/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.7
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Mar 17 17:36:10 2022
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S149>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S149>/LKA_and_ELK_State_Machine' */
#define LKAS_IN_ELKEnable              ((uint8)1U)
#define LKAS_IN_ELKLeftActive          ((uint8)2U)
#define LKAS_IN_ELKRightActive         ((uint8)3U)
#define LKAS_IN_ELK_Enable             ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKAFault               ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_LKA_Enable             ((uint8)2U)
#define LKAS_IN_NO_ACTIVE_CHILD_g      ((uint8)0U)
#define LKAS_IN_Normal_m               ((uint8)2U)
#define LKAS_IN_SysOff_g               ((uint8)2U)
#define LKAS_IN_SysOn_f                ((uint8)3U)
#define LKAS_IN_Unavailable_p          ((uint8)1U)
#define LKAS_IN_Unselected_k           ((uint8)2U)

/* Named constants for Chart: '<S116>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Exported data definition */

/* Definition for custom storage class: Default */
float32 ob_LKA_Disable_Reason;
uint32 ob_LKA_Fault_Reason;
float32 ob_LKA_LKADeactvCSyn;
float32 ob_LKA_Version;

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/* Forward declaration for local functions */
static void LKAS_Normal(void);
static void LKAS_exit_internal_Normal(void);

/*
 * System initialize for enable system:
 *    '<S91>/Sum Condition1'
 *    '<S91>/Sum Condition2'
 *    '<S472>/Sum Condition1'
 */
void LKAS_SumCondition1_Init(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S102>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S91>/Sum Condition1'
 *    '<S91>/Sum Condition2'
 *    '<S472>/Sum Condition1'
 */
void LKAS_SumCondition1_Reset(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S102>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S91>/Sum Condition1'
 *    '<S91>/Sum Condition2'
 *    '<S472>/Sum Condition1'
 */
void LKAS_SumCondition1_Disable(boolean *rty_Out, DW_SumCondition1_LKAS_T
  *localDW)
{
  /* Outputs for Enabled SubSystem: '<S91>/Sum Condition1' incorporates:
   *  EnablePort: '<S102>/state = reset'
   */
  /* Disable for Outport: '<S102>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S91>/Sum Condition1' */
  localDW->SumCondition1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S91>/Sum Condition1'
 *    '<S91>/Sum Condition2'
 *    '<S472>/Sum Condition1'
 */
void LKAS_SumCondition1(boolean rtu_statereset, float32 rtu_SampleTime, float32
  rtu_Sum, boolean *rty_Out, DW_SumCondition1_LKAS_T *localDW)
{
  float32 rtb_Saturation_mn;

  /* Outputs for Enabled SubSystem: '<S91>/Sum Condition1' incorporates:
   *  EnablePort: '<S102>/state = reset'
   */
  if (rtu_statereset) {
    if (!localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Reset(localDW);
      localDW->SumCondition1_MODE = true;
    }

    /* Sum: '<S102>/Add1' incorporates:
     *  Memory: '<S102>/Memory'
     */
    rtb_Saturation_mn = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S102>/Saturation' */
    if (rtb_Saturation_mn > 60.0F) {
      rtb_Saturation_mn = 60.0F;
    } else {
      if (rtb_Saturation_mn < 0.0F) {
        rtb_Saturation_mn = 0.0F;
      }
    }

    /* End of Saturate: '<S102>/Saturation' */

    /* RelationalOperator: '<S102>/Relational Operator' */
    *rty_Out = (rtb_Saturation_mn >= rtu_Sum);

    /* Update for Memory: '<S102>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_mn;
  } else {
    if (localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S91>/Sum Condition1' */
}

/*
 * Output and update for action system:
 *    '<S151>/If Action Subsystem2'
 *    '<S197>/If Action Subsystem3'
 *    '<S198>/If Action Subsystem3'
 *    '<S199>/If Action Subsystem3'
 *    '<S200>/If Action Subsystem3'
 *    '<S201>/If Action Subsystem3'
 *    '<S209>/If Action Subsystem3'
 *    '<S241>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S154>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S154>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/* System initialize for atomic system: '<S164>/Moving Standard Deviation2' */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S167>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S167>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* System reset for atomic system: '<S164>/Moving Standard Deviation2' */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S167>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S167>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S167>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* Output and update for atomic system: '<S164>/Moving Standard Deviation2' */
void LKAS_MovingStandardDeviation2(float32 rtu_In1, float32 *rty_Out2, float32
  *rty_Out1, DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_h;
  float32 rtb_Delay1_a;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_SumofElements;
  float32 rtb_TmpSignalConversionAtStanda[50];
  sint32 tmp;
  sint32 i;
  float32 rtb_Saturation_as;

  /* Delay: '<S167>/Delay' */
  rtb_Delay_h = localDW->Delay_DSTATE;

  /* Delay: '<S167>/Delay1' */
  rtb_Delay1_a = localDW->Delay1_DSTATE;

  /* Delay: '<S167>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S167>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S167>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S167>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S167>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S167>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S167>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S167>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S167>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S167>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S167>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S167>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S167>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S167>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S167>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S167>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S167>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S167>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S167>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S167>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S167>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S167>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S167>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S167>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S167>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S167>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S167>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S167>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S167>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S167>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S167>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S167>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S167>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S167>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S167>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S167>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S167>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S167>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S167>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S167>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S167>/Delay47' */
  rtb_SumofElements = localDW->Delay47_DSTATE;

  /* Delay: '<S167>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S167>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S167>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S167>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S167>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S167>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S167>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_h;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_a;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_SumofElements;

  /* Sum: '<S167>/Sum of Elements' */
  tmp = 0;
  rtb_Saturation_as = -0.0F;
  for (i = 0; i < 50; i++) {
    rtb_Saturation_as += rtb_TmpSignalConversionAtStanda[i];
  }

  rtb_SumofElements = rtb_Saturation_as;

  /* End of Sum: '<S167>/Sum of Elements' */

  /* Sum: '<S167>/Add2' incorporates:
   *  Constant: '<S167>/Constant'
   *  Memory: '<S167>/Memory3'
   */
  rtb_Saturation_as = (float32)((uint8)(((uint32)((uint8)1U)) + ((uint32)((uint8)
    localDW->Memory3_PreviousInput))));

  /* Saturate: '<S167>/Saturation' */
  if (rtb_Saturation_as > 50.0F) {
    rtb_Saturation_as = 50.0F;
  } else {
    if (rtb_Saturation_as < 1.0F) {
      rtb_Saturation_as = 1.0F;
    }
  }

  /* End of Saturate: '<S167>/Saturation' */

  /* Product: '<S167>/Divide' */
  *rty_Out2 = rtb_SumofElements / rtb_Saturation_as;

  /* S-Function (sdspstatfcns): '<S167>/Standard Deviation' incorporates:
   *  SignalConversion: '<S167>/TmpSignal ConversionAtStandard DeviationInport1'
   */
  while (tmp < 1) {
    localDW->StandardDeviation_AccVal = rtu_In1;
    localDW->StandardDeviation_SqData = rtu_In1 * rtu_In1;
    tmp = 1;
    for (i = 48; i >= 0; i--) {
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[tmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[tmp] *
        rtb_TmpSignalConversionAtStanda[tmp];
      tmp++;
    }

    *rty_Out1 = (localDW->StandardDeviation_SqData -
                 ((localDW->StandardDeviation_AccVal *
                   localDW->StandardDeviation_AccVal) / 50.0F)) / 49.0F;
    *rty_Out1 = sqrtf(fabsf(*rty_Out1));
    tmp = 1;
  }

  /* End of S-Function (sdspstatfcns): '<S167>/Standard Deviation' */

  /* Update for Delay: '<S167>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S167>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_h;

  /* Update for Delay: '<S167>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S167>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S167>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S167>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S167>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S167>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S167>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S167>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S167>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S167>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S167>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_a;

  /* Update for Delay: '<S167>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S167>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S167>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S167>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S167>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S167>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S167>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S167>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S167>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S167>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S167>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S167>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S167>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S167>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S167>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S167>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S167>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S167>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S167>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S167>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S167>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S167>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S167>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S167>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S167>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S167>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S167>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S167>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S167>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S167>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S167>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S167>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S167>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S167>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S167>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S167>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;

  /* Update for Memory: '<S167>/Memory3' */
  localDW->Memory3_PreviousInput = rtb_Saturation_as;
}

/*
 * Output and update for action system:
 *    '<S178>/If Action Subsystem3'
 *    '<S424>/If Action Subsystem3'
 *    '<S463>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S182>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * System initialize for atomic system:
 *    '<S178>/Moving Standard Deviation1'
 *    '<S178>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation1_Init(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S183>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S178>/Moving Standard Deviation1'
 *    '<S178>/Moving Standard Deviation2'
 */
void MovingStandardDeviation1_Reset(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S183>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S183>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S178>/Moving Standard Deviation1'
 *    '<S178>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation1(float32 rtu_In1,
  DW_MovingStandardDeviation1_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_hl;
  float32 rtb_Delay1_l;
  float32 rtb_Delay10_d;
  float32 rtb_Delay11_p;
  float32 rtb_Delay12_l;
  float32 rtb_Delay13_k;
  float32 rtb_Delay14_c;
  float32 rtb_Delay15_m;
  float32 rtb_Delay16_p;
  float32 rtb_Delay17_d;
  float32 rtb_Delay18_d;
  float32 rtb_Delay19_i;
  float32 rtb_Delay2_k;
  float32 rtb_Delay20_e;
  float32 rtb_Delay21_i;
  float32 rtb_Delay22_p;
  float32 rtb_Delay23_o;
  float32 rtb_Delay24_o;
  float32 rtb_Delay25_m;
  float32 rtb_Delay26_n;
  float32 rtb_Delay27_h;
  float32 rtb_Delay28_p;
  float32 rtb_Delay29_l;
  float32 rtb_Delay3_i;
  float32 rtb_Delay30_b;
  float32 rtb_Delay31_f;
  float32 rtb_Delay32_i;
  float32 rtb_Delay33_j;
  float32 rtb_Delay34_i;
  float32 rtb_Delay35_f;
  float32 rtb_Delay36_g;
  float32 rtb_Delay37_o;
  float32 rtb_Delay38_f;
  float32 rtb_Delay39_g;
  float32 rtb_Delay4_g;
  float32 rtb_Delay40_f;
  float32 rtb_Delay41_b;
  float32 rtb_Delay42_j;
  float32 rtb_Delay43_o;
  float32 rtb_Delay44_b;
  float32 rtb_Delay45_e;
  float32 rtb_Delay46_d;
  float32 rtb_Delay48_n;
  float32 rtb_Delay5_k;
  float32 rtb_Delay6_f;
  float32 rtb_Delay7_m;
  float32 rtb_Delay8_h;
  float32 rtb_Delay9_e;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S183>/Delay' */
  rtb_Delay_hl = localDW->Delay_DSTATE;

  /* Delay: '<S183>/Delay1' */
  rtb_Delay1_l = localDW->Delay1_DSTATE;

  /* Delay: '<S183>/Delay10' */
  rtb_Delay10_d = localDW->Delay10_DSTATE;

  /* Delay: '<S183>/Delay11' */
  rtb_Delay11_p = localDW->Delay11_DSTATE;

  /* Delay: '<S183>/Delay12' */
  rtb_Delay12_l = localDW->Delay12_DSTATE;

  /* Delay: '<S183>/Delay13' */
  rtb_Delay13_k = localDW->Delay13_DSTATE;

  /* Delay: '<S183>/Delay14' */
  rtb_Delay14_c = localDW->Delay14_DSTATE;

  /* Delay: '<S183>/Delay15' */
  rtb_Delay15_m = localDW->Delay15_DSTATE;

  /* Delay: '<S183>/Delay16' */
  rtb_Delay16_p = localDW->Delay16_DSTATE;

  /* Delay: '<S183>/Delay17' */
  rtb_Delay17_d = localDW->Delay17_DSTATE;

  /* Delay: '<S183>/Delay18' */
  rtb_Delay18_d = localDW->Delay18_DSTATE;

  /* Delay: '<S183>/Delay19' */
  rtb_Delay19_i = localDW->Delay19_DSTATE;

  /* Delay: '<S183>/Delay2' */
  rtb_Delay2_k = localDW->Delay2_DSTATE;

  /* Delay: '<S183>/Delay20' */
  rtb_Delay20_e = localDW->Delay20_DSTATE;

  /* Delay: '<S183>/Delay21' */
  rtb_Delay21_i = localDW->Delay21_DSTATE;

  /* Delay: '<S183>/Delay22' */
  rtb_Delay22_p = localDW->Delay22_DSTATE;

  /* Delay: '<S183>/Delay23' */
  rtb_Delay23_o = localDW->Delay23_DSTATE;

  /* Delay: '<S183>/Delay24' */
  rtb_Delay24_o = localDW->Delay24_DSTATE;

  /* Delay: '<S183>/Delay25' */
  rtb_Delay25_m = localDW->Delay25_DSTATE;

  /* Delay: '<S183>/Delay26' */
  rtb_Delay26_n = localDW->Delay26_DSTATE;

  /* Delay: '<S183>/Delay27' */
  rtb_Delay27_h = localDW->Delay27_DSTATE;

  /* Delay: '<S183>/Delay28' */
  rtb_Delay28_p = localDW->Delay28_DSTATE;

  /* Delay: '<S183>/Delay29' */
  rtb_Delay29_l = localDW->Delay29_DSTATE;

  /* Delay: '<S183>/Delay3' */
  rtb_Delay3_i = localDW->Delay3_DSTATE;

  /* Delay: '<S183>/Delay30' */
  rtb_Delay30_b = localDW->Delay30_DSTATE;

  /* Delay: '<S183>/Delay31' */
  rtb_Delay31_f = localDW->Delay31_DSTATE;

  /* Delay: '<S183>/Delay32' */
  rtb_Delay32_i = localDW->Delay32_DSTATE;

  /* Delay: '<S183>/Delay33' */
  rtb_Delay33_j = localDW->Delay33_DSTATE;

  /* Delay: '<S183>/Delay34' */
  rtb_Delay34_i = localDW->Delay34_DSTATE;

  /* Delay: '<S183>/Delay35' */
  rtb_Delay35_f = localDW->Delay35_DSTATE;

  /* Delay: '<S183>/Delay36' */
  rtb_Delay36_g = localDW->Delay36_DSTATE;

  /* Delay: '<S183>/Delay37' */
  rtb_Delay37_o = localDW->Delay37_DSTATE;

  /* Delay: '<S183>/Delay38' */
  rtb_Delay38_f = localDW->Delay38_DSTATE;

  /* Delay: '<S183>/Delay39' */
  rtb_Delay39_g = localDW->Delay39_DSTATE;

  /* Delay: '<S183>/Delay4' */
  rtb_Delay4_g = localDW->Delay4_DSTATE;

  /* Delay: '<S183>/Delay40' */
  rtb_Delay40_f = localDW->Delay40_DSTATE;

  /* Delay: '<S183>/Delay41' */
  rtb_Delay41_b = localDW->Delay41_DSTATE;

  /* Delay: '<S183>/Delay42' */
  rtb_Delay42_j = localDW->Delay42_DSTATE;

  /* Delay: '<S183>/Delay43' */
  rtb_Delay43_o = localDW->Delay43_DSTATE;

  /* Delay: '<S183>/Delay44' */
  rtb_Delay44_b = localDW->Delay44_DSTATE;

  /* Delay: '<S183>/Delay45' */
  rtb_Delay45_e = localDW->Delay45_DSTATE;

  /* Delay: '<S183>/Delay46' */
  rtb_Delay46_d = localDW->Delay46_DSTATE;

  /* Delay: '<S183>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S183>/Delay48' */
  rtb_Delay48_n = localDW->Delay48_DSTATE;

  /* Delay: '<S183>/Delay5' */
  rtb_Delay5_k = localDW->Delay5_DSTATE;

  /* Delay: '<S183>/Delay6' */
  rtb_Delay6_f = localDW->Delay6_DSTATE;

  /* Delay: '<S183>/Delay7' */
  rtb_Delay7_m = localDW->Delay7_DSTATE;

  /* Delay: '<S183>/Delay8' */
  rtb_Delay8_h = localDW->Delay8_DSTATE;

  /* Delay: '<S183>/Delay9' */
  rtb_Delay9_e = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S183>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_hl;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_l;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2_k;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3_i;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4_g;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5_k;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6_f;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7_m;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8_h;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9_e;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10_d;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11_p;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12_l;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13_k;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14_c;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15_m;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16_p;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17_d;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18_d;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28_p;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19_i;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20_e;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21_i;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22_p;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23_o;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24_o;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25_m;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26_n;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27_h;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38_f;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29_l;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30_b;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31_f;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32_i;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33_j;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34_i;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35_f;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36_g;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37_o;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48_n;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39_g;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40_f;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41_b;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42_j;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43_o;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44_b;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45_e;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46_d;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S183>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S183>/Standard Deviation' */

  /* Update for Delay: '<S183>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S183>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_hl;

  /* Update for Delay: '<S183>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9_e;

  /* Update for Delay: '<S183>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10_d;

  /* Update for Delay: '<S183>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11_p;

  /* Update for Delay: '<S183>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12_l;

  /* Update for Delay: '<S183>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13_k;

  /* Update for Delay: '<S183>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14_c;

  /* Update for Delay: '<S183>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15_m;

  /* Update for Delay: '<S183>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16_p;

  /* Update for Delay: '<S183>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17_d;

  /* Update for Delay: '<S183>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28_p;

  /* Update for Delay: '<S183>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_l;

  /* Update for Delay: '<S183>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19_i;

  /* Update for Delay: '<S183>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20_e;

  /* Update for Delay: '<S183>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21_i;

  /* Update for Delay: '<S183>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22_p;

  /* Update for Delay: '<S183>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23_o;

  /* Update for Delay: '<S183>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24_o;

  /* Update for Delay: '<S183>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25_m;

  /* Update for Delay: '<S183>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26_n;

  /* Update for Delay: '<S183>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18_d;

  /* Update for Delay: '<S183>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38_f;

  /* Update for Delay: '<S183>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2_k;

  /* Update for Delay: '<S183>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29_l;

  /* Update for Delay: '<S183>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30_b;

  /* Update for Delay: '<S183>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31_f;

  /* Update for Delay: '<S183>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32_i;

  /* Update for Delay: '<S183>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33_j;

  /* Update for Delay: '<S183>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34_i;

  /* Update for Delay: '<S183>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35_f;

  /* Update for Delay: '<S183>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36_g;

  /* Update for Delay: '<S183>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27_h;

  /* Update for Delay: '<S183>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48_n;

  /* Update for Delay: '<S183>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3_i;

  /* Update for Delay: '<S183>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39_g;

  /* Update for Delay: '<S183>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40_f;

  /* Update for Delay: '<S183>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41_b;

  /* Update for Delay: '<S183>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42_j;

  /* Update for Delay: '<S183>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43_o;

  /* Update for Delay: '<S183>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44_b;

  /* Update for Delay: '<S183>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45_e;

  /* Update for Delay: '<S183>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46_d;

  /* Update for Delay: '<S183>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37_o;

  /* Update for Delay: '<S183>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4_g;

  /* Update for Delay: '<S183>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5_k;

  /* Update for Delay: '<S183>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6_f;

  /* Update for Delay: '<S183>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7_m;

  /* Update for Delay: '<S183>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8_h;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S178>/Sum Condition'
 *    '<S178>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S185>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S178>/Sum Condition'
 *    '<S178>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S185>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S178>/Sum Condition'
 *    '<S178>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S178>/Sum Condition' incorporates:
   *  EnablePort: '<S185>/Enable'
   */
  /* Disable for Outport: '<S185>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S178>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S178>/Sum Condition'
 *    '<S178>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_b;

  /* Outputs for Enabled SubSystem: '<S178>/Sum Condition' incorporates:
   *  EnablePort: '<S185>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S185>/Add1' incorporates:
     *  Memory: '<S185>/Memory'
     */
    rtb_Saturation_b = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S185>/Saturation' */
    if (rtb_Saturation_b > 100.0F) {
      rtb_Saturation_b = 100.0F;
    } else {
      if (rtb_Saturation_b < 0.0F) {
        rtb_Saturation_b = 0.0F;
      }
    }

    /* End of Saturate: '<S185>/Saturation' */

    /* RelationalOperator: '<S185>/Relational Operator' */
    *rty_Out = (rtb_Saturation_b >= rtu_In1);

    /* Update for Memory: '<S185>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_b;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S178>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S197>/If Action Subsystem2'
 *    '<S197>/If Action Subsystem1'
 *    '<S198>/If Action Subsystem2'
 *    '<S198>/If Action Subsystem1'
 *    '<S199>/If Action Subsystem2'
 *    '<S199>/If Action Subsystem1'
 *    '<S200>/If Action Subsystem2'
 *    '<S200>/If Action Subsystem1'
 *    '<S201>/If Action Subsystem2'
 *    '<S201>/If Action Subsystem1'
 *    ...
 */
void LKAS_IfActionSubsystem2_p(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S211>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S202>/if action '
 *    '<S203>/if action '
 *    '<S204>/if action '
 *    '<S205>/if action '
 *    '<S206>/if action '
 *    '<S207>/if action '
 *    '<S208>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S225>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S241>/If Action Subsystem'
 *    '<S241>/If Action Subsystem4'
 *    '<S193>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S243>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system: '<S158>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S158>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  float32 K1K2Det_T1;
  float32 DelteSW0;
  float32 u;
  float32 KMax;
  float32 DelteSW1;
  float32 tmp;

  /* MATLAB Function: '<S189>/MATLABFunction1' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLABFunction1': '<S196>:1' */
  /* '<S196>:1:34' LDDir = K1K2Det_stLDDir; */
  /*     D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S196>:1:36' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_mj * 0.0174532924F;

  /* '<S196>:1:37' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S196>:1:38' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S196>:1:39' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S196>:1:40' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S196>:1:41' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S196>:1:42' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_m / 3.6F;

  /* '<S196>:1:43' Kw= u/(L*(1+K*u*u)*i); */
  /* '<S196>:1:44' KMax = K1K2Det_dphiSWARMax/180*pi; */
  KMax = (LKAS_DW.MPInP_dphiSWARMax / 180.0F) * 3.14159274F;

  /* '<S196>:1:45' Delte_Psi1 = PrvwHdAg; */
  /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
  /* '<S196>:1:47' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
  u = ((-2.0F * LKAS_DW.In_a) / (((u / (((((LKAS_DW.MPInP_StbFacm_SY * u) * u) +
             1.0F) * LKAS_DW.LKA_WhlBaseL_C_j) * LKAS_DW.LKA_StrRatio_C_a)) *
         LKAS_DW.MPInP_tiTTLCIni) * LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F *
    DelteSW0) / LKAS_DW.MPInP_tiTTLCIni);

  /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
  /* '<S196>:1:49' DelteSW1 = DelteSW0+K1*TTLC; */
  DelteSW1 = (u * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

  /* '<S196>:1:50' K1K2Det_T1 = TTLC; */
  K1K2Det_T1 = LKAS_DW.MPInP_tiTTLCIni;

  /* '<S196>:1:51' if ~(K1<abs(KMax) && K1>-abs(KMax)) */
  tmp = fabsf(KMax);
  if ((u >= tmp) || (u <= (-tmp))) {
    /*  ������ת������ */
    /* '<S196>:1:52' K1 = LDDir*KMax; */
    u = LKAS_DW.Merge * KMax;

    /* '<S196>:1:53' K1K2Det_T1 = max((-DelteSW0+sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1,(-DelteSW0-sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1); */
    KMax = sqrtf((DelteSW0 * DelteSW0) - ((2.0F * u) * LKAS_DW.In_a));
    K1K2Det_T1 = fmaxf((KMax + (-DelteSW0)) / u, ((-DelteSW0) - KMax) / u);

    /* '<S196>:1:54' DelteSW1 = (K1*K1K2Det_T1+DelteSW0); */
    DelteSW1 = (u * K1K2Det_T1) + DelteSW0;
  }

  /* '<S196>:1:56' if LDDir>0 && K1<0 && DelteSW0>0 && Delte_Psi1<0 */
  if ((((LKAS_DW.Merge > 0.0F) && (u < 0.0F)) && (DelteSW0 > 0.0F)) &&
      (LKAS_DW.In_a < 0.0F)) {
    /* '<S196>:1:57' K1 = single(0); */
    u = 0.0F;

    /* '<S196>:1:58' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S196>:1:59' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_a) / DelteSW0;
  }

  /* '<S196>:1:61' if LDDir<0 && K1>0 && DelteSW0<0 && Delte_Psi1>0 */
  if ((((LKAS_DW.Merge < 0.0F) && (u > 0.0F)) && (DelteSW0 < 0.0F)) &&
      (LKAS_DW.In_a > 0.0F)) {
    /* '<S196>:1:62' K1 = single(0); */
    u = 0.0F;

    /* '<S196>:1:63' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S196>:1:64' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_a) / DelteSW0;
  }

  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S196>:1:67' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S196>:1:69' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = u * 57.2957802F;
  LKAS_DW.K1K2Det_T1 = K1K2Det_T1;

  /* End of MATLAB Function: '<S189>/MATLABFunction1' */
}

/*
 * Output and update for atomic system:
 *    '<S251>/Saturable Gain Lut (SatGainLut)'
 *    '<S251>/Saturable Gain Lut (SatGainLut)1'
 */
void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32 rtu_InputLimLwr,
  float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32 rtu_GainLimUpr,
  float32 *rty_Gain)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S254>:1' */
  /*  Function Name: Saturable Gain Lut */
  /*  */
  /*  Description:  */
  /*    Saturable Gain Lookup Table. */
  /*  */
  /*  Assumptions and Limitation: */
  /*    The data type of all inputs and output is single. */
  /*  */
  /*  Inputs: */
  /*    Input: */
  /*    InputLimLwr: */
  /*    InputLimUpr: */
  /*    GainLimLwr: */
  /*    GainLimUpr: */
  /*  */
  /*  Outputs: */
  /*    Gain: The result of Looking up table. */
  /*  $Revision: 1.0$ */
  /*  $Author: Zhang Jianwei$ */
  /*  $Date: January 27, 2019$ */
  /*  ________________________________________ */
  /* '<S254>:1:25' if Input <= InputLimLwr */
  if (rtu_Input <= rtu_InputLimLwr) {
    /* '<S254>:1:26' Gain = GainLimLwr; */
    *rty_Gain = rtu_GainLimLwr;
  } else if (rtu_Input >= rtu_InputLimUpr) {
    /* '<S254>:1:27' elseif Input >= InputLimUpr */
    /* '<S254>:1:28' Gain = GainLimUpr; */
    *rty_Gain = rtu_GainLimUpr;
  } else {
    /* '<S254>:1:29' else */
    /* '<S254>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
    /* '<S254>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
    *rty_Gain = (((rtu_Input - rtu_InputLimLwr) / (rtu_InputLimUpr -
      rtu_InputLimLwr)) * (rtu_GainLimUpr - rtu_GainLimLwr)) + rtu_GainLimLwr;
  }
}

/*
 * Output and update for action system:
 *    '<S258>/If Action Subsystem'
 *    '<S258>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_g(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S260>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S281>/if action '
 *    '<S282>/if action '
 *    '<S289>/if action '
 *    '<S290>/if action '
 */
void LKAS_ifaction_l(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S283>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S274>/If Action Subsystem'
 *    '<S275>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_c(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_n_T *localDW)
{
  uint16 rtb_Saturation1_nc;
  uint16 rtb_Saturation1_j;

  /* Outputs for Enabled SubSystem: '<S274>/If Action Subsystem' incorporates:
   *  EnablePort: '<S279>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S281>/Add' incorporates:
     *  Constant: '<S281>/Constant'
     *  Memory: '<S281>/Memory'
     */
    rtb_Saturation1_nc = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S281>/Saturation1' */
    if (rtb_Saturation1_nc >= ((uint16)10000U)) {
      rtb_Saturation1_nc = ((uint16)10000U);
    }

    /* End of Saturate: '<S281>/Saturation1' */

    /* If: '<S281>/If' incorporates:
     *  Constant: '<S281>/Constant2'
     */
    if (rtb_Saturation1_nc <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S281>/if action ' incorporates:
       *  ActionPort: '<S283>/Action Port'
       */
      LKAS_ifaction_l(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S281>/if action ' */
    }

    /* End of If: '<S281>/If' */

    /* Sum: '<S282>/Add' incorporates:
     *  Constant: '<S282>/Constant'
     *  Memory: '<S282>/Memory'
     */
    rtb_Saturation1_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_d));

    /* Saturate: '<S282>/Saturation1' */
    if (rtb_Saturation1_j >= ((uint16)10000U)) {
      rtb_Saturation1_j = ((uint16)10000U);
    }

    /* End of Saturate: '<S282>/Saturation1' */

    /* If: '<S282>/If' incorporates:
     *  Constant: '<S282>/Constant2'
     */
    if (rtb_Saturation1_j == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S282>/if action ' incorporates:
       *  ActionPort: '<S284>/Action Port'
       */
      LKAS_ifaction_l(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S282>/if action ' */
    }

    /* End of If: '<S282>/If' */

    /* Update for Memory: '<S281>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_nc;

    /* Update for Memory: '<S282>/Memory' */
    localDW->Memory_PreviousInput_d = rtb_Saturation1_j;
  }

  /* End of Outputs for SubSystem: '<S274>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S274>/If Action Subsystem2'
 *    '<S275>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_n(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S280>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S280>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S149>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_b = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_b = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c69_LKAS = 0U;
  LKAS_DW.is_c69_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.LDWSM_stLDWActvFlg = 0U;
  LKAS_DW.LDWSM_stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S149>/LDW_State_Machine'
 * Block description for: '<S149>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S149>/LDW_State_Machine'
   *
   * Block description for '<S149>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c69_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c69_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S342>:2' */
    LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S342>:1' */
    /* Transition: '<S342>:31' */
    LKAS_DW.is_SysOff_b = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S342>:30' */
    LKAS_DW.LDWSM_stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c69_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S342>:36' */
      tmp = !LKAS_DW.LDW_Fault;
      if (tmp && ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)
             LKAS_DW.LKA_Mode) == 2))) {
        /* Transition: '<S342>:38' */
        /* Exit Internal 'Fault': '<S342>:36' */
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S342>:3' */
        /* Transition: '<S342>:77' */
        LKAS_DW.is_SysOn_b = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S342>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 0) && tmp) {
        /* Transition: '<S342>:40' */
        /* Exit Internal 'Fault': '<S342>:36' */
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_b = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S342>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else {
        LKAS_DW.LDWSM_stLDWState = 6U;

        /* During 'LDWFault': '<S342>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S342>:1' */
      if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
          && (LKAS_DW.LDW_Fault)) {
        /* Transition: '<S342>:39' */
        /* Exit Internal 'SysOff': '<S342>:1' */
        LKAS_DW.is_SysOff_b = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S342>:36' */
        /* Transition: '<S342>:75' */
        /* Entry 'LDWFault': '<S342>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
                  == 2)) {
        /* Transition: '<S342>:41' */
        /* Exit Internal 'SysOff': '<S342>:1' */
        LKAS_DW.is_SysOff_b = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S342>:3' */
        /* Transition: '<S342>:77' */
        LKAS_DW.is_SysOn_b = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S342>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_b) == LKAS_IN_Unavailable) {
        LKAS_DW.LDWSM_stLDWState = 0U;

        /* During 'Unavailable': '<S342>:30' */
        if (((sint32)LKAS_DW.LKA_Mode) == 0) {
          /* Transition: '<S342>:35' */
          LKAS_DW.is_SysOff_b = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S342>:32' */
          LKAS_DW.LDWSM_stLDWState = 1U;
        }
      } else {
        LKAS_DW.LDWSM_stLDWState = 1U;

        /* During 'Unselected': '<S342>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S342>:3' */
      if (LKAS_DW.LDW_Fault) {
        /* Transition: '<S342>:37' */
        /* Exit Internal 'SysOn': '<S342>:3' */
        if (((uint32)LKAS_DW.is_SysOn_b) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S342>:102' */
          switch (LKAS_DW.is_Normal_k) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S342>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S342>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_b = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_b = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S342>:36' */
        /* Transition: '<S342>:75' */
        /* Entry 'LDWFault': '<S342>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) != 1) && (((sint32)LKAS_DW.LKA_Mode)
                  != 2)) {
        /* Transition: '<S342>:42' */
        /* Exit Internal 'SysOn': '<S342>:3' */
        if (((uint32)LKAS_DW.is_SysOn_b) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S342>:102' */
          switch (LKAS_DW.is_Normal_k) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S342>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S342>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_b = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_b = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_b = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S342>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_b) == LKAS_IN_LDWSelected) {
        LKAS_DW.LDWSM_stLDWState = 2U;

        /* During 'LDWSelected': '<S342>:47' */
        if ((LKAS_DW.Merge_m) && (!LKAS_DW.Merge1_fi)) {
          /* Transition: '<S342>:50' */
          LKAS_DW.is_SysOn_b = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S342>:102' */
          /* Transition: '<S342>:113' */
          LKAS_DW.is_Normal_k = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S342>:112' */
          LKAS_DW.LDWSM_stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S342>:102' */
        if (LKAS_DW.Merge1_fi) {
          /* Transition: '<S342>:44' */
          /* Exit Internal 'Normal': '<S342>:102' */
          switch (LKAS_DW.is_Normal_k) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S342>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S342>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_k = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_b = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S342>:47' */
          LKAS_DW.LDWSM_stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_k) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.LDWSM_stLDWState = 3U;

            /* During 'LDWEnable': '<S342>:112' */
            if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_c)) {
              /* Transition: '<S342>:118' */
              LKAS_DW.is_Normal_k = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S342>:114' */
              LKAS_DW.LDWSM_stLDWState = 4U;
              LKAS_DW.LDWSM_stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_c))
              {
                /* Transition: '<S342>:119' */
                LKAS_DW.is_Normal_k = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S342>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.LDWSM_stLDWState = 4U;

            /* During 'LDWLeftActive': '<S342>:114' */
            if (LKAS_DW.Merge_c) {
              /* Transition: '<S342>:116' */
              /* Exit 'LDWLeftActive': '<S342>:114' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_k = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S342>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_c))
              {
                /* Transition: '<S342>:120' */
                /* Exit 'LDWLeftActive': '<S342>:114' */
                LKAS_DW.is_Normal_k = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S342>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LDWSM_stLDWState = 5U;

            /* During 'LDWRightActive': '<S342>:115' */
            if (LKAS_DW.Merge_c) {
              /* Transition: '<S342>:117' */
              /* Exit 'LDWRightActive': '<S342>:115' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_k = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S342>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_c))
              {
                /* Transition: '<S342>:121' */
                /* Exit 'LDWRightActive': '<S342>:115' */
                LKAS_DW.is_Normal_k = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S342>:114' */
                LKAS_DW.LDWSM_stLDWState = 4U;
                LKAS_DW.LDWSM_stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S149>/LDW_State_Machine' */
}

/* Function for Chart: '<S149>/LKA_and_ELK_State_Machine' */
static void LKAS_Normal(void)
{
  /* During 'Normal': '<S344>:102' */
  if (((uint32)LKAS_DW.is_Normal) == LKAS_IN_ELK_Enable) {
    /* During 'ELK_Enable': '<S344>:151' */
    switch (LKAS_DW.is_ELK_Enable) {
     case LKAS_IN_ELKEnable:
      LKAS_DW.LKASM_stLKAState = 3U;

      /* During 'ELKEnable': '<S344>:124' */
      /* Transition: '<S344>:134' */
      LKAS_DW.is_ELK_Enable = LKAS_IN_ELKLeftActive;

      /* Entry 'ELKLeftActive': '<S344>:129' */
      LKAS_DW.LKASM_stLKAState = 4U;
      LKAS_DW.LKASM_stLKAActvFlg = 0U;
      break;

     case LKAS_IN_ELKLeftActive:
      LKAS_DW.LKASM_stLKAState = 4U;

      /* During 'ELKLeftActive': '<S344>:129' */
      break;

     default:
      LKAS_DW.LKASM_stLKAState = 5U;

      /* During 'ELKRightActive': '<S344>:131' */
      /* Transition: '<S344>:133' */
      /* Exit 'ELKRightActive': '<S344>:131' */
      LKAS_DW.is_ELK_Enable = LKAS_IN_ELKLeftActive;

      /* Entry 'ELKLeftActive': '<S344>:129' */
      LKAS_DW.LKASM_stLKAState = 4U;
      LKAS_DW.LKASM_stLKAActvFlg = 0U;
      break;
    }
  } else {
    /* During 'LKA_Enable': '<S344>:150' */
    if (LKAS_DW.Merge2_n) {
      /* Transition: '<S344>:122' */
      if ((LKAS_DW.Merge1_e) && (!LKAS_DW.Merge2_n)) {
        /* Transition: '<S344>:144' */
        /* Exit Internal 'LKA_Enable': '<S344>:150' */
        switch (LKAS_DW.is_LKA_Enable) {
         case LKAS_IN_LKALeftActive:
          /* Exit 'LKALeftActive': '<S344>:109' */
          LKAS_DW.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
          break;

         case LKAS_IN_LKARightActive:
          /* Exit 'LKARightActive': '<S344>:110' */
          LKAS_DW.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
          break;

         default:
          LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
          break;
        }

        /* Exit 'LKA_Enable': '<S344>:150' */
        LKAS_DW.is_Normal = LKAS_IN_LKA_Enable;

        /* Entry 'LKA_Enable': '<S344>:150' */
        /* Entry Internal 'LKA_Enable': '<S344>:150' */
        /* Transition: '<S344>:153' */
        LKAS_DW.is_LKA_Enable = LKAS_IN_LKAEnable;

        /* Entry 'LKAEnable': '<S344>:115' */
        LKAS_DW.LKASM_stLKAState = 3U;
        LKAS_DW.EPS_Control_i = 1U;
      } else {
        /* Transition: '<S344>:146' */
        /* Exit Internal 'LKA_Enable': '<S344>:150' */
        switch (LKAS_DW.is_LKA_Enable) {
         case LKAS_IN_LKALeftActive:
          /* Exit 'LKALeftActive': '<S344>:109' */
          LKAS_DW.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
          break;

         case LKAS_IN_LKARightActive:
          /* Exit 'LKARightActive': '<S344>:110' */
          LKAS_DW.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
          break;

         default:
          LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
          break;
        }

        /* Exit 'LKA_Enable': '<S344>:150' */
        LKAS_DW.EPS_Control_i = 0U;
        LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S344>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      }
    } else {
      switch (LKAS_DW.is_LKA_Enable) {
       case LKAS_IN_LKAEnable:
        LKAS_DW.LKASM_stLKAState = 3U;

        /* During 'LKAEnable': '<S344>:115' */
        if ((((sint32)LKAS_DW.Merge2) == 2) && (!LKAS_DW.Merge1_f)) {
          /* Transition: '<S344>:104' */
          LKAS_DW.is_LKA_Enable = LKAS_IN_LKARightActive;

          /* Entry 'LKARightActive': '<S344>:110' */
          LKAS_DW.LKASM_stLKAState = 5U;
          LKAS_DW.LKASM_stLKAActvFlg = LKAS_DW.Merge2;
        } else {
          if ((((sint32)LKAS_DW.Merge2) == 1) && (!LKAS_DW.Merge1_f)) {
            /* Transition: '<S344>:105' */
            LKAS_DW.is_LKA_Enable = LKAS_IN_LKALeftActive;

            /* Entry 'LKALeftActive': '<S344>:109' */
            LKAS_DW.LKASM_stLKAState = 4U;
            LKAS_DW.LKASM_stLKAActvFlg = LKAS_DW.Merge2;
          }
        }
        break;

       case LKAS_IN_LKALeftActive:
        LKAS_DW.LKASM_stLKAState = 4U;

        /* During 'LKALeftActive': '<S344>:109' */
        if (LKAS_DW.Merge1_f) {
          /* Transition: '<S344>:106' */
          /* Exit 'LKALeftActive': '<S344>:109' */
          LKAS_DW.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_LKA_Enable = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S344>:115' */
          LKAS_DW.LKASM_stLKAState = 3U;
          LKAS_DW.EPS_Control_i = 1U;
        } else {
          if ((((sint32)LKAS_DW.Merge2) == 2) && (!LKAS_DW.Merge1_f)) {
            /* Transition: '<S344>:111' */
            /* Exit 'LKALeftActive': '<S344>:109' */
            LKAS_DW.is_LKA_Enable = LKAS_IN_LKARightActive;

            /* Entry 'LKARightActive': '<S344>:110' */
            LKAS_DW.LKASM_stLKAState = 5U;
            LKAS_DW.LKASM_stLKAActvFlg = LKAS_DW.Merge2;
          }
        }
        break;

       default:
        LKAS_DW.LKASM_stLKAState = 5U;

        /* During 'LKARightActive': '<S344>:110' */
        if (LKAS_DW.Merge1_f) {
          /* Transition: '<S344>:107' */
          /* Exit 'LKARightActive': '<S344>:110' */
          LKAS_DW.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_LKA_Enable = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S344>:115' */
          LKAS_DW.LKASM_stLKAState = 3U;
          LKAS_DW.EPS_Control_i = 1U;
        } else {
          if ((((sint32)LKAS_DW.Merge2) == 1) && (!LKAS_DW.Merge1_f)) {
            /* Transition: '<S344>:112' */
            /* Exit 'LKARightActive': '<S344>:110' */
            LKAS_DW.is_LKA_Enable = LKAS_IN_LKALeftActive;

            /* Entry 'LKALeftActive': '<S344>:109' */
            LKAS_DW.LKASM_stLKAState = 4U;
            LKAS_DW.LKASM_stLKAActvFlg = LKAS_DW.Merge2;
          }
        }
        break;
      }
    }
  }
}

/* Function for Chart: '<S149>/LKA_and_ELK_State_Machine' */
static void LKAS_exit_internal_Normal(void)
{
  /* Exit Internal 'Normal': '<S344>:102' */
  switch (LKAS_DW.is_Normal) {
   case LKAS_IN_ELK_Enable:
    /* Exit Internal 'ELK_Enable': '<S344>:151' */
    switch (LKAS_DW.is_ELK_Enable) {
     case LKAS_IN_ELKLeftActive:
      /* Exit 'ELKLeftActive': '<S344>:129' */
      LKAS_DW.LKASM_stLKAActvFlg = 0U;
      LKAS_DW.is_ELK_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
      break;

     case LKAS_IN_ELKRightActive:
      /* Exit 'ELKRightActive': '<S344>:131' */
      LKAS_DW.LKASM_stLKAActvFlg = 0U;
      LKAS_DW.is_ELK_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
      break;

     default:
      LKAS_DW.is_ELK_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
      break;
    }

    /* Exit 'ELK_Enable': '<S344>:151' */
    LKAS_DW.EPS_Control_i = 0U;
    LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
    break;

   case LKAS_IN_LKA_Enable:
    /* Exit Internal 'LKA_Enable': '<S344>:150' */
    switch (LKAS_DW.is_LKA_Enable) {
     case LKAS_IN_LKALeftActive:
      /* Exit 'LKALeftActive': '<S344>:109' */
      LKAS_DW.LKASM_stLKAActvFlg = 0U;
      LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
      break;

     case LKAS_IN_LKARightActive:
      /* Exit 'LKARightActive': '<S344>:110' */
      LKAS_DW.LKASM_stLKAActvFlg = 0U;
      LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
      break;

     default:
      LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
      break;
    }

    /* Exit 'LKA_Enable': '<S344>:150' */
    LKAS_DW.EPS_Control_i = 0U;
    LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
    break;

   default:
    /* no actions */
    break;
  }
}

/* System reset for atomic system: '<S149>/LKA_and_ELK_State_Machine' */
void LKA_and_ELK_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.is_ELK_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.is_LKA_Enable = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.is_active_c7_LKAS = 0U;
  LKAS_DW.is_c7_LKAS = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.LKASM_stLKAActvFlg = 0U;
  LKAS_DW.LKASM_stLKAState = 0U;
  LKAS_DW.EPS_Control_i = 0U;
}

/*
 * Output and update for atomic system: '<S149>/LKA_and_ELK_State_Machine'
 * Block description for: '<S149>/LKA_and_ELK_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_and_ELK_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S149>/LKA_and_ELK_State_Machine'
   *
   * Block description for '<S149>/LKA_and_ELK_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_and_ELK_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_and_ELK_State_Machine */
  if (((uint32)LKAS_DW.is_active_c7_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_and_ELK_State_Machine */
    LKAS_DW.is_active_c7_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_and_ELK_State_Machine */
    /* Transition: '<S344>:2' */
    LKAS_DW.is_c7_LKAS = LKAS_IN_SysOff_g;

    /* Entry Internal 'SysOff': '<S344>:1' */
    /* Transition: '<S344>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_p;

    /* Entry 'Unavailable': '<S344>:30' */
    LKAS_DW.LKASM_stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c7_LKAS) {
     case LKAS_IN_LKAFault:
      LKAS_DW.LKASM_stLKAState = 6U;

      /* During 'LKAFault': '<S344>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && ((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)
             LKAS_DW.LKA_Mode) == 3))) {
        /* Transition: '<S344>:38' */
        LKAS_DW.is_c7_LKAS = LKAS_IN_SysOn_f;

        /* Entry Internal 'SysOn': '<S344>:3' */
        /* Transition: '<S344>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S344>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else {
        if (((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)LKAS_DW.LKA_Mode) ==
              1)) && tmp) {
          /* Transition: '<S344>:40' */
          LKAS_DW.is_c7_LKAS = LKAS_IN_SysOff_g;
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_k;

          /* Entry 'Unselected': '<S344>:32' */
          LKAS_DW.LKASM_stLKAState = 1U;
        }
      }
      break;

     case LKAS_IN_SysOff_g:
      /* During 'SysOff': '<S344>:1' */
      if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) == 3))
          && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S344>:39' */
        /* Exit Internal 'SysOff': '<S344>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_g;
        LKAS_DW.is_c7_LKAS = LKAS_IN_LKAFault;

        /* Entry 'LKAFault': '<S344>:36' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode)
                  == 3)) {
        /* Transition: '<S344>:41' */
        /* Exit Internal 'SysOff': '<S344>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_g;
        LKAS_DW.is_c7_LKAS = LKAS_IN_SysOn_f;

        /* Entry Internal 'SysOn': '<S344>:3' */
        /* Transition: '<S344>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S344>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_p) {
        LKAS_DW.LKASM_stLKAState = 0U;

        /* During 'Unavailable': '<S344>:30' */
        if ((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)LKAS_DW.LKA_Mode) ==
             1)) {
          /* Transition: '<S344>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_k;

          /* Entry 'Unselected': '<S344>:32' */
          LKAS_DW.LKASM_stLKAState = 1U;
        }
      } else {
        LKAS_DW.LKASM_stLKAState = 1U;

        /* During 'Unselected': '<S344>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S344>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S344>:37' */
        /* Exit Internal 'SysOn': '<S344>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_m) {
          LKAS_exit_internal_Normal();
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
        }

        LKAS_DW.is_c7_LKAS = LKAS_IN_LKAFault;

        /* Entry 'LKAFault': '<S344>:36' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) != 2) && (((sint32)LKAS_DW.LKA_Mode)
                  != 3)) {
        /* Transition: '<S344>:42' */
        /* Exit Internal 'SysOn': '<S344>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_m) {
          LKAS_exit_internal_Normal();
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
        }

        LKAS_DW.is_c7_LKAS = LKAS_IN_SysOff_g;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_k;

        /* Entry 'Unselected': '<S344>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.LKASM_stLKAState = 2U;

        /* During 'LKASelected': '<S344>:19' */
        if ((LKAS_DW.Merge1_e) && (!LKAS_DW.Merge2_n)) {
          /* Transition: '<S344>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_m;
          LKAS_DW.is_Normal = LKAS_IN_LKA_Enable;

          /* Entry 'LKA_Enable': '<S344>:150' */
          /* Entry Internal 'LKA_Enable': '<S344>:150' */
          /* Transition: '<S344>:153' */
          LKAS_DW.is_LKA_Enable = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S344>:115' */
          LKAS_DW.LKASM_stLKAState = 3U;
          LKAS_DW.EPS_Control_i = 1U;
        }
      } else {
        LKAS_Normal();
      }
      break;
    }
  }

  /* End of Chart: '<S149>/LKA_and_ELK_State_Machine' */
}

/*
 * Output and update for action system:
 *    '<S365>/Ph1SWA'
 *    '<S374>/Ph1SWA'
 *    '<S401>/Ph1SWA'
 *    '<S411>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S369>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S369>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S365>/Ph2SWA'
 *    '<S374>/Ph2SWA'
 *    '<S401>/Ph2SWA'
 *    '<S411>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S370>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S370>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S365>/Ph3SWA'
 *    '<S401>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S371>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S374>/Ph3SWA'
 *    '<S411>/Ph3SWA'
 */
void LKAS_Ph3SWA_b(float32 *rty_Out)
{
  /* SignalConversion: '<S380>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S380>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S437>/If Action Subsystem4'
 *    '<S437>/If Action Subsystem3'
 *    '<S543>/If Action Subsystem3'
 *    '<S543>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S449>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S449>/Constant'
   */
  *rty_Out = false;
}

/*
 * Output and update for action system:
 *    '<S472>/If Action Subsystem'
 *    '<S472>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_e(boolean *rty_Out)
{
  /* SignalConversion: '<S476>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S476>/Constant'
   */
  *rty_Out = true;
}

/*
 * Output and update for atomic system:
 *    '<S557>/MATLAB Function'
 *    '<S576>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_DvtThresUprLDW, float32 rtu_LaneWidth,
  float32 rtu_LKA_CarWidth, float32 *rty_ThresDet_coefficient)
{
  float32 tmp;

  /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Enable Condition  (EnaC)/LDW Own Condition (LDWOwnC)/Vehicle Position Check (VehPosChk)/Subsystem/MATLAB Function': '<S558>:1' */
  /* '<S558>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
  /* '<S558>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
  /* '<S558>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
  /* '<S558>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
  /* '<S558>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
  tmp = (2.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth;
  *rty_ThresDet_coefficient = fminf(fmaxf(0.0F, (fminf(fmaxf(tmp, rtu_LaneWidth),
    (6.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth) - tmp) / (4.0F *
    rtu_DvtThresUprLDW)), 1.0F);
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPva_g_obj_acc_x[40];
  float32 rtb_IMAPva_g_obj_acc_y[40];
  float32 rtb_IMAPva_g_obj_length[40];
  float32 rtb_IMAPva_g_obj_pos_var_x[40];
  float32 rtb_IMAPva_g_obj_pos_var_xy[40];
  float32 rtb_IMAPva_g_obj_pos_var_y[40];
  float32 rtb_IMAPva_g_obj_pos_x[40];
  float32 rtb_IMAPva_g_obj_pos_y[40];
  float32 rtb_IMAPva_g_obj_vel_x[40];
  float32 rtb_IMAPva_g_obj_vel_y[40];
  float32 rtb_IMAPva_g_obj_width[40];
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_VehSpd;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_Gain_h;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_Gain_f;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_MAX_DELAY_EPSSTAR_TIME;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_LFClb_TFC_KpVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KpVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KpV1_C;
  float32 rtb_LL_LFClb_TFC_KpV2_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KdV1_C;
  float32 rtb_LL_LFClb_TFC_KdV2_C;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_LL_HandsOff_TextTime;
  float32 rtb_LL_HandsOff_WarnTime;
  float32 rtb_R0_VR_j;
  float32 rtb_L0_VR_d;
  float32 rtb_R0_W_c;
  float32 rtb_L0_W_c;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_Lrg_C0;
  float32 rtb_Lrg_C1;
  float32 rtb_Lrg_C2;
  float32 rtb_Lrg_C3;
  float32 rtb_Lrg_VR;
  float32 rtb_R1_VR;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_VR_d;
  float32 rtb_R1_W;
  float32 rtb_Rrg_C0;
  float32 rtb_Rrg_C1;
  float32 rtb_Rrg_C2;
  float32 rtb_Rrg_C3;
  float32 rtb_Rrg_VR;
  float32 rtb_R1_VR_h;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_lStpLngth_C;
  float32 rtb_LL_DesDvt_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_n;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_crCrvt;
  float32 rtb_Gain1;
  float32 rtb_phiHdAg_Lft;
  float32 rtb_Add5_k;
  float32 rtb_phiHdAg_Rgt;
  float32 rtb_Add_e1;
  float32 rtb_Add_g;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge;
  float32 rtb_Switch_a;
  float32 rtb_Saturation_h;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Multiply;
  float32 rtb_Switch_ak;
  float32 rtb_Switch2_e;
  float32 rtb_Switch_f;
  float32 rtb_Saturation_hz;
  float32 rtb_Abs1_o;
  float32 rtb_Abs_i;
  float32 rtb_UnaryMinus_e;
  float32 rtb_Merge1;
  float32 rtb_Divide_b;
  float32 rtb_Switch_n;
  float32 rtb_Switch2_c;
  float32 rtb_Divide_dg;
  float32 rtb_Switch_o1;
  float32 rtb_Switch2_h;
  float32 rtb_Merge1_g;
  float32 rtb_Divide_a;
  float32 rtb_Switch_e;
  float32 rtb_Switch2_j;
  float32 rtb_Divide_n;
  float32 rtb_Switch_p;
  float32 rtb_Switch2_hl;
  float32 rtb_Multiply_n;
  float32 rtb_Switch_l;
  float32 rtb_Switch2_m;
  float32 rtb_Memory_ol;
  float32 rtb_Merge1_p;
  float32 rtb_Divide_p;
  float32 rtb_Switch_j;
  float32 rtb_Switch2_mp;
  float32 rtb_Divide_l;
  float32 rtb_Switch_f3;
  float32 rtb_Switch2_jy;
  float32 rtb_Memory_e;
  float32 rtb_Merge1_n;
  float32 rtb_Divide_j;
  float32 rtb_Switch_j2;
  float32 rtb_Switch2_g;
  float32 rtb_Divide_e;
  float32 rtb_Switch_g;
  float32 rtb_Switch2_k;
  float32 rtb_Saturation_i;
  float32 rtb_Divide_lg;
  float32 rtb_Divide_ex;
  float32 rtb_Add_c;
  float32 rtb_Add_o;
  float32 rtb_phiHdAg;
  float32 rtb_lDvt;
  float32 rtb_ThresDet_coefficient;
  float32 rtb_ThresDet_coefficient_d;
  float32 rtb_Saturation2_e;
  float32 rtb_Add1_fg;
  float32 rtb_Merge_d;
  float32 rtb_Gain_nj;
  float32 rtb_Gain1_e;
  float32 rtb_Add_ne;
  float32 rtb_Add_ja;
  float32 rtb_Saturation6;
  float32 rtb_Saturation2_l;
  float32 rtb_Saturation2_ey;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_li;
  float32 rtb_Saturation_ny;
  float32 rtb_Add1_l1;
  float32 rtb_kphtomps_po;
  float32 rtb_Saturation_c;
  float32 rtb_Switch2_no;
  float32 rtb_Switch_p3;
  float32 rtb_Switch2_i;
  float32 rtb_Gain1_n;
  float32 rtb_Switch_oe;
  float32 rtb_Switch2_jw;
  float32 rtb_Divide5_j;
  float32 rtb_Divide2_e;
  float32 rtb_Merge_g;
  float32 rtb_Switch_ei;
  float32 rtb_Switch2_hf;
  float32 rtb_Divide7;
  float32 rtb_Switch_jp;
  float32 rtb_Switch2_b;
  float32 rtb_Saturation_f;
  float32 rtb_Switch_ld;
  float32 rtb_Add_fk;
  float32 rtb_Switch_gl;
  float32 rtb_Switch2_hr;
  float32 rtb_UkYk1_c;
  float32 rtb_Switch_m;
  float32 rtb_Switch2_hb;
  float32 rtb_Abs1_a;
  float32 rtb_Abs_a;
  float32 rtb_Add1_k;
  float32 rtb_Merge_f;
  float32 rtb_Merge_gk;
  float32 rtb_Merge_p;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_lf;
  float32 rtb_Saturation_j2;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_In;
  float32 rtb_In_d;
  float32 rtb_In_n;
  float32 rtb_LKA_Status_Display;
  float32 rtb_LKA_Status_Display_e;
  float32 rtb_Plan;
  float32 rtb_T1_a;
  float32 rtb_Plan_m;
  float32 rtb_T1_g;
  float32 rtb_Gain_i;
  float32 rtb_Merge_n;
  float32 rtb_kphTomps_l;
  float32 rtb_Divide3_n;
  float32 rtb_Gain2_g;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_c;
  uint16 rtb_Saturation1_dc;
  uint16 rtb_Saturation1_k5;
  uint16 rtb_Saturation1_b;
  uint16 rtb_Saturation1_a;
  uint16 rtb_Saturation2_i;
  uint16 rtb_Add_jv;
  uint16 rtb_Saturation1_l;
  uint16 rtb_Saturation1_h;
  uint8 rtb_IMAPva_d_obj_MotionStatus[40];
  uint8 rtb_IMAPva_d_obj_class[40];
  uint8 rtb_IMAPva_d_obj_id[40];
  uint8 rtb_IMAPva_d_obj_lane[40];
  uint8 rtb_IMAPva_d_obj_status[40];
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_p;
  uint8 rtb_L0_Type_k;
  uint8 rtb_LDW_Warn_Mode;
  uint8 rtb_EWWWve_y_BSD_LCAWarning;
  uint8 rtb_EWWWve_y_BSD_LCWWorkingSt;
  uint8 rtb_EWWWve_y_BSD_S_LCAWarning;
  uint8 rtb_EWWWve_y_BSD_S_LCWWorkingSt;
  uint8 rtb_FDMMve_d_ElkFcnConf;
  uint8 rtb_IMAPve_d_APA_AutoPark_WorkS;
  uint8 rtb_IMAPve_d_BCM_HazardLamp_Swi;
  uint8 rtb_IMAPve_d_ELK_Switch;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_EPS_TrqLim_State;
  uint8 rtb_IMAPve_d_EPS_Trq_State;
  uint8 rtb_IMAPve_d_ESC_LatAcc_Valid;
  uint8 rtb_IMAPve_d_ESC_LonAcc_Valid;
  uint8 rtb_IMAPve_d_ESC_VehSpd_Valid;
  uint8 rtb_IMAPve_d_ESC_YawRate_Valid;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L1_Type;
  uint8 rtb_Lrg_Q;
  uint8 rtb_Lrg_Type;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_R1_Type;
  uint8 rtb_Rrg_Q;
  uint8 rtb_Rrg_Type;
  uint8 rtb_IMAPve_d_SAS_Clb_State;
  uint8 rtb_IMAPve_d_SAS_Trim_State;
  uint8 rtb_IMAPve_d_SWS_Failure_Status;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_IMAPve_d_obj_Num;
  uint8 rtb_DACMode;
  uint8 rtb_EPS_Control;
  uint8 rtb_LDW_State;
  uint8 rtb_Switch8;
  uint8 rtb_Switch8_c;
  uint8 rtb_Switch8_j;
  uint8 rtb_Saturation1_d2;
  uint8 rtb_Vehicle_Lane_Display_i;
  uint8 rtb_LKA_Action_Indication_g;
  uint8 rtb_LDW_Status_Display_i;
  uint8 rtb_LDW_Flag_d;
  uint8 rtb_Hands_Off_Warning_a;
  uint8 rtb_Hands_Off_Warning_h;
  uint8 rtb_HMI_Popup_Status_g;
  uint8 rtb_HMI_Popup_Status_d;
  boolean rtb_LogicalOperator2;
  boolean rtb_ADIA_DTC_EMS_14B_InvOorReal;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxT;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinT;
  boolean rtb_ADIAve_e_Node_ACU_Validity;
  boolean rtb_ADIAve_e_Node_EPB_Validity;
  boolean rtb_ADIA_Inner_FRadar_FaultStat;
  boolean rtb_ADIAve_d_sen_sta_Corner_rad;
  boolean rtb_ADIAve_e_Node_EMS_Validity;
  boolean rtb_ADIAve_e_Node_TBOX_Validity;
  boolean rtb_ADIA_DTC_ESC_EPBErrorStatus;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorTCS;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorVeh;
  boolean rtb_ADIA_DTC_MP5_366_OorAEBButt;
  boolean rtb_ADIA_DTC_MP5_366_OorFCWButt;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorSta;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorYaw;
  boolean rtb_ADIA_DTC_ESC6_123_InvOorDyn;
  boolean rtb_ADIA_DTC_ESC6_123_InvUnfilY;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehDri;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehHol;
  boolean rtb_ADIA_DTC_GW_MP5_413_OorISAM;
  boolean rtb_ADIA_DTC_SCC_309_OorACCButt;
  boolean rtb_ADIA_DTC_BCM3_33C_InvBrkLig;
  boolean rtb_ADIA_DTC_EMS_14A_OorACCStat;
  boolean rtb_ADIA_DTC_EMS10_88_InvAccPed;
  boolean rtb_ADIA_DTC_EMS5_E0_InvOorBrkP;
  boolean rtb_ADIA_DTC_EMS5_E0_OorEngineS;
  boolean rtb_Compare_mo;
  boolean rtb_UnitDelay_p;
  boolean rtb_Merge_h;
  boolean rtb_Compare_b0;
  boolean rtb_UnitDelay_de;
  boolean rtb_Compare_ld;
  boolean rtb_Merge_a;
  boolean rtb_Merge_fj;
  boolean rtb_Compare_lz;
  boolean rtb_LogicalOperator1_f;
  boolean rtb_RelationalOperator6_p;
  boolean rtb_RelationalOperator5;
  boolean rtb_Compare_gy;
  boolean rtb_Memory1_h;
  boolean rtb_Merge_ai;
  float32 x10;
  float32 x20;
  float32 x1;
  UInt16 tmpRead;
  UInt16 tmpRead_0;
  UInt16 tmpRead_1;
  UInt16 tmpRead_2;
  UInt16 tmpRead_3;
  UInt16 tmpRead_4;
  UInt16 tmpRead_5;
  UInt16 tmpRead_6;
  UInt16 tmpRead_7;
  UInt16 tmpRead_8;
  UInt16 tmpRead_9;
  UInt16 tmpRead_a;
  UInt16 tmpRead_b;
  UInt16 tmpRead_c;
  UInt16 tmpRead_d;
  UInt16 tmpRead_e;
  UInt16 tmpRead_f;
  UInt16 tmpRead_g;
  UInt16 tmpRead_h;
  UInt16 tmpRead_i;
  UInt16 tmpRead_j;
  UInt16 tmpRead_k;
  UInt16 tmpRead_l;
  UInt16 tmpRead_m;
  UInt16 tmpRead_n;
  UInt16 tmpRead_o;
  UInt16 tmpRead_p;
  UInt16 tmpRead_q;
  UInt16 tmpRead_r;
  UInt16 tmpRead_s;
  UInt16 tmpRead_t;
  UInt16 tmpRead_u;
  UInt16 tmpRead_v;
  UInt16 tmpRead_w;
  UInt16 tmpRead_x;
  UInt16 tmpRead_y[40];
  UInt16 tmpRead_z[40];
  UInt16 tmpRead_10[40];
  UInt16 tmpRead_11[40];
  UInt16 tmpRead_12[40];
  T_M_Nm_Float32 tmpRead_13;
  T_M_Nm_Float32 tmpRead_14;
  UInt16 tmpRead_15;
  UInt16 tmpRead_16;
  T_M_Nm_Float32 tmpRead_17;
  T_M_Nm_Float32 tmpRead_18;
  T_M_Nm_Float32 tmpRead_19;
  UInt16 tmpRead_1a;
  T_M_Nm_Float32 tmpRead_1b;
  T_M_Nm_Float32 tmpRead_1c;
  T_M_Nm_Float32 tmpRead_1d;
  T_M_Nm_Float32 tmpRead_1e;
  T_M_Nm_Float32 tmpRead_1f;
  UInt16 tmpRead_1g;
  UInt16 tmpRead_1h;
  T_M_Nm_Float32 tmpRead_1i;
  T_M_Nm_Float32 tmpRead_1j;
  T_M_Nm_Float32 tmpRead_1k;
  T_M_Nm_Float32 tmpRead_1l;
  UInt16 tmpRead_1m;
  UInt16 tmpRead_1n;
  T_M_Nm_Float32 tmpRead_1o;
  T_M_Nm_Float32 tmpRead_1p;
  T_M_Nm_Float32 tmpRead_1q;
  T_M_Nm_Float32 tmpRead_1r;
  UInt16 tmpRead_1s;
  UInt16 tmpRead_1t;
  T_M_Nm_Float32 tmpRead_1u;
  T_M_Nm_Float32 tmpRead_1v;
  T_M_Nm_Float32 tmpRead_1w;
  T_M_Nm_Float32 tmpRead_1x;
  UInt16 tmpRead_1y;
  UInt16 tmpRead_1z;
  UInt32 tmpWrite;
  UInt32 tmpWrite_0;
  UInt32 tmpWrite_1;
  UInt32 tmpWrite_2;
  UInt32 tmpWrite_3;
  UInt32 tmpWrite_4;
  UInt32 tmpWrite_5;
  UInt32 tmpWrite_6;
  uint8 rtb_Mod1;
  uint8 rtb_IMAPve_d_Rrg_TYPE_BACK;
  boolean rtb_LKA_Main_Switch;
  uint8 rtb_L0_Type;
  float32 rtb_Switch;
  uint8 rtb_R0_Type;
  float32 rtb_Switch1;
  uint8 rtb_L0_Q;
  uint8 rtb_R0_Q;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  float32 rtb_SW_Angle;
  boolean rtb_BCM_Left_Light;
  boolean rtb_BCM_Right_Light;
  uint8 rtb_TCU_ActualGear;
  float32 rtb_IMAPve_g_Rrg_VR_Start_BACK;
  float32 rtb_Saturation1;
  float32 rtb_Switch_i;
  float32 rtb_Switch_ha;
  float32 rtb_L0_C0_b;
  float32 rtb_LL_CompHdAg_C;
  float32 rtb_L0_C1_fx;
  float32 rtb_R0_C1_d;
  float32 rtb_L0_C2_h;
  float32 rtb_L0_C3_g;
  float32 rtb_R0_C0_a;
  float32 rtb_R0_C3_j;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_LKA_LatestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  boolean rtb_LL_SingleLane_Disable_Swt;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LFClb_TFC_KdBalance_C;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LL_LKAExPrcs_tiExitDelayTim;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_Abs_l;
  float32 rtb_Abs_h;
  float32 rtb_TTLC_i;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_h;
  boolean rtb_LogicalOperator3_b;
  boolean rtb_RelationalOperator_j;
  boolean rtb_Compare_m2;
  boolean rtb_LogicalOperator_ax;
  boolean rtb_Compare_ag2;
  boolean rtb_LogicalOperator_nl;
  boolean rtb_Compare_b5;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_pu;
  boolean rtb_RelationalOperator_p;
  boolean rtb_LogicalOperator_o5;
  boolean rtb_LogicalOperator_ps;
  float32 rtb_ThresDet_coefficient_l;
  uint8 rtb_CastToSingle3;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge_ou;
  uint32 rtb_Add;
  float32 rtb_Saturation_ae;
  uint16 rtb_Saturation_nn;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  float32 rtb_TTLC;
  float32 rtb_TLft;
  sint32 i;
  float32 tmp;
  float32 rtb_Abs_n_tmp;
  float32 rtb_Add5_k_tmp;
  float32 rtb_LogicalOperator3_h_tmp;
  boolean rtb_RelationalOperator_kw_tmp;
  float32 rtb_Add_e1_tmp;
  float32 rtb_Add_g_tmp;
  boolean exitg1;

  /* Inport: '<Root>/IMAPve_d_R0_Q' */
  Rte_Read_IMAPve_d_R0_Q_IMAPve_d_R0_Q(&rtb_Saturation_nn);

  /* Inport: '<Root>/IMAPve_d_L0_Q' */
  Rte_Read_IMAPve_d_L0_Q_IMAPve_d_L0_Q(&tmpRead_15);

  /* Inport: '<Root>/IMAPva_d_obj_MotionStatus' */
  Rte_Read_IMAPva_d_obj_MotionStatus_IMAPva_d_obj_MotionStatus(tmpRead_12);

  /* Inport: '<Root>/IMAPva_d_obj_status' */
  Rte_Read_IMAPva_d_obj_status_IMAPva_d_obj_status(tmpRead_11);

  /* Inport: '<Root>/IMAPva_d_obj_lane' */
  Rte_Read_IMAPva_d_obj_lane_IMAPva_d_obj_lane(tmpRead_10);

  /* Inport: '<Root>/IMAPva_d_obj_class' */
  Rte_Read_IMAPva_d_obj_class_IMAPva_d_obj_class(tmpRead_z);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPva_g_obj_length_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_length'
   */
  Rte_Read_IMAPva_g_obj_length_IMAPva_g_obj_length(rtb_IMAPva_g_obj_length);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_width_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_width'
   */
  Rte_Read_IMAPva_g_obj_width_IMAPva_g_obj_width(rtb_IMAPva_g_obj_width);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_var_xy_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_pos_var_xy'
   */
  Rte_Read_IMAPva_g_obj_pos_var_xy_IMAPva_g_obj_pos_var_xy
    (rtb_IMAPva_g_obj_pos_var_xy);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_var_y_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_pos_var_y'
   */
  Rte_Read_IMAPva_g_obj_pos_var_y_IMAPva_g_obj_pos_var_y
    (rtb_IMAPva_g_obj_pos_var_y);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_var_x_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_pos_var_x'
   */
  Rte_Read_IMAPva_g_obj_pos_var_x_IMAPva_g_obj_pos_var_x
    (rtb_IMAPva_g_obj_pos_var_x);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_acc_y_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_acc_y'
   */
  Rte_Read_IMAPva_g_obj_acc_y_IMAPva_g_obj_acc_y(rtb_IMAPva_g_obj_acc_y);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_acc_x_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_acc_x'
   */
  Rte_Read_IMAPva_g_obj_acc_x_IMAPva_g_obj_acc_x(rtb_IMAPva_g_obj_acc_x);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_vel_y_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_vel_y'
   */
  Rte_Read_IMAPva_g_obj_vel_y_IMAPva_g_obj_vel_y(rtb_IMAPva_g_obj_vel_y);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_vel_x_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_vel_x'
   */
  Rte_Read_IMAPva_g_obj_vel_x_IMAPva_g_obj_vel_x(rtb_IMAPva_g_obj_vel_x);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_y_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_pos_y'
   */
  Rte_Read_IMAPva_g_obj_pos_y_IMAPva_g_obj_pos_y(rtb_IMAPva_g_obj_pos_y);

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_x_1' incorporates:
   *  Inport: '<Root>/IMAPva_g_obj_pos_x'
   */
  Rte_Read_IMAPva_g_obj_pos_x_IMAPva_g_obj_pos_x(rtb_IMAPva_g_obj_pos_x);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPva_d_obj_id' */
  Rte_Read_IMAPva_d_obj_id_IMAPva_d_obj_id(tmpRead_y);

  /* Inport: '<Root>/IMAPve_d_LKA_Mode' */
  Rte_Read_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode(&tmpRead_2);

  /* Inport: '<Root>/IMAPve_d_LKA_Main_Switch' */
  Rte_Read_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch(&tmpRead_1);

  /* Inport: '<Root>/FDMMve_d_LkaFcnConf' */
  Rte_Read_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf(&tmpRead);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPva_d_obj_MotionStatus_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_MotionStatus[i] = (uint8)tmpRead_12[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_MotionStatus_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_class_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_class[i] = (uint8)tmpRead_z[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_class_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_id_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_id[i] = (uint8)tmpRead_y[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_id_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_lane_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_lane[i] = (uint8)tmpRead_10[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_lane_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_status_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_status[i] = (uint8)tmpRead_11[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_status_1' */

  /* DataTypeConversion: '<S1>/FDMMve_d_LkaFcnConf_1' */
  rtb_Mod1 = (uint8)tmpRead;

  /* Switch: '<S108>/Switch' incorporates:
   *  Constant: '<S108>/Constant3'
   *  Constant: '<S108>/Constant4'
   */
  if (rtb_Mod1 > ((uint8)0U)) {
    rtb_L0_Q = ((uint8)1U);
  } else {
    rtb_L0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S108>/Switch' */

  /* Saturate: '<S108>/Saturation1' */
  if (rtb_Mod1 > ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  } else {
    if (rtb_Mod1 < ((uint8)1U)) {
      rtb_Mod1 = ((uint8)1U);
    }
  }

  /* End of Saturate: '<S108>/Saturation1' */

  /* Sum: '<S108>/Add1' incorporates:
   *  Constant: '<S108>/Constant1'
   */
  rtb_Mod1 -= ((uint8)1U);

  /* Saturate: '<S108>/Saturation' */
  if (rtb_Mod1 >= ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  }

  /* End of Saturate: '<S108>/Saturation' */

  /* Math: '<S108>/Mod' incorporates:
   *  Constant: '<S108>/Constant2'
   */
  if (((sint32)((uint8)6U)) == 0) {
    rtb_R0_Q = rtb_Mod1;
  } else {
    rtb_R0_Q = (uint8)(rtb_Mod1 % ((uint8)6U));
  }

  /* End of Math: '<S108>/Mod' */

  /* Product: '<S108>/Divide1' incorporates:
   *  Constant: '<S108>/Constant5'
   */
  rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(((uint32)rtb_R0_Q) / ((uint32)((uint8)3U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1' */
  rtb_R0_Q = (uint8)tmpRead_2;

  /* MinMax: '<S108>/Max' */
  if (rtb_IMAPve_d_Rrg_TYPE_BACK > rtb_R0_Q) {
    rtb_R0_Q = rtb_IMAPve_d_Rrg_TYPE_BACK;
  }

  /* End of MinMax: '<S108>/Max' */

  /* Product: '<S108>/Divide' incorporates:
   *  Constant: '<S108>/Constant6'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  Logic: '<S108>/Logical Operator'
   *  Sum: '<S108>/Add'
   */
  LKAS_DW.LKA_Mode = (uint8)((sint32)(((((sint32)rtb_L0_Q) != 0) || (((sint32)
    ((uint8)tmpRead_1)) != 0)) ? ((sint32)((uint8)(((uint32)rtb_R0_Q) + ((uint32)
    ((uint8)1U))))) : 0));

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' */
  rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)tmpRead_15;

  /* Switch: '<S121>/Switch' incorporates:
   *  Constant: '<S121>/Constant'
   */
  if (rtb_IMAPve_d_Rrg_TYPE_BACK >= ((uint8)2U)) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = rtb_IMAPve_d_Rrg_TYPE_BACK;
  }

  /* End of Switch: '<S121>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' */
  rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)rtb_Saturation_nn;

  /* Switch: '<S117>/Switch1' incorporates:
   *  Constant: '<S117>/Constant1'
   */
  if (rtb_IMAPve_d_Rrg_TYPE_BACK >= ((uint8)2U)) {
    rtb_R0_Q = ((uint8)3U);
  } else {
    rtb_R0_Q = rtb_IMAPve_d_Rrg_TYPE_BACK;
  }

  /* End of Switch: '<S117>/Switch1' */

  /* Chart: '<S116>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c26_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c26_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S123>:4' */
    LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S123>:3' */
    /* '<S123>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S123>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S123>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c26_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S123>:9' */
      /* '<S123>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S123>:13' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S123>:3' */
        /* '<S123>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S123>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S123>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S123>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S123>:14' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S123>:7' */
          /* '<S123>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S123>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S123>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S123>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
            /* Transition: '<S123>:23' */
            LKAS_DW.is_c26_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S123>:5' */
            /* '<S123>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S123>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S123>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S123>:5' */
      /* '<S123>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S123>:16' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S123>:3' */
        /* '<S123>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S123>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S123>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S123>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S123>:18' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S123>:7' */
          /* '<S123>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S123>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S123>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S123>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_R0_Q) < 3) {
            /* Transition: '<S123>:11' */
            LKAS_DW.is_c26_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S123>:3' */
      /* '<S123>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S123>:6' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S123>:5' */
        /* '<S123>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S123>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S123>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S123>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S123>:8' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S123>:7' */
          /* '<S123>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S123>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S123>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S123>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) < 3)) {
            /* Transition: '<S123>:10' */
            /* '<S123>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c26_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S123>:7' */
      /* '<S123>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S123>:17' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S123>:3' */
        /* '<S123>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S123>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S123>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S123>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
          /* Transition: '<S123>:19' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S123>:5' */
          /* '<S123>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S123>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S123>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S123>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_L0_Q) < 3) {
            /* Transition: '<S123>:12' */
            LKAS_DW.is_c26_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S116>/LaneReconstructSM' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_L0_Type' */
  Rte_Read_IMAPve_d_L0_Type_IMAPve_d_L0_Type(&tmpRead_16);

  /* Inport: '<Root>/IMAPve_g_L0_C0' */
  Rte_Read_IMAPve_g_L0_C0_IMAPve_g_L0_C0(&rtb_Switch);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1' */
  rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)tmpRead_16;

  /* DataTypeConversion: '<S115>/Cast To Single77' */
  rtb_L0_Type = rtb_IMAPve_d_Rrg_TYPE_BACK;

  /* Switch: '<S133>/Switch' incorporates:
   *  Constant: '<S144>/Constant'
   *  DataTypeConversion: '<S115>/Cast To Single77'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  Memory: '<S128>/Memory1'
   *  RelationalOperator: '<S144>/Compare'
   *  Sum: '<S133>/Add'
   *  UnaryMinus: '<S115>/Unary Minus'
   */
  if (rtb_IMAPve_d_Rrg_TYPE_BACK == ((uint8)10U)) {
    rtb_Switch = (-rtb_Switch) + LKAS_DW.Memory1_PreviousInput;
  } else {
    rtb_Switch = -rtb_Switch;
  }

  /* End of Switch: '<S133>/Switch' */

  /* Switch: '<S143>/Switch' incorporates:
   *  Abs: '<S143>/Abs'
   *  Constant: '<S145>/Constant'
   *  Memory: '<S143>/Memory'
   *  Memory: '<S143>/Memory1'
   *  Product: '<S143>/Divide'
   *  Product: '<S143>/Divide1'
   *  RelationalOperator: '<S145>/Compare'
   *  Sum: '<S143>/Add1'
   *  Sum: '<S143>/Add3'
   */
  if (fabsf(rtb_Switch - LKAS_DW.Memory1_PreviousInput_l) > 0.5F) {
    rtb_Switch_i = rtb_Switch;
  } else {
    rtb_Switch_i = (rtb_Switch * LKAS_ConstB.Divide2) + (LKAS_ConstB.Add2 *
      LKAS_DW.Memory_PreviousInput);
  }

  /* End of Switch: '<S143>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_R0_Type' */
  Rte_Read_IMAPve_d_R0_Type_IMAPve_d_R0_Type(&tmpRead_1a);

  /* Inport: '<Root>/IMAPve_g_R0_C0' */
  Rte_Read_IMAPve_g_R0_C0_IMAPve_g_R0_C0(&rtb_Switch1);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1' */
  rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)tmpRead_1a;

  /* DataTypeConversion: '<S115>/Cast To Single48' */
  rtb_R0_Type = rtb_IMAPve_d_Rrg_TYPE_BACK;

  /* Switch: '<S129>/Switch1' incorporates:
   *  Constant: '<S136>/Constant'
   *  DataTypeConversion: '<S115>/Cast To Single48'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  Memory: '<S128>/Memory1'
   *  RelationalOperator: '<S136>/Compare'
   *  Sum: '<S129>/Add1'
   *  UnaryMinus: '<S115>/Unary Minus4'
   */
  if (rtb_IMAPve_d_Rrg_TYPE_BACK == ((uint8)10U)) {
    rtb_Switch1 = (-rtb_Switch1) - LKAS_DW.Memory1_PreviousInput;
  } else {
    rtb_Switch1 = -rtb_Switch1;
  }

  /* End of Switch: '<S129>/Switch1' */

  /* Switch: '<S135>/Switch' incorporates:
   *  Abs: '<S135>/Abs'
   *  Constant: '<S137>/Constant'
   *  Memory: '<S135>/Memory'
   *  Memory: '<S135>/Memory1'
   *  Product: '<S135>/Divide'
   *  Product: '<S135>/Divide1'
   *  RelationalOperator: '<S137>/Compare'
   *  Sum: '<S135>/Add1'
   *  Sum: '<S135>/Add3'
   */
  if (fabsf(rtb_Switch1 - LKAS_DW.Memory1_PreviousInput_f) > 0.5F) {
    rtb_Switch_ha = rtb_Switch1;
  } else {
    rtb_Switch_ha = (rtb_Switch1 * LKAS_ConstB.Divide2_f) + (LKAS_ConstB.Add2_o *
      LKAS_DW.Memory_PreviousInput_b);
  }

  /* End of Switch: '<S135>/Switch' */

  /* Switch: '<S116>/Switch1' incorporates:
   *  Gain: '<S125>/Gain'
   *  Memory: '<S128>/Memory'
   *  Sum: '<S125>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_b = rtb_Switch_i;
  } else {
    rtb_L0_C0_b = (LKAS_DW.Memory_PreviousInput_o - rtb_Switch_ha) * (-1.0F);
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_L0_C1' */
  Rte_Read_IMAPve_g_L0_C1_IMAPve_g_L0_C1(&rtb_L0_C1_fx);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S664>/Switch24' incorporates:
   *  Constant: '<S664>/LL_CompHdAg_C=0.005'
   */
  if (LKAS_ConstB.DataTypeConversion38 != 0.0F) {
    rtb_LL_CompHdAg_C = LKAS_ConstB.DataTypeConversion38;
  } else {
    rtb_LL_CompHdAg_C = LL_CompHdAg_C;
  }

  /* End of Switch: '<S664>/Switch24' */

  /* Switch: '<S130>/Switch1' incorporates:
   *  Constant: '<S138>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
   *  RelationalOperator: '<S138>/Compare'
   *  Sum: '<S130>/Add'
   *  UnaryMinus: '<S115>/Unary Minus1'
   */
  if (rtb_L0_Q == ((uint8)3U)) {
    rtb_L0_C1_fx = rtb_LL_CompHdAg_C + (-rtb_L0_C1_fx);
  } else {
    rtb_L0_C1_fx = -rtb_L0_C1_fx;
  }

  /* End of Switch: '<S130>/Switch1' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_R0_C1' */
  Rte_Read_IMAPve_g_R0_C1_IMAPve_g_R0_C1(&rtb_R0_C0_a);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S131>/Switch1' incorporates:
   *  Constant: '<S139>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
   *  RelationalOperator: '<S139>/Compare'
   *  Sum: '<S131>/Add'
   *  UnaryMinus: '<S115>/Unary Minus5'
   */
  if (rtb_R0_Q == ((uint8)3U)) {
    rtb_R0_C1_d = rtb_LL_CompHdAg_C + (-rtb_R0_C0_a);
  } else {
    rtb_R0_C1_d = -rtb_R0_C0_a;
  }

  /* End of Switch: '<S131>/Switch1' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_R0_C2' */
  Rte_Read_IMAPve_g_R0_C2_IMAPve_g_R0_C2(&tmpRead_18);

  /* Inport: '<Root>/IMAPve_g_L0_C2' */
  Rte_Read_IMAPve_g_L0_C2_IMAPve_g_L0_C2(&tmpRead_13);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S116>/Switch1' incorporates:
   *  DataTypeConversion: '<S125>/Cast To Single1'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_LL_CompHdAg_C = rtb_L0_C1_fx;
  } else {
    rtb_LL_CompHdAg_C = rtb_R0_C1_d;
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_R0_C3' */
  Rte_Read_IMAPve_g_R0_C3_IMAPve_g_R0_C3(&rtb_LL_LKA_LatestWarnLine_C);

  /* Inport: '<Root>/IMAPve_g_L0_C3' */
  Rte_Read_IMAPve_g_L0_C3_IMAPve_g_L0_C3(&rtb_LL_LFClb_TFC_KdBalance_C);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S116>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  UnaryMinus: '<S115>/Unary Minus2'
   *  UnaryMinus: '<S115>/Unary Minus3'
   *  UnaryMinus: '<S115>/Unary Minus6'
   *  UnaryMinus: '<S115>/Unary Minus7'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C2_h = (float32)((T_M_Nm_Float32)(-tmpRead_13));
    rtb_L0_C3_g = -rtb_LL_LFClb_TFC_KdBalance_C;
  } else {
    rtb_L0_C2_h = (float32)((T_M_Nm_Float32)(-tmpRead_18));
    rtb_L0_C3_g = -rtb_LL_LKA_LatestWarnLine_C;
  }

  /* Switch: '<S116>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  Memory: '<S128>/Memory'
   *  Sum: '<S127>/Add'
   *  UnaryMinus: '<S115>/Unary Minus2'
   *  UnaryMinus: '<S115>/Unary Minus3'
   *  UnaryMinus: '<S115>/Unary Minus6'
   *  UnaryMinus: '<S115>/Unary Minus7'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_C0_a = rtb_Switch_ha;
    rtb_L0_C1_fx = rtb_R0_C1_d;
    rtb_R0_C1_d = (float32)((T_M_Nm_Float32)(-tmpRead_18));
    rtb_R0_C3_j = -rtb_LL_LKA_LatestWarnLine_C;
  } else {
    rtb_R0_C0_a = LKAS_DW.Memory_PreviousInput_o + rtb_Switch_i;
    rtb_R0_C1_d = (float32)((T_M_Nm_Float32)(-tmpRead_13));
    rtb_R0_C3_j = -rtb_LL_LFClb_TFC_KdBalance_C;
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_TCU_Actual_Gear' */
  Rte_Read_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear(&tmpRead_r);

  /* Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch' */
  Rte_Read_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
    (&tmpRead_p);

  /* Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch' */
  Rte_Read_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch(&tmpRead_o);

  /* Inport: '<Root>/IMAPve_d_BCM_Right_Light' */
  Rte_Read_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light(&tmpRead_n);

  /* Inport: '<Root>/IMAPve_d_BCM_Left_Light' */
  Rte_Read_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light(&tmpRead_m);

  /* Inport: '<Root>/IMAPve_d_BCM_HazardLamp' */
  Rte_Read_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp(&tmpRead_l);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  Rte_Read_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc(&rtb_IMAPve_g_ESC_LonAcc);

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  Rte_Read_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd(&rtb_IMAPve_g_ESC_VehSpd);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_ESC_LatAcc' */
  Rte_Read_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc(&rtb_Saturation_ae);

  /* Inport: '<Root>/IMAPve_g_SW_Angle_Speed' */
  Rte_Read_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
    (&rtb_ThresDet_coefficient_l);

  /* Inport: '<Root>/IMAPve_g_EPS_SteeringAngle' */
  Rte_Read_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle(&rtb_SW_Angle);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  Rte_Read_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq(&rtb_IMAPve_g_EPS_SW_Trq);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_EPS_LKA_State' */
  Rte_Read_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State(&tmpRead_7);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)tmpRead_7;

  /* Gain: '<S111>/Gain' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1'
   */
  rtb_SW_Angle *= 1.0F;

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' */
  rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)tmpRead_l;

  /* Logic: '<S104>/Logical Operator' incorporates:
   *  Constant: '<S113>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1'
   *  RelationalOperator: '<S113>/Compare'
   */
  rtb_BCM_Left_Light = ((((sint32)((uint8)tmpRead_m)) != 0) || (((uint8)
    tmpRead_o) == ((uint8)1U)));

  /* Logic: '<S104>/Logical Operator1' incorporates:
   *  Constant: '<S114>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1'
   *  RelationalOperator: '<S114>/Compare'
   */
  rtb_BCM_Right_Light = ((((sint32)((uint8)tmpRead_n)) != 0) || (((uint8)
    tmpRead_p) == ((uint8)1U)));

  /* MultiPortSwitch: '<S110>/Multiport Switch' incorporates:
   *  Constant: '<S110>/Constant1'
   *  Constant: '<S110>/Constant3'
   *  DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1'
   */
  switch ((uint8)tmpRead_r) {
   case 0:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 1:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 2:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 3:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 4:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 5:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 6:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 7:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 8:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 9:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   default:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;
  }

  /* End of MultiPortSwitch: '<S110>/Multiport Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/ADIAve_g_BSWFaultStatus' */
  Rte_Read_ADIAve_g_BSWFaultStatus_ADIAve_g_BSWFaultStatus
    (&rtb_IMAPve_g_Rrg_VR_Start_BACK);

  /* Inport: '<Root>/ADIAve_g_ASWFaultStatus' */
  Rte_Read_ADIAve_g_ASWFaultStatus_ADIAve_g_ASWFaultStatus(&rtb_Saturation1);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S665>/Switch58' incorporates:
   *  Constant: '<S665>/LLSMConClb4'
   *
   * Block description for '<S665>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S665>/Switch58' */

  /* Gain: '<S670>/Gain' incorporates:
   *  Constant: '<S670>/Constant'
   *  Sum: '<S670>/Add'
   */
  rtb_Gain_h = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S665>/Switch84' incorporates:
   *  Constant: '<S665>/LLSMConClb5'
   *
   * Block description for '<S665>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S665>/Switch84' */

  /* Switch: '<S665>/Switch85' incorporates:
   *  Constant: '<S665>/LLSMConClb6'
   *
   * Block description for '<S665>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S665>/Switch85' */

  /* Switch: '<S665>/Switch86' incorporates:
   *  Constant: '<S665>/LLSMConClb7'
   *
   * Block description for '<S665>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S665>/Switch86' */

  /* Switch: '<S665>/Switch54' incorporates:
   *  Constant: '<S665>/LLSMConClb12'
   *
   * Block description for '<S665>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S665>/Switch54' */

  /* Switch: '<S665>/Switch55' incorporates:
   *  Constant: '<S665>/LLSMConClb13'
   *
   * Block description for '<S665>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S665>/Switch55' */

  /* Switch: '<S665>/Switch60' incorporates:
   *  Constant: '<S665>/LLSMConClb17'
   *
   * Block description for '<S665>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S665>/Switch60' */

  /* Switch: '<S665>/Switch57' incorporates:
   *  Constant: '<S665>/LLSMConClb18'
   *
   * Block description for '<S665>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S665>/Switch57' */

  /* Switch: '<S665>/Switch59' incorporates:
   *  Constant: '<S665>/LLSMConClb19'
   *
   * Block description for '<S665>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_LL_LKA_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_LL_LKA_LatestWarnLine_C = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S665>/Switch59' */

  /* Switch: '<S665>/Switch69' incorporates:
   *  Constant: '<S665>/LLSMConClb22'
   *
   * Block description for '<S665>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S665>/Switch69' */

  /* Gain: '<S667>/Gain' incorporates:
   *  Constant: '<S667>/Constant'
   *  Sum: '<S667>/Add'
   */
  rtb_Gain_f = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S665>/Switch68' incorporates:
   *  Constant: '<S665>/LLSMConClb23'
   *
   * Block description for '<S665>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S665>/Switch68' */

  /* Switch: '<S665>/Switch70' incorporates:
   *  Constant: '<S665>/LLSMConClb24'
   *
   * Block description for '<S665>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S665>/Switch70' */

  /* Switch: '<S665>/Switch71' incorporates:
   *  Constant: '<S665>/LLSMConClb25'
   *
   * Block description for '<S665>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S665>/Switch71' */

  /* Switch: '<S665>/Switch73' incorporates:
   *  Constant: '<S665>/LLSMConClb27'
   *
   * Block description for '<S665>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S665>/Switch73' */

  /* Switch: '<S665>/Switch62' incorporates:
   *  Constant: '<S665>/LLSMConClb31'
   *
   * Block description for '<S665>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S665>/Switch62' */

  /* Switch: '<S665>/Switch63' incorporates:
   *  Constant: '<S665>/LLSMConClb32'
   *
   * Block description for '<S665>/LLSMConClb32':
   *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
   */
  if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LKAS_ConstB.DataTypeConversion78;
  } else {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LL_MAX_DELAY_EPSSTAR_TIME;
  }

  /* End of Switch: '<S665>/Switch63' */

  /* Switch: '<S665>/Switch66' incorporates:
   *  Constant: '<S665>/LLSMConClb35'
   *
   * Block description for '<S665>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S665>/Switch66' */

  /* Switch: '<S665>/Switch4' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=4'
   *
   * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=4':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_SingleLane_Disable_Swt = (LKAS_ConstB.DataTypeConversion4 != 0.0F);
  } else {
    rtb_LL_SingleLane_Disable_Swt = LL_SingleLane_Disable_Swt;
  }

  /* End of Switch: '<S665>/Switch4' */

  /* Switch: '<S665>/Switch81' incorporates:
   *  Constant: '<S665>/LLSMConClb36'
   *
   * Block description for '<S665>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S665>/Switch81' */

  /* Switch: '<S665>/Switch82' incorporates:
   *  Constant: '<S665>/LLSMConClb37'
   *
   * Block description for '<S665>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S665>/Switch82' */

  /* Switch: '<S665>/Switch83' incorporates:
   *  Constant: '<S665>/LLSMConClb38'
   *
   * Block description for '<S665>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S665>/Switch83' */

  /* Switch: '<S665>/Switch75' incorporates:
   *  Constant: '<S665>/LLSMConClb39'
   *
   * Block description for '<S665>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S665>/Switch75' */

  /* Switch: '<S665>/Switch76' incorporates:
   *  Constant: '<S665>/LLSMConClb40'
   *
   * Block description for '<S665>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S665>/Switch76' */

  /* Switch: '<S665>/Switch77' incorporates:
   *  Constant: '<S665>/LLSMConClb41'
   *
   * Block description for '<S665>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S665>/Switch77' */

  /* Switch: '<S665>/Switch78' incorporates:
   *  Constant: '<S665>/LLSMConClb42'
   *
   * Block description for '<S665>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S665>/Switch78' */

  /* Switch: '<S664>/Switch3' incorporates:
   *  Constant: '<S664>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3_o != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3_o;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S664>/Switch3' */

  /* Switch: '<S664>/Switch31' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KpVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_e != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LKAS_ConstB.DataTypeConversion14_e;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S664>/Switch31' */

  /* Switch: '<S664>/Switch34' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KpVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4_n != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LKAS_ConstB.DataTypeConversion4_n;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S664>/Switch34' */

  /* Switch: '<S664>/Switch33' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KpV1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_d != 0.0F) {
    rtb_LL_LFClb_TFC_KpV1_C = LKAS_ConstB.DataTypeConversion7_d;
  } else {
    rtb_LL_LFClb_TFC_KpV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S664>/Switch33' */

  /* Switch: '<S664>/Switch35' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KpV2_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion17_i != 0.0F) {
    rtb_LL_LFClb_TFC_KpV2_C = LKAS_ConstB.DataTypeConversion17_i;
  } else {
    rtb_LL_LFClb_TFC_KpV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S664>/Switch35' */

  /* Switch: '<S664>/Switch20' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LL_LFClb_TFC_KdVehSpdLwr_C;
  }

  /* End of Switch: '<S664>/Switch20' */

  /* Switch: '<S664>/Switch22' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LL_LFClb_TFC_KdVehSpdUpr_C;
  }

  /* End of Switch: '<S664>/Switch22' */

  /* Switch: '<S664>/Switch21' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdV1_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV1_C = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LFClb_TFC_KdV1_C = LL_LFClb_TFC_KdV1_C;
  }

  /* End of Switch: '<S664>/Switch21' */

  /* Switch: '<S664>/Switch23' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdV2_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV2_C = LKAS_ConstB.DataTypeConversion30;
  } else {
    rtb_LL_LFClb_TFC_KdV2_C = LL_LFClb_TFC_KdV2_C;
  }

  /* End of Switch: '<S664>/Switch23' */

  /* Switch: '<S664>/Switch9' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdBalance_C=1.2'
   */
  if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
    rtb_LL_LFClb_TFC_KdBalance_C = LKAS_ConstB.DataTypeConversion9;
  } else {
    rtb_LL_LFClb_TFC_KdBalance_C = LL_LFClb_TFC_KdBalance_C;
  }

  /* End of Switch: '<S664>/Switch9' */

  /* Switch: '<S664>/Switch11' incorporates:
   *  Constant: '<S664>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_k != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12_k;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S664>/Switch11' */

  /* Switch: '<S664>/Switch13' incorporates:
   *  Constant: '<S664>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_c != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_c;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S664>/Switch13' */

  /* Switch: '<S664>/Switch16' incorporates:
   *  Constant: '<S664>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S664>/Switch16' */

  /* Switch: '<S664>/Switch55' incorporates:
   *  Constant: '<S664>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S664>/Switch55' */

  /* Switch: '<S664>/Switch54' incorporates:
   *  Constant: '<S664>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S664>/Switch54' */

  /* Switch: '<S664>/Switch44' incorporates:
   *  Constant: '<S664>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S664>/Switch44' */

  /* Switch: '<S664>/Switch25' incorporates:
   *  Constant: '<S664>/LL_LKAExPrcs_tiExitDelayTime3=0.5'
   */
  if (LKAS_ConstB.DataTypeConversion39 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LKAS_ConstB.DataTypeConversion39;
  } else {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LL_LKAExPrcs_tiExitDelayTime3;
  }

  /* End of Switch: '<S664>/Switch25' */

  /* Switch: '<S662>/Switch19' incorporates:
   *  Constant: '<S662>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_h != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_h;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S662>/Switch19' */

  /* Switch: '<S662>/Switch' incorporates:
   *  Constant: '<S662>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_p != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_p;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S662>/Switch' */

  /* Switch: '<S662>/Switch1' incorporates:
   *  Constant: '<S662>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_f != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_f;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S662>/Switch1' */

  /* Switch: '<S662>/Switch2' incorporates:
   *  Constant: '<S662>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_e != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_j = LKAS_ConstB.DataTypeConversion4_e;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_j = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S662>/Switch2' */

  /* Switch: '<S662>/Switch3' incorporates:
   *  Constant: '<S662>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_ku != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_a = LKAS_ConstB.DataTypeConversion6_ku;
  } else {
    LKAS_DW.LKA_StrRatio_C_a = LKA_StrRatio_C;
  }

  /* End of Switch: '<S662>/Switch3' */

  /* Switch: '<S662>/Switch11' incorporates:
   *  Constant: '<S662>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S662>/Switch11' */

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (((sint32)LKAS_DW.LKA_Mode) > 0) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S149>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);
      LKAS_DW.Delay1_4_DSTATE = ((uint8)0U);

      /* InitializeConditions for Delay: '<S148>/Delay' */
      LKAS_DW.Delay_DSTATE_c = ((uint8)0U);

      /* InitializeConditions for Memory: '<S589>/Memory' */
      LKAS_DW.Memory_PreviousInput_bk = 0.0F;

      /* InitializeConditions for Delay: '<S149>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S532>/Memory' */
      LKAS_DW.Memory_PreviousInput_bl = 0.0F;

      /* InitializeConditions for UnitDelay: '<S464>/Delay Input1'
       *
       * Block description for '<S464>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S463>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_c = false;

      /* InitializeConditions for UnitDelay: '<S426>/Delay Input1'
       *
       * Block description for '<S426>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_a = false;

      /* InitializeConditions for UnitDelay: '<S424>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_i = false;

      /* InitializeConditions for UnitDelay: '<S425>/Delay Input1'
       *
       * Block description for '<S425>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_i = false;

      /* InitializeConditions for Memory: '<S391>/Memory' */
      LKAS_DW.Memory_PreviousInput_e = false;

      /* InitializeConditions for Delay: '<S149>/Delay' */
      LKAS_DW.Delay_DSTATE_m = false;

      /* InitializeConditions for Delay: '<S149>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S439>/Memory' */
      LKAS_DW.Memory_PreviousInput_gd = ((uint8)0U);

      /* InitializeConditions for Memory: '<S365>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = 0.0F;

      /* InitializeConditions for Memory: '<S401>/Memory' */
      LKAS_DW.Memory_PreviousInput_gb = 0.0F;

      /* InitializeConditions for Memory: '<S601>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = 0.0F;

      /* InitializeConditions for Delay: '<S602>/Delay' */
      LKAS_DW.Delay_DSTATE_d = ((uint8)0U);

      /* InitializeConditions for Delay: '<S603>/Delay' */
      LKAS_DW.Delay_DSTATE_a = ((uint8)0U);

      /* InitializeConditions for Delay: '<S604>/Delay' */
      LKAS_DW.Delay_DSTATE_b = ((uint8)0U);

      /* SystemReset for Chart: '<S149>/LDW_State_Machine'
       *
       * Block description for '<S149>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S149>/LKA_and_ELK_State_Machine'
       *
       * Block description for '<S149>/LKA_and_ELK_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKA_and_ELK_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.DACMode = LKAS_DW.LKA_Mode;

    /* Gain: '<S293>/Gain' incorporates:
     *  Sum: '<S293>/Add'
     */
    rtb_crCrvt = (rtb_L0_C2_h + rtb_R0_C1_d) * 0.5F;

    /* Delay: '<S149>/Delay1' */
    rtb_DACMode = LKAS_DW.Delay1_1_DSTATE;
    rtb_EPS_Control = LKAS_DW.Delay1_4_DSTATE;

    /* Sum: '<S303>/Add1' incorporates:
     *  MATLAB Function: '<S301>/MATLABFunction3'
     */
    x20 = rtb_L0_C0_b + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S303>/Gain1' incorporates:
     *  Product: '<S303>/Divide'
     *  Product: '<S303>/Divide1'
     *  Sum: '<S303>/Add1'
     *  Sum: '<S303>/Add5'
     *  Trigonometry: '<S303>/Cos2'
     *  Trigonometry: '<S303>/Sin'
     */
    rtb_Gain1 = ((x20 * cosf(rtb_LL_CompHdAg_C)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_LL_CompHdAg_C))) * (-1.0F);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S147>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S295>/Gain1' incorporates:
     *  Gain: '<S191>/Gain'
     *  Gain: '<S237>/kph To mps'
     *  Gain: '<S251>/kph to mps'
     *  Gain: '<S252>/kph to mps'
     *  Gain: '<S301>/Gain2'
     *  Gain: '<S308>/kph to mps'
     *  Gain: '<S314>/kph to mps'
     *  Gain: '<S323>/kph to mps'
     *  Gain: '<S324>/kph to mps'
     */
    rtb_Abs_n_tmp = 0.277777791F * rtb_IMAPve_g_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S295>/Divide4' incorporates:
     *  Constant: '<S295>/Constant2'
     *  Constant: '<S295>/Constant3'
     *  Gain: '<S295>/Gain1'
     */
    rtb_Abs_h = (rtb_Abs_n_tmp * 2.0F) * 0.1F;

    /* Sum: '<S295>/Add3' incorporates:
     *  Product: '<S295>/Divide3'
     */
    rtb_phiHdAg_Lft = (rtb_L0_C2_h * rtb_Abs_h) + rtb_LL_CompHdAg_C;

    /* Sum: '<S304>/Add1' incorporates:
     *  MATLAB Function: '<S301>/MATLABFunction4'
     */
    rtb_Add5_k_tmp = rtb_R0_C0_a - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S304>/Add5' incorporates:
     *  Product: '<S304>/Divide'
     *  Product: '<S304>/Divide1'
     *  Sum: '<S304>/Add1'
     *  Trigonometry: '<S304>/Cos2'
     *  Trigonometry: '<S304>/Sin'
     */
    rtb_Add5_k = (rtb_Add5_k_tmp * cosf(rtb_L0_C1_fx)) + (rtb_LKA_Veh2CamL_C *
      sinf(rtb_L0_C1_fx));

    /* Sum: '<S295>/Add1' incorporates:
     *  Product: '<S295>/Divide5'
     */
    rtb_phiHdAg_Rgt = (rtb_R0_C1_d * rtb_Abs_h) + rtb_L0_C1_fx;

    /* Switch: '<S664>/Switch2' incorporates:
     *  Constant: '<S664>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_e != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_e;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S664>/Switch2' */

    /* Product: '<S308>/Divide' */
    rtb_Abs_h = rtb_Abs_n_tmp * x10;

    /* Gain: '<S305>/Gain' incorporates:
     *  Gain: '<S320>/Gain'
     *  Gain: '<S321>/Gain'
     *  Gain: '<S322>/Gain'
     */
    rtb_Add_e1_tmp = 2.0F * rtb_L0_C2_h;

    /* Sum: '<S305>/Add' incorporates:
     *  Gain: '<S305>/Gain'
     *  Gain: '<S305>/Gain1'
     *  Product: '<S305>/Product'
     */
    rtb_Add_e1 = ((6.0F * rtb_L0_C3_g) * rtb_Abs_h) + rtb_Add_e1_tmp;

    /* Gain: '<S306>/Gain' incorporates:
     *  Gain: '<S317>/Gain'
     *  Gain: '<S318>/Gain'
     *  Gain: '<S319>/Gain'
     */
    rtb_Add_g_tmp = 2.0F * rtb_R0_C1_d;

    /* Sum: '<S306>/Add' incorporates:
     *  Gain: '<S306>/Gain'
     *  Gain: '<S306>/Gain1'
     *  Product: '<S306>/Product'
     */
    rtb_Add_g = ((6.0F * rtb_R0_C3_j) * rtb_Abs_h) + rtb_Add_g_tmp;

    /* Product: '<S295>/Divide1' incorporates:
     *  Gain: '<S295>/Gain1'
     */
    rtb_Abs_h = rtb_phiHdAg_Lft * rtb_Abs_n_tmp;

    /* Saturate: '<S301>/Saturation2' incorporates:
     *  UnaryMinus: '<S301>/Unary Minus1'
     */
    if ((-rtb_Abs_h) > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else if ((-rtb_Abs_h) < (-2.0F)) {
      rtb_LKA_Veh2CamL_C = (-2.0F);
    } else {
      rtb_LKA_Veh2CamL_C = -rtb_Abs_h;
    }

    /* End of Saturate: '<S301>/Saturation2' */

    /* MATLAB Function: '<S301>/MATLABFunction' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction': '<S332>:1' */
    /* '<S332>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1 > 0.0F) && (rtb_Gain1 < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S332>:1:3' TTLC = -dvt/vy; */
      rtb_TTLC_i = (-rtb_Gain1) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S332>:1:4' else */
      /* '<S332>:1:5' TTLC = single(3); */
      rtb_TTLC_i = 3.0F;
    }

    /* End of MATLAB Function: '<S301>/MATLABFunction' */

    /* Saturate: '<S301>/Saturation' */
    if (rtb_TTLC_i > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_TTLC_i < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_TTLC_i;
    }

    /* End of Saturate: '<S301>/Saturation' */

    /* Product: '<S295>/Divide2' incorporates:
     *  Gain: '<S295>/Gain1'
     */
    rtb_Abs_l = rtb_phiHdAg_Rgt * rtb_Abs_n_tmp;

    /* Saturate: '<S301>/Saturation3' */
    if (rtb_Abs_l > 2.0F) {
      rtb_TTLC_i = 2.0F;
    } else if (rtb_Abs_l < (-2.0F)) {
      rtb_TTLC_i = (-2.0F);
    } else {
      rtb_TTLC_i = rtb_Abs_l;
    }

    /* End of Saturate: '<S301>/Saturation3' */

    /* MATLAB Function: '<S301>/MATLABFunction1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction1': '<S333>:1' */
    /* '<S333>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_k > 0.0F) && (rtb_Add5_k < 2.0F)) && (rtb_TTLC_i < 0.0F)) &&
        (rtb_TTLC_i > -1.5F)) {
      /* '<S333>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_h = (-rtb_Add5_k) / rtb_TTLC_i;
    } else {
      /* '<S333>:1:4' else */
      /* '<S333>:1:5' TTLC = single(3); */
      rtb_TTLC_h = 3.0F;
    }

    /* End of MATLAB Function: '<S301>/MATLABFunction1' */

    /* Saturate: '<S301>/Saturation1' */
    if (rtb_TTLC_h > 2.0F) {
      rtb_TTLC_h = 2.0F;
    } else {
      if (rtb_TTLC_h < 0.6F) {
        rtb_TTLC_h = 0.6F;
      }
    }

    /* End of Saturate: '<S301>/Saturation1' */

    /* MATLAB Function: '<S301>/MATLABFunction5' incorporates:
     *  Gain: '<S331>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction5': '<S337>:1' */
    /* '<S337>:1:2' K = 0.09/vx; */
    /* '<S337>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_SW_Angle) / (((((((0.09F / rtb_Abs_n_tmp) *
      rtb_Abs_n_tmp) * rtb_Abs_n_tmp) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_j) *
      LKAS_DW.LKA_StrRatio_C_a) * 2.0F);

    /* MATLAB Function: '<S301>/MATLABFunction3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction3': '<S335>:1' */
    /* '<S335>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2_h - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_LL_CompHdAg_C > 0.0F) || (rtb_LL_CompHdAg_C <
          0.0F))) {
      /* '<S335>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_b) - rtb_LKA_Veh2CamW_C) / rtb_LL_CompHdAg_C;
      if (x10 > 0.0F) {
        /* '<S335>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_Abs_n_tmp;
      } else {
        /* '<S335>:1:9' else */
        /* '<S335>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_LL_CompHdAg_C * rtb_LL_CompHdAg_C) - ((x10 * 4.0F) * x20);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S335>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S335>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_LL_CompHdAg_C)) / x1;

        /* '<S335>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_LL_CompHdAg_C) - x20) / x1;

        /* '<S335>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S335>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S335>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S335>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_Abs_n_tmp;
        } else if (x1 > 0.0F) {
          /* '<S335>:1:19' elseif x1>0 */
          /* '<S335>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_Abs_n_tmp;
        } else {
          /* '<S335>:1:21' else */
          /* '<S335>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S335>:1:24' else */
        /* '<S335>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S335>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S301>/MATLABFunction4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction4': '<S336>:1' */
    /* '<S336>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_R0_C1_d - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_fx > 0.0F) || (rtb_L0_C1_fx < 0.0F))) {
      /* '<S336>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_R0_C0_a) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1_fx;
      if (x10 > 0.0F) {
        /* '<S336>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_n_tmp;
      } else {
        /* '<S336>:1:9' else */
        /* '<S336>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_fx * rtb_L0_C1_fx) - ((x10 * 4.0F) * rtb_Add5_k_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S336>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S336>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_fx)) / x1;

        /* '<S336>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_fx) - x20) / x1;

        /* '<S336>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S336>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S336>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S336>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_n_tmp;
        } else if (x1 > 0.0F) {
          /* '<S336>:1:19' elseif x1>0 */
          /* '<S336>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_Abs_n_tmp;
        } else {
          /* '<S336>:1:21' else */
          /* '<S336>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S336>:1:24' else */
        /* '<S336>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S336>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S301>/MATLABFunction2' incorporates:
     *  Constant: '<S301>/Constant'
     *  Constant: '<S301>/Constant1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction2': '<S334>:1' */
    /* '<S334>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - 2.0F) / rtb_LftTTLC) <= 0.2F) {
      /* '<S334>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, 2.0F);
    } else {
      /* '<S334>:1:4' else */
      /* '<S334>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S334>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_h - 2.0F) / rtb_TTLC_h) <= 0.2F) {
      /* '<S334>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_h = fminf(rtb_TTLC_h, 2.0F);
    } else {
      /* '<S334>:1:10' else */
      /* '<S334>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S334>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_e1) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S334>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S334>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_g) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_h)
           / rtb_TTLC_h) <= 0.7F)) && (rtb_TTLC_h <= 1.95F)) {
      /* '<S334>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_h = (rtb_TTLC_h + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S301>/Saturation7' incorporates:
     *  MATLAB Function: '<S301>/MATLABFunction2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S301>/Saturation7' */

    /* Saturate: '<S301>/Saturation8' incorporates:
     *  MATLAB Function: '<S301>/MATLABFunction2'
     */
    if (rtb_TTLC_h > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_h < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_h;
    }

    /* End of Saturate: '<S301>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S147>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S156>/Subsystem' incorporates:
     *  EnablePort: '<S165>/Enable'
     */
    /* Abs: '<S296>/Abs' incorporates:
     *  MATLAB Function: '<S165>/DriverSwaTrqAdd'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_L0_C0_b);

    /* Abs: '<S296>/Abs1' incorporates:
     *  MATLAB Function: '<S165>/DriverSwaTrqAdd'
     */
    rtb_Add5_k_tmp = fabsf(rtb_R0_C0_a);

    /* End of Outputs for SubSystem: '<S156>/Subsystem' */
    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Sum: '<S296>/Add' incorporates:
     *  Abs: '<S296>/Abs'
     *  Abs: '<S296>/Abs1'
     */
    rtb_LftTTLC = rtb_LKA_Veh2CamW_C + rtb_Add5_k_tmp;

    /* Saturate: '<S296>/Saturation' */
    if (rtb_LftTTLC > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_LftTTLC < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_LftTTLC;
    }

    /* End of Saturate: '<S296>/Saturation' */

    /* If: '<S307>/If' incorporates:
     *  Delay: '<S148>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE_c) == 1) {
      /* Outputs for IfAction SubSystem: '<S307>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S310>/Action Port'
       */
      LKAS_IfActionSubsystem2_p(rtb_Add_e1, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S307>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE_c) == 2) {
      /* Outputs for IfAction SubSystem: '<S307>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S309>/Action Port'
       */
      LKAS_IfActionSubsystem2_p(rtb_Add_g, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S307>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S307>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S311>/Action Port'
       */
      /* Gain: '<S311>/Gain' incorporates:
       *  Sum: '<S311>/Add'
       */
      rtb_Merge = (rtb_Add_e1 + rtb_Add_g) * 0.5F;

      /* End of Outputs for SubSystem: '<S307>/If Action Subsystem3' */
    }

    /* End of If: '<S307>/If' */

    /* Switch: '<S591>/Switch' incorporates:
     *  Constant: '<S668>/Constant'
     *  Constant: '<S669>/Constant'
     *  Gain: '<S668>/Gain'
     *  Gain: '<S669>/Gain'
     *  Sum: '<S668>/Add'
     *  Sum: '<S669>/Add'
     *  Switch: '<S665>/Switch47'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S665>/Switch48' incorporates:
       *  Constant: '<S665>/LLSMConClb3'
       *
       * Block description for '<S665>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S665>/Switch48' */
      rtb_Switch_a = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S665>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S665>/Switch47' incorporates:
         *  Constant: '<S665>/LLSMConClb2'
         *
         * Block description for '<S665>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_a = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S591>/Switch' */

    /* Switch: '<S589>/Switch' incorporates:
     *  Constant: '<S589>/Constant'
     *  Constant: '<S589>/Constant1'
     *  Constant: '<S594>/Constant'
     *  Constant: '<S595>/Constant'
     *  Constant: '<S596>/Constant'
     *  Logic: '<S589>/Logical Operator'
     *  RelationalOperator: '<S594>/Compare'
     *  RelationalOperator: '<S595>/Compare'
     *  RelationalOperator: '<S596>/Compare'
     */
    if (((rtb_IMAPve_d_Rrg_TYPE_BACK >= ((uint8)3U)) || (((sint32)
           (rtb_BCM_Left_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) ||
        (((sint32)(rtb_BCM_Right_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S589>/Switch' */

    /* Sum: '<S589>/Add' incorporates:
     *  Memory: '<S589>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_bk;

    /* Saturate: '<S589>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_h = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_h = (-1.0F);
    } else {
      rtb_Saturation_h = rtb_LftTTLC;
    }

    /* End of Saturate: '<S589>/Saturation' */

    /* Abs: '<S583>/Abs1' incorporates:
     *  Abs: '<S488>/Abs1'
     */
    rtb_TLft = fabsf(rtb_LaneWidth);
    rtb_Abs1 = rtb_TLft;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S147>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S581>/Abs' incorporates:
     *  Abs: '<S176>/Abs'
     *  Abs: '<S177>/Abs'
     *  Abs: '<S178>/Abs4'
     *  Abs: '<S486>/Abs'
     *  MATLAB Function: '<S453>/MATLAB Function'
     */
    rtb_TTLC_h = fabsf(rtb_Merge);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC_h;

    /* Switch: '<S665>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S542>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S542>/Unary Minus' incorporates:
       *  Constant: '<S665>/LLSMConClb11'
       *
       * Block description for '<S665>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S665>/Switch53' */

    /* Switch: '<S665>/Switch87' incorporates:
     *  Constant: '<S665>/LLSMConClb8'
     *
     * Block description for '<S665>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S665>/Switch87' */

    /* Switch: '<S665>/Switch49' incorporates:
     *  Constant: '<S665>/LLSMConClb43'
     *
     * Block description for '<S665>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S665>/Switch49' */

    /* Switch: '<S665>/Switch88' incorporates:
     *  Constant: '<S665>/LLSMConClb9'
     *
     * Block description for '<S665>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_LftTTLC = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S665>/Switch88' */

    /* Switch: '<S665>/Switch50' incorporates:
     *  Constant: '<S665>/LLSMConClb10'
     *
     * Block description for '<S665>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      tmp = LKAS_ConstB.DataTypeConversion17;
    } else {
      tmp = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S665>/Switch50' */

    /* Abs: '<S579>/Abs' incorporates:
     *  Abs: '<S484>/Abs'
     *  Sum: '<S579>/Add'
     */
    x1 = fabsf(rtb_LL_CompHdAg_C - rtb_L0_C1_fx);

    /* Abs: '<S542>/Abs2' incorporates:
     *  Abs: '<S326>/Abs2'
     *  Abs: '<S451>/Abs2'
     */
    rtb_TTLC = fabsf(rtb_SW_Angle);

    /* Abs: '<S542>/Abs3' incorporates:
     *  Abs: '<S451>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     */
    rtb_LogicalOperator3_h_tmp = fabsf(rtb_ThresDet_coefficient_l);

    /* Abs: '<S542>/Abs4' incorporates:
     *  Abs: '<S451>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     */
    rtb_Saturation_ae = fabsf(rtb_Saturation_ae);

    /* Abs: '<S542>/Abs1' incorporates:
     *  Abs: '<S452>/Abs'
     *  Abs: '<S453>/Abs'
     */
    rtb_ThresDet_coefficient_l = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S543>/Logical Operator2' incorporates:
     *  Abs: '<S542>/Abs1'
     *  Abs: '<S542>/Abs2'
     *  Abs: '<S542>/Abs3'
     *  Abs: '<S542>/Abs4'
     *  Abs: '<S579>/Abs'
     *  Constant: '<S581>/Constant'
     *  Constant: '<S584>/Constant'
     *  Constant: '<S586>/Constant'
     *  Constant: '<S587>/Constant'
     *  Constant: '<S593>/Constant'
     *  Constant: '<S597>/Constant'
     *  Logic: '<S542>/Logical Operator3'
     *  Logic: '<S548>/FixPt Logical Operator'
     *  Logic: '<S580>/Logical Operator3'
     *  Logic: '<S582>/Logical Operator'
     *  Logic: '<S585>/FixPt Logical Operator'
     *  Logic: '<S588>/FixPt Logical Operator'
     *  Logic: '<S592>/Logical Operator'
     *  Logic: '<S598>/FixPt Logical Operator'
     *  RelationalOperator: '<S542>/Relational Operator'
     *  RelationalOperator: '<S542>/Relational Operator1'
     *  RelationalOperator: '<S542>/Relational Operator2'
     *  RelationalOperator: '<S542>/Relational Operator3'
     *  RelationalOperator: '<S548>/Lower Test'
     *  RelationalOperator: '<S548>/Upper Test'
     *  RelationalOperator: '<S584>/Compare'
     *  RelationalOperator: '<S585>/Lower Test'
     *  RelationalOperator: '<S585>/Upper Test'
     *  RelationalOperator: '<S586>/Compare'
     *  RelationalOperator: '<S587>/Compare'
     *  RelationalOperator: '<S588>/Lower Test'
     *  RelationalOperator: '<S588>/Upper Test'
     *  RelationalOperator: '<S593>/Compare'
     *  RelationalOperator: '<S597>/Compare'
     *  RelationalOperator: '<S598>/Lower Test'
     *  RelationalOperator: '<S598>/Upper Test'
     *  Switch: '<S116>/Switch'
     *  Switch: '<S116>/Switch1'
     */
    rtb_LogicalOperator3_b = ((((((rtb_Gain_h <= rtb_IMAPve_g_ESC_VehSpd) &&
      (rtb_IMAPve_g_ESC_VehSpd <= rtb_Switch_a)) && (rtb_Saturation_h <= 0.0F)) &&
      (rtb_TCU_ActualGear == ((uint8)3U))) && (((((rtb_L0_Q > ((uint8)2U)) &&
      (rtb_R0_Q > ((uint8)2U))) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) &&
      (rtb_Abs1 <= rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) &&
      (rtb_Abs <= rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) && (x1 <= 0.025F))) &&
      (((((rtb_TTLC < x10) && (rtb_LogicalOperator3_h_tmp < x20)) &&
         (rtb_ThresDet_coefficient_l < rtb_LftTTLC)) && (rtb_Saturation_ae < tmp))
       && ((rtb_UnaryMinus < rtb_IMAPve_g_ESC_LonAcc) &&
           (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* MATLAB Function: '<S576>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_LKA_EarliestWarnLine_C, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient);

    /* Product: '<S576>/Multiply' */
    rtb_Multiply = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_ThresDet_coefficient;

    /* Switch: '<S578>/Switch' incorporates:
     *  Constant: '<S576>/Constant'
     *  RelationalOperator: '<S578>/UpperRelop'
     */
    if (rtb_Multiply < 0.0F) {
      rtb_Switch_ak = 0.0F;
    } else {
      rtb_Switch_ak = rtb_Multiply;
    }

    /* End of Switch: '<S578>/Switch' */

    /* Switch: '<S578>/Switch2' incorporates:
     *  RelationalOperator: '<S578>/LowerRelop1'
     */
    if (rtb_Multiply > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_e = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_e = rtb_Switch_ak;
    }

    /* End of Switch: '<S578>/Switch2' */

    /* Abs: '<S563>/Abs1' incorporates:
     *  Abs: '<S474>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S563>/Abs2' incorporates:
     *  Abs: '<S474>/Abs1'
     */
    x20 = fabsf(rtb_TTLC_i);

    /* If: '<S543>/If1' incorporates:
     *  Abs: '<S563>/Abs1'
     *  Abs: '<S563>/Abs2'
     *  Constant: '<S550>/Constant'
     *  Constant: '<S565>/Constant'
     *  Constant: '<S566>/Constant'
     *  Constant: '<S571>/Constant'
     *  Constant: '<S572>/Constant'
     *  Constant: '<S573>/Constant'
     *  Constant: '<S574>/Constant'
     *  DataTypeConversion: '<S543>/Cast To Single'
     *  Logic: '<S543>/Logical Operator1'
     *  Logic: '<S560>/Logical Operator'
     *  Logic: '<S562>/Logical Operator'
     *  Logic: '<S563>/Logical Operator'
     *  Logic: '<S564>/Logical Operator'
     *  RelationalOperator: '<S563>/Relational Operator2'
     *  RelationalOperator: '<S563>/Relational Operator3'
     *  RelationalOperator: '<S564>/Relational Operator1'
     *  RelationalOperator: '<S564>/Relational Operator2'
     *  RelationalOperator: '<S565>/Compare'
     *  RelationalOperator: '<S566>/Compare'
     *  RelationalOperator: '<S571>/Compare'
     *  RelationalOperator: '<S572>/Compare'
     *  RelationalOperator: '<S573>/Compare'
     *  RelationalOperator: '<S574>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_LogicalOperator3_b &&
         ((((LKAS_DW.LKA_Mode == ((uint8)2U)) && (((sint32)
              (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
                (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) ? 1 : 0)) ==
             ((sint32)(true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1 >= rtb_Switch2_e) &&
              (rtb_Add5_k >= rtb_Switch2_e)) ? 1 : 0)) == ((sint32)(true ? 1 : 0))))))
    {
      /* Outputs for IfAction SubSystem: '<S543>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S550>/Action Port'
       */
      LKAS_DW.Merge1_e = true;

      /* End of Outputs for SubSystem: '<S543>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S543>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S552>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_e);

      /* End of Outputs for SubSystem: '<S543>/If Action Subsystem4' */
    }

    /* End of If: '<S543>/If1' */

    /* Switch: '<S534>/Switch' incorporates:
     *  Constant: '<S666>/Constant'
     *  Constant: '<S671>/Constant'
     *  Gain: '<S666>/Gain'
     *  Gain: '<S671>/Gain'
     *  Sum: '<S666>/Add'
     *  Sum: '<S671>/Add'
     *  Switch: '<S665>/Switch67'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S665>/Switch80' incorporates:
       *  Constant: '<S665>/LLSMConClb21'
       *
       * Block description for '<S665>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_LftTTLC = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S665>/Switch80' */
      rtb_Switch_f = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S665>/Switch67' */
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S665>/Switch67' incorporates:
         *  Constant: '<S665>/LLSMConClb20'
         *
         * Block description for '<S665>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_LftTTLC = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_f = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S534>/Switch' */

    /* Logic: '<S534>/Logical Operator' incorporates:
     *  Logic: '<S541>/FixPt Logical Operator'
     *  RelationalOperator: '<S541>/Lower Test'
     *  RelationalOperator: '<S541>/Upper Test'
     */
    rtb_LKA_Main_Switch = ((rtb_Gain_f >= rtb_IMAPve_g_ESC_VehSpd) ||
      (rtb_IMAPve_g_ESC_VehSpd >= rtb_Switch_f));

    /* Logic: '<S532>/Logical Operator' incorporates:
     *  Logic: '<S354>/Logical Operator6'
     */
    rtb_RelationalOperator_kw_tmp = !rtb_LL_SingleLane_Disable_Swt;

    /* Switch: '<S532>/Switch' incorporates:
     *  Constant: '<S532>/Constant'
     *  Constant: '<S532>/Constant1'
     *  Constant: '<S537>/Constant'
     *  Constant: '<S538>/Constant'
     *  Constant: '<S539>/Constant'
     *  Delay: '<S149>/Delay1'
     *  Logic: '<S532>/Logical Operator'
     *  Logic: '<S532>/Logical Operator1'
     *  Logic: '<S532>/Logical Operator2'
     *  Logic: '<S532>/Logical Operator3'
     *  Logic: '<S532>/Logical Operator4'
     *  Logic: '<S532>/Logical Operator5'
     *  RelationalOperator: '<S537>/Compare'
     *  RelationalOperator: '<S538>/Compare'
     *  RelationalOperator: '<S539>/Compare'
     */
    if (((((rtb_IMAPve_d_Rrg_TYPE_BACK >= ((uint8)3U)) || (rtb_BCM_Left_Light &&
            rtb_RelationalOperator_kw_tmp)) || (rtb_BCM_Right_Light &&
           rtb_RelationalOperator_kw_tmp)) || (rtb_BCM_Left_Light &&
          (LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)))) || (rtb_BCM_Right_Light &&
         (LKAS_DW.Delay1_3_DSTATE == ((uint8)5U)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S532>/Switch' */

    /* Sum: '<S532>/Add' incorporates:
     *  Memory: '<S532>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_bl;

    /* Saturate: '<S532>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_hz = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_hz = (-1.0F);
    } else {
      rtb_Saturation_hz = rtb_LftTTLC;
    }

    /* End of Saturate: '<S532>/Saturation' */

    /* RelationalOperator: '<S536>/Compare' incorporates:
     *  Constant: '<S536>/Constant'
     */
    rtb_LL_SingleLane_Disable_Swt = (rtb_Saturation_hz > 1.0F);

    /* RelationalOperator: '<S540>/Compare' incorporates:
     *  Constant: '<S540>/Constant'
     */
    rtb_Compare_m2 = (rtb_TCU_ActualGear != ((uint8)3U));

    /* Logic: '<S487>/Logical Operator' incorporates:
     *  Constant: '<S491>/Constant'
     *  Constant: '<S492>/Constant'
     *  RelationalOperator: '<S491>/Compare'
     *  RelationalOperator: '<S492>/Compare'
     *  Switch: '<S116>/Switch'
     *  Switch: '<S116>/Switch1'
     */
    rtb_LogicalOperator_ax = ((rtb_L0_Q < ((uint8)3U)) && (rtb_R0_Q < ((uint8)3U)));

    /* Abs: '<S488>/Abs1' */
    rtb_Abs1_o = rtb_TLft;

    /* RelationalOperator: '<S493>/Compare' incorporates:
     *  Constant: '<S493>/Constant'
     *  Logic: '<S494>/FixPt Logical Operator'
     *  RelationalOperator: '<S494>/Lower Test'
     *  RelationalOperator: '<S494>/Upper Test'
     */
    rtb_Compare_ag2 = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_o) &&
      (rtb_Abs1_o <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S486>/Abs' */
    rtb_Abs_i = rtb_TTLC_h;

    /* Logic: '<S486>/Logical Operator' incorporates:
     *  Constant: '<S486>/Constant'
     *  Logic: '<S490>/FixPt Logical Operator'
     *  RelationalOperator: '<S490>/Lower Test'
     *  RelationalOperator: '<S490>/Upper Test'
     */
    rtb_LogicalOperator_nl = ((0.0F > rtb_Abs_i) || (rtb_Abs_i >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S489>/Compare' incorporates:
     *  Constant: '<S489>/Constant'
     */
    rtb_Compare_b5 = (x1 > 0.04F);

    /* Switch: '<S665>/Switch72' incorporates:
     *  Constant: '<S665>/LLSMConClb26'
     *
     * Block description for '<S665>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S665>/Switch72' */

    /* RelationalOperator: '<S451>/Relational Operator1' */
    rtb_phiSWA_Thres = (rtb_TTLC >= rtb_LftTTLC);

    /* Switch: '<S665>/Switch74' incorporates:
     *  Constant: '<S665>/LLSMConClb28'
     *
     * Block description for '<S665>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S665>/Switch74' */

    /* RelationalOperator: '<S451>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_LogicalOperator3_h_tmp >= rtb_LftTTLC);

    /* Switch: '<S665>/Switch79' incorporates:
     *  Constant: '<S665>/LLSMConClb29'
     *
     * Block description for '<S665>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_LftTTLC = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S665>/Switch79' */

    /* Logic: '<S451>/Logical Operator1' incorporates:
     *  Constant: '<S454>/Constant'
     *  RelationalOperator: '<S451>/Relational Operator3'
     *  RelationalOperator: '<S454>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_Saturation_ae >= rtb_LftTTLC) &&
                       (rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)));

    /* Switch: '<S665>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S451>/Unary Minus' */
      rtb_UnaryMinus_e = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S451>/Unary Minus' incorporates:
       *  Constant: '<S665>/LLSMConClb30'
       *
       * Block description for '<S665>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_e = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S665>/Switch61' */

    /* RelationalOperator: '<S455>/Compare' incorporates:
     *  Constant: '<S455>/Constant'
     *  Logic: '<S456>/FixPt Logical Operator'
     *  RelationalOperator: '<S456>/Lower Test'
     *  RelationalOperator: '<S456>/Upper Test'
     */
    rtb_Compare_pu = (((sint32)(((rtb_UnaryMinus_e < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                      ((sint32)(false ? 1 : 0)));

    /* Switch: '<S452>/Switch' incorporates:
     *  Constant: '<S457>/Constant'
     *  Constant: '<S665>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
     *  RelationalOperator: '<S457>/Compare'
     *  Switch: '<S665>/Switch38'
     *
     * Block description for '<S665>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
     *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      /* Switch: '<S665>/Switch44' incorporates:
       *  Constant: '<S665>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
       *
       * Block description for '<S665>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
       *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
       */
      if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
        rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion8;
      } else {
        rtb_LKA_Veh2CamL_C = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
      }

      /* End of Switch: '<S665>/Switch44' */
    } else if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
      /* Switch: '<S665>/Switch38' */
      rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion6;
    } else {
      rtb_LKA_Veh2CamL_C = LL_RlsDet_tiTrqChkT_DISABLE;
    }

    /* End of Switch: '<S452>/Switch' */

    /* Outputs for Enabled SubSystem: '<S452>/ExitCount' incorporates:
     *  EnablePort: '<S460>/Enable'
     */
    /* RelationalOperator: '<S452>/Relational Operator' */
    if (rtb_ThresDet_coefficient_l <= rtb_LKA_Veh2CamL_C) {
      if (!LKAS_DW.ExitCount_MODE) {
        /* InitializeConditions for Memory: '<S460>/Memory' */
        LKAS_DW.Memory_PreviousInput_a = 0.0F;
        LKAS_DW.ExitCount_MODE = true;
      }

      /* Sum: '<S460>/Add' incorporates:
       *  Constant: '<S458>/Constant'
       *  Constant: '<S459>/Constant'
       *  Logic: '<S452>/Logical Operator2'
       *  Memory: '<S460>/Memory'
       *  Product: '<S452>/Divide'
       *  RelationalOperator: '<S458>/Compare'
       *  RelationalOperator: '<S459>/Compare'
       */
      rtb_Saturation_ae = (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
                            (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ?
                           rtb_LKA_SampleTime : 0.0F) +
        LKAS_DW.Memory_PreviousInput_a;

      /* Saturate: '<S460>/Saturation' */
      if (rtb_Saturation_ae > 60.0F) {
        rtb_Saturation_ae = 60.0F;
      } else {
        if (rtb_Saturation_ae < 0.0F) {
          rtb_Saturation_ae = 0.0F;
        }
      }

      /* End of Saturate: '<S460>/Saturation' */

      /* Switch: '<S665>/Switch3' incorporates:
       *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=3'
       *
       * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=3':
       *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
       */
      if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion3;
      } else {
        rtb_LftTTLC = LL_HandsOff_ExitTime;
      }

      /* End of Switch: '<S665>/Switch3' */

      /* RelationalOperator: '<S460>/Relational Operator' */
      LKAS_DW.RelationalOperator_d = (rtb_Saturation_ae >= rtb_LftTTLC);

      /* Update for Memory: '<S460>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = rtb_Saturation_ae;
    } else {
      if (LKAS_DW.ExitCount_MODE) {
        /* Disable for Outport: '<S460>/Out' */
        LKAS_DW.RelationalOperator_d = false;
        LKAS_DW.ExitCount_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S452>/Relational Operator' */
    /* End of Outputs for SubSystem: '<S452>/ExitCount' */

    /* Saturate: '<S453>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S461>:1' */
    /* '<S461>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S461>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S461>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S461>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_IMAPve_g_ESC_VehSpd > 80.0F) {
      rtb_LftTTLC = 80.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      rtb_LftTTLC = 60.0F;
    } else {
      rtb_LftTTLC = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S453>/Saturation' */

    /* MATLAB Function: '<S453>/MATLAB Function' */
    if (rtb_ThresDet_coefficient_l >= fminf(fmaxf(1.5F, ((1.5F *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL) - ((rtb_LftTTLC / 180.0F) *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL)) + (rtb_TTLC_h / 0.005F)), 2.75F))
    {
      /* Outputs for Enabled SubSystem: '<S453>/Sum Condition1' incorporates:
       *  EnablePort: '<S462>/state = reset'
       */
      /* '<S461>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_d) {
        /* InitializeConditions for Memory: '<S462>/Memory' */
        LKAS_DW.Memory_PreviousInput_d = 0.0F;
        LKAS_DW.SumCondition1_MODE_d = true;
      }

      /* Sum: '<S462>/Add1' incorporates:
       *  Memory: '<S462>/Memory'
       */
      rtb_Saturation_ae = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_d;

      /* Saturate: '<S462>/Saturation' */
      if (rtb_Saturation_ae > 5000.0F) {
        rtb_Saturation_ae = 5000.0F;
      } else {
        if (rtb_Saturation_ae < 0.0F) {
          rtb_Saturation_ae = 0.0F;
        }
      }

      /* End of Saturate: '<S462>/Saturation' */
      /* End of Outputs for SubSystem: '<S453>/Sum Condition1' */

      /* Switch: '<S665>/Switch65' incorporates:
       *  Constant: '<S665>/LLSMConClb34'
       *
       * Block description for '<S665>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_LftTTLC = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S665>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S453>/Sum Condition1' incorporates:
       *  EnablePort: '<S462>/state = reset'
       */
      /* RelationalOperator: '<S462>/Relational Operator' */
      LKAS_DW.RelationalOperator_b = (rtb_Saturation_ae >= rtb_LftTTLC);

      /* Update for Memory: '<S462>/Memory' */
      LKAS_DW.Memory_PreviousInput_d = rtb_Saturation_ae;

      /* End of Outputs for SubSystem: '<S453>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S453>/Sum Condition1' incorporates:
       *  EnablePort: '<S462>/state = reset'
       */
      /* '<S461>:1:7' else */
      /* '<S461>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_d) {
        /* Disable for Outport: '<S462>/Out' */
        LKAS_DW.RelationalOperator_b = false;
        LKAS_DW.SumCondition1_MODE_d = false;
      }

      /* End of Outputs for SubSystem: '<S453>/Sum Condition1' */
    }

    /* RelationalOperator: '<S468>/Compare' incorporates:
     *  Constant: '<S468>/Constant'
     */
    rtb_Compare_mo = (((sint32)(LKAS_DW.RelationalOperator_b ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S463>/Unit Delay' */
    rtb_UnitDelay_p = LKAS_DW.UnitDelay_DSTATE_c;

    /* If: '<S463>/If' incorporates:
     *  Constant: '<S465>/Constant'
     *  RelationalOperator: '<S464>/FixPt Relational Operator'
     *  UnitDelay: '<S464>/Delay Input1'
     *
     * Block description for '<S464>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if (((sint32)(rtb_Compare_mo ? 1 : 0)) > ((sint32)
         (LKAS_DW.DelayInput1_DSTATE ? 1 : 0))) {
      /* Outputs for IfAction SubSystem: '<S463>/If Action Subsystem' incorporates:
       *  ActionPort: '<S465>/Action Port'
       */
      rtb_Merge_h = true;

      /* End of Outputs for SubSystem: '<S463>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S463>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S466>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_p, &rtb_Merge_h);

      /* End of Outputs for SubSystem: '<S463>/If Action Subsystem3' */
    }

    /* End of If: '<S463>/If' */

    /* Outputs for Enabled SubSystem: '<S463>/Sum Condition1' incorporates:
     *  EnablePort: '<S467>/state = reset'
     */
    if (rtb_Merge_h) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S467>/Memory' */
        LKAS_DW.Memory_PreviousInput_or = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S467>/Add1' incorporates:
       *  Memory: '<S467>/Memory'
       */
      rtb_Saturation_ae = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_or;

      /* Saturate: '<S467>/Saturation' */
      if (rtb_Saturation_ae > 10.0F) {
        rtb_Saturation_ae = 10.0F;
      } else {
        if (rtb_Saturation_ae < 0.0F) {
          rtb_Saturation_ae = 0.0F;
        }
      }

      /* End of Saturate: '<S467>/Saturation' */

      /* RelationalOperator: '<S467>/Relational Operator' */
      LKAS_DW.RelationalOperator_o = (rtb_Saturation_ae <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S467>/Memory' */
      LKAS_DW.Memory_PreviousInput_or = rtb_Saturation_ae;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S467>/Out' */
        LKAS_DW.RelationalOperator_o = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S463>/Sum Condition1' */

    /* Logic: '<S463>/Logical Operator' */
    rtb_RelationalOperator_p = ((LKAS_DW.RelationalOperator_b) ||
      (LKAS_DW.RelationalOperator_o));

    /* Logic: '<S437>/Logical Operator2' incorporates:
     *  Logic: '<S450>/Logical Operator1'
     *  Logic: '<S451>/Logical Operator'
     *  Logic: '<S485>/Logical Operator3'
     *  Logic: '<S535>/Logical Operator3'
     */
    rtb_RelationalOperator_j = ((((rtb_LKA_Main_Switch ||
      rtb_LL_SingleLane_Disable_Swt) || rtb_Compare_m2) ||
      (((rtb_LogicalOperator_ax || rtb_Compare_ag2) || rtb_LogicalOperator_nl) ||
       rtb_Compare_b5)) || (((((rtb_phiSWA_Thres || rtb_dphiSWARate_Thres) ||
      rtb_aLAcc_Thres) || rtb_Compare_pu) || (LKAS_DW.RelationalOperator_d)) ||
      rtb_RelationalOperator_p));

    /* Logic: '<S474>/Logical Operator' incorporates:
     *  RelationalOperator: '<S474>/Relational Operator1'
     *  RelationalOperator: '<S474>/Relational Operator2'
     */
    rtb_LogicalOperator_o5 = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S475>/Logical Operator' incorporates:
     *  RelationalOperator: '<S475>/Relational Operator1'
     *  RelationalOperator: '<S475>/Relational Operator2'
     */
    rtb_LogicalOperator_ps = ((rtb_Gain1 <= rtb_LL_LKA_LatestWarnLine_C) ||
      (rtb_Add5_k <= rtb_LL_LKA_LatestWarnLine_C));

    /* If: '<S437>/If2' incorporates:
     *  Constant: '<S446>/Constant'
     *  Constant: '<S480>/Constant'
     *  Constant: '<S481>/Constant'
     *  Constant: '<S483>/Constant'
     *  DataTypeConversion: '<S437>/Cast To Single'
     *  Logic: '<S437>/Logical Operator1'
     *  Logic: '<S473>/Logical Operator'
     *  Logic: '<S473>/Logical Operator1'
     *  RelationalOperator: '<S480>/Compare'
     *  RelationalOperator: '<S481>/Compare'
     *  RelationalOperator: '<S483>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_RelationalOperator_j ||
         ((LKAS_DW.LKA_Mode == ((uint8)2U)) && ((rtb_LogicalOperator_o5 == true)
           || (rtb_LogicalOperator_ps == true))))) {
      /* Outputs for IfAction SubSystem: '<S437>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S446>/Action Port'
       */
      LKAS_DW.Merge2_n = true;

      /* End of Outputs for SubSystem: '<S437>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S437>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S448>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2_n);

      /* End of Outputs for SubSystem: '<S437>/If Action Subsystem3' */
    }

    /* End of If: '<S437>/If2' */

    /* If: '<S374>/If' */
    if ((rtb_Abs_h >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_l >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S374>/Ph1SWA' incorporates:
       *  ActionPort: '<S378>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S374>/Ph1SWA' */
    } else if ((rtb_Abs_h <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_l <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S374>/Ph2SWA' incorporates:
       *  ActionPort: '<S379>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S374>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S374>/Ph3SWA' incorporates:
       *  ActionPort: '<S380>/Action Port'
       */
      LKAS_Ph3SWA_b(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S374>/Ph3SWA' */
    }

    /* End of If: '<S374>/If' */

    /* Saturate: '<S352>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_Saturation_ae = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_Saturation_ae = (-2.0F);
    } else {
      rtb_Saturation_ae = rtb_Gain1;
    }

    /* End of Saturate: '<S352>/Saturation5' */

    /* MATLAB Function: '<S361>/MATLAB Function' incorporates:
     *  MATLAB Function: '<S397>/MATLAB Function'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S364>:1' */
    /* '<S364>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S364>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S364>:1:5' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S364>:1:6' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S364>:1:7' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    x20 = (2.0F * rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth;
    x20 = fminf(fmaxf(0.0F, (fminf(fmaxf(x20, rtb_LaneWidth), (6.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth) - x20) / (4.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW)), 1.0F);

    /* Product: '<S361>/Divide5' incorporates:
     *  MATLAB Function: '<S361>/MATLAB Function'
     */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S361>/Divide6' incorporates:
     *  MATLAB Function: '<S361>/MATLAB Function'
     */
    rtb_TTLC_i = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S376>/Abs' incorporates:
     *  Abs: '<S367>/Abs'
     *  Abs: '<S403>/Abs'
     */
    rtb_ThresDet_coefficient_l = fabsf(rtb_Abs_h);

    /* Product: '<S376>/Divide' incorporates:
     *  Abs: '<S376>/Abs'
     */
    rtb_Divide_b = rtb_TTLC_i * rtb_ThresDet_coefficient_l;

    /* Product: '<S361>/Divide4' incorporates:
     *  MATLAB Function: '<S361>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S381>/Switch' incorporates:
     *  RelationalOperator: '<S381>/UpperRelop'
     */
    if (rtb_Divide_b < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_n = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_n = rtb_Divide_b;
    }

    /* End of Switch: '<S381>/Switch' */

    /* Switch: '<S381>/Switch2' incorporates:
     *  RelationalOperator: '<S381>/LowerRelop1'
     */
    if (rtb_Divide_b > rtb_LftTTLC) {
      rtb_Switch2_c = rtb_LftTTLC;
    } else {
      rtb_Switch2_c = rtb_Switch_n;
    }

    /* End of Switch: '<S381>/Switch2' */

    /* Saturate: '<S352>/Saturation1' */
    if (rtb_Add5_k > 2.0F) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 2.0F;
    } else if (rtb_Add5_k < (-2.0F)) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = (-2.0F);
    } else {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_Add5_k;
    }

    /* End of Saturate: '<S352>/Saturation1' */

    /* Abs: '<S377>/Abs' incorporates:
     *  Abs: '<S368>/Abs'
     *  Abs: '<S404>/Abs'
     */
    rtb_TLft = fabsf(rtb_Abs_l);

    /* Product: '<S377>/Divide' incorporates:
     *  Abs: '<S377>/Abs'
     */
    rtb_Divide_dg = rtb_TTLC_i * rtb_TLft;

    /* Switch: '<S382>/Switch' incorporates:
     *  RelationalOperator: '<S382>/UpperRelop'
     */
    if (rtb_Divide_dg < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_o1 = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_o1 = rtb_Divide_dg;
    }

    /* End of Switch: '<S382>/Switch' */

    /* Switch: '<S382>/Switch2' incorporates:
     *  RelationalOperator: '<S382>/LowerRelop1'
     */
    if (rtb_Divide_dg > rtb_LftTTLC) {
      rtb_Switch2_h = rtb_LftTTLC;
    } else {
      rtb_Switch2_h = rtb_Switch_o1;
    }

    /* End of Switch: '<S382>/Switch2' */

    /* Switch: '<S375>/Switch3' incorporates:
     *  Constant: '<S377>/Constant'
     *  Gain: '<S375>/Gain1'
     *  Logic: '<S377>/Logical Operator'
     *  RelationalOperator: '<S377>/Relational Operator1'
     *  RelationalOperator: '<S377>/Relational Operator2'
     */
    if (rtb_Merge1 >= 0.0F) {
      /* Switch: '<S375>/Switch2' incorporates:
       *  Constant: '<S375>/Constant2'
       *  Constant: '<S376>/Constant'
       *  DataTypeConversion: '<S375>/Cast To Single'
       *  Logic: '<S376>/Logical Operator'
       *  RelationalOperator: '<S376>/Relational Operator1'
       *  RelationalOperator: '<S376>/Relational Operator3'
       */
      if (rtb_Merge1 > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_Saturation_ae) &&
          (rtb_Saturation_ae <= rtb_Switch2_c)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S375>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F <
        rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
        rtb_Switch2_h)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S375>/Switch3' */

    /* DataTypeConversion: '<S354>/Data Type Conversion' incorporates:
     *  Constant: '<S385>/Constant'
     *  Constant: '<S386>/Constant'
     *  Constant: '<S387>/Constant'
     *  Constant: '<S388>/Constant'
     *  Logic: '<S354>/Logical Operator'
     *  Logic: '<S354>/Logical Operator1'
     *  Logic: '<S354>/Logical Operator2'
     *  Logic: '<S354>/Logical Operator3'
     *  Logic: '<S354>/Logical Operator4'
     *  Logic: '<S354>/Logical Operator5'
     *  Logic: '<S354>/Logical Operator7'
     *  RelationalOperator: '<S385>/Compare'
     *  RelationalOperator: '<S386>/Compare'
     *  RelationalOperator: '<S387>/Compare'
     *  RelationalOperator: '<S388>/Compare'
     *  Switch: '<S116>/Switch'
     *  Switch: '<S116>/Switch1'
     */
    rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(((((rtb_RelationalOperator_kw_tmp ||
      (!rtb_BCM_Right_Light)) && (rtb_R0_Q > ((uint8)2U))) &&
      (rtb_TCU_ActualGear == ((uint8)2U))) || (((rtb_RelationalOperator_kw_tmp ||
      (!rtb_BCM_Left_Light)) && (rtb_TCU_ActualGear == ((uint8)1U))) &&
      (rtb_L0_Q > ((uint8)2U)))) ? 1 : 0);

    /* DataTypeConversion: '<S353>/Data Type Conversion' incorporates:
     *  Constant: '<S383>/Constant'
     *  Constant: '<S384>/Constant'
     *  Logic: '<S353>/Logical Operator'
     *  RelationalOperator: '<S383>/Compare'
     *  RelationalOperator: '<S384>/Compare'
     */
    rtb_CastToSingle3 = (uint8)(((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
      (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? 1 : 0);

    /* If: '<S351>/If1' incorporates:
     *  Constant: '<S356>/Constant'
     *  Constant: '<S359>/Constant'
     *  Constant: '<S360>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)rtb_TCU_ActualGear) ==
           1)) && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_Rrg_TYPE_BACK) == 1)) {
      /* Outputs for IfAction SubSystem: '<S351>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S359>/Action Port'
       */
      LKAS_DW.Merge2 = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S351>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)
        rtb_TCU_ActualGear) == 2)) && (((sint32)rtb_CastToSingle3) == 1)) &&
               (((sint32)rtb_IMAPve_d_Rrg_TYPE_BACK) == 1)) {
      /* Outputs for IfAction SubSystem: '<S351>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S360>/Action Port'
       */
      LKAS_DW.Merge2 = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S351>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S351>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S356>/Action Port'
       */
      LKAS_DW.Merge2 = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S351>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S351>/If1' */

    /* If: '<S411>/If' */
    if ((rtb_Abs_h >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_l >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S411>/Ph1SWA' incorporates:
       *  ActionPort: '<S415>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_g);

      /* End of Outputs for SubSystem: '<S411>/Ph1SWA' */
    } else if ((rtb_Abs_h <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_Abs_l <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S411>/Ph2SWA' incorporates:
       *  ActionPort: '<S416>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_g);

      /* End of Outputs for SubSystem: '<S411>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S411>/Ph3SWA' incorporates:
       *  ActionPort: '<S417>/Action Port'
       */
      LKAS_Ph3SWA_b(&rtb_Merge1_g);

      /* End of Outputs for SubSystem: '<S411>/Ph3SWA' */
    }

    /* End of If: '<S411>/If' */

    /* Saturate: '<S390>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_TTLC_i = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_TTLC_i = (-2.0F);
    } else {
      rtb_TTLC_i = rtb_Gain1;
    }

    /* End of Saturate: '<S390>/Saturation5' */

    /* Product: '<S397>/Divide5' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S400>:1' */
    /* '<S400>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S400>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S400>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S400>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S400>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_LL_ThresDet_lDvtThresUprLKA *= x20;

    /* Product: '<S397>/Divide6' */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S413>/Divide' incorporates:
     *  Abs: '<S413>/Abs'
     */
    rtb_Divide_a = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_h);

    /* Product: '<S397>/Divide4' */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S418>/Switch' incorporates:
     *  RelationalOperator: '<S418>/UpperRelop'
     */
    if (rtb_Divide_a < rtb_LftTTLC) {
      rtb_Switch_e = rtb_LftTTLC;
    } else {
      rtb_Switch_e = rtb_Divide_a;
    }

    /* End of Switch: '<S418>/Switch' */

    /* Switch: '<S418>/Switch2' incorporates:
     *  RelationalOperator: '<S418>/LowerRelop1'
     */
    if (rtb_Divide_a > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_j = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_j = rtb_Switch_e;
    }

    /* End of Switch: '<S418>/Switch2' */

    /* Saturate: '<S390>/Saturation1' */
    if (rtb_Add5_k > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_k < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_k;
    }

    /* End of Saturate: '<S390>/Saturation1' */

    /* Product: '<S414>/Divide' incorporates:
     *  Abs: '<S414>/Abs'
     */
    rtb_Divide_n = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_l);

    /* Switch: '<S419>/Switch' incorporates:
     *  RelationalOperator: '<S419>/UpperRelop'
     */
    if (rtb_Divide_n < rtb_LftTTLC) {
      rtb_Switch_p = rtb_LftTTLC;
    } else {
      rtb_Switch_p = rtb_Divide_n;
    }

    /* End of Switch: '<S419>/Switch' */

    /* Switch: '<S419>/Switch2' incorporates:
     *  RelationalOperator: '<S419>/LowerRelop1'
     */
    if (rtb_Divide_n > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_hl = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_hl = rtb_Switch_p;
    }

    /* End of Switch: '<S419>/Switch2' */

    /* Switch: '<S412>/Switch3' incorporates:
     *  Constant: '<S414>/Constant'
     *  Gain: '<S412>/Gain1'
     *  Logic: '<S414>/Logical Operator'
     *  RelationalOperator: '<S414>/Relational Operator1'
     *  RelationalOperator: '<S414>/Relational Operator2'
     */
    if (rtb_Merge1_g >= 0.0F) {
      /* Switch: '<S412>/Switch2' incorporates:
       *  Constant: '<S412>/Constant2'
       *  Constant: '<S413>/Constant'
       *  DataTypeConversion: '<S412>/Cast To Single'
       *  Logic: '<S413>/Logical Operator'
       *  RelationalOperator: '<S413>/Relational Operator1'
       *  RelationalOperator: '<S413>/Relational Operator3'
       */
      if (rtb_Merge1_g > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_TTLC_i) && (rtb_TTLC_i <=
          rtb_Switch2_j)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S412>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F <
        rtb_LL_ThresDet_lDvtThresLwrLKA) && (rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_hl)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S412>/Switch3' */

    /* MATLAB Function: '<S391>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S423>:1' */
    /* '<S423>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S423>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S423>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S423>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_IMAPve_g_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge), 0.005F)) / 0.005F);

    /* '<S423>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_TCU_ActualGear) == 2) && (rtb_IMAPve_g_EPS_SW_Trq >
          rtb_LL_MAX_DRIVER_TORQUE_DISABL)) || ((((sint32)rtb_TCU_ActualGear) ==
          1) && (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL))))
    {
      /* Outputs for Enabled SubSystem: '<S391>/Count 0.2s' incorporates:
       *  EnablePort: '<S422>/Enable'
       */
      /* '<S423>:1:7' stDvrTkConFlg=1; */
      /* '<S423>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S423>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S422>/Memory' */
        LKAS_DW.Memory_PreviousInput_kn = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S422>/Add' incorporates:
       *  Memory: '<S422>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_kn;

      /* Saturate: '<S422>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S422>/Saturation' */
      /* End of Outputs for SubSystem: '<S391>/Count 0.2s' */

      /* Switch: '<S665>/Switch16' incorporates:
       *  Constant: '<S665>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S665>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S665>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S391>/Count 0.2s' incorporates:
       *  EnablePort: '<S422>/Enable'
       */
      /* RelationalOperator: '<S422>/Relational Operator' */
      LKAS_DW.RelationalOperator_l = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S422>/Memory' */
      LKAS_DW.Memory_PreviousInput_kn = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S391>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S391>/Count 0.2s' incorporates:
       *  EnablePort: '<S422>/Enable'
       */
      /* '<S423>:1:10' else */
      /* '<S423>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S422>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S391>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S391>/MATLAB Function' */

    /* RelationalOperator: '<S432>/Compare' incorporates:
     *  Constant: '<S432>/Constant'
     */
    rtb_Compare_b0 = (((sint32)(LKAS_DW.RelationalOperator_l ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S424>/Unit Delay' */
    rtb_UnitDelay_de = LKAS_DW.UnitDelay_DSTATE_i;

    /* RelationalOperator: '<S431>/Compare' incorporates:
     *  Constant: '<S431>/Constant'
     */
    rtb_Compare_ld = (((sint32)(rtb_UnitDelay_de ? 1 : 0)) <= ((sint32)(false ?
      1 : 0)));

    /* If: '<S424>/If' incorporates:
     *  Constant: '<S427>/Constant'
     *  Constant: '<S428>/Constant'
     *  RelationalOperator: '<S425>/FixPt Relational Operator'
     *  RelationalOperator: '<S426>/FixPt Relational Operator'
     *  UnitDelay: '<S425>/Delay Input1'
     *  UnitDelay: '<S426>/Delay Input1'
     *
     * Block description for '<S425>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S426>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_l) && (((sint32)(rtb_Compare_b0 ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_a ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S424>/If Action Subsystem' incorporates:
       *  ActionPort: '<S427>/Action Port'
       */
      rtb_Merge_a = true;

      /* End of Outputs for SubSystem: '<S424>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_de) && (((sint32)(rtb_Compare_ld ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_i ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S424>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S428>/Action Port'
       */
      rtb_Merge_a = false;

      /* End of Outputs for SubSystem: '<S424>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S424>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S429>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_de, &rtb_Merge_a);

      /* End of Outputs for SubSystem: '<S424>/If Action Subsystem3' */
    }

    /* End of If: '<S424>/If' */

    /* Outputs for Enabled SubSystem: '<S391>/Count' incorporates:
     *  EnablePort: '<S421>/Enable'
     */
    /* Logic: '<S391>/Logical Operator' incorporates:
     *  Constant: '<S420>/Constant'
     *  Memory: '<S391>/Memory'
     *  RelationalOperator: '<S420>/Compare'
     */
    if ((rtb_TCU_ActualGear > ((uint8)0U)) && (LKAS_DW.Memory_PreviousInput_e))
    {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S421>/Memory' */
        LKAS_DW.Memory_PreviousInput_kd = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S421>/Add' incorporates:
       *  Memory: '<S421>/Memory'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_kd;

      /* Saturate: '<S421>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_LftTTLC;
      }

      /* End of Saturate: '<S421>/Saturation' */

      /* Update for Memory: '<S421>/Memory' */
      LKAS_DW.Memory_PreviousInput_kd = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S421>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S391>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S391>/Count' */

    /* Outputs for Enabled SubSystem: '<S424>/Sum Condition1' incorporates:
     *  EnablePort: '<S430>/state = reset'
     */
    if (rtb_Merge_a) {
      if (!LKAS_DW.SumCondition1_MODE_o) {
        /* InitializeConditions for Memory: '<S430>/Memory' */
        LKAS_DW.Memory_PreviousInput_gn = 0.0F;
        LKAS_DW.SumCondition1_MODE_o = true;
      }

      /* Sum: '<S430>/Add1' incorporates:
       *  Memory: '<S430>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_gn;

      /* Saturate: '<S430>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 5.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 5.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S430>/Saturation' */

      /* Switch: '<S665>/Switch40' incorporates:
       *  Constant: '<S665>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S665>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S665>/Switch40' */

      /* RelationalOperator: '<S430>/Relational Operator' incorporates:
       *  Sum: '<S391>/Add'
       */
      LKAS_DW.RelationalOperator_h = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S430>/Memory' */
      LKAS_DW.Memory_PreviousInput_gn = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S430>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }
    }

    /* End of Outputs for SubSystem: '<S424>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S392>/Sum Condition1' incorporates:
     *  EnablePort: '<S436>/state = reset'
     */
    /* Logic: '<S392>/Logical Operator' incorporates:
     *  Constant: '<S434>/Constant'
     *  Constant: '<S435>/Constant'
     *  Delay: '<S149>/Delay1'
     *  RelationalOperator: '<S434>/Compare'
     *  RelationalOperator: '<S435>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_m) {
        /* InitializeConditions for Memory: '<S436>/Memory' */
        LKAS_DW.Memory_PreviousInput_kq = 0.0F;
        LKAS_DW.SumCondition1_MODE_m = true;
      }

      /* Sum: '<S436>/Add1' incorporates:
       *  Memory: '<S436>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_kq;

      /* Saturate: '<S436>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S436>/Saturation' */

      /* RelationalOperator: '<S436>/Relational Operator' */
      LKAS_DW.RelationalOperator_j = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S436>/Memory' */
      LKAS_DW.Memory_PreviousInput_kq = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S436>/Out' */
        LKAS_DW.RelationalOperator_j = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }
    }

    /* End of Logic: '<S392>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S392>/Sum Condition1' */

    /* If: '<S389>/If1' incorporates:
     *  Constant: '<S394>/Constant'
     *  Constant: '<S396>/Constant'
     *  Constant: '<S433>/Constant'
     *  Delay: '<S149>/Delay'
     *  Logic: '<S389>/Logical Operator'
     *  Logic: '<S392>/Logical Operator1'
     *  RelationalOperator: '<S433>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((LKAS_DW.RelationalOperator_h) ||
          ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_j))) || (LKAS_DW.Delay_DSTATE_m))) {
      /* Outputs for IfAction SubSystem: '<S389>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S396>/Action Port'
       */
      LKAS_DW.Merge1_f = true;

      /* End of Outputs for SubSystem: '<S389>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S389>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S394>/Action Port'
       */
      LKAS_DW.Merge1_f = false;

      /* End of Outputs for SubSystem: '<S389>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S389>/If1' */

    /* MATLAB Function: '<S557>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_ThresDet_lDvtThresUprLDW, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient_d);

    /* Product: '<S557>/Multiply' */
    rtb_Multiply_n = rtb_LL_ThresDet_lDvtThresUprLDW *
      rtb_ThresDet_coefficient_d;

    /* Switch: '<S559>/Switch' incorporates:
     *  Constant: '<S557>/Constant'
     *  RelationalOperator: '<S559>/UpperRelop'
     */
    if (rtb_Multiply_n < 0.0F) {
      rtb_Switch_l = 0.0F;
    } else {
      rtb_Switch_l = rtb_Multiply_n;
    }

    /* End of Switch: '<S559>/Switch' */

    /* Switch: '<S559>/Switch2' incorporates:
     *  RelationalOperator: '<S559>/LowerRelop1'
     */
    if (rtb_Multiply_n > rtb_LL_ThresDet_lDvtThresUprLDW) {
      rtb_Switch2_m = rtb_LL_ThresDet_lDvtThresUprLDW;
    } else {
      rtb_Switch2_m = rtb_Switch_l;
    }

    /* End of Switch: '<S559>/Switch2' */

    /* Logic: '<S543>/Logical Operator3' incorporates:
     *  Constant: '<S555>/Constant'
     *  Constant: '<S556>/Constant'
     *  Logic: '<S553>/Logical Operator'
     *  Logic: '<S554>/Logical Operator'
     *  RelationalOperator: '<S554>/Relational Operator1'
     *  RelationalOperator: '<S554>/Relational Operator2'
     *  RelationalOperator: '<S555>/Compare'
     *  RelationalOperator: '<S556>/Compare'
     */
    rtb_LogicalOperator3_b = (((LKAS_DW.LKA_Mode >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1 >= rtb_Switch2_m) && (rtb_Add5_k >= rtb_Switch2_m)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_b);

    /* If: '<S543>/If' incorporates:
     *  Constant: '<S549>/Constant'
     *  DataTypeConversion: '<S543>/Cast To Single'
     *  DataTypeConversion: '<S543>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_LogicalOperator3_b) {
      /* Outputs for IfAction SubSystem: '<S543>/If Action Subsystem' incorporates:
       *  ActionPort: '<S549>/Action Port'
       */
      LKAS_DW.Merge_m = true;

      /* End of Outputs for SubSystem: '<S543>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S543>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S551>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_m);

      /* End of Outputs for SubSystem: '<S543>/If Action Subsystem3' */
    }

    /* End of If: '<S543>/If' */

    /* Delay: '<S149>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_2_DSTATE;

    /* If: '<S439>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S439>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_gd != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S439>/If Action Subsystem' incorporates:
         *  ActionPort: '<S469>/Action Port'
         */
        /* InitializeConditions for If: '<S439>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S469>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_k = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S439>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S439>/If Action Subsystem' incorporates:
       *  ActionPort: '<S469>/Action Port'
       */
      /* Sum: '<S469>/Add1' incorporates:
       *  Memory: '<S469>/Memory'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_k;

      /* Saturate: '<S469>/Saturation' */
      if (rtb_LL_TkOvStChk_tiTDelTime > 10.0F) {
        rtb_LL_TkOvStChk_tiTDelTime = 10.0F;
      } else {
        if (rtb_LL_TkOvStChk_tiTDelTime < 0.0F) {
          rtb_LL_TkOvStChk_tiTDelTime = 0.0F;
        }
      }

      /* End of Saturate: '<S469>/Saturation' */
      /* End of Outputs for SubSystem: '<S439>/If Action Subsystem' */

      /* Switch: '<S665>/Switch64' incorporates:
       *  Constant: '<S665>/LLSMConClb33'
       *
       * Block description for '<S665>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S665>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S439>/If Action Subsystem' incorporates:
       *  ActionPort: '<S469>/Action Port'
       */
      /* RelationalOperator: '<S469>/Relational Operator' */
      rtb_Merge_ou = (rtb_LL_TkOvStChk_tiTDelTime >= x10);

      /* Update for Memory: '<S469>/Memory' */
      LKAS_DW.Memory_PreviousInput_k = rtb_LL_TkOvStChk_tiTDelTime;

      /* End of Outputs for SubSystem: '<S439>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S439>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S470>/Action Port'
       */
      /* SignalConversion: '<S470>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S470>/Constant'
       */
      rtb_Merge_ou = false;

      /* End of Outputs for SubSystem: '<S439>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S439>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S440>/Logical Operator1' incorporates:
     *  Constant: '<S471>/Constant'
     *  Logic: '<S440>/Logical Operator'
     *  RelationalOperator: '<S440>/Relational Operator1'
     *  RelationalOperator: '<S440>/Relational Operator2'
     *  RelationalOperator: '<S471>/Compare'
     */
    rtb_BCM_Left_Light = ((LKAS_DW.LKA_Mode >= ((uint8)1U)) && ((rtb_Gain1 <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_k <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S437>/Logical Operator3' */
    rtb_RelationalOperator_j = ((rtb_BCM_Left_Light || rtb_Merge_ou) ||
      rtb_RelationalOperator_j);

    /* If: '<S437>/If1' incorporates:
     *  Constant: '<S447>/Constant'
     *  DataTypeConversion: '<S437>/Cast To Single'
     *  DataTypeConversion: '<S437>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_RelationalOperator_j) {
      /* Outputs for IfAction SubSystem: '<S437>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S447>/Action Port'
       */
      LKAS_DW.Merge1_fi = true;

      /* End of Outputs for SubSystem: '<S437>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S437>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S449>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_fi);

      /* End of Outputs for SubSystem: '<S437>/If Action Subsystem4' */
    }

    /* End of If: '<S437>/If1' */

    /* Memory: '<S365>/Memory' */
    rtb_Memory_ol = LKAS_DW.Memory_PreviousInput_g;

    /* If: '<S365>/If' */
    if ((rtb_Abs_h >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_l >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S365>/Ph1SWA' incorporates:
       *  ActionPort: '<S369>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_p);

      /* End of Outputs for SubSystem: '<S365>/Ph1SWA' */
    } else if ((rtb_Abs_h <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_l <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S365>/Ph2SWA' incorporates:
       *  ActionPort: '<S370>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_p);

      /* End of Outputs for SubSystem: '<S365>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S365>/Ph3SWA' incorporates:
       *  ActionPort: '<S371>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_ol, &rtb_Merge1_p);

      /* End of Outputs for SubSystem: '<S365>/Ph3SWA' */
    }

    /* End of If: '<S365>/If' */

    /* Product: '<S361>/Divide2' incorporates:
     *  MATLAB Function: '<S361>/MATLAB Function'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S361>/Divide3' incorporates:
     *  MATLAB Function: '<S361>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S367>/Divide' */
    rtb_Divide_p = rtb_LKA_Veh2CamL_C * rtb_ThresDet_coefficient_l;

    /* Product: '<S361>/Divide1' incorporates:
     *  MATLAB Function: '<S361>/MATLAB Function'
     */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S372>/Switch' incorporates:
     *  RelationalOperator: '<S372>/UpperRelop'
     */
    if (rtb_Divide_p < rtb_LftTTLC) {
      rtb_Switch_j = rtb_LftTTLC;
    } else {
      rtb_Switch_j = rtb_Divide_p;
    }

    /* End of Switch: '<S372>/Switch' */

    /* Switch: '<S372>/Switch2' incorporates:
     *  RelationalOperator: '<S372>/LowerRelop1'
     */
    if (rtb_Divide_p > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_mp = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_mp = rtb_Switch_j;
    }

    /* End of Switch: '<S372>/Switch2' */

    /* Product: '<S368>/Divide' */
    rtb_Divide_l = rtb_LKA_Veh2CamL_C * rtb_TLft;

    /* Switch: '<S373>/Switch' incorporates:
     *  RelationalOperator: '<S373>/UpperRelop'
     */
    if (rtb_Divide_l < rtb_LftTTLC) {
      rtb_Switch_f3 = rtb_LftTTLC;
    } else {
      rtb_Switch_f3 = rtb_Divide_l;
    }

    /* End of Switch: '<S373>/Switch' */

    /* Switch: '<S373>/Switch2' incorporates:
     *  RelationalOperator: '<S373>/LowerRelop1'
     */
    if (rtb_Divide_l > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_jy = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_jy = rtb_Switch_f3;
    }

    /* End of Switch: '<S373>/Switch2' */

    /* Switch: '<S366>/Switch3' incorporates:
     *  Gain: '<S366>/Gain1'
     *  RelationalOperator: '<S368>/Relational Operator2'
     */
    if (rtb_Merge1_p >= 0.0F) {
      /* Switch: '<S366>/Switch2' incorporates:
       *  Constant: '<S366>/Constant2'
       *  DataTypeConversion: '<S366>/Cast To Single'
       *  RelationalOperator: '<S367>/Relational Operator2'
       */
      if (rtb_Merge1_p > 0.0F) {
        rtb_CastToSingle3 = (uint8)((rtb_Saturation_ae <= rtb_Switch2_mp) ? 1 :
          0);
      } else {
        rtb_CastToSingle3 = ((uint8)0U);
      }

      /* End of Switch: '<S366>/Switch2' */
    } else {
      rtb_CastToSingle3 = (uint8)((((uint32)((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
        rtb_Switch2_jy) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S366>/Switch3' */

    /* If: '<S351>/If' incorporates:
     *  Constant: '<S355>/Constant'
     *  Constant: '<S357>/Constant'
     *  Constant: '<S358>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
         && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_Rrg_TYPE_BACK) == 1)) {
      /* Outputs for IfAction SubSystem: '<S351>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S357>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S351>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
      == 2)) && (((sint32)rtb_CastToSingle3) == 2)) && (((sint32)
                 rtb_IMAPve_d_Rrg_TYPE_BACK) == 1)) {
      /* Outputs for IfAction SubSystem: '<S351>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S358>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S351>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S351>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S355>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S351>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S351>/If' */

    /* Memory: '<S401>/Memory' */
    rtb_Memory_e = LKAS_DW.Memory_PreviousInput_gb;

    /* If: '<S401>/If' */
    if ((rtb_Abs_h >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_l >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S401>/Ph1SWA' incorporates:
       *  ActionPort: '<S405>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S401>/Ph1SWA' */
    } else if ((rtb_Abs_h <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_l <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S401>/Ph2SWA' incorporates:
       *  ActionPort: '<S406>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S401>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S401>/Ph3SWA' incorporates:
       *  ActionPort: '<S407>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_e, &rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S401>/Ph3SWA' */
    }

    /* End of If: '<S401>/If' */

    /* Product: '<S397>/Divide2' */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S397>/Divide3' */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S403>/Divide' */
    rtb_Divide_j = rtb_LKA_Veh2CamL_C * rtb_ThresDet_coefficient_l;

    /* Product: '<S397>/Divide1' */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S409>/Switch' incorporates:
     *  RelationalOperator: '<S409>/UpperRelop'
     */
    if (rtb_Divide_j < rtb_LftTTLC) {
      rtb_Switch_j2 = rtb_LftTTLC;
    } else {
      rtb_Switch_j2 = rtb_Divide_j;
    }

    /* End of Switch: '<S409>/Switch' */

    /* Switch: '<S409>/Switch2' incorporates:
     *  RelationalOperator: '<S409>/LowerRelop1'
     */
    if (rtb_Divide_j > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_g = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_g = rtb_Switch_j2;
    }

    /* End of Switch: '<S409>/Switch2' */

    /* Product: '<S404>/Divide' */
    rtb_Divide_e = rtb_LKA_Veh2CamL_C * rtb_TLft;

    /* Switch: '<S410>/Switch' incorporates:
     *  RelationalOperator: '<S410>/UpperRelop'
     */
    if (rtb_Divide_e < rtb_LftTTLC) {
      rtb_Switch_g = rtb_LftTTLC;
    } else {
      rtb_Switch_g = rtb_Divide_e;
    }

    /* End of Switch: '<S410>/Switch' */

    /* Switch: '<S410>/Switch2' incorporates:
     *  RelationalOperator: '<S410>/LowerRelop1'
     */
    if (rtb_Divide_e > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_k = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_k = rtb_Switch_g;
    }

    /* End of Switch: '<S410>/Switch2' */

    /* Switch: '<S402>/Switch3' incorporates:
     *  Gain: '<S402>/Gain1'
     *  RelationalOperator: '<S404>/Relational Operator2'
     */
    if (rtb_Merge1_n >= 0.0F) {
      /* Switch: '<S402>/Switch2' incorporates:
       *  Constant: '<S402>/Constant2'
       *  DataTypeConversion: '<S402>/Cast To Single'
       *  RelationalOperator: '<S403>/Relational Operator2'
       */
      if (rtb_Merge1_n > 0.0F) {
        rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)((rtb_TTLC_i <= rtb_Switch2_g) ? 1 :
          0);
      } else {
        rtb_IMAPve_d_Rrg_TYPE_BACK = ((uint8)0U);
      }

      /* End of Switch: '<S402>/Switch2' */
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)((((uint32)
        ((rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_k) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S402>/Switch3' */

    /* Outputs for Enabled SubSystem: '<S402>/Sum Condition' incorporates:
     *  EnablePort: '<S408>/Enable'
     */
    if (((sint32)rtb_IMAPve_d_Rrg_TYPE_BACK) > 0) {
      if (!LKAS_DW.SumCondition_MODE) {
        /* InitializeConditions for Memory: '<S408>/Memory' */
        LKAS_DW.Memory_PreviousInput_ij = 0.0F;
        LKAS_DW.SumCondition_MODE = true;
      }

      /* Sum: '<S408>/Add1' incorporates:
       *  Memory: '<S408>/Memory'
       */
      rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_ij;

      /* Saturate: '<S408>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 5.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 5.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S408>/Saturation' */

      /* RelationalOperator: '<S408>/Relational Operator' incorporates:
       *  Constant: '<S402>/Constant'
       */
      LKAS_DW.RelationalOperator_a = (rtb_LL_LDW_LatestWarnLine_C <= 2.0F);

      /* Update for Memory: '<S408>/Memory' */
      LKAS_DW.Memory_PreviousInput_ij = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S408>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S402>/Sum Condition' */

    /* If: '<S389>/If' incorporates:
     *  Constant: '<S393>/Constant'
     *  Constant: '<S395>/Constant'
     *  DataTypeConversion: '<S402>/Cast To Single3'
     *  DataTypeConversion: '<S402>/Cast To Single4'
     *  Product: '<S402>/Divide'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && (((sint32)((uint32)(((uint32)rtb_IMAPve_d_Rrg_TYPE_BACK) *
            (LKAS_DW.RelationalOperator_a ? 1U : 0U)))) == 0)) {
      /* Outputs for IfAction SubSystem: '<S389>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S395>/Action Port'
       */
      LKAS_DW.Merge_c = true;

      /* End of Outputs for SubSystem: '<S389>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S389>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S393>/Action Port'
       */
      LKAS_DW.Merge_c = false;

      /* End of Outputs for SubSystem: '<S389>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S389>/If' */

    /* Logic: '<S350>/Logical Operator1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     */
    rtb_BCM_Right_Light = ((rtb_Saturation1 != 0.0F) ||
      (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F));

    /* Logic: '<S350>/Logical Operator10' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     */
    LKAS_DW.LDW_Fault = ((rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) ||
                         rtb_BCM_Right_Light);

    /* Chart: '<S149>/LDW_State_Machine'
     *
     * Block description for '<S149>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* Sum: '<S601>/Add' incorporates:
     *  Memory: '<S601>/Memory'
     */
    rtb_LftTTLC = LKAS_DW.Memory_PreviousInput_h + rtb_LKA_SampleTime;

    /* Saturate: '<S601>/Saturation' */
    if (rtb_LftTTLC > 11.0F) {
      rtb_Saturation_i = 11.0F;
    } else if (rtb_LftTTLC < 0.0F) {
      rtb_Saturation_i = 0.0F;
    } else {
      rtb_Saturation_i = rtb_LftTTLC;
    }

    /* End of Saturate: '<S601>/Saturation' */

    /* Logic: '<S350>/Logical Operator8' incorporates:
     *  Constant: '<S600>/Constant'
     *  Constant: '<S601>/Constant1'
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  Logic: '<S350>/AND'
     *  RelationalOperator: '<S600>/Compare'
     *  RelationalOperator: '<S601>/Relational Operator'
     */
    LKAS_DW.LKA_Fault = (((rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) ||
                          rtb_BCM_Right_Light) || ((rtb_IMAPve_d_EPS_LKA_State ==
      ((uint8)4U)) && (rtb_Saturation_i >= ((float32)((uint16)5U)))));

    /* Chart: '<S149>/LKA_and_ELK_State_Machine'
     *
     * Block description for '<S149>/LKA_and_ELK_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_and_ELK_State_Machine();

    /* Outputs for Enabled SubSystem: '<S326>/Subsystem' incorporates:
     *  EnablePort: '<S330>/Enable'
     */
    /* Logic: '<S326>/Logical Operator3' incorporates:
     *  Abs: '<S326>/Abs4'
     *  Abs: '<S326>/Abs5'
     *  Abs: '<S326>/Abs6'
     *  Abs: '<S326>/Abs7'
     *  Constant: '<S326>/Constant'
     *  Constant: '<S326>/Constant1'
     *  Constant: '<S326>/Constant4'
     *  Constant: '<S326>/Constant5'
     *  Constant: '<S328>/Constant'
     *  Constant: '<S329>/Constant'
     *  Logic: '<S326>/Logical Operator'
     *  Logic: '<S326>/Logical Operator1'
     *  Logic: '<S326>/Logical Operator4'
     *  RelationalOperator: '<S326>/Relational Operator'
     *  RelationalOperator: '<S326>/Relational Operator1'
     *  RelationalOperator: '<S326>/Relational Operator2'
     *  RelationalOperator: '<S326>/Relational Operator3'
     *  RelationalOperator: '<S326>/Relational Operator6'
     *  RelationalOperator: '<S326>/Relational Operator7'
     *  RelationalOperator: '<S328>/Compare'
     *  RelationalOperator: '<S329>/Compare'
     *  Switch: '<S116>/Switch'
     *  Switch: '<S116>/Switch1'
     */
    if ((((((fabsf(rtb_LL_CompHdAg_C) <= 0.008F) && (fabsf(rtb_L0_C1_fx) <=
             0.008F)) && ((fabsf(rtb_L0_C2_h) <= 0.0001F) && (fabsf(rtb_R0_C1_d)
             <= 0.0001F))) && ((rtb_L0_Q == ((uint8)3U)) && (rtb_R0_Q == ((uint8)
             3U)))) && (rtb_IMAPve_g_ESC_VehSpd >= 35.0F)) && (rtb_TTLC <= 4.0F))
    {
      if (!LKAS_DW.Subsystem_MODE_j) {
        /* InitializeConditions for Memory: '<S330>/Memory' */
        LKAS_DW.Memory_PreviousInput_pl = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_j = true;
      }

      /* Sum: '<S330>/Add1' incorporates:
       *  Memory: '<S330>/Memory'
       */
      rtb_Saturation_nn = (uint16)(1U + ((uint32)LKAS_DW.Memory_PreviousInput_pl));

      /* Saturate: '<S330>/Saturation' */
      if (rtb_Saturation_nn >= ((uint16)3000U)) {
        rtb_Saturation_nn = ((uint16)3000U);
      }

      /* End of Saturate: '<S330>/Saturation' */

      /* RelationalOperator: '<S330>/Relational Operator' incorporates:
       *  Constant: '<S326>/Constant3'
       *  DataTypeConversion: '<S330>/Cast To Single1'
       *  Product: '<S326>/Divide'
       */
      LKAS_DW.RelationalOperator_m = (rtb_Saturation_nn >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S330>/Memory' */
      LKAS_DW.Memory_PreviousInput_pl = rtb_Saturation_nn;
    } else {
      if (LKAS_DW.Subsystem_MODE_j) {
        /* Disable for Outport: '<S330>/Out' */
        LKAS_DW.RelationalOperator_m = false;
        LKAS_DW.Subsystem_MODE_j = false;
      }
    }

    /* End of Logic: '<S326>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S326>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S300>/Subsystem' incorporates:
     *  EnablePort: '<S325>/Enable'
     */
    if (LKAS_DW.RelationalOperator_m) {
      /* Sum: '<S327>/Add2' incorporates:
       *  Constant: '<S327>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S327>/Memory3'
       */
      rtb_LL_LDW_LatestWarnLine_C = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S327>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 50.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 50.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S327>/Saturation' */

      /* Switch: '<S327>/Switch' incorporates:
       *  Constant: '<S325>/Constant'
       *  Product: '<S327>/Divide'
       *  Product: '<S327>/Divide1'
       *  Sum: '<S327>/Add'
       *  Sum: '<S327>/Add1'
       *  UnitDelay: '<S327>/Unit Delay'
       */
      if (rtb_LL_LDW_LatestWarnLine_C > 1.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_SW_Angle - LKAS_DW.UnitDelay_DSTATE)) + LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_SW_Angle;
      }

      /* End of Switch: '<S327>/Switch' */

      /* Saturate: '<S325>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 3.0F) {
        LKAS_DW.Saturation_h = 3.0F;
      } else if (rtb_LL_ThresDet_lDvtThresLwrLDW < (-3.0F)) {
        LKAS_DW.Saturation_h = (-3.0F);
      } else {
        LKAS_DW.Saturation_h = rtb_LL_ThresDet_lDvtThresLwrLDW;
      }

      /* End of Saturate: '<S325>/Saturation' */

      /* Update for UnitDelay: '<S327>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Update for Memory: '<S327>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Outputs for SubSystem: '<S300>/Subsystem' */

    /* Saturate: '<S302>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 0.001F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.001F;
    } else {
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S302>/Saturation' */

    /* Gain: '<S338>/kph To mps' incorporates:
     *  Gain: '<S339>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = 0.277777791F *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S338>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S340>:1' */
    /* '<S340>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 60.0F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_LL_ThresDet_lDvtThresUprLKA;
    }

    /* End of Saturate: '<S338>/Saturation3' */

    /* Product: '<S338>/Divide1' incorporates:
     *  Constant: '<S338>/Constant'
     */
    rtb_LftTTLC = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S338>/Saturation1' */
    if (rtb_LftTTLC > 0.0117F) {
      rtb_LftTTLC = 0.0117F;
    } else {
      if (rtb_LftTTLC < 0.00237F) {
        rtb_LftTTLC = 0.00237F;
      }
    }

    /* End of Saturate: '<S338>/Saturation1' */

    /* Switch: '<S664>/Switch7' incorporates:
     *  Constant: '<S664>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_d != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_d;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S664>/Switch7' */

    /* MATLAB Function: '<S338>/MATLAB Function' incorporates:
     *  Gain: '<S338>/kph To mps'
     */
    rtb_LL_LDW_LatestWarnLine_C = ((((((((rtb_LftTTLC *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_a) * LKAS_DW.LKA_WhlBaseL_C_j) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S339>/Saturation3' */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 60.0F;
      }
    }

    /* End of Saturate: '<S339>/Saturation3' */

    /* Product: '<S339>/Divide1' incorporates:
     *  Constant: '<S339>/Constant'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = 0.09F / rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S339>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S341>:1' */
    /* '<S341>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 0.0117F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.0117F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 0.00237F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 0.00237F;
      }
    }

    /* End of Saturate: '<S339>/Saturation1' */

    /* Switch: '<S664>/Switch4' incorporates:
     *  Constant: '<S664>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_i != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_i;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S664>/Switch4' */

    /* MATLAB Function: '<S339>/MATLAB Function' */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_a) * LKAS_DW.LKA_WhlBaseL_C_j) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Gain: '<S297>/Gain1' incorporates:
     *  Sum: '<S297>/Add1'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = (rtb_Add_e1 + rtb_Add_g) * 0.5F;

    /* Switch: '<S299>/Switch' incorporates:
     *  Constant: '<S315>/Constant'
     *  RelationalOperator: '<S315>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_LftTTLC = rtb_LFTTTLC;
    } else {
      rtb_LftTTLC = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S299>/Switch' */

    /* Saturate: '<S299>/Saturation' */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else {
      if (rtb_LftTTLC < 0.5F) {
        rtb_LftTTLC = 0.5F;
      }
    }

    /* End of Saturate: '<S299>/Saturation' */

    /* Product: '<S323>/Divide' */
    rtb_Divide_lg = rtb_Abs_n_tmp * rtb_LftTTLC;

    /* Switch: '<S299>/Switch1' incorporates:
     *  Constant: '<S316>/Constant'
     *  RelationalOperator: '<S316>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S299>/Switch1' */

    /* Saturate: '<S299>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S299>/Saturation1' */

    /* Product: '<S324>/Divide' */
    rtb_Divide_ex = rtb_Abs_n_tmp * rtb_LL_HdAgPrvwT_C;

    /* Gain: '<S299>/Gain1' incorporates:
     *  Sum: '<S299>/Add1'
     */
    rtb_LL_HdAgPrvwT_C = (rtb_Divide_lg + rtb_Divide_ex) * 0.5F;

    /* Switch: '<S664>/Switch8' incorporates:
     *  Constant: '<S664>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_g != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_g;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S664>/Switch8' */

    /* Product: '<S314>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_Abs_n_tmp * x10;

    /* Product: '<S312>/Z*Z' incorporates:
     *  Product: '<S313>/Z*Z'
     */
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Sum: '<S312>/Add' incorporates:
     *  Product: '<S312>/Product'
     *  Product: '<S312>/Product3'
     *  Product: '<S312>/Product4'
     *  Product: '<S312>/Z*Z'
     *  Product: '<S312>/Z*Z*Z'
     */
    rtb_Add_c = (((rtb_LL_CompHdAg_C * rtb_LL_ThresDet_lDvtThresUprLKA) +
                  rtb_L0_C0_b) + (rtb_L0_C2_h * rtb_LL_DvtSpdDet_vDvtSpdMin_C))
      + ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_DvtSpdDet_vDvtSpdMin_C) *
         rtb_L0_C3_g);

    /* Sum: '<S313>/Add' incorporates:
     *  Product: '<S313>/Product'
     *  Product: '<S313>/Product3'
     *  Product: '<S313>/Product4'
     *  Product: '<S313>/Z*Z*Z'
     */
    rtb_Add_o = (((rtb_L0_C1_fx * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_R0_C0_a)
                 + (rtb_R0_C1_d * rtb_LL_DvtSpdDet_vDvtSpdMin_C)) +
      ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_DvtSpdDet_vDvtSpdMin_C) *
       rtb_R0_C3_j);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S147>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S176>/Memory' */
        LKAS_DW.Memory_PreviousInput_l = 0.0F;

        /* InitializeConditions for Memory: '<S207>/Memory' */
        LKAS_DW.Memory_PreviousInput_pm = ((uint16)0U);

        /* InitializeConditions for Memory: '<S194>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_h = ((uint8)0U);

        /* InitializeConditions for Memory: '<S206>/Memory' */
        LKAS_DW.Memory_PreviousInput_n = ((uint16)0U);

        /* InitializeConditions for Memory: '<S208>/Memory' */
        LKAS_DW.Memory_PreviousInput_h3 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S203>/Memory' */
        LKAS_DW.Memory_PreviousInput_dj = ((uint16)0U);

        /* InitializeConditions for Memory: '<S191>/Memory' */
        LKAS_DW.Memory_PreviousInput_ae = 0.0F;

        /* InitializeConditions for Memory: '<S177>/Memory' */
        LKAS_DW.Memory_PreviousInput_id = 0.0F;

        /* InitializeConditions for Memory: '<S178>/Memory' */
        LKAS_DW.Memory_PreviousInput_g0 = 0.0F;

        /* InitializeConditions for UnitDelay: '<S180>/Delay Input1'
         *
         * Block description for '<S180>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_j = false;

        /* InitializeConditions for Memory: '<S178>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_o = false;

        /* InitializeConditions for Memory: '<S169>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_c = 0.0F;

        /* InitializeConditions for Memory: '<S270>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_n = 0.0F;

        /* InitializeConditions for Memory: '<S253>/Memory' */
        LKAS_DW.Memory_PreviousInput_lt = 0.0F;

        /* InitializeConditions for UnitDelay: '<S251>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_f = 0.0F;

        /* InitializeConditions for Memory: '<S259>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_h = 0.0F;

        /* InitializeConditions for Memory: '<S265>/Memory' */
        LKAS_DW.Memory_PreviousInput_h4 = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S269>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_d = 0.0F;

        /* InitializeConditions for Memory: '<S269>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_a = 0.0F;

        /* InitializeConditions for UnitDelay: '<S246>/Delay Input2'
         *
         * Block description for '<S246>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_g = 0.0F;

        /* InitializeConditions for Memory: '<S246>/Memory' */
        LKAS_DW.Memory_PreviousInput_li = ((uint16)0U);

        /* InitializeConditions for Memory: '<S202>/Memory' */
        LKAS_DW.Memory_PreviousInput_ny = ((uint16)0U);

        /* InitializeConditions for Memory: '<S204>/Memory' */
        LKAS_DW.Memory_PreviousInput_nn = ((uint16)0U);

        /* InitializeConditions for Memory: '<S205>/Memory' */
        LKAS_DW.Memory_PreviousInput_hp = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S164>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S164>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S178>/Moving Standard Deviation1' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S178>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S178>/Moving Standard Deviation2' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation2_e);

        /* End of SystemReset for SubSystem: '<S178>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Memory: '<S176>/Memory' */
      rtb_Divide3_n = LKAS_DW.Memory_PreviousInput_l;

      /* Sum: '<S176>/Add2' */
      rtb_Divide3_n += rtb_LKA_SampleTime;

      /* Saturate: '<S176>/Saturation2' */
      if (rtb_Divide3_n > 20.0F) {
        rtb_Saturation2_e = 20.0F;
      } else if (rtb_Divide3_n < 0.0F) {
        rtb_Saturation2_e = 0.0F;
      } else {
        rtb_Saturation2_e = rtb_Divide3_n;
      }

      /* End of Saturate: '<S176>/Saturation2' */

      /* Abs: '<S176>/Abs' */
      rtb_Divide3_n = rtb_TTLC_h;

      /* Saturate: '<S176>/Saturation' */
      if (rtb_Divide3_n > 0.004F) {
        rtb_Divide3_n = 0.004F;
      } else {
        if (rtb_Divide3_n < 0.0F) {
          rtb_Divide3_n = 0.0F;
        }
      }

      /* End of Saturate: '<S176>/Saturation' */

      /* RelationalOperator: '<S176>/Relational Operator4' incorporates:
       *  Constant: '<S176>/Constant'
       *  Constant: '<S176>/Constant1'
       *  Product: '<S176>/Divide'
       *  Sum: '<S176>/Add'
       */
      rtb_BCM_Right_Light = (rtb_Saturation2_e >=
        ((((rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F) * rtb_Divide3_n) / 0.004F) +
         rtb_LL_LKAExPrcs_tiExitTime1));

      /* Abs: '<S177>/Abs' */
      rtb_Divide3_n = rtb_TTLC_h;

      /* Saturate: '<S177>/Saturation' */
      if (rtb_Divide3_n > 0.004F) {
        rtb_Divide3_n = 0.004F;
      } else {
        if (rtb_Divide3_n < 0.0F) {
          rtb_Divide3_n = 0.0F;
        }
      }

      /* End of Saturate: '<S177>/Saturation' */

      /* Product: '<S177>/Divide' incorporates:
       *  Constant: '<S177>/Constant'
       *  Constant: '<S177>/Constant1'
       */
      rtb_LL_DvtSpdDet_vDvtSpdMin_C = ((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) *
        rtb_Divide3_n) / 0.004F;

      /* Sum: '<S207>/Add' incorporates:
       *  Constant: '<S207>/Constant'
       *  Memory: '<S207>/Memory'
       */
      rtb_Saturation_nn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_pm));

      /* Saturate: '<S207>/Saturation1' */
      if (rtb_Saturation_nn < ((uint16)10000U)) {
        rtb_Saturation1_c = rtb_Saturation_nn;
      } else {
        rtb_Saturation1_c = ((uint16)10000U);
      }

      /* End of Saturate: '<S207>/Saturation1' */

      /* Gain: '<S252>/kph to mps' */
      rtb_Divide3_n = rtb_Abs_n_tmp;

      /* Saturate: '<S252>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S252>/Saturation3' */

      /* Product: '<S252>/Divide2' incorporates:
       *  Constant: '<S252>/Constant'
       */
      rtb_LftTTLC = 0.09F / x10;

      /* Switch: '<S664>/Switch36' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_a != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_a;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S664>/Switch36' */

      /* Saturate: '<S252>/Saturation1' */
      if (rtb_LftTTLC > 0.01F) {
        rtb_LftTTLC = 0.01F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S252>/Saturation1' */

      /* Gain: '<S252>/Gain2' incorporates:
       *  Constant: '<S252>/Constant1'
       *  Gain: '<S252>/rad to deg'
       *  Gain: '<S297>/Gain1'
       *  Math: '<S252>/Math Function'
       *  Product: '<S252>/Divide'
       *  Product: '<S252>/Divide1'
       *  Product: '<S252>/Product'
       *  Product: '<S252>/Product1'
       *  Product: '<S252>/Product2'
       *  Product: '<S252>/Product3'
       *  Sum: '<S252>/Add'
       *
       * About '<S252>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = (((((((rtb_Divide3_n * rtb_Divide3_n) *
        rtb_LftTTLC) + 1.0F) / (rtb_Divide3_n / LKAS_DW.LKA_WhlBaseL_C_j)) *
        ((rtb_Divide3_n * rtb_LL_ThresDet_tiTTLCThresLDW) * 57.2957802F)) * x10)
        * LKAS_DW.LKA_StrRatio_C_a) * (-1.0F);

      /* Sum: '<S190>/Add1' */
      rtb_Add1_fg = (rtb_SW_Angle - rtb_LL_LKAExPrcs_tiExitTime1) -
        LKAS_DW.Saturation_h;

      /* If: '<S207>/If' incorporates:
       *  Constant: '<S207>/Constant2'
       */
      if (rtb_Saturation1_c == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S207>/if action ' incorporates:
         *  ActionPort: '<S230>/Action Port'
         */
        LKAS_ifaction(rtb_Add1_fg, &LKAS_DW.In_mj);

        /* End of Outputs for SubSystem: '<S207>/if action ' */
      }

      /* End of If: '<S207>/If' */

      /* Sum: '<S194>/Add' incorporates:
       *  Constant: '<S194>/Constant'
       *  Memory: '<S194>/Memory1'
       */
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_h));

      /* Saturate: '<S194>/Saturation1' */
      if (rtb_IMAPve_d_Rrg_TYPE_BACK < ((uint8)5U)) {
        rtb_Saturation1_d2 = rtb_IMAPve_d_Rrg_TYPE_BACK;
      } else {
        rtb_Saturation1_d2 = ((uint8)5U);
      }

      /* End of Saturate: '<S194>/Saturation1' */

      /* Saturate: '<S190>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        rtb_Divide3_n = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        rtb_Divide3_n = 60.0F;
      } else {
        rtb_Divide3_n = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S190>/Saturation3' */

      /* Product: '<S190>/Divide1' incorporates:
       *  Constant: '<S190>/Constant'
       */
      rtb_Divide3_n = 0.09F / rtb_Divide3_n;

      /* Saturate: '<S190>/Saturation1' */
      if (rtb_Divide3_n > 0.0117F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.0117F;
      } else if (rtb_Divide3_n < 0.00237F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.MPInP_StbFacm_SY = rtb_Divide3_n;
      }

      /* End of Saturate: '<S190>/Saturation1' */

      /* Gain: '<S190>/Gain' */
      LKAS_DW.MPInP_dphiSWARMax = 1.0F * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S206>/Add' incorporates:
       *  Constant: '<S206>/Constant'
       *  Memory: '<S206>/Memory'
       */
      rtb_Saturation_nn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_n));

      /* Saturate: '<S206>/Saturation1' */
      if (rtb_Saturation_nn < ((uint16)10000U)) {
        rtb_Saturation1_dc = rtb_Saturation_nn;
      } else {
        rtb_Saturation1_dc = ((uint16)10000U);
      }

      /* End of Saturate: '<S206>/Saturation1' */

      /* If: '<S197>/If' incorporates:
       *  DataTypeConversion: '<S147>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S197>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S211>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_LFTTTLC, &rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S197>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S197>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S210>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_RGTTTLC, &rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S197>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S197>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S212>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S197>/If Action Subsystem3' */
      }

      /* End of If: '<S197>/If' */

      /* If: '<S206>/If' incorporates:
       *  Constant: '<S206>/Constant2'
       */
      if (rtb_Saturation1_dc == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S206>/if action ' incorporates:
         *  ActionPort: '<S229>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_d, &LKAS_DW.In_l);

        /* End of Outputs for SubSystem: '<S206>/if action ' */
      }

      /* End of If: '<S206>/If' */

      /* Saturate: '<S190>/Saturation2' */
      if (LKAS_DW.In_l > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_l < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_l;
      }

      /* End of Saturate: '<S190>/Saturation2' */

      /* Sum: '<S208>/Add' incorporates:
       *  Constant: '<S208>/Constant'
       *  Memory: '<S208>/Memory'
       */
      rtb_Saturation_nn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_h3));

      /* Saturate: '<S208>/Saturation1' */
      if (rtb_Saturation_nn < ((uint16)10000U)) {
        rtb_Saturation1_k5 = rtb_Saturation_nn;
      } else {
        rtb_Saturation1_k5 = ((uint16)10000U);
      }

      /* End of Saturate: '<S208>/Saturation1' */

      /* If: '<S208>/If' incorporates:
       *  Constant: '<S208>/Constant2'
       */
      if (rtb_Saturation1_k5 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S208>/if action ' incorporates:
         *  ActionPort: '<S231>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_ESC_VehSpd, &LKAS_DW.In_m);

        /* End of Outputs for SubSystem: '<S208>/if action ' */
      }

      /* End of If: '<S208>/If' */

      /* Sum: '<S203>/Add' incorporates:
       *  Constant: '<S203>/Constant'
       *  Memory: '<S203>/Memory'
       */
      rtb_Saturation_nn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_dj));

      /* Saturate: '<S203>/Saturation1' */
      if (rtb_Saturation_nn < ((uint16)10000U)) {
        rtb_Saturation1_b = rtb_Saturation_nn;
      } else {
        rtb_Saturation1_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S203>/Saturation1' */

      /* Product: '<S321>/Z*Z' incorporates:
       *  Product: '<S318>/Z*Z'
       */
      rtb_R0_C1_d = rtb_Divide_lg * rtb_Divide_lg;

      /* Gain: '<S321>/Gain1' incorporates:
       *  Gain: '<S320>/Gain1'
       *  Gain: '<S322>/Gain1'
       */
      rtb_L0_C3_g *= 3.0F;

      /* Gain: '<S318>/Gain1' incorporates:
       *  Gain: '<S317>/Gain1'
       *  Gain: '<S319>/Gain1'
       */
      rtb_R0_C3_j *= 3.0F;

      /* Gain: '<S198>/Gain' incorporates:
       *  Gain: '<S318>/Gain1'
       *  Gain: '<S321>/Gain1'
       *  Product: '<S318>/Product3'
       *  Product: '<S318>/Product4'
       *  Product: '<S321>/Product3'
       *  Product: '<S321>/Product4'
       *  Product: '<S321>/Z*Z'
       *  Sum: '<S198>/Add'
       *  Sum: '<S318>/Add'
       *  Sum: '<S321>/Add'
       */
      rtb_Gain_nj = ((((rtb_Add_e1_tmp * rtb_Divide_lg) + rtb_LL_CompHdAg_C) +
                      (rtb_L0_C3_g * rtb_R0_C1_d)) + (((rtb_Add_g_tmp *
        rtb_Divide_lg) + rtb_L0_C1_fx) + (rtb_R0_C3_j * rtb_R0_C1_d))) * 0.5F;

      /* Product: '<S322>/Z*Z' incorporates:
       *  Product: '<S319>/Z*Z'
       */
      rtb_R0_C1_d = rtb_Divide_ex * rtb_Divide_ex;

      /* Gain: '<S198>/Gain1' incorporates:
       *  Product: '<S319>/Product3'
       *  Product: '<S319>/Product4'
       *  Product: '<S322>/Product3'
       *  Product: '<S322>/Product4'
       *  Product: '<S322>/Z*Z'
       *  Sum: '<S198>/Add1'
       *  Sum: '<S319>/Add'
       *  Sum: '<S322>/Add'
       */
      rtb_Gain1_e = ((((rtb_Add_e1_tmp * rtb_Divide_ex) + rtb_LL_CompHdAg_C) +
                      (rtb_L0_C3_g * rtb_R0_C1_d)) + (((rtb_Add_g_tmp *
        rtb_Divide_ex) + rtb_L0_C1_fx) + (rtb_R0_C3_j * rtb_R0_C1_d))) * 0.5F;

      /* If: '<S198>/If' incorporates:
       *  DataTypeConversion: '<S147>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S198>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S214>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_Gain_nj, &rtb_Divide3_n);

        /* End of Outputs for SubSystem: '<S198>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S198>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S213>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_Gain1_e, &rtb_Divide3_n);

        /* End of Outputs for SubSystem: '<S198>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S198>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S215>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Divide3_n);

        /* End of Outputs for SubSystem: '<S198>/If Action Subsystem3' */
      }

      /* End of If: '<S198>/If' */

      /* If: '<S200>/If' incorporates:
       *  DataTypeConversion: '<S147>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S200>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S220>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_Divide_lg, &rtb_Gain2_g);

        /* End of Outputs for SubSystem: '<S200>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S200>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S219>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_Divide_ex, &rtb_Gain2_g);

        /* End of Outputs for SubSystem: '<S200>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S200>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S221>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Gain2_g);

        /* End of Outputs for SubSystem: '<S200>/If Action Subsystem3' */
      }

      /* End of If: '<S200>/If' */

      /* Sum: '<S190>/Add' incorporates:
       *  Gain: '<S297>/Gain1'
       *  Product: '<S190>/Divide2'
       */
      rtb_Add_ne = rtb_Divide3_n - (rtb_LL_ThresDet_tiTTLCThresLDW * rtb_Gain2_g);

      /* If: '<S203>/If' incorporates:
       *  Constant: '<S203>/Constant2'
       */
      if (rtb_Saturation1_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S203>/if action ' incorporates:
         *  ActionPort: '<S226>/Action Port'
         */
        LKAS_ifaction(rtb_Add_ne, &LKAS_DW.In_a);

        /* End of Outputs for SubSystem: '<S203>/if action ' */
      }

      /* End of If: '<S203>/If' */

      /* If: '<S209>/If' incorporates:
       *  DataTypeConversion: '<S147>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S209>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S233>/Action Port'
         */
        /* SignalConversion: '<S233>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S233>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S209>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S209>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S232>/Action Port'
         */
        /* SignalConversion: '<S232>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S232>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S209>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S209>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S234>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S209>/If Action Subsystem3' */
      }

      /* End of If: '<S209>/If' */

      /* If: '<S194>/If' incorporates:
       *  Constant: '<S194>/Constant19'
       */
      rtAction = -1;
      if (rtb_Saturation1_d2 == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        /* Outputs for IfAction SubSystem: '<S158>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S189>/Action Port'
         *
         * Block description for '<S158>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S158>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S194>/If' */

      /* Memory: '<S191>/Memory' */
      rtb_Gain2_g = LKAS_DW.Memory_PreviousInput_ae;

      /* Sum: '<S191>/Add' incorporates:
       *  Gain: '<S191>/Gain1'
       *  Product: '<S191>/Divide'
       *  Product: '<S191>/Product'
       */
      rtb_Add_ja = ((rtb_Abs_n_tmp * rtb_LKA_SampleTime) / (0.277777791F *
        LKAS_DW.In_m)) + rtb_Gain2_g;

      /* MATLAB Function: '<S192>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S235>:1' */
      /* '<S235>:1:19' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S235>:1:20' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S235>:1:21' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S235>:1:22' Delte2PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S235>:1:23' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S235>:1:24' NomT = SWACmd_tiNomT; */
      /* '<S235>:1:25' T1 = K1K2Det_T1; */
      /* '<S235>:1:26' T2 = T1; */
      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S235>:1:34' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_ja < LKAS_DW.K1K2Det_T1) && (rtb_Add_ja >= 0.0F)) {
        /* '<S235>:1:35' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_ja) +
          LKAS_DW.In_mj;
      } else if ((rtb_Add_ja <= LKAS_DW.K1K2Det_T1) && (rtb_Add_ja >=
                  LKAS_DW.K1K2Det_T1)) {
        /* '<S235>:1:36' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S235>:1:38' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
          LKAS_DW.K1K2Det_T1) + LKAS_DW.In_mj;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_ja >= LKAS_DW.K1K2Det_T1) {
          /* '<S235>:1:40' elseif(NomT >= T2) */
          /* '<S235>:1:41' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
            LKAS_DW.K1K2Det_T1) + LKAS_DW.In_mj;

          /*    DelteSWCmd = single(0); */
        }
      }

      /* Saturate: '<S158>/Saturation6' incorporates:
       *  MATLAB Function: '<S192>/SWACmd'
       */
      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S235>:1:47' SWACmd_phiSWACmd = DelteSWCmd; */
      if (LKAS_DW.K1K2Det_T1 > 2.0F) {
        rtb_Saturation6 = 2.0F;
      } else if (LKAS_DW.K1K2Det_T1 < 0.2F) {
        rtb_Saturation6 = 0.2F;
      } else {
        rtb_Saturation6 = LKAS_DW.K1K2Det_T1;
      }

      /* End of Saturate: '<S158>/Saturation6' */

      /* Memory: '<S177>/Memory' */
      rtb_Gain2_g = LKAS_DW.Memory_PreviousInput_id;

      /* Sum: '<S177>/Add2' */
      rtb_Gain2_g += rtb_LKA_SampleTime;

      /* Saturate: '<S177>/Saturation2' */
      if (rtb_Gain2_g > 12.0F) {
        rtb_Saturation2_l = 12.0F;
      } else if (rtb_Gain2_g < 0.0F) {
        rtb_Saturation2_l = 0.0F;
      } else {
        rtb_Saturation2_l = rtb_Gain2_g;
      }

      /* End of Saturate: '<S177>/Saturation2' */

      /* Abs: '<S177>/Abs2' */
      rtb_Gain2_g = fabsf(rtb_Gain1);

      /* Sum: '<S177>/Add3' incorporates:
       *  Sum: '<S178>/Add'
       *  Sum: '<S237>/Add'
       *  Sum: '<S258>/Add6'
       */
      rtb_R0_C1_d = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Gain: '<S177>/Gain' incorporates:
       *  Sum: '<S177>/Add3'
       */
      rtb_Divide3_n = rtb_R0_C1_d * 0.166666672F;

      /* RelationalOperator: '<S177>/Relational Operator2' */
      rtb_LogicalOperator3_b = (rtb_Gain2_g >= rtb_Divide3_n);

      /* Abs: '<S177>/Abs3' */
      rtb_Gain2_g = fabsf(rtb_Add5_k);

      /* Outputs for Enabled SubSystem: '<S177>/Sum Condition1' incorporates:
       *  EnablePort: '<S179>/Enable'
       */
      /* Logic: '<S177>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S177>/Relational Operator3'
       *  RelationalOperator: '<S177>/Relational Operator4'
       */
      if (((rtb_Saturation2_l >= rtb_Saturation6) && rtb_LogicalOperator3_b) &&
          (rtb_Gain2_g >= rtb_Divide3_n)) {
        if (!LKAS_DW.SumCondition1_MODE_e) {
          /* InitializeConditions for Memory: '<S179>/Memory' */
          LKAS_DW.Memory_PreviousInput_bi = 0.0F;
          LKAS_DW.SumCondition1_MODE_e = true;
        }

        /* Sum: '<S179>/Add1' incorporates:
         *  Memory: '<S179>/Memory'
         */
        rtb_Abs_l = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_bi;

        /* Saturate: '<S179>/Saturation' */
        if (rtb_Abs_l > 10.0F) {
          rtb_Abs_l = 10.0F;
        } else {
          if (rtb_Abs_l < 0.0F) {
            rtb_Abs_l = 0.0F;
          }
        }

        /* End of Saturate: '<S179>/Saturation' */

        /* RelationalOperator: '<S179>/Relational Operator' incorporates:
         *  Sum: '<S177>/Add1'
         */
        LKAS_DW.RelationalOperator_dq = (rtb_Abs_l >=
          (rtb_LL_LKAExPrcs_tiExitTime2 + rtb_LL_DvtSpdDet_vDvtSpdMin_C));

        /* Update for Memory: '<S179>/Memory' */
        LKAS_DW.Memory_PreviousInput_bi = rtb_Abs_l;
      } else {
        if (LKAS_DW.SumCondition1_MODE_e) {
          /* Disable for Outport: '<S179>/Out' */
          LKAS_DW.RelationalOperator_dq = false;
          LKAS_DW.SumCondition1_MODE_e = false;
        }
      }

      /* End of Logic: '<S177>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S177>/Sum Condition1' */

      /* Memory: '<S178>/Memory' */
      rtb_Gain2_g = LKAS_DW.Memory_PreviousInput_g0;

      /* Sum: '<S178>/Add2' */
      rtb_Gain2_g += rtb_LKA_SampleTime;

      /* Saturate: '<S178>/Saturation2' */
      if (rtb_Gain2_g > 10.0F) {
        rtb_Saturation2_ey = 10.0F;
      } else if (rtb_Gain2_g < 0.0F) {
        rtb_Saturation2_ey = 0.0F;
      } else {
        rtb_Saturation2_ey = rtb_Gain2_g;
      }

      /* End of Saturate: '<S178>/Saturation2' */

      /* Gain: '<S178>/Gain' */
      rtb_Gain2_g = rtb_R0_C1_d * 0.333333343F;

      /* Logic: '<S178>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S178>/Relational Operator2'
       *  RelationalOperator: '<S178>/Relational Operator3'
       *  RelationalOperator: '<S178>/Relational Operator4'
       */
      rtb_LogicalOperator3_b = (((rtb_Saturation2_ey >= rtb_Saturation6) &&
        (rtb_Gain1 >= rtb_Gain2_g)) && (rtb_Add5_k >= rtb_Gain2_g));

      /* Abs: '<S178>/Abs4' */
      rtb_Gain2_g = rtb_TTLC_h;

      /* Saturate: '<S178>/Saturation' */
      if (rtb_Gain2_g > 0.004F) {
        rtb_Gain2_g = 0.004F;
      } else {
        if (rtb_Gain2_g < 0.0F) {
          rtb_Gain2_g = 0.0F;
        }
      }

      /* End of Saturate: '<S178>/Saturation' */

      /* Switch: '<S664>/Switch45' incorporates:
       *  Constant: '<S664>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S664>/Switch45' */

      /* Sum: '<S178>/Add6' incorporates:
       *  Constant: '<S178>/Constant'
       *  Constant: '<S178>/Constant7'
       *  Product: '<S178>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Gain2_g) / 0.004F) + x10;

      /* Outputs for Atomic SubSystem: '<S164>/Moving Standard Deviation2' */
      LKAS_MovingStandardDeviation2(rtb_IMAPve_g_EPS_SW_Trq, &rtb_kphTomps_l,
        &rtb_Merge_n, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S164>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S178>/Moving Standard Deviation1' */
      rtb_Gain_i = (float32) LKAS_MovingStandardDeviation1(rtb_Add5_k,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S178>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S178>/Relational Operator6' */
      rtb_RelationalOperator6_p = (rtb_Gain_i <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S178>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_p, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_p, &LKAS_DW.SumCondition1_m);

      /* End of Outputs for SubSystem: '<S178>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S178>/Moving Standard Deviation2' */
      rtb_Gain_i = (float32) LKAS_MovingStandardDeviation1(rtb_Gain1,
        &LKAS_DW.MovingStandardDeviation2_e);

      /* End of Outputs for SubSystem: '<S178>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S178>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain_i <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S178>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_hz, &LKAS_DW.SumCondition_c);

      /* End of Outputs for SubSystem: '<S178>/Sum Condition' */

      /* RelationalOperator: '<S188>/Compare' incorporates:
       *  Constant: '<S188>/Constant'
       *  Constant: '<S664>/LL_LKAExPrcs_ExitC0Swt=1'
       *  Logic: '<S178>/Logical Operator2'
       *  Switch: '<S664>/Switch46'
       */
      rtb_Compare_gy = (((sint32)((((rtb_LogicalOperator3_b &&
        (LKAS_DW.RelationalOperator_p)) && (LKAS_DW.RelationalOperator_hz)) &&
        ((LKAS_ConstB.DataTypeConversion35) || (LL_LKAExPrcs_ExitC0Swt))) ? 1 :
        0)) > ((sint32)(false ? 1 : 0)));

      /* Memory: '<S178>/Memory1' */
      rtb_Memory1_h = LKAS_DW.Memory1_PreviousInput_o;

      /* If: '<S178>/If' incorporates:
       *  Constant: '<S181>/Constant'
       *  RelationalOperator: '<S180>/FixPt Relational Operator'
       *  UnitDelay: '<S180>/Delay Input1'
       *
       * Block description for '<S180>/Delay Input1':
       *
       *  Store in Global RAM
       */
      if (((sint32)(rtb_Compare_gy ? 1 : 0)) > ((sint32)
           (LKAS_DW.DelayInput1_DSTATE_j ? 1 : 0))) {
        /* Outputs for IfAction SubSystem: '<S178>/If Action Subsystem' incorporates:
         *  ActionPort: '<S181>/Action Port'
         */
        rtb_Merge_ai = true;

        /* End of Outputs for SubSystem: '<S178>/If Action Subsystem' */
      } else {
        /* Outputs for IfAction SubSystem: '<S178>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S182>/Action Port'
         */
        LKAS_IfActionSubsystem3(rtb_Memory1_h, &rtb_Merge_ai);

        /* End of Outputs for SubSystem: '<S178>/If Action Subsystem3' */
      }

      /* End of If: '<S178>/If' */

      /* Outputs for Enabled SubSystem: '<S164>/Sum Condition2' incorporates:
       *  EnablePort: '<S168>/state = reset'
       */
      /* Outputs for Enabled SubSystem: '<S178>/Sum Condition2' incorporates:
       *  EnablePort: '<S187>/state = reset'
       */
      if (rtb_Merge_ai) {
        if (!LKAS_DW.SumCondition2_MODE) {
          /* InitializeConditions for Memory: '<S187>/Memory' */
          LKAS_DW.Memory_PreviousInput_j = 0.0F;
          LKAS_DW.SumCondition2_MODE = true;
        }

        /* Sum: '<S187>/Add1' incorporates:
         *  Memory: '<S187>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_j;

        /* Saturate: '<S187>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S187>/Saturation' */

        /* RelationalOperator: '<S187>/Relational Operator' */
        LKAS_DW.RelationalOperator_c = (rtb_LL_LKAExPrcs_tiExitTime2 >=
          rtb_LL_LKAExPrcs_tiExitDelayTim);

        /* Update for Memory: '<S187>/Memory' */
        LKAS_DW.Memory_PreviousInput_j = rtb_LL_LKAExPrcs_tiExitTime2;
        if (!LKAS_DW.SumCondition2_MODE_p) {
          /* InitializeConditions for Memory: '<S168>/Memory' */
          LKAS_DW.Memory_PreviousInput_ll = 0.0F;
          LKAS_DW.SumCondition2_MODE_p = true;
        }

        /* Sum: '<S168>/Add1' incorporates:
         *  Memory: '<S168>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_ll;

        /* Saturate: '<S168>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S168>/Saturation' */

        /* Switch: '<S664>/Switch28' incorporates:
         *  Constant: '<S664>/LL_LKASWASyn_M4K=0.1'
         */
        if (LKAS_ConstB.DataTypeConversion42 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion42;
        } else {
          x10 = LL_LKASWASyn_M4K;
        }

        /* End of Switch: '<S664>/Switch28' */

        /* Sum: '<S168>/Add2' incorporates:
         *  Constant: '<S168>/Constant1'
         */
        rtb_LftTTLC = x10 - 1.0F;

        /* Product: '<S168>/Divide' */
        rtb_LL_LKAExPrcs_tiExitDelayTim = rtb_LL_LKAExPrcs_tiExitTime2 /
          rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Saturate: '<S168>/Saturation1' */
        if (rtb_LL_LKAExPrcs_tiExitDelayTim > 1.0F) {
          rtb_LL_LKAExPrcs_tiExitDelayTim = 1.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitDelayTim < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitDelayTim = 0.0F;
          }
        }

        /* End of Saturate: '<S168>/Saturation1' */

        /* Saturate: '<S168>/Saturation2' */
        if (rtb_LftTTLC > 0.0F) {
          rtb_LftTTLC = 0.0F;
        } else {
          if (rtb_LftTTLC < (-1.0F)) {
            rtb_LftTTLC = (-1.0F);
          }
        }

        /* End of Saturate: '<S168>/Saturation2' */

        /* Sum: '<S168>/Add3' incorporates:
         *  Constant: '<S168>/Constant2'
         *  Product: '<S168>/Divide1'
         */
        rtb_LftTTLC = (rtb_LL_LKAExPrcs_tiExitDelayTim * rtb_LftTTLC) + 1.0F;

        /* Saturate: '<S168>/Saturation3' */
        if (rtb_LftTTLC > 1.0F) {
          LKAS_DW.Saturation3 = 1.0F;
        } else if (rtb_LftTTLC < 0.0F) {
          LKAS_DW.Saturation3 = 0.0F;
        } else {
          LKAS_DW.Saturation3 = rtb_LftTTLC;
        }

        /* End of Saturate: '<S168>/Saturation3' */

        /* Update for Memory: '<S168>/Memory' */
        LKAS_DW.Memory_PreviousInput_ll = rtb_LL_LKAExPrcs_tiExitTime2;
      } else {
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S187>/Out' */
          LKAS_DW.RelationalOperator_c = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        if (LKAS_DW.SumCondition2_MODE_p) {
          LKAS_DW.SumCondition2_MODE_p = false;
        }
      }

      /* End of Outputs for SubSystem: '<S178>/Sum Condition2' */
      /* End of Outputs for SubSystem: '<S164>/Sum Condition2' */

      /* Fcn: '<S157>/Fcn' incorporates:
       *  DataTypeConversion: '<S157>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((LKAS_DW.RelationalOperator_c ? 1 : 0) *
        (LKAS_DW.RelationalOperator_c ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!LKAS_DW.RelationalOperator_c) ? 1 : 0)) *
        (LKAS_DW.RelationalOperator_dq ? 1 : 0)) * ((sint32)2.0F))) + (((sint32)
        (((!LKAS_DW.RelationalOperator_dq) && (!LKAS_DW.RelationalOperator_c)) ?
         1 : 0)) * (rtb_BCM_Right_Light ? 1 : 0))));

      /* Logic: '<S157>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_BCM_Right_Light ||
        (LKAS_DW.RelationalOperator_dq)) || (LKAS_DW.RelationalOperator_c));

      /* DataTypeConversion: '<S160>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon_o = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Sum: '<S164>/Add' */
      rtb_Gain2_g = rtb_IMAPve_g_EPS_SW_Trq - rtb_kphTomps_l;

      /* Saturate: '<S164>/Saturation4' */
      if (rtb_Gain2_g > 2.0F) {
        rtb_Gain2_g = 2.0F;
      } else {
        if (rtb_Gain2_g < 0.0F) {
          rtb_Gain2_g = 0.0F;
        }
      }

      /* End of Saturate: '<S164>/Saturation4' */

      /* Abs: '<S164>/Abs' */
      rtb_Gain2_g = fabsf(rtb_Gain2_g);

      /* Saturate: '<S164>/Saturation7' */
      if (rtb_Gain2_g > 1.0F) {
        rtb_Gain2_g = 1.0F;
      } else {
        if (rtb_Gain2_g < 0.0F) {
          rtb_Gain2_g = 0.0F;
        }
      }

      /* End of Saturate: '<S164>/Saturation7' */

      /* Switch: '<S664>/Switch26' incorporates:
       *  Constant: '<S664>/LL_LKASWASyn_M3D=0.5'
       */
      if (LKAS_ConstB.DataTypeConversion40 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion40;
      } else {
        x10 = LL_LKASWASyn_M3D;
      }

      /* End of Switch: '<S664>/Switch26' */

      /* Product: '<S164>/Divide2' */
      rtb_Gain2_g /= x10;

      /* Saturate: '<S164>/Saturation5' */
      if (rtb_Gain2_g > 1.0F) {
        rtb_Gain2_g = 1.0F;
      } else {
        if (rtb_Gain2_g < 0.0F) {
          rtb_Gain2_g = 0.0F;
        }
      }

      /* End of Saturate: '<S164>/Saturation5' */

      /* Switch: '<S664>/Switch18' incorporates:
       *  Constant: '<S664>/LL_LKASWASyn_M3K_DT=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion25;
      } else {
        x10 = LL_LKASWASyn_M3K_DT;
      }

      /* End of Switch: '<S664>/Switch18' */

      /* Product: '<S164>/Divide1' */
      rtb_Gain2_g *= x10;

      /* Saturate: '<S164>/Saturation3' */
      if (rtb_Gain2_g > 0.4F) {
        rtb_Gain2_g = 0.4F;
      } else {
        if (rtb_Gain2_g < 0.0F) {
          rtb_Gain2_g = 0.0F;
        }
      }

      /* End of Saturate: '<S164>/Saturation3' */

      /* Switch: '<S664>/Switch27' incorporates:
       *  Constant: '<S664>/LL_LKASWASyn_M3K_MSD=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion41 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion41;
      } else {
        x10 = LL_LKASWASyn_M3K_MSD;
      }

      /* End of Switch: '<S664>/Switch27' */

      /* Product: '<S164>/Divide' */
      rtb_Divide3_n = rtb_Merge_n * x10;

      /* Saturate: '<S164>/Saturation1' */
      if (rtb_Divide3_n > 0.4F) {
        rtb_Divide3_n = 0.4F;
      } else {
        if (rtb_Divide3_n < 0.0F) {
          rtb_Divide3_n = 0.0F;
        }
      }

      /* End of Saturate: '<S164>/Saturation1' */

      /* Sum: '<S169>/Add2' incorporates:
       *  Memory: '<S169>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_c;

      /* Saturate: '<S169>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_li = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_li = 0.0F;
      } else {
        rtb_Saturation_li = rtb_LftTTLC;
      }

      /* End of Saturate: '<S169>/Saturation' */

      /* MATLAB Function: '<S164>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Driver Torque Assist/MATLAB Function': '<S166>:1' */
      /* '<S166>:1:2' if T<T1 */
      if (rtb_Saturation_li < rtb_Saturation6) {
        /* '<S166>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_LL_LKASWASyn_M0 += ((rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6) * rtb_Saturation_li;
      } else if ((rtb_Saturation_li >= rtb_Saturation6) && (rtb_Saturation_li <=
                  (rtb_Saturation6 + rtb_LL_LKASWASyn_T2))) {
        /* Switch: '<S664>/Switch14' incorporates:
         *  Constant: '<S664>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S166>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S166>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_o != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_o;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (((x10 - rtb_LL_LKASWASyn_M1) /
          rtb_LL_LKASWASyn_T2) * (rtb_Saturation_li - rtb_Saturation6)) +
          rtb_LL_LKASWASyn_M1;
      } else {
        /* Switch: '<S664>/Switch14' incorporates:
         *  Constant: '<S664>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S166>:1:6' else */
        /* '<S166>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_o != 0.0F) {
          rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20_o;
        } else {
          rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S164>/MATLAB Function' */

      /* Sum: '<S164>/Add1' */
      rtb_Gain2_g = (rtb_LL_LKASWASyn_M0 - rtb_Gain2_g) - rtb_Divide3_n;

      /* Saturate: '<S164>/Saturation6' */
      if (rtb_Gain2_g > 1.0F) {
        rtb_Gain2_g = 1.0F;
      } else {
        if (rtb_Gain2_g < 0.01F) {
          rtb_Gain2_g = 0.01F;
        }
      }

      /* End of Saturate: '<S164>/Saturation6' */

      /* Product: '<S164>/Divide5' */
      rtb_Gain2_g *= LKAS_DW.Saturation3;

      /* Saturate: '<S164>/Saturation2' */
      if (rtb_Gain2_g > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Gain2_g < 0.01F) {
        LKAS_DW.Saturation2 = 0.01F;
      } else {
        LKAS_DW.Saturation2 = rtb_Gain2_g;
      }

      /* End of Saturate: '<S164>/Saturation2' */

      /* Outputs for Enabled SubSystem: '<S156>/Subsystem' incorporates:
       *  EnablePort: '<S165>/Enable'
       */
      /* RelationalOperator: '<S163>/Compare' incorporates:
       *  Constant: '<S163>/Constant'
       *  Constant: '<S664>/LL_LKASWASyn_TrqSwaAddSwt=1'
       *  Switch: '<S664>/Switch47'
       */
      if (((sint32)(((LKAS_ConstB.DataTypeConversion47_j) ||
                     (LL_LKASWASyn_TrqSwaAddSwt)) ? 1 : 0)) > ((sint32)(false ?
            1 : 0))) {
        if (!LKAS_DW.Subsystem_MODE_b) {
          LKAS_DW.Subsystem_MODE_b = true;
        }

        /* MATLAB Function: '<S165>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S170>:1' */
        /* '<S170>:1:2' Swaadd=single(0); */
        /* '<S170>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S170>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S170>:1:5' l0c0=abs(l0c0); */
        /* '<S170>:1:6' r0c0=abs(r0c0); */
        /* '<S170>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_LL_LKASWASyn_M1 = fmaxf(fminf(rtb_LKA_Veh2CamW_C + rtb_Add5_k_tmp,
          5.4F), 2.5F);

        /* '<S170>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_LL_LKASWASyn_M1 > 2.5F) && (rtb_LL_LKASWASyn_M1 < 5.4F)) {
          /* '<S170>:1:9' leftlane=l0c0/lanewidth; */
          rtb_LL_LKASWASyn_T2 = rtb_LKA_Veh2CamW_C / rtb_LL_LKASWASyn_M1;

          /* '<S170>:1:10' rightlane=r0c0/lanewidth; */
          rtb_LL_LKASWASyn_M0 = rtb_Add5_k_tmp / rtb_LL_LKASWASyn_M1;
        } else {
          /* '<S170>:1:11' else */
          /* '<S170>:1:12' leftlane=single(0.5); */
          rtb_LL_LKASWASyn_T2 = 0.5F;

          /* '<S170>:1:13' rightlane=single(0.5); */
          rtb_LL_LKASWASyn_M0 = 0.5F;
        }

        /* '<S170>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S170>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S170>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S664>/Switch42' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S170>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S664>/Switch43' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M0 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_LL_LKASWASyn_T2) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S664>/Switch42' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S170>:1:19' else */
          /* '<S170>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S664>/Switch43' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M0 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_LL_LKASWASyn_M0) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S171>/Add2' incorporates:
         *  Constant: '<S171>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S171>/Memory3'
         */
        rtb_LL_LKASWASyn_M1 = 1.0F + LKAS_DW.Memory3_PreviousInput_k;

        /* Saturate: '<S171>/Saturation' */
        if (rtb_LL_LKASWASyn_M1 > 50.0F) {
          rtb_LL_LKASWASyn_M1 = 50.0F;
        } else {
          if (rtb_LL_LKASWASyn_M1 < 0.0F) {
            rtb_LL_LKASWASyn_M1 = 0.0F;
          }
        }

        /* End of Saturate: '<S171>/Saturation' */

        /* Switch: '<S171>/Switch' incorporates:
         *  Product: '<S171>/Divide'
         *  Product: '<S171>/Divide1'
         *  Sum: '<S171>/Add'
         *  Sum: '<S171>/Add1'
         *  UnitDelay: '<S171>/Unit Delay'
         */
        if (rtb_LL_LKASWASyn_M1 > 1.0F) {
          /* Switch: '<S664>/Switch50' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S664>/Switch50' */
          rtb_LL_LKASWASyn_M0 = ((rtb_LKA_SampleTime / x10) *
            (rtb_LL_LKASWASyn_M0 - LKAS_DW.UnitDelay_DSTATE_o)) +
            LKAS_DW.UnitDelay_DSTATE_o;
        }

        /* End of Switch: '<S171>/Switch' */

        /* SampleTimeMath: '<S174>/TSamp'
         *
         * About '<S174>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_LKASWASyn_T2 = rtb_LL_LKASWASyn_M0 * 100.0F;

        /* Sum: '<S172>/Add2' incorporates:
         *  Constant: '<S172>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S172>/Memory3'
         */
        rtb_LL_LKAExPrcs_tiExitDelayTim = 1.0F + LKAS_DW.Memory3_PreviousInput_m;

        /* Saturate: '<S172>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitDelayTim > 50.0F) {
          rtb_LL_LKAExPrcs_tiExitDelayTim = 50.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitDelayTim < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitDelayTim = 0.0F;
          }
        }

        /* End of Saturate: '<S172>/Saturation' */

        /* Switch: '<S172>/Switch' incorporates:
         *  Product: '<S172>/Divide'
         *  Product: '<S172>/Divide1'
         *  Sum: '<S172>/Add'
         *  Sum: '<S172>/Add1'
         *  Sum: '<S174>/Diff'
         *  UnitDelay: '<S172>/Unit Delay'
         *  UnitDelay: '<S174>/UD'
         *
         * Block description for '<S174>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S174>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_LKAExPrcs_tiExitDelayTim > 2.0F) {
          /* Switch: '<S664>/Switch52' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S664>/Switch52' */
          rtb_LL_LKAExPrcs_tiExitTime2 = (((rtb_LL_LKASWASyn_T2 -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_o4) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_o4;
        } else {
          rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LL_LKASWASyn_T2 - LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S172>/Switch' */

        /* Saturate: '<S165>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 30.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 30.0F;
        } else if (rtb_LL_LKAExPrcs_tiExitTime2 < (-30.0F)) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = (-30.0F);
        } else {
          rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LL_LKAExPrcs_tiExitTime2;
        }

        /* End of Saturate: '<S165>/Saturation' */

        /* Switch: '<S664>/Switch53' incorporates:
         *  Constant: '<S664>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S664>/Switch53' */

        /* Sum: '<S173>/Difference Inputs1' incorporates:
         *  Product: '<S165>/Divide1'
         *  Product: '<S165>/Divide3'
         *  Sum: '<S165>/Add'
         *  UnitDelay: '<S173>/Delay Input2'
         *
         * Block description for '<S173>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S173>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_LKAExPrcs_ExitC0Dvt = ((rtb_LL_LKAExPrcs_ExitC0Dvt * x10) +
          rtb_LL_LKASWASyn_M0) - LKAS_DW.DelayInput2_DSTATE_p;

        /* Product: '<S173>/delta rise limit' incorporates:
         *  Constant: '<S165>/Constant1'
         *  SampleTimeMath: '<S173>/sample time'
         *
         * About '<S173>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = 5.0F * 0.01F;

        /* Product: '<S173>/delta fall limit' incorporates:
         *  Constant: '<S165>/Constant2'
         *  SampleTimeMath: '<S173>/sample time'
         *
         * About '<S173>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_L0_C2_h = (-5.0F) * 0.01F;

        /* Switch: '<S175>/Switch2' incorporates:
         *  Product: '<S173>/delta fall limit'
         *  Product: '<S173>/delta rise limit'
         *  RelationalOperator: '<S175>/LowerRelop1'
         *  RelationalOperator: '<S175>/UpperRelop'
         *  Switch: '<S175>/Switch'
         */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > rtb_LL_DvtSpdDet_vDvtSpdMin_C) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LL_DvtSpdDet_vDvtSpdMin_C;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < rtb_L0_C2_h) {
            /* Switch: '<S175>/Switch' incorporates:
             *  Product: '<S173>/delta fall limit'
             */
            rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_L0_C2_h;
          }
        }

        /* End of Switch: '<S175>/Switch2' */

        /* Sum: '<S173>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S173>/Delay Input2'
         *
         * Block description for '<S173>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S173>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_p = rtb_LL_LKAExPrcs_ExitC0Dvt +
          LKAS_DW.DelayInput2_DSTATE_p;

        /* Update for UnitDelay: '<S171>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_o = rtb_LL_LKASWASyn_M0;

        /* Update for Memory: '<S171>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_k = rtb_LL_LKASWASyn_M1;

        /* Update for UnitDelay: '<S174>/UD'
         *
         * Block description for '<S174>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_LKASWASyn_T2;

        /* Update for UnitDelay: '<S172>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_o4 = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for Memory: '<S172>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_m = rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Update for UnitDelay: '<S173>/Delay Input2'
         *
         * Block description for '<S173>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_p = LKAS_DW.DifferenceInputs2_p;
      } else {
        if (LKAS_DW.Subsystem_MODE_b) {
          /* Disable for Outport: '<S165>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_p = 0.0F;
          LKAS_DW.Subsystem_MODE_b = false;
        }
      }

      /* End of RelationalOperator: '<S163>/Compare' */
      /* End of Outputs for SubSystem: '<S156>/Subsystem' */

      /* Sum: '<S270>/Add2' incorporates:
       *  Memory: '<S270>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_n;

      /* Saturate: '<S270>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_ny = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_ny = 0.0F;
      } else {
        rtb_Saturation_ny = rtb_LftTTLC;
      }

      /* End of Saturate: '<S270>/Saturation' */

      /* If: '<S268>/If' incorporates:
       *  DataTypeConversion: '<S147>/Cast To Single'
       *  Inport: '<S276>/Plan'
       *  Inport: '<S276>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_i;
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_i = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S268>/If Action Subsystem' incorporates:
           *  ActionPort: '<S274>/Action Port'
           */
          /* InitializeConditions for If: '<S268>/If' incorporates:
           *  Memory: '<S274>/Memory'
           *  UnitDelay: '<S278>/Delay Input1'
           *
           * Block description for '<S278>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_n = false;
          LKAS_DW.Memory_PreviousInput_f = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S268>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S268>/If Action Subsystem' incorporates:
         *  ActionPort: '<S274>/Action Port'
         */
        /* RelationalOperator: '<S277>/Compare' incorporates:
         *  Constant: '<S277>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Lft >= 0.0F);

        /* Memory: '<S274>/Memory' */
        rtb_Plan_m = LKAS_DW.Memory_PreviousInput_f;

        /* Sum: '<S274>/Add' incorporates:
         *  Logic: '<S274>/Logical Operator'
         *  RelationalOperator: '<S274>/Relational Operator'
         *  RelationalOperator: '<S278>/FixPt Relational Operator'
         *  UnitDelay: '<S278>/Delay Input1'
         *
         * Block description for '<S278>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_g = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_n ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_ny)) ? 1 : 0)) + rtb_Plan_m;

        /* Saturate: '<S274>/Saturation' */
        if (rtb_T1_g > 5.0F) {
          rtb_Saturation_j2 = 5.0F;
        } else if (rtb_T1_g < 0.0F) {
          rtb_Saturation_j2 = 0.0F;
        } else {
          rtb_Saturation_j2 = rtb_T1_g;
        }

        /* End of Saturate: '<S274>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S274>/If Action Subsystem' */
        LKAS_IfActionSubsystem_c(rtb_Saturation_j2, rtb_Saturation_ny,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_d, &LKAS_DW.In_i,
          &LKAS_DW.IfActionSubsystem_c);

        /* End of Outputs for SubSystem: '<S274>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S274>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_n(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_g, &rtb_Plan_m);

        /* End of Outputs for SubSystem: '<S274>/If Action Subsystem2' */

        /* Switch: '<S274>/Switch' incorporates:
         *  Switch: '<S274>/Switch1'
         */
        if (rtb_Saturation_j2 > 0.0F) {
          LKAS_DW.Merge_e = LKAS_DW.In_d;
          LKAS_DW.Merge1 = LKAS_DW.In_i;
        } else {
          LKAS_DW.Merge_e = rtb_T1_g;
          LKAS_DW.Merge1 = rtb_Plan_m;
        }

        /* End of Switch: '<S274>/Switch' */

        /* Update for UnitDelay: '<S278>/Delay Input1'
         *
         * Block description for '<S278>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_n = rtb_BCM_Right_Light;

        /* Update for Memory: '<S274>/Memory' */
        LKAS_DW.Memory_PreviousInput_f = rtb_Saturation_j2;

        /* End of Outputs for SubSystem: '<S268>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S268>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S275>/Action Port'
           */
          /* InitializeConditions for If: '<S268>/If' incorporates:
           *  Memory: '<S275>/Memory'
           *  UnitDelay: '<S286>/Delay Input1'
           *
           * Block description for '<S286>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_h = false;
          LKAS_DW.Memory_PreviousInput_oh = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S268>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S268>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S275>/Action Port'
         */
        /* RelationalOperator: '<S285>/Compare' incorporates:
         *  Constant: '<S285>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Rgt <= 0.0F);

        /* Memory: '<S275>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_oh;

        /* Sum: '<S275>/Add' incorporates:
         *  Logic: '<S275>/Logical Operator'
         *  RelationalOperator: '<S275>/Relational Operator'
         *  RelationalOperator: '<S286>/FixPt Relational Operator'
         *  UnitDelay: '<S286>/Delay Input1'
         *
         * Block description for '<S286>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_a = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_h ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_ny)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S275>/Saturation' */
        if (rtb_T1_a > 5.0F) {
          rtb_Saturation_lf = 5.0F;
        } else if (rtb_T1_a < 0.0F) {
          rtb_Saturation_lf = 0.0F;
        } else {
          rtb_Saturation_lf = rtb_T1_a;
        }

        /* End of Saturate: '<S275>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S275>/If Action Subsystem' */
        LKAS_IfActionSubsystem_c(rtb_Saturation_lf, rtb_Saturation_ny,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_k, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_l);

        /* End of Outputs for SubSystem: '<S275>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S275>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_n(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_a, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S275>/If Action Subsystem2' */

        /* Switch: '<S275>/Switch' incorporates:
         *  Switch: '<S275>/Switch1'
         */
        if (rtb_Saturation_lf > 0.0F) {
          LKAS_DW.Merge_e = LKAS_DW.In_k;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_e = rtb_T1_a;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S275>/Switch' */

        /* Update for UnitDelay: '<S286>/Delay Input1'
         *
         * Block description for '<S286>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_h = rtb_BCM_Right_Light;

        /* Update for Memory: '<S275>/Memory' */
        LKAS_DW.Memory_PreviousInput_oh = rtb_Saturation_lf;

        /* End of Outputs for SubSystem: '<S268>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S268>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S276>/Action Port'
         */
        LKAS_DW.Merge_e = rtb_Saturation6;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S268>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S268>/If' */

      /* Saturate: '<S162>/Saturation6' */
      if (LKAS_DW.Merge_e > 0.5F) {
        rtb_LL_LKASWASyn_M0 = 0.5F;
      } else if (LKAS_DW.Merge_e < 0.2F) {
        rtb_LL_LKASWASyn_M0 = 0.2F;
      } else {
        rtb_LL_LKASWASyn_M0 = LKAS_DW.Merge_e;
      }

      /* End of Saturate: '<S162>/Saturation6' */

      /* Product: '<S162>/Divide' incorporates:
       *  Product: '<S162>/Divide4'
       *  Product: '<S271>/Divide'
       *  Sum: '<S162>/Add2'
       */
      rtb_LL_LKASWASyn_M0 = (rtb_Saturation_ny - LKAS_DW.Merge_e) /
        rtb_LL_LKASWASyn_M0;
      rtb_Gain2_g = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S162>/Saturation2' */
      if (rtb_Gain2_g > 1.0F) {
        rtb_Gain2_g = 1.0F;
      } else {
        if (rtb_Gain2_g < 0.0F) {
          rtb_Gain2_g = 0.0F;
        }
      }

      /* End of Saturate: '<S162>/Saturation2' */

      /* Sum: '<S162>/Add5' incorporates:
       *  Constant: '<S162>/Constant2'
       */
      rtb_LL_LKASWASyn_M1 = 1.0F - rtb_Gain2_g;

      /* Memory: '<S253>/Memory' */
      rtb_Divide3_n = LKAS_DW.Memory_PreviousInput_lt;

      /* Product: '<S320>/Z*Z' incorporates:
       *  Product: '<S317>/Z*Z'
       */
      rtb_LL_LKASWASyn_T2 = rtb_LL_HdAgPrvwT_C * rtb_LL_HdAgPrvwT_C;

      /* Sum: '<S253>/Add1' incorporates:
       *  Gain: '<S299>/Gain2'
       *  Product: '<S253>/Divide'
       *  Product: '<S253>/Divide1'
       *  Product: '<S317>/Product3'
       *  Product: '<S317>/Product4'
       *  Product: '<S320>/Product3'
       *  Product: '<S320>/Product4'
       *  Product: '<S320>/Z*Z'
       *  Sum: '<S299>/Add2'
       *  Sum: '<S317>/Add'
       *  Sum: '<S320>/Add'
       */
      rtb_Add1_l1 = ((((((rtb_Add_e1_tmp * rtb_LL_HdAgPrvwT_C) +
                         rtb_LL_CompHdAg_C) + (rtb_L0_C3_g * rtb_LL_LKASWASyn_T2))
                       + (((rtb_Add_g_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_fx)
                          + (rtb_R0_C3_j * rtb_LL_LKASWASyn_T2))) * 0.5F) *
                     LKAS_ConstB.Divide2_nn) + (LKAS_ConstB.Add2_p *
        rtb_Divide3_n);

      /* Product: '<S251>/Divide3' incorporates:
       *  Gain: '<S297>/Gain1'
       */
      rtb_Divide3_n = rtb_LL_HdAgPrvwT_C * rtb_LL_ThresDet_tiTTLCThresLDW;

      /* Gain: '<S251>/kph to mps' */
      rtb_kphtomps_po = rtb_Abs_n_tmp;

      /* MATLAB Function: '<S251>/Saturable Gain Lut (SatGainLut)' */
      LKAS_SaturableGainLutSatGainLut(rtb_IMAPve_g_ESC_VehSpd,
        rtb_LL_LFClb_TFC_KpVehSpdLwr_C, rtb_LL_LFClb_TFC_KpVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KpV1_C, rtb_LL_LFClb_TFC_KpV2_C, &rtb_Gain_i);

      /* Switch: '<S664>/Switch32' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_PrvwT_C=2'
       */
      if (LKAS_ConstB.DataTypeConversion15_k != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_k;
      } else {
        x10 = LL_LFClb_TFC_PrvwT_C;
      }

      /* End of Switch: '<S664>/Switch32' */

      /* Product: '<S251>/Divide1' */
      rtb_LftTTLC = x10 * rtb_kphtomps_po;

      /* Switch: '<S664>/Switch30' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_KpKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_e != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_e;
      } else {
        x10 = LL_LFClb_TFC_KpKlat_C;
      }

      /* End of Switch: '<S664>/Switch30' */

      /* Saturate: '<S251>/Saturation' */
      if (rtb_LftTTLC > 40.0F) {
        rtb_LftTTLC = 40.0F;
      } else {
        if (rtb_LftTTLC < 5.0F) {
          rtb_LftTTLC = 5.0F;
        }
      }

      /* End of Saturate: '<S251>/Saturation' */

      /* Sum: '<S251>/Subtract2' incorporates:
       *  Sum: '<S251>/Add1'
       */
      rtb_LL_HdAgPrvwT_C = rtb_Add1_l1 - rtb_Divide3_n;

      /* Product: '<S251>/Product4' incorporates:
       *  Gain: '<S298>/Gain1'
       *  Product: '<S251>/Divide'
       *  Product: '<S251>/Product1'
       *  Sum: '<S251>/Subtract1'
       *  Sum: '<S251>/Subtract2'
       *  Sum: '<S298>/Add1'
       */
      rtb_L0_C1_fx = (((((rtb_Add_c + rtb_Add_o) * 0.5F) / rtb_LftTTLC) * x10) -
                      rtb_LL_HdAgPrvwT_C) * rtb_Gain_i;

      /* Switch: '<S664>/Switch19' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_Kp_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion26_j != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion26_j;
      } else {
        x10 = LL_LFClb_TFC_Kp_C;
      }

      /* End of Switch: '<S664>/Switch19' */

      /* Product: '<S251>/Product2' */
      rtb_Merge_n = rtb_L0_C1_fx * x10;

      /* Saturate: '<S251>/Saturation2' */
      if (rtb_Merge_n > 360.0F) {
        rtb_Merge_n = 360.0F;
      } else {
        if (rtb_Merge_n < (-360.0F)) {
          rtb_Merge_n = (-360.0F);
        }
      }

      /* End of Saturate: '<S251>/Saturation2' */

      /* Abs: '<S251>/Abs' incorporates:
       *  Gain: '<S297>/Gain1'
       */
      rtb_kphTomps_l = fabsf(rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Saturate: '<S251>/Saturation1' */
      if (rtb_kphTomps_l > 0.004F) {
        rtb_kphTomps_l = 0.004F;
      } else {
        if (rtb_kphTomps_l < 1.0E-5F) {
          rtb_kphTomps_l = 1.0E-5F;
        }
      }

      /* End of Saturate: '<S251>/Saturation1' */

      /* Switch: '<S664>/Switch39' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_KiMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_KiMaxSWA_C;
      }

      /* End of Switch: '<S664>/Switch39' */

      /* Sum: '<S251>/Add3' incorporates:
       *  Constant: '<S251>/Constant3'
       *  Constant: '<S251>/Constant4'
       *  Product: '<S251>/Divide4'
       *  Sum: '<S251>/Add5'
       */
      rtb_kphTomps_l = (((x10 - 1.0F) * rtb_kphTomps_l) / 0.004F) + 1.0F;

      /* Sum: '<S259>/Add2' incorporates:
       *  Memory: '<S259>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_h;

      /* Saturate: '<S259>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_c = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_c = 0.0F;
      } else {
        rtb_Saturation_c = rtb_LftTTLC;
      }

      /* End of Saturate: '<S259>/Saturation' */

      /* Switch: '<S251>/Switch2' incorporates:
       *  Product: '<S251>/Divide2'
       *  Sum: '<S251>/Add'
       *  Sum: '<S251>/Add2'
       *  Switch: '<S664>/Switch40'
       *  UnitDelay: '<S251>/Unit Delay'
       */
      if ((rtb_Saturation_c - rtb_Saturation6) >= 0.0F) {
        /* Switch: '<S664>/Switch40' incorporates:
         *  Constant: '<S664>/LL_LFClb_TFC_Ki_C=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_no = (rtb_L0_C1_fx * x10) + LKAS_DW.UnitDelay_DSTATE_f;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S664>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S664>/Switch40' incorporates:
           *  Constant: '<S664>/LL_LFClb_TFC_Ki_C=0.01'
           */
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_no = rtb_L0_C1_fx * x10;
      }

      /* End of Switch: '<S251>/Switch2' */

      /* Gain: '<S251>/Gain' */
      rtb_L0_C1_fx = (-1.0F) * rtb_kphTomps_l;

      /* Switch: '<S256>/Switch' incorporates:
       *  RelationalOperator: '<S256>/UpperRelop'
       */
      if (rtb_Switch2_no < rtb_L0_C1_fx) {
        rtb_Switch_p3 = rtb_L0_C1_fx;
      } else {
        rtb_Switch_p3 = rtb_Switch2_no;
      }

      /* End of Switch: '<S256>/Switch' */

      /* Switch: '<S256>/Switch2' incorporates:
       *  RelationalOperator: '<S256>/LowerRelop1'
       */
      if (rtb_Switch2_no > rtb_kphTomps_l) {
        rtb_Switch2_i = rtb_kphTomps_l;
      } else {
        rtb_Switch2_i = rtb_Switch_p3;
      }

      /* End of Switch: '<S256>/Switch2' */

      /* Product: '<S162>/Divide1' incorporates:
       *  Sum: '<S162>/Add3'
       */
      rtb_LL_CompHdAg_C = (rtb_Merge_n + rtb_Switch2_i) * rtb_Gain2_g;

      /* Switch: '<S664>/Switch49' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_KdMaxSWA_C=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_KdMaxSWA_C;
      }

      /* End of Switch: '<S664>/Switch49' */

      /* Product: '<S251>/Divide8' incorporates:
       *  Constant: '<S251>/Constant7'
       *  Constant: '<S251>/Constant8'
       *  Sum: '<S251>/Add4'
       */
      rtb_kphTomps_l = ((180.0F - rtb_kphtomps_po) * x10) / 120.0F;

      /* MATLAB Function: '<S251>/Saturable Gain Lut (SatGainLut)1' */
      LKAS_SaturableGainLutSatGainLut(rtb_kphtomps_po,
        rtb_LL_LFClb_TFC_KdVehSpdLwr_C, rtb_LL_LFClb_TFC_KdVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KdV1_C, rtb_LL_LFClb_TFC_KdV2_C, &rtb_Gain_i);

      /* Product: '<S258>/Divide1' incorporates:
       *  Constant: '<S258>/Constant3'
       *  Sum: '<S258>/Add4'
       */
      rtb_Merge_n = (1.0F + rtb_LL_LFClb_TFC_KdBalance_C) * rtb_Gain_i;

      /* Gain: '<S258>/Gain' incorporates:
       *  Abs: '<S258>/Abs'
       */
      rtb_L0_C1_fx = fabsf(rtb_R0_C1_d) * 0.5F;

      /* Gain: '<S258>/Gain1' incorporates:
       *  Sum: '<S258>/Add2'
       */
      rtb_Gain1_n = (rtb_L0_C0_b + rtb_R0_C0_a) * 0.5F;

      /* Gain: '<S258>/Gain2' */
      rtb_Gain2_g = (-1.0F) * rtb_L0_C1_fx;

      /* Switch: '<S263>/Switch' incorporates:
       *  RelationalOperator: '<S263>/UpperRelop'
       */
      if (rtb_Gain1_n < rtb_Gain2_g) {
        rtb_Switch_oe = rtb_Gain2_g;
      } else {
        rtb_Switch_oe = rtb_Gain1_n;
      }

      /* End of Switch: '<S263>/Switch' */

      /* Switch: '<S263>/Switch2' incorporates:
       *  RelationalOperator: '<S263>/LowerRelop1'
       */
      if (rtb_Gain1_n > rtb_L0_C1_fx) {
        rtb_Switch2_jw = rtb_L0_C1_fx;
      } else {
        rtb_Switch2_jw = rtb_Switch_oe;
      }

      /* End of Switch: '<S263>/Switch2' */

      /* Product: '<S258>/Divide4' */
      rtb_L0_C1_fx = (rtb_Switch2_jw / rtb_L0_C1_fx) *
        rtb_LL_LFClb_TFC_KdBalance_C;

      /* Product: '<S258>/Divide5' incorporates:
       *  Constant: '<S258>/Constant2'
       *  Sum: '<S258>/Add5'
       */
      rtb_Divide5_j = (1.0F + rtb_L0_C1_fx) * rtb_Gain_i;

      /* Product: '<S258>/Divide2' incorporates:
       *  Constant: '<S258>/Constant2'
       *  Sum: '<S258>/Add1'
       */
      rtb_Divide2_e = (1.0F - rtb_L0_C1_fx) * rtb_Gain_i;

      /* Sum: '<S265>/Add' incorporates:
       *  Constant: '<S265>/Constant'
       *  Memory: '<S265>/Memory'
       */
      rtb_Saturation_nn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_h4));

      /* Saturate: '<S265>/Saturation1' */
      if (rtb_Saturation_nn < ((uint16)10000U)) {
        rtb_Saturation1_a = rtb_Saturation_nn;
      } else {
        rtb_Saturation1_a = ((uint16)10000U);
      }

      /* End of Saturate: '<S265>/Saturation1' */

      /* If: '<S265>/If' incorporates:
       *  Constant: '<S265>/Constant2'
       *  DataTypeConversion: '<S147>/Cast To Single'
       *  Inport: '<S266>/In'
       */
      if (rtb_Saturation1_a == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S265>/if action ' incorporates:
         *  ActionPort: '<S266>/Action Port'
         */
        LKAS_DW.In_n = LKAS_DW.LKASM_stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S265>/if action ' */
      }

      /* End of If: '<S265>/If' */

      /* If: '<S258>/If' incorporates:
       *  Inport: '<S262>/In1'
       */
      if (((sint32)LKAS_DW.In_n) == 1) {
        /* Outputs for IfAction SubSystem: '<S258>/If Action Subsystem' incorporates:
         *  ActionPort: '<S260>/Action Port'
         */
        LKAS_IfActionSubsystem_g(rtb_Divide2_e, &rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S258>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_n) == 2) {
        /* Outputs for IfAction SubSystem: '<S258>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S261>/Action Port'
         */
        LKAS_IfActionSubsystem_g(rtb_Divide5_j, &rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S258>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S258>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S262>/Action Port'
         */
        rtb_Merge_g = rtb_Gain_i;

        /* End of Outputs for SubSystem: '<S258>/If Action Subsystem2' */
      }

      /* End of If: '<S258>/If' */

      /* Product: '<S258>/Divide3' incorporates:
       *  Constant: '<S258>/Constant1'
       *  Sum: '<S258>/Add3'
       */
      rtb_L0_C1_fx = (1.0F - rtb_LL_LFClb_TFC_KdBalance_C) * rtb_Gain_i;

      /* Switch: '<S264>/Switch' incorporates:
       *  RelationalOperator: '<S264>/UpperRelop'
       */
      if (rtb_Merge_g < rtb_L0_C1_fx) {
        rtb_Switch_ei = rtb_L0_C1_fx;
      } else {
        rtb_Switch_ei = rtb_Merge_g;
      }

      /* End of Switch: '<S264>/Switch' */

      /* Switch: '<S264>/Switch2' incorporates:
       *  RelationalOperator: '<S264>/LowerRelop1'
       */
      if (rtb_Merge_g > rtb_Merge_n) {
        rtb_Switch2_hf = rtb_Merge_n;
      } else {
        rtb_Switch2_hf = rtb_Switch_ei;
      }

      /* End of Switch: '<S264>/Switch2' */

      /* Product: '<S251>/Divide7' incorporates:
       *  Gain: '<S251>/Gain1'
       */
      rtb_Divide7 = (rtb_LL_HdAgPrvwT_C * (-1.0F)) * rtb_Switch2_hf;

      /* Gain: '<S251>/Gain3' */
      rtb_Merge_n = (-1.0F) * rtb_kphTomps_l;

      /* Switch: '<S257>/Switch' incorporates:
       *  RelationalOperator: '<S257>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_Merge_n) {
        rtb_Switch_jp = rtb_Merge_n;
      } else {
        rtb_Switch_jp = rtb_Divide7;
      }

      /* End of Switch: '<S257>/Switch' */

      /* Switch: '<S257>/Switch2' incorporates:
       *  RelationalOperator: '<S257>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_kphTomps_l) {
        rtb_Switch2_b = rtb_kphTomps_l;
      } else {
        rtb_Switch2_b = rtb_Switch_jp;
      }

      /* End of Switch: '<S257>/Switch2' */

      /* Product: '<S162>/Divide4' */
      rtb_kphTomps_l = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S162>/Saturation1' */
      if (rtb_kphTomps_l > 1.0F) {
        rtb_kphTomps_l = 1.0F;
      } else {
        if (rtb_kphTomps_l < 0.0F) {
          rtb_kphTomps_l = 0.0F;
        }
      }

      /* End of Saturate: '<S162>/Saturation1' */

      /* Product: '<S162>/Divide2' */
      rtb_L0_C0_b = rtb_Switch2_b * rtb_kphTomps_l;

      /* Saturate: '<S271>/Saturation4' */
      if (rtb_LL_LKASWASyn_M0 > 1.0F) {
        rtb_LL_LKASWASyn_M0 = 1.0F;
      } else {
        if (rtb_LL_LKASWASyn_M0 < 0.0F) {
          rtb_LL_LKASWASyn_M0 = 0.0F;
        }
      }

      /* End of Saturate: '<S271>/Saturation4' */

      /* Product: '<S162>/Divide5' incorporates:
       *  Constant: '<S271>/Constant1'
       *  Product: '<S271>/Divide8'
       *  Sum: '<S271>/Add1'
       */
      rtb_kphTomps_l = ((LKAS_ConstB.Add3 * rtb_LL_LKASWASyn_M0) + 0.0F) *
        rtb_LL_LKAExPrcs_tiExitTime1;

      /* Saturate: '<S162>/Saturation3' */
      if (rtb_Merge > 0.004F) {
        rtb_Merge_n = 0.004F;
      } else if (rtb_Merge < (-0.004F)) {
        rtb_Merge_n = (-0.004F);
      } else {
        rtb_Merge_n = rtb_Merge;
      }

      /* End of Saturate: '<S162>/Saturation3' */

      /* Product: '<S162>/Divide3' */
      rtb_LftTTLC = rtb_Saturation_ny / LKAS_DW.Merge_e;

      /* Saturate: '<S162>/Saturation' */
      if (rtb_LftTTLC > 1.0F) {
        rtb_LftTTLC = 1.0F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S162>/Saturation' */

      /* Sum: '<S162>/Add4' incorporates:
       *  Product: '<S162>/Divide6'
       *  Product: '<S162>/Divide7'
       *  Sum: '<S162>/Add6'
       */
      rtb_L0_C0_b = (((((LKAS_DW.Merge1 + rtb_LL_LKAExPrcs_tiExitTime1) *
                        rtb_LL_LKASWASyn_M1) + rtb_LL_CompHdAg_C) + rtb_L0_C0_b)
                     + rtb_kphTomps_l) + (LKAS_DW.DifferenceInputs2_p *
        rtb_LftTTLC);

      /* Memory: '<S269>/Memory3' */
      rtb_kphTomps_l = LKAS_DW.Memory3_PreviousInput_a;

      /* Sum: '<S269>/Add2' incorporates:
       *  Constant: '<S269>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_kphTomps_l += 1.0F;

      /* Saturate: '<S269>/Saturation' */
      if (rtb_kphTomps_l > 50.0F) {
        rtb_Saturation_f = 50.0F;
      } else if (rtb_kphTomps_l < 0.0F) {
        rtb_Saturation_f = 0.0F;
      } else {
        rtb_Saturation_f = rtb_kphTomps_l;
      }

      /* End of Saturate: '<S269>/Saturation' */

      /* Switch: '<S269>/Switch' incorporates:
       *  Constant: '<S162>/Constant1'
       *  Product: '<S269>/Divide'
       *  Product: '<S269>/Divide1'
       *  Sum: '<S269>/Add'
       *  Sum: '<S269>/Add1'
       *  UnitDelay: '<S269>/Unit Delay'
       */
      if (rtb_Saturation_f > 30.0F) {
        rtb_Switch_ld = ((rtb_LKA_SampleTime / 0.1F) * (rtb_L0_C0_b -
          LKAS_DW.UnitDelay_DSTATE_d)) + LKAS_DW.UnitDelay_DSTATE_d;
      } else {
        rtb_Switch_ld = rtb_L0_C0_b;
      }

      /* End of Switch: '<S269>/Switch' */

      /* Switch: '<S664>/Switch17' incorporates:
       *  Constant: '<S664>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S664>/Switch17' */

      /* Sum: '<S159>/Add' */
      rtb_Add_fk = (rtb_Switch_ld - x10) + LKAS_DW.Saturation_h;

      /* Sum: '<S159>/Add1' */
      rtb_kphTomps_l = rtb_LL_LKAExPrcs_tiExitTime1 +
        rtb_LL_LDW_LatestWarnLine_C;

      /* Sum: '<S159>/Add2' incorporates:
       *  Gain: '<S159>/Gain2'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 += (-1.0F) * rtb_LL_LDW_LatestWarnLine_C;

      /* Switch: '<S247>/Switch' incorporates:
       *  RelationalOperator: '<S247>/UpperRelop'
       */
      if (rtb_Add_fk < rtb_LL_LKAExPrcs_tiExitTime1) {
        rtb_Switch_gl = rtb_LL_LKAExPrcs_tiExitTime1;
      } else {
        rtb_Switch_gl = rtb_Add_fk;
      }

      /* End of Switch: '<S247>/Switch' */

      /* Switch: '<S247>/Switch2' incorporates:
       *  RelationalOperator: '<S247>/LowerRelop1'
       */
      if (rtb_Add_fk > rtb_kphTomps_l) {
        rtb_Switch2_hr = rtb_kphTomps_l;
      } else {
        rtb_Switch2_hr = rtb_Switch_gl;
      }

      /* End of Switch: '<S247>/Switch2' */

      /* Sum: '<S246>/Add1' incorporates:
       *  Constant: '<S246>/Constant'
       *  Memory: '<S246>/Memory'
       */
      rtb_Saturation_nn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_li));

      /* Switch: '<S246>/Switch' incorporates:
       *  Constant: '<S246>/LatchTime_SY'
       *  RelationalOperator: '<S246>/Relational Operator'
       *  UnitDelay: '<S246>/Delay Input2'
       *
       * Block description for '<S246>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_nn <= ((uint16)1U)) {
        rtb_kphTomps_l = rtb_Switch2_hr;
      } else {
        rtb_kphTomps_l = LKAS_DW.DelayInput2_DSTATE_g;
      }

      /* End of Switch: '<S246>/Switch' */

      /* Sum: '<S246>/Difference Inputs1'
       *
       * Block description for '<S246>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_c = rtb_Switch2_hr - rtb_kphTomps_l;

      /* SampleTimeMath: '<S246>/sample time'
       *
       * About '<S246>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_Merge_n = 0.01F;

      /* Product: '<S246>/delta rise limit' incorporates:
       *  Gain: '<S159>/Gain3'
       */
      rtb_L0_C1_fx = (1.4F * rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_Merge_n;

      /* Product: '<S246>/delta fall limit' incorporates:
       *  Gain: '<S159>/Gain1'
       */
      rtb_Merge_n *= (-1.4F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S248>/Switch' incorporates:
       *  RelationalOperator: '<S248>/UpperRelop'
       */
      if (rtb_UkYk1_c < rtb_Merge_n) {
        rtb_Switch_m = rtb_Merge_n;
      } else {
        rtb_Switch_m = rtb_UkYk1_c;
      }

      /* End of Switch: '<S248>/Switch' */

      /* Switch: '<S248>/Switch2' incorporates:
       *  RelationalOperator: '<S248>/LowerRelop1'
       */
      if (rtb_UkYk1_c > rtb_L0_C1_fx) {
        rtb_Switch2_hb = rtb_L0_C1_fx;
      } else {
        rtb_Switch2_hb = rtb_Switch_m;
      }

      /* End of Switch: '<S248>/Switch2' */

      /* Sum: '<S246>/Difference Inputs2'
       *
       * Block description for '<S246>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_hb + rtb_kphTomps_l;

      /* Saturate: '<S246>/Saturation2' */
      if (rtb_Saturation_nn < ((uint16)10000U)) {
        rtb_Saturation2_i = rtb_Saturation_nn;
      } else {
        rtb_Saturation2_i = ((uint16)10000U);
      }

      /* End of Saturate: '<S246>/Saturation2' */

      /* DataTypeConversion: '<S160>/CastLKA3' */
      LKAS_DW.T1_Mon_n = LKAS_DW.Merge_e;

      /* If: '<S199>/If' incorporates:
       *  DataTypeConversion: '<S147>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S199>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S217>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_Add_c, &rtb_Merge_gk);

        /* End of Outputs for SubSystem: '<S199>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S199>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S216>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_Add_o, &rtb_Merge_gk);

        /* End of Outputs for SubSystem: '<S199>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S199>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S218>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_gk);

        /* End of Outputs for SubSystem: '<S199>/If Action Subsystem3' */
      }

      /* End of If: '<S199>/If' */

      /* If: '<S201>/If' incorporates:
       *  DataTypeConversion: '<S147>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S201>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S223>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_phiHdAg_Lft, &rtb_Merge_p);

        /* End of Outputs for SubSystem: '<S201>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S201>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S222>/Action Port'
         */
        LKAS_IfActionSubsystem2_p(rtb_phiHdAg_Rgt, &rtb_Merge_p);

        /* End of Outputs for SubSystem: '<S201>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S201>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S224>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_p);

        /* End of Outputs for SubSystem: '<S201>/If Action Subsystem3' */
      }

      /* End of If: '<S201>/If' */

      /* DataTypeConversion: '<S241>/Data Type Conversion' incorporates:
       *  Constant: '<S242>/Constant'
       *  RelationalOperator: '<S242>/Compare'
       */
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)((rtb_Merge <= 0.0F) ? 1 : 0);

      /* Gain: '<S237>/kph To mps' */
      rtb_kphTomps_l = rtb_Abs_n_tmp;

      /* Switch: '<S664>/Switch5' incorporates:
       *  Constant: '<S664>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_n != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_n;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S664>/Switch5' */

      /* Product: '<S241>/Divide' */
      rtb_Merge_n = (rtb_Merge * rtb_kphTomps_l) * x10;

      /* Abs: '<S241>/Abs1' incorporates:
       *  Abs: '<S241>/Abs'
       */
      rtb_L0_C0_b = fabsf(rtb_Merge_n);
      rtb_Abs1_a = rtb_L0_C0_b;

      /* Abs: '<S241>/Abs' */
      rtb_Abs_a = rtb_L0_C0_b;

      /* If: '<S241>/If' incorporates:
       *  DataTypeConversion: '<S147>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) && (((sint32)
            rtb_IMAPve_d_Rrg_TYPE_BACK) == 0)) {
        /* Outputs for IfAction SubSystem: '<S241>/If Action Subsystem' incorporates:
         *  ActionPort: '<S243>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_a, &rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S241>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) && (((sint32)
                   rtb_IMAPve_d_Rrg_TYPE_BACK) == 1)) {
        /* Outputs for IfAction SubSystem: '<S241>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S245>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_a, &rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S241>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S241>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S244>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S241>/If Action Subsystem2' */
      }

      /* End of If: '<S241>/If' */

      /* Switch: '<S664>/Switch6' incorporates:
       *  Constant: '<S664>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_k != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_k;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S664>/Switch6' */

      /* Sum: '<S237>/Add1' incorporates:
       *  Product: '<S237>/Divide'
       *  Product: '<S237>/Divide1'
       */
      rtb_Add1_k = (((1.0F / x10) * rtb_R0_C1_d) / rtb_kphTomps_l) + rtb_Merge_n;

      /* If: '<S193>/If' incorporates:
       *  Constant: '<S240>/Constant2'
       *  DataTypeConversion: '<S147>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem' incorporates:
         *  ActionPort: '<S238>/Action Port'
         */
        /* Gain: '<S238>/Gain2' */
        rtb_Merge_f = (-1.0F) * rtb_Add1_k;

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S239>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_k, &rtb_Merge_f);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S240>/Action Port'
         */
        rtb_Merge_f = 0.0F;

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem2' */
      }

      /* End of If: '<S193>/If' */

      /* Sum: '<S202>/Add' incorporates:
       *  Constant: '<S202>/Constant'
       *  Memory: '<S202>/Memory'
       */
      rtb_Add_jv = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ny));

      /* Saturate: '<S202>/Saturation1' */
      if (rtb_Add_jv < ((uint16)10000U)) {
        rtb_Saturation_nn = rtb_Add_jv;
      } else {
        rtb_Saturation_nn = ((uint16)10000U);
      }

      /* End of Saturate: '<S202>/Saturation1' */

      /* If: '<S202>/If' incorporates:
       *  Constant: '<S202>/Constant2'
       */
      if (rtb_Saturation_nn == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S202>/if action ' incorporates:
         *  ActionPort: '<S225>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_f, &rtb_In_n);

        /* End of Outputs for SubSystem: '<S202>/if action ' */
      }

      /* End of If: '<S202>/If' */

      /* Sum: '<S204>/Add' incorporates:
       *  Constant: '<S204>/Constant'
       *  Memory: '<S204>/Memory'
       */
      rtb_Saturation_nn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_nn));

      /* Saturate: '<S204>/Saturation1' */
      if (rtb_Saturation_nn < ((uint16)10000U)) {
        rtb_Saturation1_l = rtb_Saturation_nn;
      } else {
        rtb_Saturation1_l = ((uint16)10000U);
      }

      /* End of Saturate: '<S204>/Saturation1' */

      /* If: '<S204>/If' incorporates:
       *  Constant: '<S204>/Constant2'
       */
      if (rtb_Saturation1_l == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S204>/if action ' incorporates:
         *  ActionPort: '<S227>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_gk, &rtb_In_d);

        /* End of Outputs for SubSystem: '<S204>/if action ' */
      }

      /* End of If: '<S204>/If' */

      /* Sum: '<S205>/Add' incorporates:
       *  Constant: '<S205>/Constant'
       *  Memory: '<S205>/Memory'
       */
      rtb_Saturation_nn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_hp));

      /* Saturate: '<S205>/Saturation1' */
      if (rtb_Saturation_nn < ((uint16)10000U)) {
        rtb_Saturation1_h = rtb_Saturation_nn;
      } else {
        rtb_Saturation1_h = ((uint16)10000U);
      }

      /* End of Saturate: '<S205>/Saturation1' */

      /* If: '<S205>/If' incorporates:
       *  Constant: '<S205>/Constant2'
       */
      if (rtb_Saturation1_h == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S205>/if action ' incorporates:
         *  ActionPort: '<S228>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_p, &rtb_In);

        /* End of Outputs for SubSystem: '<S205>/if action ' */
      }

      /* End of If: '<S205>/If' */

      /* DataTypeConversion: '<S190>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_IMAPve_g_ESC_VehSpd;

      /* DataTypeConversion: '<S160>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon_n = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S194>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S177>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_e) {
          /* Disable for Outport: '<S179>/Out' */
          LKAS_DW.RelationalOperator_dq = false;
          LKAS_DW.SumCondition1_MODE_e = false;
        }

        /* End of Disable for SubSystem: '<S177>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S178>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_m.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_p,
            &LKAS_DW.SumCondition1_m);
        }

        /* End of Disable for SubSystem: '<S178>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S178>/Sum Condition' */
        if (LKAS_DW.SumCondition_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_hz,
            &LKAS_DW.SumCondition_c);
        }

        /* End of Disable for SubSystem: '<S178>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S178>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S187>/Out' */
          LKAS_DW.RelationalOperator_c = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S178>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S164>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_p) {
          LKAS_DW.SumCondition2_MODE_p = false;
        }

        /* End of Disable for SubSystem: '<S164>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S156>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_b) {
          /* Disable for Outport: '<S165>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_p = 0.0F;
          LKAS_DW.Subsystem_MODE_b = false;
        }

        /* End of Disable for SubSystem: '<S156>/Subsystem' */

        /* Disable for If: '<S268>/If' */
        LKAS_DW.If_ActiveSubsystem_i = -1;

        /* Disable for Outport: '<S147>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S147>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S147>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S147>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_o = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_n = 0.0F;
        LKAS_DW.T1_Mon_n = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon_o;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon_n;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.T1_Mon = LKAS_DW.T1_Mon_n;

    /* Switch: '<S602>/Switch1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  Delay: '<S602>/Delay'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S613>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(LKAS_DW.Delay_DSTATE_d | ((uint8)1U));
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_d)) | ((uint8)1U))));
    }

    /* End of Switch: '<S602>/Switch1' */

    /* Switch: '<S602>/Switch2' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean2'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S614>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)2U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)2U))));
    }

    /* End of Switch: '<S602>/Switch2' */

    /* Switch: '<S602>/Switch3' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean3'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S607>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S607>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S607>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S615>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)4U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)4U))));
    }

    /* End of Switch: '<S602>/Switch3' */

    /* Switch: '<S602>/Switch4' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean9'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S608>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S608>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S608>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)8U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)8U))));
    }

    /* End of Switch: '<S602>/Switch4' */

    /* Switch: '<S602>/Switch5' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean10'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S610>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S610>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S610>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)16U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)16U))));
    }

    /* End of Switch: '<S602>/Switch5' */

    /* Switch: '<S602>/Switch6' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean11'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S609>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S609>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S609>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)32U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)32U))));
    }

    /* End of Switch: '<S602>/Switch6' */

    /* Switch: '<S602>/Switch7' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean12'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S611>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S611>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S611>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)64U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)64U))));
    }

    /* End of Switch: '<S602>/Switch7' */

    /* Switch: '<S602>/Switch8' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean21'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S612>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S612>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S612>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_Switch8 = (uint8)(rtb_IMAPve_d_Rrg_TYPE_BACK | ((uint8)128U));
    } else {
      rtb_Switch8 = (uint8)(~((uint8)(((uint8)(~rtb_IMAPve_d_Rrg_TYPE_BACK)) |
        ((uint8)128U))));
    }

    /* End of Switch: '<S602>/Switch8' */

    /* Switch: '<S603>/Switch1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean15'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  Delay: '<S603>/Delay'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S629>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(LKAS_DW.Delay_DSTATE_a | ((uint8)1U));
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_a)) | ((uint8)1U))));
    }

    /* End of Switch: '<S603>/Switch1' */

    /* Switch: '<S603>/Switch2' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean16'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S630>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)2U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)2U))));
    }

    /* End of Switch: '<S603>/Switch2' */

    /* Switch: '<S603>/Switch3' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean19'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S631>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)4U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)4U))));
    }

    /* End of Switch: '<S603>/Switch3' */

    /* Switch: '<S603>/Switch4' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean20'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S624>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S624>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S624>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)8U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)8U))));
    }

    /* End of Switch: '<S603>/Switch4' */

    /* Switch: '<S603>/Switch5' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean35'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S626>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S626>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S626>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)16U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)16U))));
    }

    /* End of Switch: '<S603>/Switch5' */

    /* Switch: '<S603>/Switch6' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean36'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S625>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S625>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S625>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator1'
     */
    if (rtb_Saturation1 != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)32U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)32U))));
    }

    /* End of Switch: '<S603>/Switch6' */

    /* Switch: '<S603>/Switch7' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S627>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S627>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S627>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator1'
     */
    if (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)64U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)64U))));
    }

    /* End of Switch: '<S603>/Switch7' */

    /* Switch: '<S603>/Switch8' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S628>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S628>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S628>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator1'
     */
    if (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) {
      rtb_Switch8_c = (uint8)(rtb_IMAPve_d_Rrg_TYPE_BACK | ((uint8)128U));
    } else {
      rtb_Switch8_c = (uint8)(~((uint8)(((uint8)(~rtb_IMAPve_d_Rrg_TYPE_BACK)) |
        ((uint8)128U))));
    }

    /* End of Switch: '<S603>/Switch8' */

    /* Switch: '<S604>/Switch1' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean2'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  Delay: '<S604>/Delay'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S645>/FixPt Bitwise Operator1'
     */
    if (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(LKAS_DW.Delay_DSTATE_b | ((uint8)1U));
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_b)) | ((uint8)1U))));
    }

    /* End of Switch: '<S604>/Switch1' */

    /* Switch: '<S604>/Switch2' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean3'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S646>/FixPt Bitwise Operator1'
     */
    if (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)2U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)2U))));
    }

    /* End of Switch: '<S604>/Switch2' */

    /* Switch: '<S604>/Switch3' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean4'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S647>/FixPt Bitwise Operator1'
     */
    if (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)4U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)4U))));
    }

    /* End of Switch: '<S604>/Switch3' */

    /* Switch: '<S604>/Switch4' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean6'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S640>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S640>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S640>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S648>/FixPt Bitwise Operator1'
     */
    if (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)8U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)8U))));
    }

    /* End of Switch: '<S604>/Switch4' */

    /* Switch: '<S604>/Switch5' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean8'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S642>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S642>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S642>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S649>/FixPt Bitwise Operator1'
     */
    if (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)16U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)16U))));
    }

    /* End of Switch: '<S604>/Switch5' */

    /* Switch: '<S604>/Switch6' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean9'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S641>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S641>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S641>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S650>/FixPt Bitwise Operator1'
     */
    if (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)32U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)32U))));
    }

    /* End of Switch: '<S604>/Switch6' */

    /* Switch: '<S604>/Switch7' incorporates:
     *  S-Function (sfix_bitop): '<S643>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S643>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S643>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S651>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LDW_Fault) {
      rtb_IMAPve_d_Rrg_TYPE_BACK |= ((uint8)64U);
    } else {
      rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_Rrg_TYPE_BACK)) | ((uint8)64U))));
    }

    /* End of Switch: '<S604>/Switch7' */

    /* Switch: '<S604>/Switch8' incorporates:
     *  S-Function (sfix_bitop): '<S644>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S644>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S644>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S652>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LKA_Fault) {
      rtb_Switch8_j = (uint8)(rtb_IMAPve_d_Rrg_TYPE_BACK | ((uint8)128U));
    } else {
      rtb_Switch8_j = (uint8)(~((uint8)(((uint8)(~rtb_IMAPve_d_Rrg_TYPE_BACK)) |
        ((uint8)128U))));
    }

    /* End of Switch: '<S604>/Switch8' */

    /* Sum: '<S599>/Add' incorporates:
     *  ArithShift: '<S599>/Shift Arithmetic'
     *  ArithShift: '<S599>/Shift Arithmetic1'
     *  DataTypeConversion: '<S599>/Data Type Conversion'
     *  DataTypeConversion: '<S599>/Data Type Conversion1'
     *  DataTypeConversion: '<S599>/Data Type Conversion2'
     */
    rtb_Add = ((((uint32)rtb_Switch8_c) << 8) + ((uint32)rtb_Switch8)) +
      (((uint32)rtb_Switch8_j) << 16);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Fault_Reason = rtb_Add;

    /* DataTypeConversion: '<S345>/Cast2' */
    ob_LKA_Fault_Reason = rtb_Add;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_State_Mon = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.EPS_Control = LKAS_DW.EPS_Control_i;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LDW_State_Mon = LKAS_DW.LDWSM_stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.LDWSM_stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S146>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S151>/If' */
      if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S151>/If Action Subsystem' incorporates:
         *  ActionPort: '<S152>/Action Port'
         */
        /* Gain: '<S152>/rad to deg' incorporates:
         *  Gain: '<S152>/Gain'
         */
        LKAS_DW.Merge_a = ((-1.0F) * rtb_phiHdAg_Lft) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S151>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S151>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S153>/Action Port'
         */
        /* Gain: '<S153>/rad to deg' */
        LKAS_DW.Merge_a = 57.2957802F * rtb_phiHdAg_Rgt;

        /* End of Outputs for SubSystem: '<S151>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S151>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S154>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_a);

        /* End of Outputs for SubSystem: '<S151>/If Action Subsystem2' */
      }

      /* End of If: '<S151>/If' */

      /* Switch: '<S663>/Switch2' incorporates:
       *  Constant: '<S663>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_l != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_l;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S663>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S151>/Sum Condition' incorporates:
       *  EnablePort: '<S155>/Enable'
       */
      /* RelationalOperator: '<S151>/Relational Operator' */
      if (LKAS_DW.Merge_a >= x10) {
        if (!LKAS_DW.SumCondition_MODE_h) {
          /* InitializeConditions for Memory: '<S155>/Memory' */
          LKAS_DW.Memory_PreviousInput_p = 0.0F;
          LKAS_DW.SumCondition_MODE_h = true;
        }

        /* Sum: '<S155>/Add1' incorporates:
         *  Memory: '<S155>/Memory'
         */
        rtb_L0_C0_b = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_p;

        /* Saturate: '<S155>/Saturation' */
        if (rtb_L0_C0_b > 0.6F) {
          rtb_L0_C0_b = 0.6F;
        } else {
          if (rtb_L0_C0_b < 0.0F) {
            rtb_L0_C0_b = 0.0F;
          }
        }

        /* End of Saturate: '<S155>/Saturation' */

        /* RelationalOperator: '<S155>/Relational Operator' incorporates:
         *  Constant: '<S151>/Constant'
         */
        LKAS_DW.RelationalOperator_lw = (rtb_L0_C0_b >= 0.05F);

        /* Update for Memory: '<S155>/Memory' */
        LKAS_DW.Memory_PreviousInput_p = rtb_L0_C0_b;
      } else {
        if (LKAS_DW.SumCondition_MODE_h) {
          /* Disable for Outport: '<S155>/Out' */
          LKAS_DW.RelationalOperator_lw = false;
          LKAS_DW.SumCondition_MODE_h = false;
        }
      }

      /* End of RelationalOperator: '<S151>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S151>/Sum Condition' */

      /* Product: '<S146>/Product' incorporates:
       *  Logic: '<S146>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.LDWSM_stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_lw) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S151>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_h) {
          /* Disable for Outport: '<S155>/Out' */
          LKAS_DW.RelationalOperator_lw = false;
          LKAS_DW.SumCondition_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S151>/Sum Condition' */

        /* Disable for Outport: '<S146>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* If: '<S472>/If' incorporates:
     *  Constant: '<S478>/Constant'
     *  Delay: '<S149>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_IMAPve_d_EPS_LKA_State) != 1)) {
      /* Outputs for IfAction SubSystem: '<S472>/If Action Subsystem' incorporates:
       *  ActionPort: '<S476>/Action Port'
       */
      LKAS_IfActionSubsystem_e(&rtb_Merge_fj);

      /* End of Outputs for SubSystem: '<S472>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_IMAPve_d_EPS_LKA_State) != 3)) {
      /* Outputs for IfAction SubSystem: '<S472>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S477>/Action Port'
       */
      LKAS_IfActionSubsystem_e(&rtb_Merge_fj);

      /* End of Outputs for SubSystem: '<S472>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S472>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S478>/Action Port'
       */
      rtb_Merge_fj = false;

      /* End of Outputs for SubSystem: '<S472>/If Action Subsystem3' */
    }

    /* End of If: '<S472>/If' */

    /* Outputs for Enabled SubSystem: '<S472>/Sum Condition1' */
    LKAS_SumCondition1(rtb_Merge_fj, rtb_LKA_SampleTime,
                       rtb_LL_MAX_DELAY_EPSSTAR_TIME,
                       &LKAS_DW.RelationalOperator, &LKAS_DW.SumCondition1_i);

    /* End of Outputs for SubSystem: '<S472>/Sum Condition1' */

    /* SignalConversion: '<S531>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S444>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LKA_Main_Switch;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_LL_SingleLane_Disable_Swt;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_Compare_m2;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_ax;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_ag2;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_nl;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_b5;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_pu;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_d;
    rtb_TmpSignalConversionAtSFunct[12] = rtb_RelationalOperator_p;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_LogicalOperator_o5;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_ps;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_BCM_Left_Light;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge_ou;

    /* MATLAB Function: '<S444>/Disable Reason' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S531>:1' */
    /* '<S531>:1:2' y = single(0); */
    rtb_L0_C0_b = 0.0F;

    /* '<S531>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S531>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S531>:1:5' y = single(i); */
        rtb_L0_C0_b = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Disable_Reason = rtb_L0_C0_b;

    /* DataTypeConversion: '<S345>/Cast' */
    ob_LKA_Disable_Reason = rtb_L0_C0_b;

    /* RelationalOperator: '<S482>/Compare' incorporates:
     *  Constant: '<S482>/Constant'
     */
    rtb_Compare_lz = (LKAS_DW.RelationalOperator == true);

    /* DataTypeConversion: '<S345>/Cast1' */
    ob_LKA_LKADeactvCSyn = (float32)(LKAS_DW.Merge1_f ? 1.0F : 0.0F);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LFTTTLC_Mon = rtb_LFTTTLC;

    /* Gain: '<S295>/Gain' incorporates:
     *  Sum: '<S295>/Add4'
     */
    rtb_phiHdAg = (rtb_phiHdAg_Lft + rtb_phiHdAg_Rgt) * 0.5F;

    /* Logic: '<S564>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S564>/Relational Operator3'
     *  RelationalOperator: '<S564>/Relational Operator4'
     */
    rtb_LogicalOperator1_f = ((rtb_Gain1 <= rtb_LL_LKA_LatestWarnLine_C) ||
      (rtb_Add5_k <= rtb_LL_LKA_LatestWarnLine_C));

    /* Gain: '<S294>/Gain' incorporates:
     *  Sum: '<S294>/Add'
     */
    rtb_lDvt = (rtb_Gain1 + rtb_Add5_k) * 0.5F;
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S452>/ExitCount' */
      if (LKAS_DW.ExitCount_MODE) {
        /* Disable for Outport: '<S460>/Out' */
        LKAS_DW.RelationalOperator_d = false;
        LKAS_DW.ExitCount_MODE = false;
      }

      /* End of Disable for SubSystem: '<S452>/ExitCount' */

      /* Disable for Enabled SubSystem: '<S453>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_d) {
        /* Disable for Outport: '<S462>/Out' */
        LKAS_DW.RelationalOperator_b = false;
        LKAS_DW.SumCondition1_MODE_d = false;
      }

      /* End of Disable for SubSystem: '<S453>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S463>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S467>/Out' */
        LKAS_DW.RelationalOperator_o = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S463>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S391>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S422>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S391>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S391>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S421>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S391>/Count' */

      /* Disable for Enabled SubSystem: '<S424>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S430>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }

      /* End of Disable for SubSystem: '<S424>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S392>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S436>/Out' */
        LKAS_DW.RelationalOperator_j = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }

      /* End of Disable for SubSystem: '<S392>/Sum Condition1' */

      /* Disable for If: '<S439>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S402>/Sum Condition' */
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S408>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition_MODE = false;
      }

      /* End of Disable for SubSystem: '<S402>/Sum Condition' */

      /* Disable for Enabled SubSystem: '<S326>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_j) {
        /* Disable for Outport: '<S330>/Out' */
        LKAS_DW.RelationalOperator_m = false;
        LKAS_DW.Subsystem_MODE_j = false;
      }

      /* End of Disable for SubSystem: '<S326>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S194>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S177>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_e) {
          /* Disable for Outport: '<S179>/Out' */
          LKAS_DW.RelationalOperator_dq = false;
          LKAS_DW.SumCondition1_MODE_e = false;
        }

        /* End of Disable for SubSystem: '<S177>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S178>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_m.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_p,
            &LKAS_DW.SumCondition1_m);
        }

        /* End of Disable for SubSystem: '<S178>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S178>/Sum Condition' */
        if (LKAS_DW.SumCondition_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_hz,
            &LKAS_DW.SumCondition_c);
        }

        /* End of Disable for SubSystem: '<S178>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S178>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S187>/Out' */
          LKAS_DW.RelationalOperator_c = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S178>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S164>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_p) {
          LKAS_DW.SumCondition2_MODE_p = false;
        }

        /* End of Disable for SubSystem: '<S164>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S156>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_b) {
          /* Disable for Outport: '<S165>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_p = 0.0F;
          LKAS_DW.Subsystem_MODE_b = false;
        }

        /* End of Disable for SubSystem: '<S156>/Subsystem' */

        /* Disable for If: '<S268>/If' */
        LKAS_DW.If_ActiveSubsystem_i = -1;

        /* Disable for Outport: '<S147>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S147>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S147>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S147>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_o = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_n = 0.0F;
        LKAS_DW.T1_Mon_n = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S151>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_h) {
          /* Disable for Outport: '<S155>/Out' */
          LKAS_DW.RelationalOperator_lw = false;
          LKAS_DW.SumCondition_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S151>/Sum Condition' */

        /* Disable for Outport: '<S146>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Enabled SubSystem: '<S472>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_i.SumCondition1_MODE) {
        LKAS_SumCondition1_Disable(&LKAS_DW.RelationalOperator,
          &LKAS_DW.SumCondition1_i);
      }

      /* End of Disable for SubSystem: '<S472>/Sum Condition1' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.DACMode = ((uint8)0U);
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);
      LKAS_DW.EPS_Control = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S11>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_IMAPve_d_Rrg_TYPE_BACK = ((uint8)1U);
    break;

   case 1:
    rtb_IMAPve_d_Rrg_TYPE_BACK = ((uint8)1U);
    break;

   case 2:
    rtb_IMAPve_d_Rrg_TYPE_BACK = ((uint8)2U);
    break;

   case 3:
    rtb_IMAPve_d_Rrg_TYPE_BACK = ((uint8)3U);
    break;

   case 4:
    rtb_IMAPve_d_Rrg_TYPE_BACK = ((uint8)4U);
    break;

   case 5:
    rtb_IMAPve_d_Rrg_TYPE_BACK = ((uint8)4U);
    break;

   default:
    rtb_IMAPve_d_Rrg_TYPE_BACK = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S11>/Multiport Switch' */

  /* RelationalOperator: '<S654>/Compare' incorporates:
   *  Constant: '<S654>/Constant'
   */
  rtb_Merge_ou = (rtb_IMAPve_d_Rrg_TYPE_BACK == ((uint8)4U));

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/x1'
   */
  if (rtb_Merge_ou) {
    rtb_L0_C0_b = LKAS_DW.OutputM;
  } else {
    rtb_L0_C0_b = (float32)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single10'
   */
  (void) Rte_Write_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_L0_C0_b);

  /* Switch: '<S11>/Switch1' incorporates:
   *  Constant: '<S11>/1'
   *  Constant: '<S11>/x0'
   */
  if (rtb_Merge_ou) {
    rtb_TCU_ActualGear = ((uint8)1U);
  } else {
    rtb_TCU_ActualGear = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single1'
   *  DataTypeConversion: '<S1>/Cast To Single12'
   */
  (void) Rte_Write_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq((UInt8)
    rtb_TCU_ActualGear);

  /* Outputs for Enabled SubSystem: '<S653>/Subsystem' incorporates:
   *  EnablePort: '<S660>/Enable'
   */
  if (((sint32)rtb_TCU_ActualGear) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S660>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S660>/Add' */
    rtb_L0_C0_b = LKAS_DW.OutputSWACmd - rtb_SW_Angle;

    /* Sum: '<S660>/Add1' incorporates:
     *  Constant: '<S660>/Ki'
     *  Delay: '<S660>/Delay1'
     *  Product: '<S660>/Product2'
     */
    rtb_L0_C1_fx = (rtb_L0_C0_b * 0.0005F) + LKAS_DW.Delay1_DSTATE;

    /* Saturate: '<S660>/Saturation' */
    if (rtb_L0_C1_fx > 0.5F) {
      rtb_L0_C1_fx = 0.5F;
    } else {
      if (rtb_L0_C1_fx < (-0.5F)) {
        rtb_L0_C1_fx = (-0.5F);
      }
    }

    /* End of Saturate: '<S660>/Saturation' */

    /* Fcn: '<S660>/Fcn' */
    rtb_SW_Angle = LKAS_DW.OutputSWACmd * LKAS_DW.OutputSWACmd;

    /* Sum: '<S660>/Add2' incorporates:
     *  Constant: '<S660>/Kp'
     *  Fcn: '<S660>/Fcn'
     *  Product: '<S660>/Product1'
     */
    LKAS_DW.in_trq = (((((rtb_SW_Angle * LKAS_DW.OutputSWACmd) * 2.0e-6F) +
                        (rtb_SW_Angle * -0.0005F)) + (LKAS_DW.OutputSWACmd *
      0.0505F)) + (rtb_L0_C0_b * 0.02F)) + rtb_L0_C1_fx;

    /* Update for Delay: '<S660>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_L0_C1_fx;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S660>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S653>/Subsystem' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_Camera_Status' */
  Rte_Read_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status(&tmpRead_u);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Sum: '<S658>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S658>/Delay Input2'
   *
   * Block description for '<S658>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S658>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C0_b = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S658>/delta rise limit' incorporates:
   *  Constant: '<S653>/Constant'
   *  SampleTimeMath: '<S658>/sample time'
   *
   * About '<S658>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C1_fx = 5.0F * 0.01F;

  /* Product: '<S658>/delta fall limit' incorporates:
   *  Constant: '<S653>/Constant1'
   *  SampleTimeMath: '<S658>/sample time'
   *
   * About '<S658>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_R0_C0_a = (-5.0F) * 0.01F;

  /* Switch: '<S661>/Switch2' incorporates:
   *  Product: '<S658>/delta fall limit'
   *  Product: '<S658>/delta rise limit'
   *  RelationalOperator: '<S661>/LowerRelop1'
   *  RelationalOperator: '<S661>/UpperRelop'
   *  Switch: '<S661>/Switch'
   */
  if (rtb_L0_C0_b > rtb_L0_C1_fx) {
    rtb_L0_C0_b = rtb_L0_C1_fx;
  } else {
    if (rtb_L0_C0_b < rtb_R0_C0_a) {
      /* Switch: '<S661>/Switch' incorporates:
       *  Product: '<S658>/delta fall limit'
       */
      rtb_L0_C0_b = rtb_R0_C0_a;
    }
  }

  /* End of Switch: '<S661>/Switch2' */

  /* Sum: '<S658>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S658>/Delay Input2'
   *
   * Block description for '<S658>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S658>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C0_b += LKAS_DW.DelayInput2_DSTATE;

  /* Switch: '<S659>/Switch2' incorporates:
   *  Constant: '<S653>/Constant3'
   *  Constant: '<S653>/Constant4'
   *  RelationalOperator: '<S659>/LowerRelop1'
   *  RelationalOperator: '<S659>/UpperRelop'
   *  Switch: '<S659>/Switch'
   */
  if (rtb_L0_C0_b > 5.0F) {
    rtb_SW_Angle = 5.0F;
  } else if (rtb_L0_C0_b < (-5.0F)) {
    /* Switch: '<S659>/Switch' incorporates:
     *  Constant: '<S653>/Constant4'
     */
    rtb_SW_Angle = (-5.0F);
  } else {
    rtb_SW_Angle = rtb_L0_C0_b;
  }

  /* End of Switch: '<S659>/Switch2' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single13'
   */
  (void) Rte_Write_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_SW_Angle);

  /* Switch: '<S11>/Switch2' incorporates:
   *  Constant: '<S11>/x2'
   *  Constant: '<S656>/Constant'
   *  Constant: '<S657>/Constant'
   *  Logic: '<S11>/Logical Operator'
   *  RelationalOperator: '<S656>/Compare'
   *  RelationalOperator: '<S657>/Compare'
   */
  if ((rtb_IMAPve_d_Rrg_TYPE_BACK == ((uint8)4U)) || (rtb_IMAPve_d_Rrg_TYPE_BACK
       == ((uint8)3U))) {
    rtb_TCU_ActualGear = LKAS_DW.EPS_Control;
  } else {
    rtb_TCU_ActualGear = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch2' */

  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single9'
   */
  (void) Rte_Write_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control((UInt8)
    rtb_TCU_ActualGear);

  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single8'
   */
  (void) Rte_Write_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control((UInt8)
    rtb_IMAPve_d_Rrg_TYPE_BACK);

  /* Switch: '<S91>/Switch' incorporates:
   *  Constant: '<S91>/Constant'
   *  Constant: '<S91>/Constant1'
   *  Constant: '<S93>/Constant'
   *  RelationalOperator: '<S93>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_LKA_Veh2CamL_C = 0.5F;
  } else {
    rtb_LKA_Veh2CamL_C = 0.25F;
  }

  /* End of Switch: '<S91>/Switch' */

  /* Logic: '<S91>/Logical Operator2' incorporates:
   *  Abs: '<S91>/Abs'
   *  Constant: '<S100>/Constant'
   *  Constant: '<S101>/Constant'
   *  Constant: '<S94>/Constant'
   *  Constant: '<S95>/Constant'
   *  Constant: '<S96>/Constant'
   *  Constant: '<S97>/Constant'
   *  Constant: '<S98>/Constant'
   *  Constant: '<S99>/Constant'
   *  Logic: '<S91>/Logical Operator1'
   *  Logic: '<S91>/Logical Operator3'
   *  RelationalOperator: '<S100>/Compare'
   *  RelationalOperator: '<S101>/Compare'
   *  RelationalOperator: '<S91>/Relational Operator'
   *  RelationalOperator: '<S94>/Compare'
   *  RelationalOperator: '<S95>/Compare'
   *  RelationalOperator: '<S96>/Compare'
   *  RelationalOperator: '<S97>/Compare'
   *  RelationalOperator: '<S98>/Compare'
   *  RelationalOperator: '<S99>/Compare'
   */
  rtb_LogicalOperator2 = ((((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (LKAS_DW.LKA_State == ((uint8)5U))) || (LKAS_DW.LKA_State == ((uint8)4U))) ||
    (LKAS_DW.LKA_State == ((uint8)3U))) && ((rtb_IMAPve_d_EPS_LKA_State ==
    ((uint8)3U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)))) && (fabsf
    (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_LKA_Veh2CamL_C));

  /* Switch: '<S665>/Switch1' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=1'
   *
   * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=1':
   *  ��ʻԱ���ֿ�ʼ�����ܷ����������ѵ�ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_HandsOff_TextTime = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_HandsOff_TextTime = LL_HandsOff_TextTime;
  }

  /* End of Switch: '<S665>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S91>/Sum Condition1' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_TextTime, &LKAS_DW.RelationalOperator_j0,
                     &LKAS_DW.SumCondition1);

  /* End of Outputs for SubSystem: '<S91>/Sum Condition1' */

  /* MATLAB Function: '<S8>/HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S84>:1' */
  /* '<S84>:1:2' if stDACmode==2&&LKA_STATE==6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 6)) {
    /* �������ָ������� */
    /* '<S84>:1:3' HMI_Popup_Status=uint8(6); */
    rtb_HMI_Popup_Status_g = 6U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (((sint32)((uint8)tmpRead_u)) == 5)) {
    /* '<S84>:1:6' elseif (stDACmode==2||stDACmode==1)&&(Front_Camera_Blocked==5) */
    /* ����ͷ���ڵ� */
    /* '<S84>:1:7' HMI_Popup_Status=uint8(4); */
    rtb_HMI_Popup_Status_g = 4U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (LKAS_DW.RelationalOperator_j0)) {
    /* '<S84>:1:8' elseif (stDACmode==2||stDACmode==1)&&HandsOff==1 */
    /* ���շ����� */
    /* '<S84>:1:9' HMI_Popup_Status=uint8(2); */
    rtb_HMI_Popup_Status_g = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              2)) {
    /* '<S84>:1:10' elseif stDACmode==2&&(LKA_STATE==2) */
    /* '<S84>:1:11' HMI_Popup_Status=uint8(1); */
    rtb_HMI_Popup_Status_g = 1U;
  } else if (((sint32)LKAS_DW.LKA_Mode) != 2) {
    /* '<S84>:1:12' elseif stDACmode~=2&&stFaultCSyn==0 */
    /* '<S84>:1:13' HMI_Popup_Status=uint8(8); */
    rtb_HMI_Popup_Status_g = 8U;
  } else {
    /* '<S84>:1:14' elseif stFaultCSyn==0 */
    /* '<S84>:1:15' HMI_Popup_Status=uint8(7); */
    rtb_HMI_Popup_Status_g = 7U;
  }

  /* End of MATLAB Function: '<S8>/HMI_Popup_Status' */

  /* Switch: '<S665>/Switch2' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=2'
   *
   * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=2':
   *  ��ʻԱ���ֿ�ʼ����������������ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion2_f3 != 0.0F) {
    rtb_LL_HandsOff_WarnTime = LKAS_ConstB.DataTypeConversion2_f3;
  } else {
    rtb_LL_HandsOff_WarnTime = LL_HandsOff_WarnTime;
  }

  /* End of Switch: '<S665>/Switch2' */

  /* Outputs for Enabled SubSystem: '<S91>/Sum Condition2' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_WarnTime, &LKAS_DW.RelationalOperator_n,
                     &LKAS_DW.SumCondition2);

  /* End of Outputs for SubSystem: '<S91>/Sum Condition2' */

  /* MATLAB Function: '<S8>/Hands_Off_Warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_Off_Warning': '<S85>:1' */
  /* '<S85>:1:2' if HandsOff==0 */
  if (!LKAS_DW.RelationalOperator_n) {
    /* '<S85>:1:3' Hands_Off_Warning= uint8(0); */
    rtb_Hands_Off_Warning_h = 0U;
  } else {
    /* '<S85>:1:4' elseif HandsOff==1 */
    /* '<S85>:1:5' Hands_Off_Warning= uint8(1); */
    rtb_Hands_Off_Warning_h = 1U;
  }

  /* End of MATLAB Function: '<S8>/Hands_Off_Warning' */

  /* MATLAB Function: '<S8>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S87>:1' */
  /* '<S87>:1:2' if HMI_stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S87>:1:3' if HMI_LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S87>:1:4' LDW_Flag=uint8(1); */
      rtb_LDW_Flag_d = 1U;
      break;

     case 2:
      /* '<S87>:1:5' elseif HMI_LDWWarnInfo==2 */
      /* '<S87>:1:6' LDW_Flag=uint8(2); */
      rtb_LDW_Flag_d = 2U;
      break;

     default:
      /* '<S87>:1:7' else */
      /* '<S87>:1:8' LDW_Flag=uint8(0); */
      rtb_LDW_Flag_d = 0U;
      break;
    }
    break;

   case 2:
    /* '<S87>:1:10' elseif HMI_stDACmode==2 */
    /* '<S87>:1:11' if HMI_LDWWarnInfo==1 && HMI_LKA_STATE==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S87>:1:12' LDW_Flag=uint8(1); */
      rtb_LDW_Flag_d = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S87>:1:13' elseif HMI_LDWWarnInfo==2 && HMI_LKA_STATE==5 */
      /* '<S87>:1:14' LDW_Flag=uint8(2); */
      rtb_LDW_Flag_d = 2U;
    } else {
      /* '<S87>:1:15' else */
      /* '<S87>:1:16' LDW_Flag=uint8(0); */
      rtb_LDW_Flag_d = 0U;
    }
    break;

   default:
    /* '<S87>:1:18' else */
    /* '<S87>:1:19' LDW_Flag=uint8(0); */
    rtb_LDW_Flag_d = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/LDW_Flag' */

  /* MATLAB Function: '<S8>/LDW_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Status_Display': '<S88>:1' */
  /* '<S88>:1:2' if (stDACmode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S88>:1:3' LDW_Status_Display=uint8(1); */
    rtb_LDW_Status_Display_i = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S88>:1:4' elseif (stDACmode==1)&&LDW_STATE==6 */
    /* '<S88>:1:5' LDW_Status_Display=uint8(2); */
    rtb_LDW_Status_Display_i = 2U;
  } else {
    /* '<S88>:1:6' else */
    /* '<S88>:1:7' LDW_Status_Display=uint8(0); */
    rtb_LDW_Status_Display_i = 0U;
  }

  /* End of MATLAB Function: '<S8>/LDW_Status_Display' */

  /* MATLAB Function: '<S8>/LKA_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_Status_Display': '<S89>:1' */
  /* '<S89>:1:3' if stDACmode==2&&LKA_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) != 6)) {
    /* '<S89>:1:4' LKA_Status_Display=single(1); */
    rtb_LKA_Status_Display = 1.0F;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S89>:1:5' elseif stDACmode==2&&LKA_STATE==6 */
    /* '<S89>:1:6' LKA_Status_Display=single(2); */
    rtb_LKA_Status_Display = 2.0F;
  } else {
    /* '<S89>:1:7' else */
    /* '<S89>:1:8' LKA_Status_Display=single(0); */
    rtb_LKA_Status_Display = 0.0F;
  }

  /* End of MATLAB Function: '<S8>/LKA_Status_Display' */

  /* MATLAB Function: '<S8>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S90>:1' */
  /* '<S90>:1:2' if stDACmode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S90>:1:3' LKA_Action_Indication=uint8(1); */
    rtb_LKA_Action_Indication_g = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S90>:1:4' elseif stDACmode==2&&LKA_STATE==3 */
    /* '<S90>:1:5' LKA_Action_Indication=uint8(2); */
    rtb_LKA_Action_Indication_g = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S90>:1:6' elseif stDACmode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S90>:1:7' LKA_Action_Indication=uint8(3); */
    rtb_LKA_Action_Indication_g = 3U;
  } else {
    /* '<S90>:1:8' else */
    /* '<S90>:1:9' LKA_Action_Indication=uint8(0); */
    rtb_LKA_Action_Indication_g = 0U;
  }

  /* End of MATLAB Function: '<S8>/LKA_action_indication' */

  /* MATLAB Function: '<S8>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S116>/Switch'
   *  Switch: '<S116>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S92>:1' */
  /* '<S92>:1:2' if stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S92>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) == 3)) &&
        (((sint32)rtb_R0_Q) != 3)) {
      /* '<S92>:1:4' Vehicle_Lane_Display=uint8(3); */
      rtb_Vehicle_Lane_Display_i = 3U;
    } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) != 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
      /* '<S92>:1:6' Vehicle_Lane_Display=uint8(4); */
      rtb_Vehicle_Lane_Display_i = 4U;
    } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) == 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
      /* '<S92>:1:8' Vehicle_Lane_Display=uint8(5); */
      rtb_Vehicle_Lane_Display_i = 5U;
    } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
               && (((sint32)rtb_R0_Q) != 3)) {
      /* '<S92>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
      /* '<S92>:1:10' Vehicle_Lane_Display=uint8(10); */
      rtb_Vehicle_Lane_Display_i = 10U;
    } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) != 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
      /* '<S92>:1:12' Vehicle_Lane_Display=uint8(11); */
      rtb_Vehicle_Lane_Display_i = 11U;
    } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
      /* '<S92>:1:14' Vehicle_Lane_Display=uint8(12); */
      rtb_Vehicle_Lane_Display_i = 12U;
    } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) == 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
      /* '<S92>:1:16' Vehicle_Lane_Display=uint8(13); */
      rtb_Vehicle_Lane_Display_i = 13U;
    } else {
      /* '<S92>:1:17' else */
      /* '<S92>:1:18' Vehicle_Lane_Display=uint8(1); */
      rtb_Vehicle_Lane_Display_i = 1U;
    }
    break;

   case 2:
    /* '<S92>:1:20' elseif stDACmode==2 */
    /* '<S92>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) == 3)) &&
        (((sint32)rtb_R0_Q) != 3)) {
      /* '<S92>:1:22' Vehicle_Lane_Display=uint8(3); */
      rtb_Vehicle_Lane_Display_i = 3U;
    } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) != 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
      /* '<S92>:1:24' Vehicle_Lane_Display=uint8(4); */
      rtb_Vehicle_Lane_Display_i = 4U;
    } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) == 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
      /* '<S92>:1:26' Vehicle_Lane_Display=uint8(5); */
      rtb_Vehicle_Lane_Display_i = 5U;
    } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
               && (((sint32)rtb_R0_Q) != 3)) {
      /* '<S92>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
      /* '<S92>:1:28' Vehicle_Lane_Display=uint8(6); */
      rtb_Vehicle_Lane_Display_i = 6U;
    } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) != 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
      /* '<S92>:1:30' Vehicle_Lane_Display=uint8(7); */
      rtb_Vehicle_Lane_Display_i = 7U;
    } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
      /* '<S92>:1:32' Vehicle_Lane_Display=uint8(8); */
      rtb_Vehicle_Lane_Display_i = 8U;
    } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) == 3))
               && (((sint32)rtb_R0_Q) == 3)) {
      /* '<S92>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
      /* '<S92>:1:34' Vehicle_Lane_Display=uint8(9); */
      rtb_Vehicle_Lane_Display_i = 9U;
    } else {
      /* '<S92>:1:35' else */
      /* '<S92>:1:36' Vehicle_Lane_Display=uint8(1); */
      rtb_Vehicle_Lane_Display_i = 1U;
    }
    break;

   default:
    /* '<S92>:1:38' else */
    /* '<S92>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_Vehicle_Lane_Display_i = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/Vehicle_Lane_Display' */

  /* DataTypeConversion: '<S11>/Cast To Single10' incorporates:
   *  Constant: '<S655>/Constant'
   *  RelationalOperator: '<S655>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.DACMode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S4>/Cast To Single1' */
  LKAS_DW.CastToSingle1 = LKAS_DW.LFTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single2' */
  LKAS_DW.CastToSingle2 = LKAS_DW.RGTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single3' */
  LKAS_DW.CastToSingle3 = (float32)LKAS_DW.LDW_State_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single4' */
  LKAS_DW.CastToSingle4 = (float32)LKAS_DW.LKA_State_Mon;

  /* S-Function (scanpack): '<S4>/CAN Pack' */
  /* S-Function (scanpack): '<S4>/CAN Pack' */
  LKAS_DW.CANPack.ID = 1U;
  LKAS_DW.CANPack.Length = 8U;
  LKAS_DW.CANPack.Extended = 0U;
  LKAS_DW.CANPack.Remote = 0;
  LKAS_DW.CANPack.Data[0] = 0;
  LKAS_DW.CANPack.Data[1] = 0;
  LKAS_DW.CANPack.Data[2] = 0;
  LKAS_DW.CANPack.Data[3] = 0;
  LKAS_DW.CANPack.Data[4] = 0;
  LKAS_DW.CANPack.Data[5] = 0;
  LKAS_DW.CANPack.Data[6] = 0;
  LKAS_DW.CANPack.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle1;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[1] = LKAS_DW.CANPack.Data[1] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[0] = LKAS_DW.CANPack.Data[0] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle2;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[3] = LKAS_DW.CANPack.Data[3] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[2] = LKAS_DW.CANPack.Data[2] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle3;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[5] = LKAS_DW.CANPack.Data[5] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[4] = LKAS_DW.CANPack.Data[4] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle4;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[7] = LKAS_DW.CANPack.Data[7] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[6] = LKAS_DW.CANPack.Data[6] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single5' */
  LKAS_DW.CastToSingle5 = LKAS_DW.LKA_ExitFlg_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single6' */
  LKAS_DW.CastToSingle6 = LKAS_DW.LKA_SampleTime_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single7' */
  LKAS_DW.CastToSingle7 = LKAS_DW.T1_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single8' */
  LKAS_DW.CastToSingle8 = LKAS_DW.Disable_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  LKAS_DW.CANPack1.ID = 2U;
  LKAS_DW.CANPack1.Length = 8U;
  LKAS_DW.CANPack1.Extended = 0U;
  LKAS_DW.CANPack1.Remote = 0;
  LKAS_DW.CANPack1.Data[0] = 0;
  LKAS_DW.CANPack1.Data[1] = 0;
  LKAS_DW.CANPack1.Data[2] = 0;
  LKAS_DW.CANPack1.Data[3] = 0;
  LKAS_DW.CANPack1.Data[4] = 0;
  LKAS_DW.CANPack1.Data[5] = 0;
  LKAS_DW.CANPack1.Data[6] = 0;
  LKAS_DW.CANPack1.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle5;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[1] = LKAS_DW.CANPack1.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[0] = LKAS_DW.CANPack1.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle6;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[3] = LKAS_DW.CANPack1.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[2] = LKAS_DW.CANPack1.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle7;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[5] = LKAS_DW.CANPack1.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[4] = LKAS_DW.CANPack1.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle8;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[7] = LKAS_DW.CANPack1.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[6] = LKAS_DW.CANPack1.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single9' */
  LKAS_DW.CastToSingle9 = (float32)LKAS_DW.Fault_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack2' */
  /* S-Function (scanpack): '<S4>/CAN Pack2' */
  LKAS_DW.CANPack2.ID = 3U;
  LKAS_DW.CANPack2.Length = 8U;
  LKAS_DW.CANPack2.Extended = 0U;
  LKAS_DW.CANPack2.Remote = 0;
  LKAS_DW.CANPack2.Data[0] = 0;
  LKAS_DW.CANPack2.Data[1] = 0;
  LKAS_DW.CANPack2.Data[2] = 0;
  LKAS_DW.CANPack2.Data[3] = 0;
  LKAS_DW.CANPack2.Data[4] = 0;
  LKAS_DW.CANPack2.Data[5] = 0;
  LKAS_DW.CANPack2.Data[6] = 0;
  LKAS_DW.CANPack2.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle9;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[1] = LKAS_DW.CANPack2.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[0] = LKAS_DW.CANPack2.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle10;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[3] = LKAS_DW.CANPack2.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[2] = LKAS_DW.CANPack2.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle21;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[5] = LKAS_DW.CANPack2.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[4] = LKAS_DW.CANPack2.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle22;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[7] = LKAS_DW.CANPack2.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[6] = LKAS_DW.CANPack2.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack' incorporates:
   *  Outport: '<Root>/LKASve_g_ob5H_10'
   *  Outport: '<Root>/LKASve_g_ob5L_10'
   */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack' */
    if ((8 == LKAS_DW.CANPack.Length) && (LKAS_DW.CANPack.ID != INVALID_CAN_ID) )
    {
      if ((1 == LKAS_DW.CANPack.ID) && (0U == LKAS_DW.CANPack.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              tmpWrite = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              tmpWrite_0 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack1' incorporates:
   *  Outport: '<Root>/LKASve_g_ob6H_10'
   *  Outport: '<Root>/LKASve_g_ob6L_10'
   */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
    if ((8 == LKAS_DW.CANPack1.Length) && (LKAS_DW.CANPack1.ID != INVALID_CAN_ID)
        ) {
      if ((2 == LKAS_DW.CANPack1.ID) && (0U == LKAS_DW.CANPack1.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              tmpWrite_1 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              tmpWrite_2 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack2' incorporates:
   *  Outport: '<Root>/LKASve_g_ob07H_100'
   *  Outport: '<Root>/LKASve_g_ob07L_100'
   */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
    if ((8 == LKAS_DW.CANPack2.Length) && (LKAS_DW.CANPack2.ID != INVALID_CAN_ID)
        ) {
      if ((3 == LKAS_DW.CANPack2.ID) && (0U == LKAS_DW.CANPack2.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack2.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              tmpWrite_3 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack2.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              tmpWrite_4 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack3' incorporates:
   *  Outport: '<Root>/LKASve_g_ob08H_100'
   *  Outport: '<Root>/LKASve_g_ob08L_100'
   */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
    if ((8 == LKAS_ConstB.CANPack3.Length) && (LKAS_ConstB.CANPack3.ID !=
         INVALID_CAN_ID) ) {
      if ((4 == LKAS_ConstB.CANPack3.ID) && (0U == LKAS_ConstB.CANPack3.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              tmpWrite_5 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              tmpWrite_6 = result;
            }
          }
        }
      }
    }
  }

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single'
   *  DataTypeConversion: '<S1>/Cast To Single11'
   */
  (void) Rte_Write_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* DataTypeConversion: '<S12>/Cast To Boolean37' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_14B_InvOorReal = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean38' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxN = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean39' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxT = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean40' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinN = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean41' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinT = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_e_Node_ACU_Validity = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean10' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_e_Node_EPB_Validity = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean11' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_Inner_FRadar_FaultStat = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean12' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_d_sen_sta_Corner_rad = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_e_Node_EMS_Validity = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_e_Node_TBOX_Validity = (rtb_IMAPve_g_Rrg_VR_Start_BACK != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean1' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC_EPBErrorStatus = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean13' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorTCS = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean14' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorVeh = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean17' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_MP5_366_OorAEBButt = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean18' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_MP5_366_OorFCWButt = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean22' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorSta = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean23' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorYaw = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean24' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC6_123_InvOorDyn = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean25' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC6_123_InvUnfilY = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean26' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehDri = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean27' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehHol = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean28' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_GW_MP5_413_OorISAM = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean29' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_SCC_309_OorACCButt = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean4' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_BCM3_33C_InvBrkLig = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_14A_OorACCStat = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean6' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS10_88_InvAccPed = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS5_E0_InvOorBrkP = (rtb_Saturation1 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean8' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS5_E0_OorEngineS = (rtb_Saturation1 != 0.0F);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_ob5H_10' */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S134>:1' */
  /* '<S134>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S134>:1:3' cur=min(single(0.004),cur); */
  /* '<S134>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S134>:1:5' offset=min(single(0.5),offset); */
  (void) Rte_Write_LKASve_g_ob5H_10_LKASve_g_ob5H_10(tmpWrite);

  /* Outport: '<Root>/LKASve_g_ob5L_10' */
  (void) Rte_Write_LKASve_g_ob5L_10_LKASve_g_ob5L_10(tmpWrite_0);

  /* Outport: '<Root>/LKASve_g_ob6H_10' */
  (void) Rte_Write_LKASve_g_ob6H_10_LKASve_g_ob6H_10(tmpWrite_1);

  /* Outport: '<Root>/LKASve_g_ob6L_10' */
  (void) Rte_Write_LKASve_g_ob6L_10_LKASve_g_ob6L_10(tmpWrite_2);

  /* Outport: '<Root>/LKASve_g_ob07H_100' */
  (void) Rte_Write_LKASve_g_ob07H_100_LKASve_g_ob07H_100(tmpWrite_3);

  /* Outport: '<Root>/LKASve_g_ob07L_100' */
  (void) Rte_Write_LKASve_g_ob07L_100_LKASve_g_ob07L_100(tmpWrite_4);

  /* Outport: '<Root>/LKASve_g_ob08H_100' */
  (void) Rte_Write_LKASve_g_ob08H_100_LKASve_g_ob08H_100(tmpWrite_5);

  /* Outport: '<Root>/LKASve_g_ob08L_100' */
  (void) Rte_Write_LKASve_g_ob08L_100_LKASve_g_ob08L_100(tmpWrite_6);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S132>/Switch' incorporates:
   *  Constant: '<S141>/Constant'
   *  Constant: '<S142>/Constant'
   *  Delay: '<S132>/Delay'
   *  Gain: '<S132>/Gain'
   *  Logic: '<S132>/Logical Operator'
   *  RelationalOperator: '<S141>/Compare'
   *  RelationalOperator: '<S142>/Compare'
   *  Sum: '<S132>/Add'
   */
  if ((rtb_L0_Q >= ((uint8)2U)) && (rtb_R0_Q >= ((uint8)2U))) {
    rtb_IMAPve_g_Rrg_VR_Start_BACK = ((-1.0F) * rtb_Switch_i) + rtb_Switch_ha;
  } else {
    rtb_IMAPve_g_Rrg_VR_Start_BACK = LKAS_DW.Delay_DSTATE;
  }

  /* End of Switch: '<S132>/Switch' */

  /* Sum: '<S140>/Add1' incorporates:
   *  Memory: '<S140>/Memory'
   *  Product: '<S140>/Divide'
   *  Product: '<S140>/Divide1'
   */
  rtb_IMAPve_g_Rrg_VR_Start_BACK = (rtb_IMAPve_g_Rrg_VR_Start_BACK *
    LKAS_ConstB.Divide2_n) + (LKAS_ConstB.Add2_n *
    LKAS_DW.Memory_PreviousInput_i);

  /* Saturate: '<S132>/Saturation1' */
  if (rtb_IMAPve_g_Rrg_VR_Start_BACK > 5.5F) {
    rtb_Saturation1 = 5.5F;
  } else if (rtb_IMAPve_g_Rrg_VR_Start_BACK < 2.5F) {
    rtb_Saturation1 = 2.5F;
  } else {
    rtb_Saturation1 = rtb_IMAPve_g_Rrg_VR_Start_BACK;
  }

  /* End of Saturate: '<S132>/Saturation1' */

  /* Switch: '<S116>/Switch' incorporates:
   *  DataTypeConversion: '<S127>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_p = rtb_R0_Type;
  } else {
    rtb_R0_Type_p = rtb_L0_Type;
  }

  /* Switch: '<S116>/Switch1' incorporates:
   *  Constant: '<S124>/Constant'
   *  DataTypeConversion: '<S125>/Cast To Single5'
   *  Inport: '<Root>/IMAPve_d_L1_Q'
   *  Switch: '<S124>/Switch3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_k = rtb_L0_Type;
    Rte_Read_IMAPve_d_L1_Q_IMAPve_d_L1_Q(&tmpRead_1g);

    /* DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     */
    rtb_L0_Q = (uint8)tmpRead_1g;

    /* Switch: '<S118>/Switch1' incorporates:
     *  Constant: '<S118>/Constant1'
     */
    if (rtb_L0_Q >= ((uint8)2U)) {
      rtb_L1_Q = (uint16)((uint8)3U);
    } else {
      rtb_L1_Q = (uint16)rtb_L0_Q;
    }

    /* End of Switch: '<S118>/Switch1' */
  } else {
    rtb_L0_Type_k = rtb_R0_Type;
    rtb_L1_Q = ((uint16)0U);
  }

  /* Switch: '<S126>/Switch3' incorporates:
   *  Constant: '<S126>/Constant'
   *  Inport: '<Root>/IMAPve_d_R1_Q'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    Rte_Read_IMAPve_d_R1_Q_IMAPve_d_R1_Q(&tmpRead_1m);

    /* DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    rtb_L0_Q = (uint8)tmpRead_1m;

    /* Switch: '<S119>/Switch1' incorporates:
     *  Constant: '<S119>/Constant1'
     */
    if (rtb_L0_Q >= ((uint8)2U)) {
      rtb_R1_Q = (uint16)((uint8)3U);
    } else {
      rtb_R1_Q = (uint16)rtb_L0_Q;
    }

    /* End of Switch: '<S119>/Switch1' */
  } else {
    rtb_R1_Q = ((uint16)0U);
  }

  /* End of Switch: '<S126>/Switch3' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_R0_VR' */
  Rte_Read_IMAPve_g_R0_VR_IMAPve_g_R0_VR(&tmpRead_19);

  /* Inport: '<Root>/IMAPve_g_L0_VR' */
  Rte_Read_IMAPve_g_L0_VR_IMAPve_g_L0_VR(&tmpRead_14);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S116>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_VR_j = (float32)tmpRead_19;
  } else {
    rtb_R0_VR_j = (float32)tmpRead_14;
  }

  /* Switch: '<S116>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_d = (float32)tmpRead_14;
  } else {
    rtb_L0_VR_d = (float32)tmpRead_19;
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_R0_W' */
  Rte_Read_IMAPve_g_R0_W_IMAPve_g_R0_W(&tmpRead_1b);

  /* Inport: '<Root>/IMAPve_g_L0_W' */
  Rte_Read_IMAPve_g_L0_W_IMAPve_g_L0_W(&tmpRead_17);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S116>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_W_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_c = (float32)tmpRead_1b;
  } else {
    rtb_R0_W_c = (float32)tmpRead_17;
  }

  /* Switch: '<S116>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_W_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_c = (float32)tmpRead_17;
  } else {
    rtb_L0_W_c = (float32)tmpRead_1b;
  }

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_S_LCAWarning_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_S_LCAWarning'
   */
  Rte_Read_EWWWve_y_BSD_S_LCAWarning_EWWWve_y_BSD_S_LCAWarning
    (&rtb_EWWWve_y_BSD_S_LCAWarning);

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_S_LCWWorkingSt_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_S_LCWWorkingSt'
   */
  Rte_Read_EWWWve_y_BSD_S_LCWWorkingSt_EWWWve_y_BSD_S_LCWWorkingSt
    (&rtb_EWWWve_y_BSD_S_LCWWorkingSt);

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_LCAWarning_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_LCAWarning'
   */
  Rte_Read_EWWWve_y_BSD_LCAWarning_EWWWve_y_BSD_LCAWarning
    (&rtb_EWWWve_y_BSD_LCAWarning);

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_LCWWorkingSt_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_LCWWorkingSt'
   */
  Rte_Read_EWWWve_y_BSD_LCWWorkingSt_EWWWve_y_BSD_LCWWorkingSt
    (&rtb_EWWWve_y_BSD_LCWWorkingSt);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_Rrg_TYPE_BACK' */
  Rte_Read_IMAPve_d_Rrg_TYPE_BACK_IMAPve_d_Rrg_TYPE_BACK(&tmpRead_1z);

  /* Inport: '<Root>/IMAPve_d_Rrg_Q_BACK' */
  Rte_Read_IMAPve_d_Rrg_Q_BACK_IMAPve_d_Rrg_Q_BACK(&tmpRead_1y);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S115>/Cast To Single14' incorporates:
   *  Inport: '<Root>/IMAPve_g_Rrg_VR_End_BACK'
   */
  Rte_Read_IMAPve_g_Rrg_VR_End_BACK_IMAPve_g_Rrg_VR_End_BACK(&rtb_Rrg_VR);

  /* DataTypeConversion: '<S115>/Cast To Single12' incorporates:
   *  Inport: '<Root>/IMAPve_g_Rrg_VR_Start_BACK'
   */
  Rte_Read_IMAPve_g_Rrg_VR_Start_BACK_IMAPve_g_Rrg_VR_Start_BACK(&rtb_R1_VR_h);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_Rrg_C3_BACK' */
  Rte_Read_IMAPve_g_Rrg_C3_BACK_IMAPve_g_Rrg_C3_BACK(&tmpRead_1x);

  /* Inport: '<Root>/IMAPve_g_Rrg_C2_BACK' */
  Rte_Read_IMAPve_g_Rrg_C2_BACK_IMAPve_g_Rrg_C2_BACK(&tmpRead_1w);

  /* Inport: '<Root>/IMAPve_g_Rrg_C1_BACK' */
  Rte_Read_IMAPve_g_Rrg_C1_BACK_IMAPve_g_Rrg_C1_BACK(&tmpRead_1v);

  /* Inport: '<Root>/IMAPve_g_Rrg_C0_BACK' */
  Rte_Read_IMAPve_g_Rrg_C0_BACK_IMAPve_g_Rrg_C0_BACK(&tmpRead_1u);

  /* Inport: '<Root>/IMAPve_d_Lrg_TYPE_BACK' */
  Rte_Read_IMAPve_d_Lrg_TYPE_BACK_IMAPve_d_Lrg_TYPE_BACK(&tmpRead_1t);

  /* Inport: '<Root>/IMAPve_d_Lrg_Q_BACK' */
  Rte_Read_IMAPve_d_Lrg_Q_BACK_IMAPve_d_Lrg_Q_BACK(&tmpRead_1s);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S115>/Cast To Single6' incorporates:
   *  Inport: '<Root>/IMAPve_g_Lrg_VR_End_BACK'
   */
  Rte_Read_IMAPve_g_Lrg_VR_End_BACK_IMAPve_g_Lrg_VR_End_BACK(&rtb_Lrg_VR);

  /* DataTypeConversion: '<S115>/Cast To Single4' incorporates:
   *  Inport: '<Root>/IMAPve_g_Lrg_VR_Start_BACK'
   */
  Rte_Read_IMAPve_g_Lrg_VR_Start_BACK_IMAPve_g_Lrg_VR_Start_BACK(&rtb_R1_VR);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_Lrg_C3_BACK' */
  Rte_Read_IMAPve_g_Lrg_C3_BACK_IMAPve_g_Lrg_C3_BACK(&tmpRead_1r);

  /* Inport: '<Root>/IMAPve_g_Lrg_C2_BACK' */
  Rte_Read_IMAPve_g_Lrg_C2_BACK_IMAPve_g_Lrg_C2_BACK(&tmpRead_1q);

  /* Inport: '<Root>/IMAPve_g_Lrg_C1_BACK' */
  Rte_Read_IMAPve_g_Lrg_C1_BACK_IMAPve_g_Lrg_C1_BACK(&tmpRead_1p);

  /* Inport: '<Root>/IMAPve_g_Lrg_C0_BACK' */
  Rte_Read_IMAPve_g_Lrg_C0_BACK_IMAPve_g_Lrg_C0_BACK(&tmpRead_1o);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S115>/Cast To Single52' incorporates:
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  Rte_Read_IMAPve_g_R1_W_IMAPve_g_R1_W(&rtb_R1_W);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_R1_Type' */
  Rte_Read_IMAPve_d_R1_Type_IMAPve_d_R1_Type(&tmpRead_1n);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S115>/Cast To Single50' incorporates:
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  Rte_Read_IMAPve_g_R1_VR_IMAPve_g_R1_VR(&rtb_R1_VR_d);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_R1_C3' */
  Rte_Read_IMAPve_g_R1_C3_IMAPve_g_R1_C3(&tmpRead_1l);

  /* Inport: '<Root>/IMAPve_g_R1_C2' */
  Rte_Read_IMAPve_g_R1_C2_IMAPve_g_R1_C2(&tmpRead_1k);

  /* Inport: '<Root>/IMAPve_g_R1_C1' */
  Rte_Read_IMAPve_g_R1_C1_IMAPve_g_R1_C1(&tmpRead_1j);

  /* Inport: '<Root>/IMAPve_g_R1_C0' */
  Rte_Read_IMAPve_g_R1_C0_IMAPve_g_R1_C0(&tmpRead_1i);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S115>/Cast To Single74' incorporates:
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  Rte_Read_IMAPve_g_L1_W_IMAPve_g_L1_W(&rtb_L1_W);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_L1_Type' */
  Rte_Read_IMAPve_d_L1_Type_IMAPve_d_L1_Type(&tmpRead_1h);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S115>/Cast To Single78' incorporates:
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  Rte_Read_IMAPve_g_L1_VR_IMAPve_g_L1_VR(&rtb_L1_VR);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_L1_C3' */
  Rte_Read_IMAPve_g_L1_C3_IMAPve_g_L1_C3(&tmpRead_1f);

  /* Inport: '<Root>/IMAPve_g_L1_C2' */
  Rte_Read_IMAPve_g_L1_C2_IMAPve_g_L1_C2(&tmpRead_1e);

  /* Inport: '<Root>/IMAPve_g_L1_C1' */
  Rte_Read_IMAPve_g_L1_C1_IMAPve_g_L1_C1(&tmpRead_1d);

  /* Inport: '<Root>/IMAPve_g_L1_C0' */
  Rte_Read_IMAPve_g_L1_C0_IMAPve_g_L1_C0(&tmpRead_1c);

  /* Inport: '<Root>/IMAPve_d_obj_Num' */
  Rte_Read_IMAPve_d_obj_Num_IMAPve_d_obj_Num(&tmpRead_x);

  /* Inport: '<Root>/IMAPve_d_Fusion_Status' */
  Rte_Read_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status(&tmpRead_w);

  /* Inport: '<Root>/IMAPve_d_Sensor_Status' */
  Rte_Read_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status(&tmpRead_v);

  /* Inport: '<Root>/ADIAve_d_FuncFaultStatus' */
  Rte_Read_ADIAve_d_FuncFaultStatus_ADIAve_d_FuncFaultStatus(&tmpRead_t);

  /* Inport: '<Root>/IMAPve_d_TCU_TCU_Available' */
  Rte_Read_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available(&tmpRead_s);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  Rte_Read_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal
    (&rtb_IMAPve_g_EMS_RealPedal);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_BCM_HazardLamp_Switch' */
  Rte_Read_IMAPve_d_BCM_HazardLamp_Switch_IMAPve_d_BCM_HazardLamp_Switch
    (&tmpRead_q);

  /* Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid' */
  Rte_Read_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid(&tmpRead_k);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  Rte_Read_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    (&rtb_IMAPve_g_ESC_Brake_Press);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid' */
  Rte_Read_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid(&tmpRead_j);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  Rte_Read_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate
    (&rtb_IMAPve_g_ESC_UnYawRate);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid' */
  Rte_Read_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid(&tmpRead_i);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  Rte_Read_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate(&rtb_IMAPve_g_ESC_YawRate);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid' */
  Rte_Read_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid(&tmpRead_h);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  Rte_Read_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle(&rtb_IMAPve_g_SW_Angle);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag' */
  Rte_Read_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    (&tmpRead_g);

  /* Inport: '<Root>/IMAPve_d_EPS_ESA_State' */
  Rte_Read_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State(&tmpRead_f);

  /* Inport: '<Root>/IMAPve_d_EPS_Driver_Override' */
  Rte_Read_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override(&tmpRead_e);

  /* Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State' */
  Rte_Read_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    (&tmpRead_d);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  Rte_Read_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    (&rtb_IMAPve_g_EPS_LKA_Current);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_EPS_TrqLim_State' */
  Rte_Read_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State(&tmpRead_c);

  /* Inport: '<Root>/IMAPve_d_SWS_Failure_Status' */
  Rte_Read_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status(&tmpRead_b);

  /* Inport: '<Root>/IMAPve_d_SAS_Trim_State' */
  Rte_Read_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State(&tmpRead_a);

  /* Inport: '<Root>/IMAPve_d_SAS_Clb_State' */
  Rte_Read_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State(&tmpRead_9);

  /* Inport: '<Root>/IMAPve_d_EPS_Trq_State' */
  Rte_Read_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State(&tmpRead_8);

  /* Inport: '<Root>/IMAPve_d_MP5_Work_State' */
  Rte_Read_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State(&tmpRead_6);

  /* Inport: '<Root>/IMAPve_d_APA_AutoPark_WorkSt' */
  Rte_Read_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt(&tmpRead_5);

  /* Inport: '<Root>/IMAPve_d_ELK_Switch' */
  Rte_Read_IMAPve_d_ELK_Switch_IMAPve_d_ELK_Switch(&tmpRead_4);

  /* Inport: '<Root>/IMAPve_d_LDW_Warn_Mode' */
  Rte_Read_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode(&tmpRead_3);

  /* Inport: '<Root>/FDMMve_d_ElkFcnConf' */
  Rte_Read_FDMMve_d_ElkFcnConf_FDMMve_d_ElkFcnConf(&tmpRead_0);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Math: '<S108>/Mod1' incorporates:
   *  Constant: '<S108>/Constant7'
   */
  if (((sint32)((uint8)3U)) != 0) {
    rtb_Mod1 %= ((uint8)3U);
  }

  /* End of Math: '<S108>/Mod1' */

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' */
  rtb_R0_Q = (uint8)tmpRead_3;

  /* MinMax: '<S108>/Max1' */
  if (rtb_Mod1 > rtb_R0_Q) {
    rtb_LDW_Warn_Mode = rtb_Mod1;
  } else {
    rtb_LDW_Warn_Mode = rtb_R0_Q;
  }

  /* End of MinMax: '<S108>/Max1' */

  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single1'
   *  DataTypeConversion: '<S5>/Cast To Single1'
   */
  (void) Rte_Write_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)LKAS_ConstB.Vehicle_Lane_Display_c);

  /* Outport: '<Root>/LKASve_y_HMI_ELKPopupMessage' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single14'
   *  DataTypeConversion: '<S5>/Cast To Single16'
   */
  (void) Rte_Write_LKASve_y_HMI_ELKPopupMessage_LKASve_y_HMI_ELKPopupMessage
    ((UInt8)LKAS_ConstB.HMI_ELKPopupMessage_j);

  /* Outport: '<Root>/LKASve_y_HapticAlarmReq' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single15'
   *  DataTypeConversion: '<S5>/Cast To Single15'
   */
  (void) Rte_Write_LKASve_y_HapticAlarmReq_LKASve_y_HapticAlarmReq((UInt8)
    LKAS_ConstB.HapticAlarmReq_b);

  /* Outport: '<Root>/LKASve_y_ELK_Status_Display' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single16'
   *  DataTypeConversion: '<S5>/Cast To Single14'
   */
  (void) Rte_Write_LKASve_y_ELK_Status_Display_LKASve_y_ELK_Status_Display
    ((UInt8)LKAS_ConstB.ELK_Status_Display_o);

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single2'
   *  DataTypeConversion: '<S5>/Cast To Single2'
   */
  (void) Rte_Write_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)LKAS_ConstB.LDW_Status_Display_o);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single3'
   *  DataTypeConversion: '<S5>/Cast To Single3'
   */
  (void) Rte_Write_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)LKAS_ConstB.LKA_Status_Display_h);

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single4'
   *  DataTypeConversion: '<S5>/Cast To Single4'
   */
  (void) Rte_Write_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    LKAS_ConstB.LDW_Flag_l);

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single5'
   *  DataTypeConversion: '<S5>/Cast To Single5'
   */
  (void) Rte_Write_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning((UInt8)
    LKAS_ConstB.Hands_Off_Warning_l);

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single6'
   *  DataTypeConversion: '<S5>/Cast To Single6'
   */
  (void) Rte_Write_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)LKAS_ConstB.LKA_Action_Indication_j);

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single7'
   *  DataTypeConversion: '<S5>/Cast To Single7'
   */
  (void) Rte_Write_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status((UInt8)
    LKAS_ConstB.HMI_Popup_Status_g);

  /* DataTypeConversion: '<S1>/FDMMve_d_ElkFcnConf_1' */
  rtb_FDMMve_d_ElkFcnConf = (uint8)tmpRead_0;

  /* DataTypeConversion: '<S1>/IMAPve_d_APA_AutoPark_WorkSt_1' */
  rtb_IMAPve_d_APA_AutoPark_WorkS = (uint8)tmpRead_5;

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_Switch_1' */
  rtb_IMAPve_d_BCM_HazardLamp_Swi = (uint8)tmpRead_q;

  /* DataTypeConversion: '<S1>/IMAPve_d_ELK_Switch_1' */
  rtb_IMAPve_d_ELK_Switch = (uint8)tmpRead_4;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)tmpRead_e;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)tmpRead_f;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)tmpRead_d;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)tmpRead_g;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1' */
  rtb_IMAPve_d_EPS_TrqLim_State = (uint8)tmpRead_c;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1' */
  rtb_IMAPve_d_EPS_Trq_State = (uint8)tmpRead_8;

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1' */
  rtb_IMAPve_d_ESC_LatAcc_Valid = (uint8)tmpRead_h;

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1' */
  rtb_IMAPve_d_ESC_LonAcc_Valid = (uint8)tmpRead_j;

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1' */
  rtb_IMAPve_d_ESC_VehSpd_Valid = (uint8)tmpRead_k;

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1' */
  rtb_IMAPve_d_ESC_YawRate_Valid = (uint8)tmpRead_i;

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' */
  rtb_IMAPve_d_Fusion_Status = (uint8)tmpRead_w;

  /* DataTypeConversion: '<S115>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   */
  rtb_L1_Type = (uint8)tmpRead_1h;

  /* DataTypeConversion: '<S1>/IMAPve_d_Lrg_Q_BACK_1' */
  rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)tmpRead_1s;

  /* Switch: '<S120>/Switch1' incorporates:
   *  Constant: '<S120>/Constant1'
   */
  if (rtb_IMAPve_d_Rrg_TYPE_BACK >= ((uint8)2U)) {
    rtb_Lrg_Q = ((uint8)3U);
  } else {
    rtb_Lrg_Q = rtb_IMAPve_d_Rrg_TYPE_BACK;
  }

  /* End of Switch: '<S120>/Switch1' */

  /* DataTypeConversion: '<S115>/Cast To Single8' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_Lrg_TYPE_BACK_1'
   */
  rtb_Lrg_Type = (uint8)tmpRead_1t;

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' */
  rtb_IMAPve_d_MP5_Work_State = (uint8)tmpRead_6;

  /* DataTypeConversion: '<S115>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   */
  rtb_R1_Type = (uint8)tmpRead_1n;

  /* DataTypeConversion: '<S1>/IMAPve_d_Rrg_Q_BACK_1' */
  rtb_IMAPve_d_Rrg_TYPE_BACK = (uint8)tmpRead_1y;

  /* Switch: '<S122>/Switch1' incorporates:
   *  Constant: '<S122>/Constant1'
   */
  if (rtb_IMAPve_d_Rrg_TYPE_BACK >= ((uint8)2U)) {
    rtb_Rrg_Q = ((uint8)3U);
  } else {
    rtb_Rrg_Q = rtb_IMAPve_d_Rrg_TYPE_BACK;
  }

  /* End of Switch: '<S122>/Switch1' */

  /* DataTypeConversion: '<S115>/Cast To Single16' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_Rrg_TYPE_BACK_1'
   */
  rtb_Rrg_Type = (uint8)tmpRead_1z;

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1' */
  rtb_IMAPve_d_SAS_Clb_State = (uint8)tmpRead_9;

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1' */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)tmpRead_a;

  /* DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1' */
  rtb_IMAPve_d_SWS_Failure_Status = (uint8)tmpRead_b;

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' */
  rtb_IMAPve_d_Sensor_Status = (uint8)tmpRead_v;

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)tmpRead_s;

  /* DataTypeConversion: '<S1>/IMAPve_d_obj_Num_1' */
  rtb_IMAPve_d_obj_Num = (uint8)tmpRead_x;

  /* DataTypeConversion: '<S115>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  UnaryMinus: '<S115>/Unary Minus8'
   */
  rtb_L1_C0 = (float32)((T_M_Nm_Float32)(-tmpRead_1c));

  /* DataTypeConversion: '<S115>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  UnaryMinus: '<S115>/Unary Minus9'
   */
  rtb_L1_C1 = (float32)((T_M_Nm_Float32)(-tmpRead_1d));

  /* DataTypeConversion: '<S115>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  UnaryMinus: '<S115>/Unary Minus10'
   */
  rtb_L1_C2 = (float32)((T_M_Nm_Float32)(-tmpRead_1e));

  /* DataTypeConversion: '<S115>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  UnaryMinus: '<S115>/Unary Minus11'
   */
  rtb_L1_C3 = (float32)((T_M_Nm_Float32)(-tmpRead_1f));

  /* DataTypeConversion: '<S115>/Cast To Single2' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C0_BACK_1'
   *  UnaryMinus: '<S115>/Unary Minus18'
   */
  rtb_Lrg_C0 = (float32)((T_M_Nm_Float32)(-tmpRead_1o));

  /* DataTypeConversion: '<S115>/Cast To Single1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C1_BACK_1'
   *  UnaryMinus: '<S115>/Unary Minus19'
   */
  rtb_Lrg_C1 = (float32)((T_M_Nm_Float32)(-tmpRead_1p));

  /* DataTypeConversion: '<S115>/Cast To Single3' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C2_BACK_1'
   *  UnaryMinus: '<S115>/Unary Minus16'
   */
  rtb_Lrg_C2 = (float32)((T_M_Nm_Float32)(-tmpRead_1q));

  /* DataTypeConversion: '<S115>/Cast To Single5' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C3_BACK_1'
   *  UnaryMinus: '<S115>/Unary Minus17'
   */
  rtb_Lrg_C3 = (float32)((T_M_Nm_Float32)(-tmpRead_1r));

  /* DataTypeConversion: '<S115>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  UnaryMinus: '<S115>/Unary Minus14'
   */
  rtb_R1_C0 = (float32)((T_M_Nm_Float32)(-tmpRead_1i));

  /* DataTypeConversion: '<S115>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  UnaryMinus: '<S115>/Unary Minus15'
   */
  rtb_R1_C1 = (float32)((T_M_Nm_Float32)(-tmpRead_1j));

  /* DataTypeConversion: '<S115>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  UnaryMinus: '<S115>/Unary Minus12'
   */
  rtb_R1_C2 = (float32)((T_M_Nm_Float32)(-tmpRead_1k));

  /* DataTypeConversion: '<S115>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  UnaryMinus: '<S115>/Unary Minus13'
   */
  rtb_R1_C3 = (float32)((T_M_Nm_Float32)(-tmpRead_1l));

  /* DataTypeConversion: '<S115>/Cast To Single10' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C0_BACK_1'
   *  UnaryMinus: '<S115>/Unary Minus22'
   */
  rtb_Rrg_C0 = (float32)((T_M_Nm_Float32)(-tmpRead_1u));

  /* DataTypeConversion: '<S115>/Cast To Single9' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C1_BACK_1'
   *  UnaryMinus: '<S115>/Unary Minus23'
   */
  rtb_Rrg_C1 = (float32)((T_M_Nm_Float32)(-tmpRead_1v));

  /* DataTypeConversion: '<S115>/Cast To Single11' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C2_BACK_1'
   *  UnaryMinus: '<S115>/Unary Minus20'
   */
  rtb_Rrg_C2 = (float32)((T_M_Nm_Float32)(-tmpRead_1w));

  /* DataTypeConversion: '<S115>/Cast To Single13' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C3_BACK_1'
   *  UnaryMinus: '<S115>/Unary Minus21'
   */
  rtb_Rrg_C3 = (float32)((T_M_Nm_Float32)(-tmpRead_1x));

  /* MATLAB Function: '<S8>/ELK_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/ELK_Status_Display': '<S82>:1' */
  /* '<S82>:1:3' if stDACmode==2&&LKA_STATE~=6 */
  /* '<S82>:1:7' else */
  /* '<S82>:1:8' LKA_Status_Display=single(0); */
  rtb_LKA_Status_Display_e = 0.0F;

  /* MATLAB Function: '<S8>/HapticAlarmReq' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HapticAlarmReq': '<S86>:1' */
  /* '<S86>:1:2' if HandsOff==0 */
  /* '<S86>:1:3' Hands_Off_Warning= uint8(0); */
  rtb_Hands_Off_Warning_a = 0U;

  /* MATLAB Function: '<S8>/HMI_ELKPopupMessage' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_ELKPopupMessage': '<S83>:1' */
  /* '<S83>:1:2' if stDACmode==2&&LKA_STATE==6 */
  /* '<S83>:1:12' elseif stDACmode~=2&&stFaultCSyn==0 */
  /* '<S83>:1:13' HMI_Popup_Status=uint8(8); */
  rtb_HMI_Popup_Status_d = 8U;

  /* Switch: '<S664>/Switch1' incorporates:
   *  Constant: '<S664>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1_p != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1_p;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S664>/Switch1' */

  /* Switch: '<S664>/Switch15' incorporates:
   *  Constant: '<S664>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    rtb_LL_lStpLngth_C = LKAS_ConstB.DataTypeConversion21;
  } else {
    rtb_LL_lStpLngth_C = LL_lStpLngth_C;
  }

  /* End of Switch: '<S664>/Switch15' */

  /* Switch: '<S664>/Switch10' incorporates:
   *  Constant: '<S664>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22_j != 0.0F) {
    rtb_LL_DesDvt_C = LKAS_ConstB.DataTypeConversion22_j;
  } else {
    rtb_LL_DesDvt_C = LL_DesDvt_C;
  }

  /* End of Switch: '<S664>/Switch10' */

  /* Switch: '<S664>/Switch12' incorporates:
   *  Constant: '<S664>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S664>/Switch12' */

  /* Switch: '<S665>/Switch56' incorporates:
   *  Constant: '<S665>/LLSMConClb14'
   *
   * Block description for '<S665>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_m != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_m;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S665>/Switch56' */

  /* Switch: '<S665>/Switch51' incorporates:
   *  Constant: '<S665>/LLSMConClb15'
   *
   * Block description for '<S665>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_c != 0.0F) {
    rtb_LL_DvtComp_C_n = LKAS_ConstB.DataTypeConversion25_c;
  } else {
    rtb_LL_DvtComp_C_n = LL_DvtComp_C;
  }

  /* End of Switch: '<S665>/Switch51' */

  /* Switch: '<S665>/Switch52' incorporates:
   *  Constant: '<S665>/LLSMConClb16'
   *
   * Block description for '<S665>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36_c != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36_c;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S665>/Switch52' */

  /* Switch: '<S665>/Switch46' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_k != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_k;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S665>/Switch46' */

  /* Abs: '<S128>/Abs' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  Sum: '<S128>/Add2'
   *  UnaryMinus: '<S115>/Unary Minus2'
   *  UnaryMinus: '<S115>/Unary Minus6'
   */
  rtb_LftTTLC = fabsf((float32)(((float32)((T_M_Nm_Float32)(-tmpRead_13))) +
    ((float32)((T_M_Nm_Float32)(-tmpRead_18)))));

  /* Saturate: '<S128>/Saturation' */
  if (rtb_LftTTLC > 0.004F) {
    rtb_LftTTLC = 0.004F;
  } else {
    if (rtb_LftTTLC < 0.0F) {
      rtb_LftTTLC = 0.0F;
    }
  }

  /* End of Saturate: '<S128>/Saturation' */

  /* Update for Memory: '<S128>/Memory1' incorporates:
   *  MATLAB Function: '<S128>/get_roadside_offset'
   *  Memory: '<S128>/Memory'
   */
  LKAS_DW.Memory1_PreviousInput = fminf(0.5F, (((fminf(0.004F, rtb_LftTTLC) /
    0.004F) + 1.0F) * 0.2F) * (fminf(4.0F, LKAS_DW.Memory_PreviousInput_o) -
    2.0F));

  /* Update for Memory: '<S143>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_l = rtb_Switch;

  /* Update for Memory: '<S143>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Switch_i;

  /* Update for Memory: '<S128>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = rtb_Saturation1;

  /* Update for Memory: '<S135>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_f = rtb_Switch1;

  /* Update for Memory: '<S135>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = rtb_Switch_ha;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S149>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.LKA_Mode;
    LKAS_DW.Delay1_4_DSTATE = LKAS_DW.EPS_Control_i;

    /* Update for Delay: '<S148>/Delay' */
    LKAS_DW.Delay_DSTATE_c = LKAS_DW.LKASM_stLKAActvFlg;

    /* Update for Memory: '<S589>/Memory' */
    LKAS_DW.Memory_PreviousInput_bk = rtb_Saturation_h;

    /* Update for Delay: '<S149>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.LKASM_stLKAState;

    /* Update for Memory: '<S532>/Memory' */
    LKAS_DW.Memory_PreviousInput_bl = rtb_Saturation_hz;

    /* Update for UnitDelay: '<S464>/Delay Input1'
     *
     * Block description for '<S464>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_mo;

    /* Update for UnitDelay: '<S463>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_c = LKAS_DW.RelationalOperator_o;

    /* Update for UnitDelay: '<S426>/Delay Input1'
     *
     * Block description for '<S426>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_a = rtb_Compare_b0;

    /* Update for UnitDelay: '<S424>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_i = LKAS_DW.RelationalOperator_h;

    /* Update for UnitDelay: '<S425>/Delay Input1'
     *
     * Block description for '<S425>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_i = rtb_Compare_ld;

    /* Update for Memory: '<S391>/Memory' */
    LKAS_DW.Memory_PreviousInput_e = LKAS_DW.RelationalOperator_h;

    /* Update for Delay: '<S149>/Delay' */
    LKAS_DW.Delay_DSTATE_m = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S149>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.LDWSM_stLDWState;

    /* Update for Memory: '<S439>/Memory' */
    LKAS_DW.Memory_PreviousInput_gd = rtb_LDW_State;

    /* Update for Memory: '<S365>/Memory' */
    LKAS_DW.Memory_PreviousInput_g = rtb_Merge1_p;

    /* Update for Memory: '<S401>/Memory' */
    LKAS_DW.Memory_PreviousInput_gb = rtb_Merge1_n;

    /* Update for Memory: '<S601>/Memory' */
    LKAS_DW.Memory_PreviousInput_h = rtb_Saturation_i;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S147>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S176>/Memory' */
      LKAS_DW.Memory_PreviousInput_l = rtb_Saturation2_e;

      /* Update for Memory: '<S207>/Memory' */
      LKAS_DW.Memory_PreviousInput_pm = rtb_Saturation1_c;

      /* Update for Memory: '<S194>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_h = rtb_Saturation1_d2;

      /* Update for Memory: '<S206>/Memory' */
      LKAS_DW.Memory_PreviousInput_n = rtb_Saturation1_dc;

      /* Update for Memory: '<S208>/Memory' */
      LKAS_DW.Memory_PreviousInput_h3 = rtb_Saturation1_k5;

      /* Update for Memory: '<S203>/Memory' */
      LKAS_DW.Memory_PreviousInput_dj = rtb_Saturation1_b;

      /* Update for Memory: '<S191>/Memory' */
      LKAS_DW.Memory_PreviousInput_ae = rtb_Add_ja;

      /* Update for Memory: '<S177>/Memory' */
      LKAS_DW.Memory_PreviousInput_id = rtb_Saturation2_l;

      /* Update for Memory: '<S178>/Memory' */
      LKAS_DW.Memory_PreviousInput_g0 = rtb_Saturation2_ey;

      /* Update for UnitDelay: '<S180>/Delay Input1'
       *
       * Block description for '<S180>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_j = rtb_Compare_gy;

      /* Update for Memory: '<S178>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_o = rtb_Merge_ai;

      /* Update for Memory: '<S169>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_c = rtb_Saturation_li;

      /* Update for Memory: '<S270>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_n = rtb_Saturation_ny;

      /* Update for Memory: '<S253>/Memory' */
      LKAS_DW.Memory_PreviousInput_lt = rtb_Add1_l1;

      /* Update for UnitDelay: '<S251>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_f = rtb_Switch2_i;

      /* Update for Memory: '<S259>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_h = rtb_Saturation_c;

      /* Update for Memory: '<S265>/Memory' */
      LKAS_DW.Memory_PreviousInput_h4 = rtb_Saturation1_a;

      /* Update for UnitDelay: '<S269>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_d = rtb_Switch_ld;

      /* Update for Memory: '<S269>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_a = rtb_Saturation_f;

      /* Update for UnitDelay: '<S246>/Delay Input2'
       *
       * Block description for '<S246>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_g = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S246>/Memory' */
      LKAS_DW.Memory_PreviousInput_li = rtb_Saturation2_i;

      /* Update for Memory: '<S202>/Memory' */
      LKAS_DW.Memory_PreviousInput_ny = rtb_Add_jv;

      /* Update for Memory: '<S204>/Memory' */
      LKAS_DW.Memory_PreviousInput_nn = rtb_Saturation1_l;

      /* Update for Memory: '<S205>/Memory' */
      LKAS_DW.Memory_PreviousInput_hp = rtb_Saturation1_h;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S602>/Delay' */
    LKAS_DW.Delay_DSTATE_d = rtb_Switch8;

    /* Update for Delay: '<S603>/Delay' */
    LKAS_DW.Delay_DSTATE_a = rtb_Switch8_c;

    /* Update for Delay: '<S604>/Delay' */
    LKAS_DW.Delay_DSTATE_b = rtb_Switch8_j;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S658>/Delay Input2'
   *
   * Block description for '<S658>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_L0_C0_b;

  /* Update for Delay: '<S132>/Delay' */
  LKAS_DW.Delay_DSTATE = rtb_Saturation1;

  /* Update for Memory: '<S140>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = rtb_IMAPve_g_Rrg_VR_Start_BACK;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  {
    UInt32 tmpWrite;
    UInt32 tmpWrite_0;
    UInt32 tmpWrite_1;
    UInt32 tmpWrite_2;
    UInt32 tmpWrite_3;
    UInt32 tmpWrite_4;
    UInt32 tmpWrite_5;
    UInt32 tmpWrite_6;

    /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
     *  SubSystem: '<Root>/LKAS'
     */
    /* Start for Enabled SubSystem: '<S2>/LLOn' */
    /* Start for If: '<S439>/u1>=3|u1==1&u2==u3' */
    LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

    /* Start for Enabled SubSystem: '<S10>/LKA'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Start for If: '<S194>/If' */
    LKAS_DW.If_ActiveSubsystem = -1;

    /* Start for If: '<S268>/If' */
    LKAS_DW.If_ActiveSubsystem_i = -1;

    /* End of Start for SubSystem: '<S10>/LKA' */
    /* End of Start for SubSystem: '<S2>/LLOn' */
    /* Start for S-Function (scanunpack): '<S4>/CAN Unpack' incorporates:
     *  Outport: '<Root>/LKASve_g_ob5H_10'
     *  Outport: '<Root>/LKASve_g_ob5L_10'
     */

    /*-----------S-Function Block: <S4>/CAN Unpack -----------------*/

    /* Start for S-Function (scanunpack): '<S4>/CAN Unpack1' incorporates:
     *  Outport: '<Root>/LKASve_g_ob6H_10'
     *  Outport: '<Root>/LKASve_g_ob6L_10'
     */

    /*-----------S-Function Block: <S4>/CAN Unpack1 -----------------*/

    /* Start for S-Function (scanunpack): '<S4>/CAN Unpack2' incorporates:
     *  Outport: '<Root>/LKASve_g_ob07H_100'
     *  Outport: '<Root>/LKASve_g_ob07L_100'
     */

    /*-----------S-Function Block: <S4>/CAN Unpack2 -----------------*/

    /* Start for S-Function (scanunpack): '<S4>/CAN Unpack3' incorporates:
     *  Outport: '<Root>/LKASve_g_ob08H_100'
     *  Outport: '<Root>/LKASve_g_ob08L_100'
     */

    /*-----------S-Function Block: <S4>/CAN Unpack3 -----------------*/

    /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

    /* ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
     *  SubSystem: '<Root>/LKAS'
     */
    /* ConstCode for Constant: '<S2>/Version' */
    ob_LKA_Version = 220317.0F;

    /* End of ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

    /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
     *  SubSystem: '<Root>/LKAS'
     */
    /* InitializeConditions for Memory: '<S143>/Memory1' */
    LKAS_DW.Memory1_PreviousInput_l = (-1.75F);

    /* InitializeConditions for Memory: '<S143>/Memory' */
    LKAS_DW.Memory_PreviousInput = (-1.75F);

    /* InitializeConditions for Memory: '<S135>/Memory1' */
    LKAS_DW.Memory1_PreviousInput_f = 1.75F;

    /* InitializeConditions for Memory: '<S135>/Memory' */
    LKAS_DW.Memory_PreviousInput_b = 1.75F;

    /* InitializeConditions for Memory: '<S140>/Memory' */
    LKAS_DW.Memory_PreviousInput_i = 3.2F;

    /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
    /* InitializeConditions for Delay: '<S149>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);
    LKAS_DW.Delay1_4_DSTATE = ((uint8)0U);

    /* InitializeConditions for Delay: '<S148>/Delay' */
    LKAS_DW.Delay_DSTATE_c = ((uint8)0U);

    /* InitializeConditions for Memory: '<S589>/Memory' */
    LKAS_DW.Memory_PreviousInput_bk = 0.0F;

    /* InitializeConditions for Delay: '<S149>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

    /* InitializeConditions for Memory: '<S532>/Memory' */
    LKAS_DW.Memory_PreviousInput_bl = 0.0F;

    /* InitializeConditions for UnitDelay: '<S464>/Delay Input1'
     *
     * Block description for '<S464>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = false;

    /* InitializeConditions for UnitDelay: '<S463>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_c = false;

    /* InitializeConditions for UnitDelay: '<S426>/Delay Input1'
     *
     * Block description for '<S426>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_a = false;

    /* InitializeConditions for UnitDelay: '<S424>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_i = false;

    /* InitializeConditions for UnitDelay: '<S425>/Delay Input1'
     *
     * Block description for '<S425>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_i = false;

    /* InitializeConditions for Memory: '<S391>/Memory' */
    LKAS_DW.Memory_PreviousInput_e = false;

    /* InitializeConditions for Delay: '<S149>/Delay' */
    LKAS_DW.Delay_DSTATE_m = false;

    /* InitializeConditions for Delay: '<S149>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

    /* InitializeConditions for Memory: '<S439>/Memory' */
    LKAS_DW.Memory_PreviousInput_gd = ((uint8)0U);

    /* InitializeConditions for Memory: '<S365>/Memory' */
    LKAS_DW.Memory_PreviousInput_g = 0.0F;

    /* InitializeConditions for Memory: '<S401>/Memory' */
    LKAS_DW.Memory_PreviousInput_gb = 0.0F;

    /* InitializeConditions for Memory: '<S601>/Memory' */
    LKAS_DW.Memory_PreviousInput_h = 0.0F;

    /* InitializeConditions for Delay: '<S602>/Delay' */
    LKAS_DW.Delay_DSTATE_d = ((uint8)0U);

    /* InitializeConditions for Delay: '<S603>/Delay' */
    LKAS_DW.Delay_DSTATE_a = ((uint8)0U);

    /* InitializeConditions for Delay: '<S604>/Delay' */
    LKAS_DW.Delay_DSTATE_b = ((uint8)0U);

    /* SystemInitialize for Enabled SubSystem: '<S452>/ExitCount' */
    /* InitializeConditions for Memory: '<S460>/Memory' */
    LKAS_DW.Memory_PreviousInput_a = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S452>/ExitCount' */

    /* SystemInitialize for Enabled SubSystem: '<S453>/Sum Condition1' */
    /* InitializeConditions for Memory: '<S462>/Memory' */
    LKAS_DW.Memory_PreviousInput_d = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S453>/Sum Condition1' */

    /* SystemInitialize for Enabled SubSystem: '<S463>/Sum Condition1' */
    /* InitializeConditions for Memory: '<S467>/Memory' */
    LKAS_DW.Memory_PreviousInput_or = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S463>/Sum Condition1' */

    /* SystemInitialize for Enabled SubSystem: '<S391>/Count 0.2s' */
    /* InitializeConditions for Memory: '<S422>/Memory' */
    LKAS_DW.Memory_PreviousInput_kn = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S391>/Count 0.2s' */

    /* SystemInitialize for Enabled SubSystem: '<S391>/Count' */
    /* InitializeConditions for Memory: '<S421>/Memory' */
    LKAS_DW.Memory_PreviousInput_kd = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S391>/Count' */

    /* SystemInitialize for Enabled SubSystem: '<S424>/Sum Condition1' */
    /* InitializeConditions for Memory: '<S430>/Memory' */
    LKAS_DW.Memory_PreviousInput_gn = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S424>/Sum Condition1' */

    /* SystemInitialize for Enabled SubSystem: '<S392>/Sum Condition1' */
    /* InitializeConditions for Memory: '<S436>/Memory' */
    LKAS_DW.Memory_PreviousInput_kq = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S392>/Sum Condition1' */

    /* SystemInitialize for IfAction SubSystem: '<S439>/If Action Subsystem' */
    /* InitializeConditions for Memory: '<S469>/Memory' */
    LKAS_DW.Memory_PreviousInput_k = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S439>/If Action Subsystem' */

    /* SystemInitialize for Enabled SubSystem: '<S402>/Sum Condition' */
    /* InitializeConditions for Memory: '<S408>/Memory' */
    LKAS_DW.Memory_PreviousInput_ij = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S402>/Sum Condition' */

    /* SystemInitialize for Enabled SubSystem: '<S326>/Subsystem' */
    /* InitializeConditions for Memory: '<S330>/Memory' */
    LKAS_DW.Memory_PreviousInput_pl = ((uint16)0U);

    /* End of SystemInitialize for SubSystem: '<S326>/Subsystem' */

    /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* InitializeConditions for Memory: '<S176>/Memory' */
    LKAS_DW.Memory_PreviousInput_l = 0.0F;

    /* InitializeConditions for Memory: '<S207>/Memory' */
    LKAS_DW.Memory_PreviousInput_pm = ((uint16)0U);

    /* InitializeConditions for Memory: '<S194>/Memory1' */
    LKAS_DW.Memory1_PreviousInput_h = ((uint8)0U);

    /* InitializeConditions for Memory: '<S206>/Memory' */
    LKAS_DW.Memory_PreviousInput_n = ((uint16)0U);

    /* InitializeConditions for Memory: '<S208>/Memory' */
    LKAS_DW.Memory_PreviousInput_h3 = ((uint16)0U);

    /* InitializeConditions for Memory: '<S203>/Memory' */
    LKAS_DW.Memory_PreviousInput_dj = ((uint16)0U);

    /* InitializeConditions for Memory: '<S191>/Memory' */
    LKAS_DW.Memory_PreviousInput_ae = 0.0F;

    /* InitializeConditions for Memory: '<S177>/Memory' */
    LKAS_DW.Memory_PreviousInput_id = 0.0F;

    /* InitializeConditions for Memory: '<S178>/Memory' */
    LKAS_DW.Memory_PreviousInput_g0 = 0.0F;

    /* InitializeConditions for UnitDelay: '<S180>/Delay Input1'
     *
     * Block description for '<S180>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_j = false;

    /* InitializeConditions for Memory: '<S178>/Memory1' */
    LKAS_DW.Memory1_PreviousInput_o = false;

    /* InitializeConditions for Memory: '<S169>/Memory3' */
    LKAS_DW.Memory3_PreviousInput_c = 0.0F;

    /* InitializeConditions for Memory: '<S270>/Memory3' */
    LKAS_DW.Memory3_PreviousInput_n = 0.0F;

    /* InitializeConditions for Memory: '<S253>/Memory' */
    LKAS_DW.Memory_PreviousInput_lt = 0.0F;

    /* InitializeConditions for UnitDelay: '<S251>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_f = 0.0F;

    /* InitializeConditions for Memory: '<S259>/Memory3' */
    LKAS_DW.Memory3_PreviousInput_h = 0.0F;

    /* InitializeConditions for Memory: '<S265>/Memory' */
    LKAS_DW.Memory_PreviousInput_h4 = ((uint16)0U);

    /* InitializeConditions for UnitDelay: '<S269>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_d = 0.0F;

    /* InitializeConditions for Memory: '<S269>/Memory3' */
    LKAS_DW.Memory3_PreviousInput_a = 0.0F;

    /* InitializeConditions for UnitDelay: '<S246>/Delay Input2'
     *
     * Block description for '<S246>/Delay Input2':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput2_DSTATE_g = 0.0F;

    /* InitializeConditions for Memory: '<S246>/Memory' */
    LKAS_DW.Memory_PreviousInput_li = ((uint16)0U);

    /* InitializeConditions for Memory: '<S202>/Memory' */
    LKAS_DW.Memory_PreviousInput_ny = ((uint16)0U);

    /* InitializeConditions for Memory: '<S204>/Memory' */
    LKAS_DW.Memory_PreviousInput_nn = ((uint16)0U);

    /* InitializeConditions for Memory: '<S205>/Memory' */
    LKAS_DW.Memory_PreviousInput_hp = ((uint16)0U);

    /* SystemInitialize for Enabled SubSystem: '<S177>/Sum Condition1' */
    /* InitializeConditions for Memory: '<S179>/Memory' */
    LKAS_DW.Memory_PreviousInput_bi = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S177>/Sum Condition1' */

    /* SystemInitialize for Atomic SubSystem: '<S164>/Moving Standard Deviation2' */
    L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

    /* End of SystemInitialize for SubSystem: '<S164>/Moving Standard Deviation2' */

    /* SystemInitialize for Atomic SubSystem: '<S178>/Moving Standard Deviation1' */
    L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation1);

    /* End of SystemInitialize for SubSystem: '<S178>/Moving Standard Deviation1' */

    /* SystemInitialize for Enabled SubSystem: '<S178>/Sum Condition1' */
    LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_m);

    /* End of SystemInitialize for SubSystem: '<S178>/Sum Condition1' */

    /* SystemInitialize for Atomic SubSystem: '<S178>/Moving Standard Deviation2' */
    L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation2_e);

    /* End of SystemInitialize for SubSystem: '<S178>/Moving Standard Deviation2' */

    /* SystemInitialize for Enabled SubSystem: '<S178>/Sum Condition' */
    LKAS_SumCondition_Init(&LKAS_DW.SumCondition_c);

    /* End of SystemInitialize for SubSystem: '<S178>/Sum Condition' */

    /* SystemInitialize for Enabled SubSystem: '<S178>/Sum Condition2' */
    /* InitializeConditions for Memory: '<S187>/Memory' */
    LKAS_DW.Memory_PreviousInput_j = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S178>/Sum Condition2' */

    /* SystemInitialize for Enabled SubSystem: '<S164>/Sum Condition2' */
    /* InitializeConditions for Memory: '<S168>/Memory' */
    LKAS_DW.Memory_PreviousInput_ll = 0.0F;

    /* SystemInitialize for Outport: '<S168>/M3K' */
    LKAS_DW.Saturation3 = 1.0F;

    /* End of SystemInitialize for SubSystem: '<S164>/Sum Condition2' */

    /* SystemInitialize for IfAction SubSystem: '<S268>/If Action Subsystem' */
    /* InitializeConditions for UnitDelay: '<S278>/Delay Input1'
     *
     * Block description for '<S278>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_n = false;

    /* InitializeConditions for Memory: '<S274>/Memory' */
    LKAS_DW.Memory_PreviousInput_f = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S268>/If Action Subsystem' */

    /* SystemInitialize for IfAction SubSystem: '<S268>/If Action Subsystem1' */
    /* InitializeConditions for UnitDelay: '<S286>/Delay Input1'
     *
     * Block description for '<S286>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_h = false;

    /* InitializeConditions for Memory: '<S275>/Memory' */
    LKAS_DW.Memory_PreviousInput_oh = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S268>/If Action Subsystem1' */

    /* SystemInitialize for Merge: '<S268>/Merge' */
    LKAS_DW.Merge_e = 1.0F;

    /* SystemInitialize for Merge: '<S268>/Merge1' */
    LKAS_DW.Merge1 = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

    /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    /* SystemInitialize for Merge: '<S151>/Merge' */
    LKAS_DW.Merge_a = 0.0F;

    /* SystemInitialize for Enabled SubSystem: '<S151>/Sum Condition' */
    /* InitializeConditions for Memory: '<S155>/Memory' */
    LKAS_DW.Memory_PreviousInput_p = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S151>/Sum Condition' */
    /* End of SystemInitialize for SubSystem: '<S10>/LDW' */

    /* SystemInitialize for Enabled SubSystem: '<S472>/Sum Condition1' */
    LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1_i);

    /* End of SystemInitialize for SubSystem: '<S472>/Sum Condition1' */
    /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

    /* SystemInitialize for Enabled SubSystem: '<S653>/Subsystem' */
    /* InitializeConditions for Delay: '<S660>/Delay1' */
    LKAS_DW.Delay1_DSTATE = 0.0F;

    /* End of SystemInitialize for SubSystem: '<S653>/Subsystem' */

    /* SystemInitialize for Enabled SubSystem: '<S91>/Sum Condition1' */
    LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1);

    /* End of SystemInitialize for SubSystem: '<S91>/Sum Condition1' */

    /* SystemInitialize for Enabled SubSystem: '<S91>/Sum Condition2' */
    LKAS_SumCondition1_Init(&LKAS_DW.SumCondition2);

    /* End of SystemInitialize for SubSystem: '<S91>/Sum Condition2' */
    /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

    /* Outport: '<Root>/LKASve_g_ob5H_10' */
    (void) Rte_Write_LKASve_g_ob5H_10_LKASve_g_ob5H_10(tmpWrite);

    /* Outport: '<Root>/LKASve_g_ob5L_10' */
    (void) Rte_Write_LKASve_g_ob5L_10_LKASve_g_ob5L_10(tmpWrite_0);

    /* Outport: '<Root>/LKASve_g_ob6H_10' */
    (void) Rte_Write_LKASve_g_ob6H_10_LKASve_g_ob6H_10(tmpWrite_1);

    /* Outport: '<Root>/LKASve_g_ob6L_10' */
    (void) Rte_Write_LKASve_g_ob6L_10_LKASve_g_ob6L_10(tmpWrite_2);

    /* Outport: '<Root>/LKASve_g_ob07H_100' */
    (void) Rte_Write_LKASve_g_ob07H_100_LKASve_g_ob07H_100(tmpWrite_3);

    /* Outport: '<Root>/LKASve_g_ob07L_100' */
    (void) Rte_Write_LKASve_g_ob07L_100_LKASve_g_ob07L_100(tmpWrite_4);

    /* Outport: '<Root>/LKASve_g_ob08H_100' */
    (void) Rte_Write_LKASve_g_ob08H_100_LKASve_g_ob08H_100(tmpWrite_5);

    /* Outport: '<Root>/LKASve_g_ob08L_100' */
    (void) Rte_Write_LKASve_g_ob08L_100_LKASve_g_ob08L_100(tmpWrite_6);
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
