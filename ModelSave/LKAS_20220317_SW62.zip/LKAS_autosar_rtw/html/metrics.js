function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["LKAS_DW"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	size: 1280};
	 this.metricsArray.var["ob_LKA_Disable_Reason"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	size: 4};
	 this.metricsArray.var["ob_LKA_Fault_Reason"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	size: 4};
	 this.metricsArray.var["ob_LKA_LKADeactvCSyn"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	size: 4};
	 this.metricsArray.var["ob_LKA_Version"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	size: 4};
	 this.metricsArray.fcn["LKAMotionPlanningCalculationLKA"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["LKAS.c:LKAS_Normal"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS.c:LKAS_exit_internal_Normal"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem2"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem2_n"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem2_p"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem3"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem4"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem_c"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem_e"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem_g"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_LDW_State_Machine"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 1,
	stackTotal: 1};
	 this.metricsArray.fcn["LKAS_LDW_State_Machine_Reset"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_LKA_and_ELK_State_Machine"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 1,
	stackTotal: 1};
	 this.metricsArray.fcn["LKAS_MATLABFunction"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["LKAS_MovingStandardDeviation1"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 416,
	stackTotal: 416};
	 this.metricsArray.fcn["LKAS_MovingStandardDeviation2"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 408,
	stackTotal: 408};
	 this.metricsArray.fcn["LKAS_Ph1SWA"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_Ph2SWA"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_Ph3SWA"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_Ph3SWA_b"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SaturableGainLutSatGainLut"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["LKAS_SumCondition1"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["LKAS_SumCondition1_Disable"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition1_Init"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition1_Reset"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition_Disable"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition_Init"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition_Reset"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_ifaction"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_ifaction_l"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKA_and_ELK_State_Machine_Reset"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["L_MovingStandardDeviation1_Init"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["L_MovingStandardDeviation2_Init"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MovingStandardDeviation1_Reset"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MovingStandardDeviation2_Reset"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_ADIAve_d_FuncFaultStatus_ADIAve_d_FuncFaultStatus"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_ADIAve_g_ASWFaultStatus_ADIAve_g_ASWFaultStatus"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_ADIAve_g_BSWFaultStatus_ADIAve_g_BSWFaultStatus"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_EWWWve_y_BSD_LCAWarning_EWWWve_y_BSD_LCAWarning"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_EWWWve_y_BSD_LCWWorkingSt_EWWWve_y_BSD_LCWWorkingSt"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_EWWWve_y_BSD_S_LCAWarning_EWWWve_y_BSD_S_LCAWarning"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_EWWWve_y_BSD_S_LCWWorkingSt_EWWWve_y_BSD_S_LCWWorkingSt"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_FDMMve_d_ElkFcnConf_FDMMve_d_ElkFcnConf"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_d_obj_MotionStatus_IMAPva_d_obj_MotionStatus"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_d_obj_class_IMAPva_d_obj_class"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_d_obj_id_IMAPva_d_obj_id"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_d_obj_lane_IMAPva_d_obj_lane"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_d_obj_status_IMAPva_d_obj_status"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_acc_x_IMAPva_g_obj_acc_x"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_acc_y_IMAPva_g_obj_acc_y"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_length_IMAPva_g_obj_length"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_pos_var_x_IMAPva_g_obj_pos_var_x"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_pos_var_xy_IMAPva_g_obj_pos_var_xy"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_pos_var_y_IMAPva_g_obj_pos_var_y"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_pos_x_IMAPva_g_obj_pos_x"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_pos_y_IMAPva_g_obj_pos_y"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_vel_x_IMAPva_g_obj_vel_x"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_vel_y_IMAPva_g_obj_vel_y"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPva_g_obj_width_IMAPva_g_obj_width"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_BCM_HazardLamp_Switch_IMAPve_d_BCM_HazardLamp_Switch"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_ELK_Switch_IMAPve_d_ELK_Switch"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_L0_Q_IMAPve_d_L0_Q"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_L0_Type_IMAPve_d_L0_Type"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_L1_Q_IMAPve_d_L1_Q"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_L1_Type_IMAPve_d_L1_Type"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_Lrg_Q_BACK_IMAPve_d_Lrg_Q_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_Lrg_TYPE_BACK_IMAPve_d_Lrg_TYPE_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_R0_Q_IMAPve_d_R0_Q"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_R0_Type_IMAPve_d_R0_Type"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_R1_Q_IMAPve_d_R1_Q"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_R1_Type_IMAPve_d_R1_Type"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_Rrg_Q_BACK_IMAPve_d_Rrg_Q_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_Rrg_TYPE_BACK_IMAPve_d_Rrg_TYPE_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_d_obj_Num_IMAPve_d_obj_Num"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L0_C0_IMAPve_g_L0_C0"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L0_C1_IMAPve_g_L0_C1"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L0_C2_IMAPve_g_L0_C2"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L0_C3_IMAPve_g_L0_C3"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L0_VR_IMAPve_g_L0_VR"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L0_W_IMAPve_g_L0_W"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L1_C0_IMAPve_g_L1_C0"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L1_C1_IMAPve_g_L1_C1"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L1_C2_IMAPve_g_L1_C2"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L1_C3_IMAPve_g_L1_C3"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L1_VR_IMAPve_g_L1_VR"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_L1_W_IMAPve_g_L1_W"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Lrg_C0_BACK_IMAPve_g_Lrg_C0_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Lrg_C1_BACK_IMAPve_g_Lrg_C1_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Lrg_C2_BACK_IMAPve_g_Lrg_C2_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Lrg_C3_BACK_IMAPve_g_Lrg_C3_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Lrg_VR_End_BACK_IMAPve_g_Lrg_VR_End_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Lrg_VR_Start_BACK_IMAPve_g_Lrg_VR_Start_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R0_C0_IMAPve_g_R0_C0"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R0_C1_IMAPve_g_R0_C1"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R0_C2_IMAPve_g_R0_C2"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R0_C3_IMAPve_g_R0_C3"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R0_VR_IMAPve_g_R0_VR"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R0_W_IMAPve_g_R0_W"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R1_C0_IMAPve_g_R1_C0"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R1_C1_IMAPve_g_R1_C1"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R1_C2_IMAPve_g_R1_C2"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R1_C3_IMAPve_g_R1_C3"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R1_VR_IMAPve_g_R1_VR"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_R1_W_IMAPve_g_R1_W"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Rrg_C0_BACK_IMAPve_g_Rrg_C0_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Rrg_C1_BACK_IMAPve_g_Rrg_C1_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Rrg_C2_BACK_IMAPve_g_Rrg_C2_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Rrg_C3_BACK_IMAPve_g_Rrg_C3_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Rrg_VR_End_BACK_IMAPve_g_Rrg_VR_End_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_Rrg_VR_Start_BACK_IMAPve_g_Rrg_VR_Start_BACK"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_LKAS_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_ob07H_100_LKASve_g_ob07H_100"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_ob07L_100_LKASve_g_ob07L_100"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_ob08H_100_LKASve_g_ob08H_100"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_ob08L_100_LKASve_g_ob08L_100"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_ob5H_10_LKASve_g_ob5H_10"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_ob5L_10_LKASve_g_ob5L_10"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_ob6H_10_LKASve_g_ob6H_10"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_g_ob6L_10_LKASve_g_ob6L_10"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_ELK_Status_Display_LKASve_y_ELK_Status_Display"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_HMI_ELKPopupMessage_LKASve_y_HMI_ELKPopupMessage"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_HapticAlarmReq_LKASve_y_HapticAlarmReq"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_LKAS_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Runnable_LKAS_Init"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 32,
	stackTotal: 32};
	 this.metricsArray.fcn["Runnable_LKAS_Step"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 4014,
	stackTotal: 4430};
	 this.metricsArray.fcn["cosf"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabsf"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmaxf"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fminf"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sinf"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sqrtf"] = {file: "D:\\LKAS\\bin\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="LKAS_metrics.html">Global Memory: 1296(bytes) Maximum Stack: 4014(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
