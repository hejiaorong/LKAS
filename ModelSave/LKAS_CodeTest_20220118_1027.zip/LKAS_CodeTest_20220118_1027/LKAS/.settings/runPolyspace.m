polyspaceBugFinderNoDesktop('-options-file', 'D:\LKAS\bin\LKAS_CodeTest_20220118_1027\LKAS\.settings\options_command.txt', '-results-dir', 'D:\LKAS\bin\LKAS_CodeTest_20220118_1027\LKAS');
