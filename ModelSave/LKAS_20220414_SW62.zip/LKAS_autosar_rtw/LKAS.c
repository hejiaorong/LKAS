/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Apr 14 19:16:47 2022
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S143>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S143>/LKA_State_Machine' */
#define LKAS_IN_Fault_f                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_j      ((uint8)0U)
#define LKAS_IN_Normal_a               ((uint8)2U)
#define LKAS_IN_SysOff_m               ((uint8)2U)
#define LKAS_IN_SysOn_k                ((uint8)3U)
#define LKAS_IN_Unavailable_p          ((uint8)1U)
#define LKAS_IN_Unselected_n           ((uint8)2U)

/* Named constants for Chart: '<S111>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Exported data definition */

/* Definition for custom storage class: Default */
float32 ob_LKA_Disable_Reason;
uint32 ob_LKA_Fault_Reason;
float32 ob_LKA_LKADeactvCSyn;
float32 ob_LKA_Version;

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * System initialize for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S466>/Sum Condition1'
 */
void LKAS_SumCondition1_Init(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S99>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S466>/Sum Condition1'
 */
void LKAS_SumCondition1_Reset(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S99>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S466>/Sum Condition1'
 */
void LKAS_SumCondition1_Disable(boolean *rty_Out, DW_SumCondition1_LKAS_T
  *localDW)
{
  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' incorporates:
   *  EnablePort: '<S99>/state = reset'
   */
  /* Disable for Outport: '<S99>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */
  localDW->SumCondition1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S466>/Sum Condition1'
 */
void LKAS_SumCondition1(boolean rtu_statereset, float32 rtu_SampleTime, float32
  rtu_Sum, boolean *rty_Out, DW_SumCondition1_LKAS_T *localDW)
{
  float32 rtb_Saturation_f1;

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' incorporates:
   *  EnablePort: '<S99>/state = reset'
   */
  if (rtu_statereset) {
    if (!localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Reset(localDW);
      localDW->SumCondition1_MODE = true;
    }

    /* Sum: '<S99>/Add1' incorporates:
     *  Memory: '<S99>/Memory'
     */
    rtb_Saturation_f1 = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S99>/Saturation' */
    if (rtb_Saturation_f1 > 60.0F) {
      rtb_Saturation_f1 = 60.0F;
    } else {
      if (rtb_Saturation_f1 < 0.0F) {
        rtb_Saturation_f1 = 0.0F;
      }
    }

    /* End of Saturate: '<S99>/Saturation' */

    /* RelationalOperator: '<S99>/Relational Operator' */
    *rty_Out = (rtb_Saturation_f1 >= rtu_Sum);

    /* Update for Memory: '<S99>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_f1;
  } else {
    if (localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */
}

/*
 * Output and update for action system:
 *    '<S145>/If Action Subsystem2'
 *    '<S191>/If Action Subsystem3'
 *    '<S192>/If Action Subsystem3'
 *    '<S193>/If Action Subsystem3'
 *    '<S194>/If Action Subsystem3'
 *    '<S195>/If Action Subsystem3'
 *    '<S203>/If Action Subsystem3'
 *    '<S235>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S148>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S148>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/* System initialize for atomic system: '<S158>/Moving Standard Deviation2' */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S161>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S161>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* System reset for atomic system: '<S158>/Moving Standard Deviation2' */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S161>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S161>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* Output and update for atomic system: '<S158>/Moving Standard Deviation2' */
void LKAS_MovingStandardDeviation2(float32 rtu_In1, float32 *rty_Out2, float32
  *rty_Out1, DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_h;
  float32 rtb_Delay1_p;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_SumofElements;
  float32 rtb_TmpSignalConversionAtStanda[50];
  sint32 tmp;
  sint32 i;
  float32 rtb_Saturation_g;

  /* Delay: '<S161>/Delay' */
  rtb_Delay_h = localDW->Delay_DSTATE;

  /* Delay: '<S161>/Delay1' */
  rtb_Delay1_p = localDW->Delay1_DSTATE;

  /* Delay: '<S161>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S161>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S161>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S161>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S161>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S161>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S161>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S161>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S161>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S161>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S161>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S161>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S161>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S161>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S161>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S161>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S161>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S161>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S161>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S161>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S161>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S161>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S161>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S161>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S161>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S161>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S161>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S161>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S161>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S161>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S161>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S161>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S161>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S161>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S161>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S161>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S161>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S161>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S161>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S161>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S161>/Delay47' */
  rtb_SumofElements = localDW->Delay47_DSTATE;

  /* Delay: '<S161>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S161>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S161>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S161>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S161>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S161>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S161>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_h;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_p;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_SumofElements;

  /* Sum: '<S161>/Sum of Elements' */
  tmp = 0;
  rtb_Saturation_g = -0.0F;
  for (i = 0; i < 50; i++) {
    rtb_Saturation_g += rtb_TmpSignalConversionAtStanda[i];
  }

  rtb_SumofElements = rtb_Saturation_g;

  /* End of Sum: '<S161>/Sum of Elements' */

  /* Sum: '<S161>/Add2' incorporates:
   *  Constant: '<S161>/Constant'
   *  Memory: '<S161>/Memory3'
   */
  rtb_Saturation_g = (float32)((uint8)(((uint32)((uint8)1U)) + ((uint32)((uint8)
    localDW->Memory3_PreviousInput))));

  /* Saturate: '<S161>/Saturation' */
  if (rtb_Saturation_g > 50.0F) {
    rtb_Saturation_g = 50.0F;
  } else {
    if (rtb_Saturation_g < 1.0F) {
      rtb_Saturation_g = 1.0F;
    }
  }

  /* End of Saturate: '<S161>/Saturation' */

  /* Product: '<S161>/Divide' */
  *rty_Out2 = rtb_SumofElements / rtb_Saturation_g;

  /* S-Function (sdspstatfcns): '<S161>/Standard Deviation' incorporates:
   *  SignalConversion: '<S161>/TmpSignal ConversionAtStandard DeviationInport1'
   */
  while (tmp < 1) {
    localDW->StandardDeviation_AccVal = rtu_In1;
    localDW->StandardDeviation_SqData = rtu_In1 * rtu_In1;
    tmp = 1;
    for (i = 48; i >= 0; i--) {
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[tmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[tmp] *
        rtb_TmpSignalConversionAtStanda[tmp];
      tmp++;
    }

    *rty_Out1 = (localDW->StandardDeviation_SqData -
                 ((localDW->StandardDeviation_AccVal *
                   localDW->StandardDeviation_AccVal) / 50.0F)) / 49.0F;
    *rty_Out1 = sqrtf(fabsf(*rty_Out1));
    tmp = 1;
  }

  /* End of S-Function (sdspstatfcns): '<S161>/Standard Deviation' */

  /* Update for Delay: '<S161>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S161>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_h;

  /* Update for Delay: '<S161>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S161>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S161>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S161>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S161>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S161>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S161>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S161>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S161>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S161>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S161>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_p;

  /* Update for Delay: '<S161>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S161>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S161>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S161>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S161>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S161>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S161>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S161>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S161>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S161>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S161>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S161>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S161>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S161>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S161>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S161>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S161>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S161>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S161>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S161>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S161>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S161>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S161>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S161>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S161>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S161>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S161>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S161>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S161>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S161>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S161>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S161>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S161>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S161>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S161>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S161>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;

  /* Update for Memory: '<S161>/Memory3' */
  localDW->Memory3_PreviousInput = rtb_Saturation_g;
}

/*
 * Output and update for action system:
 *    '<S172>/If Action Subsystem3'
 *    '<S417>/If Action Subsystem3'
 *    '<S457>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S176>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * System initialize for atomic system:
 *    '<S172>/Moving Standard Deviation1'
 *    '<S172>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation1_Init(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S177>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S172>/Moving Standard Deviation1'
 *    '<S172>/Moving Standard Deviation2'
 */
void MovingStandardDeviation1_Reset(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S177>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S172>/Moving Standard Deviation1'
 *    '<S172>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation1(float32 rtu_In1,
  DW_MovingStandardDeviation1_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_d;
  float32 rtb_Delay1_f;
  float32 rtb_Delay10_e;
  float32 rtb_Delay11_a;
  float32 rtb_Delay12_j;
  float32 rtb_Delay13_a;
  float32 rtb_Delay14_e;
  float32 rtb_Delay15_h;
  float32 rtb_Delay16_g;
  float32 rtb_Delay17_m;
  float32 rtb_Delay18_k;
  float32 rtb_Delay19_e;
  float32 rtb_Delay2_e;
  float32 rtb_Delay20_g;
  float32 rtb_Delay21_g;
  float32 rtb_Delay22_b;
  float32 rtb_Delay23_g;
  float32 rtb_Delay24_n;
  float32 rtb_Delay25_f;
  float32 rtb_Delay26_l;
  float32 rtb_Delay27_k;
  float32 rtb_Delay28_f;
  float32 rtb_Delay29_p;
  float32 rtb_Delay3_g;
  float32 rtb_Delay30_c;
  float32 rtb_Delay31_n;
  float32 rtb_Delay32_c;
  float32 rtb_Delay33_n;
  float32 rtb_Delay34_a;
  float32 rtb_Delay35_a;
  float32 rtb_Delay36_n;
  float32 rtb_Delay37_l;
  float32 rtb_Delay38_f;
  float32 rtb_Delay39_p;
  float32 rtb_Delay4_e;
  float32 rtb_Delay40_o;
  float32 rtb_Delay41_a;
  float32 rtb_Delay42_p;
  float32 rtb_Delay43_o;
  float32 rtb_Delay44_b;
  float32 rtb_Delay45_e;
  float32 rtb_Delay46_a;
  float32 rtb_Delay48_f;
  float32 rtb_Delay5_m;
  float32 rtb_Delay6_k;
  float32 rtb_Delay7_j;
  float32 rtb_Delay8_m;
  float32 rtb_Delay9_j;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S177>/Delay' */
  rtb_Delay_d = localDW->Delay_DSTATE;

  /* Delay: '<S177>/Delay1' */
  rtb_Delay1_f = localDW->Delay1_DSTATE;

  /* Delay: '<S177>/Delay10' */
  rtb_Delay10_e = localDW->Delay10_DSTATE;

  /* Delay: '<S177>/Delay11' */
  rtb_Delay11_a = localDW->Delay11_DSTATE;

  /* Delay: '<S177>/Delay12' */
  rtb_Delay12_j = localDW->Delay12_DSTATE;

  /* Delay: '<S177>/Delay13' */
  rtb_Delay13_a = localDW->Delay13_DSTATE;

  /* Delay: '<S177>/Delay14' */
  rtb_Delay14_e = localDW->Delay14_DSTATE;

  /* Delay: '<S177>/Delay15' */
  rtb_Delay15_h = localDW->Delay15_DSTATE;

  /* Delay: '<S177>/Delay16' */
  rtb_Delay16_g = localDW->Delay16_DSTATE;

  /* Delay: '<S177>/Delay17' */
  rtb_Delay17_m = localDW->Delay17_DSTATE;

  /* Delay: '<S177>/Delay18' */
  rtb_Delay18_k = localDW->Delay18_DSTATE;

  /* Delay: '<S177>/Delay19' */
  rtb_Delay19_e = localDW->Delay19_DSTATE;

  /* Delay: '<S177>/Delay2' */
  rtb_Delay2_e = localDW->Delay2_DSTATE;

  /* Delay: '<S177>/Delay20' */
  rtb_Delay20_g = localDW->Delay20_DSTATE;

  /* Delay: '<S177>/Delay21' */
  rtb_Delay21_g = localDW->Delay21_DSTATE;

  /* Delay: '<S177>/Delay22' */
  rtb_Delay22_b = localDW->Delay22_DSTATE;

  /* Delay: '<S177>/Delay23' */
  rtb_Delay23_g = localDW->Delay23_DSTATE;

  /* Delay: '<S177>/Delay24' */
  rtb_Delay24_n = localDW->Delay24_DSTATE;

  /* Delay: '<S177>/Delay25' */
  rtb_Delay25_f = localDW->Delay25_DSTATE;

  /* Delay: '<S177>/Delay26' */
  rtb_Delay26_l = localDW->Delay26_DSTATE;

  /* Delay: '<S177>/Delay27' */
  rtb_Delay27_k = localDW->Delay27_DSTATE;

  /* Delay: '<S177>/Delay28' */
  rtb_Delay28_f = localDW->Delay28_DSTATE;

  /* Delay: '<S177>/Delay29' */
  rtb_Delay29_p = localDW->Delay29_DSTATE;

  /* Delay: '<S177>/Delay3' */
  rtb_Delay3_g = localDW->Delay3_DSTATE;

  /* Delay: '<S177>/Delay30' */
  rtb_Delay30_c = localDW->Delay30_DSTATE;

  /* Delay: '<S177>/Delay31' */
  rtb_Delay31_n = localDW->Delay31_DSTATE;

  /* Delay: '<S177>/Delay32' */
  rtb_Delay32_c = localDW->Delay32_DSTATE;

  /* Delay: '<S177>/Delay33' */
  rtb_Delay33_n = localDW->Delay33_DSTATE;

  /* Delay: '<S177>/Delay34' */
  rtb_Delay34_a = localDW->Delay34_DSTATE;

  /* Delay: '<S177>/Delay35' */
  rtb_Delay35_a = localDW->Delay35_DSTATE;

  /* Delay: '<S177>/Delay36' */
  rtb_Delay36_n = localDW->Delay36_DSTATE;

  /* Delay: '<S177>/Delay37' */
  rtb_Delay37_l = localDW->Delay37_DSTATE;

  /* Delay: '<S177>/Delay38' */
  rtb_Delay38_f = localDW->Delay38_DSTATE;

  /* Delay: '<S177>/Delay39' */
  rtb_Delay39_p = localDW->Delay39_DSTATE;

  /* Delay: '<S177>/Delay4' */
  rtb_Delay4_e = localDW->Delay4_DSTATE;

  /* Delay: '<S177>/Delay40' */
  rtb_Delay40_o = localDW->Delay40_DSTATE;

  /* Delay: '<S177>/Delay41' */
  rtb_Delay41_a = localDW->Delay41_DSTATE;

  /* Delay: '<S177>/Delay42' */
  rtb_Delay42_p = localDW->Delay42_DSTATE;

  /* Delay: '<S177>/Delay43' */
  rtb_Delay43_o = localDW->Delay43_DSTATE;

  /* Delay: '<S177>/Delay44' */
  rtb_Delay44_b = localDW->Delay44_DSTATE;

  /* Delay: '<S177>/Delay45' */
  rtb_Delay45_e = localDW->Delay45_DSTATE;

  /* Delay: '<S177>/Delay46' */
  rtb_Delay46_a = localDW->Delay46_DSTATE;

  /* Delay: '<S177>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S177>/Delay48' */
  rtb_Delay48_f = localDW->Delay48_DSTATE;

  /* Delay: '<S177>/Delay5' */
  rtb_Delay5_m = localDW->Delay5_DSTATE;

  /* Delay: '<S177>/Delay6' */
  rtb_Delay6_k = localDW->Delay6_DSTATE;

  /* Delay: '<S177>/Delay7' */
  rtb_Delay7_j = localDW->Delay7_DSTATE;

  /* Delay: '<S177>/Delay8' */
  rtb_Delay8_m = localDW->Delay8_DSTATE;

  /* Delay: '<S177>/Delay9' */
  rtb_Delay9_j = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S177>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_d;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_f;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2_e;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3_g;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4_e;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5_m;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6_k;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7_j;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8_m;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9_j;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10_e;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11_a;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12_j;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13_a;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14_e;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15_h;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16_g;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17_m;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18_k;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28_f;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19_e;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20_g;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21_g;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22_b;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23_g;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24_n;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25_f;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26_l;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27_k;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38_f;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29_p;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30_c;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31_n;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32_c;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33_n;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34_a;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35_a;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36_n;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37_l;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48_f;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39_p;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40_o;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41_a;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42_p;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43_o;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44_b;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45_e;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46_a;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S177>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S177>/Standard Deviation' */

  /* Update for Delay: '<S177>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S177>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_d;

  /* Update for Delay: '<S177>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9_j;

  /* Update for Delay: '<S177>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10_e;

  /* Update for Delay: '<S177>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11_a;

  /* Update for Delay: '<S177>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12_j;

  /* Update for Delay: '<S177>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13_a;

  /* Update for Delay: '<S177>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14_e;

  /* Update for Delay: '<S177>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15_h;

  /* Update for Delay: '<S177>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16_g;

  /* Update for Delay: '<S177>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17_m;

  /* Update for Delay: '<S177>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28_f;

  /* Update for Delay: '<S177>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_f;

  /* Update for Delay: '<S177>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19_e;

  /* Update for Delay: '<S177>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20_g;

  /* Update for Delay: '<S177>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21_g;

  /* Update for Delay: '<S177>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22_b;

  /* Update for Delay: '<S177>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23_g;

  /* Update for Delay: '<S177>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24_n;

  /* Update for Delay: '<S177>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25_f;

  /* Update for Delay: '<S177>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26_l;

  /* Update for Delay: '<S177>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18_k;

  /* Update for Delay: '<S177>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38_f;

  /* Update for Delay: '<S177>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2_e;

  /* Update for Delay: '<S177>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29_p;

  /* Update for Delay: '<S177>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30_c;

  /* Update for Delay: '<S177>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31_n;

  /* Update for Delay: '<S177>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32_c;

  /* Update for Delay: '<S177>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33_n;

  /* Update for Delay: '<S177>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34_a;

  /* Update for Delay: '<S177>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35_a;

  /* Update for Delay: '<S177>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36_n;

  /* Update for Delay: '<S177>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27_k;

  /* Update for Delay: '<S177>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48_f;

  /* Update for Delay: '<S177>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3_g;

  /* Update for Delay: '<S177>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39_p;

  /* Update for Delay: '<S177>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40_o;

  /* Update for Delay: '<S177>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41_a;

  /* Update for Delay: '<S177>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42_p;

  /* Update for Delay: '<S177>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43_o;

  /* Update for Delay: '<S177>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44_b;

  /* Update for Delay: '<S177>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45_e;

  /* Update for Delay: '<S177>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46_a;

  /* Update for Delay: '<S177>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37_l;

  /* Update for Delay: '<S177>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4_e;

  /* Update for Delay: '<S177>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5_m;

  /* Update for Delay: '<S177>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6_k;

  /* Update for Delay: '<S177>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7_j;

  /* Update for Delay: '<S177>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8_m;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S172>/Sum Condition'
 *    '<S172>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S179>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S172>/Sum Condition'
 *    '<S172>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S179>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S172>/Sum Condition'
 *    '<S172>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S172>/Sum Condition' incorporates:
   *  EnablePort: '<S179>/Enable'
   */
  /* Disable for Outport: '<S179>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S172>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S172>/Sum Condition'
 *    '<S172>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_px;

  /* Outputs for Enabled SubSystem: '<S172>/Sum Condition' incorporates:
   *  EnablePort: '<S179>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S179>/Add1' incorporates:
     *  Memory: '<S179>/Memory'
     */
    rtb_Saturation_px = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S179>/Saturation' */
    if (rtb_Saturation_px > 100.0F) {
      rtb_Saturation_px = 100.0F;
    } else {
      if (rtb_Saturation_px < 0.0F) {
        rtb_Saturation_px = 0.0F;
      }
    }

    /* End of Saturate: '<S179>/Saturation' */

    /* RelationalOperator: '<S179>/Relational Operator' */
    *rty_Out = (rtb_Saturation_px >= rtu_In1);

    /* Update for Memory: '<S179>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_px;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S172>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S191>/If Action Subsystem2'
 *    '<S191>/If Action Subsystem1'
 *    '<S192>/If Action Subsystem2'
 *    '<S192>/If Action Subsystem1'
 *    '<S193>/If Action Subsystem2'
 *    '<S193>/If Action Subsystem1'
 *    '<S194>/If Action Subsystem2'
 *    '<S194>/If Action Subsystem1'
 *    '<S195>/If Action Subsystem2'
 *    '<S195>/If Action Subsystem1'
 *    ...
 */
void LKAS_IfActionSubsystem2_m(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S205>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S196>/if action '
 *    '<S197>/if action '
 *    '<S198>/if action '
 *    '<S199>/if action '
 *    '<S200>/if action '
 *    '<S201>/if action '
 *    '<S202>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S219>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S235>/If Action Subsystem'
 *    '<S235>/If Action Subsystem4'
 *    '<S187>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S237>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system: '<S152>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S152>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  float32 K1K2Det_T1;
  float32 DelteSW0;
  float32 u;
  float32 KMax;
  float32 DelteSW1;
  float32 tmp;

  /* MATLAB Function: '<S183>/MATLABFunction1' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLABFunction1': '<S190>:1' */
  /* '<S190>:1:34' LDDir = K1K2Det_stLDDir; */
  /*     D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S190>:1:36' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_p * 0.0174532924F;

  /* '<S190>:1:37' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S190>:1:38' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S190>:1:39' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S190>:1:40' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S190>:1:41' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S190>:1:42' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_m / 3.6F;

  /* '<S190>:1:43' Kw= u/(L*(1+K*u*u)*i); */
  /* '<S190>:1:44' KMax = K1K2Det_dphiSWARMax/180*pi; */
  KMax = (LKAS_DW.MPInP_dphiSWARMax / 180.0F) * 3.14159274F;

  /* '<S190>:1:45' Delte_Psi1 = PrvwHdAg; */
  /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
  /* '<S190>:1:47' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
  u = ((-2.0F * LKAS_DW.In_ly) / (((u / (((((LKAS_DW.MPInP_StbFacm_SY * u) * u)
             + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_j) * LKAS_DW.LKA_StrRatio_C_d)) *
         LKAS_DW.MPInP_tiTTLCIni) * LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F *
    DelteSW0) / LKAS_DW.MPInP_tiTTLCIni);

  /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
  /* '<S190>:1:49' DelteSW1 = DelteSW0+K1*TTLC; */
  DelteSW1 = (u * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

  /* '<S190>:1:50' K1K2Det_T1 = TTLC; */
  K1K2Det_T1 = LKAS_DW.MPInP_tiTTLCIni;

  /* '<S190>:1:51' if ~(K1<abs(KMax) && K1>-abs(KMax)) */
  tmp = fabsf(KMax);
  if ((u >= tmp) || (u <= (-tmp))) {
    /*  ������ת������ */
    /* '<S190>:1:52' K1 = LDDir*KMax; */
    u = LKAS_DW.Merge * KMax;

    /* '<S190>:1:53' K1K2Det_T1 = max((-DelteSW0+sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1,(-DelteSW0-sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1); */
    KMax = sqrtf((DelteSW0 * DelteSW0) - ((2.0F * u) * LKAS_DW.In_ly));
    K1K2Det_T1 = fmaxf((KMax + (-DelteSW0)) / u, ((-DelteSW0) - KMax) / u);

    /* '<S190>:1:54' DelteSW1 = (K1*K1K2Det_T1+DelteSW0); */
    DelteSW1 = (u * K1K2Det_T1) + DelteSW0;
  }

  /* '<S190>:1:56' if LDDir>0 && K1<0 && DelteSW0>0 && Delte_Psi1<0 */
  if ((((LKAS_DW.Merge > 0.0F) && (u < 0.0F)) && (DelteSW0 > 0.0F)) &&
      (LKAS_DW.In_ly < 0.0F)) {
    /* '<S190>:1:57' K1 = single(0); */
    u = 0.0F;

    /* '<S190>:1:58' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S190>:1:59' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_ly) / DelteSW0;
  }

  /* '<S190>:1:61' if LDDir<0 && K1>0 && DelteSW0<0 && Delte_Psi1>0 */
  if ((((LKAS_DW.Merge < 0.0F) && (u > 0.0F)) && (DelteSW0 < 0.0F)) &&
      (LKAS_DW.In_ly > 0.0F)) {
    /* '<S190>:1:62' K1 = single(0); */
    u = 0.0F;

    /* '<S190>:1:63' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S190>:1:64' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_ly) / DelteSW0;
  }

  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S190>:1:67' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S190>:1:69' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = u * 57.2957802F;
  LKAS_DW.K1K2Det_T1 = K1K2Det_T1;

  /* End of MATLAB Function: '<S183>/MATLABFunction1' */
}

/*
 * Output and update for atomic system:
 *    '<S245>/Saturable Gain Lut (SatGainLut)'
 *    '<S245>/Saturable Gain Lut (SatGainLut)1'
 */
void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32 rtu_InputLimLwr,
  float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32 rtu_GainLimUpr,
  float32 *rty_Gain)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S248>:1' */
  /*  Function Name: Saturable Gain Lut */
  /*  */
  /*  Description:  */
  /*    Saturable Gain Lookup Table. */
  /*  */
  /*  Assumptions and Limitation: */
  /*    The data type of all inputs and output is single. */
  /*  */
  /*  Inputs: */
  /*    Input: */
  /*    InputLimLwr: */
  /*    InputLimUpr: */
  /*    GainLimLwr: */
  /*    GainLimUpr: */
  /*  */
  /*  Outputs: */
  /*    Gain: The result of Looking up table. */
  /*  $Revision: 1.0$ */
  /*  $Author: Zhang Jianwei$ */
  /*  $Date: January 27, 2019$ */
  /*  ________________________________________ */
  /* '<S248>:1:25' if Input <= InputLimLwr */
  if (rtu_Input <= rtu_InputLimLwr) {
    /* '<S248>:1:26' Gain = GainLimLwr; */
    *rty_Gain = rtu_GainLimLwr;
  } else if (rtu_Input >= rtu_InputLimUpr) {
    /* '<S248>:1:27' elseif Input >= InputLimUpr */
    /* '<S248>:1:28' Gain = GainLimUpr; */
    *rty_Gain = rtu_GainLimUpr;
  } else {
    /* '<S248>:1:29' else */
    /* '<S248>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
    /* '<S248>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
    *rty_Gain = (((rtu_Input - rtu_InputLimLwr) / (rtu_InputLimUpr -
      rtu_InputLimLwr)) * (rtu_GainLimUpr - rtu_GainLimLwr)) + rtu_GainLimLwr;
  }
}

/*
 * Output and update for action system:
 *    '<S252>/If Action Subsystem'
 *    '<S252>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_f(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S254>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S275>/if action '
 *    '<S276>/if action '
 *    '<S283>/if action '
 *    '<S284>/if action '
 */
void LKAS_ifaction_c(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S277>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S268>/If Action Subsystem'
 *    '<S269>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_n(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_k_T *localDW)
{
  uint16 rtb_Saturation1_ph;
  uint16 rtb_Saturation1_l3;

  /* Outputs for Enabled SubSystem: '<S268>/If Action Subsystem' incorporates:
   *  EnablePort: '<S273>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S275>/Add' incorporates:
     *  Constant: '<S275>/Constant'
     *  Memory: '<S275>/Memory'
     */
    rtb_Saturation1_ph = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S275>/Saturation1' */
    if (rtb_Saturation1_ph >= ((uint16)10000U)) {
      rtb_Saturation1_ph = ((uint16)10000U);
    }

    /* End of Saturate: '<S275>/Saturation1' */

    /* If: '<S275>/If' incorporates:
     *  Constant: '<S275>/Constant2'
     */
    if (rtb_Saturation1_ph <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S275>/if action ' incorporates:
       *  ActionPort: '<S277>/Action Port'
       */
      LKAS_ifaction_c(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S275>/if action ' */
    }

    /* End of If: '<S275>/If' */

    /* Sum: '<S276>/Add' incorporates:
     *  Constant: '<S276>/Constant'
     *  Memory: '<S276>/Memory'
     */
    rtb_Saturation1_l3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_e));

    /* Saturate: '<S276>/Saturation1' */
    if (rtb_Saturation1_l3 >= ((uint16)10000U)) {
      rtb_Saturation1_l3 = ((uint16)10000U);
    }

    /* End of Saturate: '<S276>/Saturation1' */

    /* If: '<S276>/If' incorporates:
     *  Constant: '<S276>/Constant2'
     */
    if (rtb_Saturation1_l3 == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S276>/if action ' incorporates:
       *  ActionPort: '<S278>/Action Port'
       */
      LKAS_ifaction_c(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S276>/if action ' */
    }

    /* End of If: '<S276>/If' */

    /* Update for Memory: '<S275>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_ph;

    /* Update for Memory: '<S276>/Memory' */
    localDW->Memory_PreviousInput_e = rtb_Saturation1_l3;
  }

  /* End of Outputs for SubSystem: '<S268>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S268>/If Action Subsystem2'
 *    '<S269>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_e(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S274>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S274>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S143>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_a = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_p = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c63_LKAS = 0U;
  LKAS_DW.is_c63_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.stLDWActvFlg = 0U;
  LKAS_DW.stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S143>/LDW_State_Machine'
 * Block description for: '<S143>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S143>/LDW_State_Machine'
   *
   * Block description for '<S143>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c63_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c63_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S336>:2' */
    LKAS_DW.is_c63_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S336>:1' */
    /* Transition: '<S336>:31' */
    LKAS_DW.is_SysOff_a = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S336>:30' */
    LKAS_DW.stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c63_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S336>:36' */
      tmp = !LKAS_DW.LDW_Fault;
      if (tmp && ((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)
             LKAS_DW.LKA_Mode_k) == 2))) {
        /* Transition: '<S336>:38' */
        /* Exit Internal 'Fault': '<S336>:36' */
        LKAS_DW.is_c63_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S336>:3' */
        /* Transition: '<S336>:77' */
        LKAS_DW.is_SysOn_p = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S336>:47' */
        LKAS_DW.stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.LKA_Mode_k) == 0) && tmp) {
        /* Transition: '<S336>:40' */
        /* Exit Internal 'Fault': '<S336>:36' */
        LKAS_DW.is_c63_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_a = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S336>:32' */
        LKAS_DW.stLDWState = 1U;
      } else {
        LKAS_DW.stLDWState = 6U;

        /* During 'LDWFault': '<S336>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S336>:1' */
      if (((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
            2)) && (LKAS_DW.LDW_Fault)) {
        /* Transition: '<S336>:39' */
        /* Exit Internal 'SysOff': '<S336>:1' */
        LKAS_DW.is_SysOff_a = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c63_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S336>:36' */
        /* Transition: '<S336>:75' */
        /* Entry 'LDWFault': '<S336>:73' */
        LKAS_DW.stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)
                   LKAS_DW.LKA_Mode_k) == 2)) {
        /* Transition: '<S336>:41' */
        /* Exit Internal 'SysOff': '<S336>:1' */
        LKAS_DW.is_SysOff_a = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c63_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S336>:3' */
        /* Transition: '<S336>:77' */
        LKAS_DW.is_SysOn_p = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S336>:47' */
        LKAS_DW.stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_a) == LKAS_IN_Unavailable) {
        LKAS_DW.stLDWState = 0U;

        /* During 'Unavailable': '<S336>:30' */
        if (((sint32)LKAS_DW.LKA_Mode_k) == 0) {
          /* Transition: '<S336>:35' */
          LKAS_DW.is_SysOff_a = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S336>:32' */
          LKAS_DW.stLDWState = 1U;
        }
      } else {
        LKAS_DW.stLDWState = 1U;

        /* During 'Unselected': '<S336>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S336>:3' */
      if (LKAS_DW.LDW_Fault) {
        /* Transition: '<S336>:37' */
        /* Exit Internal 'SysOn': '<S336>:3' */
        if (((uint32)LKAS_DW.is_SysOn_p) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S336>:102' */
          switch (LKAS_DW.is_Normal_m) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S336>:114' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S336>:115' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_p = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_p = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c63_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S336>:36' */
        /* Transition: '<S336>:75' */
        /* Entry 'LDWFault': '<S336>:73' */
        LKAS_DW.stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode_k) != 1) && (((sint32)
                   LKAS_DW.LKA_Mode_k) != 2)) {
        /* Transition: '<S336>:42' */
        /* Exit Internal 'SysOn': '<S336>:3' */
        if (((uint32)LKAS_DW.is_SysOn_p) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S336>:102' */
          switch (LKAS_DW.is_Normal_m) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S336>:114' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S336>:115' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_p = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_p = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c63_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_a = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S336>:32' */
        LKAS_DW.stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_p) == LKAS_IN_LDWSelected) {
        LKAS_DW.stLDWState = 2U;

        /* During 'LDWSelected': '<S336>:47' */
        if ((LKAS_DW.Merge_pz) && (!LKAS_DW.Merge1_jp)) {
          /* Transition: '<S336>:50' */
          LKAS_DW.is_SysOn_p = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S336>:102' */
          /* Transition: '<S336>:113' */
          LKAS_DW.is_Normal_m = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S336>:112' */
          LKAS_DW.stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S336>:102' */
        if (LKAS_DW.Merge1_jp) {
          /* Transition: '<S336>:44' */
          /* Exit Internal 'Normal': '<S336>:102' */
          switch (LKAS_DW.is_Normal_m) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S336>:114' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S336>:115' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_m = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_p = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S336>:47' */
          LKAS_DW.stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_m) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.stLDWState = 3U;

            /* During 'LDWEnable': '<S336>:112' */
            if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.LKA_Fault))
            {
              /* Transition: '<S336>:118' */
              LKAS_DW.is_Normal_m = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S336>:114' */
              LKAS_DW.stLDWState = 4U;
              LKAS_DW.stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S336>:119' */
                LKAS_DW.is_Normal_m = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S336>:115' */
                LKAS_DW.stLDWState = 5U;
                LKAS_DW.stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.stLDWState = 4U;

            /* During 'LDWLeftActive': '<S336>:114' */
            if (LKAS_DW.LKA_Fault) {
              /* Transition: '<S336>:116' */
              /* Exit 'LDWLeftActive': '<S336>:114' */
              LKAS_DW.stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_m = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S336>:112' */
              LKAS_DW.stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S336>:120' */
                /* Exit 'LDWLeftActive': '<S336>:114' */
                LKAS_DW.is_Normal_m = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S336>:115' */
                LKAS_DW.stLDWState = 5U;
                LKAS_DW.stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.stLDWState = 5U;

            /* During 'LDWRightActive': '<S336>:115' */
            if (LKAS_DW.LKA_Fault) {
              /* Transition: '<S336>:117' */
              /* Exit 'LDWRightActive': '<S336>:115' */
              LKAS_DW.stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_m = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S336>:112' */
              LKAS_DW.stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S336>:121' */
                /* Exit 'LDWRightActive': '<S336>:115' */
                LKAS_DW.is_Normal_m = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S336>:114' */
                LKAS_DW.stLDWState = 4U;
                LKAS_DW.stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S143>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S143>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_active_c64_LKAS = 0U;
  LKAS_DW.is_c64_LKAS = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.stLKAActvFlg = 0U;
  LKAS_DW.stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S143>/LKA_State_Machine'
 * Block description for: '<S143>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S143>/LKA_State_Machine'
   *
   * Block description for '<S143>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  if (((uint32)LKAS_DW.is_active_c64_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    LKAS_DW.is_active_c64_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    /* Transition: '<S337>:2' */
    LKAS_DW.is_c64_LKAS = LKAS_IN_SysOff_m;

    /* Entry Internal 'SysOff': '<S337>:1' */
    /* Transition: '<S337>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_p;

    /* Entry 'Unavailable': '<S337>:30' */
    LKAS_DW.stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c64_LKAS) {
     case LKAS_IN_Fault_f:
      /* During 'Fault': '<S337>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.LKA_Mode_k) == 2)) {
        /* Transition: '<S337>:38' */
        /* Exit Internal 'Fault': '<S337>:36' */
        LKAS_DW.is_c64_LKAS = LKAS_IN_SysOn_k;

        /* Entry Internal 'SysOn': '<S337>:3' */
        /* Transition: '<S337>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S337>:19' */
        LKAS_DW.stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.LKA_Mode_k) == 0) || (((sint32)
                    LKAS_DW.LKA_Mode_k) == 1)) && tmp) {
        /* Transition: '<S337>:40' */
        /* Exit Internal 'Fault': '<S337>:36' */
        LKAS_DW.is_c64_LKAS = LKAS_IN_SysOff_m;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_n;

        /* Entry 'Unselected': '<S337>:32' */
        LKAS_DW.stLKAState = 1U;
      } else {
        LKAS_DW.stLKAState = 6U;

        /* During 'LKAFault': '<S337>:72' */
      }
      break;

     case LKAS_IN_SysOff_m:
      /* During 'SysOff': '<S337>:1' */
      if ((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S337>:39' */
        /* Exit Internal 'SysOff': '<S337>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
        LKAS_DW.is_c64_LKAS = LKAS_IN_Fault_f;

        /* Entry Internal 'Fault': '<S337>:36' */
        /* Transition: '<S337>:74' */
        /* Entry 'LKAFault': '<S337>:72' */
        LKAS_DW.stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode_k) == 2) {
        /* Transition: '<S337>:41' */
        /* Exit Internal 'SysOff': '<S337>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
        LKAS_DW.is_c64_LKAS = LKAS_IN_SysOn_k;

        /* Entry Internal 'SysOn': '<S337>:3' */
        /* Transition: '<S337>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S337>:19' */
        LKAS_DW.stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_p) {
        LKAS_DW.stLKAState = 0U;

        /* During 'Unavailable': '<S337>:30' */
        if ((((sint32)LKAS_DW.LKA_Mode_k) == 0) || (((sint32)LKAS_DW.LKA_Mode_k)
             == 1)) {
          /* Transition: '<S337>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_n;

          /* Entry 'Unselected': '<S337>:32' */
          LKAS_DW.stLKAState = 1U;
        }
      } else {
        LKAS_DW.stLKAState = 1U;

        /* During 'Unselected': '<S337>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S337>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S337>:37' */
        /* Exit Internal 'SysOn': '<S337>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_a) {
          /* Exit Internal 'Normal': '<S337>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S337>:109' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S337>:110' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        }

        LKAS_DW.is_c64_LKAS = LKAS_IN_Fault_f;

        /* Entry Internal 'Fault': '<S337>:36' */
        /* Transition: '<S337>:74' */
        /* Entry 'LKAFault': '<S337>:72' */
        LKAS_DW.stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode_k) != 2) {
        /* Transition: '<S337>:42' */
        /* Exit Internal 'SysOn': '<S337>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_a) {
          /* Exit Internal 'Normal': '<S337>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S337>:109' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S337>:110' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        }

        LKAS_DW.is_c64_LKAS = LKAS_IN_SysOff_m;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_n;

        /* Entry 'Unselected': '<S337>:32' */
        LKAS_DW.stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.stLKAState = 2U;

        /* During 'LKASelected': '<S337>:19' */
        if ((LKAS_DW.Merge1_a) && (!LKAS_DW.Merge2)) {
          /* Transition: '<S337>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_a;

          /* Entry Internal 'Normal': '<S337>:102' */
          /* Transition: '<S337>:103' */
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S337>:108' */
          LKAS_DW.stLKAState = 3U;
        }
      } else {
        /* During 'Normal': '<S337>:102' */
        if (LKAS_DW.Merge2) {
          /* Transition: '<S337>:25' */
          /* Exit Internal 'Normal': '<S337>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S337>:109' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S337>:110' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

          /* Entry 'LKASelected': '<S337>:19' */
          LKAS_DW.stLKAState = 2U;
        } else {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKAEnable:
            LKAS_DW.stLKAState = 3U;

            /* During 'LKAEnable': '<S337>:108' */
            if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_j)) {
              /* Transition: '<S337>:105' */
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

              /* Entry 'LKALeftActive': '<S337>:109' */
              LKAS_DW.stLKAState = 4U;
              LKAS_DW.stLKAActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_j))
              {
                /* Transition: '<S337>:104' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S337>:110' */
                LKAS_DW.stLKAState = 5U;
                LKAS_DW.stLKAActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LKALeftActive:
            LKAS_DW.stLKAState = 4U;

            /* During 'LKALeftActive': '<S337>:109' */
            if (LKAS_DW.Merge1_j) {
              /* Transition: '<S337>:106' */
              /* Exit 'LKALeftActive': '<S337>:109' */
              LKAS_DW.stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S337>:108' */
              LKAS_DW.stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_j))
              {
                /* Transition: '<S337>:111' */
                /* Exit 'LKALeftActive': '<S337>:109' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S337>:110' */
                LKAS_DW.stLKAState = 5U;
                LKAS_DW.stLKAActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.stLKAState = 5U;

            /* During 'LKARightActive': '<S337>:110' */
            if (LKAS_DW.Merge1_j) {
              /* Transition: '<S337>:107' */
              /* Exit 'LKARightActive': '<S337>:110' */
              LKAS_DW.stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S337>:108' */
              LKAS_DW.stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_j))
              {
                /* Transition: '<S337>:112' */
                /* Exit 'LKARightActive': '<S337>:110' */
                LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

                /* Entry 'LKALeftActive': '<S337>:109' */
                LKAS_DW.stLKAState = 4U;
                LKAS_DW.stLKAActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S143>/LKA_State_Machine' */
}

/*
 * Output and update for action system:
 *    '<S358>/Ph1SWA'
 *    '<S367>/Ph1SWA'
 *    '<S394>/Ph1SWA'
 *    '<S404>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S362>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S362>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S358>/Ph2SWA'
 *    '<S367>/Ph2SWA'
 *    '<S394>/Ph2SWA'
 *    '<S404>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S363>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S363>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S358>/Ph3SWA'
 *    '<S394>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S364>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S367>/Ph3SWA'
 *    '<S404>/Ph3SWA'
 */
void LKAS_Ph3SWA_d(float32 *rty_Out)
{
  /* SignalConversion: '<S373>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S373>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S430>/If Action Subsystem4'
 *    '<S430>/If Action Subsystem3'
 *    '<S540>/If Action Subsystem3'
 *    '<S540>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S442>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S442>/Constant'
   */
  *rty_Out = false;
}

/*
 * System initialize for enable system:
 *    '<S445>/ExitCount'
 *    '<S445>/ExitCount1'
 */
void LKAS_ExitCount_Init(DW_ExitCount_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S453>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S445>/ExitCount'
 *    '<S445>/ExitCount1'
 */
void LKAS_ExitCount_Reset(DW_ExitCount_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S453>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S445>/ExitCount'
 *    '<S445>/ExitCount1'
 */
void LKAS_ExitCount_Disable(boolean *rty_Out, DW_ExitCount_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S445>/ExitCount' incorporates:
   *  EnablePort: '<S453>/Enable'
   */
  /* Disable for Outport: '<S453>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S445>/ExitCount' */
  localDW->ExitCount_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S445>/ExitCount'
 *    '<S445>/ExitCount1'
 */
void LKAS_ExitCount(boolean rtu_Enable, float32 rtu_SampleTime, float32
                    rtu_ExitTime, boolean *rty_Out, DW_ExitCount_LKAS_T *localDW)
{
  float32 rtb_Saturation_iz;

  /* Outputs for Enabled SubSystem: '<S445>/ExitCount' incorporates:
   *  EnablePort: '<S453>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->ExitCount_MODE) {
      LKAS_ExitCount_Reset(localDW);
      localDW->ExitCount_MODE = true;
    }

    /* Sum: '<S453>/Add' incorporates:
     *  Memory: '<S453>/Memory'
     */
    rtb_Saturation_iz = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S453>/Saturation' */
    if (rtb_Saturation_iz > 60.0F) {
      rtb_Saturation_iz = 60.0F;
    } else {
      if (rtb_Saturation_iz < 0.0F) {
        rtb_Saturation_iz = 0.0F;
      }
    }

    /* End of Saturate: '<S453>/Saturation' */

    /* RelationalOperator: '<S453>/Relational Operator' */
    *rty_Out = (rtb_Saturation_iz >= rtu_ExitTime);

    /* Update for Memory: '<S453>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_iz;
  } else {
    if (localDW->ExitCount_MODE) {
      LKAS_ExitCount_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S445>/ExitCount' */
}

/*
 * Output and update for action system:
 *    '<S466>/If Action Subsystem'
 *    '<S466>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_b(boolean *rty_Out)
{
  /* SignalConversion: '<S470>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S470>/Constant'
   */
  *rty_Out = true;
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPva_g_obj_acc_x[40];
  float32 rtb_IMAPva_g_obj_acc_y[40];
  float32 rtb_IMAPva_g_obj_length[40];
  float32 rtb_IMAPva_g_obj_pos_var_x[40];
  float32 rtb_IMAPva_g_obj_pos_var_xy[40];
  float32 rtb_IMAPva_g_obj_pos_var_y[40];
  float32 rtb_IMAPva_g_obj_pos_x[40];
  float32 rtb_IMAPva_g_obj_pos_y[40];
  float32 rtb_IMAPva_g_obj_vel_x[40];
  float32 rtb_IMAPva_g_obj_vel_y[40];
  float32 rtb_IMAPva_g_obj_width[40];
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_ESC_VehSpd;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_Gain_j;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_Gain_js;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_MAX_DELAY_EPSSTAR_TIME;
  float32 rtb_LL_HandsOff_ExitTime;
  float32 rtb_LL_LFClb_TFC_KpVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KpVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KpV1_C;
  float32 rtb_LL_LFClb_TFC_KpV2_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KdV1_C;
  float32 rtb_LL_LFClb_TFC_KdV2_C;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LL_HandsOff_WarnTime;
  float32 rtb_LL_HandsOff_TextTime;
  float32 rtb_R0_VR_p;
  float32 rtb_L0_VR_b;
  float32 rtb_R0_W_f;
  float32 rtb_L0_W_f;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_R1_VR;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_VR_i;
  float32 rtb_R1_W;
  float32 rtb_R1_VR_d;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_lStpLngth_C;
  float32 rtb_LL_DesDvt_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_i;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1;
  float32 rtb_phiHdAg_Lft;
  float32 rtb_Add5_j;
  float32 rtb_phiHdAg_Rgt;
  float32 rtb_Add_a;
  float32 rtb_Add_l;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_Merge;
  float32 rtb_Switch_e;
  float32 rtb_Saturation_f;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Switch_g;
  float32 rtb_Switch2_n;
  float32 rtb_Switch_l;
  float32 rtb_Saturation_e;
  float32 rtb_Abs1_a;
  float32 rtb_Abs_m;
  float32 rtb_UnaryMinus_i;
  float32 rtb_Divide_gr;
  float32 rtb_Merge1;
  float32 rtb_Divide_i;
  float32 rtb_Switch_j;
  float32 rtb_Switch2_l;
  float32 rtb_Divide_gw;
  float32 rtb_Switch_o;
  float32 rtb_Switch2_lf;
  float32 rtb_Merge1_b;
  float32 rtb_Divide_gj;
  float32 rtb_Switch_jg;
  float32 rtb_Switch2_g;
  float32 rtb_Divide_h;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_j;
  float32 rtb_Multiply;
  float32 rtb_Switch_m;
  float32 rtb_Switch2_p;
  float32 rtb_Memory;
  float32 rtb_Merge1_c;
  float32 rtb_Divide_m;
  float32 rtb_Switch_lm;
  float32 rtb_Switch2_nd;
  float32 rtb_Divide_l;
  float32 rtb_Switch_h;
  float32 rtb_Switch2_b;
  float32 rtb_Memory_g;
  float32 rtb_Merge1_d;
  float32 rtb_Divide_hq;
  float32 rtb_Switch_jy;
  float32 rtb_Switch2_pe;
  float32 rtb_Divide_e;
  float32 rtb_Switch_b;
  float32 rtb_Switch2_e;
  float32 rtb_Saturation_j;
  float32 rtb_Divide_d;
  float32 rtb_Divide_k;
  float32 rtb_Add_ny;
  float32 rtb_Add_cg;
  float32 rtb_phiHdAg;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_LKA_Enable_Line;
  float32 rtb_Saturation2_l;
  float32 rtb_Add1_cj;
  float32 rtb_Merge_o;
  float32 rtb_Gain_c;
  float32 rtb_Gain1_c;
  float32 rtb_Add_hu;
  float32 rtb_Add_lk;
  float32 rtb_Saturation6;
  float32 rtb_Saturation2_la;
  float32 rtb_Saturation2_d;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_fc;
  float32 rtb_Saturation_h;
  float32 rtb_Add1_d3;
  float32 rtb_kphtomps_m;
  float32 rtb_Saturation_em;
  float32 rtb_Switch2_h;
  float32 rtb_Switch_i5;
  float32 rtb_Switch2_bi;
  float32 rtb_Gain1_cj;
  float32 rtb_Switch_gk;
  float32 rtb_Switch2_i;
  float32 rtb_Divide5_a;
  float32 rtb_Divide2_hw;
  float32 rtb_Merge_k;
  float32 rtb_Switch_hl;
  float32 rtb_Switch2_nk;
  float32 rtb_Divide7;
  float32 rtb_Switch_bv;
  float32 rtb_Switch2_gi;
  float32 rtb_Saturation_fj;
  float32 rtb_Switch_n0;
  float32 rtb_Add_jv;
  float32 rtb_Switch_iy;
  float32 rtb_Switch2_es;
  float32 rtb_UkYk1_g;
  float32 rtb_Switch_a;
  float32 rtb_Switch2_jc;
  float32 rtb_Abs1_m;
  float32 rtb_Abs_ml;
  float32 rtb_Add1_ie;
  float32 rtb_Merge_i;
  float32 rtb_Merge_g;
  float32 rtb_Merge_ks;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_n2;
  float32 rtb_Saturation_p;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_In;
  float32 rtb_In_i;
  float32 rtb_In_g;
  float32 rtb_Plan;
  float32 rtb_T1_h;
  float32 rtb_Plan_g;
  float32 rtb_T1_f;
  float32 rtb_Gain_pi;
  float32 rtb_Merge_g1;
  float32 rtb_kphTomps_p;
  float32 rtb_Divide3_b;
  float32 rtb_Gain2_k;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_l;
  uint16 rtb_Saturation1_p;
  uint16 rtb_Saturation1_pr;
  uint16 rtb_Saturation1_b;
  uint16 rtb_Saturation1_pb;
  uint16 rtb_Saturation2_g;
  uint16 rtb_Add_m5;
  uint16 rtb_Saturation1_d;
  uint16 rtb_Saturation1_c;
  uint8 rtb_IMAPva_d_obj_MotionStatus[40];
  uint8 rtb_IMAPva_d_obj_class[40];
  uint8 rtb_IMAPva_d_obj_id[40];
  uint8 rtb_IMAPva_d_obj_lane[40];
  uint8 rtb_IMAPva_d_obj_status[40];
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_o;
  uint8 rtb_L0_Type_k;
  uint8 rtb_EWWWve_y_BSD_LCAWarning;
  uint8 rtb_EWWWve_y_BSD_LCWWorkingSt;
  uint8 rtb_EWWWve_y_BSD_S_LCAWarning;
  uint8 rtb_EWWWve_y_BSD_S_LCWWorkingSt;
  uint8 rtb_FDMMve_d_ElkFcnConf;
  uint8 rtb_IMAPve_d_APA_AutoPark_WorkS;
  uint8 rtb_IMAPve_d_BCM_HazardLamp_Swi;
  uint8 rtb_IMAPve_d_ELK_Switch;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_EPS_TrqLim_State;
  uint8 rtb_IMAPve_d_EPS_Trq_State;
  uint8 rtb_IMAPve_d_ESC_VehSpd_Valid;
  uint8 rtb_IMAPve_d_ESC_YawRate_Valid;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L1_Type;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_R1_Type;
  uint8 rtb_IMAPve_d_SAS_Clb_State;
  uint8 rtb_IMAPve_d_SAS_Trim_State;
  uint8 rtb_IMAPve_d_SWS_Failure_Status;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_IMAPve_d_obj_Num;
  uint8 rtb_LDW_State;
  uint8 rtb_Switch8;
  uint8 rtb_Switch8_h;
  uint8 rtb_Switch8_e;
  uint8 rtb_LKA_Mode;
  uint8 rtb_Saturation1_k;
  boolean rtb_LogicalOperator2;
  boolean rtb_ADIA_DTC_EMS_14B_InvOorReal;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxT;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinT;
  boolean rtb_ADIAve_e_Node_ACU_Validity;
  boolean rtb_ADIAve_e_Node_EPB_Validity;
  boolean rtb_ADIA_Inner_FRadar_FaultStat;
  boolean rtb_ADIAve_d_sen_sta_Corner_rad;
  boolean rtb_ADIAve_e_Node_EMS_Validity;
  boolean rtb_ADIAve_e_Node_IC_Validity;
  boolean rtb_ADIAve_e_Node_TBOX_Validity;
  boolean rtb_ADIA_DTC_ESC_EPBErrorStatus;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorTCS;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorVeh;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorLat;
  boolean rtb_ADIA_DTC_MP5_366_OorAEBButt;
  boolean rtb_ADIA_DTC_MP5_366_OorFCWButt;
  boolean rtb_ADIA_DTC_SAS_A5_InvOorSteAn;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorLon;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorSta;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorYaw;
  boolean rtb_ADIA_DTC_ESC6_123_InvOorDyn;
  boolean rtb_ADIA_DTC_ESC6_123_InvUnfilY;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehDri;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehHol;
  boolean rtb_ADIA_DTC_GW_MP5_413_OorISAM;
  boolean rtb_ADIA_DTC_SCC_309_OorACCButt;
  boolean rtb_ADIA_DTC_TCU1_93_InvOorGear;
  boolean rtb_ADIA_DTC_BCM3_33C_InvBrkLig;
  boolean rtb_ADIA_DTC_EMS_14A_OorACCStat;
  boolean rtb_ADIA_DTC_EMS10_88_InvAccPed;
  boolean rtb_ADIA_DTC_EMS5_E0_InvOorBrkP;
  boolean rtb_ADIA_DTC_EMS5_E0_OorEngineS;
  boolean rtb_LogicalOperator3_i;
  boolean rtb_OR_p;
  boolean rtb_Compare_f2;
  boolean rtb_UnitDelay_e;
  boolean rtb_Merge_m;
  boolean rtb_Compare_nn;
  boolean rtb_UnitDelay_d;
  boolean rtb_Compare_mh;
  boolean rtb_Merge_oy;
  boolean rtb_Merge_j;
  boolean rtb_Compare_h2;
  boolean rtb_LogicalOperator1_ma;
  boolean rtb_RelationalOperator6_g;
  boolean rtb_RelationalOperator5;
  boolean rtb_Compare_nye;
  boolean rtb_Memory1_c;
  boolean rtb_Merge_c;
  boolean rtb_LKA_Main_Switch;
  boolean rtb_LKA_Switch;
  float32 x10;
  float32 x20;
  float32 x1;
  const UInt16 *tmpIRead;
  const T_M_Nm_Float32 *tmpIRead_0;
  const T_M_Nm_Float32 *tmpIRead_1;
  const T_M_Nm_Float32 *tmpIRead_2;
  const T_M_Nm_Float32 *tmpIRead_3;
  const T_M_Nm_Float32 *tmpIRead_4;
  const T_M_Nm_Float32 *tmpIRead_5;
  const T_M_Nm_Float32 *tmpIRead_6;
  const T_M_Nm_Float32 *tmpIRead_7;
  const T_M_Nm_Float32 *tmpIRead_8;
  const T_M_Nm_Float32 *tmpIRead_9;
  const T_M_Nm_Float32 *tmpIRead_a;
  const UInt16 *tmpIRead_b;
  const UInt16 *tmpIRead_c;
  const UInt16 *tmpIRead_d;
  const UInt16 *tmpIRead_e;
  uint8 rtb_FDMMve_d_LkaFcnConf;
  uint8 rtb_IMAPve_d_LKA_Mode;
  uint8 rtb_IMAPve_d_LDW_Warn_Mode;
  float32 rtb_Abs_ka;
  float32 rtb_L0_C0;
  float32 rtb_R0_C0;
  uint8 rtb_R0_Q_c;
  float32 rtb_SW_Angle;
  boolean rtb_BCM_Left_Light;
  boolean rtb_BCM_Right_Light;
  uint8 rtb_TCU_ActualGear;
  uint8 rtb_HMI_Popup_Status_f;
  uint8 rtb_LKA_Action_Indication_m;
  float32 rtb_R0_C2;
  uint8 rtb_L0_Q;
  uint8 rtb_Lrg_Q;
  boolean rtb_LFlg;
  uint8 rtb_Rrg_Q;
  boolean rtb_RFlg;
  float32 rtb_L0_C0_g;
  float32 rtb_R0_C0_j;
  float32 rtb_L0_C0_c;
  float32 rtb_L0_C1_h5;
  float32 rtb_R0_C1_g;
  float32 rtb_L0_C1_c;
  float32 rtb_L0_C2_f;
  float32 rtb_L0_C3;
  float32 rtb_R0_C3;
  float32 rtb_L0_C3_i;
  float32 rtb_R0_C2_b;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_LKA_LatestWarnLine_C;
  float32 rtb_LL_LKA_EnableLine_Max;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  float32 rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  boolean rtb_LL_SingleLane_Disable_Swt;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LFClb_TFC_KdBalance_C;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LL_LKAExPrcs_tiExitDelayTim;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_LKA_CarWidth;
  float32 rtb_Abs_d;
  float32 rtb_Abs_f;
  float32 rtb_TTLC_o;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_f;
  boolean rtb_LogicalOperator3_o;
  boolean rtb_RelationalOperator_n;
  boolean rtb_LogicalOperator_e;
  boolean rtb_Compare_av;
  boolean rtb_Compare_kq;
  boolean rtb_LogicalOperator_gy;
  boolean rtb_Compare_lg;
  boolean rtb_LogicalOperator_ez;
  boolean rtb_Compare_cy;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_kj;
  boolean rtb_stDvrTkConFlg_n;
  boolean rtb_LogicalOperator_ac;
  boolean rtb_LogicalOperator_lm;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge_g2;
  uint32 rtb_Add;
  uint8 rtb_L0_Type;
  uint16 rtb_Saturation_a;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  float32 rtb_TTLC;
  float32 rtb_TLft;
  uint8 rtb_L1_Q_a;
  sint32 i;
  float32 rtb_Abs_d_tmp;
  float32 rtb_Add5_j_tmp;
  float32 rtb_Abs1_tmp;
  float32 rtb_LogicalOperator3_c_tmp;
  float32 rtb_LogicalOperator3_c_tmp_0;
  float32 rtb_LogicalOperator3_c_tmp_1;
  float32 rtb_LogicalOperator3_c_tmp_2;
  float32 rtb_Add_a_tmp;
  float32 rtb_Add_l_tmp;
  boolean exitg1;

  /* Inport: '<Root>/IMAPva_d_obj_MotionStatus' */
  tmpIRead_e =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_MotionStatus_IMAPva_d_obj_MotionStatus
    ();

  /* Inport: '<Root>/IMAPva_d_obj_status' */
  tmpIRead_d =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_status_IMAPva_d_obj_status();

  /* Inport: '<Root>/IMAPva_d_obj_lane' */
  tmpIRead_c = Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_lane_IMAPva_d_obj_lane();

  /* Inport: '<Root>/IMAPva_d_obj_class' */
  tmpIRead_b =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_class_IMAPva_d_obj_class();

  /* Inport: '<Root>/IMAPva_g_obj_length' */
  tmpIRead_a =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_length_IMAPva_g_obj_length();

  /* Inport: '<Root>/IMAPva_g_obj_width' */
  tmpIRead_9 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_width_IMAPva_g_obj_width();

  /* Inport: '<Root>/IMAPva_g_obj_pos_var_xy' */
  tmpIRead_8 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_var_xy_IMAPva_g_obj_pos_var_xy
    ();

  /* Inport: '<Root>/IMAPva_g_obj_pos_var_y' */
  tmpIRead_7 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_var_y_IMAPva_g_obj_pos_var_y();

  /* Inport: '<Root>/IMAPva_g_obj_pos_var_x' */
  tmpIRead_6 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_var_x_IMAPva_g_obj_pos_var_x();

  /* Inport: '<Root>/IMAPva_g_obj_acc_y' */
  tmpIRead_5 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_acc_y_IMAPva_g_obj_acc_y();

  /* Inport: '<Root>/IMAPva_g_obj_acc_x' */
  tmpIRead_4 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_acc_x_IMAPva_g_obj_acc_x();

  /* Inport: '<Root>/IMAPva_g_obj_vel_y' */
  tmpIRead_3 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_vel_y_IMAPva_g_obj_vel_y();

  /* Inport: '<Root>/IMAPva_g_obj_vel_x' */
  tmpIRead_2 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_vel_x_IMAPva_g_obj_vel_x();

  /* Inport: '<Root>/IMAPva_g_obj_pos_y' */
  tmpIRead_1 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_y_IMAPva_g_obj_pos_y();

  /* Inport: '<Root>/IMAPva_g_obj_pos_x' */
  tmpIRead_0 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_x_IMAPva_g_obj_pos_x();

  /* Inport: '<Root>/IMAPva_d_obj_id' */
  tmpIRead = Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_id_IMAPva_d_obj_id();

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPva_d_obj_MotionStatus_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_MotionStatus[i] = (uint8)tmpIRead_e[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_MotionStatus_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_class_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_class[i] = (uint8)tmpIRead_b[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_class_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_id_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_id[i] = (uint8)tmpIRead[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_id_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_lane_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_lane[i] = (uint8)tmpIRead_c[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_lane_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_status_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_status[i] = (uint8)tmpIRead_d[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_status_1' */

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_acc_x_1' */
  memcpy(&rtb_IMAPva_g_obj_acc_x[0], &tmpIRead_4[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_acc_y_1' */
  memcpy(&rtb_IMAPva_g_obj_acc_y[0], &tmpIRead_5[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_length_1' */
  memcpy(&rtb_IMAPva_g_obj_length[0], &tmpIRead_a[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_var_x_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_var_x[0], &tmpIRead_6[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_var_xy_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_var_xy[0], &tmpIRead_8[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_var_y_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_var_y[0], &tmpIRead_7[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_x_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_x[0], &tmpIRead_0[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_y_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_y[0], &tmpIRead_1[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_vel_x_1' */
  memcpy(&rtb_IMAPva_g_obj_vel_x[0], &tmpIRead_2[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_vel_y_1' */
  memcpy(&rtb_IMAPva_g_obj_vel_y[0], &tmpIRead_3[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_width_1' */
  memcpy(&rtb_IMAPva_g_obj_width[0], &tmpIRead_9[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/FDMMve_d_LkaFcnConf_1' incorporates:
   *  Inport: '<Root>/FDMMve_d_LkaFcnConf'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf();

  /* DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LKA_Mode'
   */
  rtb_IMAPve_d_LKA_Mode = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode();

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LDW_Warn_Mode'
   */
  rtb_IMAPve_d_LDW_Warn_Mode = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode();

  /* MATLAB Function: '<S104>/MATLAB Function' incorporates:
   *  DataTypeConversion: '<S104>/Cast To Boolean'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  Inport: '<Root>/IMAPve_d_LKA_Main_Switch'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsMP5Info/MATLAB Function': '<S139>:1' */
  /* '<S139>:1:2' LKA_Switch = (LkaFcnConf > 0 || LKA_Main_Switch_In > 0); */
  rtb_LFlg = ((((sint32)rtb_FDMMve_d_LkaFcnConf) > 0) || (((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch
    ())) != 0));
  rtb_LKA_Switch = rtb_LFlg;

  /* '<S139>:1:3' LKA_Main_Switch = LKA_Switch; */
  rtb_LKA_Main_Switch = rtb_LFlg;

  /* '<S139>:1:5' if LDW_Warn_Mode_In == 2 || LkaFcnConf == 3 || LkaFcnConf == 6 || LkaFcnConf == 9 || LkaFcnConf == 12 */
  if (((((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 2) || (((sint32)
           rtb_FDMMve_d_LkaFcnConf) == 3)) || (((sint32)rtb_FDMMve_d_LkaFcnConf)
         == 6)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 9)) || (((sint32)
        rtb_FDMMve_d_LkaFcnConf) == 12)) {
    /* '<S139>:1:6' LDW_Warn_Mode = uint8(2); */
    rtb_IMAPve_d_LDW_Warn_Mode = 2U;
  } else if (((((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 1) || (((sint32)
      rtb_FDMMve_d_LkaFcnConf) == 2)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 5))
              || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 8)) || (((sint32)
               rtb_FDMMve_d_LkaFcnConf) == 11)) {
    /* '<S139>:1:7' elseif  LDW_Warn_Mode_In == 1 || LkaFcnConf == 2 || LkaFcnConf == 5 || LkaFcnConf == 8 || LkaFcnConf == 11 */
    /* '<S139>:1:8' LDW_Warn_Mode = uint8(1); */
    rtb_IMAPve_d_LDW_Warn_Mode = 1U;
  } else if (((((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 0) || (((sint32)
      rtb_FDMMve_d_LkaFcnConf) == 1)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 4))
              || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 7)) || (((sint32)
               rtb_FDMMve_d_LkaFcnConf) == 10)) {
    /* '<S139>:1:9' elseif  LDW_Warn_Mode_In == 0 || LkaFcnConf == 1 || LkaFcnConf == 4 || LkaFcnConf == 7 || LkaFcnConf == 10 */
    /* '<S139>:1:10' LDW_Warn_Mode = uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  } else {
    /* '<S139>:1:11' else */
    /* '<S139>:1:12' LDW_Warn_Mode = uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  }

  /* '<S139>:1:15' if LKA_Switch */
  if (rtb_LFlg) {
    /* '<S139>:1:16' if LkaFcnConf == 4 || LkaFcnConf == 5 || LkaFcnConf == 6 || LkaFcnConf == 10 || LkaFcnConf == 11 || LkaFcnConf == 12 || LKA_Mode_In == 1 */
    if (((((((((sint32)rtb_FDMMve_d_LkaFcnConf) == 4) || (((sint32)
               rtb_FDMMve_d_LkaFcnConf) == 5)) || (((sint32)
              rtb_FDMMve_d_LkaFcnConf) == 6)) || (((sint32)
             rtb_FDMMve_d_LkaFcnConf) == 10)) || (((sint32)
            rtb_FDMMve_d_LkaFcnConf) == 11)) || (((sint32)
           rtb_FDMMve_d_LkaFcnConf) == 12)) || (((sint32)rtb_IMAPve_d_LKA_Mode) ==
         1)) {
      /* '<S139>:1:17' LKA_Mode = uint8(2); */
      LKAS_DW.LKA_Mode_k = 2U;
    } else if (((((((((sint32)rtb_FDMMve_d_LkaFcnConf) == 1) || (((sint32)
        rtb_FDMMve_d_LkaFcnConf) == 2)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) ==
      3)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 7)) || (((sint32)
        rtb_FDMMve_d_LkaFcnConf) == 8)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) ==
      9)) || (((sint32)rtb_IMAPve_d_LKA_Mode) == 0)) {
      /* '<S139>:1:18' elseif LkaFcnConf == 1 || LkaFcnConf == 2 || LkaFcnConf == 3 || LkaFcnConf == 7 || LkaFcnConf == 8 || LkaFcnConf == 9 || LKA_Mode_In == 0 */
      /* '<S139>:1:19' LKA_Mode = uint8(1); */
      LKAS_DW.LKA_Mode_k = 1U;
    } else {
      /* '<S139>:1:20' else */
      /* '<S139>:1:21' LKA_Mode = uint8(0); */
      LKAS_DW.LKA_Mode_k = 0U;
    }
  } else {
    /* '<S139>:1:23' else */
    /* '<S139>:1:24' LKA_Mode = uint8(0); */
    LKAS_DW.LKA_Mode_k = 0U;
  }

  /* End of MATLAB Function: '<S104>/MATLAB Function' */

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Q'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q();

  /* Switch: '<S116>/Switch' incorporates:
   *  Constant: '<S116>/Constant'
   */
  if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = rtb_FDMMve_d_LkaFcnConf;
  }

  /* End of Switch: '<S116>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_Lrg_Q_BACK_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Lrg_Q_BACK'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Lrg_Q_BACK_IMAPve_d_Lrg_Q_BACK();

  /* Switch: '<S115>/Switch1' incorporates:
   *  Constant: '<S115>/Constant1'
   */
  if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
    rtb_Lrg_Q = ((uint8)3U);
  } else {
    rtb_Lrg_Q = rtb_FDMMve_d_LkaFcnConf;
  }

  /* End of Switch: '<S115>/Switch1' */

  /* DataTypeConversion: '<S110>/Cast To Single64' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   *  UnaryMinus: '<S110>/Unary Minus'
   */
  rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0
    ()));

  /* UnaryMinus: '<S110>/Unary Minus18' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C0_BACK_1'
   *  Inport: '<Root>/IMAPve_g_Lrg_C0_BACK'
   */
  rtb_Abs_ka = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C0_BACK_IMAPve_g_Lrg_C0_BACK()));

  /* MATLAB Function: '<S123>/Switch_L0_or_Lrg' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single2'
   *  Memory: '<S123>/Memory1'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/Switch_L0_or_Lrg': '<S129>:1' */
  rtb_R0_C2 = rtb_Abs_ka;

  /* '<S129>:1:2' if Lrg_Q == 3 */
  if (((sint32)rtb_Lrg_Q) == 3) {
    /* '<S129>:1:3' Lrg_C0 = Lrg_C0 + Offset; */
    rtb_R0_C2 = rtb_Abs_ka + LKAS_DW.Memory1_PreviousInput;

    /* '<S129>:1:4' if L0_Q == 3 */
    if (((sint32)rtb_L0_Q) == 3) {
      /* '<S129>:1:5' if Lrg_C0 > L0_C0 */
      if (rtb_R0_C2 > rtb_L0_C0) {
        /* '<S129>:1:6' LFlg = true; */
        rtb_LFlg = true;

        /* Switch: '<S123>/Switch1' */
        rtb_IMAPve_d_LKA_Mode = 3U;
      } else {
        /* '<S129>:1:7' else */
        /* '<S129>:1:8' LFlg = false; */
        rtb_LFlg = false;

        /* Switch: '<S123>/Switch1' */
        rtb_IMAPve_d_LKA_Mode = rtb_L0_Q;
      }
    } else {
      /* '<S129>:1:10' else */
      /* '<S129>:1:11' LFlg = true; */
      rtb_LFlg = true;

      /* Switch: '<S123>/Switch1' */
      rtb_IMAPve_d_LKA_Mode = 3U;
    }
  } else {
    /* '<S129>:1:13' else */
    /* '<S129>:1:14' LFlg = false; */
    rtb_LFlg = false;

    /* Switch: '<S123>/Switch1' */
    rtb_IMAPve_d_LKA_Mode = rtb_L0_Q;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_Rrg_Q_BACK_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Rrg_Q_BACK'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Rrg_Q_BACK_IMAPve_d_Rrg_Q_BACK();

  /* Switch: '<S117>/Switch1' incorporates:
   *  Constant: '<S117>/Constant1'
   */
  if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
    rtb_Rrg_Q = ((uint8)3U);
  } else {
    rtb_Rrg_Q = rtb_FDMMve_d_LkaFcnConf;
  }

  /* End of Switch: '<S117>/Switch1' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Q'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q();

  /* Switch: '<S112>/Switch1' incorporates:
   *  Constant: '<S112>/Constant1'
   */
  if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
    rtb_FDMMve_d_LkaFcnConf = ((uint8)3U);
  }

  /* End of Switch: '<S112>/Switch1' */

  /* DataTypeConversion: '<S110>/Cast To Single55' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   *  UnaryMinus: '<S110>/Unary Minus4'
   */
  rtb_R0_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0
    ()));

  /* UnaryMinus: '<S110>/Unary Minus22' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C0_BACK_1'
   *  Inport: '<Root>/IMAPve_g_Rrg_C0_BACK'
   */
  rtb_Abs_ka = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C0_BACK_IMAPve_g_Rrg_C0_BACK()));

  /* MATLAB Function: '<S123>/Switch_R0_or_Rrg' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single10'
   *  Memory: '<S123>/Memory1'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/Switch_R0_or_Rrg': '<S130>:1' */
  /* '<S130>:1:2' if Rrg_Q == 3 */
  if (((sint32)rtb_Rrg_Q) == 3) {
    /* '<S130>:1:3' Rrg_C0 = Rrg_C0 - Offset; */
    rtb_Abs_ka -= LKAS_DW.Memory1_PreviousInput;

    /* '<S130>:1:4' if R0_Q == 3 */
    if (((sint32)rtb_FDMMve_d_LkaFcnConf) == 3) {
      /* '<S130>:1:5' if Rrg_C0 < R0_C0 */
      if (rtb_Abs_ka < rtb_R0_C0) {
        /* '<S130>:1:6' RFlg = true; */
        rtb_RFlg = true;

        /* Switch: '<S123>/Switch' */
        rtb_R0_Q_c = 3U;
      } else {
        /* '<S130>:1:7' else */
        /* '<S130>:1:8' RFlg = false; */
        rtb_RFlg = false;

        /* Switch: '<S123>/Switch' */
        rtb_R0_Q_c = rtb_FDMMve_d_LkaFcnConf;
      }
    } else {
      /* '<S130>:1:10' else */
      /* '<S130>:1:11' RFlg = true; */
      rtb_RFlg = true;

      /* Switch: '<S123>/Switch' */
      rtb_R0_Q_c = 3U;
    }
  } else {
    /* '<S130>:1:13' else */
    /* '<S130>:1:14' RFlg = false; */
    rtb_RFlg = false;

    /* Switch: '<S123>/Switch' */
    rtb_R0_Q_c = rtb_FDMMve_d_LkaFcnConf;
  }

  /* Chart: '<S111>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c9_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c9_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S118>:4' */
    LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S118>:3' */
    /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c9_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S118>:9' */
      /* '<S118>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* Transition: '<S118>:13' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S118>:3' */
        /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) < 3))
        {
          /* Transition: '<S118>:14' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S118>:7' */
          /* '<S118>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S118>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S118>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_IMAPve_d_LKA_Mode) < 3) && (((sint32)rtb_R0_Q_c) ==
               3)) {
            /* Transition: '<S118>:23' */
            LKAS_DW.is_c9_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S118>:5' */
            /* '<S118>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S118>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S118>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S118>:5' */
      /* '<S118>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* Transition: '<S118>:16' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S118>:3' */
        /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) < 3))
        {
          /* Transition: '<S118>:18' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S118>:7' */
          /* '<S118>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S118>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S118>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_R0_Q_c) < 3) {
            /* Transition: '<S118>:11' */
            LKAS_DW.is_c9_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S118>:3' */
      /* '<S118>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_IMAPve_d_LKA_Mode) < 3) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* Transition: '<S118>:6' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S118>:5' */
        /* '<S118>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S118>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S118>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) < 3))
        {
          /* Transition: '<S118>:8' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S118>:7' */
          /* '<S118>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S118>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S118>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_IMAPve_d_LKA_Mode) < 3) && (((sint32)rtb_R0_Q_c) < 3))
          {
            /* Transition: '<S118>:10' */
            /* '<S118>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c9_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S118>:7' */
      /* '<S118>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* Transition: '<S118>:17' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S118>:3' */
        /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_IMAPve_d_LKA_Mode) < 3) && (((sint32)rtb_R0_Q_c) == 3))
        {
          /* Transition: '<S118>:19' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S118>:5' */
          /* '<S118>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S118>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S118>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_IMAPve_d_LKA_Mode) < 3) {
            /* Transition: '<S118>:12' */
            LKAS_DW.is_c9_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S111>/LaneReconstructSM' */

  /* Switch: '<S123>/Switch1' incorporates:
   *  MATLAB Function: '<S123>/Switch_L0_or_Lrg'
   */
  if (rtb_LFlg) {
    rtb_L0_C0_g = rtb_R0_C2;
  } else {
    rtb_L0_C0_g = rtb_L0_C0;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  MATLAB Function: '<S123>/Switch_R0_or_Rrg'
   */
  if (rtb_RFlg) {
    rtb_R0_C0_j = rtb_Abs_ka;
  } else {
    rtb_R0_C0_j = rtb_R0_C0;
  }

  /* Switch: '<S128>/Switch' incorporates:
   *  Constant: '<S137>/Constant'
   *  Constant: '<S138>/Constant'
   *  Delay: '<S128>/Delay'
   *  Gain: '<S128>/Gain'
   *  Logic: '<S128>/Logical Operator'
   *  RelationalOperator: '<S137>/Compare'
   *  RelationalOperator: '<S138>/Compare'
   *  Sum: '<S128>/Add'
   */
  if ((rtb_IMAPve_d_LKA_Mode >= ((uint8)2U)) && (rtb_R0_Q_c >= ((uint8)2U))) {
    rtb_R0_C3 = ((-1.0F) * rtb_L0_C0_g) + rtb_R0_C0_j;
  } else {
    rtb_R0_C3 = LKAS_DW.Delay_DSTATE;
  }

  /* End of Switch: '<S128>/Switch' */

  /* Sum: '<S136>/Add1' incorporates:
   *  Memory: '<S136>/Memory'
   *  Product: '<S136>/Divide'
   *  Product: '<S136>/Divide1'
   */
  rtb_Abs_ka = (rtb_R0_C3 * LKAS_ConstB.Divide2) + (LKAS_ConstB.Add2 *
    LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S128>/Saturation1' */
  if (rtb_Abs_ka > 5.5F) {
    rtb_R0_C0 = 5.5F;
  } else if (rtb_Abs_ka < 2.5F) {
    rtb_R0_C0 = 2.5F;
  } else {
    rtb_R0_C0 = rtb_Abs_ka;
  }

  /* End of Saturate: '<S128>/Saturation1' */

  /* Switch: '<S111>/Switch1' incorporates:
   *  Gain: '<S120>/Gain'
   *  Sum: '<S120>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_c = rtb_L0_C0_g;
  } else {
    rtb_L0_C0_c = (rtb_R0_C0 - rtb_R0_C0_j) * (-1.0F);
  }

  /* Switch: '<S664>/Switch24' incorporates:
   *  Constant: '<S664>/LL_CompHdAg_C=0.005'
   */
  if (LKAS_ConstB.DataTypeConversion38 != 0.0F) {
    rtb_L0_C0 = LKAS_ConstB.DataTypeConversion38;
  } else {
    rtb_L0_C0 = LL_CompHdAg_C;
  }

  /* End of Switch: '<S664>/Switch24' */

  /* Switch: '<S123>/Switch1' incorporates:
   *  Constant: '<S132>/Constant'
   *  RelationalOperator: '<S132>/Compare'
   *  Switch: '<S124>/Switch1'
   */
  if (rtb_LFlg) {
    /* Switch: '<S125>/Switch1' incorporates:
     *  Constant: '<S133>/Constant'
     *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C1_BACK_1'
     *  Inport: '<Root>/IMAPve_g_Lrg_C1_BACK'
     *  RelationalOperator: '<S133>/Compare'
     *  Sum: '<S125>/Add'
     *  UnaryMinus: '<S110>/Unary Minus19'
     */
    if (rtb_Lrg_Q == ((uint8)3U)) {
      rtb_L0_C1_h5 = rtb_L0_C0 + ((float32)((T_M_Nm_Float32)
        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C1_BACK_IMAPve_g_Lrg_C1_BACK
         ())));
    } else {
      rtb_L0_C1_h5 = (float32)((T_M_Nm_Float32)
        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C1_BACK_IMAPve_g_Lrg_C1_BACK
         ()));
    }

    /* End of Switch: '<S125>/Switch1' */
  } else if (rtb_L0_Q == ((uint8)3U)) {
    /* Switch: '<S124>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
     *  Inport: '<Root>/IMAPve_g_L0_C1'
     *  Sum: '<S124>/Add'
     *  UnaryMinus: '<S110>/Unary Minus1'
     */
    rtb_L0_C1_h5 = rtb_L0_C0 + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1())));
  } else {
    /* Switch: '<S124>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
     *  Inport: '<Root>/IMAPve_g_L0_C1'
     *  UnaryMinus: '<S110>/Unary Minus1'
     */
    rtb_L0_C1_h5 = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1()));
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  Constant: '<S134>/Constant'
   *  RelationalOperator: '<S134>/Compare'
   *  Switch: '<S126>/Switch1'
   */
  if (rtb_RFlg) {
    /* Switch: '<S127>/Switch1' incorporates:
     *  Constant: '<S135>/Constant'
     *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C1_BACK_1'
     *  Inport: '<Root>/IMAPve_g_Rrg_C1_BACK'
     *  RelationalOperator: '<S135>/Compare'
     *  Sum: '<S127>/Add'
     *  UnaryMinus: '<S110>/Unary Minus23'
     */
    if (rtb_Rrg_Q == ((uint8)3U)) {
      rtb_R0_C1_g = rtb_L0_C0 + ((float32)((T_M_Nm_Float32)
        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C1_BACK_IMAPve_g_Rrg_C1_BACK
         ())));
    } else {
      rtb_R0_C1_g = (float32)((T_M_Nm_Float32)
        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C1_BACK_IMAPve_g_Rrg_C1_BACK
         ()));
    }

    /* End of Switch: '<S127>/Switch1' */
  } else if (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U)) {
    /* Switch: '<S126>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
     *  Inport: '<Root>/IMAPve_g_R0_C1'
     *  Sum: '<S126>/Add'
     *  UnaryMinus: '<S110>/Unary Minus5'
     */
    rtb_R0_C1_g = rtb_L0_C0 + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1())));
  } else {
    /* Switch: '<S126>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
     *  Inport: '<Root>/IMAPve_g_R0_C1'
     *  UnaryMinus: '<S110>/Unary Minus5'
     */
    rtb_R0_C1_g = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1()));
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single1'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C1_c = rtb_L0_C1_h5;
  } else {
    rtb_L0_C1_c = rtb_R0_C1_g;
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C2_BACK_1'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  Inport: '<Root>/IMAPve_g_Lrg_C2_BACK'
   *  UnaryMinus: '<S110>/Unary Minus16'
   *  UnaryMinus: '<S110>/Unary Minus2'
   */
  if (rtb_LFlg) {
    rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C2_BACK_IMAPve_g_Lrg_C2_BACK
      ()));
  } else {
    rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2
      ()));
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C2_BACK_1'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   *  Inport: '<Root>/IMAPve_g_Rrg_C2_BACK'
   *  UnaryMinus: '<S110>/Unary Minus20'
   *  UnaryMinus: '<S110>/Unary Minus6'
   */
  if (rtb_RFlg) {
    rtb_R0_C2 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C2_BACK_IMAPve_g_Rrg_C2_BACK
      ()));
  } else {
    rtb_R0_C2 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2
      ()));
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single2'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C2_f = rtb_L0_C0;
  } else {
    rtb_L0_C2_f = rtb_R0_C2;
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C3_BACK_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  Inport: '<Root>/IMAPve_g_Lrg_C3_BACK'
   *  UnaryMinus: '<S110>/Unary Minus17'
   *  UnaryMinus: '<S110>/Unary Minus3'
   */
  if (rtb_LFlg) {
    rtb_L0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C3_BACK_IMAPve_g_Lrg_C3_BACK
      ()));
  } else {
    rtb_L0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3
      ()));
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C3_BACK_1'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   *  Inport: '<Root>/IMAPve_g_Rrg_C3_BACK'
   *  UnaryMinus: '<S110>/Unary Minus21'
   *  UnaryMinus: '<S110>/Unary Minus7'
   */
  if (rtb_RFlg) {
    rtb_R0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C3_BACK_IMAPve_g_Rrg_C3_BACK
      ()));
  } else {
    rtb_R0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3
      ()));
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C3_i = rtb_L0_C3;
  } else {
    rtb_L0_C3_i = rtb_R0_C3;
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single2'
   *  Sum: '<S122>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_L0_C1_h5 = rtb_R0_C1_g;
    rtb_R0_C2_b = rtb_R0_C2;
    rtb_L0_C3 = rtb_R0_C3;
  } else {
    rtb_R0_C0_j = rtb_R0_C0 + rtb_L0_C0_g;
    rtb_R0_C2_b = rtb_L0_C0;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_LKA_State'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  rtb_IMAPve_g_EPS_SW_Trq = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid'
   */
  rtb_L0_Q = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid
    ();

  /* Saturate: '<S107>/Saturation' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1'
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  rtb_ESC_VehSpd = fmaxf((float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd(), 0.1F);

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  rtb_IMAPve_g_ESC_LonAcc = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid'
   */
  rtb_Lrg_Q = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid
    ();

  /* Gain: '<S106>/Gain' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1'
   *  Inport: '<Root>/IMAPve_g_EPS_SteeringAngle'
   */
  rtb_SW_Angle = 1.0F * ((float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
    ());

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp'
   */
  rtb_Rrg_Q = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp
    ();

  /* Logic: '<S101>/Logical Operator' incorporates:
   *  Constant: '<S108>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Left_Light'
   *  RelationalOperator: '<S108>/Compare'
   */
  rtb_BCM_Left_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch
                    ()) == ((uint8)1U)));

  /* Logic: '<S101>/Logical Operator1' incorporates:
   *  Constant: '<S109>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Right_Light'
   *  RelationalOperator: '<S109>/Compare'
   */
  rtb_BCM_Right_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
                    ()) == ((uint8)1U)));

  /* MultiPortSwitch: '<S105>/Multiport Switch' incorporates:
   *  Constant: '<S105>/Constant1'
   *  Constant: '<S105>/Constant3'
   *  DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1'
   *  Inport: '<Root>/IMAPve_d_TCU_Actual_Gear'
   */
  switch ((uint8)
          Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear
          ()) {
   case 0:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 1:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 2:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 3:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 4:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 5:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 6:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 7:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 8:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 9:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   default:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;
  }

  /* End of MultiPortSwitch: '<S105>/Multiport Switch' */

  /* Switch: '<S665>/Switch58' incorporates:
   *  Constant: '<S665>/LLSMConClb4'
   *
   * Block description for '<S665>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S665>/Switch58' */

  /* Gain: '<S670>/Gain' incorporates:
   *  Constant: '<S670>/Constant'
   *  Sum: '<S670>/Add'
   */
  rtb_Gain_j = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S665>/Switch84' incorporates:
   *  Constant: '<S665>/LLSMConClb5'
   *
   * Block description for '<S665>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S665>/Switch84' */

  /* Switch: '<S665>/Switch85' incorporates:
   *  Constant: '<S665>/LLSMConClb6'
   *
   * Block description for '<S665>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S665>/Switch85' */

  /* Switch: '<S665>/Switch86' incorporates:
   *  Constant: '<S665>/LLSMConClb7'
   *
   * Block description for '<S665>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S665>/Switch86' */

  /* Switch: '<S665>/Switch54' incorporates:
   *  Constant: '<S665>/LLSMConClb12'
   *
   * Block description for '<S665>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S665>/Switch54' */

  /* Switch: '<S665>/Switch55' incorporates:
   *  Constant: '<S665>/LLSMConClb13'
   *
   * Block description for '<S665>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S665>/Switch55' */

  /* Switch: '<S665>/Switch60' incorporates:
   *  Constant: '<S665>/LLSMConClb17'
   *
   * Block description for '<S665>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S665>/Switch60' */

  /* Switch: '<S665>/Switch59' incorporates:
   *  Constant: '<S665>/LLSMConClb19'
   *
   * Block description for '<S665>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_LL_LKA_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_LL_LKA_LatestWarnLine_C = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S665>/Switch59' */

  /* Switch: '<S665>/Switch5' incorporates:
   *  Constant: '<S665>/LLSMConClb1'
   *
   * Block description for '<S665>/LLSMConClb1':
   *  LKA���ܵ�ƫ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    rtb_LL_LKA_EnableLine_Max = LKAS_ConstB.DataTypeConversion22;
  } else {
    rtb_LL_LKA_EnableLine_Max = LL_LKA_EnableLine_Max;
  }

  /* End of Switch: '<S665>/Switch5' */

  /* Switch: '<S665>/Switch69' incorporates:
   *  Constant: '<S665>/LLSMConClb22'
   *
   * Block description for '<S665>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S665>/Switch69' */

  /* Gain: '<S667>/Gain' incorporates:
   *  Constant: '<S667>/Constant'
   *  Sum: '<S667>/Add'
   */
  rtb_Gain_js = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S665>/Switch68' incorporates:
   *  Constant: '<S665>/LLSMConClb23'
   *
   * Block description for '<S665>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S665>/Switch68' */

  /* Switch: '<S665>/Switch70' incorporates:
   *  Constant: '<S665>/LLSMConClb24'
   *
   * Block description for '<S665>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S665>/Switch70' */

  /* Switch: '<S665>/Switch71' incorporates:
   *  Constant: '<S665>/LLSMConClb25'
   *
   * Block description for '<S665>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S665>/Switch71' */

  /* Switch: '<S665>/Switch73' incorporates:
   *  Constant: '<S665>/LLSMConClb27'
   *
   * Block description for '<S665>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S665>/Switch73' */

  /* Switch: '<S665>/Switch62' incorporates:
   *  Constant: '<S665>/LLSMConClb31'
   *
   * Block description for '<S665>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S665>/Switch62' */

  /* Switch: '<S665>/Switch63' incorporates:
   *  Constant: '<S665>/LLSMConClb32'
   *
   * Block description for '<S665>/LLSMConClb32':
   *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
   */
  if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LKAS_ConstB.DataTypeConversion78;
  } else {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LL_MAX_DELAY_EPSSTAR_TIME;
  }

  /* End of Switch: '<S665>/Switch63' */

  /* Switch: '<S665>/Switch66' incorporates:
   *  Constant: '<S665>/LLSMConClb35'
   *
   * Block description for '<S665>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S665>/Switch66' */

  /* Switch: '<S665>/Switch38' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
   *
   * Block description for '<S665>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
   *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
    rtb_R0_C1_g = LKAS_ConstB.DataTypeConversion6;
  } else {
    rtb_R0_C1_g = LL_RlsDet_tiTrqChkT_DISABLE;
  }

  /* End of Switch: '<S665>/Switch38' */

  /* Switch: '<S665>/Switch44' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
   *
   * Block description for '<S665>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
   *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
   */
  if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = LKAS_ConstB.DataTypeConversion8;
  } else {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
  }

  /* End of Switch: '<S665>/Switch44' */

  /* Switch: '<S665>/Switch3' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=3'
   *
   * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=3':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
    rtb_LL_HandsOff_ExitTime = LKAS_ConstB.DataTypeConversion3;
  } else {
    rtb_LL_HandsOff_ExitTime = LL_HandsOff_ExitTime;
  }

  /* End of Switch: '<S665>/Switch3' */

  /* Switch: '<S665>/Switch4' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=4'
   *
   * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=4':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_SingleLane_Disable_Swt = (LKAS_ConstB.DataTypeConversion4 != 0.0F);
  } else {
    rtb_LL_SingleLane_Disable_Swt = LL_SingleLane_Disable_Swt;
  }

  /* End of Switch: '<S665>/Switch4' */

  /* Switch: '<S665>/Switch81' incorporates:
   *  Constant: '<S665>/LLSMConClb36'
   *
   * Block description for '<S665>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S665>/Switch81' */

  /* Switch: '<S665>/Switch82' incorporates:
   *  Constant: '<S665>/LLSMConClb37'
   *
   * Block description for '<S665>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S665>/Switch82' */

  /* Switch: '<S665>/Switch83' incorporates:
   *  Constant: '<S665>/LLSMConClb38'
   *
   * Block description for '<S665>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S665>/Switch83' */

  /* Switch: '<S665>/Switch75' incorporates:
   *  Constant: '<S665>/LLSMConClb39'
   *
   * Block description for '<S665>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S665>/Switch75' */

  /* Switch: '<S665>/Switch76' incorporates:
   *  Constant: '<S665>/LLSMConClb40'
   *
   * Block description for '<S665>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S665>/Switch76' */

  /* Switch: '<S665>/Switch77' incorporates:
   *  Constant: '<S665>/LLSMConClb41'
   *
   * Block description for '<S665>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S665>/Switch77' */

  /* Switch: '<S665>/Switch78' incorporates:
   *  Constant: '<S665>/LLSMConClb42'
   *
   * Block description for '<S665>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S665>/Switch78' */

  /* Switch: '<S664>/Switch3' incorporates:
   *  Constant: '<S664>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3_p != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3_p;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S664>/Switch3' */

  /* Switch: '<S664>/Switch31' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KpVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_m != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LKAS_ConstB.DataTypeConversion14_m;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S664>/Switch31' */

  /* Switch: '<S664>/Switch34' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KpVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4_m != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LKAS_ConstB.DataTypeConversion4_m;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S664>/Switch34' */

  /* Switch: '<S664>/Switch33' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KpV1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_n != 0.0F) {
    rtb_LL_LFClb_TFC_KpV1_C = LKAS_ConstB.DataTypeConversion7_n;
  } else {
    rtb_LL_LFClb_TFC_KpV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S664>/Switch33' */

  /* Switch: '<S664>/Switch35' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KpV2_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion17_j != 0.0F) {
    rtb_LL_LFClb_TFC_KpV2_C = LKAS_ConstB.DataTypeConversion17_j;
  } else {
    rtb_LL_LFClb_TFC_KpV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S664>/Switch35' */

  /* Switch: '<S664>/Switch20' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LL_LFClb_TFC_KdVehSpdLwr_C;
  }

  /* End of Switch: '<S664>/Switch20' */

  /* Switch: '<S664>/Switch22' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LL_LFClb_TFC_KdVehSpdUpr_C;
  }

  /* End of Switch: '<S664>/Switch22' */

  /* Switch: '<S664>/Switch21' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdV1_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV1_C = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LFClb_TFC_KdV1_C = LL_LFClb_TFC_KdV1_C;
  }

  /* End of Switch: '<S664>/Switch21' */

  /* Switch: '<S664>/Switch23' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdV2_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV2_C = LKAS_ConstB.DataTypeConversion30;
  } else {
    rtb_LL_LFClb_TFC_KdV2_C = LL_LFClb_TFC_KdV2_C;
  }

  /* End of Switch: '<S664>/Switch23' */

  /* Switch: '<S664>/Switch9' incorporates:
   *  Constant: '<S664>/LL_LFClb_TFC_KdBalance_C=1.2'
   */
  if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
    rtb_LL_LFClb_TFC_KdBalance_C = LKAS_ConstB.DataTypeConversion9;
  } else {
    rtb_LL_LFClb_TFC_KdBalance_C = LL_LFClb_TFC_KdBalance_C;
  }

  /* End of Switch: '<S664>/Switch9' */

  /* Switch: '<S664>/Switch11' incorporates:
   *  Constant: '<S664>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_n != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12_n;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S664>/Switch11' */

  /* Switch: '<S664>/Switch13' incorporates:
   *  Constant: '<S664>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_b != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_b;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S664>/Switch13' */

  /* Switch: '<S664>/Switch55' incorporates:
   *  Constant: '<S664>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S664>/Switch55' */

  /* Switch: '<S664>/Switch54' incorporates:
   *  Constant: '<S664>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S664>/Switch54' */

  /* Switch: '<S664>/Switch44' incorporates:
   *  Constant: '<S664>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S664>/Switch44' */

  /* Switch: '<S664>/Switch25' incorporates:
   *  Constant: '<S664>/LL_LKAExPrcs_tiExitDelayTime3=0.5'
   */
  if (LKAS_ConstB.DataTypeConversion39 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LKAS_ConstB.DataTypeConversion39;
  } else {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LL_LKAExPrcs_tiExitDelayTime3;
  }

  /* End of Switch: '<S664>/Switch25' */

  /* Switch: '<S662>/Switch19' incorporates:
   *  Constant: '<S662>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_l != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_l;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S662>/Switch19' */

  /* Switch: '<S662>/Switch' incorporates:
   *  Constant: '<S662>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_i != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_i;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S662>/Switch' */

  /* Switch: '<S662>/Switch1' incorporates:
   *  Constant: '<S662>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_h != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_h;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S662>/Switch1' */

  /* Switch: '<S662>/Switch2' incorporates:
   *  Constant: '<S662>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_f != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_j = LKAS_ConstB.DataTypeConversion4_f;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_j = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S662>/Switch2' */

  /* Switch: '<S662>/Switch3' incorporates:
   *  Constant: '<S662>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_f != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_d = LKAS_ConstB.DataTypeConversion6_f;
  } else {
    LKAS_DW.LKA_StrRatio_C_d = LKA_StrRatio_C;
  }

  /* End of Switch: '<S662>/Switch3' */

  /* Switch: '<S662>/Switch11' incorporates:
   *  Constant: '<S662>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22_b != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22_b;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S662>/Switch11' */

  /* DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1' incorporates:
   *  Inport: '<Root>/ADIAve_g_ASWFaultStatus'
   */
  rtb_L0_C0_g = (float32)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_ASWFaultStatus_ADIAve_g_ASWFaultStatus
    ();

  /* DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1' incorporates:
   *  Inport: '<Root>/ADIAve_g_BSWFaultStatus'
   */
  rtb_R0_C3 = (float32)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_BSWFaultStatus_ADIAve_g_BSWFaultStatus
    ();

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (rtb_LKA_Main_Switch) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S142>/Delay' */
      LKAS_DW.Delay_DSTATE_c = ((uint8)0U);

      /* InitializeConditions for Memory: '<S587>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = 0.0F;

      /* InitializeConditions for Delay: '<S143>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S527>/Memory' */
      LKAS_DW.Memory_PreviousInput_f = 0.0F;

      /* InitializeConditions for Memory: '<S445>/Memory' */
      LKAS_DW.Memory_PreviousInput_d = 0.0F;

      /* InitializeConditions for UnitDelay: '<S458>/Delay Input1'
       *
       * Block description for '<S458>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S457>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_e = false;

      /* InitializeConditions for UnitDelay: '<S419>/Delay Input1'
       *
       * Block description for '<S419>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_h = false;

      /* InitializeConditions for UnitDelay: '<S417>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_jz = false;

      /* InitializeConditions for UnitDelay: '<S418>/Delay Input1'
       *
       * Block description for '<S418>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_k = false;

      /* InitializeConditions for Memory: '<S384>/Memory' */
      LKAS_DW.Memory_PreviousInput_cb = false;

      /* InitializeConditions for Delay: '<S143>/Delay' */
      LKAS_DW.Delay_DSTATE_p = false;

      /* InitializeConditions for Delay: '<S143>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S432>/Memory' */
      LKAS_DW.Memory_PreviousInput_io = ((uint8)0U);

      /* InitializeConditions for Memory: '<S358>/Memory' */
      LKAS_DW.Memory_PreviousInput_j = 0.0F;

      /* InitializeConditions for Memory: '<S394>/Memory' */
      LKAS_DW.Memory_PreviousInput_c = 0.0F;

      /* InitializeConditions for Memory: '<S601>/Memory' */
      LKAS_DW.Memory_PreviousInput_ce = 0.0F;

      /* InitializeConditions for Delay: '<S602>/Delay' */
      LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

      /* InitializeConditions for Delay: '<S603>/Delay' */
      LKAS_DW.Delay_DSTATE_d = ((uint8)0U);

      /* InitializeConditions for Delay: '<S604>/Delay' */
      LKAS_DW.Delay_DSTATE_ci = ((uint8)0U);

      /* InitializeConditions for Delay: '<S143>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S143>/LDW_State_Machine'
       *
       * Block description for '<S143>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S143>/LKA_State_Machine'
       *
       * Block description for '<S143>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S297>/Add1' incorporates:
     *  MATLAB Function: '<S295>/MATLABFunction3'
     */
    rtb_TLft = rtb_L0_C0_c + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S297>/Gain1' incorporates:
     *  Product: '<S297>/Divide'
     *  Product: '<S297>/Divide1'
     *  Sum: '<S297>/Add1'
     *  Sum: '<S297>/Add5'
     *  Trigonometry: '<S297>/Cos2'
     *  Trigonometry: '<S297>/Sin'
     */
    rtb_Gain1 = ((rtb_TLft * cosf(rtb_L0_C1_c)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_c))) * (-1.0F);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S289>/Gain1' incorporates:
     *  Gain: '<S185>/Gain'
     *  Gain: '<S231>/kph To mps'
     *  Gain: '<S245>/kph to mps'
     *  Gain: '<S246>/kph to mps'
     *  Gain: '<S295>/Gain2'
     *  Gain: '<S302>/kph to mps'
     *  Gain: '<S308>/kph to mps'
     *  Gain: '<S317>/kph to mps'
     *  Gain: '<S318>/kph to mps'
     */
    rtb_Abs_d_tmp = 0.277777791F * rtb_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S289>/Divide4' incorporates:
     *  Constant: '<S289>/Constant2'
     *  Constant: '<S289>/Constant3'
     *  Gain: '<S289>/Gain1'
     */
    rtb_Abs_f = (rtb_Abs_d_tmp * 2.0F) * 0.1F;

    /* Sum: '<S289>/Add3' incorporates:
     *  Product: '<S289>/Divide3'
     */
    rtb_phiHdAg_Lft = (rtb_L0_C2_f * rtb_Abs_f) + rtb_L0_C1_c;

    /* Sum: '<S298>/Add1' incorporates:
     *  MATLAB Function: '<S295>/MATLABFunction4'
     */
    rtb_Add5_j_tmp = rtb_R0_C0_j - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S298>/Add5' incorporates:
     *  Product: '<S298>/Divide'
     *  Product: '<S298>/Divide1'
     *  Sum: '<S298>/Add1'
     *  Trigonometry: '<S298>/Cos2'
     *  Trigonometry: '<S298>/Sin'
     */
    rtb_Add5_j = (rtb_Add5_j_tmp * cosf(rtb_L0_C1_h5)) + (rtb_LKA_Veh2CamL_C *
      sinf(rtb_L0_C1_h5));

    /* Sum: '<S289>/Add1' incorporates:
     *  Product: '<S289>/Divide5'
     */
    rtb_phiHdAg_Rgt = (rtb_R0_C2_b * rtb_Abs_f) + rtb_L0_C1_h5;

    /* Switch: '<S664>/Switch2' incorporates:
     *  Constant: '<S664>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_f != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_f;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S664>/Switch2' */

    /* Product: '<S302>/Divide' */
    rtb_Abs_f = rtb_Abs_d_tmp * x10;

    /* Gain: '<S299>/Gain' incorporates:
     *  Gain: '<S314>/Gain'
     *  Gain: '<S315>/Gain'
     *  Gain: '<S316>/Gain'
     */
    rtb_Add_a_tmp = 2.0F * rtb_L0_C2_f;

    /* Sum: '<S299>/Add' incorporates:
     *  Gain: '<S299>/Gain'
     *  Gain: '<S299>/Gain1'
     *  Product: '<S299>/Product'
     */
    rtb_Add_a = ((6.0F * rtb_L0_C3_i) * rtb_Abs_f) + rtb_Add_a_tmp;

    /* Gain: '<S300>/Gain' incorporates:
     *  Gain: '<S311>/Gain'
     *  Gain: '<S312>/Gain'
     *  Gain: '<S313>/Gain'
     */
    rtb_Add_l_tmp = 2.0F * rtb_R0_C2_b;

    /* Sum: '<S300>/Add' incorporates:
     *  Gain: '<S300>/Gain'
     *  Gain: '<S300>/Gain1'
     *  Product: '<S300>/Product'
     */
    rtb_Add_l = ((6.0F * rtb_L0_C3) * rtb_Abs_f) + rtb_Add_l_tmp;

    /* Product: '<S289>/Divide1' incorporates:
     *  Gain: '<S289>/Gain1'
     */
    rtb_Abs_f = rtb_phiHdAg_Lft * rtb_Abs_d_tmp;

    /* Saturate: '<S295>/Saturation2' incorporates:
     *  UnaryMinus: '<S295>/Unary Minus1'
     */
    if ((-rtb_Abs_f) > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else if ((-rtb_Abs_f) < (-2.0F)) {
      rtb_LKA_Veh2CamL_C = (-2.0F);
    } else {
      rtb_LKA_Veh2CamL_C = -rtb_Abs_f;
    }

    /* End of Saturate: '<S295>/Saturation2' */

    /* MATLAB Function: '<S295>/MATLABFunction' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction': '<S326>:1' */
    /* '<S326>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1 > 0.0F) && (rtb_Gain1 < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S326>:1:3' TTLC = -dvt/vy; */
      rtb_TTLC_o = (-rtb_Gain1) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S326>:1:4' else */
      /* '<S326>:1:5' TTLC = single(3); */
      rtb_TTLC_o = 3.0F;
    }

    /* End of MATLAB Function: '<S295>/MATLABFunction' */

    /* Saturate: '<S295>/Saturation' */
    if (rtb_TTLC_o > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_TTLC_o < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_TTLC_o;
    }

    /* End of Saturate: '<S295>/Saturation' */

    /* Product: '<S289>/Divide2' incorporates:
     *  Gain: '<S289>/Gain1'
     */
    rtb_Abs_d = rtb_phiHdAg_Rgt * rtb_Abs_d_tmp;

    /* Saturate: '<S295>/Saturation3' */
    if (rtb_Abs_d > 2.0F) {
      rtb_TTLC_o = 2.0F;
    } else if (rtb_Abs_d < (-2.0F)) {
      rtb_TTLC_o = (-2.0F);
    } else {
      rtb_TTLC_o = rtb_Abs_d;
    }

    /* End of Saturate: '<S295>/Saturation3' */

    /* MATLAB Function: '<S295>/MATLABFunction1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction1': '<S327>:1' */
    /* '<S327>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_j > 0.0F) && (rtb_Add5_j < 2.0F)) && (rtb_TTLC_o < 0.0F)) &&
        (rtb_TTLC_o > -1.5F)) {
      /* '<S327>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_f = (-rtb_Add5_j) / rtb_TTLC_o;
    } else {
      /* '<S327>:1:4' else */
      /* '<S327>:1:5' TTLC = single(3); */
      rtb_TTLC_f = 3.0F;
    }

    /* End of MATLAB Function: '<S295>/MATLABFunction1' */

    /* Saturate: '<S295>/Saturation1' */
    if (rtb_TTLC_f > 2.0F) {
      rtb_TTLC_f = 2.0F;
    } else {
      if (rtb_TTLC_f < 0.6F) {
        rtb_TTLC_f = 0.6F;
      }
    }

    /* End of Saturate: '<S295>/Saturation1' */

    /* MATLAB Function: '<S295>/MATLABFunction5' incorporates:
     *  Gain: '<S325>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction5': '<S331>:1' */
    /* '<S331>:1:2' K = single(single(0.09)/single(vx)); */
    /* '<S331>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_SW_Angle) / (((((((0.09F / rtb_Abs_d_tmp) *
      rtb_Abs_d_tmp) * rtb_Abs_d_tmp) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_j) *
      LKAS_DW.LKA_StrRatio_C_d) * 2.0F);

    /* MATLAB Function: '<S295>/MATLABFunction3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction3': '<S329>:1' */
    /* '<S329>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2_f - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_c > 0.0F) || (rtb_L0_C1_c < 0.0F))) {
      /* '<S329>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_c) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_c;
      if (x10 > 0.0F) {
        /* '<S329>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_Abs_d_tmp;
      } else {
        /* '<S329>:1:9' else */
        /* '<S329>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_c * rtb_L0_C1_c) - ((x10 * 4.0F) * rtb_TLft);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S329>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S329>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_c)) / x1;

        /* '<S329>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_c) - x20) / x1;

        /* '<S329>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S329>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S329>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S329>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_Abs_d_tmp;
        } else if (x1 > 0.0F) {
          /* '<S329>:1:19' elseif x1>0 */
          /* '<S329>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_Abs_d_tmp;
        } else {
          /* '<S329>:1:21' else */
          /* '<S329>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S329>:1:24' else */
        /* '<S329>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S329>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S295>/MATLABFunction4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction4': '<S330>:1' */
    /* '<S330>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_R0_C2_b - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_h5 > 0.0F) || (rtb_L0_C1_h5 < 0.0F))) {
      /* '<S330>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_R0_C0_j) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1_h5;
      if (x10 > 0.0F) {
        /* '<S330>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_d_tmp;
      } else {
        /* '<S330>:1:9' else */
        /* '<S330>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_h5 * rtb_L0_C1_h5) - ((x10 * 4.0F) * rtb_Add5_j_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S330>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S330>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_h5)) / x1;

        /* '<S330>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_h5) - x20) / x1;

        /* '<S330>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S330>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S330>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S330>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_d_tmp;
        } else if (x1 > 0.0F) {
          /* '<S330>:1:19' elseif x1>0 */
          /* '<S330>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_Abs_d_tmp;
        } else {
          /* '<S330>:1:21' else */
          /* '<S330>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S330>:1:24' else */
        /* '<S330>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S330>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S295>/MATLABFunction2' incorporates:
     *  Constant: '<S295>/Constant'
     *  Constant: '<S295>/Constant1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction2': '<S328>:1' */
    /* '<S328>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - 2.0F) / rtb_LftTTLC) <= 0.2F) {
      /* '<S328>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, 2.0F);
    } else {
      /* '<S328>:1:4' else */
      /* '<S328>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S328>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_f - 2.0F) / rtb_TTLC_f) <= 0.2F) {
      /* '<S328>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_f = fminf(rtb_TTLC_f, 2.0F);
    } else {
      /* '<S328>:1:10' else */
      /* '<S328>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S328>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_a) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S328>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S328>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_l) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_f)
           / rtb_TTLC_f) <= 0.7F)) && (rtb_TTLC_f <= 1.95F)) {
      /* '<S328>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_f = (rtb_TTLC_f + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S295>/Saturation7' incorporates:
     *  MATLAB Function: '<S295>/MATLABFunction2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S295>/Saturation7' */

    /* Saturate: '<S295>/Saturation8' incorporates:
     *  MATLAB Function: '<S295>/MATLABFunction2'
     */
    if (rtb_TTLC_f > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_f < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_f;
    }

    /* End of Saturate: '<S295>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S150>/Subsystem' incorporates:
     *  EnablePort: '<S159>/Enable'
     */
    /* Abs: '<S290>/Abs' incorporates:
     *  MATLAB Function: '<S159>/DriverSwaTrqAdd'
     */
    rtb_Add5_j_tmp = fabsf(rtb_L0_C0_c);

    /* Abs: '<S290>/Abs1' incorporates:
     *  MATLAB Function: '<S159>/DriverSwaTrqAdd'
     */
    rtb_TTLC = fabsf(rtb_R0_C0_j);

    /* End of Outputs for SubSystem: '<S150>/Subsystem' */
    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Sum: '<S290>/Add' incorporates:
     *  Abs: '<S290>/Abs'
     *  Abs: '<S290>/Abs1'
     */
    rtb_LKA_Veh2CamW_C = rtb_Add5_j_tmp + rtb_TTLC;

    /* Saturate: '<S290>/Saturation' */
    if (rtb_LKA_Veh2CamW_C > 6.0F) {
      rtb_LKA_Veh2CamW_C = 6.0F;
    } else {
      if (rtb_LKA_Veh2CamW_C < 2.0F) {
        rtb_LKA_Veh2CamW_C = 2.0F;
      }
    }

    /* End of Saturate: '<S290>/Saturation' */

    /* If: '<S301>/If' incorporates:
     *  Delay: '<S142>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE_c) == 1) {
      /* Outputs for IfAction SubSystem: '<S301>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S304>/Action Port'
       */
      LKAS_IfActionSubsystem2_m(rtb_Add_a, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S301>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE_c) == 2) {
      /* Outputs for IfAction SubSystem: '<S301>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S303>/Action Port'
       */
      LKAS_IfActionSubsystem2_m(rtb_Add_l, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S301>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S301>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S305>/Action Port'
       */
      /* Gain: '<S305>/Gain' incorporates:
       *  Sum: '<S305>/Add'
       */
      rtb_Merge = (rtb_Add_a + rtb_Add_l) * 0.5F;

      /* End of Outputs for SubSystem: '<S301>/If Action Subsystem3' */
    }

    /* End of If: '<S301>/If' */

    /* Switch: '<S589>/Switch' incorporates:
     *  Constant: '<S668>/Constant'
     *  Constant: '<S669>/Constant'
     *  Gain: '<S668>/Gain'
     *  Gain: '<S669>/Gain'
     *  Sum: '<S668>/Add'
     *  Sum: '<S669>/Add'
     *  Switch: '<S665>/Switch47'
     */
    if (LKAS_DW.LKA_Mode_k >= ((uint8)2U)) {
      /* Switch: '<S665>/Switch48' incorporates:
       *  Constant: '<S665>/LLSMConClb3'
       *
       * Block description for '<S665>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S665>/Switch48' */
      rtb_Switch_e = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S665>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S665>/Switch47' incorporates:
         *  Constant: '<S665>/LLSMConClb2'
         *
         * Block description for '<S665>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_e = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S589>/Switch' */

    /* Switch: '<S587>/Switch' incorporates:
     *  Constant: '<S587>/Constant'
     *  Constant: '<S587>/Constant1'
     *  Constant: '<S594>/Constant'
     *  Constant: '<S595>/Constant'
     *  Constant: '<S596>/Constant'
     *  Logic: '<S587>/Logical Operator'
     *  RelationalOperator: '<S594>/Compare'
     *  RelationalOperator: '<S595>/Compare'
     *  RelationalOperator: '<S596>/Compare'
     */
    if (((rtb_Rrg_Q >= ((uint8)3U)) || (((sint32)(rtb_BCM_Left_Light ? 1 : 0)) >
          ((sint32)(false ? 1 : 0)))) || (((sint32)(rtb_BCM_Right_Light ? 1 : 0))
         > ((sint32)(false ? 1 : 0)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S587>/Switch' */

    /* Sum: '<S587>/Add' incorporates:
     *  Memory: '<S587>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_a;

    /* Saturate: '<S587>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_f = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_f = (-1.0F);
    } else {
      rtb_Saturation_f = rtb_LftTTLC;
    }

    /* End of Saturate: '<S587>/Saturation' */

    /* Abs: '<S580>/Abs1' incorporates:
     *  Abs: '<S482>/Abs1'
     */
    rtb_Abs1_tmp = fabsf(rtb_LKA_Veh2CamW_C);
    rtb_Abs1 = rtb_Abs1_tmp;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S578>/Abs' incorporates:
     *  Abs: '<S170>/Abs'
     *  Abs: '<S171>/Abs'
     *  Abs: '<S172>/Abs4'
     *  Abs: '<S480>/Abs'
     *  MATLAB Function: '<S446>/MATLAB Function'
     */
    rtb_TLft = fabsf(rtb_Merge);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TLft;

    /* Switch: '<S665>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S539>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S539>/Unary Minus' incorporates:
       *  Constant: '<S665>/LLSMConClb11'
       *
       * Block description for '<S665>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S665>/Switch53' */

    /* Switch: '<S665>/Switch87' incorporates:
     *  Constant: '<S665>/LLSMConClb8'
     *
     * Block description for '<S665>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S665>/Switch87' */

    /* Switch: '<S665>/Switch49' incorporates:
     *  Constant: '<S665>/LLSMConClb43'
     *
     * Block description for '<S665>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S665>/Switch49' */

    /* Switch: '<S665>/Switch88' incorporates:
     *  Constant: '<S665>/LLSMConClb9'
     *
     * Block description for '<S665>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_LftTTLC = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S665>/Switch88' */

    /* Switch: '<S665>/Switch50' incorporates:
     *  Constant: '<S665>/LLSMConClb10'
     *
     * Block description for '<S665>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      rtb_TTLC_f = LKAS_ConstB.DataTypeConversion17;
    } else {
      rtb_TTLC_f = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S665>/Switch50' */

    /* Abs: '<S576>/Abs' incorporates:
     *  Abs: '<S478>/Abs'
     *  Sum: '<S576>/Add'
     */
    rtb_LogicalOperator3_c_tmp = fabsf(rtb_L0_C1_c - rtb_L0_C1_h5);

    /* Abs: '<S539>/Abs2' incorporates:
     *  Abs: '<S320>/Abs2'
     *  Abs: '<S444>/Abs2'
     */
    x1 = fabsf(rtb_SW_Angle);

    /* Abs: '<S539>/Abs3' incorporates:
     *  Abs: '<S444>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     *  Inport: '<Root>/IMAPve_g_SW_Angle_Speed'
     */
    rtb_LogicalOperator3_c_tmp_0 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
      ());

    /* Abs: '<S539>/Abs4' incorporates:
     *  Abs: '<S444>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     *  Inport: '<Root>/IMAPve_g_ESC_LatAcc'
     */
    rtb_LogicalOperator3_c_tmp_1 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc());

    /* Abs: '<S539>/Abs1' incorporates:
     *  Abs: '<S445>/Abs'
     *  Abs: '<S446>/Abs'
     */
    rtb_LogicalOperator3_c_tmp_2 = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S540>/Logical Operator2' incorporates:
     *  Abs: '<S539>/Abs1'
     *  Abs: '<S539>/Abs2'
     *  Abs: '<S539>/Abs3'
     *  Abs: '<S539>/Abs4'
     *  Abs: '<S576>/Abs'
     *  Constant: '<S578>/Constant'
     *  Constant: '<S581>/Constant'
     *  Constant: '<S583>/Constant'
     *  Constant: '<S584>/Constant'
     *  Constant: '<S591>/Constant'
     *  Constant: '<S592>/Constant'
     *  Constant: '<S593>/Constant'
     *  Constant: '<S597>/Constant'
     *  Logic: '<S539>/Logical Operator3'
     *  Logic: '<S545>/FixPt Logical Operator'
     *  Logic: '<S577>/Logical Operator3'
     *  Logic: '<S579>/Logical Operator'
     *  Logic: '<S582>/FixPt Logical Operator'
     *  Logic: '<S585>/FixPt Logical Operator'
     *  Logic: '<S586>/Logical Operator'
     *  Logic: '<S590>/Logical Operator'
     *  Logic: '<S598>/FixPt Logical Operator'
     *  RelationalOperator: '<S539>/Relational Operator'
     *  RelationalOperator: '<S539>/Relational Operator1'
     *  RelationalOperator: '<S539>/Relational Operator2'
     *  RelationalOperator: '<S539>/Relational Operator3'
     *  RelationalOperator: '<S545>/Lower Test'
     *  RelationalOperator: '<S545>/Upper Test'
     *  RelationalOperator: '<S581>/Compare'
     *  RelationalOperator: '<S582>/Lower Test'
     *  RelationalOperator: '<S582>/Upper Test'
     *  RelationalOperator: '<S583>/Compare'
     *  RelationalOperator: '<S584>/Compare'
     *  RelationalOperator: '<S585>/Lower Test'
     *  RelationalOperator: '<S585>/Upper Test'
     *  RelationalOperator: '<S591>/Compare'
     *  RelationalOperator: '<S592>/Compare'
     *  RelationalOperator: '<S593>/Compare'
     *  RelationalOperator: '<S597>/Compare'
     *  RelationalOperator: '<S598>/Lower Test'
     *  RelationalOperator: '<S598>/Upper Test'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_LogicalOperator3_o = (((((((rtb_Gain_j <= rtb_ESC_VehSpd) &&
      (rtb_ESC_VehSpd <= rtb_Switch_e)) && ((rtb_L0_Q == ((uint8)0U)) &&
      (rtb_Lrg_Q == ((uint8)0U)))) && (rtb_Saturation_f <= 0.0F)) &&
      (rtb_TCU_ActualGear == ((uint8)3U))) && (((((rtb_IMAPve_d_LKA_Mode >
      ((uint8)2U)) && (rtb_R0_Q_c > ((uint8)2U))) &&
      ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) && (rtb_Abs1 <=
      rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) && (rtb_Abs <=
      rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) && (rtb_LogicalOperator3_c_tmp <=
      0.025F))) && (((((x1 < x10) && (rtb_LogicalOperator3_c_tmp_0 < x20)) &&
                      (rtb_LogicalOperator3_c_tmp_2 < rtb_LftTTLC)) &&
                     (rtb_LogicalOperator3_c_tmp_1 < rtb_TTLC_f)) &&
                    ((rtb_UnaryMinus < rtb_IMAPve_g_ESC_LonAcc) &&
                     (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* Switch: '<S665>/Switch6' incorporates:
     *  Constant: '<S665>/LLSMConClb44'
     *
     * Block description for '<S665>/LLSMConClb44':
     *  LKA���ܵ�ʹ����С�������ȼ�������
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Enable Condition  (EnaC)/LKA Own Condition (LKAOwnC)/Vehicle Position Check (VehPosChk)1/Subsystem/MATLAB Function': '<S574>:1' */
    /* '<S574>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*LaneWid_DvtMin); */
    if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion23;
    } else {
      x10 = LL_LKA_EnableLine_DvtMin;
    }

    /* End of Switch: '<S665>/Switch6' */

    /* MATLAB Function: '<S573>/MATLAB Function' */
    rtb_LftTTLC = (2.0F * x10) + rtb_LKA_CarWidth;

    /* Switch: '<S665>/Switch7' incorporates:
     *  Constant: '<S665>/LLSMConClb45'
     *
     * Block description for '<S665>/LLSMConClb45':
     *  LKA���ܵ�ʹ����󳵵����ȼ�������
     */
    /* '<S574>:1:3' LanWidmax = single(LKA_CarWidth+single(2)*LaneWid_DvtMax); */
    if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion24;
    } else {
      x10 = LL_LKA_EnableLine_DvtMax;
    }

    /* End of Switch: '<S665>/Switch7' */

    /* MATLAB Function: '<S573>/MATLAB Function' */
    rtb_TTLC_f = (2.0F * x10) + rtb_LKA_CarWidth;

    /* '<S574>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /*   LKA_Enable_Line = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S574>:1:6' LKA_Enable_Line = LKA_EnableLine_Max*(single(LanWid-LanWidmin))/single(LanWidmax-LanWidmin); */
    rtb_LKA_Enable_Line = ((fminf(fmaxf(rtb_LftTTLC, rtb_LKA_Veh2CamW_C),
      rtb_TTLC_f) - rtb_LftTTLC) * rtb_LL_LKA_EnableLine_Max) / (rtb_TTLC_f -
      rtb_LftTTLC);

    /* Switch: '<S575>/Switch' incorporates:
     *  Constant: '<S573>/Constant'
     *  RelationalOperator: '<S575>/UpperRelop'
     */
    if (rtb_LKA_Enable_Line < 0.0F) {
      rtb_Switch_g = 0.0F;
    } else {
      rtb_Switch_g = rtb_LKA_Enable_Line;
    }

    /* End of Switch: '<S575>/Switch' */

    /* Switch: '<S575>/Switch2' incorporates:
     *  RelationalOperator: '<S575>/LowerRelop1'
     */
    if (rtb_LKA_Enable_Line > rtb_LL_LKA_EnableLine_Max) {
      rtb_Switch2_n = rtb_LL_LKA_EnableLine_Max;
    } else {
      rtb_Switch2_n = rtb_Switch_g;
    }

    /* End of Switch: '<S575>/Switch2' */

    /* Abs: '<S560>/Abs1' incorporates:
     *  Abs: '<S468>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S560>/Abs2' incorporates:
     *  Abs: '<S468>/Abs1'
     */
    x20 = fabsf(rtb_TTLC_o);

    /* If: '<S540>/If1' incorporates:
     *  Abs: '<S560>/Abs1'
     *  Abs: '<S560>/Abs2'
     *  Constant: '<S547>/Constant'
     *  Constant: '<S562>/Constant'
     *  Constant: '<S563>/Constant'
     *  Constant: '<S568>/Constant'
     *  Constant: '<S569>/Constant'
     *  Constant: '<S570>/Constant'
     *  Constant: '<S571>/Constant'
     *  Logic: '<S540>/Logical Operator1'
     *  Logic: '<S557>/Logical Operator'
     *  Logic: '<S559>/Logical Operator'
     *  Logic: '<S560>/Logical Operator'
     *  Logic: '<S561>/Logical Operator'
     *  RelationalOperator: '<S560>/Relational Operator2'
     *  RelationalOperator: '<S560>/Relational Operator3'
     *  RelationalOperator: '<S561>/Relational Operator1'
     *  RelationalOperator: '<S561>/Relational Operator2'
     *  RelationalOperator: '<S562>/Compare'
     *  RelationalOperator: '<S563>/Compare'
     *  RelationalOperator: '<S568>/Compare'
     *  RelationalOperator: '<S569>/Compare'
     *  RelationalOperator: '<S570>/Compare'
     *  RelationalOperator: '<S571>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (rtb_LogicalOperator3_o &&
         ((((LKAS_DW.LKA_Mode_k == ((uint8)2U)) && (((sint32)
              (((rtb_FDMMve_d_LkaFcnConf == ((uint8)2U)) ||
                (rtb_FDMMve_d_LkaFcnConf == ((uint8)1U))) ? 1 : 0)) == ((sint32)
              (true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1 >= rtb_Switch2_n) &&
              (rtb_Add5_j >= rtb_Switch2_n)) ? 1 : 0)) == ((sint32)(true ? 1 : 0))))))
    {
      /* Outputs for IfAction SubSystem: '<S540>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S547>/Action Port'
       */
      LKAS_DW.Merge1_a = true;

      /* End of Outputs for SubSystem: '<S540>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S540>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S549>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_a);

      /* End of Outputs for SubSystem: '<S540>/If Action Subsystem4' */
    }

    /* End of If: '<S540>/If1' */

    /* Switch: '<S529>/Switch' incorporates:
     *  Constant: '<S666>/Constant'
     *  Constant: '<S671>/Constant'
     *  Gain: '<S666>/Gain'
     *  Gain: '<S671>/Gain'
     *  Sum: '<S666>/Add'
     *  Sum: '<S671>/Add'
     *  Switch: '<S665>/Switch67'
     */
    if (LKAS_DW.LKA_Mode_k >= ((uint8)2U)) {
      /* Switch: '<S665>/Switch80' incorporates:
       *  Constant: '<S665>/LLSMConClb21'
       *
       * Block description for '<S665>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_LftTTLC = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S665>/Switch80' */
      rtb_Switch_l = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S665>/Switch67' */
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S665>/Switch67' incorporates:
         *  Constant: '<S665>/LLSMConClb20'
         *
         * Block description for '<S665>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_LftTTLC = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_l = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S529>/Switch' */

    /* Logic: '<S529>/Logical Operator' incorporates:
     *  Logic: '<S538>/FixPt Logical Operator'
     *  RelationalOperator: '<S538>/Lower Test'
     *  RelationalOperator: '<S538>/Upper Test'
     */
    rtb_LogicalOperator_e = ((rtb_Gain_js >= rtb_ESC_VehSpd) || (rtb_ESC_VehSpd >=
      rtb_Switch_l));

    /* Logic: '<S527>/Logical Operator' incorporates:
     *  Logic: '<S347>/Logical Operator6'
     */
    rtb_LL_SingleLane_Disable_Swt = !rtb_LL_SingleLane_Disable_Swt;

    /* Switch: '<S527>/Switch' incorporates:
     *  Constant: '<S527>/Constant'
     *  Constant: '<S527>/Constant1'
     *  Constant: '<S534>/Constant'
     *  Constant: '<S535>/Constant'
     *  Constant: '<S536>/Constant'
     *  Delay: '<S143>/Delay1'
     *  Logic: '<S527>/Logical Operator'
     *  Logic: '<S527>/Logical Operator1'
     *  Logic: '<S527>/Logical Operator2'
     *  Logic: '<S527>/Logical Operator3'
     *  Logic: '<S527>/Logical Operator4'
     *  Logic: '<S527>/Logical Operator5'
     *  RelationalOperator: '<S534>/Compare'
     *  RelationalOperator: '<S535>/Compare'
     *  RelationalOperator: '<S536>/Compare'
     */
    if (((((rtb_Rrg_Q >= ((uint8)3U)) || (rtb_BCM_Left_Light &&
            rtb_LL_SingleLane_Disable_Swt)) || (rtb_BCM_Right_Light &&
           rtb_LL_SingleLane_Disable_Swt)) || (rtb_BCM_Left_Light &&
          (LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)))) || (rtb_BCM_Right_Light &&
         (LKAS_DW.Delay1_3_DSTATE == ((uint8)5U)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S527>/Switch' */

    /* Sum: '<S527>/Add' incorporates:
     *  Memory: '<S527>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_f;

    /* Saturate: '<S527>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_e = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_e = (-1.0F);
    } else {
      rtb_Saturation_e = rtb_LftTTLC;
    }

    /* End of Saturate: '<S527>/Saturation' */

    /* RelationalOperator: '<S533>/Compare' incorporates:
     *  Constant: '<S533>/Constant'
     */
    rtb_Compare_av = (rtb_Saturation_e > 1.0F);

    /* RelationalOperator: '<S537>/Compare' incorporates:
     *  Constant: '<S537>/Constant'
     */
    rtb_Compare_kq = (rtb_TCU_ActualGear != ((uint8)3U));

    /* Logic: '<S481>/Logical Operator' incorporates:
     *  Constant: '<S485>/Constant'
     *  Constant: '<S486>/Constant'
     *  RelationalOperator: '<S485>/Compare'
     *  RelationalOperator: '<S486>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_LogicalOperator_gy = ((rtb_IMAPve_d_LKA_Mode < ((uint8)3U)) &&
      (rtb_R0_Q_c < ((uint8)3U)));

    /* Abs: '<S482>/Abs1' */
    rtb_Abs1_a = rtb_Abs1_tmp;

    /* RelationalOperator: '<S487>/Compare' incorporates:
     *  Constant: '<S487>/Constant'
     *  Logic: '<S488>/FixPt Logical Operator'
     *  RelationalOperator: '<S488>/Lower Test'
     *  RelationalOperator: '<S488>/Upper Test'
     */
    rtb_Compare_lg = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_a) &&
      (rtb_Abs1_a <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S480>/Abs' */
    rtb_Abs_m = rtb_TLft;

    /* Logic: '<S480>/Logical Operator' incorporates:
     *  Constant: '<S480>/Constant'
     *  Logic: '<S484>/FixPt Logical Operator'
     *  RelationalOperator: '<S484>/Lower Test'
     *  RelationalOperator: '<S484>/Upper Test'
     */
    rtb_LogicalOperator_ez = ((0.0F > rtb_Abs_m) || (rtb_Abs_m >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S483>/Compare' incorporates:
     *  Constant: '<S483>/Constant'
     */
    rtb_Compare_cy = (rtb_LogicalOperator3_c_tmp > 0.04F);

    /* Switch: '<S665>/Switch72' incorporates:
     *  Constant: '<S665>/LLSMConClb26'
     *
     * Block description for '<S665>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S665>/Switch72' */

    /* RelationalOperator: '<S444>/Relational Operator1' */
    rtb_phiSWA_Thres = (x1 >= rtb_LftTTLC);

    /* Switch: '<S665>/Switch74' incorporates:
     *  Constant: '<S665>/LLSMConClb28'
     *
     * Block description for '<S665>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S665>/Switch74' */

    /* RelationalOperator: '<S444>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_LogicalOperator3_c_tmp_0 >= rtb_LftTTLC);

    /* Switch: '<S665>/Switch79' incorporates:
     *  Constant: '<S665>/LLSMConClb29'
     *
     * Block description for '<S665>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_LftTTLC = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S665>/Switch79' */

    /* Logic: '<S444>/Logical Operator1' incorporates:
     *  Constant: '<S447>/Constant'
     *  RelationalOperator: '<S444>/Relational Operator3'
     *  RelationalOperator: '<S447>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_c_tmp_1 >= rtb_LftTTLC) &&
                       (rtb_FDMMve_d_LkaFcnConf != ((uint8)3U)));

    /* Switch: '<S665>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S444>/Unary Minus' */
      rtb_UnaryMinus_i = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S444>/Unary Minus' incorporates:
       *  Constant: '<S665>/LLSMConClb30'
       *
       * Block description for '<S665>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_i = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S665>/Switch61' */

    /* RelationalOperator: '<S448>/Compare' incorporates:
     *  Constant: '<S448>/Constant'
     *  Logic: '<S449>/FixPt Logical Operator'
     *  RelationalOperator: '<S449>/Lower Test'
     *  RelationalOperator: '<S449>/Upper Test'
     */
    rtb_Compare_kj = (((sint32)(((rtb_UnaryMinus_i < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                      ((sint32)(false ? 1 : 0)));

    /* Logic: '<S445>/Logical Operator3' incorporates:
     *  Abs: '<S445>/Abs1'
     *  Constant: '<S445>/Constant'
     *  Constant: '<S445>/Constant1'
     *  Memory: '<S445>/Memory'
     *  RelationalOperator: '<S445>/Relational Operator1'
     *  RelationalOperator: '<S445>/Relational Operator2'
     *  Sum: '<S445>/Add'
     */
    rtb_LogicalOperator3_i = ((rtb_LogicalOperator3_c_tmp_2 <= 0.8F) && (fabsf
      (LKAS_DW.Memory_PreviousInput_d - rtb_IMAPve_g_EPS_SW_Trq) <= 0.01F));

    /* Outputs for Enabled SubSystem: '<S445>/ExitCount1' */
    /* Constant: '<S445>/Constant2' */
    LKAS_ExitCount(rtb_LogicalOperator3_i, rtb_LKA_SampleTime, 5.0F,
                   &LKAS_DW.RelationalOperator_b, &LKAS_DW.ExitCount1);

    /* End of Outputs for SubSystem: '<S445>/ExitCount1' */

    /* Switch: '<S445>/Switch' incorporates:
     *  Constant: '<S450>/Constant'
     *  RelationalOperator: '<S450>/Compare'
     */
    if (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U)) {
      rtb_TTLC_o = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
    } else {
      rtb_TTLC_o = rtb_R0_C1_g;
    }

    /* End of Switch: '<S445>/Switch' */

    /* Logic: '<S445>/OR' incorporates:
     *  RelationalOperator: '<S445>/Relational Operator'
     */
    rtb_OR_p = ((rtb_LogicalOperator3_c_tmp_2 <= rtb_TTLC_o) ||
                (LKAS_DW.RelationalOperator_b));

    /* Product: '<S445>/Divide' incorporates:
     *  Constant: '<S451>/Constant'
     *  Constant: '<S452>/Constant'
     *  Logic: '<S445>/Logical Operator1'
     *  Logic: '<S445>/Logical Operator2'
     *  RelationalOperator: '<S451>/Compare'
     *  RelationalOperator: '<S452>/Compare'
     */
    rtb_Divide_gr = (((rtb_FDMMve_d_LkaFcnConf == ((uint8)1U)) ||
                      (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U))) && rtb_OR_p) ?
      rtb_LKA_SampleTime : 0.0F;

    /* Outputs for Enabled SubSystem: '<S445>/ExitCount' */
    LKAS_ExitCount(rtb_OR_p, rtb_Divide_gr, rtb_LL_HandsOff_ExitTime,
                   &LKAS_DW.RelationalOperator_o, &LKAS_DW.ExitCount);

    /* End of Outputs for SubSystem: '<S445>/ExitCount' */

    /* Saturate: '<S446>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S455>:1' */
    /* '<S455>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S455>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S455>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S455>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_ESC_VehSpd > 80.0F) {
      rtb_LftTTLC = 80.0F;
    } else if (rtb_ESC_VehSpd < 60.0F) {
      rtb_LftTTLC = 60.0F;
    } else {
      rtb_LftTTLC = rtb_ESC_VehSpd;
    }

    /* End of Saturate: '<S446>/Saturation' */

    /* MATLAB Function: '<S446>/MATLAB Function' */
    if (rtb_LogicalOperator3_c_tmp_2 >= fminf(fmaxf(1.5F, ((1.5F *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL) - ((rtb_LftTTLC / 180.0F) *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL)) + (rtb_TLft / 0.005F)), 2.75F)) {
      /* Outputs for Enabled SubSystem: '<S446>/Sum Condition1' incorporates:
       *  EnablePort: '<S456>/state = reset'
       */
      /* '<S455>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_o) {
        /* InitializeConditions for Memory: '<S456>/Memory' */
        LKAS_DW.Memory_PreviousInput_oq = 0.0F;
        LKAS_DW.SumCondition1_MODE_o = true;
      }

      /* Sum: '<S456>/Add1' incorporates:
       *  Memory: '<S456>/Memory'
       */
      rtb_LL_LKA_EnableLine_Max = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_oq;

      /* Saturate: '<S456>/Saturation' */
      if (rtb_LL_LKA_EnableLine_Max > 5000.0F) {
        rtb_LL_LKA_EnableLine_Max = 5000.0F;
      } else {
        if (rtb_LL_LKA_EnableLine_Max < 0.0F) {
          rtb_LL_LKA_EnableLine_Max = 0.0F;
        }
      }

      /* End of Saturate: '<S456>/Saturation' */
      /* End of Outputs for SubSystem: '<S446>/Sum Condition1' */

      /* Switch: '<S665>/Switch65' incorporates:
       *  Constant: '<S665>/LLSMConClb34'
       *
       * Block description for '<S665>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_LftTTLC = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S665>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S446>/Sum Condition1' incorporates:
       *  EnablePort: '<S456>/state = reset'
       */
      /* RelationalOperator: '<S456>/Relational Operator' */
      LKAS_DW.RelationalOperator_i = (rtb_LL_LKA_EnableLine_Max >= rtb_LftTTLC);

      /* Update for Memory: '<S456>/Memory' */
      LKAS_DW.Memory_PreviousInput_oq = rtb_LL_LKA_EnableLine_Max;

      /* End of Outputs for SubSystem: '<S446>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S446>/Sum Condition1' incorporates:
       *  EnablePort: '<S456>/state = reset'
       */
      /* '<S455>:1:7' else */
      /* '<S455>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S456>/Out' */
        LKAS_DW.RelationalOperator_i = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }

      /* End of Outputs for SubSystem: '<S446>/Sum Condition1' */
    }

    /* RelationalOperator: '<S462>/Compare' incorporates:
     *  Constant: '<S462>/Constant'
     */
    rtb_Compare_f2 = (((sint32)(LKAS_DW.RelationalOperator_i ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S457>/Unit Delay' */
    rtb_UnitDelay_e = LKAS_DW.UnitDelay_DSTATE_e;

    /* If: '<S457>/If' incorporates:
     *  Constant: '<S459>/Constant'
     *  RelationalOperator: '<S458>/FixPt Relational Operator'
     *  UnitDelay: '<S458>/Delay Input1'
     *
     * Block description for '<S458>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if (((sint32)(rtb_Compare_f2 ? 1 : 0)) > ((sint32)
         (LKAS_DW.DelayInput1_DSTATE ? 1 : 0))) {
      /* Outputs for IfAction SubSystem: '<S457>/If Action Subsystem' incorporates:
       *  ActionPort: '<S459>/Action Port'
       */
      rtb_Merge_m = true;

      /* End of Outputs for SubSystem: '<S457>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S457>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S460>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_e, &rtb_Merge_m);

      /* End of Outputs for SubSystem: '<S457>/If Action Subsystem3' */
    }

    /* End of If: '<S457>/If' */

    /* Outputs for Enabled SubSystem: '<S457>/Sum Condition1' incorporates:
     *  EnablePort: '<S461>/state = reset'
     */
    if (rtb_Merge_m) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S461>/Memory' */
        LKAS_DW.Memory_PreviousInput_o = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S461>/Add1' incorporates:
       *  Memory: '<S461>/Memory'
       */
      rtb_LL_LKA_EnableLine_Max = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_o;

      /* Saturate: '<S461>/Saturation' */
      if (rtb_LL_LKA_EnableLine_Max > 10.0F) {
        rtb_LL_LKA_EnableLine_Max = 10.0F;
      } else {
        if (rtb_LL_LKA_EnableLine_Max < 0.0F) {
          rtb_LL_LKA_EnableLine_Max = 0.0F;
        }
      }

      /* End of Saturate: '<S461>/Saturation' */

      /* RelationalOperator: '<S461>/Relational Operator' */
      LKAS_DW.RelationalOperator_g = (rtb_LL_LKA_EnableLine_Max <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S461>/Memory' */
      LKAS_DW.Memory_PreviousInput_o = rtb_LL_LKA_EnableLine_Max;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S461>/Out' */
        LKAS_DW.RelationalOperator_g = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S457>/Sum Condition1' */

    /* Logic: '<S457>/Logical Operator' */
    rtb_stDvrTkConFlg_n = ((LKAS_DW.RelationalOperator_i) ||
      (LKAS_DW.RelationalOperator_g));

    /* Logic: '<S430>/Logical Operator2' incorporates:
     *  Constant: '<S531>/Constant'
     *  Constant: '<S532>/Constant'
     *  Logic: '<S443>/Logical Operator1'
     *  Logic: '<S444>/Logical Operator'
     *  Logic: '<S479>/Logical Operator3'
     *  Logic: '<S526>/OR'
     *  Logic: '<S530>/Logical Operator3'
     *  RelationalOperator: '<S531>/Compare'
     *  RelationalOperator: '<S532>/Compare'
     */
    rtb_RelationalOperator_n = (((((rtb_LogicalOperator_e || ((rtb_L0_Q ==
      ((uint8)1U)) || (rtb_Lrg_Q == ((uint8)1U)))) || rtb_Compare_av) ||
      rtb_Compare_kq) || (((rtb_LogicalOperator_gy || rtb_Compare_lg) ||
      rtb_LogicalOperator_ez) || rtb_Compare_cy)) || (((((rtb_phiSWA_Thres ||
      rtb_dphiSWARate_Thres) || rtb_aLAcc_Thres) || rtb_Compare_kj) ||
      (LKAS_DW.RelationalOperator_o)) || rtb_stDvrTkConFlg_n));

    /* Logic: '<S468>/Logical Operator' incorporates:
     *  RelationalOperator: '<S468>/Relational Operator1'
     *  RelationalOperator: '<S468>/Relational Operator2'
     */
    rtb_LogicalOperator_ac = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S469>/Logical Operator' incorporates:
     *  RelationalOperator: '<S469>/Relational Operator1'
     *  RelationalOperator: '<S469>/Relational Operator2'
     */
    rtb_LogicalOperator_lm = ((rtb_Gain1 <= rtb_LL_LKA_LatestWarnLine_C) ||
      (rtb_Add5_j <= rtb_LL_LKA_LatestWarnLine_C));

    /* If: '<S430>/If2' incorporates:
     *  Constant: '<S439>/Constant'
     *  Constant: '<S474>/Constant'
     *  Constant: '<S475>/Constant'
     *  Constant: '<S477>/Constant'
     *  Logic: '<S430>/Logical Operator1'
     *  Logic: '<S467>/Logical Operator'
     *  Logic: '<S467>/Logical Operator1'
     *  RelationalOperator: '<S474>/Compare'
     *  RelationalOperator: '<S475>/Compare'
     *  RelationalOperator: '<S477>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (rtb_RelationalOperator_n ||
         ((LKAS_DW.LKA_Mode_k == ((uint8)2U)) && ((rtb_LogicalOperator_ac ==
            true) || (rtb_LogicalOperator_lm == true))))) {
      /* Outputs for IfAction SubSystem: '<S430>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S439>/Action Port'
       */
      LKAS_DW.Merge2 = true;

      /* End of Outputs for SubSystem: '<S430>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S430>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S441>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2);

      /* End of Outputs for SubSystem: '<S430>/If Action Subsystem3' */
    }

    /* End of If: '<S430>/If2' */

    /* If: '<S367>/If' */
    if ((rtb_Abs_f >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_d >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S367>/Ph1SWA' incorporates:
       *  ActionPort: '<S371>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S367>/Ph1SWA' */
    } else if ((rtb_Abs_f <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_d <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S367>/Ph2SWA' incorporates:
       *  ActionPort: '<S372>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S367>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S367>/Ph3SWA' incorporates:
       *  ActionPort: '<S373>/Action Port'
       */
      LKAS_Ph3SWA_d(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S367>/Ph3SWA' */
    }

    /* End of If: '<S367>/If' */

    /* Saturate: '<S345>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = (-2.0F);
    } else {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_Gain1;
    }

    /* End of Saturate: '<S345>/Saturation5' */

    /* MATLAB Function: '<S354>/MATLAB Function' incorporates:
     *  MATLAB Function: '<S390>/MATLAB Function'
     *  MATLAB Function: '<S554>/MATLAB Function'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S357>:1' */
    /* '<S357>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S357>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S357>:1:5' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S357>:1:6' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S357>:1:7' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_LKA_Veh2CamL_C = (2.0F * rtb_LL_ThresDet_lDvtThresUprLDW) +
      rtb_LKA_CarWidth;
    rtb_LKA_Veh2CamL_C = fminf(fmaxf(0.0F, (fminf(fmaxf(rtb_LKA_Veh2CamL_C,
      rtb_LKA_Veh2CamW_C), (6.0F * rtb_LL_ThresDet_lDvtThresUprLDW) +
      rtb_LKA_CarWidth) - rtb_LKA_Veh2CamL_C) / (4.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW)), 1.0F);

    /* Product: '<S354>/Divide5' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_LftTTLC = rtb_LKA_Veh2CamL_C * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S354>/Divide6' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    x20 = rtb_LKA_Veh2CamL_C * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S369>/Abs' incorporates:
     *  Abs: '<S360>/Abs'
     *  Abs: '<S396>/Abs'
     */
    rtb_TTLC_f = fabsf(rtb_Abs_f);

    /* Product: '<S369>/Divide' incorporates:
     *  Abs: '<S369>/Abs'
     */
    rtb_Divide_i = x20 * rtb_TTLC_f;

    /* Product: '<S354>/Divide4' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_LL_LKA_EnableLine_Max = rtb_LKA_Veh2CamL_C *
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S374>/Switch' incorporates:
     *  RelationalOperator: '<S374>/UpperRelop'
     */
    if (rtb_Divide_i < rtb_LL_LKA_EnableLine_Max) {
      rtb_Switch_j = rtb_LL_LKA_EnableLine_Max;
    } else {
      rtb_Switch_j = rtb_Divide_i;
    }

    /* End of Switch: '<S374>/Switch' */

    /* Switch: '<S374>/Switch2' incorporates:
     *  RelationalOperator: '<S374>/LowerRelop1'
     */
    if (rtb_Divide_i > rtb_LftTTLC) {
      rtb_Switch2_l = rtb_LftTTLC;
    } else {
      rtb_Switch2_l = rtb_Switch_j;
    }

    /* End of Switch: '<S374>/Switch2' */

    /* Saturate: '<S345>/Saturation1' */
    if (rtb_Add5_j > 2.0F) {
      rtb_TTLC_o = 2.0F;
    } else if (rtb_Add5_j < (-2.0F)) {
      rtb_TTLC_o = (-2.0F);
    } else {
      rtb_TTLC_o = rtb_Add5_j;
    }

    /* End of Saturate: '<S345>/Saturation1' */

    /* Abs: '<S370>/Abs' incorporates:
     *  Abs: '<S361>/Abs'
     *  Abs: '<S397>/Abs'
     */
    rtb_LogicalOperator3_c_tmp_2 = fabsf(rtb_Abs_d);

    /* Product: '<S370>/Divide' incorporates:
     *  Abs: '<S370>/Abs'
     */
    rtb_Divide_gw = x20 * rtb_LogicalOperator3_c_tmp_2;

    /* Switch: '<S375>/Switch' incorporates:
     *  RelationalOperator: '<S375>/UpperRelop'
     */
    if (rtb_Divide_gw < rtb_LL_LKA_EnableLine_Max) {
      rtb_Switch_o = rtb_LL_LKA_EnableLine_Max;
    } else {
      rtb_Switch_o = rtb_Divide_gw;
    }

    /* End of Switch: '<S375>/Switch' */

    /* Switch: '<S375>/Switch2' incorporates:
     *  RelationalOperator: '<S375>/LowerRelop1'
     */
    if (rtb_Divide_gw > rtb_LftTTLC) {
      rtb_Switch2_lf = rtb_LftTTLC;
    } else {
      rtb_Switch2_lf = rtb_Switch_o;
    }

    /* End of Switch: '<S375>/Switch2' */

    /* Switch: '<S368>/Switch3' incorporates:
     *  Constant: '<S370>/Constant'
     *  Gain: '<S368>/Gain1'
     *  Logic: '<S370>/Logical Operator'
     *  RelationalOperator: '<S370>/Relational Operator1'
     *  RelationalOperator: '<S370>/Relational Operator2'
     */
    if (rtb_Merge1 >= 0.0F) {
      /* Switch: '<S368>/Switch2' incorporates:
       *  Constant: '<S368>/Constant2'
       *  Constant: '<S369>/Constant'
       *  DataTypeConversion: '<S368>/Cast To Single'
       *  Logic: '<S369>/Logical Operator'
       *  RelationalOperator: '<S369>/Relational Operator1'
       *  RelationalOperator: '<S369>/Relational Operator3'
       */
      if (rtb_Merge1 > 0.0F) {
        rtb_Lrg_Q = (uint8)(((0.0F < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) &&
                             (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <= rtb_Switch2_l))
                            ? 1 : 0);
      } else {
        rtb_Lrg_Q = ((uint8)0U);
      }

      /* End of Switch: '<S368>/Switch2' */
    } else {
      rtb_Lrg_Q = (uint8)((((uint32)(((0.0F < rtb_TTLC_o) && (rtb_TTLC_o <=
        rtb_Switch2_lf)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S368>/Switch3' */

    /* DataTypeConversion: '<S347>/Data Type Conversion' incorporates:
     *  Constant: '<S378>/Constant'
     *  Constant: '<S379>/Constant'
     *  Constant: '<S380>/Constant'
     *  Constant: '<S381>/Constant'
     *  Logic: '<S347>/Logical Operator'
     *  Logic: '<S347>/Logical Operator1'
     *  Logic: '<S347>/Logical Operator2'
     *  Logic: '<S347>/Logical Operator3'
     *  Logic: '<S347>/Logical Operator4'
     *  Logic: '<S347>/Logical Operator5'
     *  Logic: '<S347>/Logical Operator7'
     *  RelationalOperator: '<S378>/Compare'
     *  RelationalOperator: '<S379>/Compare'
     *  RelationalOperator: '<S380>/Compare'
     *  RelationalOperator: '<S381>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_L0_Q = (uint8)(((((rtb_LL_SingleLane_Disable_Swt ||
      (!rtb_BCM_Right_Light)) && (rtb_R0_Q_c > ((uint8)2U))) && (rtb_Lrg_Q ==
      ((uint8)2U))) || (((rtb_LL_SingleLane_Disable_Swt || (!rtb_BCM_Left_Light))
                         && (rtb_Lrg_Q == ((uint8)1U))) &&
                        (rtb_IMAPve_d_LKA_Mode > ((uint8)2U)))) ? 1 : 0);

    /* DataTypeConversion: '<S346>/Data Type Conversion' incorporates:
     *  Constant: '<S376>/Constant'
     *  Constant: '<S377>/Constant'
     *  Logic: '<S346>/Logical Operator'
     *  RelationalOperator: '<S376>/Compare'
     *  RelationalOperator: '<S377>/Compare'
     */
    rtb_Rrg_Q = (uint8)(((rtb_FDMMve_d_LkaFcnConf == ((uint8)1U)) ||
                         (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U))) ? 1 : 0);

    /* If: '<S344>/If1' incorporates:
     *  Constant: '<S349>/Constant'
     *  Constant: '<S352>/Constant'
     *  Constant: '<S353>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (((sint32)rtb_Lrg_Q) == 1)) &&
         (((sint32)rtb_Rrg_Q) == 1)) && (((sint32)rtb_L0_Q) == 1)) {
      /* Outputs for IfAction SubSystem: '<S344>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S352>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S344>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (((sint32)rtb_Lrg_Q) ==
                  2)) && (((sint32)rtb_Rrg_Q) == 1)) && (((sint32)rtb_L0_Q) == 1))
    {
      /* Outputs for IfAction SubSystem: '<S344>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S353>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S344>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S344>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S349>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S344>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S344>/If1' */

    /* If: '<S404>/If' */
    if ((rtb_Abs_f >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_d >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S404>/Ph1SWA' incorporates:
       *  ActionPort: '<S408>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_b);

      /* End of Outputs for SubSystem: '<S404>/Ph1SWA' */
    } else if ((rtb_Abs_f <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_Abs_d <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S404>/Ph2SWA' incorporates:
       *  ActionPort: '<S409>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_b);

      /* End of Outputs for SubSystem: '<S404>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S404>/Ph3SWA' incorporates:
       *  ActionPort: '<S410>/Action Port'
       */
      LKAS_Ph3SWA_d(&rtb_Merge1_b);

      /* End of Outputs for SubSystem: '<S404>/Ph3SWA' */
    }

    /* End of If: '<S404>/If' */

    /* Saturate: '<S383>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      x20 = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      x20 = (-2.0F);
    } else {
      x20 = rtb_Gain1;
    }

    /* End of Saturate: '<S383>/Saturation5' */

    /* Product: '<S390>/Divide5' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S393>:1' */
    /* '<S393>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S393>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S393>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S393>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S393>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_LL_ThresDet_lDvtThresUprLKA *= rtb_LKA_Veh2CamL_C;

    /* Product: '<S390>/Divide6' */
    rtb_LL_LKA_EnableLine_Max = rtb_LKA_Veh2CamL_C *
      rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S406>/Divide' incorporates:
     *  Abs: '<S406>/Abs'
     */
    rtb_Divide_gj = rtb_LL_LKA_EnableLine_Max * fabsf(rtb_Abs_f);

    /* Product: '<S390>/Divide4' */
    rtb_LftTTLC = rtb_LKA_Veh2CamL_C * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S411>/Switch' incorporates:
     *  RelationalOperator: '<S411>/UpperRelop'
     */
    if (rtb_Divide_gj < rtb_LftTTLC) {
      rtb_Switch_jg = rtb_LftTTLC;
    } else {
      rtb_Switch_jg = rtb_Divide_gj;
    }

    /* End of Switch: '<S411>/Switch' */

    /* Switch: '<S411>/Switch2' incorporates:
     *  RelationalOperator: '<S411>/LowerRelop1'
     */
    if (rtb_Divide_gj > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_g = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_g = rtb_Switch_jg;
    }

    /* End of Switch: '<S411>/Switch2' */

    /* Saturate: '<S383>/Saturation1' */
    if (rtb_Add5_j > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_j < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_j;
    }

    /* End of Saturate: '<S383>/Saturation1' */

    /* Product: '<S407>/Divide' incorporates:
     *  Abs: '<S407>/Abs'
     */
    rtb_Divide_h = rtb_LL_LKA_EnableLine_Max * fabsf(rtb_Abs_d);

    /* Switch: '<S412>/Switch' incorporates:
     *  RelationalOperator: '<S412>/UpperRelop'
     */
    if (rtb_Divide_h < rtb_LftTTLC) {
      rtb_Switch_i = rtb_LftTTLC;
    } else {
      rtb_Switch_i = rtb_Divide_h;
    }

    /* End of Switch: '<S412>/Switch' */

    /* Switch: '<S412>/Switch2' incorporates:
     *  RelationalOperator: '<S412>/LowerRelop1'
     */
    if (rtb_Divide_h > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_j = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_j = rtb_Switch_i;
    }

    /* End of Switch: '<S412>/Switch2' */

    /* Switch: '<S405>/Switch3' incorporates:
     *  Constant: '<S407>/Constant'
     *  Gain: '<S405>/Gain1'
     *  Logic: '<S407>/Logical Operator'
     *  RelationalOperator: '<S407>/Relational Operator1'
     *  RelationalOperator: '<S407>/Relational Operator2'
     */
    if (rtb_Merge1_b >= 0.0F) {
      /* Switch: '<S405>/Switch2' incorporates:
       *  Constant: '<S405>/Constant2'
       *  Constant: '<S406>/Constant'
       *  DataTypeConversion: '<S405>/Cast To Single'
       *  Logic: '<S406>/Logical Operator'
       *  RelationalOperator: '<S406>/Relational Operator1'
       *  RelationalOperator: '<S406>/Relational Operator3'
       */
      if (rtb_Merge1_b > 0.0F) {
        rtb_Lrg_Q = (uint8)(((0.0F < x20) && (x20 <= rtb_Switch2_g)) ? 1 : 0);
      } else {
        rtb_Lrg_Q = ((uint8)0U);
      }

      /* End of Switch: '<S405>/Switch2' */
    } else {
      rtb_Lrg_Q = (uint8)((((uint32)(((0.0F < rtb_LL_ThresDet_lDvtThresLwrLKA) &&
        (rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_j)) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S405>/Switch3' */

    /* MATLAB Function: '<S384>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S416>:1' */
    /* '<S416>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S416>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S416>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S416>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge), 0.005F)) / 0.005F);

    /* '<S416>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_Lrg_Q) == 2) && (rtb_IMAPve_g_EPS_SW_Trq >
          rtb_LL_MAX_DRIVER_TORQUE_DISABL)) || ((((sint32)rtb_Lrg_Q) == 1) &&
         (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL)))) {
      /* Outputs for Enabled SubSystem: '<S384>/Count 0.2s' incorporates:
       *  EnablePort: '<S415>/Enable'
       */
      /* '<S416>:1:7' stDvrTkConFlg=1; */
      /* '<S416>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S416>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S415>/Memory' */
        LKAS_DW.Memory_PreviousInput_do = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S415>/Add' incorporates:
       *  Memory: '<S415>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_do;

      /* Saturate: '<S415>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S415>/Saturation' */
      /* End of Outputs for SubSystem: '<S384>/Count 0.2s' */

      /* Switch: '<S665>/Switch16' incorporates:
       *  Constant: '<S665>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S665>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S665>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S384>/Count 0.2s' incorporates:
       *  EnablePort: '<S415>/Enable'
       */
      /* RelationalOperator: '<S415>/Relational Operator' */
      LKAS_DW.RelationalOperator_p = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S415>/Memory' */
      LKAS_DW.Memory_PreviousInput_do = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S384>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S384>/Count 0.2s' incorporates:
       *  EnablePort: '<S415>/Enable'
       */
      /* '<S416>:1:10' else */
      /* '<S416>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S415>/Out' */
        LKAS_DW.RelationalOperator_p = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S384>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S384>/MATLAB Function' */

    /* RelationalOperator: '<S425>/Compare' incorporates:
     *  Constant: '<S425>/Constant'
     */
    rtb_Compare_nn = (((sint32)(LKAS_DW.RelationalOperator_p ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S417>/Unit Delay' */
    rtb_UnitDelay_d = LKAS_DW.UnitDelay_DSTATE_jz;

    /* RelationalOperator: '<S424>/Compare' incorporates:
     *  Constant: '<S424>/Constant'
     */
    rtb_Compare_mh = (((sint32)(rtb_UnitDelay_d ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S417>/If' incorporates:
     *  Constant: '<S420>/Constant'
     *  Constant: '<S421>/Constant'
     *  RelationalOperator: '<S418>/FixPt Relational Operator'
     *  RelationalOperator: '<S419>/FixPt Relational Operator'
     *  UnitDelay: '<S418>/Delay Input1'
     *  UnitDelay: '<S419>/Delay Input1'
     *
     * Block description for '<S418>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S419>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_p) && (((sint32)(rtb_Compare_nn ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_h ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S417>/If Action Subsystem' incorporates:
       *  ActionPort: '<S420>/Action Port'
       */
      rtb_Merge_oy = true;

      /* End of Outputs for SubSystem: '<S417>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_d) && (((sint32)(rtb_Compare_mh ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_k ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S417>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S421>/Action Port'
       */
      rtb_Merge_oy = false;

      /* End of Outputs for SubSystem: '<S417>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S417>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S422>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_d, &rtb_Merge_oy);

      /* End of Outputs for SubSystem: '<S417>/If Action Subsystem3' */
    }

    /* End of If: '<S417>/If' */

    /* Outputs for Enabled SubSystem: '<S384>/Count' incorporates:
     *  EnablePort: '<S414>/Enable'
     */
    /* Logic: '<S384>/Logical Operator' incorporates:
     *  Constant: '<S413>/Constant'
     *  Memory: '<S384>/Memory'
     *  RelationalOperator: '<S413>/Compare'
     */
    if ((rtb_Lrg_Q > ((uint8)0U)) && (LKAS_DW.Memory_PreviousInput_cb)) {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S414>/Memory' */
        LKAS_DW.Memory_PreviousInput_m = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S414>/Add' incorporates:
       *  Memory: '<S414>/Memory'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_m;

      /* Saturate: '<S414>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_LftTTLC;
      }

      /* End of Saturate: '<S414>/Saturation' */

      /* Update for Memory: '<S414>/Memory' */
      LKAS_DW.Memory_PreviousInput_m = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S414>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S384>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S384>/Count' */

    /* Outputs for Enabled SubSystem: '<S417>/Sum Condition1' incorporates:
     *  EnablePort: '<S423>/state = reset'
     */
    if (rtb_Merge_oy) {
      if (!LKAS_DW.SumCondition1_MODE_o3) {
        /* InitializeConditions for Memory: '<S423>/Memory' */
        LKAS_DW.Memory_PreviousInput_j3 = 0.0F;
        LKAS_DW.SumCondition1_MODE_o3 = true;
      }

      /* Sum: '<S423>/Add1' incorporates:
       *  Memory: '<S423>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_j3;

      /* Saturate: '<S423>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 5.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 5.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S423>/Saturation' */

      /* Switch: '<S665>/Switch40' incorporates:
       *  Constant: '<S665>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S665>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S665>/Switch40' */

      /* RelationalOperator: '<S423>/Relational Operator' incorporates:
       *  Sum: '<S384>/Add'
       */
      LKAS_DW.RelationalOperator_f = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S423>/Memory' */
      LKAS_DW.Memory_PreviousInput_j3 = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_o3) {
        /* Disable for Outport: '<S423>/Out' */
        LKAS_DW.RelationalOperator_f = false;
        LKAS_DW.SumCondition1_MODE_o3 = false;
      }
    }

    /* End of Outputs for SubSystem: '<S417>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S385>/Sum Condition1' incorporates:
     *  EnablePort: '<S429>/state = reset'
     */
    /* Logic: '<S385>/Logical Operator' incorporates:
     *  Constant: '<S427>/Constant'
     *  Constant: '<S428>/Constant'
     *  Delay: '<S143>/Delay1'
     *  RelationalOperator: '<S427>/Compare'
     *  RelationalOperator: '<S428>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_b) {
        /* InitializeConditions for Memory: '<S429>/Memory' */
        LKAS_DW.Memory_PreviousInput_jz = 0.0F;
        LKAS_DW.SumCondition1_MODE_b = true;
      }

      /* Sum: '<S429>/Add1' incorporates:
       *  Memory: '<S429>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_jz;

      /* Saturate: '<S429>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S429>/Saturation' */

      /* RelationalOperator: '<S429>/Relational Operator' */
      LKAS_DW.RelationalOperator_m = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S429>/Memory' */
      LKAS_DW.Memory_PreviousInput_jz = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S429>/Out' */
        LKAS_DW.RelationalOperator_m = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }
    }

    /* End of Logic: '<S385>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S385>/Sum Condition1' */

    /* If: '<S382>/If1' incorporates:
     *  Constant: '<S387>/Constant'
     *  Constant: '<S389>/Constant'
     *  Constant: '<S426>/Constant'
     *  Delay: '<S143>/Delay'
     *  Logic: '<S382>/Logical Operator'
     *  Logic: '<S385>/Logical Operator1'
     *  RelationalOperator: '<S426>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (((LKAS_DW.RelationalOperator_f) ||
          ((rtb_FDMMve_d_LkaFcnConf != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_m))) || (LKAS_DW.Delay_DSTATE_p))) {
      /* Outputs for IfAction SubSystem: '<S382>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S389>/Action Port'
       */
      LKAS_DW.Merge1_j = true;

      /* End of Outputs for SubSystem: '<S382>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S382>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S387>/Action Port'
       */
      LKAS_DW.Merge1_j = false;

      /* End of Outputs for SubSystem: '<S382>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S382>/If1' */

    /* Product: '<S554>/Multiply' incorporates:
     *  Product: '<S354>/Divide2'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Enable Condition  (EnaC)/LDW Own Condition (LDWOwnC)/Vehicle Position Check (VehPosChk)/Subsystem/MATLAB Function': '<S555>:1' */
    /* '<S555>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S555>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S555>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S555>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S555>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LKA_Veh2CamL_C *
      rtb_LL_ThresDet_lDvtThresUprLDW;
    rtb_Multiply = rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Switch: '<S556>/Switch' incorporates:
     *  Constant: '<S554>/Constant'
     *  RelationalOperator: '<S556>/UpperRelop'
     */
    if (rtb_Multiply < 0.0F) {
      rtb_Switch_m = 0.0F;
    } else {
      rtb_Switch_m = rtb_Multiply;
    }

    /* End of Switch: '<S556>/Switch' */

    /* Switch: '<S556>/Switch2' incorporates:
     *  RelationalOperator: '<S556>/LowerRelop1'
     */
    if (rtb_Multiply > rtb_LL_ThresDet_lDvtThresUprLDW) {
      rtb_Switch2_p = rtb_LL_ThresDet_lDvtThresUprLDW;
    } else {
      rtb_Switch2_p = rtb_Switch_m;
    }

    /* End of Switch: '<S556>/Switch2' */

    /* Logic: '<S540>/Logical Operator3' incorporates:
     *  Constant: '<S552>/Constant'
     *  Constant: '<S553>/Constant'
     *  Logic: '<S550>/Logical Operator'
     *  Logic: '<S551>/Logical Operator'
     *  RelationalOperator: '<S551>/Relational Operator1'
     *  RelationalOperator: '<S551>/Relational Operator2'
     *  RelationalOperator: '<S552>/Compare'
     *  RelationalOperator: '<S553>/Compare'
     */
    rtb_LogicalOperator3_o = (((LKAS_DW.LKA_Mode_k >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1 >= rtb_Switch2_p) && (rtb_Add5_j >= rtb_Switch2_p)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_o);

    /* If: '<S540>/If' incorporates:
     *  Constant: '<S546>/Constant'
     *  DataTypeConversion: '<S540>/Cast To Single'
     */
    if (((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
          2)) && rtb_LogicalOperator3_o) {
      /* Outputs for IfAction SubSystem: '<S540>/If Action Subsystem' incorporates:
       *  ActionPort: '<S546>/Action Port'
       */
      LKAS_DW.Merge_pz = true;

      /* End of Outputs for SubSystem: '<S540>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S540>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S548>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_pz);

      /* End of Outputs for SubSystem: '<S540>/If Action Subsystem3' */
    }

    /* End of If: '<S540>/If' */

    /* Delay: '<S143>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S432>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S432>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_io != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S432>/If Action Subsystem' incorporates:
         *  ActionPort: '<S463>/Action Port'
         */
        /* InitializeConditions for If: '<S432>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S463>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_h = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S432>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S432>/If Action Subsystem' incorporates:
       *  ActionPort: '<S463>/Action Port'
       */
      /* Sum: '<S463>/Add1' incorporates:
       *  Memory: '<S463>/Memory'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_h;

      /* Saturate: '<S463>/Saturation' */
      if (rtb_LL_TkOvStChk_tiTDelTime > 10.0F) {
        rtb_LL_TkOvStChk_tiTDelTime = 10.0F;
      } else {
        if (rtb_LL_TkOvStChk_tiTDelTime < 0.0F) {
          rtb_LL_TkOvStChk_tiTDelTime = 0.0F;
        }
      }

      /* End of Saturate: '<S463>/Saturation' */
      /* End of Outputs for SubSystem: '<S432>/If Action Subsystem' */

      /* Switch: '<S665>/Switch64' incorporates:
       *  Constant: '<S665>/LLSMConClb33'
       *
       * Block description for '<S665>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S665>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S432>/If Action Subsystem' incorporates:
       *  ActionPort: '<S463>/Action Port'
       */
      /* RelationalOperator: '<S463>/Relational Operator' */
      rtb_Merge_g2 = (rtb_LL_TkOvStChk_tiTDelTime >= x10);

      /* Update for Memory: '<S463>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = rtb_LL_TkOvStChk_tiTDelTime;

      /* End of Outputs for SubSystem: '<S432>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S432>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S464>/Action Port'
       */
      /* SignalConversion: '<S464>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S464>/Constant'
       */
      rtb_Merge_g2 = false;

      /* End of Outputs for SubSystem: '<S432>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S432>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S433>/Logical Operator1' incorporates:
     *  Constant: '<S465>/Constant'
     *  Logic: '<S433>/Logical Operator'
     *  RelationalOperator: '<S433>/Relational Operator1'
     *  RelationalOperator: '<S433>/Relational Operator2'
     *  RelationalOperator: '<S465>/Compare'
     */
    rtb_BCM_Left_Light = ((LKAS_DW.LKA_Mode_k >= ((uint8)1U)) && ((rtb_Gain1 <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_j <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S430>/Logical Operator3' */
    rtb_RelationalOperator_n = ((rtb_BCM_Left_Light || rtb_Merge_g2) ||
      rtb_RelationalOperator_n);

    /* If: '<S430>/If1' incorporates:
     *  Constant: '<S440>/Constant'
     *  DataTypeConversion: '<S430>/Cast To Single'
     */
    if (((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
          2)) && rtb_RelationalOperator_n) {
      /* Outputs for IfAction SubSystem: '<S430>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S440>/Action Port'
       */
      LKAS_DW.Merge1_jp = true;

      /* End of Outputs for SubSystem: '<S430>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S430>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S442>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_jp);

      /* End of Outputs for SubSystem: '<S430>/If Action Subsystem4' */
    }

    /* End of If: '<S430>/If1' */

    /* Memory: '<S358>/Memory' */
    rtb_Memory = LKAS_DW.Memory_PreviousInput_j;

    /* If: '<S358>/If' */
    if ((rtb_Abs_f >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_d >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S358>/Ph1SWA' incorporates:
       *  ActionPort: '<S362>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_c);

      /* End of Outputs for SubSystem: '<S358>/Ph1SWA' */
    } else if ((rtb_Abs_f <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_d <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S358>/Ph2SWA' incorporates:
       *  ActionPort: '<S363>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_c);

      /* End of Outputs for SubSystem: '<S358>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S358>/Ph3SWA' incorporates:
       *  ActionPort: '<S364>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory, &rtb_Merge1_c);

      /* End of Outputs for SubSystem: '<S358>/Ph3SWA' */
    }

    /* End of If: '<S358>/If' */

    /* Product: '<S354>/Divide3' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_LL_LKA_EnableLine_Max = rtb_LKA_Veh2CamL_C *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S360>/Divide' */
    rtb_Divide_m = rtb_LL_LKA_EnableLine_Max * rtb_TTLC_f;

    /* Product: '<S354>/Divide1' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_LftTTLC = rtb_LKA_Veh2CamL_C * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S365>/Switch' incorporates:
     *  RelationalOperator: '<S365>/UpperRelop'
     */
    if (rtb_Divide_m < rtb_LftTTLC) {
      rtb_Switch_lm = rtb_LftTTLC;
    } else {
      rtb_Switch_lm = rtb_Divide_m;
    }

    /* End of Switch: '<S365>/Switch' */

    /* Switch: '<S365>/Switch2' incorporates:
     *  RelationalOperator: '<S365>/LowerRelop1'
     */
    if (rtb_Divide_m > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_nd = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_nd = rtb_Switch_lm;
    }

    /* End of Switch: '<S365>/Switch2' */

    /* Product: '<S361>/Divide' */
    rtb_Divide_l = rtb_LL_LKA_EnableLine_Max * rtb_LogicalOperator3_c_tmp_2;

    /* Switch: '<S366>/Switch' incorporates:
     *  RelationalOperator: '<S366>/UpperRelop'
     */
    if (rtb_Divide_l < rtb_LftTTLC) {
      rtb_Switch_h = rtb_LftTTLC;
    } else {
      rtb_Switch_h = rtb_Divide_l;
    }

    /* End of Switch: '<S366>/Switch' */

    /* Switch: '<S366>/Switch2' incorporates:
     *  RelationalOperator: '<S366>/LowerRelop1'
     */
    if (rtb_Divide_l > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_b = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_b = rtb_Switch_h;
    }

    /* End of Switch: '<S366>/Switch2' */

    /* Switch: '<S359>/Switch3' incorporates:
     *  Gain: '<S359>/Gain1'
     *  RelationalOperator: '<S361>/Relational Operator2'
     */
    if (rtb_Merge1_c >= 0.0F) {
      /* Switch: '<S359>/Switch2' incorporates:
       *  Constant: '<S359>/Constant2'
       *  DataTypeConversion: '<S359>/Cast To Single'
       *  RelationalOperator: '<S360>/Relational Operator2'
       */
      if (rtb_Merge1_c > 0.0F) {
        rtb_Rrg_Q = (uint8)((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <= rtb_Switch2_nd) ?
                            1 : 0);
      } else {
        rtb_Rrg_Q = ((uint8)0U);
      }

      /* End of Switch: '<S359>/Switch2' */
    } else {
      rtb_Rrg_Q = (uint8)((((uint32)((rtb_TTLC_o <= rtb_Switch2_b) ? 1 : 0)) *
                           ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S359>/Switch3' */

    /* If: '<S344>/If' incorporates:
     *  Constant: '<S348>/Constant'
     *  Constant: '<S350>/Constant'
     *  Constant: '<S351>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
           2)) && (((sint32)rtb_Rrg_Q) == 1)) && (((sint32)rtb_L0_Q) == 1)) {
      /* Outputs for IfAction SubSystem: '<S344>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S350>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S344>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)
        LKAS_DW.LKA_Mode_k) == 2)) && (((sint32)rtb_Rrg_Q) == 2)) && (((sint32)
                 rtb_L0_Q) == 1)) {
      /* Outputs for IfAction SubSystem: '<S344>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S351>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S344>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S344>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S348>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S344>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S344>/If' */

    /* Memory: '<S394>/Memory' */
    rtb_Memory_g = LKAS_DW.Memory_PreviousInput_c;

    /* If: '<S394>/If' */
    if ((rtb_Abs_f >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_d >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S394>/Ph1SWA' incorporates:
       *  ActionPort: '<S398>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S394>/Ph1SWA' */
    } else if ((rtb_Abs_f <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_d <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S394>/Ph2SWA' incorporates:
       *  ActionPort: '<S399>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S394>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S394>/Ph3SWA' incorporates:
       *  ActionPort: '<S400>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_g, &rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S394>/Ph3SWA' */
    }

    /* End of If: '<S394>/If' */

    /* Product: '<S390>/Divide2' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LKA_Veh2CamL_C *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S390>/Divide3' */
    rtb_LL_LKA_EnableLine_Max = rtb_LKA_Veh2CamL_C *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S396>/Divide' */
    rtb_Divide_hq = rtb_LL_LKA_EnableLine_Max * rtb_TTLC_f;

    /* Product: '<S390>/Divide1' */
    rtb_LftTTLC = rtb_LKA_Veh2CamL_C * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S402>/Switch' incorporates:
     *  RelationalOperator: '<S402>/UpperRelop'
     */
    if (rtb_Divide_hq < rtb_LftTTLC) {
      rtb_Switch_jy = rtb_LftTTLC;
    } else {
      rtb_Switch_jy = rtb_Divide_hq;
    }

    /* End of Switch: '<S402>/Switch' */

    /* Switch: '<S402>/Switch2' incorporates:
     *  RelationalOperator: '<S402>/LowerRelop1'
     */
    if (rtb_Divide_hq > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_pe = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_pe = rtb_Switch_jy;
    }

    /* End of Switch: '<S402>/Switch2' */

    /* Product: '<S397>/Divide' */
    rtb_Divide_e = rtb_LL_LKA_EnableLine_Max * rtb_LogicalOperator3_c_tmp_2;

    /* Switch: '<S403>/Switch' incorporates:
     *  RelationalOperator: '<S403>/UpperRelop'
     */
    if (rtb_Divide_e < rtb_LftTTLC) {
      rtb_Switch_b = rtb_LftTTLC;
    } else {
      rtb_Switch_b = rtb_Divide_e;
    }

    /* End of Switch: '<S403>/Switch' */

    /* Switch: '<S403>/Switch2' incorporates:
     *  RelationalOperator: '<S403>/LowerRelop1'
     */
    if (rtb_Divide_e > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_e = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_e = rtb_Switch_b;
    }

    /* End of Switch: '<S403>/Switch2' */

    /* Switch: '<S395>/Switch3' incorporates:
     *  Gain: '<S395>/Gain1'
     *  RelationalOperator: '<S397>/Relational Operator2'
     */
    if (rtb_Merge1_d >= 0.0F) {
      /* Switch: '<S395>/Switch2' incorporates:
       *  Constant: '<S395>/Constant2'
       *  DataTypeConversion: '<S395>/Cast To Single'
       *  RelationalOperator: '<S396>/Relational Operator2'
       */
      if (rtb_Merge1_d > 0.0F) {
        rtb_L0_Q = (uint8)((x20 <= rtb_Switch2_pe) ? 1 : 0);
      } else {
        rtb_L0_Q = ((uint8)0U);
      }

      /* End of Switch: '<S395>/Switch2' */
    } else {
      rtb_L0_Q = (uint8)((((uint32)((rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_e) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S395>/Switch3' */

    /* Outputs for Enabled SubSystem: '<S395>/Sum Condition' incorporates:
     *  EnablePort: '<S401>/Enable'
     */
    if (((sint32)rtb_L0_Q) > 0) {
      if (!LKAS_DW.SumCondition_MODE) {
        /* InitializeConditions for Memory: '<S401>/Memory' */
        LKAS_DW.Memory_PreviousInput_au = 0.0F;
        LKAS_DW.SumCondition_MODE = true;
      }

      /* Sum: '<S401>/Add1' incorporates:
       *  Memory: '<S401>/Memory'
       */
      rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_au;

      /* Saturate: '<S401>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 5.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 5.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S401>/Saturation' */

      /* RelationalOperator: '<S401>/Relational Operator' incorporates:
       *  Constant: '<S395>/Constant'
       */
      LKAS_DW.RelationalOperator_c = (rtb_LL_LDW_LatestWarnLine_C <= 2.0F);

      /* Update for Memory: '<S401>/Memory' */
      LKAS_DW.Memory_PreviousInput_au = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S401>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S395>/Sum Condition' */

    /* If: '<S382>/If' incorporates:
     *  Constant: '<S386>/Constant'
     *  Constant: '<S388>/Constant'
     *  DataTypeConversion: '<S395>/Cast To Single3'
     *  DataTypeConversion: '<S395>/Cast To Single4'
     *  Product: '<S395>/Divide'
     */
    if (((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
          2)) && (((sint32)((uint32)(((uint32)rtb_L0_Q) *
            (LKAS_DW.RelationalOperator_c ? 1U : 0U)))) == 0)) {
      /* Outputs for IfAction SubSystem: '<S382>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S388>/Action Port'
       */
      LKAS_DW.LKA_Fault = true;

      /* End of Outputs for SubSystem: '<S382>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S382>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S386>/Action Port'
       */
      LKAS_DW.LKA_Fault = false;

      /* End of Outputs for SubSystem: '<S382>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S382>/If' */

    /* Logic: '<S343>/Logical Operator2' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  DataTypeConversion: '<S54>/Extract Desired Bits'
     */
    rtb_LL_SingleLane_Disable_Swt = (rtb_R0_C3 != 0.0F);

    /* Logic: '<S343>/Logical Operator1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  DataTypeConversion: '<S15>/Extract Desired Bits'
     *  DataTypeConversion: '<S46>/Extract Desired Bits'
     */
    rtb_BCM_Right_Light = ((rtb_L0_C0_g != 0.0F) || (rtb_R0_C3 != 0.0F));

    /* Logic: '<S343>/Logical Operator10' */
    LKAS_DW.LDW_Fault = (rtb_LL_SingleLane_Disable_Swt || rtb_BCM_Right_Light);

    /* Chart: '<S143>/LDW_State_Machine'
     *
     * Block description for '<S143>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* Sum: '<S601>/Add' incorporates:
     *  Memory: '<S601>/Memory'
     */
    rtb_LftTTLC = LKAS_DW.Memory_PreviousInput_ce + rtb_LKA_SampleTime;

    /* Saturate: '<S601>/Saturation' */
    if (rtb_LftTTLC > 11.0F) {
      rtb_Saturation_j = 11.0F;
    } else if (rtb_LftTTLC < 0.0F) {
      rtb_Saturation_j = 0.0F;
    } else {
      rtb_Saturation_j = rtb_LftTTLC;
    }

    /* End of Saturate: '<S601>/Saturation' */

    /* Logic: '<S343>/Logical Operator8' incorporates:
     *  Constant: '<S600>/Constant'
     *  Constant: '<S601>/Constant1'
     *  Logic: '<S343>/AND'
     *  RelationalOperator: '<S600>/Compare'
     *  RelationalOperator: '<S601>/Relational Operator'
     */
    LKAS_DW.LKA_Fault = ((rtb_LL_SingleLane_Disable_Swt || rtb_BCM_Right_Light) ||
                         ((rtb_FDMMve_d_LkaFcnConf == ((uint8)4U)) &&
                          (rtb_Saturation_j >= ((float32)((uint16)5U)))));

    /* Chart: '<S143>/LKA_State_Machine'
     *
     * Block description for '<S143>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S320>/Subsystem' incorporates:
     *  EnablePort: '<S324>/Enable'
     */
    /* Logic: '<S320>/Logical Operator3' incorporates:
     *  Abs: '<S320>/Abs4'
     *  Abs: '<S320>/Abs5'
     *  Abs: '<S320>/Abs6'
     *  Abs: '<S320>/Abs7'
     *  Constant: '<S320>/Constant'
     *  Constant: '<S320>/Constant1'
     *  Constant: '<S320>/Constant4'
     *  Constant: '<S320>/Constant5'
     *  Constant: '<S322>/Constant'
     *  Constant: '<S323>/Constant'
     *  Logic: '<S320>/Logical Operator'
     *  Logic: '<S320>/Logical Operator1'
     *  Logic: '<S320>/Logical Operator4'
     *  RelationalOperator: '<S320>/Relational Operator'
     *  RelationalOperator: '<S320>/Relational Operator1'
     *  RelationalOperator: '<S320>/Relational Operator2'
     *  RelationalOperator: '<S320>/Relational Operator3'
     *  RelationalOperator: '<S320>/Relational Operator6'
     *  RelationalOperator: '<S320>/Relational Operator7'
     *  RelationalOperator: '<S322>/Compare'
     *  RelationalOperator: '<S323>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_c) <= 0.008F) && (fabsf(rtb_L0_C1_h5) <= 0.008F)) &&
           ((fabsf(rtb_L0_C2_f) <= 0.0001F) && (fabsf(rtb_R0_C2_b) <= 0.0001F)))
          && ((rtb_IMAPve_d_LKA_Mode == ((uint8)3U)) && (rtb_R0_Q_c == ((uint8)
             3U)))) && (rtb_ESC_VehSpd >= 35.0F)) && (x1 <= 4.0F)) {
      if (!LKAS_DW.Subsystem_MODE_p) {
        /* InitializeConditions for Memory: '<S324>/Memory' */
        LKAS_DW.Memory_PreviousInput_oih = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_p = true;
      }

      /* Sum: '<S324>/Add1' incorporates:
       *  Memory: '<S324>/Memory'
       */
      rtb_Saturation_a = (uint16)(1U + ((uint32)LKAS_DW.Memory_PreviousInput_oih));

      /* Saturate: '<S324>/Saturation' */
      if (rtb_Saturation_a >= ((uint16)3000U)) {
        rtb_Saturation_a = ((uint16)3000U);
      }

      /* End of Saturate: '<S324>/Saturation' */

      /* RelationalOperator: '<S324>/Relational Operator' incorporates:
       *  Constant: '<S320>/Constant3'
       *  DataTypeConversion: '<S324>/Cast To Single1'
       *  Product: '<S320>/Divide'
       */
      LKAS_DW.RelationalOperator_gd = (rtb_Saturation_a >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S324>/Memory' */
      LKAS_DW.Memory_PreviousInput_oih = rtb_Saturation_a;
    } else {
      if (LKAS_DW.Subsystem_MODE_p) {
        /* Disable for Outport: '<S324>/Out' */
        LKAS_DW.RelationalOperator_gd = false;
        LKAS_DW.Subsystem_MODE_p = false;
      }
    }

    /* End of Logic: '<S320>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S320>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S294>/Subsystem' incorporates:
     *  EnablePort: '<S319>/Enable'
     */
    if (LKAS_DW.RelationalOperator_gd) {
      /* Sum: '<S321>/Add2' incorporates:
       *  Constant: '<S321>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S321>/Memory3'
       */
      rtb_LL_LDW_LatestWarnLine_C = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S321>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 50.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 50.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S321>/Saturation' */

      /* Switch: '<S321>/Switch' incorporates:
       *  Constant: '<S319>/Constant'
       *  Product: '<S321>/Divide'
       *  Product: '<S321>/Divide1'
       *  Sum: '<S321>/Add'
       *  Sum: '<S321>/Add1'
       *  UnitDelay: '<S321>/Unit Delay'
       */
      if (rtb_LL_LDW_LatestWarnLine_C > 1.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_SW_Angle - LKAS_DW.UnitDelay_DSTATE)) + LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_SW_Angle;
      }

      /* End of Switch: '<S321>/Switch' */

      /* Saturate: '<S319>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 3.0F) {
        LKAS_DW.Saturation_a = 3.0F;
      } else if (rtb_LL_ThresDet_lDvtThresLwrLDW < (-3.0F)) {
        LKAS_DW.Saturation_a = (-3.0F);
      } else {
        LKAS_DW.Saturation_a = rtb_LL_ThresDet_lDvtThresLwrLDW;
      }

      /* End of Saturate: '<S319>/Saturation' */

      /* Update for UnitDelay: '<S321>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Update for Memory: '<S321>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Outputs for SubSystem: '<S294>/Subsystem' */

    /* Saturate: '<S296>/Saturation' */
    if (rtb_ESC_VehSpd > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else if (rtb_ESC_VehSpd < 0.001F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.001F;
    } else {
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ESC_VehSpd;
    }

    /* End of Saturate: '<S296>/Saturation' */

    /* Gain: '<S332>/kph To mps' incorporates:
     *  Gain: '<S333>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = 0.277777791F *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S332>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S334>:1' */
    /* '<S334>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 60.0F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_LL_ThresDet_lDvtThresUprLKA;
    }

    /* End of Saturate: '<S332>/Saturation3' */

    /* Product: '<S332>/Divide1' incorporates:
     *  Constant: '<S332>/Constant'
     */
    rtb_LftTTLC = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S332>/Saturation1' */
    if (rtb_LftTTLC > 0.0117F) {
      rtb_LftTTLC = 0.0117F;
    } else {
      if (rtb_LftTTLC < 0.00237F) {
        rtb_LftTTLC = 0.00237F;
      }
    }

    /* End of Saturate: '<S332>/Saturation1' */

    /* Switch: '<S664>/Switch7' incorporates:
     *  Constant: '<S664>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_d != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_d;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S664>/Switch7' */

    /* MATLAB Function: '<S332>/MATLAB Function' incorporates:
     *  Gain: '<S332>/kph To mps'
     */
    rtb_LL_LDW_LatestWarnLine_C = ((((((((rtb_LftTTLC *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_d) * LKAS_DW.LKA_WhlBaseL_C_j) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S333>/Saturation3' */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 60.0F;
      }
    }

    /* End of Saturate: '<S333>/Saturation3' */

    /* Product: '<S333>/Divide1' incorporates:
     *  Constant: '<S333>/Constant'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = 0.09F / rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S333>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S335>:1' */
    /* '<S335>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 0.0117F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.0117F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 0.00237F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 0.00237F;
      }
    }

    /* End of Saturate: '<S333>/Saturation1' */

    /* Switch: '<S664>/Switch4' incorporates:
     *  Constant: '<S664>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_k != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_k;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S664>/Switch4' */

    /* MATLAB Function: '<S333>/MATLAB Function' */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_d) * LKAS_DW.LKA_WhlBaseL_C_j) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Gain: '<S291>/Gain1' incorporates:
     *  Sum: '<S291>/Add1'
     */
    rtb_LL_ThresDet_lDvtThresUprLDW = (rtb_Add_a + rtb_Add_l) * 0.5F;

    /* Switch: '<S293>/Switch' incorporates:
     *  Constant: '<S309>/Constant'
     *  RelationalOperator: '<S309>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_LftTTLC = rtb_LFTTTLC;
    } else {
      rtb_LftTTLC = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S293>/Switch' */

    /* Saturate: '<S293>/Saturation' */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else {
      if (rtb_LftTTLC < 0.5F) {
        rtb_LftTTLC = 0.5F;
      }
    }

    /* End of Saturate: '<S293>/Saturation' */

    /* Product: '<S317>/Divide' */
    rtb_Divide_d = rtb_Abs_d_tmp * rtb_LftTTLC;

    /* Switch: '<S293>/Switch1' incorporates:
     *  Constant: '<S310>/Constant'
     *  RelationalOperator: '<S310>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S293>/Switch1' */

    /* Saturate: '<S293>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S293>/Saturation1' */

    /* Product: '<S318>/Divide' */
    rtb_Divide_k = rtb_Abs_d_tmp * rtb_LL_HdAgPrvwT_C;

    /* Gain: '<S293>/Gain1' incorporates:
     *  Sum: '<S293>/Add1'
     */
    rtb_LL_HdAgPrvwT_C = (rtb_Divide_d + rtb_Divide_k) * 0.5F;

    /* Switch: '<S664>/Switch8' incorporates:
     *  Constant: '<S664>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_g != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_g;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S664>/Switch8' */

    /* Product: '<S308>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_Abs_d_tmp * x10;

    /* Product: '<S306>/Z*Z' incorporates:
     *  Product: '<S307>/Z*Z'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Sum: '<S306>/Add' incorporates:
     *  Product: '<S306>/Product'
     *  Product: '<S306>/Product3'
     *  Product: '<S306>/Product4'
     *  Product: '<S306>/Z*Z'
     *  Product: '<S306>/Z*Z*Z'
     */
    rtb_Add_ny = (((rtb_L0_C1_c * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_L0_C0_c)
                  + (rtb_L0_C2_f * rtb_LL_ThresDet_tiTTLCThresLDW)) +
      ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_ThresDet_tiTTLCThresLDW) *
       rtb_L0_C3_i);

    /* Sum: '<S307>/Add' incorporates:
     *  Product: '<S307>/Product'
     *  Product: '<S307>/Product3'
     *  Product: '<S307>/Product4'
     *  Product: '<S307>/Z*Z*Z'
     */
    rtb_Add_cg = (((rtb_L0_C1_h5 * rtb_LL_ThresDet_lDvtThresUprLKA) +
                   rtb_R0_C0_j) + (rtb_R0_C2_b * rtb_LL_ThresDet_tiTTLCThresLDW))
      + ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_ThresDet_tiTTLCThresLDW) *
         rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S170>/Memory' */
        LKAS_DW.Memory_PreviousInput_oi = 0.0F;

        /* InitializeConditions for Memory: '<S201>/Memory' */
        LKAS_DW.Memory_PreviousInput_od = ((uint16)0U);

        /* InitializeConditions for Memory: '<S188>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_p = ((uint8)0U);

        /* InitializeConditions for Memory: '<S200>/Memory' */
        LKAS_DW.Memory_PreviousInput_nn = ((uint16)0U);

        /* InitializeConditions for Memory: '<S202>/Memory' */
        LKAS_DW.Memory_PreviousInput_nt = ((uint16)0U);

        /* InitializeConditions for Memory: '<S197>/Memory' */
        LKAS_DW.Memory_PreviousInput_o5 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S185>/Memory' */
        LKAS_DW.Memory_PreviousInput_mm = 0.0F;

        /* InitializeConditions for Memory: '<S171>/Memory' */
        LKAS_DW.Memory_PreviousInput_fx = 0.0F;

        /* InitializeConditions for Memory: '<S172>/Memory' */
        LKAS_DW.Memory_PreviousInput_i = 0.0F;

        /* InitializeConditions for UnitDelay: '<S174>/Delay Input1'
         *
         * Block description for '<S174>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_d = false;

        /* InitializeConditions for Memory: '<S172>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_l = false;

        /* InitializeConditions for Memory: '<S163>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_m = 0.0F;

        /* InitializeConditions for Memory: '<S264>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_k = 0.0F;

        /* InitializeConditions for Memory: '<S247>/Memory' */
        LKAS_DW.Memory_PreviousInput_mk = 0.0F;

        /* InitializeConditions for UnitDelay: '<S245>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_i = 0.0F;

        /* InitializeConditions for Memory: '<S253>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_m1 = 0.0F;

        /* InitializeConditions for Memory: '<S259>/Memory' */
        LKAS_DW.Memory_PreviousInput_nv = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S263>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_m = 0.0F;

        /* InitializeConditions for Memory: '<S263>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_k4 = 0.0F;

        /* InitializeConditions for UnitDelay: '<S240>/Delay Input2'
         *
         * Block description for '<S240>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_m = 0.0F;

        /* InitializeConditions for Memory: '<S240>/Memory' */
        LKAS_DW.Memory_PreviousInput_no = ((uint16)0U);

        /* InitializeConditions for Memory: '<S196>/Memory' */
        LKAS_DW.Memory_PreviousInput_n2 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S198>/Memory' */
        LKAS_DW.Memory_PreviousInput_g = ((uint16)0U);

        /* InitializeConditions for Memory: '<S199>/Memory' */
        LKAS_DW.Memory_PreviousInput_p = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S158>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S158>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S172>/Moving Standard Deviation1' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S172>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S172>/Moving Standard Deviation2' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation2_i);

        /* End of SystemReset for SubSystem: '<S172>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Memory: '<S170>/Memory' */
      rtb_Divide3_b = LKAS_DW.Memory_PreviousInput_oi;

      /* Sum: '<S170>/Add2' */
      rtb_Divide3_b += rtb_LKA_SampleTime;

      /* Saturate: '<S170>/Saturation2' */
      if (rtb_Divide3_b > 20.0F) {
        rtb_Saturation2_l = 20.0F;
      } else if (rtb_Divide3_b < 0.0F) {
        rtb_Saturation2_l = 0.0F;
      } else {
        rtb_Saturation2_l = rtb_Divide3_b;
      }

      /* End of Saturate: '<S170>/Saturation2' */

      /* Abs: '<S170>/Abs' */
      rtb_Divide3_b = rtb_TLft;

      /* Saturate: '<S170>/Saturation' */
      if (rtb_Divide3_b > 0.004F) {
        rtb_Divide3_b = 0.004F;
      } else {
        if (rtb_Divide3_b < 0.0F) {
          rtb_Divide3_b = 0.0F;
        }
      }

      /* End of Saturate: '<S170>/Saturation' */

      /* RelationalOperator: '<S170>/Relational Operator4' incorporates:
       *  Constant: '<S170>/Constant'
       *  Constant: '<S170>/Constant1'
       *  Product: '<S170>/Divide'
       *  Sum: '<S170>/Add'
       */
      rtb_BCM_Right_Light = (rtb_Saturation2_l >=
        ((((rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F) * rtb_Divide3_b) / 0.004F) +
         rtb_LL_LKAExPrcs_tiExitTime1));

      /* Abs: '<S171>/Abs' */
      rtb_Divide3_b = rtb_TLft;

      /* Saturate: '<S171>/Saturation' */
      if (rtb_Divide3_b > 0.004F) {
        rtb_Divide3_b = 0.004F;
      } else {
        if (rtb_Divide3_b < 0.0F) {
          rtb_Divide3_b = 0.0F;
        }
      }

      /* End of Saturate: '<S171>/Saturation' */

      /* Product: '<S171>/Divide' incorporates:
       *  Constant: '<S171>/Constant'
       *  Constant: '<S171>/Constant1'
       */
      rtb_LL_ThresDet_tiTTLCThresLDW = ((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) *
        rtb_Divide3_b) / 0.004F;

      /* Sum: '<S201>/Add' incorporates:
       *  Constant: '<S201>/Constant'
       *  Memory: '<S201>/Memory'
       */
      rtb_Saturation_a = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_od));

      /* Saturate: '<S201>/Saturation1' */
      if (rtb_Saturation_a < ((uint16)10000U)) {
        rtb_Saturation1_l = rtb_Saturation_a;
      } else {
        rtb_Saturation1_l = ((uint16)10000U);
      }

      /* End of Saturate: '<S201>/Saturation1' */

      /* Gain: '<S246>/kph to mps' */
      rtb_Divide3_b = rtb_Abs_d_tmp;

      /* Saturate: '<S246>/Saturation3' */
      if (rtb_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_ESC_VehSpd;
      }

      /* End of Saturate: '<S246>/Saturation3' */

      /* Product: '<S246>/Divide2' incorporates:
       *  Constant: '<S246>/Constant'
       */
      rtb_LftTTLC = 0.09F / x10;

      /* Switch: '<S664>/Switch36' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_a != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_a;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S664>/Switch36' */

      /* Saturate: '<S246>/Saturation1' */
      if (rtb_LftTTLC > 0.01F) {
        rtb_LftTTLC = 0.01F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S246>/Saturation1' */

      /* Gain: '<S246>/Gain2' incorporates:
       *  Constant: '<S246>/Constant1'
       *  Gain: '<S246>/rad to deg'
       *  Gain: '<S291>/Gain1'
       *  Math: '<S246>/Math Function'
       *  Product: '<S246>/Divide'
       *  Product: '<S246>/Divide1'
       *  Product: '<S246>/Product'
       *  Product: '<S246>/Product1'
       *  Product: '<S246>/Product2'
       *  Product: '<S246>/Product3'
       *  Sum: '<S246>/Add'
       *
       * About '<S246>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = (((((((rtb_Divide3_b * rtb_Divide3_b) *
        rtb_LftTTLC) + 1.0F) / (rtb_Divide3_b / LKAS_DW.LKA_WhlBaseL_C_j)) *
        ((rtb_Divide3_b * rtb_LL_ThresDet_lDvtThresUprLDW) * 57.2957802F)) * x10)
        * LKAS_DW.LKA_StrRatio_C_d) * (-1.0F);

      /* Sum: '<S184>/Add1' */
      rtb_Add1_cj = (rtb_SW_Angle - rtb_LL_LKAExPrcs_tiExitTime1) -
        LKAS_DW.Saturation_a;

      /* If: '<S201>/If' incorporates:
       *  Constant: '<S201>/Constant2'
       */
      if (rtb_Saturation1_l == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S201>/if action ' incorporates:
         *  ActionPort: '<S224>/Action Port'
         */
        LKAS_ifaction(rtb_Add1_cj, &LKAS_DW.In_p);

        /* End of Outputs for SubSystem: '<S201>/if action ' */
      }

      /* End of If: '<S201>/If' */

      /* Sum: '<S188>/Add' incorporates:
       *  Constant: '<S188>/Constant'
       *  Memory: '<S188>/Memory1'
       */
      rtb_L0_Q = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_p));

      /* Saturate: '<S188>/Saturation1' */
      if (rtb_L0_Q < ((uint8)5U)) {
        rtb_Saturation1_k = rtb_L0_Q;
      } else {
        rtb_Saturation1_k = ((uint8)5U);
      }

      /* End of Saturate: '<S188>/Saturation1' */

      /* Saturate: '<S184>/Saturation3' */
      if (rtb_ESC_VehSpd > 150.0F) {
        rtb_Divide3_b = 150.0F;
      } else if (rtb_ESC_VehSpd < 60.0F) {
        rtb_Divide3_b = 60.0F;
      } else {
        rtb_Divide3_b = rtb_ESC_VehSpd;
      }

      /* End of Saturate: '<S184>/Saturation3' */

      /* Product: '<S184>/Divide1' incorporates:
       *  Constant: '<S184>/Constant'
       */
      rtb_Divide3_b = 0.09F / rtb_Divide3_b;

      /* Saturate: '<S184>/Saturation1' */
      if (rtb_Divide3_b > 0.0117F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.0117F;
      } else if (rtb_Divide3_b < 0.00237F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.MPInP_StbFacm_SY = rtb_Divide3_b;
      }

      /* End of Saturate: '<S184>/Saturation1' */

      /* Gain: '<S184>/Gain' */
      LKAS_DW.MPInP_dphiSWARMax = 1.0F * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S200>/Add' incorporates:
       *  Constant: '<S200>/Constant'
       *  Memory: '<S200>/Memory'
       */
      rtb_Saturation_a = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_nn));

      /* Saturate: '<S200>/Saturation1' */
      if (rtb_Saturation_a < ((uint16)10000U)) {
        rtb_Saturation1_p = rtb_Saturation_a;
      } else {
        rtb_Saturation1_p = ((uint16)10000U);
      }

      /* End of Saturate: '<S200>/Saturation1' */

      /* If: '<S191>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S191>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S205>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_LFTTTLC, &rtb_Merge_o);

        /* End of Outputs for SubSystem: '<S191>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S191>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S204>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_RGTTTLC, &rtb_Merge_o);

        /* End of Outputs for SubSystem: '<S191>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S191>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S206>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_o);

        /* End of Outputs for SubSystem: '<S191>/If Action Subsystem3' */
      }

      /* End of If: '<S191>/If' */

      /* If: '<S200>/If' incorporates:
       *  Constant: '<S200>/Constant2'
       */
      if (rtb_Saturation1_p == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S200>/if action ' incorporates:
         *  ActionPort: '<S223>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_o, &LKAS_DW.In_g);

        /* End of Outputs for SubSystem: '<S200>/if action ' */
      }

      /* End of If: '<S200>/If' */

      /* Saturate: '<S184>/Saturation2' */
      if (LKAS_DW.In_g > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_g < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_g;
      }

      /* End of Saturate: '<S184>/Saturation2' */

      /* Sum: '<S202>/Add' incorporates:
       *  Constant: '<S202>/Constant'
       *  Memory: '<S202>/Memory'
       */
      rtb_Saturation_a = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_nt));

      /* Saturate: '<S202>/Saturation1' */
      if (rtb_Saturation_a < ((uint16)10000U)) {
        rtb_Saturation1_pr = rtb_Saturation_a;
      } else {
        rtb_Saturation1_pr = ((uint16)10000U);
      }

      /* End of Saturate: '<S202>/Saturation1' */

      /* If: '<S202>/If' incorporates:
       *  Constant: '<S202>/Constant2'
       */
      if (rtb_Saturation1_pr == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S202>/if action ' incorporates:
         *  ActionPort: '<S225>/Action Port'
         */
        LKAS_ifaction(rtb_ESC_VehSpd, &LKAS_DW.In_m);

        /* End of Outputs for SubSystem: '<S202>/if action ' */
      }

      /* End of If: '<S202>/If' */

      /* Sum: '<S197>/Add' incorporates:
       *  Constant: '<S197>/Constant'
       *  Memory: '<S197>/Memory'
       */
      rtb_Saturation_a = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_o5));

      /* Saturate: '<S197>/Saturation1' */
      if (rtb_Saturation_a < ((uint16)10000U)) {
        rtb_Saturation1_b = rtb_Saturation_a;
      } else {
        rtb_Saturation1_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S197>/Saturation1' */

      /* Product: '<S315>/Z*Z' incorporates:
       *  Product: '<S312>/Z*Z'
       */
      rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_Divide_d * rtb_Divide_d;

      /* Gain: '<S315>/Gain1' incorporates:
       *  Gain: '<S314>/Gain1'
       *  Gain: '<S316>/Gain1'
       */
      rtb_L0_C3_i *= 3.0F;

      /* Gain: '<S312>/Gain1' incorporates:
       *  Gain: '<S311>/Gain1'
       *  Gain: '<S313>/Gain1'
       */
      rtb_L0_C3 *= 3.0F;

      /* Gain: '<S192>/Gain' incorporates:
       *  Gain: '<S312>/Gain1'
       *  Gain: '<S315>/Gain1'
       *  Product: '<S312>/Product3'
       *  Product: '<S312>/Product4'
       *  Product: '<S315>/Product3'
       *  Product: '<S315>/Product4'
       *  Product: '<S315>/Z*Z'
       *  Sum: '<S192>/Add'
       *  Sum: '<S312>/Add'
       *  Sum: '<S315>/Add'
       */
      rtb_Gain_c = ((((rtb_Add_a_tmp * rtb_Divide_d) + rtb_L0_C1_c) +
                     (rtb_L0_C3_i * rtb_LL_DvtSpdDet_vDvtSpdMin_C)) +
                    (((rtb_Add_l_tmp * rtb_Divide_d) + rtb_L0_C1_h5) +
                     (rtb_L0_C3 * rtb_LL_DvtSpdDet_vDvtSpdMin_C))) * 0.5F;

      /* Product: '<S316>/Z*Z' incorporates:
       *  Product: '<S313>/Z*Z'
       */
      rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_Divide_k * rtb_Divide_k;

      /* Gain: '<S192>/Gain1' incorporates:
       *  Product: '<S313>/Product3'
       *  Product: '<S313>/Product4'
       *  Product: '<S316>/Product3'
       *  Product: '<S316>/Product4'
       *  Product: '<S316>/Z*Z'
       *  Sum: '<S192>/Add1'
       *  Sum: '<S313>/Add'
       *  Sum: '<S316>/Add'
       */
      rtb_Gain1_c = ((((rtb_Add_a_tmp * rtb_Divide_k) + rtb_L0_C1_c) +
                      (rtb_L0_C3_i * rtb_LL_DvtSpdDet_vDvtSpdMin_C)) +
                     (((rtb_Add_l_tmp * rtb_Divide_k) + rtb_L0_C1_h5) +
                      (rtb_L0_C3 * rtb_LL_DvtSpdDet_vDvtSpdMin_C))) * 0.5F;

      /* If: '<S192>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S192>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S208>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_Gain_c, &rtb_Divide3_b);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S192>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S207>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_Gain1_c, &rtb_Divide3_b);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S192>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S209>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Divide3_b);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem3' */
      }

      /* End of If: '<S192>/If' */

      /* If: '<S194>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S194>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S214>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_Divide_d, &rtb_Gain2_k);

        /* End of Outputs for SubSystem: '<S194>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S194>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S213>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_Divide_k, &rtb_Gain2_k);

        /* End of Outputs for SubSystem: '<S194>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S194>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S215>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Gain2_k);

        /* End of Outputs for SubSystem: '<S194>/If Action Subsystem3' */
      }

      /* End of If: '<S194>/If' */

      /* Sum: '<S184>/Add' incorporates:
       *  Gain: '<S291>/Gain1'
       *  Product: '<S184>/Divide2'
       */
      rtb_Add_hu = rtb_Divide3_b - (rtb_LL_ThresDet_lDvtThresUprLDW *
        rtb_Gain2_k);

      /* If: '<S197>/If' incorporates:
       *  Constant: '<S197>/Constant2'
       */
      if (rtb_Saturation1_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S197>/if action ' incorporates:
         *  ActionPort: '<S220>/Action Port'
         */
        LKAS_ifaction(rtb_Add_hu, &LKAS_DW.In_ly);

        /* End of Outputs for SubSystem: '<S197>/if action ' */
      }

      /* End of If: '<S197>/If' */

      /* If: '<S203>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S203>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S227>/Action Port'
         */
        /* SignalConversion: '<S227>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S227>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S203>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S203>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S226>/Action Port'
         */
        /* SignalConversion: '<S226>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S226>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S203>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S203>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S228>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S203>/If Action Subsystem3' */
      }

      /* End of If: '<S203>/If' */

      /* If: '<S188>/If' incorporates:
       *  Constant: '<S188>/Constant19'
       */
      rtAction = -1;
      if (rtb_Saturation1_k == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        /* Outputs for IfAction SubSystem: '<S152>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S183>/Action Port'
         *
         * Block description for '<S152>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S152>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S188>/If' */

      /* Memory: '<S185>/Memory' */
      rtb_Gain2_k = LKAS_DW.Memory_PreviousInput_mm;

      /* Sum: '<S185>/Add' incorporates:
       *  Gain: '<S185>/Gain1'
       *  Product: '<S185>/Divide'
       *  Product: '<S185>/Product'
       */
      rtb_Add_lk = ((rtb_Abs_d_tmp * rtb_LKA_SampleTime) / (0.277777791F *
        LKAS_DW.In_m)) + rtb_Gain2_k;

      /* MATLAB Function: '<S186>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S229>:1' */
      /* '<S229>:1:19' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S229>:1:20' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S229>:1:21' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S229>:1:22' Delte2PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S229>:1:23' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S229>:1:24' NomT = SWACmd_tiNomT; */
      /* '<S229>:1:25' T1 = K1K2Det_T1; */
      /* '<S229>:1:26' T2 = T1; */
      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S229>:1:34' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_lk < LKAS_DW.K1K2Det_T1) && (rtb_Add_lk >= 0.0F)) {
        /* '<S229>:1:35' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_lk) +
          LKAS_DW.In_p;
      } else if ((rtb_Add_lk <= LKAS_DW.K1K2Det_T1) && (rtb_Add_lk >=
                  LKAS_DW.K1K2Det_T1)) {
        /* '<S229>:1:36' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S229>:1:38' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
          LKAS_DW.K1K2Det_T1) + LKAS_DW.In_p;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_lk >= LKAS_DW.K1K2Det_T1) {
          /* '<S229>:1:40' elseif(NomT >= T2) */
          /* '<S229>:1:41' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
            LKAS_DW.K1K2Det_T1) + LKAS_DW.In_p;

          /*    DelteSWCmd = single(0); */
        }
      }

      /* Saturate: '<S152>/Saturation6' incorporates:
       *  MATLAB Function: '<S186>/SWACmd'
       */
      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S229>:1:47' SWACmd_phiSWACmd = DelteSWCmd; */
      if (LKAS_DW.K1K2Det_T1 > 2.0F) {
        rtb_Saturation6 = 2.0F;
      } else if (LKAS_DW.K1K2Det_T1 < 0.2F) {
        rtb_Saturation6 = 0.2F;
      } else {
        rtb_Saturation6 = LKAS_DW.K1K2Det_T1;
      }

      /* End of Saturate: '<S152>/Saturation6' */

      /* Memory: '<S171>/Memory' */
      rtb_Gain2_k = LKAS_DW.Memory_PreviousInput_fx;

      /* Sum: '<S171>/Add2' */
      rtb_Gain2_k += rtb_LKA_SampleTime;

      /* Saturate: '<S171>/Saturation2' */
      if (rtb_Gain2_k > 12.0F) {
        rtb_Saturation2_la = 12.0F;
      } else if (rtb_Gain2_k < 0.0F) {
        rtb_Saturation2_la = 0.0F;
      } else {
        rtb_Saturation2_la = rtb_Gain2_k;
      }

      /* End of Saturate: '<S171>/Saturation2' */

      /* Abs: '<S171>/Abs2' */
      rtb_Gain2_k = fabsf(rtb_Gain1);

      /* Sum: '<S171>/Add3' incorporates:
       *  Sum: '<S172>/Add'
       *  Sum: '<S231>/Add'
       *  Sum: '<S252>/Add6'
       */
      rtb_LKA_Veh2CamW_C -= rtb_LKA_CarWidth;

      /* Gain: '<S171>/Gain' incorporates:
       *  Sum: '<S171>/Add3'
       */
      rtb_Divide3_b = rtb_LKA_Veh2CamW_C * 0.166666672F;

      /* RelationalOperator: '<S171>/Relational Operator2' */
      rtb_LogicalOperator3_o = (rtb_Gain2_k >= rtb_Divide3_b);

      /* Abs: '<S171>/Abs3' */
      rtb_Gain2_k = fabsf(rtb_Add5_j);

      /* Outputs for Enabled SubSystem: '<S171>/Sum Condition1' incorporates:
       *  EnablePort: '<S173>/Enable'
       */
      /* Logic: '<S171>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S171>/Relational Operator3'
       *  RelationalOperator: '<S171>/Relational Operator4'
       */
      if (((rtb_Saturation2_la >= rtb_Saturation6) && rtb_LogicalOperator3_o) &&
          (rtb_Gain2_k >= rtb_Divide3_b)) {
        if (!LKAS_DW.SumCondition1_MODE_bk) {
          /* InitializeConditions for Memory: '<S173>/Memory' */
          LKAS_DW.Memory_PreviousInput_cs = 0.0F;
          LKAS_DW.SumCondition1_MODE_bk = true;
        }

        /* Sum: '<S173>/Add1' incorporates:
         *  Memory: '<S173>/Memory'
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_cs;

        /* Saturate: '<S173>/Saturation' */
        if (rtb_LL_DvtSpdDet_vDvtSpdMin_C > 10.0F) {
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = 10.0F;
        } else {
          if (rtb_LL_DvtSpdDet_vDvtSpdMin_C < 0.0F) {
            rtb_LL_DvtSpdDet_vDvtSpdMin_C = 0.0F;
          }
        }

        /* End of Saturate: '<S173>/Saturation' */

        /* RelationalOperator: '<S173>/Relational Operator' incorporates:
         *  Sum: '<S171>/Add1'
         */
        LKAS_DW.RelationalOperator_ce = (rtb_LL_DvtSpdDet_vDvtSpdMin_C >=
          (rtb_LL_LKAExPrcs_tiExitTime2 + rtb_LL_ThresDet_tiTTLCThresLDW));

        /* Update for Memory: '<S173>/Memory' */
        LKAS_DW.Memory_PreviousInput_cs = rtb_LL_DvtSpdDet_vDvtSpdMin_C;
      } else {
        if (LKAS_DW.SumCondition1_MODE_bk) {
          /* Disable for Outport: '<S173>/Out' */
          LKAS_DW.RelationalOperator_ce = false;
          LKAS_DW.SumCondition1_MODE_bk = false;
        }
      }

      /* End of Logic: '<S171>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S171>/Sum Condition1' */

      /* Memory: '<S172>/Memory' */
      rtb_Gain2_k = LKAS_DW.Memory_PreviousInput_i;

      /* Sum: '<S172>/Add2' */
      rtb_Gain2_k += rtb_LKA_SampleTime;

      /* Saturate: '<S172>/Saturation2' */
      if (rtb_Gain2_k > 10.0F) {
        rtb_Saturation2_d = 10.0F;
      } else if (rtb_Gain2_k < 0.0F) {
        rtb_Saturation2_d = 0.0F;
      } else {
        rtb_Saturation2_d = rtb_Gain2_k;
      }

      /* End of Saturate: '<S172>/Saturation2' */

      /* Gain: '<S172>/Gain' */
      rtb_Gain2_k = rtb_LKA_Veh2CamW_C * 0.333333343F;

      /* Logic: '<S172>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S172>/Relational Operator2'
       *  RelationalOperator: '<S172>/Relational Operator3'
       *  RelationalOperator: '<S172>/Relational Operator4'
       */
      rtb_LogicalOperator3_o = (((rtb_Saturation2_d >= rtb_Saturation6) &&
        (rtb_Gain1 >= rtb_Gain2_k)) && (rtb_Add5_j >= rtb_Gain2_k));

      /* Abs: '<S172>/Abs4' */
      rtb_Gain2_k = rtb_TLft;

      /* Saturate: '<S172>/Saturation' */
      if (rtb_Gain2_k > 0.004F) {
        rtb_Gain2_k = 0.004F;
      } else {
        if (rtb_Gain2_k < 0.0F) {
          rtb_Gain2_k = 0.0F;
        }
      }

      /* End of Saturate: '<S172>/Saturation' */

      /* Switch: '<S664>/Switch45' incorporates:
       *  Constant: '<S664>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S664>/Switch45' */

      /* Sum: '<S172>/Add6' incorporates:
       *  Constant: '<S172>/Constant'
       *  Constant: '<S172>/Constant7'
       *  Product: '<S172>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Gain2_k) / 0.004F) + x10;

      /* Outputs for Atomic SubSystem: '<S158>/Moving Standard Deviation2' */
      LKAS_MovingStandardDeviation2(rtb_IMAPve_g_EPS_SW_Trq, &rtb_kphTomps_p,
        &rtb_Merge_g1, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S158>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S172>/Moving Standard Deviation1' */
      rtb_Gain_pi = (float32) LKAS_MovingStandardDeviation1(rtb_Add5_j,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S172>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S172>/Relational Operator6' */
      rtb_RelationalOperator6_g = (rtb_Gain_pi <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S172>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_g, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_g0, &LKAS_DW.SumCondition1_n);

      /* End of Outputs for SubSystem: '<S172>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S172>/Moving Standard Deviation2' */
      rtb_Gain_pi = (float32) LKAS_MovingStandardDeviation1(rtb_Gain1,
        &LKAS_DW.MovingStandardDeviation2_i);

      /* End of Outputs for SubSystem: '<S172>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S172>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain_pi <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S172>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_ii, &LKAS_DW.SumCondition_o);

      /* End of Outputs for SubSystem: '<S172>/Sum Condition' */

      /* RelationalOperator: '<S182>/Compare' incorporates:
       *  Constant: '<S182>/Constant'
       *  Constant: '<S664>/LL_LKAExPrcs_ExitC0Swt=1'
       *  Logic: '<S172>/Logical Operator2'
       *  Switch: '<S664>/Switch46'
       */
      rtb_Compare_nye = (((sint32)((((rtb_LogicalOperator3_o &&
        (LKAS_DW.RelationalOperator_g0)) && (LKAS_DW.RelationalOperator_ii)) &&
        ((LKAS_ConstB.DataTypeConversion35) || (LL_LKAExPrcs_ExitC0Swt))) ? 1 :
        0)) > ((sint32)(false ? 1 : 0)));

      /* Memory: '<S172>/Memory1' */
      rtb_Memory1_c = LKAS_DW.Memory1_PreviousInput_l;

      /* If: '<S172>/If' incorporates:
       *  Constant: '<S175>/Constant'
       *  RelationalOperator: '<S174>/FixPt Relational Operator'
       *  UnitDelay: '<S174>/Delay Input1'
       *
       * Block description for '<S174>/Delay Input1':
       *
       *  Store in Global RAM
       */
      if (((sint32)(rtb_Compare_nye ? 1 : 0)) > ((sint32)
           (LKAS_DW.DelayInput1_DSTATE_d ? 1 : 0))) {
        /* Outputs for IfAction SubSystem: '<S172>/If Action Subsystem' incorporates:
         *  ActionPort: '<S175>/Action Port'
         */
        rtb_Merge_c = true;

        /* End of Outputs for SubSystem: '<S172>/If Action Subsystem' */
      } else {
        /* Outputs for IfAction SubSystem: '<S172>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S176>/Action Port'
         */
        LKAS_IfActionSubsystem3(rtb_Memory1_c, &rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S172>/If Action Subsystem3' */
      }

      /* End of If: '<S172>/If' */

      /* Outputs for Enabled SubSystem: '<S158>/Sum Condition2' incorporates:
       *  EnablePort: '<S162>/state = reset'
       */
      /* Outputs for Enabled SubSystem: '<S172>/Sum Condition2' incorporates:
       *  EnablePort: '<S181>/state = reset'
       */
      if (rtb_Merge_c) {
        if (!LKAS_DW.SumCondition2_MODE) {
          /* InitializeConditions for Memory: '<S181>/Memory' */
          LKAS_DW.Memory_PreviousInput_l = 0.0F;
          LKAS_DW.SumCondition2_MODE = true;
        }

        /* Sum: '<S181>/Add1' incorporates:
         *  Memory: '<S181>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_l;

        /* Saturate: '<S181>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S181>/Saturation' */

        /* RelationalOperator: '<S181>/Relational Operator' */
        LKAS_DW.RelationalOperator_d = (rtb_LL_LKAExPrcs_tiExitTime2 >=
          rtb_LL_LKAExPrcs_tiExitDelayTim);

        /* Update for Memory: '<S181>/Memory' */
        LKAS_DW.Memory_PreviousInput_l = rtb_LL_LKAExPrcs_tiExitTime2;
        if (!LKAS_DW.SumCondition2_MODE_m) {
          /* InitializeConditions for Memory: '<S162>/Memory' */
          LKAS_DW.Memory_PreviousInput_n = 0.0F;
          LKAS_DW.SumCondition2_MODE_m = true;
        }

        /* Sum: '<S162>/Add1' incorporates:
         *  Memory: '<S162>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_n;

        /* Saturate: '<S162>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S162>/Saturation' */

        /* Switch: '<S664>/Switch28' incorporates:
         *  Constant: '<S664>/LL_LKASWASyn_M4K=0.1'
         */
        if (LKAS_ConstB.DataTypeConversion42 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion42;
        } else {
          x10 = LL_LKASWASyn_M4K;
        }

        /* End of Switch: '<S664>/Switch28' */

        /* Sum: '<S162>/Add2' incorporates:
         *  Constant: '<S162>/Constant1'
         */
        rtb_LftTTLC = x10 - 1.0F;

        /* Product: '<S162>/Divide' */
        rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LL_LKAExPrcs_tiExitTime2 /
          rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Saturate: '<S162>/Saturation1' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 1.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 1.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        /* End of Saturate: '<S162>/Saturation1' */

        /* Saturate: '<S162>/Saturation2' */
        if (rtb_LftTTLC > 0.0F) {
          rtb_LftTTLC = 0.0F;
        } else {
          if (rtb_LftTTLC < (-1.0F)) {
            rtb_LftTTLC = (-1.0F);
          }
        }

        /* End of Saturate: '<S162>/Saturation2' */

        /* Sum: '<S162>/Add3' incorporates:
         *  Constant: '<S162>/Constant2'
         *  Product: '<S162>/Divide1'
         */
        rtb_LftTTLC = (rtb_LL_LKAExPrcs_ExitC0Dvt * rtb_LftTTLC) + 1.0F;

        /* Saturate: '<S162>/Saturation3' */
        if (rtb_LftTTLC > 1.0F) {
          LKAS_DW.Saturation3 = 1.0F;
        } else if (rtb_LftTTLC < 0.0F) {
          LKAS_DW.Saturation3 = 0.0F;
        } else {
          LKAS_DW.Saturation3 = rtb_LftTTLC;
        }

        /* End of Saturate: '<S162>/Saturation3' */

        /* Update for Memory: '<S162>/Memory' */
        LKAS_DW.Memory_PreviousInput_n = rtb_LL_LKAExPrcs_tiExitTime2;
      } else {
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S181>/Out' */
          LKAS_DW.RelationalOperator_d = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        if (LKAS_DW.SumCondition2_MODE_m) {
          /* Disable for Outport: '<S162>/M4K' */
          LKAS_DW.Saturation3 = 1.0F;
          LKAS_DW.SumCondition2_MODE_m = false;
        }
      }

      /* End of Outputs for SubSystem: '<S172>/Sum Condition2' */
      /* End of Outputs for SubSystem: '<S158>/Sum Condition2' */

      /* Fcn: '<S151>/Fcn' incorporates:
       *  DataTypeConversion: '<S151>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((LKAS_DW.RelationalOperator_d ? 1 : 0) *
        (LKAS_DW.RelationalOperator_d ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!LKAS_DW.RelationalOperator_d) ? 1 : 0)) *
        (LKAS_DW.RelationalOperator_ce ? 1 : 0)) * ((sint32)2.0F))) + (((sint32)
        (((!LKAS_DW.RelationalOperator_ce) && (!LKAS_DW.RelationalOperator_d)) ?
         1 : 0)) * (rtb_BCM_Right_Light ? 1 : 0))));

      /* Logic: '<S151>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_BCM_Right_Light ||
        (LKAS_DW.RelationalOperator_ce)) || (LKAS_DW.RelationalOperator_d));

      /* DataTypeConversion: '<S154>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon_k = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Sum: '<S158>/Add' */
      rtb_Gain2_k = rtb_IMAPve_g_EPS_SW_Trq - rtb_kphTomps_p;

      /* Saturate: '<S158>/Saturation4' */
      if (rtb_Gain2_k > 2.0F) {
        rtb_Gain2_k = 2.0F;
      } else {
        if (rtb_Gain2_k < 0.0F) {
          rtb_Gain2_k = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation4' */

      /* Abs: '<S158>/Abs' */
      rtb_Gain2_k = fabsf(rtb_Gain2_k);

      /* Saturate: '<S158>/Saturation7' */
      if (rtb_Gain2_k > 1.0F) {
        rtb_Gain2_k = 1.0F;
      } else {
        if (rtb_Gain2_k < 0.0F) {
          rtb_Gain2_k = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation7' */

      /* Switch: '<S664>/Switch26' incorporates:
       *  Constant: '<S664>/LL_LKASWASyn_M3D=0.5'
       */
      if (LKAS_ConstB.DataTypeConversion40 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion40;
      } else {
        x10 = LL_LKASWASyn_M3D;
      }

      /* End of Switch: '<S664>/Switch26' */

      /* Product: '<S158>/Divide2' */
      rtb_Gain2_k /= x10;

      /* Saturate: '<S158>/Saturation5' */
      if (rtb_Gain2_k > 1.0F) {
        rtb_Gain2_k = 1.0F;
      } else {
        if (rtb_Gain2_k < 0.0F) {
          rtb_Gain2_k = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation5' */

      /* Switch: '<S664>/Switch18' incorporates:
       *  Constant: '<S664>/LL_LKASWASyn_M3K_DT=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion25;
      } else {
        x10 = LL_LKASWASyn_M3K_DT;
      }

      /* End of Switch: '<S664>/Switch18' */

      /* Product: '<S158>/Divide1' */
      rtb_Gain2_k *= x10;

      /* Saturate: '<S158>/Saturation3' */
      if (rtb_Gain2_k > 0.4F) {
        rtb_Gain2_k = 0.4F;
      } else {
        if (rtb_Gain2_k < 0.0F) {
          rtb_Gain2_k = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation3' */

      /* Switch: '<S664>/Switch27' incorporates:
       *  Constant: '<S664>/LL_LKASWASyn_M3K_MSD=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion41 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion41;
      } else {
        x10 = LL_LKASWASyn_M3K_MSD;
      }

      /* End of Switch: '<S664>/Switch27' */

      /* Product: '<S158>/Divide' */
      rtb_Divide3_b = rtb_Merge_g1 * x10;

      /* Saturate: '<S158>/Saturation1' */
      if (rtb_Divide3_b > 0.4F) {
        rtb_Divide3_b = 0.4F;
      } else {
        if (rtb_Divide3_b < 0.0F) {
          rtb_Divide3_b = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation1' */

      /* Sum: '<S163>/Add2' incorporates:
       *  Memory: '<S163>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_m;

      /* Saturate: '<S163>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_fc = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_fc = 0.0F;
      } else {
        rtb_Saturation_fc = rtb_LftTTLC;
      }

      /* End of Saturate: '<S163>/Saturation' */

      /* MATLAB Function: '<S158>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Driver Torque Assist/MATLAB Function': '<S160>:1' */
      /* '<S160>:1:2' if T<T1 */
      if (rtb_Saturation_fc < rtb_Saturation6) {
        /* '<S160>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_LL_LKASWASyn_M0 += ((rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6) * rtb_Saturation_fc;
      } else if ((rtb_Saturation_fc >= rtb_Saturation6) && (rtb_Saturation_fc <=
                  (rtb_Saturation6 + rtb_Saturation6))) {
        /* Switch: '<S664>/Switch14' incorporates:
         *  Constant: '<S664>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S160>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S160>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_i != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_i;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (((x10 - rtb_LL_LKASWASyn_M1) / rtb_Saturation6) *
          (rtb_Saturation_fc - rtb_Saturation6)) + rtb_LL_LKASWASyn_M1;
      } else {
        /* Switch: '<S664>/Switch14' incorporates:
         *  Constant: '<S664>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S160>:1:6' else */
        /* '<S160>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_i != 0.0F) {
          rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20_i;
        } else {
          rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S158>/MATLAB Function' */

      /* Sum: '<S158>/Add1' */
      rtb_Gain2_k = (rtb_LL_LKASWASyn_M0 - rtb_Gain2_k) - rtb_Divide3_b;

      /* Saturate: '<S158>/Saturation6' */
      if (rtb_Gain2_k > 1.0F) {
        rtb_Gain2_k = 1.0F;
      } else {
        if (rtb_Gain2_k < 0.01F) {
          rtb_Gain2_k = 0.01F;
        }
      }

      /* End of Saturate: '<S158>/Saturation6' */

      /* Product: '<S158>/Divide5' */
      rtb_Gain2_k *= LKAS_DW.Saturation3;

      /* Saturate: '<S158>/Saturation2' */
      if (rtb_Gain2_k > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Gain2_k < 0.01F) {
        LKAS_DW.Saturation2 = 0.01F;
      } else {
        LKAS_DW.Saturation2 = rtb_Gain2_k;
      }

      /* End of Saturate: '<S158>/Saturation2' */

      /* Outputs for Enabled SubSystem: '<S150>/Subsystem' incorporates:
       *  EnablePort: '<S159>/Enable'
       */
      /* RelationalOperator: '<S157>/Compare' incorporates:
       *  Constant: '<S157>/Constant'
       *  Constant: '<S664>/LL_LKASWASyn_TrqSwaAddSwt=1'
       *  Switch: '<S664>/Switch47'
       */
      if (((sint32)(((LKAS_ConstB.DataTypeConversion47_c) ||
                     (LL_LKASWASyn_TrqSwaAddSwt)) ? 1 : 0)) > ((sint32)(false ?
            1 : 0))) {
        if (!LKAS_DW.Subsystem_MODE_h) {
          LKAS_DW.Subsystem_MODE_h = true;
        }

        /* MATLAB Function: '<S159>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S164>:1' */
        /* '<S164>:1:2' Swaadd=single(0); */
        /* '<S164>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S164>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S164>:1:5' l0c0=abs(l0c0); */
        /* '<S164>:1:6' r0c0=abs(r0c0); */
        /* '<S164>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_LL_LKASWASyn_M1 = fmaxf(fminf(rtb_Add5_j_tmp + rtb_TTLC, 5.4F), 2.5F);

        /* '<S164>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_LL_LKASWASyn_M1 > 2.5F) && (rtb_LL_LKASWASyn_M1 < 5.4F)) {
          /* '<S164>:1:9' leftlane=l0c0/lanewidth; */
          rtb_LL_LKAExPrcs_tiExitDelayTim = rtb_Add5_j_tmp / rtb_LL_LKASWASyn_M1;

          /* '<S164>:1:10' rightlane=r0c0/lanewidth; */
          rtb_LL_LKASWASyn_M0 = rtb_TTLC / rtb_LL_LKASWASyn_M1;
        } else {
          /* '<S164>:1:11' else */
          /* '<S164>:1:12' leftlane=single(0.5); */
          rtb_LL_LKAExPrcs_tiExitDelayTim = 0.5F;

          /* '<S164>:1:13' rightlane=single(0.5); */
          rtb_LL_LKASWASyn_M0 = 0.5F;
        }

        /* '<S164>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S164>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S164>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S664>/Switch42' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S164>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S664>/Switch43' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M0 = (((((180.0F - fmaxf(fminf(rtb_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_LL_LKAExPrcs_tiExitDelayTim) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S664>/Switch42' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S164>:1:19' else */
          /* '<S164>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S664>/Switch43' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M0 = (((((180.0F - fmaxf(fminf(rtb_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_LL_LKASWASyn_M0) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S165>/Add2' incorporates:
         *  Constant: '<S165>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S165>/Memory3'
         */
        rtb_LL_LKASWASyn_M1 = 1.0F + LKAS_DW.Memory3_PreviousInput_i;

        /* Saturate: '<S165>/Saturation' */
        if (rtb_LL_LKASWASyn_M1 > 50.0F) {
          rtb_LL_LKASWASyn_M1 = 50.0F;
        } else {
          if (rtb_LL_LKASWASyn_M1 < 0.0F) {
            rtb_LL_LKASWASyn_M1 = 0.0F;
          }
        }

        /* End of Saturate: '<S165>/Saturation' */

        /* Switch: '<S165>/Switch' incorporates:
         *  Product: '<S165>/Divide'
         *  Product: '<S165>/Divide1'
         *  Sum: '<S165>/Add'
         *  Sum: '<S165>/Add1'
         *  UnitDelay: '<S165>/Unit Delay'
         */
        if (rtb_LL_LKASWASyn_M1 > 1.0F) {
          /* Switch: '<S664>/Switch50' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S664>/Switch50' */
          rtb_LL_LKASWASyn_M0 = ((rtb_LKA_SampleTime / x10) *
            (rtb_LL_LKASWASyn_M0 - LKAS_DW.UnitDelay_DSTATE_i1)) +
            LKAS_DW.UnitDelay_DSTATE_i1;
        }

        /* End of Switch: '<S165>/Switch' */

        /* SampleTimeMath: '<S168>/TSamp'
         *
         * About '<S168>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_LKAExPrcs_tiExitDelayTim = rtb_LL_LKASWASyn_M0 * 100.0F;

        /* Sum: '<S166>/Add2' incorporates:
         *  Constant: '<S166>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S166>/Memory3'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = 1.0F + LKAS_DW.Memory3_PreviousInput_e;

        /* Saturate: '<S166>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 50.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 50.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S166>/Saturation' */

        /* Switch: '<S166>/Switch' incorporates:
         *  Product: '<S166>/Divide'
         *  Product: '<S166>/Divide1'
         *  Sum: '<S166>/Add'
         *  Sum: '<S166>/Add1'
         *  Sum: '<S168>/Diff'
         *  UnitDelay: '<S166>/Unit Delay'
         *  UnitDelay: '<S168>/UD'
         *
         * Block description for '<S168>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S168>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 2.0F) {
          /* Switch: '<S664>/Switch52' incorporates:
           *  Constant: '<S664>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S664>/Switch52' */
          rtb_LL_LKAExPrcs_ExitC0Dvt = (((rtb_LL_LKAExPrcs_tiExitDelayTim -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_j) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_j;
        } else {
          rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LL_LKAExPrcs_tiExitDelayTim -
            LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S166>/Switch' */

        /* Saturate: '<S159>/Saturation' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 30.0F) {
          rtb_LL_ThresDet_tiTTLCThresLDW = 30.0F;
        } else if (rtb_LL_LKAExPrcs_ExitC0Dvt < (-30.0F)) {
          rtb_LL_ThresDet_tiTTLCThresLDW = (-30.0F);
        } else {
          rtb_LL_ThresDet_tiTTLCThresLDW = rtb_LL_LKAExPrcs_ExitC0Dvt;
        }

        /* End of Saturate: '<S159>/Saturation' */

        /* Switch: '<S664>/Switch53' incorporates:
         *  Constant: '<S664>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S664>/Switch53' */

        /* Sum: '<S167>/Difference Inputs1' incorporates:
         *  Product: '<S159>/Divide1'
         *  Product: '<S159>/Divide3'
         *  Sum: '<S159>/Add'
         *  UnitDelay: '<S167>/Delay Input2'
         *
         * Block description for '<S167>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S167>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_ThresDet_tiTTLCThresLDW = ((rtb_LL_ThresDet_tiTTLCThresLDW * x10)
          + rtb_LL_LKASWASyn_M0) - LKAS_DW.DelayInput2_DSTATE_i;

        /* Product: '<S167>/delta rise limit' incorporates:
         *  Constant: '<S159>/Constant1'
         *  SampleTimeMath: '<S167>/sample time'
         *
         * About '<S167>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LKA_CarWidth = 5.0F * 0.01F;

        /* Product: '<S167>/delta fall limit' incorporates:
         *  Constant: '<S159>/Constant2'
         *  SampleTimeMath: '<S167>/sample time'
         *
         * About '<S167>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = (-5.0F) * 0.01F;

        /* Switch: '<S169>/Switch2' incorporates:
         *  Product: '<S167>/delta fall limit'
         *  Product: '<S167>/delta rise limit'
         *  RelationalOperator: '<S169>/LowerRelop1'
         *  RelationalOperator: '<S169>/UpperRelop'
         *  Switch: '<S169>/Switch'
         */
        if (rtb_LL_ThresDet_tiTTLCThresLDW > rtb_LKA_CarWidth) {
          rtb_LL_ThresDet_tiTTLCThresLDW = rtb_LKA_CarWidth;
        } else {
          if (rtb_LL_ThresDet_tiTTLCThresLDW < rtb_LL_DvtSpdDet_vDvtSpdMin_C) {
            /* Switch: '<S169>/Switch' incorporates:
             *  Product: '<S167>/delta fall limit'
             */
            rtb_LL_ThresDet_tiTTLCThresLDW = rtb_LL_DvtSpdDet_vDvtSpdMin_C;
          }
        }

        /* End of Switch: '<S169>/Switch2' */

        /* Sum: '<S167>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S167>/Delay Input2'
         *
         * Block description for '<S167>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S167>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_j = rtb_LL_ThresDet_tiTTLCThresLDW +
          LKAS_DW.DelayInput2_DSTATE_i;

        /* Update for UnitDelay: '<S165>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_i1 = rtb_LL_LKASWASyn_M0;

        /* Update for Memory: '<S165>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_i = rtb_LL_LKASWASyn_M1;

        /* Update for UnitDelay: '<S168>/UD'
         *
         * Block description for '<S168>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Update for UnitDelay: '<S166>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_j = rtb_LL_LKAExPrcs_ExitC0Dvt;

        /* Update for Memory: '<S166>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for UnitDelay: '<S167>/Delay Input2'
         *
         * Block description for '<S167>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_i = LKAS_DW.DifferenceInputs2_j;
      } else {
        if (LKAS_DW.Subsystem_MODE_h) {
          /* Disable for Outport: '<S159>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_j = 0.0F;
          LKAS_DW.Subsystem_MODE_h = false;
        }
      }

      /* End of RelationalOperator: '<S157>/Compare' */
      /* End of Outputs for SubSystem: '<S150>/Subsystem' */

      /* Sum: '<S264>/Add2' incorporates:
       *  Memory: '<S264>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_k;

      /* Saturate: '<S264>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_h = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_h = 0.0F;
      } else {
        rtb_Saturation_h = rtb_LftTTLC;
      }

      /* End of Saturate: '<S264>/Saturation' */

      /* If: '<S262>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       *  Inport: '<S270>/Plan'
       *  Inport: '<S270>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_i;
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_i = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S262>/If Action Subsystem' incorporates:
           *  ActionPort: '<S268>/Action Port'
           */
          /* InitializeConditions for If: '<S262>/If' incorporates:
           *  Memory: '<S268>/Memory'
           *  UnitDelay: '<S272>/Delay Input1'
           *
           * Block description for '<S272>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_p = false;
          LKAS_DW.Memory_PreviousInput_cq = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S262>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S262>/If Action Subsystem' incorporates:
         *  ActionPort: '<S268>/Action Port'
         */
        /* RelationalOperator: '<S271>/Compare' incorporates:
         *  Constant: '<S271>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Lft >= 0.0F);

        /* Memory: '<S268>/Memory' */
        rtb_Plan_g = LKAS_DW.Memory_PreviousInput_cq;

        /* Sum: '<S268>/Add' incorporates:
         *  Logic: '<S268>/Logical Operator'
         *  RelationalOperator: '<S268>/Relational Operator'
         *  RelationalOperator: '<S272>/FixPt Relational Operator'
         *  UnitDelay: '<S272>/Delay Input1'
         *
         * Block description for '<S272>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_f = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_p ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_h)) ? 1 : 0)) + rtb_Plan_g;

        /* Saturate: '<S268>/Saturation' */
        if (rtb_T1_f > 5.0F) {
          rtb_Saturation_p = 5.0F;
        } else if (rtb_T1_f < 0.0F) {
          rtb_Saturation_p = 0.0F;
        } else {
          rtb_Saturation_p = rtb_T1_f;
        }

        /* End of Saturate: '<S268>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S268>/If Action Subsystem' */
        LKAS_IfActionSubsystem_n(rtb_Saturation_p, rtb_Saturation_h,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_a, &LKAS_DW.In_k,
          &LKAS_DW.IfActionSubsystem_n);

        /* End of Outputs for SubSystem: '<S268>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S268>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_e(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_f, &rtb_Plan_g);

        /* End of Outputs for SubSystem: '<S268>/If Action Subsystem2' */

        /* Switch: '<S268>/Switch' incorporates:
         *  Switch: '<S268>/Switch1'
         */
        if (rtb_Saturation_p > 0.0F) {
          LKAS_DW.Merge_p = LKAS_DW.In_a;
          LKAS_DW.Merge1 = LKAS_DW.In_k;
        } else {
          LKAS_DW.Merge_p = rtb_T1_f;
          LKAS_DW.Merge1 = rtb_Plan_g;
        }

        /* End of Switch: '<S268>/Switch' */

        /* Update for UnitDelay: '<S272>/Delay Input1'
         *
         * Block description for '<S272>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_p = rtb_BCM_Right_Light;

        /* Update for Memory: '<S268>/Memory' */
        LKAS_DW.Memory_PreviousInput_cq = rtb_Saturation_p;

        /* End of Outputs for SubSystem: '<S262>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S262>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S269>/Action Port'
           */
          /* InitializeConditions for If: '<S262>/If' incorporates:
           *  Memory: '<S269>/Memory'
           *  UnitDelay: '<S280>/Delay Input1'
           *
           * Block description for '<S280>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_b = false;
          LKAS_DW.Memory_PreviousInput_doi = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S262>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S262>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S269>/Action Port'
         */
        /* RelationalOperator: '<S279>/Compare' incorporates:
         *  Constant: '<S279>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Rgt <= 0.0F);

        /* Memory: '<S269>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_doi;

        /* Sum: '<S269>/Add' incorporates:
         *  Logic: '<S269>/Logical Operator'
         *  RelationalOperator: '<S269>/Relational Operator'
         *  RelationalOperator: '<S280>/FixPt Relational Operator'
         *  UnitDelay: '<S280>/Delay Input1'
         *
         * Block description for '<S280>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_h = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_b ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_h)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S269>/Saturation' */
        if (rtb_T1_h > 5.0F) {
          rtb_Saturation_n2 = 5.0F;
        } else if (rtb_T1_h < 0.0F) {
          rtb_Saturation_n2 = 0.0F;
        } else {
          rtb_Saturation_n2 = rtb_T1_h;
        }

        /* End of Saturate: '<S269>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S269>/If Action Subsystem' */
        LKAS_IfActionSubsystem_n(rtb_Saturation_n2, rtb_Saturation_h,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_l, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_g);

        /* End of Outputs for SubSystem: '<S269>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S269>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_e(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_h, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S269>/If Action Subsystem2' */

        /* Switch: '<S269>/Switch' incorporates:
         *  Switch: '<S269>/Switch1'
         */
        if (rtb_Saturation_n2 > 0.0F) {
          LKAS_DW.Merge_p = LKAS_DW.In_l;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_p = rtb_T1_h;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S269>/Switch' */

        /* Update for UnitDelay: '<S280>/Delay Input1'
         *
         * Block description for '<S280>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_b = rtb_BCM_Right_Light;

        /* Update for Memory: '<S269>/Memory' */
        LKAS_DW.Memory_PreviousInput_doi = rtb_Saturation_n2;

        /* End of Outputs for SubSystem: '<S262>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S262>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S270>/Action Port'
         */
        LKAS_DW.Merge_p = rtb_Saturation6;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S262>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S262>/If' */

      /* Saturate: '<S156>/Saturation6' */
      if (LKAS_DW.Merge_p > 0.5F) {
        rtb_LL_LKASWASyn_M0 = 0.5F;
      } else if (LKAS_DW.Merge_p < 0.2F) {
        rtb_LL_LKASWASyn_M0 = 0.2F;
      } else {
        rtb_LL_LKASWASyn_M0 = LKAS_DW.Merge_p;
      }

      /* End of Saturate: '<S156>/Saturation6' */

      /* Product: '<S156>/Divide' incorporates:
       *  Product: '<S156>/Divide4'
       *  Product: '<S265>/Divide'
       *  Sum: '<S156>/Add2'
       */
      rtb_LL_LKASWASyn_M0 = (rtb_Saturation_h - LKAS_DW.Merge_p) /
        rtb_LL_LKASWASyn_M0;
      rtb_Gain2_k = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S156>/Saturation2' */
      if (rtb_Gain2_k > 1.0F) {
        rtb_Gain2_k = 1.0F;
      } else {
        if (rtb_Gain2_k < 0.0F) {
          rtb_Gain2_k = 0.0F;
        }
      }

      /* End of Saturate: '<S156>/Saturation2' */

      /* Sum: '<S156>/Add5' incorporates:
       *  Constant: '<S156>/Constant2'
       */
      rtb_LL_LKASWASyn_M1 = 1.0F - rtb_Gain2_k;

      /* Memory: '<S247>/Memory' */
      rtb_Divide3_b = LKAS_DW.Memory_PreviousInput_mk;

      /* Product: '<S314>/Z*Z' incorporates:
       *  Product: '<S311>/Z*Z'
       */
      rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LL_HdAgPrvwT_C * rtb_LL_HdAgPrvwT_C;

      /* Sum: '<S247>/Add1' incorporates:
       *  Gain: '<S293>/Gain2'
       *  Product: '<S247>/Divide'
       *  Product: '<S247>/Divide1'
       *  Product: '<S311>/Product3'
       *  Product: '<S311>/Product4'
       *  Product: '<S314>/Product3'
       *  Product: '<S314>/Product4'
       *  Product: '<S314>/Z*Z'
       *  Sum: '<S293>/Add2'
       *  Sum: '<S311>/Add'
       *  Sum: '<S314>/Add'
       */
      rtb_Add1_d3 = ((((((rtb_Add_a_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_c) +
                        (rtb_L0_C3_i * rtb_LL_LKAExPrcs_tiExitTime2)) +
                       (((rtb_Add_l_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_h5) +
                        (rtb_L0_C3 * rtb_LL_LKAExPrcs_tiExitTime2))) * 0.5F) *
                     LKAS_ConstB.Divide2_i) + (LKAS_ConstB.Add2_j *
        rtb_Divide3_b);

      /* Product: '<S245>/Divide3' incorporates:
       *  Gain: '<S291>/Gain1'
       */
      rtb_Divide3_b = rtb_LL_HdAgPrvwT_C * rtb_LL_ThresDet_lDvtThresUprLDW;

      /* Gain: '<S245>/kph to mps' */
      rtb_kphtomps_m = rtb_Abs_d_tmp;

      /* MATLAB Function: '<S245>/Saturable Gain Lut (SatGainLut)' */
      LKAS_SaturableGainLutSatGainLut(rtb_ESC_VehSpd,
        rtb_LL_LFClb_TFC_KpVehSpdLwr_C, rtb_LL_LFClb_TFC_KpVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KpV1_C, rtb_LL_LFClb_TFC_KpV2_C, &rtb_Gain_pi);

      /* Switch: '<S664>/Switch32' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_PrvwT_C=2'
       */
      if (LKAS_ConstB.DataTypeConversion15_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_h;
      } else {
        x10 = LL_LFClb_TFC_PrvwT_C;
      }

      /* End of Switch: '<S664>/Switch32' */

      /* Product: '<S245>/Divide1' */
      rtb_LftTTLC = x10 * rtb_kphtomps_m;

      /* Switch: '<S664>/Switch30' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_KpKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_k != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_k;
      } else {
        x10 = LL_LFClb_TFC_KpKlat_C;
      }

      /* End of Switch: '<S664>/Switch30' */

      /* Saturate: '<S245>/Saturation' */
      if (rtb_LftTTLC > 40.0F) {
        rtb_LftTTLC = 40.0F;
      } else {
        if (rtb_LftTTLC < 5.0F) {
          rtb_LftTTLC = 5.0F;
        }
      }

      /* End of Saturate: '<S245>/Saturation' */

      /* Sum: '<S245>/Subtract2' incorporates:
       *  Sum: '<S245>/Add1'
       */
      rtb_LL_HdAgPrvwT_C = rtb_Add1_d3 - rtb_Divide3_b;

      /* Product: '<S245>/Product4' incorporates:
       *  Gain: '<S292>/Gain1'
       *  Product: '<S245>/Divide'
       *  Product: '<S245>/Product1'
       *  Sum: '<S245>/Subtract1'
       *  Sum: '<S245>/Subtract2'
       *  Sum: '<S292>/Add1'
       */
      rtb_L0_C1_h5 = (((((rtb_Add_ny + rtb_Add_cg) * 0.5F) / rtb_LftTTLC) * x10)
                      - rtb_LL_HdAgPrvwT_C) * rtb_Gain_pi;

      /* Switch: '<S664>/Switch19' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_Kp_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion26_j != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion26_j;
      } else {
        x10 = LL_LFClb_TFC_Kp_C;
      }

      /* End of Switch: '<S664>/Switch19' */

      /* Product: '<S245>/Product2' */
      rtb_Merge_g1 = rtb_L0_C1_h5 * x10;

      /* Saturate: '<S245>/Saturation2' */
      if (rtb_Merge_g1 > 360.0F) {
        rtb_Merge_g1 = 360.0F;
      } else {
        if (rtb_Merge_g1 < (-360.0F)) {
          rtb_Merge_g1 = (-360.0F);
        }
      }

      /* End of Saturate: '<S245>/Saturation2' */

      /* Abs: '<S245>/Abs' incorporates:
       *  Gain: '<S291>/Gain1'
       */
      rtb_kphTomps_p = fabsf(rtb_LL_ThresDet_lDvtThresUprLDW);

      /* Saturate: '<S245>/Saturation1' */
      if (rtb_kphTomps_p > 0.004F) {
        rtb_kphTomps_p = 0.004F;
      } else {
        if (rtb_kphTomps_p < 1.0E-5F) {
          rtb_kphTomps_p = 1.0E-5F;
        }
      }

      /* End of Saturate: '<S245>/Saturation1' */

      /* Switch: '<S664>/Switch39' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_KiMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_KiMaxSWA_C;
      }

      /* End of Switch: '<S664>/Switch39' */

      /* Sum: '<S245>/Add3' incorporates:
       *  Constant: '<S245>/Constant3'
       *  Constant: '<S245>/Constant4'
       *  Product: '<S245>/Divide4'
       *  Sum: '<S245>/Add5'
       */
      rtb_kphTomps_p = (((x10 - 1.0F) * rtb_kphTomps_p) / 0.004F) + 1.0F;

      /* Sum: '<S253>/Add2' incorporates:
       *  Memory: '<S253>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_m1;

      /* Saturate: '<S253>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_em = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_em = 0.0F;
      } else {
        rtb_Saturation_em = rtb_LftTTLC;
      }

      /* End of Saturate: '<S253>/Saturation' */

      /* Switch: '<S245>/Switch2' incorporates:
       *  Product: '<S245>/Divide2'
       *  Sum: '<S245>/Add'
       *  Sum: '<S245>/Add2'
       *  Switch: '<S664>/Switch40'
       *  UnitDelay: '<S245>/Unit Delay'
       */
      if ((rtb_Saturation_em - rtb_Saturation6) >= 0.0F) {
        /* Switch: '<S664>/Switch40' incorporates:
         *  Constant: '<S664>/LL_LFClb_TFC_Ki_C=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_h = (rtb_L0_C1_h5 * x10) + LKAS_DW.UnitDelay_DSTATE_i;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S664>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S664>/Switch40' incorporates:
           *  Constant: '<S664>/LL_LFClb_TFC_Ki_C=0.01'
           */
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_h = rtb_L0_C1_h5 * x10;
      }

      /* End of Switch: '<S245>/Switch2' */

      /* Gain: '<S245>/Gain' */
      rtb_L0_C1_h5 = (-1.0F) * rtb_kphTomps_p;

      /* Switch: '<S250>/Switch' incorporates:
       *  RelationalOperator: '<S250>/UpperRelop'
       */
      if (rtb_Switch2_h < rtb_L0_C1_h5) {
        rtb_Switch_i5 = rtb_L0_C1_h5;
      } else {
        rtb_Switch_i5 = rtb_Switch2_h;
      }

      /* End of Switch: '<S250>/Switch' */

      /* Switch: '<S250>/Switch2' incorporates:
       *  RelationalOperator: '<S250>/LowerRelop1'
       */
      if (rtb_Switch2_h > rtb_kphTomps_p) {
        rtb_Switch2_bi = rtb_kphTomps_p;
      } else {
        rtb_Switch2_bi = rtb_Switch_i5;
      }

      /* End of Switch: '<S250>/Switch2' */

      /* Product: '<S156>/Divide1' incorporates:
       *  Sum: '<S156>/Add3'
       */
      rtb_L0_C1_c = (rtb_Merge_g1 + rtb_Switch2_bi) * rtb_Gain2_k;

      /* Switch: '<S664>/Switch49' incorporates:
       *  Constant: '<S664>/LL_LFClb_TFC_KdMaxSWA_C=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_KdMaxSWA_C;
      }

      /* End of Switch: '<S664>/Switch49' */

      /* Product: '<S245>/Divide8' incorporates:
       *  Constant: '<S245>/Constant7'
       *  Constant: '<S245>/Constant8'
       *  Sum: '<S245>/Add4'
       */
      rtb_kphTomps_p = ((180.0F - rtb_kphtomps_m) * x10) / 120.0F;

      /* MATLAB Function: '<S245>/Saturable Gain Lut (SatGainLut)1' */
      LKAS_SaturableGainLutSatGainLut(rtb_kphtomps_m,
        rtb_LL_LFClb_TFC_KdVehSpdLwr_C, rtb_LL_LFClb_TFC_KdVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KdV1_C, rtb_LL_LFClb_TFC_KdV2_C, &rtb_Gain_pi);

      /* Product: '<S252>/Divide1' incorporates:
       *  Constant: '<S252>/Constant3'
       *  Sum: '<S252>/Add4'
       */
      rtb_Merge_g1 = (1.0F + rtb_LL_LFClb_TFC_KdBalance_C) * rtb_Gain_pi;

      /* Gain: '<S252>/Gain' incorporates:
       *  Abs: '<S252>/Abs'
       */
      rtb_L0_C1_h5 = fabsf(rtb_LKA_Veh2CamW_C) * 0.5F;

      /* Gain: '<S252>/Gain1' incorporates:
       *  Sum: '<S252>/Add2'
       */
      rtb_Gain1_cj = (rtb_L0_C0_c + rtb_R0_C0_j) * 0.5F;

      /* Gain: '<S252>/Gain2' */
      rtb_Gain2_k = (-1.0F) * rtb_L0_C1_h5;

      /* Switch: '<S257>/Switch' incorporates:
       *  RelationalOperator: '<S257>/UpperRelop'
       */
      if (rtb_Gain1_cj < rtb_Gain2_k) {
        rtb_Switch_gk = rtb_Gain2_k;
      } else {
        rtb_Switch_gk = rtb_Gain1_cj;
      }

      /* End of Switch: '<S257>/Switch' */

      /* Switch: '<S257>/Switch2' incorporates:
       *  RelationalOperator: '<S257>/LowerRelop1'
       */
      if (rtb_Gain1_cj > rtb_L0_C1_h5) {
        rtb_Switch2_i = rtb_L0_C1_h5;
      } else {
        rtb_Switch2_i = rtb_Switch_gk;
      }

      /* End of Switch: '<S257>/Switch2' */

      /* Product: '<S252>/Divide4' */
      rtb_L0_C1_h5 = (rtb_Switch2_i / rtb_L0_C1_h5) *
        rtb_LL_LFClb_TFC_KdBalance_C;

      /* Product: '<S252>/Divide5' incorporates:
       *  Constant: '<S252>/Constant2'
       *  Sum: '<S252>/Add5'
       */
      rtb_Divide5_a = (1.0F + rtb_L0_C1_h5) * rtb_Gain_pi;

      /* Product: '<S252>/Divide2' incorporates:
       *  Constant: '<S252>/Constant2'
       *  Sum: '<S252>/Add1'
       */
      rtb_Divide2_hw = (1.0F - rtb_L0_C1_h5) * rtb_Gain_pi;

      /* Sum: '<S259>/Add' incorporates:
       *  Constant: '<S259>/Constant'
       *  Memory: '<S259>/Memory'
       */
      rtb_Saturation_a = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_nv));

      /* Saturate: '<S259>/Saturation1' */
      if (rtb_Saturation_a < ((uint16)10000U)) {
        rtb_Saturation1_pb = rtb_Saturation_a;
      } else {
        rtb_Saturation1_pb = ((uint16)10000U);
      }

      /* End of Saturate: '<S259>/Saturation1' */

      /* If: '<S259>/If' incorporates:
       *  Constant: '<S259>/Constant2'
       *  DataTypeConversion: '<S141>/Cast To Single'
       *  Inport: '<S260>/In'
       */
      if (rtb_Saturation1_pb == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S259>/if action ' incorporates:
         *  ActionPort: '<S260>/Action Port'
         */
        LKAS_DW.In_d = LKAS_DW.stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S259>/if action ' */
      }

      /* End of If: '<S259>/If' */

      /* If: '<S252>/If' incorporates:
       *  Inport: '<S256>/In1'
       */
      if (((sint32)LKAS_DW.In_d) == 1) {
        /* Outputs for IfAction SubSystem: '<S252>/If Action Subsystem' incorporates:
         *  ActionPort: '<S254>/Action Port'
         */
        LKAS_IfActionSubsystem_f(rtb_Divide2_hw, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S252>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_d) == 2) {
        /* Outputs for IfAction SubSystem: '<S252>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S255>/Action Port'
         */
        LKAS_IfActionSubsystem_f(rtb_Divide5_a, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S252>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S252>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S256>/Action Port'
         */
        rtb_Merge_k = rtb_Gain_pi;

        /* End of Outputs for SubSystem: '<S252>/If Action Subsystem2' */
      }

      /* End of If: '<S252>/If' */

      /* Product: '<S252>/Divide3' incorporates:
       *  Constant: '<S252>/Constant1'
       *  Sum: '<S252>/Add3'
       */
      rtb_L0_C1_h5 = (1.0F - rtb_LL_LFClb_TFC_KdBalance_C) * rtb_Gain_pi;

      /* Switch: '<S258>/Switch' incorporates:
       *  RelationalOperator: '<S258>/UpperRelop'
       */
      if (rtb_Merge_k < rtb_L0_C1_h5) {
        rtb_Switch_hl = rtb_L0_C1_h5;
      } else {
        rtb_Switch_hl = rtb_Merge_k;
      }

      /* End of Switch: '<S258>/Switch' */

      /* Switch: '<S258>/Switch2' incorporates:
       *  RelationalOperator: '<S258>/LowerRelop1'
       */
      if (rtb_Merge_k > rtb_Merge_g1) {
        rtb_Switch2_nk = rtb_Merge_g1;
      } else {
        rtb_Switch2_nk = rtb_Switch_hl;
      }

      /* End of Switch: '<S258>/Switch2' */

      /* Product: '<S245>/Divide7' incorporates:
       *  Gain: '<S245>/Gain1'
       */
      rtb_Divide7 = (rtb_LL_HdAgPrvwT_C * (-1.0F)) * rtb_Switch2_nk;

      /* Gain: '<S245>/Gain3' */
      rtb_Merge_g1 = (-1.0F) * rtb_kphTomps_p;

      /* Switch: '<S251>/Switch' incorporates:
       *  RelationalOperator: '<S251>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_Merge_g1) {
        rtb_Switch_bv = rtb_Merge_g1;
      } else {
        rtb_Switch_bv = rtb_Divide7;
      }

      /* End of Switch: '<S251>/Switch' */

      /* Switch: '<S251>/Switch2' incorporates:
       *  RelationalOperator: '<S251>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_kphTomps_p) {
        rtb_Switch2_gi = rtb_kphTomps_p;
      } else {
        rtb_Switch2_gi = rtb_Switch_bv;
      }

      /* End of Switch: '<S251>/Switch2' */

      /* Product: '<S156>/Divide4' */
      rtb_kphTomps_p = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S156>/Saturation1' */
      if (rtb_kphTomps_p > 1.0F) {
        rtb_kphTomps_p = 1.0F;
      } else {
        if (rtb_kphTomps_p < 0.0F) {
          rtb_kphTomps_p = 0.0F;
        }
      }

      /* End of Saturate: '<S156>/Saturation1' */

      /* Product: '<S156>/Divide2' */
      rtb_R0_C0_j = rtb_Switch2_gi * rtb_kphTomps_p;

      /* Saturate: '<S265>/Saturation4' */
      if (rtb_LL_LKASWASyn_M0 > 1.0F) {
        rtb_LL_LKASWASyn_M0 = 1.0F;
      } else {
        if (rtb_LL_LKASWASyn_M0 < 0.0F) {
          rtb_LL_LKASWASyn_M0 = 0.0F;
        }
      }

      /* End of Saturate: '<S265>/Saturation4' */

      /* Product: '<S156>/Divide5' incorporates:
       *  Constant: '<S265>/Constant1'
       *  Product: '<S265>/Divide8'
       *  Sum: '<S265>/Add1'
       */
      rtb_kphTomps_p = ((LKAS_ConstB.Add3 * rtb_LL_LKASWASyn_M0) + 0.0F) *
        rtb_LL_LKAExPrcs_tiExitTime1;

      /* Saturate: '<S156>/Saturation3' */
      if (rtb_Merge > 0.004F) {
        rtb_Merge_g1 = 0.004F;
      } else if (rtb_Merge < (-0.004F)) {
        rtb_Merge_g1 = (-0.004F);
      } else {
        rtb_Merge_g1 = rtb_Merge;
      }

      /* End of Saturate: '<S156>/Saturation3' */

      /* Product: '<S156>/Divide3' */
      rtb_LftTTLC = rtb_Saturation_h / LKAS_DW.Merge_p;

      /* Saturate: '<S156>/Saturation' */
      if (rtb_LftTTLC > 1.0F) {
        rtb_LftTTLC = 1.0F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S156>/Saturation' */

      /* Sum: '<S156>/Add4' incorporates:
       *  Product: '<S156>/Divide6'
       *  Product: '<S156>/Divide7'
       *  Sum: '<S156>/Add6'
       */
      rtb_R0_C0_j = (((((LKAS_DW.Merge1 + rtb_LL_LKAExPrcs_tiExitTime1) *
                        rtb_LL_LKASWASyn_M1) + rtb_L0_C1_c) + rtb_R0_C0_j) +
                     rtb_kphTomps_p) + (LKAS_DW.DifferenceInputs2_j *
        rtb_LftTTLC);

      /* Memory: '<S263>/Memory3' */
      rtb_kphTomps_p = LKAS_DW.Memory3_PreviousInput_k4;

      /* Sum: '<S263>/Add2' incorporates:
       *  Constant: '<S263>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_kphTomps_p += 1.0F;

      /* Saturate: '<S263>/Saturation' */
      if (rtb_kphTomps_p > 50.0F) {
        rtb_Saturation_fj = 50.0F;
      } else if (rtb_kphTomps_p < 0.0F) {
        rtb_Saturation_fj = 0.0F;
      } else {
        rtb_Saturation_fj = rtb_kphTomps_p;
      }

      /* End of Saturate: '<S263>/Saturation' */

      /* Switch: '<S263>/Switch' incorporates:
       *  Constant: '<S156>/Constant1'
       *  Product: '<S263>/Divide'
       *  Product: '<S263>/Divide1'
       *  Sum: '<S263>/Add'
       *  Sum: '<S263>/Add1'
       *  UnitDelay: '<S263>/Unit Delay'
       */
      if (rtb_Saturation_fj > 30.0F) {
        rtb_Switch_n0 = ((rtb_LKA_SampleTime / 0.1F) * (rtb_R0_C0_j -
          LKAS_DW.UnitDelay_DSTATE_m)) + LKAS_DW.UnitDelay_DSTATE_m;
      } else {
        rtb_Switch_n0 = rtb_R0_C0_j;
      }

      /* End of Switch: '<S263>/Switch' */

      /* Switch: '<S664>/Switch17' incorporates:
       *  Constant: '<S664>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S664>/Switch17' */

      /* Sum: '<S153>/Add' */
      rtb_Add_jv = (rtb_Switch_n0 - x10) + LKAS_DW.Saturation_a;

      /* Sum: '<S153>/Add1' */
      rtb_kphTomps_p = rtb_LL_LKAExPrcs_tiExitTime1 +
        rtb_LL_LDW_LatestWarnLine_C;

      /* Sum: '<S153>/Add2' incorporates:
       *  Gain: '<S153>/Gain2'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 += (-1.0F) * rtb_LL_LDW_LatestWarnLine_C;

      /* Switch: '<S241>/Switch' incorporates:
       *  RelationalOperator: '<S241>/UpperRelop'
       */
      if (rtb_Add_jv < rtb_LL_LKAExPrcs_tiExitTime1) {
        rtb_Switch_iy = rtb_LL_LKAExPrcs_tiExitTime1;
      } else {
        rtb_Switch_iy = rtb_Add_jv;
      }

      /* End of Switch: '<S241>/Switch' */

      /* Switch: '<S241>/Switch2' incorporates:
       *  RelationalOperator: '<S241>/LowerRelop1'
       */
      if (rtb_Add_jv > rtb_kphTomps_p) {
        rtb_Switch2_es = rtb_kphTomps_p;
      } else {
        rtb_Switch2_es = rtb_Switch_iy;
      }

      /* End of Switch: '<S241>/Switch2' */

      /* Sum: '<S240>/Add1' incorporates:
       *  Constant: '<S240>/Constant'
       *  Memory: '<S240>/Memory'
       */
      rtb_Saturation_a = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_no));

      /* Switch: '<S240>/Switch' incorporates:
       *  Constant: '<S240>/LatchTime_SY'
       *  RelationalOperator: '<S240>/Relational Operator'
       *  UnitDelay: '<S240>/Delay Input2'
       *
       * Block description for '<S240>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_a <= ((uint16)1U)) {
        rtb_kphTomps_p = rtb_Switch2_es;
      } else {
        rtb_kphTomps_p = LKAS_DW.DelayInput2_DSTATE_m;
      }

      /* End of Switch: '<S240>/Switch' */

      /* Sum: '<S240>/Difference Inputs1'
       *
       * Block description for '<S240>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_g = rtb_Switch2_es - rtb_kphTomps_p;

      /* SampleTimeMath: '<S240>/sample time'
       *
       * About '<S240>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_Merge_g1 = 0.01F;

      /* Product: '<S240>/delta rise limit' incorporates:
       *  Gain: '<S153>/Gain3'
       */
      rtb_L0_C1_h5 = (1.4F * rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_Merge_g1;

      /* Product: '<S240>/delta fall limit' incorporates:
       *  Gain: '<S153>/Gain1'
       */
      rtb_Merge_g1 *= (-1.4F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S242>/Switch' incorporates:
       *  RelationalOperator: '<S242>/UpperRelop'
       */
      if (rtb_UkYk1_g < rtb_Merge_g1) {
        rtb_Switch_a = rtb_Merge_g1;
      } else {
        rtb_Switch_a = rtb_UkYk1_g;
      }

      /* End of Switch: '<S242>/Switch' */

      /* Switch: '<S242>/Switch2' incorporates:
       *  RelationalOperator: '<S242>/LowerRelop1'
       */
      if (rtb_UkYk1_g > rtb_L0_C1_h5) {
        rtb_Switch2_jc = rtb_L0_C1_h5;
      } else {
        rtb_Switch2_jc = rtb_Switch_a;
      }

      /* End of Switch: '<S242>/Switch2' */

      /* Sum: '<S240>/Difference Inputs2'
       *
       * Block description for '<S240>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_jc + rtb_kphTomps_p;

      /* Saturate: '<S240>/Saturation2' */
      if (rtb_Saturation_a < ((uint16)10000U)) {
        rtb_Saturation2_g = rtb_Saturation_a;
      } else {
        rtb_Saturation2_g = ((uint16)10000U);
      }

      /* End of Saturate: '<S240>/Saturation2' */

      /* DataTypeConversion: '<S154>/CastLKA3' */
      LKAS_DW.T1_Mon_h = LKAS_DW.Merge_p;

      /* If: '<S193>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S211>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_Add_ny, &rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S210>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_Add_cg, &rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S212>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem3' */
      }

      /* End of If: '<S193>/If' */

      /* If: '<S195>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S195>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S217>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_phiHdAg_Lft, &rtb_Merge_ks);

        /* End of Outputs for SubSystem: '<S195>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S195>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S216>/Action Port'
         */
        LKAS_IfActionSubsystem2_m(rtb_phiHdAg_Rgt, &rtb_Merge_ks);

        /* End of Outputs for SubSystem: '<S195>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S195>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S218>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_ks);

        /* End of Outputs for SubSystem: '<S195>/If Action Subsystem3' */
      }

      /* End of If: '<S195>/If' */

      /* DataTypeConversion: '<S235>/Data Type Conversion' incorporates:
       *  Constant: '<S236>/Constant'
       *  RelationalOperator: '<S236>/Compare'
       */
      rtb_L0_Q = (uint8)((rtb_Merge <= 0.0F) ? 1 : 0);

      /* Gain: '<S231>/kph To mps' */
      rtb_kphTomps_p = rtb_Abs_d_tmp;

      /* Switch: '<S664>/Switch5' incorporates:
       *  Constant: '<S664>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_h;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S664>/Switch5' */

      /* Product: '<S235>/Divide' */
      rtb_Merge_g1 = (rtb_Merge * rtb_kphTomps_p) * x10;

      /* Abs: '<S235>/Abs1' incorporates:
       *  Abs: '<S235>/Abs'
       */
      rtb_R0_C0_j = fabsf(rtb_Merge_g1);
      rtb_Abs1_m = rtb_R0_C0_j;

      /* Abs: '<S235>/Abs' */
      rtb_Abs_ml = rtb_R0_C0_j;

      /* If: '<S235>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.stLKAActvFlg) == 1) && (((sint32)rtb_L0_Q) == 0)) {
        /* Outputs for IfAction SubSystem: '<S235>/If Action Subsystem' incorporates:
         *  ActionPort: '<S237>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_ml, &rtb_Merge_g1);

        /* End of Outputs for SubSystem: '<S235>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.stLKAActvFlg) == 2) && (((sint32)rtb_L0_Q) ==
                  1)) {
        /* Outputs for IfAction SubSystem: '<S235>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S239>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_m, &rtb_Merge_g1);

        /* End of Outputs for SubSystem: '<S235>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S235>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S238>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_g1);

        /* End of Outputs for SubSystem: '<S235>/If Action Subsystem2' */
      }

      /* End of If: '<S235>/If' */

      /* Switch: '<S664>/Switch6' incorporates:
       *  Constant: '<S664>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_g != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_g;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S664>/Switch6' */

      /* Sum: '<S231>/Add1' incorporates:
       *  Product: '<S231>/Divide'
       *  Product: '<S231>/Divide1'
       */
      rtb_Add1_ie = (((1.0F / x10) * rtb_LKA_Veh2CamW_C) / rtb_kphTomps_p) +
        rtb_Merge_g1;

      /* If: '<S187>/If' incorporates:
       *  Constant: '<S234>/Constant2'
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S187>/If Action Subsystem' incorporates:
         *  ActionPort: '<S232>/Action Port'
         */
        /* Gain: '<S232>/Gain2' */
        rtb_Merge_i = (-1.0F) * rtb_Add1_ie;

        /* End of Outputs for SubSystem: '<S187>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S187>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S233>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_ie, &rtb_Merge_i);

        /* End of Outputs for SubSystem: '<S187>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S187>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S234>/Action Port'
         */
        rtb_Merge_i = 0.0F;

        /* End of Outputs for SubSystem: '<S187>/If Action Subsystem2' */
      }

      /* End of If: '<S187>/If' */

      /* Sum: '<S196>/Add' incorporates:
       *  Constant: '<S196>/Constant'
       *  Memory: '<S196>/Memory'
       */
      rtb_Add_m5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_n2));

      /* Saturate: '<S196>/Saturation1' */
      if (rtb_Add_m5 < ((uint16)10000U)) {
        rtb_Saturation_a = rtb_Add_m5;
      } else {
        rtb_Saturation_a = ((uint16)10000U);
      }

      /* End of Saturate: '<S196>/Saturation1' */

      /* If: '<S196>/If' incorporates:
       *  Constant: '<S196>/Constant2'
       */
      if (rtb_Saturation_a == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S196>/if action ' incorporates:
         *  ActionPort: '<S219>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_i, &rtb_In_g);

        /* End of Outputs for SubSystem: '<S196>/if action ' */
      }

      /* End of If: '<S196>/If' */

      /* Sum: '<S198>/Add' incorporates:
       *  Constant: '<S198>/Constant'
       *  Memory: '<S198>/Memory'
       */
      rtb_Saturation_a = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_g));

      /* Saturate: '<S198>/Saturation1' */
      if (rtb_Saturation_a < ((uint16)10000U)) {
        rtb_Saturation1_d = rtb_Saturation_a;
      } else {
        rtb_Saturation1_d = ((uint16)10000U);
      }

      /* End of Saturate: '<S198>/Saturation1' */

      /* If: '<S198>/If' incorporates:
       *  Constant: '<S198>/Constant2'
       */
      if (rtb_Saturation1_d == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S198>/if action ' incorporates:
         *  ActionPort: '<S221>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_g, &rtb_In_i);

        /* End of Outputs for SubSystem: '<S198>/if action ' */
      }

      /* End of If: '<S198>/If' */

      /* Sum: '<S199>/Add' incorporates:
       *  Constant: '<S199>/Constant'
       *  Memory: '<S199>/Memory'
       */
      rtb_Saturation_a = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_p));

      /* Saturate: '<S199>/Saturation1' */
      if (rtb_Saturation_a < ((uint16)10000U)) {
        rtb_Saturation1_c = rtb_Saturation_a;
      } else {
        rtb_Saturation1_c = ((uint16)10000U);
      }

      /* End of Saturate: '<S199>/Saturation1' */

      /* If: '<S199>/If' incorporates:
       *  Constant: '<S199>/Constant2'
       */
      if (rtb_Saturation1_c == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S199>/if action ' incorporates:
         *  ActionPort: '<S222>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_ks, &rtb_In);

        /* End of Outputs for SubSystem: '<S199>/if action ' */
      }

      /* End of If: '<S199>/If' */

      /* DataTypeConversion: '<S184>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_ESC_VehSpd;

      /* DataTypeConversion: '<S154>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon_a = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S188>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_bk) {
          /* Disable for Outport: '<S173>/Out' */
          LKAS_DW.RelationalOperator_ce = false;
          LKAS_DW.SumCondition1_MODE_bk = false;
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_n.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_g0,
            &LKAS_DW.SumCondition1_n);
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition' */
        if (LKAS_DW.SumCondition_o.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_ii,
            &LKAS_DW.SumCondition_o);
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S181>/Out' */
          LKAS_DW.RelationalOperator_d = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S158>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_m) {
          /* Disable for Outport: '<S162>/M4K' */
          LKAS_DW.Saturation3 = 1.0F;
          LKAS_DW.SumCondition2_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S158>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S150>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_h) {
          /* Disable for Outport: '<S159>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_j = 0.0F;
          LKAS_DW.Subsystem_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S150>/Subsystem' */

        /* Disable for If: '<S262>/If' */
        LKAS_DW.If_ActiveSubsystem_i = -1;

        /* Disable for Outport: '<S141>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S141>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S141>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S141>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_k = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_a = 0.0F;
        LKAS_DW.T1_Mon_h = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon_k;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon_a;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.T1_Mon = LKAS_DW.T1_Mon_h;

    /* Switch: '<S602>/Switch1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S15>/Extract Desired Bits'
     *  Delay: '<S602>/Delay'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S607>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S607>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S607>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S608>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S608>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S608>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S609>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S609>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S609>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S610>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S610>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S610>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S611>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S611>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S611>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S613>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S614>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S615>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator1'
     *  Switch: '<S602>/Switch2'
     *  Switch: '<S602>/Switch3'
     *  Switch: '<S602>/Switch4'
     *  Switch: '<S602>/Switch5'
     *  Switch: '<S602>/Switch6'
     *  Switch: '<S602>/Switch7'
     */
    if (rtb_L0_C0_g != 0.0F) {
      rtb_L0_Q = (uint8)(((((((LKAS_DW.Delay_DSTATE_o | ((uint8)1U)) | ((uint8)
        2U)) | ((uint8)4U)) | ((uint8)8U)) | ((uint8)16U)) | ((uint8)32U)) |
                         ((uint8)64U));
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~((uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)(~((uint8)
        (~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)
        (((uint8)(~LKAS_DW.Delay_DSTATE_o)) | ((uint8)1U))))))) | ((uint8)2U)))))))
        | ((uint8)4U))))))) | ((uint8)8U))))))) | ((uint8)16U))))))) | ((uint8)
        32U))))))) | ((uint8)64U))));
    }

    /* End of Switch: '<S602>/Switch1' */

    /* Switch: '<S602>/Switch8' incorporates:
     *  S-Function (sfix_bitop): '<S612>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S612>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S612>/FixPt Bitwise Operator5'
     */
    rtb_Switch8 = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)128U))));

    /* Switch: '<S603>/Switch2' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean16'
     *  DataTypeConversion: '<S39>/Extract Desired Bits'
     *  Delay: '<S603>/Delay'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S630>/FixPt Bitwise Operator1'
     *  Switch: '<S603>/Switch1'
     */
    if (rtb_L0_C0_g != 0.0F) {
      rtb_L0_Q = (uint8)(((uint8)(~((uint8)(((uint8)(~LKAS_DW.Delay_DSTATE_d)) |
        ((uint8)1U))))) | ((uint8)2U));
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_d)) | ((uint8)1U))))))) | ((uint8)2U))));
    }

    /* End of Switch: '<S603>/Switch2' */

    /* Switch: '<S603>/Switch3' incorporates:
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator5'
     */
    rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)4U))));

    /* Switch: '<S603>/Switch4' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean20'
     *  DataTypeConversion: '<S28>/Extract Desired Bits'
     *  S-Function (sfix_bitop): '<S624>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S624>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S624>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator1'
     */
    if (rtb_L0_C0_g != 0.0F) {
      rtb_L0_Q |= ((uint8)8U);
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)8U))));
    }

    /* End of Switch: '<S603>/Switch4' */

    /* Switch: '<S603>/Switch5' incorporates:
     *  S-Function (sfix_bitop): '<S626>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S626>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S626>/FixPt Bitwise Operator5'
     */
    rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)16U))));

    /* Switch: '<S603>/Switch6' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean36'
     *  DataTypeConversion: '<S31>/Extract Desired Bits'
     *  S-Function (sfix_bitop): '<S625>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S625>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S625>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator1'
     */
    if (rtb_L0_C0_g != 0.0F) {
      rtb_L0_Q |= ((uint8)32U);
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)32U))));
    }

    /* End of Switch: '<S603>/Switch6' */

    /* Switch: '<S603>/Switch7' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  DataTypeConversion: '<S46>/Extract Desired Bits'
     *  Delay: '<S604>/Delay'
     *  S-Function (sfix_bitop): '<S627>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S627>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S627>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S628>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S628>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S628>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S645>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S646>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S647>/FixPt Bitwise Operator1'
     *  Switch: '<S603>/Switch8'
     *  Switch: '<S604>/Switch1'
     *  Switch: '<S604>/Switch2'
     *  Switch: '<S604>/Switch3'
     */
    if (rtb_R0_C3 != 0.0F) {
      rtb_Switch8_h = (uint8)((rtb_L0_Q | ((uint8)64U)) | ((uint8)128U));
      rtb_L0_Q = (uint8)(((LKAS_DW.Delay_DSTATE_ci | ((uint8)1U)) | ((uint8)2U))
                         | ((uint8)4U));
    } else {
      rtb_Switch8_h = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~rtb_L0_Q)) | ((uint8)64U))))))) | ((uint8)128U))));
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~((uint8)(~((uint8)(((uint8)(~LKAS_DW.Delay_DSTATE_ci)) | ((uint8)1U)))))))
        | ((uint8)2U))))))) | ((uint8)4U))));
    }

    /* End of Switch: '<S603>/Switch7' */

    /* Switch: '<S604>/Switch4' incorporates:
     *  S-Function (sfix_bitop): '<S640>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S640>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S640>/FixPt Bitwise Operator5'
     */
    rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)8U))));

    /* Switch: '<S604>/Switch5' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean8'
     *  DataTypeConversion: '<S64>/Extract Desired Bits'
     *  S-Function (sfix_bitop): '<S641>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S641>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S641>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S642>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S642>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S642>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S649>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S650>/FixPt Bitwise Operator1'
     *  Switch: '<S604>/Switch6'
     */
    if (rtb_R0_C3 != 0.0F) {
      rtb_L0_Q = (uint8)((rtb_L0_Q | ((uint8)16U)) | ((uint8)32U));
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~rtb_L0_Q)) | ((uint8)16U))))))) | ((uint8)32U))));
    }

    /* End of Switch: '<S604>/Switch5' */

    /* Switch: '<S604>/Switch7' incorporates:
     *  S-Function (sfix_bitop): '<S643>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S643>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S643>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S651>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LDW_Fault) {
      rtb_L0_Q |= ((uint8)64U);
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)64U))));
    }

    /* End of Switch: '<S604>/Switch7' */

    /* Switch: '<S604>/Switch8' incorporates:
     *  S-Function (sfix_bitop): '<S644>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S644>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S644>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S652>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LKA_Fault) {
      rtb_Switch8_e = (uint8)(rtb_L0_Q | ((uint8)128U));
    } else {
      rtb_Switch8_e = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)128U))));
    }

    /* End of Switch: '<S604>/Switch8' */

    /* Sum: '<S599>/Add' incorporates:
     *  ArithShift: '<S599>/Shift Arithmetic'
     *  ArithShift: '<S599>/Shift Arithmetic1'
     *  DataTypeConversion: '<S599>/Data Type Conversion'
     *  DataTypeConversion: '<S599>/Data Type Conversion1'
     *  DataTypeConversion: '<S599>/Data Type Conversion2'
     */
    rtb_Add = ((((uint32)rtb_Switch8_h) << 8) + ((uint32)rtb_Switch8)) +
      (((uint32)rtb_Switch8_e) << 16);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Fault_Reason = rtb_Add;

    /* DataTypeConversion: '<S338>/Cast2' */
    ob_LKA_Fault_Reason = rtb_Add;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_State_Mon = LKAS_DW.stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LDW_State_Mon = LKAS_DW.stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S140>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S145>/If' */
      if (((sint32)LKAS_DW.stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S145>/If Action Subsystem' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        /* Gain: '<S146>/rad to deg' incorporates:
         *  Gain: '<S146>/Gain'
         */
        LKAS_DW.Merge_pv = ((-1.0F) * rtb_phiHdAg_Lft) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S145>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S145>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        /* Gain: '<S147>/rad to deg' */
        LKAS_DW.Merge_pv = 57.2957802F * rtb_phiHdAg_Rgt;

        /* End of Outputs for SubSystem: '<S145>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S145>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_pv);

        /* End of Outputs for SubSystem: '<S145>/If Action Subsystem2' */
      }

      /* End of If: '<S145>/If' */

      /* Switch: '<S663>/Switch2' incorporates:
       *  Constant: '<S663>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_m != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_m;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S663>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S145>/Sum Condition' incorporates:
       *  EnablePort: '<S149>/Enable'
       */
      /* RelationalOperator: '<S145>/Relational Operator' */
      if (LKAS_DW.Merge_pv >= x10) {
        if (!LKAS_DW.SumCondition_MODE_g) {
          /* InitializeConditions for Memory: '<S149>/Memory' */
          LKAS_DW.Memory_PreviousInput_lr = 0.0F;
          LKAS_DW.SumCondition_MODE_g = true;
        }

        /* Sum: '<S149>/Add1' incorporates:
         *  Memory: '<S149>/Memory'
         */
        rtb_R0_C0_j = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_lr;

        /* Saturate: '<S149>/Saturation' */
        if (rtb_R0_C0_j > 0.6F) {
          rtb_R0_C0_j = 0.6F;
        } else {
          if (rtb_R0_C0_j < 0.0F) {
            rtb_R0_C0_j = 0.0F;
          }
        }

        /* End of Saturate: '<S149>/Saturation' */

        /* RelationalOperator: '<S149>/Relational Operator' incorporates:
         *  Constant: '<S145>/Constant'
         */
        LKAS_DW.RelationalOperator_oy = (rtb_R0_C0_j >= 0.05F);

        /* Update for Memory: '<S149>/Memory' */
        LKAS_DW.Memory_PreviousInput_lr = rtb_R0_C0_j;
      } else {
        if (LKAS_DW.SumCondition_MODE_g) {
          /* Disable for Outport: '<S149>/Out' */
          LKAS_DW.RelationalOperator_oy = false;
          LKAS_DW.SumCondition_MODE_g = false;
        }
      }

      /* End of RelationalOperator: '<S145>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S145>/Sum Condition' */

      /* Product: '<S140>/Product' incorporates:
       *  Logic: '<S140>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_oy) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S145>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_g) {
          /* Disable for Outport: '<S149>/Out' */
          LKAS_DW.RelationalOperator_oy = false;
          LKAS_DW.SumCondition_MODE_g = false;
        }

        /* End of Disable for SubSystem: '<S145>/Sum Condition' */

        /* Disable for Outport: '<S140>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* If: '<S466>/If' incorporates:
     *  Constant: '<S472>/Constant'
     *  Delay: '<S143>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_FDMMve_d_LkaFcnConf) != 1)) {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem' incorporates:
       *  ActionPort: '<S470>/Action Port'
       */
      LKAS_IfActionSubsystem_b(&rtb_Merge_j);

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_FDMMve_d_LkaFcnConf) != 3)) {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S471>/Action Port'
       */
      LKAS_IfActionSubsystem_b(&rtb_Merge_j);

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S472>/Action Port'
       */
      rtb_Merge_j = false;

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem3' */
    }

    /* End of If: '<S466>/If' */

    /* Outputs for Enabled SubSystem: '<S466>/Sum Condition1' */
    LKAS_SumCondition1(rtb_Merge_j, rtb_LKA_SampleTime,
                       rtb_LL_MAX_DELAY_EPSSTAR_TIME,
                       &LKAS_DW.RelationalOperator, &LKAS_DW.SumCondition1_j);

    /* End of Outputs for SubSystem: '<S466>/Sum Condition1' */

    /* SignalConversion: '<S525>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S437>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LogicalOperator_e;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_Compare_av;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_Compare_kq;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_gy;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_lg;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_ez;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_cy;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_kj;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_o;
    rtb_TmpSignalConversionAtSFunct[12] = rtb_stDvrTkConFlg_n;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_LogicalOperator_ac;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_lm;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_BCM_Left_Light;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge_g2;

    /* MATLAB Function: '<S437>/Disable Reason' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S525>:1' */
    /* '<S525>:1:2' y = single(0); */
    rtb_R0_C0_j = 0.0F;

    /* '<S525>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S525>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S525>:1:5' y = single(i); */
        rtb_R0_C0_j = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Disable_Reason = rtb_R0_C0_j;

    /* DataTypeConversion: '<S338>/Cast' */
    ob_LKA_Disable_Reason = rtb_R0_C0_j;

    /* RelationalOperator: '<S476>/Compare' incorporates:
     *  Constant: '<S476>/Constant'
     */
    rtb_Compare_h2 = (LKAS_DW.RelationalOperator == true);

    /* DataTypeConversion: '<S338>/Cast1' */
    ob_LKA_LKADeactvCSyn = (float32)(LKAS_DW.Merge1_j ? 1.0F : 0.0F);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LFTTTLC_Mon = rtb_LFTTTLC;

    /* Gain: '<S289>/Gain' incorporates:
     *  Sum: '<S289>/Add4'
     */
    rtb_phiHdAg = (rtb_phiHdAg_Lft + rtb_phiHdAg_Rgt) * 0.5F;

    /* Logic: '<S561>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S561>/Relational Operator3'
     *  RelationalOperator: '<S561>/Relational Operator4'
     */
    rtb_LogicalOperator1_ma = ((rtb_Gain1 <= rtb_LL_LKA_LatestWarnLine_C) ||
      (rtb_Add5_j <= rtb_LL_LKA_LatestWarnLine_C));

    /* Gain: '<S288>/Gain' incorporates:
     *  Sum: '<S288>/Add'
     */
    rtb_lDvt = (rtb_Gain1 + rtb_Add5_j) * 0.5F;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_Mode = LKAS_DW.LKA_Mode_k;

    /* Gain: '<S287>/Gain' incorporates:
     *  Sum: '<S287>/Add'
     */
    rtb_crCrvt = (rtb_L0_C2_f + rtb_R0_C2_b) * 0.5F;

    /* Delay: '<S143>/Delay1' */
    rtb_LKA_Mode = LKAS_DW.Delay1_2_DSTATE;
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S445>/ExitCount1' */
      if (LKAS_DW.ExitCount1.ExitCount_MODE) {
        LKAS_ExitCount_Disable(&LKAS_DW.RelationalOperator_b,
          &LKAS_DW.ExitCount1);
      }

      /* End of Disable for SubSystem: '<S445>/ExitCount1' */

      /* Disable for Enabled SubSystem: '<S445>/ExitCount' */
      if (LKAS_DW.ExitCount.ExitCount_MODE) {
        LKAS_ExitCount_Disable(&LKAS_DW.RelationalOperator_o, &LKAS_DW.ExitCount);
      }

      /* End of Disable for SubSystem: '<S445>/ExitCount' */

      /* Disable for Enabled SubSystem: '<S446>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S456>/Out' */
        LKAS_DW.RelationalOperator_i = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }

      /* End of Disable for SubSystem: '<S446>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S457>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S461>/Out' */
        LKAS_DW.RelationalOperator_g = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S457>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S384>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S415>/Out' */
        LKAS_DW.RelationalOperator_p = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S384>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S384>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S414>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S384>/Count' */

      /* Disable for Enabled SubSystem: '<S417>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_o3) {
        /* Disable for Outport: '<S423>/Out' */
        LKAS_DW.RelationalOperator_f = false;
        LKAS_DW.SumCondition1_MODE_o3 = false;
      }

      /* End of Disable for SubSystem: '<S417>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S385>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S429>/Out' */
        LKAS_DW.RelationalOperator_m = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }

      /* End of Disable for SubSystem: '<S385>/Sum Condition1' */

      /* Disable for If: '<S432>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S395>/Sum Condition' */
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S401>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition_MODE = false;
      }

      /* End of Disable for SubSystem: '<S395>/Sum Condition' */

      /* Disable for Enabled SubSystem: '<S320>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_p) {
        /* Disable for Outport: '<S324>/Out' */
        LKAS_DW.RelationalOperator_gd = false;
        LKAS_DW.Subsystem_MODE_p = false;
      }

      /* End of Disable for SubSystem: '<S320>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S188>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_bk) {
          /* Disable for Outport: '<S173>/Out' */
          LKAS_DW.RelationalOperator_ce = false;
          LKAS_DW.SumCondition1_MODE_bk = false;
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_n.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_g0,
            &LKAS_DW.SumCondition1_n);
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition' */
        if (LKAS_DW.SumCondition_o.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_ii,
            &LKAS_DW.SumCondition_o);
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S181>/Out' */
          LKAS_DW.RelationalOperator_d = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S158>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_m) {
          /* Disable for Outport: '<S162>/M4K' */
          LKAS_DW.Saturation3 = 1.0F;
          LKAS_DW.SumCondition2_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S158>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S150>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_h) {
          /* Disable for Outport: '<S159>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_j = 0.0F;
          LKAS_DW.Subsystem_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S150>/Subsystem' */

        /* Disable for If: '<S262>/If' */
        LKAS_DW.If_ActiveSubsystem_i = -1;

        /* Disable for Outport: '<S141>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S141>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S141>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S141>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_k = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_a = 0.0F;
        LKAS_DW.T1_Mon_h = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S145>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_g) {
          /* Disable for Outport: '<S149>/Out' */
          LKAS_DW.RelationalOperator_oy = false;
          LKAS_DW.SumCondition_MODE_g = false;
        }

        /* End of Disable for SubSystem: '<S145>/Sum Condition' */

        /* Disable for Outport: '<S140>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Enabled SubSystem: '<S466>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_j.SumCondition1_MODE) {
        LKAS_SumCondition1_Disable(&LKAS_DW.RelationalOperator,
          &LKAS_DW.SumCondition1_j);
      }

      /* End of Disable for SubSystem: '<S466>/Sum Condition1' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.LKA_Mode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MATLAB Function: '<S8>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S111>/Switch'
   *  Switch: '<S111>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S89>:1' */
  /* '<S89>:1:2' if stDACmode==1 */
  if (((sint32)LKAS_DW.LKA_Mode) == 1) {
    /* '<S89>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_IMAPve_d_LKA_Mode)
          != 3)) || (((sint32)rtb_R0_Q_c) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_IMAPve_d_LKA_Mode)
            != 3)) && (((sint32)rtb_R0_Q_c) == 3)) {
        /* '<S89>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:6' Vehicle_Lane_Display=uint8(4); */
        rtb_IMAPve_d_LKA_Mode = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:8' Vehicle_Lane_Display=uint8(5); */
        rtb_IMAPve_d_LKA_Mode = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) != 3))
      {
        /* '<S89>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S89>:1:10' Vehicle_Lane_Display=uint8(10); */
        rtb_IMAPve_d_LKA_Mode = 10U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) != 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:12' Vehicle_Lane_Display=uint8(11); */
        rtb_IMAPve_d_LKA_Mode = 11U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:14' Vehicle_Lane_Display=uint8(12); */
        rtb_IMAPve_d_LKA_Mode = 12U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:16' Vehicle_Lane_Display=uint8(13); */
        rtb_IMAPve_d_LKA_Mode = 13U;
      } else {
        /* '<S89>:1:17' else */
        /* '<S89>:1:18' Vehicle_Lane_Display=uint8(1); */
        rtb_IMAPve_d_LKA_Mode = 1U;
      }
    } else {
      /* '<S89>:1:4' Vehicle_Lane_Display=uint8(3); */
    }
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
              3)) {
    /* '<S89>:1:20' elseif stDACmode==2 || stDACmode==3 */
    /* '<S89>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_IMAPve_d_LKA_Mode)
          != 3)) || (((sint32)rtb_R0_Q_c) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_IMAPve_d_LKA_Mode)
            != 3)) && (((sint32)rtb_R0_Q_c) == 3)) {
        /* '<S89>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:24' Vehicle_Lane_Display=uint8(4); */
        rtb_IMAPve_d_LKA_Mode = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:26' Vehicle_Lane_Display=uint8(5); */
        rtb_IMAPve_d_LKA_Mode = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) != 3))
      {
        /* '<S89>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S89>:1:28' Vehicle_Lane_Display=uint8(6); */
        rtb_IMAPve_d_LKA_Mode = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) != 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:30' Vehicle_Lane_Display=uint8(7); */
        rtb_IMAPve_d_LKA_Mode = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:32' Vehicle_Lane_Display=uint8(8); */
        rtb_IMAPve_d_LKA_Mode = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:34' Vehicle_Lane_Display=uint8(9); */
        rtb_IMAPve_d_LKA_Mode = 9U;
      } else {
        /* '<S89>:1:35' else */
        /* '<S89>:1:36' Vehicle_Lane_Display=uint8(1); */
        rtb_IMAPve_d_LKA_Mode = 1U;
      }
    } else {
      /* '<S89>:1:22' Vehicle_Lane_Display=uint8(3); */
    }
  } else {
    /* '<S89>:1:38' else */
    /* '<S89>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_IMAPve_d_LKA_Mode = 0U;
  }

  /* End of MATLAB Function: '<S8>/Vehicle_Lane_Display' */

  /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S11>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_R0_Q_c = ((uint8)1U);
    break;

   case 1:
    rtb_R0_Q_c = ((uint8)1U);
    break;

   case 2:
    rtb_R0_Q_c = ((uint8)2U);
    break;

   case 3:
    rtb_R0_Q_c = ((uint8)3U);
    break;

   case 4:
    rtb_R0_Q_c = ((uint8)4U);
    break;

   case 5:
    rtb_R0_Q_c = ((uint8)4U);
    break;

   default:
    rtb_R0_Q_c = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S11>/Multiport Switch' */

  /* RelationalOperator: '<S654>/Compare' incorporates:
   *  Constant: '<S654>/Constant'
   */
  rtb_Merge_g2 = (rtb_R0_Q_c == ((uint8)4U));

  /* Switch: '<S11>/Switch1' incorporates:
   *  Constant: '<S11>/1'
   *  Constant: '<S11>/x0'
   */
  if (rtb_Merge_g2) {
    rtb_L0_Q = ((uint8)1U);
  } else {
    rtb_L0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S653>/Subsystem' incorporates:
   *  EnablePort: '<S660>/Enable'
   */
  if (((sint32)rtb_L0_Q) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S660>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S660>/Add' */
    rtb_L0_C2_f = LKAS_DW.OutputSWACmd - rtb_SW_Angle;

    /* Sum: '<S660>/Add1' incorporates:
     *  Constant: '<S660>/Ki'
     *  Delay: '<S660>/Delay1'
     *  Product: '<S660>/Product2'
     */
    rtb_R0_C0_j = (rtb_L0_C2_f * 0.0005F) + LKAS_DW.Delay1_DSTATE;

    /* Saturate: '<S660>/Saturation' */
    if (rtb_R0_C0_j > 0.5F) {
      rtb_R0_C0_j = 0.5F;
    } else {
      if (rtb_R0_C0_j < (-0.5F)) {
        rtb_R0_C0_j = (-0.5F);
      }
    }

    /* End of Saturate: '<S660>/Saturation' */

    /* Fcn: '<S660>/Fcn' */
    rtb_R0_C2_b = LKAS_DW.OutputSWACmd * LKAS_DW.OutputSWACmd;

    /* Sum: '<S660>/Add2' incorporates:
     *  Constant: '<S660>/Kp'
     *  Fcn: '<S660>/Fcn'
     *  Product: '<S660>/Product1'
     */
    LKAS_DW.in_trq = (((((rtb_R0_C2_b * LKAS_DW.OutputSWACmd) * 2.0e-6F) +
                        (rtb_R0_C2_b * -0.0005F)) + (LKAS_DW.OutputSWACmd *
      0.0505F)) + (rtb_L0_C2_f * 0.02F)) + rtb_R0_C0_j;

    /* Update for Delay: '<S660>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_R0_C0_j;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S660>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S653>/Subsystem' */

  /* Sum: '<S658>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S658>/Delay Input2'
   *
   * Block description for '<S658>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S658>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2_f = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S658>/delta rise limit' incorporates:
   *  Constant: '<S653>/Constant'
   *  SampleTimeMath: '<S658>/sample time'
   *
   * About '<S658>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_R0_C0_j = 5.0F * 0.01F;

  /* Product: '<S658>/delta fall limit' incorporates:
   *  Constant: '<S653>/Constant1'
   *  SampleTimeMath: '<S658>/sample time'
   *
   * About '<S658>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_R0_C2_b = (-5.0F) * 0.01F;

  /* Switch: '<S661>/Switch2' incorporates:
   *  Product: '<S658>/delta fall limit'
   *  Product: '<S658>/delta rise limit'
   *  RelationalOperator: '<S661>/LowerRelop1'
   *  RelationalOperator: '<S661>/UpperRelop'
   *  Switch: '<S661>/Switch'
   */
  if (rtb_L0_C2_f > rtb_R0_C0_j) {
    rtb_L0_C2_f = rtb_R0_C0_j;
  } else {
    if (rtb_L0_C2_f < rtb_R0_C2_b) {
      /* Switch: '<S661>/Switch' incorporates:
       *  Product: '<S658>/delta fall limit'
       */
      rtb_L0_C2_f = rtb_R0_C2_b;
    }
  }

  /* End of Switch: '<S661>/Switch2' */

  /* Sum: '<S658>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S658>/Delay Input2'
   *
   * Block description for '<S658>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S658>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2_f += LKAS_DW.DelayInput2_DSTATE;

  /* MATLAB Function: '<S8>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S85>:1' */
  /* '<S85>:1:2' if  LKA_Mode==1 && (LDW_Warn_Mode==0 || LDW_Warn_Mode==2) */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && ((((sint32)rtb_IMAPve_d_LDW_Warn_Mode)
        == 0) || (((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 2))) {
    /* '<S85>:1:3' if LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S85>:1:4' LDW_Flag=uint8(1); */
      rtb_Lrg_Q = 1U;
      break;

     case 2:
      /* '<S85>:1:5' elseif LDWWarnInfo==2 */
      /* '<S85>:1:6' LDW_Flag=uint8(2); */
      rtb_Lrg_Q = 2U;
      break;

     default:
      /* '<S85>:1:7' else */
      /* '<S85>:1:8' LDW_Flag=uint8(0); */
      rtb_Lrg_Q = 0U;
      break;
    }
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)
                rtb_IMAPve_d_LDW_Warn_Mode) == 0) || (((sint32)
                rtb_IMAPve_d_LDW_Warn_Mode) == 2))) {
    /* '<S85>:1:10' elseif (LKA_Mode==2) && (LDW_Warn_Mode==0 || LDW_Warn_Mode==2) */
    /* '<S85>:1:11' if LDWWarnInfo==1 && LKA_State==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S85>:1:12' LDW_Flag=uint8(1); */
      rtb_Lrg_Q = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S85>:1:13' elseif LDWWarnInfo==2 && LKA_State==5 */
      /* '<S85>:1:14' LDW_Flag=uint8(2); */
      rtb_Lrg_Q = 2U;
    } else {
      /* '<S85>:1:15' else */
      /* '<S85>:1:16' LDW_Flag=uint8(0); */
      rtb_Lrg_Q = 0U;
    }
  } else {
    /* '<S85>:1:18' else */
    /* '<S85>:1:19' LDW_Flag=uint8(0); */
    rtb_Lrg_Q = 0U;
  }

  /* End of MATLAB Function: '<S8>/LDW_Flag' */

  /* MATLAB Function: '<S8>/HapticAlarmReq' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HapticAlarmReq': '<S84>:1' */
  /* '<S84>:1:2' if  LDW_Flag==1 && (LDW_Warn_Mode == 1 || LDW_Warn_Mode == 2) */
  if ((((sint32)rtb_Lrg_Q) == 1) && ((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 1)
       || (((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 2))) {
    /* '<S84>:1:3' HapticAlarmReq= uint8(1); */
    rtb_IMAPve_d_LDW_Warn_Mode = 1U;
  } else {
    /* '<S84>:1:4' else */
    /* '<S84>:1:5' HapticAlarmReq= uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  }

  /* End of MATLAB Function: '<S8>/HapticAlarmReq' */

  /* MATLAB Function: '<S8>/Status_Display' */
  /*  ֻ��LDW����� */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Status_Display': '<S87>:1' */
  /* '<S87>:1:3' if (LKA_Mode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S87>:1:4' LDW_Status_Display=uint8(1); */
    rtb_Rrg_Q = 1U;

    /* '<S87>:1:5' LKA_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S87>:1:6' elseif (LKA_Mode==1)&&LDW_STATE==6 */
    /* '<S87>:1:7' LDW_Status_Display=uint8(2); */
    rtb_Rrg_Q = 2U;

    /* '<S87>:1:8' LKA_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;

    /*  ֻ��LKA����� */
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State)
              != 6)) {
    /* '<S87>:1:11' elseif  (LKA_Mode==2)&&LKA_STATE~=6 */
    /* '<S87>:1:12' LDW_Status_Display=uint8(0); */
    rtb_Rrg_Q = 0U;

    /* '<S87>:1:13' LKA_Status_Display=uint8(1); */
    rtb_TCU_ActualGear = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S87>:1:14' elseif (LKA_Mode==2)&&LKA_STATE==6 */
    /* '<S87>:1:15' LDW_Status_Display=uint8(0); */
    rtb_Rrg_Q = 0U;

    /* '<S87>:1:16' LKA_Status_Display=uint8(2); */
    rtb_TCU_ActualGear = 2U;
  } else {
    /* '<S87>:1:17' else */
    /* '<S87>:1:18' LDW_Status_Display=uint8(0); */
    rtb_Rrg_Q = 0U;

    /* '<S87>:1:19' LKA_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;
  }

  /* End of MATLAB Function: '<S8>/Status_Display' */

  /* Switch: '<S88>/Switch' incorporates:
   *  Constant: '<S90>/Constant'
   *  RelationalOperator: '<S90>/Compare'
   */
  if (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U)) {
    rtb_R0_C1_g = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  }

  /* End of Switch: '<S88>/Switch' */

  /* Logic: '<S88>/Logical Operator2' incorporates:
   *  Abs: '<S88>/Abs'
   *  Constant: '<S91>/Constant'
   *  Constant: '<S92>/Constant'
   *  Constant: '<S93>/Constant'
   *  Constant: '<S94>/Constant'
   *  Constant: '<S95>/Constant'
   *  Constant: '<S96>/Constant'
   *  Constant: '<S97>/Constant'
   *  Constant: '<S98>/Constant'
   *  Logic: '<S88>/Logical Operator1'
   *  Logic: '<S88>/Logical Operator3'
   *  RelationalOperator: '<S88>/Relational Operator'
   *  RelationalOperator: '<S91>/Compare'
   *  RelationalOperator: '<S92>/Compare'
   *  RelationalOperator: '<S93>/Compare'
   *  RelationalOperator: '<S94>/Compare'
   *  RelationalOperator: '<S95>/Compare'
   *  RelationalOperator: '<S96>/Compare'
   *  RelationalOperator: '<S97>/Compare'
   *  RelationalOperator: '<S98>/Compare'
   */
  rtb_LogicalOperator2 = ((((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (LKAS_DW.LKA_State == ((uint8)5U))) || (LKAS_DW.LKA_State == ((uint8)4U))) ||
    (LKAS_DW.LKA_State == ((uint8)3U))) && ((rtb_FDMMve_d_LkaFcnConf == ((uint8)
    3U)) || (rtb_FDMMve_d_LkaFcnConf == ((uint8)1U)))) && (fabsf
    (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_R0_C1_g));

  /* Switch: '<S665>/Switch2' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=2'
   *
   * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=2':
   *  ��ʻԱ���ֿ�ʼ����������������ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion2_g != 0.0F) {
    rtb_LL_HandsOff_WarnTime = LKAS_ConstB.DataTypeConversion2_g;
  } else {
    rtb_LL_HandsOff_WarnTime = LL_HandsOff_WarnTime;
  }

  /* End of Switch: '<S665>/Switch2' */

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition2' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_WarnTime, &LKAS_DW.RelationalOperator_g02,
                     &LKAS_DW.SumCondition2);

  /* End of Outputs for SubSystem: '<S88>/Sum Condition2' */

  /* MATLAB Function: '<S8>/Hands_Off_Warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_Off_Warning': '<S83>:1' */
  /* '<S83>:1:2' if HandsOff==0 */
  if (!LKAS_DW.RelationalOperator_g02) {
    /* '<S83>:1:3' Hands_Off_Warning= uint8(0); */
    rtb_FDMMve_d_LkaFcnConf = 0U;
  } else {
    /* '<S83>:1:4' elseif HandsOff==1 */
    /* '<S83>:1:5' Hands_Off_Warning= uint8(1); */
    rtb_FDMMve_d_LkaFcnConf = 1U;
  }

  /* End of MATLAB Function: '<S8>/Hands_Off_Warning' */

  /* Switch: '<S665>/Switch1' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=1'
   *
   * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=1':
   *  ��ʻԱ���ֿ�ʼ�����ܷ����������ѵ�ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_HandsOff_TextTime = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_HandsOff_TextTime = LL_HandsOff_TextTime;
  }

  /* End of Switch: '<S665>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_TextTime, &LKAS_DW.RelationalOperator_o2,
                     &LKAS_DW.SumCondition1);

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */

  /* MATLAB Function: '<S8>/HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1'
   *  Inport: '<Root>/IMAPve_d_Camera_Status'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S82>:1' */
  /* '<S82>:1:2' if (LKA_Mode==1||LKA_Mode==2)&&(Camera_Status==5) */
  if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2)) &&
      (((sint32)((uint8)
                 Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status
                 ())) == 5)) {
    /* ����ͷ���ڵ� */
    /* '<S82>:1:3' HMI_Popup_Status=uint8(4); */
    rtb_HMI_Popup_Status_f = 4U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) ==
    2)) && (LKAS_DW.RelationalOperator_o2)) {
    /* '<S82>:1:4' elseif (LKA_Mode==1||LKA_Mode==2) && HandsOff1_Text==1 */
    /* ���շ����� */
    /* '<S82>:1:5' HMI_Popup_Status=uint8(2); */
    rtb_HMI_Popup_Status_f = 2U;
  } else {
    /* '<S82>:1:6' else */
    /* '<S82>:1:7' HMI_Popup_Status=uint8(0); */
    rtb_HMI_Popup_Status_f = 0U;
  }

  /* End of MATLAB Function: '<S8>/HMI_Popup_Status' */

  /* MATLAB Function: '<S8>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S86>:1' */
  /* '<S86>:1:2' if LKA_Mode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S86>:1:3' LKA_Action_Indication=uint8(1); */
    rtb_LKA_Action_Indication_m = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S86>:1:4' elseif LKA_Mode==2&&LKA_STATE==3 */
    /* '<S86>:1:5' LKA_Action_Indication=uint8(2); */
    rtb_LKA_Action_Indication_m = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S86>:1:6' elseif LKA_Mode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S86>:1:7' LKA_Action_Indication=uint8(3); */
    rtb_LKA_Action_Indication_m = 3U;
  } else {
    /* '<S86>:1:8' else */
    /* '<S86>:1:9' LKA_Action_Indication=uint8(0); */
    rtb_LKA_Action_Indication_m = 0U;
  }

  /* End of MATLAB Function: '<S8>/LKA_action_indication' */

  /* DataTypeConversion: '<S11>/Cast To Single10' incorporates:
   *  Constant: '<S655>/Constant'
   *  RelationalOperator: '<S655>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.LKA_Mode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S4>/Cast To Single1' */
  LKAS_DW.CastToSingle1 = LKAS_DW.LFTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single2' */
  LKAS_DW.CastToSingle2 = LKAS_DW.RGTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single3' */
  LKAS_DW.CastToSingle3 = (float32)LKAS_DW.LDW_State_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single4' */
  LKAS_DW.CastToSingle4 = (float32)LKAS_DW.LKA_State_Mon;

  /* S-Function (scanpack): '<S4>/CAN Pack' */
  /* S-Function (scanpack): '<S4>/CAN Pack' */
  LKAS_DW.CANPack.ID = 1U;
  LKAS_DW.CANPack.Length = 8U;
  LKAS_DW.CANPack.Extended = 0U;
  LKAS_DW.CANPack.Remote = 0;
  LKAS_DW.CANPack.Data[0] = 0;
  LKAS_DW.CANPack.Data[1] = 0;
  LKAS_DW.CANPack.Data[2] = 0;
  LKAS_DW.CANPack.Data[3] = 0;
  LKAS_DW.CANPack.Data[4] = 0;
  LKAS_DW.CANPack.Data[5] = 0;
  LKAS_DW.CANPack.Data[6] = 0;
  LKAS_DW.CANPack.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle1;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[1] = LKAS_DW.CANPack.Data[1] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[0] = LKAS_DW.CANPack.Data[0] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle2;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[3] = LKAS_DW.CANPack.Data[3] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[2] = LKAS_DW.CANPack.Data[2] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle3;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[5] = LKAS_DW.CANPack.Data[5] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[4] = LKAS_DW.CANPack.Data[4] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle4;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[7] = LKAS_DW.CANPack.Data[7] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[6] = LKAS_DW.CANPack.Data[6] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single5' */
  LKAS_DW.CastToSingle5 = LKAS_DW.LKA_ExitFlg_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single6' */
  LKAS_DW.CastToSingle6 = LKAS_DW.LKA_SampleTime_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single7' */
  LKAS_DW.CastToSingle7 = LKAS_DW.T1_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single8' */
  LKAS_DW.CastToSingle8 = LKAS_DW.Disable_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  LKAS_DW.CANPack1.ID = 2U;
  LKAS_DW.CANPack1.Length = 8U;
  LKAS_DW.CANPack1.Extended = 0U;
  LKAS_DW.CANPack1.Remote = 0;
  LKAS_DW.CANPack1.Data[0] = 0;
  LKAS_DW.CANPack1.Data[1] = 0;
  LKAS_DW.CANPack1.Data[2] = 0;
  LKAS_DW.CANPack1.Data[3] = 0;
  LKAS_DW.CANPack1.Data[4] = 0;
  LKAS_DW.CANPack1.Data[5] = 0;
  LKAS_DW.CANPack1.Data[6] = 0;
  LKAS_DW.CANPack1.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle5;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[1] = LKAS_DW.CANPack1.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[0] = LKAS_DW.CANPack1.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle6;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[3] = LKAS_DW.CANPack1.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[2] = LKAS_DW.CANPack1.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle7;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[5] = LKAS_DW.CANPack1.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[4] = LKAS_DW.CANPack1.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle8;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[7] = LKAS_DW.CANPack1.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[6] = LKAS_DW.CANPack1.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single9' */
  LKAS_DW.CastToSingle9 = (float32)LKAS_DW.Fault_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack2' */
  /* S-Function (scanpack): '<S4>/CAN Pack2' */
  LKAS_DW.CANPack2.ID = 3U;
  LKAS_DW.CANPack2.Length = 8U;
  LKAS_DW.CANPack2.Extended = 0U;
  LKAS_DW.CANPack2.Remote = 0;
  LKAS_DW.CANPack2.Data[0] = 0;
  LKAS_DW.CANPack2.Data[1] = 0;
  LKAS_DW.CANPack2.Data[2] = 0;
  LKAS_DW.CANPack2.Data[3] = 0;
  LKAS_DW.CANPack2.Data[4] = 0;
  LKAS_DW.CANPack2.Data[5] = 0;
  LKAS_DW.CANPack2.Data[6] = 0;
  LKAS_DW.CANPack2.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle9;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[1] = LKAS_DW.CANPack2.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[0] = LKAS_DW.CANPack2.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle10;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[3] = LKAS_DW.CANPack2.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[2] = LKAS_DW.CANPack2.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle21;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[5] = LKAS_DW.CANPack2.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[4] = LKAS_DW.CANPack2.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle22;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[7] = LKAS_DW.CANPack2.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[6] = LKAS_DW.CANPack2.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack' */
    if ((8 == LKAS_DW.CANPack.Length) && (LKAS_DW.CANPack.ID != INVALID_CAN_ID) )
    {
      if ((1 == LKAS_DW.CANPack.ID) && (0U == LKAS_DW.CANPack.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
    if ((8 == LKAS_DW.CANPack1.Length) && (LKAS_DW.CANPack1.ID != INVALID_CAN_ID)
        ) {
      if ((2 == LKAS_DW.CANPack1.ID) && (0U == LKAS_DW.CANPack1.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
    if ((8 == LKAS_DW.CANPack2.Length) && (LKAS_DW.CANPack2.ID != INVALID_CAN_ID)
        ) {
      if ((3 == LKAS_DW.CANPack2.ID) && (0U == LKAS_DW.CANPack2.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack2.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack2.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07L_100 = result;
            }
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S12>/Cast To Boolean37' incorporates:
   *  DataTypeConversion: '<S41>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_14B_InvOorReal = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean38' incorporates:
   *  DataTypeConversion: '<S42>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxN = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean39' incorporates:
   *  DataTypeConversion: '<S43>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxT = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean40' incorporates:
   *  DataTypeConversion: '<S44>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinN = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean41' incorporates:
   *  DataTypeConversion: '<S45>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinT = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean' incorporates:
   *  DataTypeConversion: '<S53>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_ACU_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean10' incorporates:
   *  DataTypeConversion: '<S55>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_EPB_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean11' incorporates:
   *  DataTypeConversion: '<S56>/Extract Desired Bits'
   */
  rtb_ADIA_Inner_FRadar_FaultStat = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean12' incorporates:
   *  DataTypeConversion: '<S57>/Extract Desired Bits'
   */
  rtb_ADIAve_d_sen_sta_Corner_rad = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S61>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_EMS_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean6' incorporates:
   *  DataTypeConversion: '<S62>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_IC_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S63>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_TBOX_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean1' incorporates:
   *  DataTypeConversion: '<S16>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC_EPBErrorStatus = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean13' incorporates:
   *  DataTypeConversion: '<S20>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorTCS = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean14' incorporates:
   *  DataTypeConversion: '<S21>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorVeh = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean15' incorporates:
   *  DataTypeConversion: '<S22>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorLat = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean17' incorporates:
   *  DataTypeConversion: '<S40>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_MP5_366_OorAEBButt = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean18' incorporates:
   *  DataTypeConversion: '<S25>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_MP5_366_OorFCWButt = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean19' incorporates:
   *  DataTypeConversion: '<S26>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_SAS_A5_InvOorSteAn = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean21' incorporates:
   *  DataTypeConversion: '<S23>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorLon = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean22' incorporates:
   *  DataTypeConversion: '<S24>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorSta = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean23' incorporates:
   *  DataTypeConversion: '<S32>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorYaw = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean24' incorporates:
   *  DataTypeConversion: '<S33>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvOorDyn = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean25' incorporates:
   *  DataTypeConversion: '<S34>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvUnfilY = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean26' incorporates:
   *  DataTypeConversion: '<S35>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehDri = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean27' incorporates:
   *  DataTypeConversion: '<S36>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehHol = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean28' incorporates:
   *  DataTypeConversion: '<S37>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_GW_MP5_413_OorISAM = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean29' incorporates:
   *  DataTypeConversion: '<S29>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_SCC_309_OorACCButt = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean35' incorporates:
   *  DataTypeConversion: '<S30>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_TCU1_93_InvOorGear = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean4' incorporates:
   *  DataTypeConversion: '<S47>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_BCM3_33C_InvBrkLig = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S48>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_14A_OorACCStat = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean6' incorporates:
   *  DataTypeConversion: '<S49>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS10_88_InvAccPed = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S50>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS5_E0_InvOorBrkP = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean8' incorporates:
   *  DataTypeConversion: '<S51>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS5_E0_OorEngineS = (rtb_L0_C0_g != 0.0F);

  /* Switch: '<S119>/Switch3' incorporates:
   *  Constant: '<S119>/Constant'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S131>:1' */
  /* '<S131>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S131>:1:3' cur=min(single(0.004),cur); */
  /* '<S131>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S131>:1:5' offset=min(single(0.5),offset); */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    /* DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     */
    rtb_L1_Q_a = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q
      ();

    /* Switch: '<S113>/Switch1' incorporates:
     *  Constant: '<S113>/Constant1'
     */
    if (rtb_L1_Q_a >= ((uint8)2U)) {
      rtb_L1_Q = (uint16)((uint8)3U);
    } else {
      rtb_L1_Q = (uint16)rtb_L1_Q_a;
    }

    /* End of Switch: '<S113>/Switch1' */
  } else {
    rtb_L1_Q = ((uint16)0U);
  }

  /* End of Switch: '<S119>/Switch3' */

  /* Switch: '<S121>/Switch3' incorporates:
   *  Constant: '<S121>/Constant'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    /* DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    rtb_L1_Q_a = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q
      ();

    /* Switch: '<S114>/Switch1' incorporates:
     *  Constant: '<S114>/Constant1'
     */
    if (rtb_L1_Q_a >= ((uint8)2U)) {
      rtb_R1_Q = (uint16)((uint8)3U);
    } else {
      rtb_R1_Q = (uint16)rtb_L1_Q_a;
    }

    /* End of Switch: '<S114>/Switch1' */
  } else {
    rtb_R1_Q = ((uint16)0U);
  }

  /* End of Switch: '<S121>/Switch3' */

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_VR_End_BACK_1'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   *  Inport: '<Root>/IMAPve_g_Rrg_VR_End_BACK'
   */
  if (rtb_RFlg) {
    rtb_R0_C1_g = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_VR_End_BACK_IMAPve_g_Rrg_VR_End_BACK
      ();
  } else {
    rtb_R0_C1_g = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR();
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_VR_End_BACK_1'
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   *  Inport: '<Root>/IMAPve_g_Lrg_VR_End_BACK'
   */
  if (rtb_LFlg) {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_VR_End_BACK_IMAPve_g_Lrg_VR_End_BACK
      ();
  } else {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR();
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_VR_p = rtb_R0_C1_g;
  } else {
    rtb_R0_VR_p = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_b = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  } else {
    rtb_L0_VR_b = rtb_R0_C1_g;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_Rrg_TYPE_BACK_1'
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   *  Inport: '<Root>/IMAPve_d_Rrg_TYPE_BACK'
   */
  if (rtb_RFlg) {
    rtb_L1_Q_a = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Rrg_TYPE_BACK_IMAPve_d_Rrg_TYPE_BACK
      ();
  } else {
    rtb_L1_Q_a = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type();
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_Lrg_TYPE_BACK_1'
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   *  Inport: '<Root>/IMAPve_d_Lrg_TYPE_BACK'
   */
  if (rtb_LFlg) {
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Lrg_TYPE_BACK_IMAPve_d_Lrg_TYPE_BACK
      ();
  } else {
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type();
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_o = rtb_L1_Q_a;
  } else {
    rtb_R0_Type_o = rtb_L0_Type;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_k = rtb_L0_Type;
  } else {
    rtb_L0_Type_k = rtb_L1_Q_a;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  if (rtb_RFlg) {
    rtb_R0_C1_g = 0.0F;
  } else {
    rtb_R0_C1_g = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W();
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_W_1'
   *  Inport: '<Root>/IMAPve_g_L0_W'
   */
  if (rtb_LFlg) {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = 0.0F;
  } else {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W();
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_f = rtb_R0_C1_g;
  } else {
    rtb_R0_W_f = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_f = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  } else {
    rtb_L0_W_f = rtb_R0_C1_g;
  }

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_LCAWarning_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_LCAWarning'
   */
  rtb_EWWWve_y_BSD_LCAWarning = (uint8)
    Rte_IRead_Runnable_LKAS_Step_EWWWve_y_BSD_LCAWarning_EWWWve_y_BSD_LCAWarning
    ();

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_LCWWorkingSt_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_LCWWorkingSt'
   */
  rtb_EWWWve_y_BSD_LCWWorkingSt = (uint8)
    Rte_IRead_Runnable_LKAS_Step_EWWWve_y_BSD_LCWWorkingSt_EWWWve_y_BSD_LCWWorkingSt
    ();

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_S_LCAWarning_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_S_LCAWarning'
   */
  rtb_EWWWve_y_BSD_S_LCAWarning = (uint8)
    Rte_IRead_Runnable_LKAS_Step_EWWWve_y_BSD_S_LCAWarning_EWWWve_y_BSD_S_LCAWarning
    ();

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_S_LCWWorkingSt_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_S_LCWWorkingSt'
   */
  rtb_EWWWve_y_BSD_S_LCWWorkingSt = (uint8)
    Rte_IRead_Runnable_LKAS_Step_EWWWve_y_BSD_S_LCWWorkingSt_EWWWve_y_BSD_S_LCWWorkingSt
    ();

  /* DataTypeConversion: '<S1>/FDMMve_d_ElkFcnConf_1' incorporates:
   *  Inport: '<Root>/FDMMve_d_ElkFcnConf'
   */
  rtb_FDMMve_d_ElkFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_FDMMve_d_ElkFcnConf_FDMMve_d_ElkFcnConf();

  /* DataTypeConversion: '<S1>/IMAPve_d_APA_AutoPark_WorkSt_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_APA_AutoPark_WorkSt'
   */
  rtb_IMAPve_d_APA_AutoPark_WorkS = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp_Switch'
   */
  rtb_IMAPve_d_BCM_HazardLamp_Swi = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_Switch_IMAPve_d_BCM_HazardLamp_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ELK_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ELK_Switch'
   */
  rtb_IMAPve_d_ELK_Switch = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ELK_Switch_IMAPve_d_ELK_Switch();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Override'
   */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_ESA_State'
   */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State'
   */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag'
   */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_TrqLim_State'
   */
  rtb_IMAPve_d_EPS_TrqLim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Trq_State'
   */
  rtb_IMAPve_d_EPS_Trq_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid'
   */
  rtb_IMAPve_d_ESC_VehSpd_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid'
   */
  rtb_IMAPve_d_ESC_YawRate_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Fusion_Status'
   */
  rtb_IMAPve_d_Fusion_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status();

  /* DataTypeConversion: '<S110>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   */
  rtb_L1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_Work_State'
   */
  rtb_IMAPve_d_MP5_Work_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State
    ();

  /* DataTypeConversion: '<S110>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   */
  rtb_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SAS_Clb_State'
   */
  rtb_IMAPve_d_SAS_Clb_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SAS_Trim_State'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SWS_Failure_Status'
   */
  rtb_IMAPve_d_SWS_Failure_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Sensor_Status'
   */
  rtb_IMAPve_d_Sensor_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_TCU_Available'
   */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_obj_Num_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_obj_Num'
   */
  rtb_IMAPve_d_obj_Num = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_obj_Num_IMAPve_d_obj_Num();

  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  rtb_IMAPve_g_EMS_RealPedal = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  rtb_IMAPve_g_EPS_LKA_Current = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  rtb_IMAPve_g_ESC_Brake_Press = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  rtb_IMAPve_g_ESC_UnYawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  rtb_IMAPve_g_ESC_YawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate();

  /* DataTypeConversion: '<S110>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   *  UnaryMinus: '<S110>/Unary Minus8'
   */
  rtb_L1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   *  UnaryMinus: '<S110>/Unary Minus9'
   */
  rtb_L1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   *  UnaryMinus: '<S110>/Unary Minus10'
   */
  rtb_L1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   *  UnaryMinus: '<S110>/Unary Minus11'
   */
  rtb_L1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single78' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  rtb_L1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR();

  /* DataTypeConversion: '<S110>/Cast To Single74' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  rtb_L1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W();

  /* DataTypeConversion: '<S110>/Cast To Single4' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_VR_Start_BACK_1'
   *  Inport: '<Root>/IMAPve_g_Lrg_VR_Start_BACK'
   */
  rtb_R1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_VR_Start_BACK_IMAPve_g_Lrg_VR_Start_BACK
    ();

  /* DataTypeConversion: '<S110>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   *  UnaryMinus: '<S110>/Unary Minus14'
   */
  rtb_R1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   *  UnaryMinus: '<S110>/Unary Minus15'
   */
  rtb_R1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   *  UnaryMinus: '<S110>/Unary Minus12'
   */
  rtb_R1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   *  UnaryMinus: '<S110>/Unary Minus13'
   */
  rtb_R1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single50' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  rtb_R1_VR_i = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR();

  /* DataTypeConversion: '<S110>/Cast To Single52' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  rtb_R1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W();

  /* DataTypeConversion: '<S110>/Cast To Single12' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_VR_Start_BACK_1'
   *  Inport: '<Root>/IMAPve_g_Rrg_VR_Start_BACK'
   */
  rtb_R1_VR_d = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_VR_Start_BACK_IMAPve_g_Rrg_VR_Start_BACK
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  rtb_IMAPve_g_SW_Angle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle();

  /* Switch: '<S664>/Switch1' incorporates:
   *  Constant: '<S664>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1_g != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1_g;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S664>/Switch1' */

  /* Switch: '<S664>/Switch15' incorporates:
   *  Constant: '<S664>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    rtb_LL_lStpLngth_C = LKAS_ConstB.DataTypeConversion21;
  } else {
    rtb_LL_lStpLngth_C = LL_lStpLngth_C;
  }

  /* End of Switch: '<S664>/Switch15' */

  /* Switch: '<S664>/Switch10' incorporates:
   *  Constant: '<S664>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22_f != 0.0F) {
    rtb_LL_DesDvt_C = LKAS_ConstB.DataTypeConversion22_f;
  } else {
    rtb_LL_DesDvt_C = LL_DesDvt_C;
  }

  /* End of Switch: '<S664>/Switch10' */

  /* Switch: '<S664>/Switch12' incorporates:
   *  Constant: '<S664>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23_d != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23_d;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S664>/Switch12' */

  /* Switch: '<S664>/Switch16' incorporates:
   *  Constant: '<S664>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24_p != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24_p;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S664>/Switch16' */

  /* Switch: '<S665>/Switch56' incorporates:
   *  Constant: '<S665>/LLSMConClb14'
   *
   * Block description for '<S665>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_g != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_g;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S665>/Switch56' */

  /* Switch: '<S665>/Switch51' incorporates:
   *  Constant: '<S665>/LLSMConClb15'
   *
   * Block description for '<S665>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_g != 0.0F) {
    rtb_LL_DvtComp_C_i = LKAS_ConstB.DataTypeConversion25_g;
  } else {
    rtb_LL_DvtComp_C_i = LL_DvtComp_C;
  }

  /* End of Switch: '<S665>/Switch51' */

  /* Switch: '<S665>/Switch52' incorporates:
   *  Constant: '<S665>/LLSMConClb16'
   *
   * Block description for '<S665>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36_d != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36_d;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S665>/Switch52' */

  /* Switch: '<S665>/Switch57' incorporates:
   *  Constant: '<S665>/LLSMConClb18'
   *
   * Block description for '<S665>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S665>/Switch57' */

  /* Switch: '<S665>/Switch46' incorporates:
   *  Constant: '<S665>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S665>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_h != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_h;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S665>/Switch46' */

  /* Abs: '<S123>/Abs' incorporates:
   *  Sum: '<S123>/Add2'
   */
  rtb_LftTTLC = fabsf(rtb_L0_C0 + rtb_R0_C2);

  /* Saturate: '<S123>/Saturation' */
  if (rtb_LftTTLC > 0.004F) {
    rtb_LftTTLC = 0.004F;
  } else {
    if (rtb_LftTTLC < 0.0F) {
      rtb_LftTTLC = 0.0F;
    }
  }

  /* End of Saturate: '<S123>/Saturation' */

  /* Update for Memory: '<S123>/Memory1' incorporates:
   *  MATLAB Function: '<S123>/get_roadside_offset'
   */
  LKAS_DW.Memory1_PreviousInput = fminf(0.5F, (((fminf(0.004F, rtb_LftTTLC) /
    0.004F) + 1.0F) * 0.2F) * (fminf(4.0F, rtb_R0_C0) - 2.0F));

  /* Update for Delay: '<S128>/Delay' */
  LKAS_DW.Delay_DSTATE = rtb_R0_C0;

  /* Update for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Abs_ka;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S142>/Delay' */
    LKAS_DW.Delay_DSTATE_c = LKAS_DW.stLKAActvFlg;

    /* Update for Memory: '<S587>/Memory' */
    LKAS_DW.Memory_PreviousInput_a = rtb_Saturation_f;

    /* Update for Delay: '<S143>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.stLKAState;

    /* Update for Memory: '<S527>/Memory' */
    LKAS_DW.Memory_PreviousInput_f = rtb_Saturation_e;

    /* Update for Memory: '<S445>/Memory' */
    LKAS_DW.Memory_PreviousInput_d = rtb_IMAPve_g_EPS_SW_Trq;

    /* Update for UnitDelay: '<S458>/Delay Input1'
     *
     * Block description for '<S458>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_f2;

    /* Update for UnitDelay: '<S457>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_e = LKAS_DW.RelationalOperator_g;

    /* Update for UnitDelay: '<S419>/Delay Input1'
     *
     * Block description for '<S419>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_h = rtb_Compare_nn;

    /* Update for UnitDelay: '<S417>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_jz = LKAS_DW.RelationalOperator_f;

    /* Update for UnitDelay: '<S418>/Delay Input1'
     *
     * Block description for '<S418>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_k = rtb_Compare_mh;

    /* Update for Memory: '<S384>/Memory' */
    LKAS_DW.Memory_PreviousInput_cb = LKAS_DW.RelationalOperator_f;

    /* Update for Delay: '<S143>/Delay' */
    LKAS_DW.Delay_DSTATE_p = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S143>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.stLDWState;

    /* Update for Memory: '<S432>/Memory' */
    LKAS_DW.Memory_PreviousInput_io = rtb_LDW_State;

    /* Update for Memory: '<S358>/Memory' */
    LKAS_DW.Memory_PreviousInput_j = rtb_Merge1_c;

    /* Update for Memory: '<S394>/Memory' */
    LKAS_DW.Memory_PreviousInput_c = rtb_Merge1_d;

    /* Update for Memory: '<S601>/Memory' */
    LKAS_DW.Memory_PreviousInput_ce = rtb_Saturation_j;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S170>/Memory' */
      LKAS_DW.Memory_PreviousInput_oi = rtb_Saturation2_l;

      /* Update for Memory: '<S201>/Memory' */
      LKAS_DW.Memory_PreviousInput_od = rtb_Saturation1_l;

      /* Update for Memory: '<S188>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_p = rtb_Saturation1_k;

      /* Update for Memory: '<S200>/Memory' */
      LKAS_DW.Memory_PreviousInput_nn = rtb_Saturation1_p;

      /* Update for Memory: '<S202>/Memory' */
      LKAS_DW.Memory_PreviousInput_nt = rtb_Saturation1_pr;

      /* Update for Memory: '<S197>/Memory' */
      LKAS_DW.Memory_PreviousInput_o5 = rtb_Saturation1_b;

      /* Update for Memory: '<S185>/Memory' */
      LKAS_DW.Memory_PreviousInput_mm = rtb_Add_lk;

      /* Update for Memory: '<S171>/Memory' */
      LKAS_DW.Memory_PreviousInput_fx = rtb_Saturation2_la;

      /* Update for Memory: '<S172>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = rtb_Saturation2_d;

      /* Update for UnitDelay: '<S174>/Delay Input1'
       *
       * Block description for '<S174>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_d = rtb_Compare_nye;

      /* Update for Memory: '<S172>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_l = rtb_Merge_c;

      /* Update for Memory: '<S163>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_m = rtb_Saturation_fc;

      /* Update for Memory: '<S264>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_k = rtb_Saturation_h;

      /* Update for Memory: '<S247>/Memory' */
      LKAS_DW.Memory_PreviousInput_mk = rtb_Add1_d3;

      /* Update for UnitDelay: '<S245>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_i = rtb_Switch2_bi;

      /* Update for Memory: '<S253>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_m1 = rtb_Saturation_em;

      /* Update for Memory: '<S259>/Memory' */
      LKAS_DW.Memory_PreviousInput_nv = rtb_Saturation1_pb;

      /* Update for UnitDelay: '<S263>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_m = rtb_Switch_n0;

      /* Update for Memory: '<S263>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_k4 = rtb_Saturation_fj;

      /* Update for UnitDelay: '<S240>/Delay Input2'
       *
       * Block description for '<S240>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_m = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S240>/Memory' */
      LKAS_DW.Memory_PreviousInput_no = rtb_Saturation2_g;

      /* Update for Memory: '<S196>/Memory' */
      LKAS_DW.Memory_PreviousInput_n2 = rtb_Add_m5;

      /* Update for Memory: '<S198>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = rtb_Saturation1_d;

      /* Update for Memory: '<S199>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = rtb_Saturation1_c;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S602>/Delay' */
    LKAS_DW.Delay_DSTATE_o = rtb_Switch8;

    /* Update for Delay: '<S603>/Delay' */
    LKAS_DW.Delay_DSTATE_d = rtb_Switch8_h;

    /* Update for Delay: '<S604>/Delay' */
    LKAS_DW.Delay_DSTATE_ci = rtb_Switch8_e;

    /* Update for Delay: '<S143>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.LKA_Mode_k;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S658>/Delay Input2'
   *
   * Block description for '<S658>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_L0_C2_f;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_IMAPve_d_LKA_Mode);

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_Rrg_Q);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single2'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)rtb_TCU_ActualGear);

  /* Outport: '<Root>/LKASve_y_ELK_Status_Display' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single16'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_ELK_Status_Display_LKASve_y_ELK_Status_Display
    (LKAS_ConstB.ELK_Status_Display);

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single3'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    rtb_Lrg_Q);

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single4'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning
    ((UInt8)rtb_FDMMve_d_LkaFcnConf);

  /* Outport: '<Root>/LKASve_y_HapticAlarmReq' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single8'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HapticAlarmReq_LKASve_y_HapticAlarmReq
    ((UInt8)rtb_IMAPve_d_LDW_Warn_Mode);

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single5'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_LKA_Action_Indication_m);

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single6'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status
    ((UInt8)rtb_HMI_Popup_Status_f);

  /* Outport: '<Root>/LKASve_y_HMI_ELKPopupMessage' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single14'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_ELKPopupMessage_LKASve_y_HMI_ELKPopupMessage
    (LKAS_ConstB.HMI_ELKPopupMessage);

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq
    ((UInt8)rtb_L0_Q);

  /* Switch: '<S659>/Switch2' incorporates:
   *  Constant: '<S653>/Constant3'
   *  Constant: '<S653>/Constant4'
   *  RelationalOperator: '<S659>/LowerRelop1'
   *  RelationalOperator: '<S659>/UpperRelop'
   *  Switch: '<S659>/Switch'
   */
  if (rtb_L0_C2_f > 5.0F) {
    rtb_L0_C2_f = 5.0F;
  } else {
    if (rtb_L0_C2_f < (-5.0F)) {
      /* Switch: '<S659>/Switch' incorporates:
       *  Constant: '<S653>/Constant4'
       */
      rtb_L0_C2_f = (-5.0F);
    }
  }

  /* End of Switch: '<S659>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_L0_C2_f);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single8'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control
    ((UInt8)rtb_R0_Q_c);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/x1'
   */
  if (rtb_Merge_g2) {
    rtb_L0_C0 = LKAS_DW.OutputM;
  } else {
    rtb_L0_C0 = (float32)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_L0_C0);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S11>/Switch2' incorporates:
   *  Constant: '<S11>/2'
   *  Constant: '<S11>/x2'
   *  Constant: '<S656>/Constant'
   *  Constant: '<S657>/Constant'
   *  Logic: '<S11>/Logical Operator'
   *  RelationalOperator: '<S656>/Compare'
   *  RelationalOperator: '<S657>/Compare'
   */
  if ((rtb_R0_Q_c == ((uint8)4U)) || (rtb_R0_Q_c == ((uint8)3U))) {
    rtb_R0_Q_c = ((uint8)1U);
  } else {
    rtb_R0_Q_c = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    ((UInt8)rtb_R0_Q_c);

  /* Outport: '<Root>/LKASve_g_ob5H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5H_10_LKASve_g_ob5H_10
    (LKAS_DW.LKASve_g_ob5H_10);

  /* Outport: '<Root>/LKASve_g_ob5L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5L_10_LKASve_g_ob5L_10
    (LKAS_DW.LKASve_g_ob5L_10);

  /* Outport: '<Root>/LKASve_g_ob6H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6H_10_LKASve_g_ob6H_10
    (LKAS_DW.LKASve_g_ob6H_10);

  /* Outport: '<Root>/LKASve_g_ob6L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6L_10_LKASve_g_ob6L_10
    (LKAS_DW.LKASve_g_ob6L_10);

  /* Outport: '<Root>/LKASve_g_ob07H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07H_100_LKASve_g_ob07H_100
    (LKAS_DW.LKASve_g_ob07H_100);

  /* Outport: '<Root>/LKASve_g_ob07L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07L_100_LKASve_g_ob07L_100
    (LKAS_DW.LKASve_g_ob07L_100);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_g_ob08H_100' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single26'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08H_100_LKASve_g_ob08H_100((UInt32)
    ((uint32)rtb_L0_C0_g));

  /* Outport: '<Root>/LKASve_g_ob08L_100' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single23'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08L_100_LKASve_g_ob08L_100((UInt32)
    ((uint32)rtb_R0_C3));

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S432>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S188>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S262>/If' */
  LKAS_DW.If_ActiveSubsystem_i = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack' */

  /*-----------S-Function Block: <S4>/CAN Unpack -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack1' */

  /*-----------S-Function Block: <S4>/CAN Unpack1 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack2' */

  /*-----------S-Function Block: <S4>/CAN Unpack2 -----------------*/

  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* ConstCode for Constant: '<S2>/Version' */
  ob_LKA_Version = 220414.0F;

  /* End of ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S142>/Delay' */
  LKAS_DW.Delay_DSTATE_c = ((uint8)0U);

  /* InitializeConditions for Memory: '<S587>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = 0.0F;

  /* InitializeConditions for Delay: '<S143>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S527>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = 0.0F;

  /* InitializeConditions for Memory: '<S445>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* InitializeConditions for UnitDelay: '<S458>/Delay Input1'
   *
   * Block description for '<S458>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S457>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_e = false;

  /* InitializeConditions for UnitDelay: '<S419>/Delay Input1'
   *
   * Block description for '<S419>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_h = false;

  /* InitializeConditions for UnitDelay: '<S417>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_jz = false;

  /* InitializeConditions for UnitDelay: '<S418>/Delay Input1'
   *
   * Block description for '<S418>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_k = false;

  /* InitializeConditions for Memory: '<S384>/Memory' */
  LKAS_DW.Memory_PreviousInput_cb = false;

  /* InitializeConditions for Delay: '<S143>/Delay' */
  LKAS_DW.Delay_DSTATE_p = false;

  /* InitializeConditions for Delay: '<S143>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S432>/Memory' */
  LKAS_DW.Memory_PreviousInput_io = ((uint8)0U);

  /* InitializeConditions for Memory: '<S358>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = 0.0F;

  /* InitializeConditions for Memory: '<S394>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 0.0F;

  /* InitializeConditions for Memory: '<S601>/Memory' */
  LKAS_DW.Memory_PreviousInput_ce = 0.0F;

  /* InitializeConditions for Delay: '<S602>/Delay' */
  LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

  /* InitializeConditions for Delay: '<S603>/Delay' */
  LKAS_DW.Delay_DSTATE_d = ((uint8)0U);

  /* InitializeConditions for Delay: '<S604>/Delay' */
  LKAS_DW.Delay_DSTATE_ci = ((uint8)0U);

  /* InitializeConditions for Delay: '<S143>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S445>/ExitCount1' */
  LKAS_ExitCount_Init(&LKAS_DW.ExitCount1);

  /* End of SystemInitialize for SubSystem: '<S445>/ExitCount1' */

  /* SystemInitialize for Enabled SubSystem: '<S445>/ExitCount' */
  LKAS_ExitCount_Init(&LKAS_DW.ExitCount);

  /* End of SystemInitialize for SubSystem: '<S445>/ExitCount' */

  /* SystemInitialize for Enabled SubSystem: '<S446>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S456>/Memory' */
  LKAS_DW.Memory_PreviousInput_oq = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S446>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S457>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S461>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S457>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S384>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S415>/Memory' */
  LKAS_DW.Memory_PreviousInput_do = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S384>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S384>/Count' */
  /* InitializeConditions for Memory: '<S414>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S384>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S417>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S423>/Memory' */
  LKAS_DW.Memory_PreviousInput_j3 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S417>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S385>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S429>/Memory' */
  LKAS_DW.Memory_PreviousInput_jz = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S385>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S432>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S463>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S432>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S395>/Sum Condition' */
  /* InitializeConditions for Memory: '<S401>/Memory' */
  LKAS_DW.Memory_PreviousInput_au = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S395>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S320>/Subsystem' */
  /* InitializeConditions for Memory: '<S324>/Memory' */
  LKAS_DW.Memory_PreviousInput_oih = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S320>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S170>/Memory' */
  LKAS_DW.Memory_PreviousInput_oi = 0.0F;

  /* InitializeConditions for Memory: '<S201>/Memory' */
  LKAS_DW.Memory_PreviousInput_od = ((uint16)0U);

  /* InitializeConditions for Memory: '<S188>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_p = ((uint8)0U);

  /* InitializeConditions for Memory: '<S200>/Memory' */
  LKAS_DW.Memory_PreviousInput_nn = ((uint16)0U);

  /* InitializeConditions for Memory: '<S202>/Memory' */
  LKAS_DW.Memory_PreviousInput_nt = ((uint16)0U);

  /* InitializeConditions for Memory: '<S197>/Memory' */
  LKAS_DW.Memory_PreviousInput_o5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S185>/Memory' */
  LKAS_DW.Memory_PreviousInput_mm = 0.0F;

  /* InitializeConditions for Memory: '<S171>/Memory' */
  LKAS_DW.Memory_PreviousInput_fx = 0.0F;

  /* InitializeConditions for Memory: '<S172>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = 0.0F;

  /* InitializeConditions for UnitDelay: '<S174>/Delay Input1'
   *
   * Block description for '<S174>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_d = false;

  /* InitializeConditions for Memory: '<S172>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_l = false;

  /* InitializeConditions for Memory: '<S163>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_m = 0.0F;

  /* InitializeConditions for Memory: '<S264>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_k = 0.0F;

  /* InitializeConditions for Memory: '<S247>/Memory' */
  LKAS_DW.Memory_PreviousInput_mk = 0.0F;

  /* InitializeConditions for UnitDelay: '<S245>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_i = 0.0F;

  /* InitializeConditions for Memory: '<S253>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_m1 = 0.0F;

  /* InitializeConditions for Memory: '<S259>/Memory' */
  LKAS_DW.Memory_PreviousInput_nv = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S263>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_m = 0.0F;

  /* InitializeConditions for Memory: '<S263>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_k4 = 0.0F;

  /* InitializeConditions for UnitDelay: '<S240>/Delay Input2'
   *
   * Block description for '<S240>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_m = 0.0F;

  /* InitializeConditions for Memory: '<S240>/Memory' */
  LKAS_DW.Memory_PreviousInput_no = ((uint16)0U);

  /* InitializeConditions for Memory: '<S196>/Memory' */
  LKAS_DW.Memory_PreviousInput_n2 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S198>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = ((uint16)0U);

  /* InitializeConditions for Memory: '<S199>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = ((uint16)0U);

  /* SystemInitialize for Enabled SubSystem: '<S171>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S173>/Memory' */
  LKAS_DW.Memory_PreviousInput_cs = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S171>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S158>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S158>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S172>/Moving Standard Deviation1' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S172>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S172>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_n);

  /* End of SystemInitialize for SubSystem: '<S172>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S172>/Moving Standard Deviation2' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation2_i);

  /* End of SystemInitialize for SubSystem: '<S172>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S172>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_o);

  /* End of SystemInitialize for SubSystem: '<S172>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S172>/Sum Condition2' */
  /* InitializeConditions for Memory: '<S181>/Memory' */
  LKAS_DW.Memory_PreviousInput_l = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S172>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S158>/Sum Condition2' */
  /* InitializeConditions for Memory: '<S162>/Memory' */
  LKAS_DW.Memory_PreviousInput_n = 0.0F;

  /* SystemInitialize for Outport: '<S162>/M4K' */
  LKAS_DW.Saturation3 = 1.0F;

  /* End of SystemInitialize for SubSystem: '<S158>/Sum Condition2' */

  /* SystemInitialize for IfAction SubSystem: '<S262>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S272>/Delay Input1'
   *
   * Block description for '<S272>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_p = false;

  /* InitializeConditions for Memory: '<S268>/Memory' */
  LKAS_DW.Memory_PreviousInput_cq = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S262>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S262>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S280>/Delay Input1'
   *
   * Block description for '<S280>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_b = false;

  /* InitializeConditions for Memory: '<S269>/Memory' */
  LKAS_DW.Memory_PreviousInput_doi = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S262>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S262>/Merge' */
  LKAS_DW.Merge_p = 1.0F;

  /* SystemInitialize for Merge: '<S262>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S145>/Merge' */
  LKAS_DW.Merge_pv = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S145>/Sum Condition' */
  /* InitializeConditions for Memory: '<S149>/Memory' */
  LKAS_DW.Memory_PreviousInput_lr = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S145>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */

  /* SystemInitialize for Enabled SubSystem: '<S466>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1_j);

  /* End of SystemInitialize for SubSystem: '<S466>/Sum Condition1' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S653>/Subsystem' */
  /* InitializeConditions for Delay: '<S660>/Delay1' */
  LKAS_DW.Delay1_DSTATE = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S653>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S88>/Sum Condition2' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition2);

  /* End of SystemInitialize for SubSystem: '<S88>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S88>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1);

  /* End of SystemInitialize for SubSystem: '<S88>/Sum Condition1' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
