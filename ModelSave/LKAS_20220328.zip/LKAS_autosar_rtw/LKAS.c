/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.5
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Mon Mar 28 11:57:43 2022
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S143>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S143>/LKA_State_Machine' */
#define LKAS_IN_Fault_n                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_a      ((uint8)0U)
#define LKAS_IN_Normal_o               ((uint8)2U)
#define LKAS_IN_SysOff_e               ((uint8)2U)
#define LKAS_IN_SysOn_b                ((uint8)3U)
#define LKAS_IN_Unavailable_i          ((uint8)1U)
#define LKAS_IN_Unselected_n           ((uint8)2U)

/* Named constants for Chart: '<S111>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Exported data definition */

/* Definition for custom storage class: Default */
float32 ob_LKA_Disable_Reason;
uint32 ob_LKA_Fault_Reason;
float32 ob_LKA_LKADeactvCSyn;
float32 ob_LKA_Version;

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * System initialize for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S466>/Sum Condition1'
 */
void LKAS_SumCondition1_Init(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S99>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S466>/Sum Condition1'
 */
void LKAS_SumCondition1_Reset(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S99>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S466>/Sum Condition1'
 */
void LKAS_SumCondition1_Disable(boolean *rty_Out, DW_SumCondition1_LKAS_T
  *localDW)
{
  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' incorporates:
   *  EnablePort: '<S99>/state = reset'
   */
  /* Disable for Outport: '<S99>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */
  localDW->SumCondition1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S466>/Sum Condition1'
 */
void LKAS_SumCondition1(boolean rtu_statereset, float32 rtu_SampleTime, float32
  rtu_Sum, boolean *rty_Out, DW_SumCondition1_LKAS_T *localDW)
{
  float32 rtb_Saturation_gw;

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' incorporates:
   *  EnablePort: '<S99>/state = reset'
   */
  if (rtu_statereset) {
    if (!localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Reset(localDW);
      localDW->SumCondition1_MODE = true;
    }

    /* Sum: '<S99>/Add1' incorporates:
     *  Memory: '<S99>/Memory'
     */
    rtb_Saturation_gw = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S99>/Saturation' */
    if (rtb_Saturation_gw > 60.0F) {
      rtb_Saturation_gw = 60.0F;
    } else {
      if (rtb_Saturation_gw < 0.0F) {
        rtb_Saturation_gw = 0.0F;
      }
    }

    /* End of Saturate: '<S99>/Saturation' */

    /* RelationalOperator: '<S99>/Relational Operator' */
    *rty_Out = (rtb_Saturation_gw >= rtu_Sum);

    /* Update for Memory: '<S99>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_gw;
  } else {
    if (localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */
}

/*
 * Output and update for action system:
 *    '<S145>/If Action Subsystem2'
 *    '<S191>/If Action Subsystem3'
 *    '<S192>/If Action Subsystem3'
 *    '<S193>/If Action Subsystem3'
 *    '<S194>/If Action Subsystem3'
 *    '<S195>/If Action Subsystem3'
 *    '<S203>/If Action Subsystem3'
 *    '<S235>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S148>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S148>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/* System initialize for atomic system: '<S158>/Moving Standard Deviation2' */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S161>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S161>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* System reset for atomic system: '<S158>/Moving Standard Deviation2' */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S161>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S161>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S161>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* Output and update for atomic system: '<S158>/Moving Standard Deviation2' */
void LKAS_MovingStandardDeviation2(float32 rtu_In1, float32 *rty_Out2, float32
  *rty_Out1, DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_m;
  float32 rtb_Delay1_f;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_SumofElements;
  float32 rtb_TmpSignalConversionAtStanda[50];
  sint32 tmp;
  sint32 i;
  float32 rtb_Saturation_es;

  /* Delay: '<S161>/Delay' */
  rtb_Delay_m = localDW->Delay_DSTATE;

  /* Delay: '<S161>/Delay1' */
  rtb_Delay1_f = localDW->Delay1_DSTATE;

  /* Delay: '<S161>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S161>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S161>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S161>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S161>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S161>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S161>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S161>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S161>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S161>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S161>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S161>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S161>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S161>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S161>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S161>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S161>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S161>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S161>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S161>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S161>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S161>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S161>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S161>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S161>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S161>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S161>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S161>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S161>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S161>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S161>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S161>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S161>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S161>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S161>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S161>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S161>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S161>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S161>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S161>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S161>/Delay47' */
  rtb_SumofElements = localDW->Delay47_DSTATE;

  /* Delay: '<S161>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S161>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S161>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S161>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S161>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S161>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S161>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_m;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_f;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_SumofElements;

  /* Sum: '<S161>/Sum of Elements' */
  tmp = 0;
  rtb_Saturation_es = -0.0F;
  for (i = 0; i < 50; i++) {
    rtb_Saturation_es += rtb_TmpSignalConversionAtStanda[i];
  }

  rtb_SumofElements = rtb_Saturation_es;

  /* End of Sum: '<S161>/Sum of Elements' */

  /* Sum: '<S161>/Add2' incorporates:
   *  Constant: '<S161>/Constant'
   *  Memory: '<S161>/Memory3'
   */
  rtb_Saturation_es = (float32)((uint8)(((uint32)((uint8)1U)) + ((uint32)((uint8)
    localDW->Memory3_PreviousInput))));

  /* Saturate: '<S161>/Saturation' */
  if (rtb_Saturation_es > 50.0F) {
    rtb_Saturation_es = 50.0F;
  } else {
    if (rtb_Saturation_es < 1.0F) {
      rtb_Saturation_es = 1.0F;
    }
  }

  /* End of Saturate: '<S161>/Saturation' */

  /* Product: '<S161>/Divide' */
  *rty_Out2 = rtb_SumofElements / rtb_Saturation_es;

  /* S-Function (sdspstatfcns): '<S161>/Standard Deviation' incorporates:
   *  SignalConversion: '<S161>/TmpSignal ConversionAtStandard DeviationInport1'
   */
  while (tmp < 1) {
    localDW->StandardDeviation_AccVal = rtu_In1;
    localDW->StandardDeviation_SqData = rtu_In1 * rtu_In1;
    tmp = 1;
    for (i = 48; i >= 0; i--) {
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[tmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[tmp] *
        rtb_TmpSignalConversionAtStanda[tmp];
      tmp++;
    }

    *rty_Out1 = (localDW->StandardDeviation_SqData -
                 ((localDW->StandardDeviation_AccVal *
                   localDW->StandardDeviation_AccVal) / 50.0F)) / 49.0F;
    *rty_Out1 = sqrtf(fabsf(*rty_Out1));
    tmp = 1;
  }

  /* End of S-Function (sdspstatfcns): '<S161>/Standard Deviation' */

  /* Update for Delay: '<S161>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S161>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_m;

  /* Update for Delay: '<S161>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S161>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S161>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S161>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S161>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S161>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S161>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S161>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S161>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S161>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S161>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_f;

  /* Update for Delay: '<S161>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S161>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S161>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S161>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S161>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S161>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S161>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S161>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S161>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S161>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S161>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S161>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S161>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S161>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S161>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S161>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S161>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S161>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S161>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S161>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S161>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S161>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S161>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S161>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S161>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S161>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S161>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S161>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S161>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S161>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S161>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S161>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S161>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S161>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S161>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S161>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;

  /* Update for Memory: '<S161>/Memory3' */
  localDW->Memory3_PreviousInput = rtb_Saturation_es;
}

/*
 * Output and update for action system:
 *    '<S172>/If Action Subsystem3'
 *    '<S417>/If Action Subsystem3'
 *    '<S457>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S176>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * System initialize for atomic system:
 *    '<S172>/Moving Standard Deviation1'
 *    '<S172>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation1_Init(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S177>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S172>/Moving Standard Deviation1'
 *    '<S172>/Moving Standard Deviation2'
 */
void MovingStandardDeviation1_Reset(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S177>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S177>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S172>/Moving Standard Deviation1'
 *    '<S172>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation1(float32 rtu_In1,
  DW_MovingStandardDeviation1_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_f;
  float32 rtb_Delay1_i;
  float32 rtb_Delay10_l;
  float32 rtb_Delay11_g;
  float32 rtb_Delay12_a;
  float32 rtb_Delay13_n;
  float32 rtb_Delay14_o;
  float32 rtb_Delay15_l;
  float32 rtb_Delay16_o;
  float32 rtb_Delay17_a;
  float32 rtb_Delay18_n;
  float32 rtb_Delay19_h;
  float32 rtb_Delay2_p;
  float32 rtb_Delay20_p;
  float32 rtb_Delay21_d;
  float32 rtb_Delay22_l;
  float32 rtb_Delay23_d;
  float32 rtb_Delay24_n;
  float32 rtb_Delay25_l;
  float32 rtb_Delay26_f;
  float32 rtb_Delay27_j;
  float32 rtb_Delay28_k;
  float32 rtb_Delay29_h;
  float32 rtb_Delay3_a;
  float32 rtb_Delay30_d;
  float32 rtb_Delay31_c;
  float32 rtb_Delay32_b;
  float32 rtb_Delay33_k;
  float32 rtb_Delay34_j;
  float32 rtb_Delay35_d;
  float32 rtb_Delay36_i;
  float32 rtb_Delay37_e;
  float32 rtb_Delay38_j;
  float32 rtb_Delay39_c;
  float32 rtb_Delay4_i;
  float32 rtb_Delay40_n;
  float32 rtb_Delay41_b;
  float32 rtb_Delay42_b;
  float32 rtb_Delay43_c;
  float32 rtb_Delay44_f;
  float32 rtb_Delay45_e;
  float32 rtb_Delay46_i;
  float32 rtb_Delay48_k;
  float32 rtb_Delay5_g;
  float32 rtb_Delay6_e;
  float32 rtb_Delay7_f;
  float32 rtb_Delay8_o;
  float32 rtb_Delay9_o;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S177>/Delay' */
  rtb_Delay_f = localDW->Delay_DSTATE;

  /* Delay: '<S177>/Delay1' */
  rtb_Delay1_i = localDW->Delay1_DSTATE;

  /* Delay: '<S177>/Delay10' */
  rtb_Delay10_l = localDW->Delay10_DSTATE;

  /* Delay: '<S177>/Delay11' */
  rtb_Delay11_g = localDW->Delay11_DSTATE;

  /* Delay: '<S177>/Delay12' */
  rtb_Delay12_a = localDW->Delay12_DSTATE;

  /* Delay: '<S177>/Delay13' */
  rtb_Delay13_n = localDW->Delay13_DSTATE;

  /* Delay: '<S177>/Delay14' */
  rtb_Delay14_o = localDW->Delay14_DSTATE;

  /* Delay: '<S177>/Delay15' */
  rtb_Delay15_l = localDW->Delay15_DSTATE;

  /* Delay: '<S177>/Delay16' */
  rtb_Delay16_o = localDW->Delay16_DSTATE;

  /* Delay: '<S177>/Delay17' */
  rtb_Delay17_a = localDW->Delay17_DSTATE;

  /* Delay: '<S177>/Delay18' */
  rtb_Delay18_n = localDW->Delay18_DSTATE;

  /* Delay: '<S177>/Delay19' */
  rtb_Delay19_h = localDW->Delay19_DSTATE;

  /* Delay: '<S177>/Delay2' */
  rtb_Delay2_p = localDW->Delay2_DSTATE;

  /* Delay: '<S177>/Delay20' */
  rtb_Delay20_p = localDW->Delay20_DSTATE;

  /* Delay: '<S177>/Delay21' */
  rtb_Delay21_d = localDW->Delay21_DSTATE;

  /* Delay: '<S177>/Delay22' */
  rtb_Delay22_l = localDW->Delay22_DSTATE;

  /* Delay: '<S177>/Delay23' */
  rtb_Delay23_d = localDW->Delay23_DSTATE;

  /* Delay: '<S177>/Delay24' */
  rtb_Delay24_n = localDW->Delay24_DSTATE;

  /* Delay: '<S177>/Delay25' */
  rtb_Delay25_l = localDW->Delay25_DSTATE;

  /* Delay: '<S177>/Delay26' */
  rtb_Delay26_f = localDW->Delay26_DSTATE;

  /* Delay: '<S177>/Delay27' */
  rtb_Delay27_j = localDW->Delay27_DSTATE;

  /* Delay: '<S177>/Delay28' */
  rtb_Delay28_k = localDW->Delay28_DSTATE;

  /* Delay: '<S177>/Delay29' */
  rtb_Delay29_h = localDW->Delay29_DSTATE;

  /* Delay: '<S177>/Delay3' */
  rtb_Delay3_a = localDW->Delay3_DSTATE;

  /* Delay: '<S177>/Delay30' */
  rtb_Delay30_d = localDW->Delay30_DSTATE;

  /* Delay: '<S177>/Delay31' */
  rtb_Delay31_c = localDW->Delay31_DSTATE;

  /* Delay: '<S177>/Delay32' */
  rtb_Delay32_b = localDW->Delay32_DSTATE;

  /* Delay: '<S177>/Delay33' */
  rtb_Delay33_k = localDW->Delay33_DSTATE;

  /* Delay: '<S177>/Delay34' */
  rtb_Delay34_j = localDW->Delay34_DSTATE;

  /* Delay: '<S177>/Delay35' */
  rtb_Delay35_d = localDW->Delay35_DSTATE;

  /* Delay: '<S177>/Delay36' */
  rtb_Delay36_i = localDW->Delay36_DSTATE;

  /* Delay: '<S177>/Delay37' */
  rtb_Delay37_e = localDW->Delay37_DSTATE;

  /* Delay: '<S177>/Delay38' */
  rtb_Delay38_j = localDW->Delay38_DSTATE;

  /* Delay: '<S177>/Delay39' */
  rtb_Delay39_c = localDW->Delay39_DSTATE;

  /* Delay: '<S177>/Delay4' */
  rtb_Delay4_i = localDW->Delay4_DSTATE;

  /* Delay: '<S177>/Delay40' */
  rtb_Delay40_n = localDW->Delay40_DSTATE;

  /* Delay: '<S177>/Delay41' */
  rtb_Delay41_b = localDW->Delay41_DSTATE;

  /* Delay: '<S177>/Delay42' */
  rtb_Delay42_b = localDW->Delay42_DSTATE;

  /* Delay: '<S177>/Delay43' */
  rtb_Delay43_c = localDW->Delay43_DSTATE;

  /* Delay: '<S177>/Delay44' */
  rtb_Delay44_f = localDW->Delay44_DSTATE;

  /* Delay: '<S177>/Delay45' */
  rtb_Delay45_e = localDW->Delay45_DSTATE;

  /* Delay: '<S177>/Delay46' */
  rtb_Delay46_i = localDW->Delay46_DSTATE;

  /* Delay: '<S177>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S177>/Delay48' */
  rtb_Delay48_k = localDW->Delay48_DSTATE;

  /* Delay: '<S177>/Delay5' */
  rtb_Delay5_g = localDW->Delay5_DSTATE;

  /* Delay: '<S177>/Delay6' */
  rtb_Delay6_e = localDW->Delay6_DSTATE;

  /* Delay: '<S177>/Delay7' */
  rtb_Delay7_f = localDW->Delay7_DSTATE;

  /* Delay: '<S177>/Delay8' */
  rtb_Delay8_o = localDW->Delay8_DSTATE;

  /* Delay: '<S177>/Delay9' */
  rtb_Delay9_o = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S177>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_f;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_i;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2_p;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3_a;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4_i;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5_g;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6_e;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7_f;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8_o;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9_o;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10_l;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11_g;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12_a;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13_n;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14_o;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15_l;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16_o;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17_a;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18_n;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28_k;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19_h;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20_p;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21_d;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22_l;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23_d;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24_n;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25_l;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26_f;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27_j;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38_j;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29_h;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30_d;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31_c;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32_b;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33_k;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34_j;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35_d;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36_i;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37_e;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48_k;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39_c;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40_n;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41_b;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42_b;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43_c;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44_f;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45_e;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46_i;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S177>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S177>/Standard Deviation' */

  /* Update for Delay: '<S177>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S177>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_f;

  /* Update for Delay: '<S177>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9_o;

  /* Update for Delay: '<S177>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10_l;

  /* Update for Delay: '<S177>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11_g;

  /* Update for Delay: '<S177>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12_a;

  /* Update for Delay: '<S177>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13_n;

  /* Update for Delay: '<S177>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14_o;

  /* Update for Delay: '<S177>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15_l;

  /* Update for Delay: '<S177>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16_o;

  /* Update for Delay: '<S177>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17_a;

  /* Update for Delay: '<S177>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28_k;

  /* Update for Delay: '<S177>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_i;

  /* Update for Delay: '<S177>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19_h;

  /* Update for Delay: '<S177>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20_p;

  /* Update for Delay: '<S177>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21_d;

  /* Update for Delay: '<S177>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22_l;

  /* Update for Delay: '<S177>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23_d;

  /* Update for Delay: '<S177>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24_n;

  /* Update for Delay: '<S177>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25_l;

  /* Update for Delay: '<S177>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26_f;

  /* Update for Delay: '<S177>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18_n;

  /* Update for Delay: '<S177>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38_j;

  /* Update for Delay: '<S177>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2_p;

  /* Update for Delay: '<S177>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29_h;

  /* Update for Delay: '<S177>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30_d;

  /* Update for Delay: '<S177>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31_c;

  /* Update for Delay: '<S177>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32_b;

  /* Update for Delay: '<S177>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33_k;

  /* Update for Delay: '<S177>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34_j;

  /* Update for Delay: '<S177>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35_d;

  /* Update for Delay: '<S177>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36_i;

  /* Update for Delay: '<S177>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27_j;

  /* Update for Delay: '<S177>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48_k;

  /* Update for Delay: '<S177>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3_a;

  /* Update for Delay: '<S177>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39_c;

  /* Update for Delay: '<S177>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40_n;

  /* Update for Delay: '<S177>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41_b;

  /* Update for Delay: '<S177>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42_b;

  /* Update for Delay: '<S177>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43_c;

  /* Update for Delay: '<S177>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44_f;

  /* Update for Delay: '<S177>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45_e;

  /* Update for Delay: '<S177>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46_i;

  /* Update for Delay: '<S177>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37_e;

  /* Update for Delay: '<S177>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4_i;

  /* Update for Delay: '<S177>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5_g;

  /* Update for Delay: '<S177>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6_e;

  /* Update for Delay: '<S177>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7_f;

  /* Update for Delay: '<S177>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8_o;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S172>/Sum Condition'
 *    '<S172>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S179>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S172>/Sum Condition'
 *    '<S172>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S179>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S172>/Sum Condition'
 *    '<S172>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S172>/Sum Condition' incorporates:
   *  EnablePort: '<S179>/Enable'
   */
  /* Disable for Outport: '<S179>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S172>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S172>/Sum Condition'
 *    '<S172>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_cs;

  /* Outputs for Enabled SubSystem: '<S172>/Sum Condition' incorporates:
   *  EnablePort: '<S179>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S179>/Add1' incorporates:
     *  Memory: '<S179>/Memory'
     */
    rtb_Saturation_cs = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S179>/Saturation' */
    if (rtb_Saturation_cs > 100.0F) {
      rtb_Saturation_cs = 100.0F;
    } else {
      if (rtb_Saturation_cs < 0.0F) {
        rtb_Saturation_cs = 0.0F;
      }
    }

    /* End of Saturate: '<S179>/Saturation' */

    /* RelationalOperator: '<S179>/Relational Operator' */
    *rty_Out = (rtb_Saturation_cs >= rtu_In1);

    /* Update for Memory: '<S179>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_cs;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S172>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S191>/If Action Subsystem2'
 *    '<S191>/If Action Subsystem1'
 *    '<S192>/If Action Subsystem2'
 *    '<S192>/If Action Subsystem1'
 *    '<S193>/If Action Subsystem2'
 *    '<S193>/If Action Subsystem1'
 *    '<S194>/If Action Subsystem2'
 *    '<S194>/If Action Subsystem1'
 *    '<S195>/If Action Subsystem2'
 *    '<S195>/If Action Subsystem1'
 *    ...
 */
void LKAS_IfActionSubsystem2_e(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S205>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S196>/if action '
 *    '<S197>/if action '
 *    '<S198>/if action '
 *    '<S199>/if action '
 *    '<S200>/if action '
 *    '<S201>/if action '
 *    '<S202>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S219>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S235>/If Action Subsystem'
 *    '<S235>/If Action Subsystem4'
 *    '<S187>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S237>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system: '<S152>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S152>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  float32 K1K2Det_T1;
  float32 DelteSW0;
  float32 u;
  float32 KMax;
  float32 DelteSW1;
  float32 tmp;

  /* MATLAB Function: '<S183>/MATLABFunction1' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLABFunction1': '<S190>:1' */
  /* '<S190>:1:34' LDDir = K1K2Det_stLDDir; */
  /*     D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S190>:1:36' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_j * 0.0174532924F;

  /* '<S190>:1:37' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S190>:1:38' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S190>:1:39' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S190>:1:40' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S190>:1:41' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S190>:1:42' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_c / 3.6F;

  /* '<S190>:1:43' Kw= u/(L*(1+K*u*u)*i); */
  /* '<S190>:1:44' KMax = K1K2Det_dphiSWARMax/180*pi; */
  KMax = (LKAS_DW.MPInP_dphiSWARMax / 180.0F) * 3.14159274F;

  /* '<S190>:1:45' Delte_Psi1 = PrvwHdAg; */
  /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
  /* '<S190>:1:47' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
  u = ((-2.0F * LKAS_DW.In_a) / (((u / (((((LKAS_DW.MPInP_StbFacm_SY * u) * u) +
             1.0F) * LKAS_DW.LKA_WhlBaseL_C_a) * LKAS_DW.LKA_StrRatio_C_l)) *
         LKAS_DW.MPInP_tiTTLCIni) * LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F *
    DelteSW0) / LKAS_DW.MPInP_tiTTLCIni);

  /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
  /* '<S190>:1:49' DelteSW1 = DelteSW0+K1*TTLC; */
  DelteSW1 = (u * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

  /* '<S190>:1:50' K1K2Det_T1 = TTLC; */
  K1K2Det_T1 = LKAS_DW.MPInP_tiTTLCIni;

  /* '<S190>:1:51' if ~(K1<abs(KMax) && K1>-abs(KMax)) */
  tmp = fabsf(KMax);
  if ((u >= tmp) || (u <= (-tmp))) {
    /*  ������ת������ */
    /* '<S190>:1:52' K1 = LDDir*KMax; */
    u = LKAS_DW.Merge * KMax;

    /* '<S190>:1:53' K1K2Det_T1 = max((-DelteSW0+sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1,(-DelteSW0-sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1); */
    KMax = sqrtf((DelteSW0 * DelteSW0) - ((2.0F * u) * LKAS_DW.In_a));
    K1K2Det_T1 = fmaxf((KMax + (-DelteSW0)) / u, ((-DelteSW0) - KMax) / u);

    /* '<S190>:1:54' DelteSW1 = (K1*K1K2Det_T1+DelteSW0); */
    DelteSW1 = (u * K1K2Det_T1) + DelteSW0;
  }

  /* '<S190>:1:56' if LDDir>0 && K1<0 && DelteSW0>0 && Delte_Psi1<0 */
  if ((((LKAS_DW.Merge > 0.0F) && (u < 0.0F)) && (DelteSW0 > 0.0F)) &&
      (LKAS_DW.In_a < 0.0F)) {
    /* '<S190>:1:57' K1 = single(0); */
    u = 0.0F;

    /* '<S190>:1:58' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S190>:1:59' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_a) / DelteSW0;
  }

  /* '<S190>:1:61' if LDDir<0 && K1>0 && DelteSW0<0 && Delte_Psi1>0 */
  if ((((LKAS_DW.Merge < 0.0F) && (u > 0.0F)) && (DelteSW0 < 0.0F)) &&
      (LKAS_DW.In_a > 0.0F)) {
    /* '<S190>:1:62' K1 = single(0); */
    u = 0.0F;

    /* '<S190>:1:63' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S190>:1:64' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_a) / DelteSW0;
  }

  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S190>:1:67' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S190>:1:69' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = u * 57.2957802F;
  LKAS_DW.K1K2Det_T1 = K1K2Det_T1;

  /* End of MATLAB Function: '<S183>/MATLABFunction1' */
}

/*
 * Output and update for atomic system:
 *    '<S245>/Saturable Gain Lut (SatGainLut)'
 *    '<S245>/Saturable Gain Lut (SatGainLut)1'
 */
void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32 rtu_InputLimLwr,
  float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32 rtu_GainLimUpr,
  float32 *rty_Gain)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S248>:1' */
  /*  Function Name: Saturable Gain Lut */
  /*  */
  /*  Description:  */
  /*    Saturable Gain Lookup Table. */
  /*  */
  /*  Assumptions and Limitation: */
  /*    The data type of all inputs and output is single. */
  /*  */
  /*  Inputs: */
  /*    Input: */
  /*    InputLimLwr: */
  /*    InputLimUpr: */
  /*    GainLimLwr: */
  /*    GainLimUpr: */
  /*  */
  /*  Outputs: */
  /*    Gain: The result of Looking up table. */
  /*  $Revision: 1.0$ */
  /*  $Author: Zhang Jianwei$ */
  /*  $Date: January 27, 2019$ */
  /*  ________________________________________ */
  /* '<S248>:1:25' if Input <= InputLimLwr */
  if (rtu_Input <= rtu_InputLimLwr) {
    /* '<S248>:1:26' Gain = GainLimLwr; */
    *rty_Gain = rtu_GainLimLwr;
  } else if (rtu_Input >= rtu_InputLimUpr) {
    /* '<S248>:1:27' elseif Input >= InputLimUpr */
    /* '<S248>:1:28' Gain = GainLimUpr; */
    *rty_Gain = rtu_GainLimUpr;
  } else {
    /* '<S248>:1:29' else */
    /* '<S248>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
    /* '<S248>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
    *rty_Gain = (((rtu_Input - rtu_InputLimLwr) / (rtu_InputLimUpr -
      rtu_InputLimLwr)) * (rtu_GainLimUpr - rtu_GainLimLwr)) + rtu_GainLimLwr;
  }
}

/*
 * Output and update for action system:
 *    '<S252>/If Action Subsystem'
 *    '<S252>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_d(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S254>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S275>/if action '
 *    '<S276>/if action '
 *    '<S283>/if action '
 *    '<S284>/if action '
 */
void LKAS_ifaction_n(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S277>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S268>/If Action Subsystem'
 *    '<S269>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_dv(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_a_T *localDW)
{
  uint16 rtb_Saturation1_cf;
  uint16 rtb_Saturation1_eb;

  /* Outputs for Enabled SubSystem: '<S268>/If Action Subsystem' incorporates:
   *  EnablePort: '<S273>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S275>/Add' incorporates:
     *  Constant: '<S275>/Constant'
     *  Memory: '<S275>/Memory'
     */
    rtb_Saturation1_cf = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S275>/Saturation1' */
    if (rtb_Saturation1_cf >= ((uint16)10000U)) {
      rtb_Saturation1_cf = ((uint16)10000U);
    }

    /* End of Saturate: '<S275>/Saturation1' */

    /* If: '<S275>/If' incorporates:
     *  Constant: '<S275>/Constant2'
     */
    if (rtb_Saturation1_cf <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S275>/if action ' incorporates:
       *  ActionPort: '<S277>/Action Port'
       */
      LKAS_ifaction_n(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S275>/if action ' */
    }

    /* End of If: '<S275>/If' */

    /* Sum: '<S276>/Add' incorporates:
     *  Constant: '<S276>/Constant'
     *  Memory: '<S276>/Memory'
     */
    rtb_Saturation1_eb = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_d));

    /* Saturate: '<S276>/Saturation1' */
    if (rtb_Saturation1_eb >= ((uint16)10000U)) {
      rtb_Saturation1_eb = ((uint16)10000U);
    }

    /* End of Saturate: '<S276>/Saturation1' */

    /* If: '<S276>/If' incorporates:
     *  Constant: '<S276>/Constant2'
     */
    if (rtb_Saturation1_eb == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S276>/if action ' incorporates:
       *  ActionPort: '<S278>/Action Port'
       */
      LKAS_ifaction_n(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S276>/if action ' */
    }

    /* End of If: '<S276>/If' */

    /* Update for Memory: '<S275>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_cf;

    /* Update for Memory: '<S276>/Memory' */
    localDW->Memory_PreviousInput_d = rtb_Saturation1_eb;
  }

  /* End of Outputs for SubSystem: '<S268>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S268>/If Action Subsystem2'
 *    '<S269>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_g(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S274>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S274>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S143>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_m = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_h = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c69_LKAS = 0U;
  LKAS_DW.is_c69_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.stLDWActvFlg = 0U;
  LKAS_DW.stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S143>/LDW_State_Machine'
 * Block description for: '<S143>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S143>/LDW_State_Machine'
   *
   * Block description for '<S143>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c69_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c69_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S336>:2' */
    LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S336>:1' */
    /* Transition: '<S336>:31' */
    LKAS_DW.is_SysOff_m = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S336>:30' */
    LKAS_DW.stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c69_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S336>:36' */
      tmp = !LKAS_DW.LDW_Fault;
      if (tmp && ((((sint32)LKAS_DW.LKA_Mode_g) == 1) || (((sint32)
             LKAS_DW.LKA_Mode_g) == 2))) {
        /* Transition: '<S336>:38' */
        /* Exit Internal 'Fault': '<S336>:36' */
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S336>:3' */
        /* Transition: '<S336>:77' */
        LKAS_DW.is_SysOn_h = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S336>:47' */
        LKAS_DW.stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.LKA_Mode_g) == 0) && tmp) {
        /* Transition: '<S336>:40' */
        /* Exit Internal 'Fault': '<S336>:36' */
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_m = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S336>:32' */
        LKAS_DW.stLDWState = 1U;
      } else {
        LKAS_DW.stLDWState = 6U;

        /* During 'LDWFault': '<S336>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S336>:1' */
      if (((((sint32)LKAS_DW.LKA_Mode_g) == 1) || (((sint32)LKAS_DW.LKA_Mode_g) ==
            2)) && (LKAS_DW.LDW_Fault)) {
        /* Transition: '<S336>:39' */
        /* Exit Internal 'SysOff': '<S336>:1' */
        LKAS_DW.is_SysOff_m = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S336>:36' */
        /* Transition: '<S336>:75' */
        /* Entry 'LDWFault': '<S336>:73' */
        LKAS_DW.stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode_g) == 1) || (((sint32)
                   LKAS_DW.LKA_Mode_g) == 2)) {
        /* Transition: '<S336>:41' */
        /* Exit Internal 'SysOff': '<S336>:1' */
        LKAS_DW.is_SysOff_m = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S336>:3' */
        /* Transition: '<S336>:77' */
        LKAS_DW.is_SysOn_h = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S336>:47' */
        LKAS_DW.stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_m) == LKAS_IN_Unavailable) {
        LKAS_DW.stLDWState = 0U;

        /* During 'Unavailable': '<S336>:30' */
        if (((sint32)LKAS_DW.LKA_Mode_g) == 0) {
          /* Transition: '<S336>:35' */
          LKAS_DW.is_SysOff_m = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S336>:32' */
          LKAS_DW.stLDWState = 1U;
        }
      } else {
        LKAS_DW.stLDWState = 1U;

        /* During 'Unselected': '<S336>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S336>:3' */
      if (LKAS_DW.LDW_Fault) {
        /* Transition: '<S336>:37' */
        /* Exit Internal 'SysOn': '<S336>:3' */
        if (((uint32)LKAS_DW.is_SysOn_h) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S336>:102' */
          switch (LKAS_DW.is_Normal_j) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S336>:114' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S336>:115' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_h = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_h = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S336>:36' */
        /* Transition: '<S336>:75' */
        /* Entry 'LDWFault': '<S336>:73' */
        LKAS_DW.stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode_g) != 1) && (((sint32)
                   LKAS_DW.LKA_Mode_g) != 2)) {
        /* Transition: '<S336>:42' */
        /* Exit Internal 'SysOn': '<S336>:3' */
        if (((uint32)LKAS_DW.is_SysOn_h) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S336>:102' */
          switch (LKAS_DW.is_Normal_j) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S336>:114' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S336>:115' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_h = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_h = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_m = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S336>:32' */
        LKAS_DW.stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_h) == LKAS_IN_LDWSelected) {
        LKAS_DW.stLDWState = 2U;

        /* During 'LDWSelected': '<S336>:47' */
        if ((LKAS_DW.Merge_d) && (!LKAS_DW.Merge1_h)) {
          /* Transition: '<S336>:50' */
          LKAS_DW.is_SysOn_h = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S336>:102' */
          /* Transition: '<S336>:113' */
          LKAS_DW.is_Normal_j = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S336>:112' */
          LKAS_DW.stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S336>:102' */
        if (LKAS_DW.Merge1_h) {
          /* Transition: '<S336>:44' */
          /* Exit Internal 'Normal': '<S336>:102' */
          switch (LKAS_DW.is_Normal_j) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S336>:114' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S336>:115' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_h = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S336>:47' */
          LKAS_DW.stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_j) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.stLDWState = 3U;

            /* During 'LDWEnable': '<S336>:112' */
            if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.LKA_Fault))
            {
              /* Transition: '<S336>:118' */
              LKAS_DW.is_Normal_j = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S336>:114' */
              LKAS_DW.stLDWState = 4U;
              LKAS_DW.stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S336>:119' */
                LKAS_DW.is_Normal_j = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S336>:115' */
                LKAS_DW.stLDWState = 5U;
                LKAS_DW.stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.stLDWState = 4U;

            /* During 'LDWLeftActive': '<S336>:114' */
            if (LKAS_DW.LKA_Fault) {
              /* Transition: '<S336>:116' */
              /* Exit 'LDWLeftActive': '<S336>:114' */
              LKAS_DW.stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_j = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S336>:112' */
              LKAS_DW.stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S336>:120' */
                /* Exit 'LDWLeftActive': '<S336>:114' */
                LKAS_DW.is_Normal_j = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S336>:115' */
                LKAS_DW.stLDWState = 5U;
                LKAS_DW.stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.stLDWState = 5U;

            /* During 'LDWRightActive': '<S336>:115' */
            if (LKAS_DW.LKA_Fault) {
              /* Transition: '<S336>:117' */
              /* Exit 'LDWRightActive': '<S336>:115' */
              LKAS_DW.stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_j = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S336>:112' */
              LKAS_DW.stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S336>:121' */
                /* Exit 'LDWRightActive': '<S336>:115' */
                LKAS_DW.is_Normal_j = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S336>:114' */
                LKAS_DW.stLDWState = 4U;
                LKAS_DW.stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S143>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S143>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_a;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_a;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
  LKAS_DW.is_active_c70_LKAS = 0U;
  LKAS_DW.is_c70_LKAS = LKAS_IN_NO_ACTIVE_CHILD_a;
  LKAS_DW.stLKAActvFlg = 0U;
  LKAS_DW.stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S143>/LKA_State_Machine'
 * Block description for: '<S143>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S143>/LKA_State_Machine'
   *
   * Block description for '<S143>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  if (((uint32)LKAS_DW.is_active_c70_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    LKAS_DW.is_active_c70_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    /* Transition: '<S337>:2' */
    LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_e;

    /* Entry Internal 'SysOff': '<S337>:1' */
    /* Transition: '<S337>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_i;

    /* Entry 'Unavailable': '<S337>:30' */
    LKAS_DW.stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c70_LKAS) {
     case LKAS_IN_Fault_n:
      /* During 'Fault': '<S337>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.LKA_Mode_g) == 2)) {
        /* Transition: '<S337>:38' */
        /* Exit Internal 'Fault': '<S337>:36' */
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOn_b;

        /* Entry Internal 'SysOn': '<S337>:3' */
        /* Transition: '<S337>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S337>:19' */
        LKAS_DW.stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.LKA_Mode_g) == 0) || (((sint32)
                    LKAS_DW.LKA_Mode_g) == 1)) && tmp) {
        /* Transition: '<S337>:40' */
        /* Exit Internal 'Fault': '<S337>:36' */
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_e;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_n;

        /* Entry 'Unselected': '<S337>:32' */
        LKAS_DW.stLKAState = 1U;
      } else {
        LKAS_DW.stLKAState = 6U;

        /* During 'LKAFault': '<S337>:72' */
      }
      break;

     case LKAS_IN_SysOff_e:
      /* During 'SysOff': '<S337>:1' */
      if ((((sint32)LKAS_DW.LKA_Mode_g) == 2) && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S337>:39' */
        /* Exit Internal 'SysOff': '<S337>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_a;
        LKAS_DW.is_c70_LKAS = LKAS_IN_Fault_n;

        /* Entry Internal 'Fault': '<S337>:36' */
        /* Transition: '<S337>:74' */
        /* Entry 'LKAFault': '<S337>:72' */
        LKAS_DW.stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode_g) == 2) {
        /* Transition: '<S337>:41' */
        /* Exit Internal 'SysOff': '<S337>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_a;
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOn_b;

        /* Entry Internal 'SysOn': '<S337>:3' */
        /* Transition: '<S337>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S337>:19' */
        LKAS_DW.stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_i) {
        LKAS_DW.stLKAState = 0U;

        /* During 'Unavailable': '<S337>:30' */
        if ((((sint32)LKAS_DW.LKA_Mode_g) == 0) || (((sint32)LKAS_DW.LKA_Mode_g)
             == 1)) {
          /* Transition: '<S337>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_n;

          /* Entry 'Unselected': '<S337>:32' */
          LKAS_DW.stLKAState = 1U;
        }
      } else {
        LKAS_DW.stLKAState = 1U;

        /* During 'Unselected': '<S337>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S337>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S337>:37' */
        /* Exit Internal 'SysOn': '<S337>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_o) {
          /* Exit Internal 'Normal': '<S337>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S337>:109' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S337>:110' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_a;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_a;
        }

        LKAS_DW.is_c70_LKAS = LKAS_IN_Fault_n;

        /* Entry Internal 'Fault': '<S337>:36' */
        /* Transition: '<S337>:74' */
        /* Entry 'LKAFault': '<S337>:72' */
        LKAS_DW.stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode_g) != 2) {
        /* Transition: '<S337>:42' */
        /* Exit Internal 'SysOn': '<S337>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_o) {
          /* Exit Internal 'Normal': '<S337>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S337>:109' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S337>:110' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_a;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_a;
        }

        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_e;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_n;

        /* Entry 'Unselected': '<S337>:32' */
        LKAS_DW.stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.stLKAState = 2U;

        /* During 'LKASelected': '<S337>:19' */
        if ((LKAS_DW.Merge1_c) && (!LKAS_DW.Merge2)) {
          /* Transition: '<S337>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_o;

          /* Entry Internal 'Normal': '<S337>:102' */
          /* Transition: '<S337>:103' */
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S337>:108' */
          LKAS_DW.stLKAState = 3U;
        }
      } else {
        /* During 'Normal': '<S337>:102' */
        if (LKAS_DW.Merge2) {
          /* Transition: '<S337>:25' */
          /* Exit Internal 'Normal': '<S337>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S337>:109' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S337>:110' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_a;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

          /* Entry 'LKASelected': '<S337>:19' */
          LKAS_DW.stLKAState = 2U;
        } else {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKAEnable:
            LKAS_DW.stLKAState = 3U;

            /* During 'LKAEnable': '<S337>:108' */
            if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_n)) {
              /* Transition: '<S337>:105' */
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

              /* Entry 'LKALeftActive': '<S337>:109' */
              LKAS_DW.stLKAState = 4U;
              LKAS_DW.stLKAActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_n))
              {
                /* Transition: '<S337>:104' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S337>:110' */
                LKAS_DW.stLKAState = 5U;
                LKAS_DW.stLKAActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LKALeftActive:
            LKAS_DW.stLKAState = 4U;

            /* During 'LKALeftActive': '<S337>:109' */
            if (LKAS_DW.Merge1_n) {
              /* Transition: '<S337>:106' */
              /* Exit 'LKALeftActive': '<S337>:109' */
              LKAS_DW.stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S337>:108' */
              LKAS_DW.stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_n))
              {
                /* Transition: '<S337>:111' */
                /* Exit 'LKALeftActive': '<S337>:109' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S337>:110' */
                LKAS_DW.stLKAState = 5U;
                LKAS_DW.stLKAActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.stLKAState = 5U;

            /* During 'LKARightActive': '<S337>:110' */
            if (LKAS_DW.Merge1_n) {
              /* Transition: '<S337>:107' */
              /* Exit 'LKARightActive': '<S337>:110' */
              LKAS_DW.stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S337>:108' */
              LKAS_DW.stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_n))
              {
                /* Transition: '<S337>:112' */
                /* Exit 'LKARightActive': '<S337>:110' */
                LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

                /* Entry 'LKALeftActive': '<S337>:109' */
                LKAS_DW.stLKAState = 4U;
                LKAS_DW.stLKAActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S143>/LKA_State_Machine' */
}

/*
 * Output and update for action system:
 *    '<S358>/Ph1SWA'
 *    '<S367>/Ph1SWA'
 *    '<S394>/Ph1SWA'
 *    '<S404>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S362>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S362>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S358>/Ph2SWA'
 *    '<S367>/Ph2SWA'
 *    '<S394>/Ph2SWA'
 *    '<S404>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S363>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S363>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S358>/Ph3SWA'
 *    '<S394>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S364>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S367>/Ph3SWA'
 *    '<S404>/Ph3SWA'
 */
void LKAS_Ph3SWA_m(float32 *rty_Out)
{
  /* SignalConversion: '<S373>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S373>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S430>/If Action Subsystem4'
 *    '<S430>/If Action Subsystem3'
 *    '<S537>/If Action Subsystem3'
 *    '<S537>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S442>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S442>/Constant'
   */
  *rty_Out = false;
}

/*
 * System initialize for enable system:
 *    '<S445>/ExitCount'
 *    '<S445>/ExitCount1'
 */
void LKAS_ExitCount_Init(DW_ExitCount_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S453>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S445>/ExitCount'
 *    '<S445>/ExitCount1'
 */
void LKAS_ExitCount_Reset(DW_ExitCount_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S453>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S445>/ExitCount'
 *    '<S445>/ExitCount1'
 */
void LKAS_ExitCount_Disable(boolean *rty_Out, DW_ExitCount_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S445>/ExitCount' incorporates:
   *  EnablePort: '<S453>/Enable'
   */
  /* Disable for Outport: '<S453>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S445>/ExitCount' */
  localDW->ExitCount_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S445>/ExitCount'
 *    '<S445>/ExitCount1'
 */
void LKAS_ExitCount(boolean rtu_Enable, float32 rtu_SampleTime, float32
                    rtu_ExitTime, boolean *rty_Out, DW_ExitCount_LKAS_T *localDW)
{
  float32 rtb_Saturation_ga;

  /* Outputs for Enabled SubSystem: '<S445>/ExitCount' incorporates:
   *  EnablePort: '<S453>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->ExitCount_MODE) {
      LKAS_ExitCount_Reset(localDW);
      localDW->ExitCount_MODE = true;
    }

    /* Sum: '<S453>/Add' incorporates:
     *  Memory: '<S453>/Memory'
     */
    rtb_Saturation_ga = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S453>/Saturation' */
    if (rtb_Saturation_ga > 60.0F) {
      rtb_Saturation_ga = 60.0F;
    } else {
      if (rtb_Saturation_ga < 0.0F) {
        rtb_Saturation_ga = 0.0F;
      }
    }

    /* End of Saturate: '<S453>/Saturation' */

    /* RelationalOperator: '<S453>/Relational Operator' */
    *rty_Out = (rtb_Saturation_ga >= rtu_ExitTime);

    /* Update for Memory: '<S453>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_ga;
  } else {
    if (localDW->ExitCount_MODE) {
      LKAS_ExitCount_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S445>/ExitCount' */
}

/*
 * Output and update for action system:
 *    '<S466>/If Action Subsystem'
 *    '<S466>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_o(boolean *rty_Out)
{
  /* SignalConversion: '<S470>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S470>/Constant'
   */
  *rty_Out = true;
}

/*
 * Output and update for atomic system:
 *    '<S551>/MATLAB Function'
 *    '<S570>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_DvtThresUprLDW, float32 rtu_LaneWidth,
  float32 rtu_LKA_CarWidth, float32 *rty_ThresDet_coefficient)
{
  float32 tmp;

  /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Enable Condition  (EnaC)/LDW Own Condition (LDWOwnC)/Vehicle Position Check (VehPosChk)/Subsystem/MATLAB Function': '<S552>:1' */
  /* '<S552>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
  /* '<S552>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
  /* '<S552>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
  /* '<S552>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
  /* '<S552>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
  tmp = (2.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth;
  *rty_ThresDet_coefficient = fminf(fmaxf(0.0F, (fminf(fmaxf(tmp, rtu_LaneWidth),
    (6.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth) - tmp) / (4.0F *
    rtu_DvtThresUprLDW)), 1.0F);
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_ESC_VehSpd;
  float32 rtb_Gain_a;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_Gain_n;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_MAX_DELAY_EPSSTAR_TIME;
  float32 rtb_LL_HandsOff_ExitTime;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_LFClb_TFC_KpVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KpVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KpV1_C;
  float32 rtb_LL_LFClb_TFC_KpV2_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KdV1_C;
  float32 rtb_LL_LFClb_TFC_KdV2_C;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_LL_HandsOff_TextTime;
  float32 rtb_LL_HandsOff_WarnTime;
  float32 rtb_R0_VR_k;
  float32 rtb_L0_VR_p;
  float32 rtb_R0_W_b;
  float32 rtb_L0_W_g;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_R1_VR;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_VR_m;
  float32 rtb_R1_W;
  float32 rtb_R1_VR_i;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_lStpLngth_C;
  float32 rtb_LL_DesDvt_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_e;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1;
  float32 rtb_phiHdAg_Lft;
  float32 rtb_Add5_i;
  float32 rtb_phiHdAg_Rgt;
  float32 rtb_Add_o;
  float32 rtb_Add_a;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge;
  float32 rtb_Switch_n;
  float32 rtb_Saturation_c;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Multiply;
  float32 rtb_Switch_d;
  float32 rtb_Switch2_k;
  float32 rtb_Switch_h;
  float32 rtb_Saturation_co;
  float32 rtb_Abs1_n;
  float32 rtb_Abs_j;
  float32 rtb_UnaryMinus_f;
  float32 rtb_Divide_e;
  float32 rtb_Merge1;
  float32 rtb_Divide_g;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_o;
  float32 rtb_Divide_h;
  float32 rtb_Switch_ik;
  float32 rtb_Switch2_g;
  float32 rtb_Merge1_i;
  float32 rtb_Divide_c;
  float32 rtb_Switch_o;
  float32 rtb_Switch2_i;
  float32 rtb_Divide_k;
  float32 rtb_Switch_b;
  float32 rtb_Switch2_p;
  float32 rtb_Multiply_a;
  float32 rtb_Switch_j;
  float32 rtb_Switch2_f;
  float32 rtb_Memory;
  float32 rtb_Merge1_a;
  float32 rtb_Divide_i;
  float32 rtb_Switch_m;
  float32 rtb_Switch2_po;
  float32 rtb_Divide_b;
  float32 rtb_Switch_k;
  float32 rtb_Switch2_d;
  float32 rtb_Memory_p;
  float32 rtb_Merge1_g;
  float32 rtb_Divide_i4;
  float32 rtb_Switch_ir;
  float32 rtb_Switch2_j;
  float32 rtb_Divide_o;
  float32 rtb_Switch_l;
  float32 rtb_Switch2_c;
  float32 rtb_Saturation_k;
  float32 rtb_Divide_d1;
  float32 rtb_Divide_n;
  float32 rtb_Add_ah;
  float32 rtb_Add_g;
  float32 rtb_LKA_ExitFlg_Mon;
  float32 rtb_phiHdAg;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_ThresDet_coefficient;
  float32 rtb_ThresDet_coefficient_e;
  float32 rtb_Saturation2_m;
  float32 rtb_Add1_or;
  float32 rtb_Merge_l;
  float32 rtb_Gain_gy;
  float32 rtb_Gain1_e;
  float32 rtb_Add_jl;
  float32 rtb_Add_ni;
  float32 rtb_Saturation6;
  float32 rtb_Saturation2_h;
  float32 rtb_Saturation2_g;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_n;
  float32 rtb_Saturation_gk;
  float32 rtb_Add1_j;
  float32 rtb_kphtomps_m;
  float32 rtb_Saturation_bi;
  float32 rtb_Switch2_k2;
  float32 rtb_Switch_ny;
  float32 rtb_Switch2_pe;
  float32 rtb_Gain1_c;
  float32 rtb_Switch_c;
  float32 rtb_Switch2_jn;
  float32 rtb_Divide5_n;
  float32 rtb_Divide2_n;
  float32 rtb_Merge_k;
  float32 rtb_Switch_ok;
  float32 rtb_Switch2_c3;
  float32 rtb_Divide7;
  float32 rtb_Switch_hb;
  float32 rtb_Switch2_dj;
  float32 rtb_Saturation_c1;
  float32 rtb_Switch_c1;
  float32 rtb_Add_d1;
  float32 rtb_Switch_jv;
  float32 rtb_Switch2_e;
  float32 rtb_UkYk1_g;
  float32 rtb_Switch_cd;
  float32 rtb_Switch2_n;
  float32 rtb_Abs1_k;
  float32 rtb_Abs_k;
  float32 rtb_Add1_j3;
  float32 rtb_Merge_g;
  float32 rtb_Merge_c;
  float32 rtb_Merge_lz;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_m;
  float32 rtb_Saturation_jw;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_In;
  float32 rtb_In_i;
  float32 rtb_In_n;
  float32 rtb_Plan;
  float32 rtb_T1_k;
  float32 rtb_Plan_g;
  float32 rtb_T1_f;
  float32 rtb_Gain_b;
  float32 rtb_Merge_h;
  float32 rtb_kphTomps_a;
  float32 rtb_Divide3_j;
  float32 rtb_Gain2_l;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_p;
  uint16 rtb_Saturation1_g;
  uint16 rtb_Saturation1_p2;
  uint16 rtb_Saturation1_m;
  uint16 rtb_Saturation1_dg;
  uint16 rtb_Saturation2_d;
  uint16 rtb_Add_nv;
  uint16 rtb_Saturation1_h;
  uint16 rtb_Saturation1_ey;
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_o;
  uint8 rtb_L0_Type_f;
  uint8 rtb_IMAPve_d_APA_AutoPark_WorkS;
  uint8 rtb_IMAPve_d_BCM_HazardLamp_Swi;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_EPS_TrqLim_State;
  uint8 rtb_IMAPve_d_EPS_Trq_State;
  uint8 rtb_IMAPve_d_ESC_LatAcc_Valid;
  uint8 rtb_IMAPve_d_ESC_LonAcc_Valid;
  uint8 rtb_IMAPve_d_ESC_VehSpd_Valid;
  uint8 rtb_IMAPve_d_ESC_YawRate_Valid;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L1_Type;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_R1_Type;
  uint8 rtb_IMAPve_d_SAS_Clb_State;
  uint8 rtb_IMAPve_d_SAS_Trim_State;
  uint8 rtb_IMAPve_d_SWS_Failure_Status;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_LDW_State;
  uint8 rtb_Switch8;
  uint8 rtb_Switch8_k;
  uint8 rtb_Switch8_p;
  uint8 rtb_LKA_Mode;
  uint8 rtb_Saturation1_l;
  boolean rtb_LogicalOperator2;
  boolean rtb_ADIA_DTC_EMS_14B_InvOorReal;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxT;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinT;
  boolean rtb_ADIAve_e_Node_ACU_Validity;
  boolean rtb_ADIAve_e_Node_EPB_Validity;
  boolean rtb_ADIA_Inner_FRadar_FaultStat;
  boolean rtb_ADIAve_d_sen_sta_Corner_rad;
  boolean rtb_ADIAve_e_Node_EMS_Validity;
  boolean rtb_ADIAve_e_Node_TBOX_Validity;
  boolean rtb_ADIA_DTC_ESC_EPBErrorStatus;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorTCS;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorVeh;
  boolean rtb_ADIA_DTC_MP5_366_OorAEBButt;
  boolean rtb_ADIA_DTC_MP5_366_OorFCWButt;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorSta;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorYaw;
  boolean rtb_ADIA_DTC_ESC6_123_InvOorDyn;
  boolean rtb_ADIA_DTC_ESC6_123_InvUnfilY;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehDri;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehHol;
  boolean rtb_ADIA_DTC_GW_MP5_413_OorISAM;
  boolean rtb_ADIA_DTC_SCC_309_OorACCButt;
  boolean rtb_ADIA_DTC_BCM3_33C_InvBrkLig;
  boolean rtb_ADIA_DTC_EMS_14A_OorACCStat;
  boolean rtb_ADIA_DTC_EMS10_88_InvAccPed;
  boolean rtb_ADIA_DTC_EMS5_E0_InvOorBrkP;
  boolean rtb_ADIA_DTC_EMS5_E0_OorEngineS;
  boolean rtb_LogicalOperator3_ch;
  boolean rtb_OR;
  boolean rtb_Compare_f;
  boolean rtb_UnitDelay_c;
  boolean rtb_Merge_o;
  boolean rtb_Compare_a;
  boolean rtb_UnitDelay_b;
  boolean rtb_Compare_pv;
  boolean rtb_Merge_cl;
  boolean rtb_Merge_a;
  boolean rtb_Compare_nr;
  boolean rtb_LogicalOperator1_k;
  boolean rtb_RelationalOperator6_i;
  boolean rtb_RelationalOperator5;
  boolean rtb_Compare_gm;
  boolean rtb_Memory1_n;
  boolean rtb_Merge_n;
  boolean rtb_LKA_Main_Switch;
  boolean rtb_LKA_Switch;
  float32 x10;
  float32 x20;
  float32 x1;
  sint32 i;
  UInt16 tmpRead;
  UInt16 tmpRead_0;
  UInt16 tmpRead_1;
  UInt16 tmpRead_2;
  UInt16 tmpRead_3;
  UInt16 tmpRead_4;
  UInt16 tmpRead_5;
  UInt16 tmpRead_6;
  UInt16 tmpRead_7;
  UInt16 tmpRead_8;
  UInt16 tmpRead_9;
  UInt16 tmpRead_a;
  UInt16 tmpRead_b;
  UInt16 tmpRead_c;
  UInt16 tmpRead_d;
  UInt16 tmpRead_e;
  UInt16 tmpRead_f;
  UInt16 tmpRead_g;
  UInt16 tmpRead_h;
  UInt16 tmpRead_i;
  UInt16 tmpRead_j;
  UInt16 tmpRead_k;
  UInt16 tmpRead_l;
  UInt16 tmpRead_m;
  UInt16 tmpRead_n;
  UInt16 tmpRead_o;
  UInt16 tmpRead_p;
  T_M_Nm_Float32 tmpRead_q;
  T_M_Nm_Float32 tmpRead_r;
  UInt16 tmpRead_s;
  UInt16 tmpRead_t;
  UInt16 tmpRead_u;
  UInt16 tmpRead_v;
  UInt16 tmpRead_w;
  UInt16 tmpRead_x;
  UInt16 tmpRead_y;
  UInt16 tmpRead_z;
  T_M_Nm_Float32 tmpRead_10;
  T_M_Nm_Float32 tmpRead_11;
  T_M_Nm_Float32 tmpRead_12;
  T_M_Nm_Float32 tmpRead_13;
  UInt16 tmpRead_14;
  UInt16 tmpRead_15;
  T_M_Nm_Float32 tmpRead_16;
  T_M_Nm_Float32 tmpRead_17;
  T_M_Nm_Float32 tmpRead_18;
  T_M_Nm_Float32 tmpRead_19;
  UInt16 tmpRead_1a;
  UInt16 tmpRead_1b;
  UInt16 tmpRead_1c;
  UInt16 tmpRead_1d;
  uint8 rtb_IMAPve_d_BCM_HazardLamp;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  uint8 rtb_FDMMve_d_LkaFcnConf;
  uint8 rtb_IMAPve_d_LDW_Warn_Mode;
  uint8 rtb_IMAPve_d_LKA_Mode;
  UInt8 rtb_EPS_LKA_Control;
  float32 rtb_Abs_lt;
  float32 rtb_Saturation1;
  boolean rtb_BCM_Left_Light;
  boolean rtb_BCM_Right_Light;
  float32 rtb_L0_C2;
  float32 rtb_R0_C2;
  uint8 rtb_L0_Q;
  uint8 rtb_Lrg_Q;
  boolean rtb_LFlg;
  uint8 rtb_Rrg_Q;
  boolean rtb_RFlg;
  float32 rtb_L0_C0_d2;
  float32 rtb_R0_C0_f;
  float32 rtb_L0_C0_h;
  float32 rtb_LL_CompHdAg_C;
  float32 rtb_L0_C1_d;
  float32 rtb_R0_C1_a;
  float32 rtb_L0_C1_j;
  float32 rtb_L0_C2_g;
  float32 rtb_L0_C3;
  float32 rtb_R0_C3;
  float32 rtb_R0_C2_e;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  float32 rtb_LL_RlsDet_tiTrqChkT_DISABLE;
  float32 rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  boolean rtb_LL_SingleLane_Disable_Swt;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LL_LKAExPrcs_tiExitDelayTim;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_Abs_n4;
  float32 rtb_Abs_g;
  float32 rtb_TTLC_f;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_l;
  boolean rtb_LogicalOperator3_pm;
  boolean rtb_RelationalOperator_ct;
  boolean rtb_LogicalOperator_g;
  boolean rtb_Compare_gu;
  boolean rtb_LogicalOperator_jbm;
  boolean rtb_Compare_ih;
  boolean rtb_LogicalOperator_ki;
  boolean rtb_Compare_nm;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_n5;
  boolean rtb_stDvrTkConFlg_d;
  boolean rtb_LogicalOperator_bp;
  boolean rtb_LogicalOperator_mk;
  float32 rtb_ThresDet_coefficient_c;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge_p;
  uint32 rtb_Add;
  float32 rtb_R0_VR;
  float32 rtb_L0_VR;
  float32 rtb_R0_W;
  float32 rtb_L0_W;
  float32 rtb_Saturation_a1;
  uint16 rtb_Saturation_fq;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  float32 rtb_TTLC;
  float32 rtb_TLft;
  float32 tmp;
  float32 rtb_Abs_p_tmp;
  float32 rtb_Add5_i_tmp;
  float32 rtb_LogicalOperator3_j_tmp;
  boolean rtb_RelationalOperator_l_tmp;
  float32 rtb_Add_o_tmp;
  float32 rtb_Add_a_tmp;
  boolean exitg1;

  /* Inport: '<Root>/IMAPve_d_BCM_HazardLamp' */
  Rte_Read_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp(&rtb_Saturation_fq);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  Rte_Read_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc(&rtb_IMAPve_g_ESC_LonAcc);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_ESC_LatAcc' */
  Rte_Read_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc(&rtb_Saturation_a1);

  /* Inport: '<Root>/IMAPve_g_SW_Angle_Speed' */
  Rte_Read_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
    (&rtb_ThresDet_coefficient_c);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  Rte_Read_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq(&rtb_IMAPve_g_EPS_SW_Trq);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_EPS_LKA_State' */
  Rte_Read_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State(&tmpRead_5);

  /* Inport: '<Root>/IMAPve_d_LDW_Warn_Mode' */
  Rte_Read_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode(&tmpRead_2);

  /* Inport: '<Root>/IMAPve_d_LKA_Mode' */
  Rte_Read_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode(&tmpRead_1);

  /* Inport: '<Root>/IMAPve_d_LKA_Main_Switch' */
  Rte_Read_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch(&tmpRead_0);

  /* Inport: '<Root>/FDMMve_d_LkaFcnConf' */
  Rte_Read_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf(&tmpRead);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' */
  rtb_IMAPve_d_BCM_HazardLamp = (uint8)rtb_Saturation_fq;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)tmpRead_5;

  /* DataTypeConversion: '<S1>/FDMMve_d_LkaFcnConf_1' */
  rtb_FDMMve_d_LkaFcnConf = (uint8)tmpRead;

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' */
  rtb_IMAPve_d_LDW_Warn_Mode = (uint8)tmpRead_2;

  /* DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1' */
  rtb_IMAPve_d_LKA_Mode = (uint8)tmpRead_1;

  /* MATLAB Function: '<S104>/MATLAB Function' incorporates:
   *  DataTypeConversion: '<S104>/Cast To Boolean'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsMP5Info/MATLAB Function': '<S139>:1' */
  /* '<S139>:1:2' LKA_Switch = (LkaFcnConf > 0 || LKA_Main_Switch_In > 0); */
  rtb_LFlg = ((((sint32)rtb_FDMMve_d_LkaFcnConf) > 0) || (((sint32)((uint8)
    tmpRead_0)) != 0));
  rtb_LKA_Switch = rtb_LFlg;

  /* '<S139>:1:3' LKA_Main_Switch = LKA_Switch; */
  rtb_LKA_Main_Switch = rtb_LFlg;

  /* '<S139>:1:5' if LDW_Warn_Mode_In == 2 || LkaFcnConf == 3 || LkaFcnConf == 6 || LkaFcnConf == 9 || LkaFcnConf == 12 */
  if (((((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 2) || (((sint32)
           rtb_FDMMve_d_LkaFcnConf) == 3)) || (((sint32)rtb_FDMMve_d_LkaFcnConf)
         == 6)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 9)) || (((sint32)
        rtb_FDMMve_d_LkaFcnConf) == 12)) {
    /* '<S139>:1:6' LDW_Warn_Mode = uint8(2); */
    rtb_IMAPve_d_LDW_Warn_Mode = 2U;
  } else if (((((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 1) || (((sint32)
      rtb_FDMMve_d_LkaFcnConf) == 2)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 5))
              || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 8)) || (((sint32)
               rtb_FDMMve_d_LkaFcnConf) == 11)) {
    /* '<S139>:1:7' elseif  LDW_Warn_Mode_In == 1 || LkaFcnConf == 2 || LkaFcnConf == 5 || LkaFcnConf == 8 || LkaFcnConf == 11 */
    /* '<S139>:1:8' LDW_Warn_Mode = uint8(1); */
    rtb_IMAPve_d_LDW_Warn_Mode = 1U;
  } else if (((((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 0) || (((sint32)
      rtb_FDMMve_d_LkaFcnConf) == 1)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 4))
              || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 7)) || (((sint32)
               rtb_FDMMve_d_LkaFcnConf) == 10)) {
    /* '<S139>:1:9' elseif  LDW_Warn_Mode_In == 0 || LkaFcnConf == 1 || LkaFcnConf == 4 || LkaFcnConf == 7 || LkaFcnConf == 10 */
    /* '<S139>:1:10' LDW_Warn_Mode = uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  } else {
    /* '<S139>:1:11' else */
    /* '<S139>:1:12' LDW_Warn_Mode = uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  }

  /* '<S139>:1:15' if LKA_Switch */
  if (rtb_LFlg) {
    /* '<S139>:1:16' if LkaFcnConf == 4 || LkaFcnConf == 5 || LkaFcnConf == 6 || LkaFcnConf == 10 || LkaFcnConf == 11 || LkaFcnConf == 12 || LKA_Mode_In == 1 */
    if (((((((((sint32)rtb_FDMMve_d_LkaFcnConf) == 4) || (((sint32)
               rtb_FDMMve_d_LkaFcnConf) == 5)) || (((sint32)
              rtb_FDMMve_d_LkaFcnConf) == 6)) || (((sint32)
             rtb_FDMMve_d_LkaFcnConf) == 10)) || (((sint32)
            rtb_FDMMve_d_LkaFcnConf) == 11)) || (((sint32)
           rtb_FDMMve_d_LkaFcnConf) == 12)) || (((sint32)rtb_IMAPve_d_LKA_Mode) ==
         1)) {
      /* '<S139>:1:17' LKA_Mode = uint8(2); */
      LKAS_DW.LKA_Mode_g = 2U;
    } else if (((((((((sint32)rtb_FDMMve_d_LkaFcnConf) == 1) || (((sint32)
        rtb_FDMMve_d_LkaFcnConf) == 2)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) ==
      3)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 7)) || (((sint32)
        rtb_FDMMve_d_LkaFcnConf) == 8)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) ==
      9)) || (((sint32)rtb_IMAPve_d_LKA_Mode) == 0)) {
      /* '<S139>:1:18' elseif LkaFcnConf == 1 || LkaFcnConf == 2 || LkaFcnConf == 3 || LkaFcnConf == 7 || LkaFcnConf == 8 || LkaFcnConf == 9 || LKA_Mode_In == 0 */
      /* '<S139>:1:19' LKA_Mode = uint8(1); */
      LKAS_DW.LKA_Mode_g = 1U;
    } else {
      /* '<S139>:1:20' else */
      /* '<S139>:1:21' LKA_Mode = uint8(0); */
      LKAS_DW.LKA_Mode_g = 0U;
    }
  } else {
    /* '<S139>:1:23' else */
    /* '<S139>:1:24' LKA_Mode = uint8(0); */
    LKAS_DW.LKA_Mode_g = 0U;
  }

  /* End of MATLAB Function: '<S104>/MATLAB Function' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_L0_Q' */
  Rte_Read_IMAPve_d_L0_Q_IMAPve_d_L0_Q(&tmpRead_w);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' */
  rtb_EPS_LKA_Control = (UInt8)tmpRead_w;

  /* Switch: '<S116>/Switch' incorporates:
   *  Constant: '<S116>/Constant'
   */
  if (rtb_EPS_LKA_Control >= ((UInt8)((uint8)2U))) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = (uint8)rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S116>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_Lrg_Q_BACK' */
  Rte_Read_IMAPve_d_Lrg_Q_BACK_IMAPve_d_Lrg_Q_BACK(&tmpRead_1c);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_Lrg_Q_BACK_1' */
  rtb_EPS_LKA_Control = (UInt8)tmpRead_1c;

  /* Switch: '<S115>/Switch1' incorporates:
   *  Constant: '<S115>/Constant1'
   */
  if (rtb_EPS_LKA_Control >= ((UInt8)((uint8)2U))) {
    rtb_Lrg_Q = ((uint8)3U);
  } else {
    rtb_Lrg_Q = (uint8)rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S115>/Switch1' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_Lrg_C0_BACK' */
  Rte_Read_IMAPve_g_Lrg_C0_BACK_IMAPve_g_Lrg_C0_BACK(&rtb_L0_C0_d2);

  /* Inport: '<Root>/IMAPve_g_L0_C0' */
  Rte_Read_IMAPve_g_L0_C0_IMAPve_g_L0_C0(&rtb_Saturation1);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* MATLAB Function: '<S123>/Switch_L0_or_Lrg' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C0_BACK_1'
   *  Memory: '<S123>/Memory1'
   *  UnaryMinus: '<S110>/Unary Minus'
   *  UnaryMinus: '<S110>/Unary Minus18'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/Switch_L0_or_Lrg': '<S129>:1' */
  rtb_R0_C0_f = -rtb_L0_C0_d2;

  /* '<S129>:1:2' if Lrg_Q == 3 */
  if (((sint32)rtb_Lrg_Q) == 3) {
    /* '<S129>:1:3' Lrg_C0 = Lrg_C0 + Offset; */
    rtb_R0_C0_f = (-rtb_L0_C0_d2) + LKAS_DW.Memory1_PreviousInput;

    /* '<S129>:1:4' if L0_Q == 3 */
    if (((sint32)rtb_L0_Q) == 3) {
      /* '<S129>:1:5' if Lrg_C0 > L0_C0 */
      if (rtb_R0_C0_f > (-rtb_Saturation1)) {
        /* '<S129>:1:6' LFlg = true; */
        rtb_LFlg = true;
      } else {
        /* '<S129>:1:7' else */
        /* '<S129>:1:8' LFlg = false; */
        rtb_LFlg = false;
      }
    } else {
      /* '<S129>:1:10' else */
      /* '<S129>:1:11' LFlg = true; */
      rtb_LFlg = true;
    }
  } else {
    /* '<S129>:1:13' else */
    /* '<S129>:1:14' LFlg = false; */
    rtb_LFlg = false;
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_Rrg_Q_BACK' */
  Rte_Read_IMAPve_d_Rrg_Q_BACK_IMAPve_d_Rrg_Q_BACK(&tmpRead_1d);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S123>/Switch1' */
  if (rtb_LFlg) {
    rtb_FDMMve_d_LkaFcnConf = rtb_Lrg_Q;
  } else {
    rtb_FDMMve_d_LkaFcnConf = rtb_L0_Q;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_Rrg_Q_BACK_1' */
  rtb_EPS_LKA_Control = (UInt8)tmpRead_1d;

  /* Switch: '<S117>/Switch1' incorporates:
   *  Constant: '<S117>/Constant1'
   */
  if (rtb_EPS_LKA_Control >= ((UInt8)((uint8)2U))) {
    rtb_Rrg_Q = ((uint8)3U);
  } else {
    rtb_Rrg_Q = (uint8)rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S117>/Switch1' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_R0_Q' */
  Rte_Read_IMAPve_d_R0_Q_IMAPve_d_R0_Q(&tmpRead_y);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' */
  rtb_EPS_LKA_Control = (UInt8)tmpRead_y;

  /* Switch: '<S112>/Switch1' incorporates:
   *  Constant: '<S112>/Constant1'
   */
  if (rtb_EPS_LKA_Control >= ((UInt8)((uint8)2U))) {
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
  }

  /* End of Switch: '<S112>/Switch1' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_Rrg_C0_BACK' */
  Rte_Read_IMAPve_g_Rrg_C0_BACK_IMAPve_g_Rrg_C0_BACK(&rtb_L0_C0_h);

  /* Inport: '<Root>/IMAPve_g_R0_C0' */
  Rte_Read_IMAPve_g_R0_C0_IMAPve_g_R0_C0(&rtb_Abs_lt);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* MATLAB Function: '<S123>/Switch_R0_or_Rrg' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C0_BACK_1'
   *  Memory: '<S123>/Memory1'
   *  UnaryMinus: '<S110>/Unary Minus22'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/Switch_R0_or_Rrg': '<S130>:1' */
  rtb_LL_CompHdAg_C = -rtb_L0_C0_h;

  /* '<S130>:1:2' if Rrg_Q == 3 */
  if (((sint32)rtb_Rrg_Q) == 3) {
    /* '<S130>:1:3' Rrg_C0 = Rrg_C0 - Offset; */
    rtb_LL_CompHdAg_C = (-rtb_L0_C0_h) - LKAS_DW.Memory1_PreviousInput;

    /* '<S130>:1:4' if R0_Q == 3 */
    if (((sint32)rtb_EPS_LKA_Control) == 3) {
      /* '<S130>:1:5' if Rrg_C0 < R0_C0 */
      if (rtb_LL_CompHdAg_C < (-rtb_Abs_lt)) {
        /* '<S130>:1:6' RFlg = true; */
        rtb_RFlg = true;

        /* Switch: '<S123>/Switch' */
        rtb_IMAPve_d_LKA_Mode = 3U;
      } else {
        /* '<S130>:1:7' else */
        /* '<S130>:1:8' RFlg = false; */
        rtb_RFlg = false;

        /* Switch: '<S123>/Switch' */
        rtb_IMAPve_d_LKA_Mode = (uint8)rtb_EPS_LKA_Control;
      }
    } else {
      /* '<S130>:1:10' else */
      /* '<S130>:1:11' RFlg = true; */
      rtb_RFlg = true;

      /* Switch: '<S123>/Switch' */
      rtb_IMAPve_d_LKA_Mode = 3U;
    }
  } else {
    /* '<S130>:1:13' else */
    /* '<S130>:1:14' RFlg = false; */
    rtb_RFlg = false;

    /* Switch: '<S123>/Switch' */
    rtb_IMAPve_d_LKA_Mode = (uint8)rtb_EPS_LKA_Control;
  }

  /* Chart: '<S111>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c25_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c25_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S118>:4' */
    LKAS_DW.is_c25_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S118>:3' */
    /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c25_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S118>:9' */
      /* '<S118>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_FDMMve_d_LkaFcnConf) == 3) && (((sint32)
            rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* Transition: '<S118>:13' */
        LKAS_DW.is_c25_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S118>:3' */
        /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_FDMMve_d_LkaFcnConf) == 3) && (((sint32)
              rtb_IMAPve_d_LKA_Mode) < 3)) {
          /* Transition: '<S118>:14' */
          LKAS_DW.is_c25_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S118>:7' */
          /* '<S118>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S118>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S118>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_FDMMve_d_LkaFcnConf) < 3) && (((sint32)
                rtb_IMAPve_d_LKA_Mode) == 3)) {
            /* Transition: '<S118>:23' */
            LKAS_DW.is_c25_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S118>:5' */
            /* '<S118>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S118>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S118>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S118>:5' */
      /* '<S118>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_FDMMve_d_LkaFcnConf) == 3) && (((sint32)
            rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* Transition: '<S118>:16' */
        LKAS_DW.is_c25_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S118>:3' */
        /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_FDMMve_d_LkaFcnConf) == 3) && (((sint32)
              rtb_IMAPve_d_LKA_Mode) < 3)) {
          /* Transition: '<S118>:18' */
          LKAS_DW.is_c25_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S118>:7' */
          /* '<S118>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S118>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S118>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_IMAPve_d_LKA_Mode) < 3) {
            /* Transition: '<S118>:11' */
            LKAS_DW.is_c25_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S118>:3' */
      /* '<S118>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_FDMMve_d_LkaFcnConf) < 3) && (((sint32)
            rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* Transition: '<S118>:6' */
        LKAS_DW.is_c25_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S118>:5' */
        /* '<S118>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S118>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S118>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_FDMMve_d_LkaFcnConf) == 3) && (((sint32)
              rtb_IMAPve_d_LKA_Mode) < 3)) {
          /* Transition: '<S118>:8' */
          LKAS_DW.is_c25_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S118>:7' */
          /* '<S118>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S118>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S118>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_FDMMve_d_LkaFcnConf) < 3) && (((sint32)
                rtb_IMAPve_d_LKA_Mode) < 3)) {
            /* Transition: '<S118>:10' */
            /* '<S118>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c25_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S118>:7' */
      /* '<S118>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_FDMMve_d_LkaFcnConf) == 3) && (((sint32)
            rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* Transition: '<S118>:17' */
        LKAS_DW.is_c25_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S118>:3' */
        /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_FDMMve_d_LkaFcnConf) < 3) && (((sint32)
              rtb_IMAPve_d_LKA_Mode) == 3)) {
          /* Transition: '<S118>:19' */
          LKAS_DW.is_c25_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S118>:5' */
          /* '<S118>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S118>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S118>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_FDMMve_d_LkaFcnConf) < 3) {
            /* Transition: '<S118>:12' */
            LKAS_DW.is_c25_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S111>/LaneReconstructSM' */

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  MATLAB Function: '<S123>/Switch_L0_or_Lrg'
   *  UnaryMinus: '<S110>/Unary Minus'
   */
  if (rtb_LFlg) {
    rtb_L0_C0_d2 = rtb_R0_C0_f;
  } else {
    rtb_L0_C0_d2 = -rtb_Saturation1;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  MATLAB Function: '<S123>/Switch_R0_or_Rrg'
   *  UnaryMinus: '<S110>/Unary Minus4'
   */
  if (rtb_RFlg) {
    rtb_R0_C0_f = rtb_LL_CompHdAg_C;
  } else {
    rtb_R0_C0_f = -rtb_Abs_lt;
  }

  /* Switch: '<S128>/Switch' incorporates:
   *  Constant: '<S137>/Constant'
   *  Constant: '<S138>/Constant'
   *  Delay: '<S128>/Delay'
   *  Gain: '<S128>/Gain'
   *  Logic: '<S128>/Logical Operator'
   *  RelationalOperator: '<S137>/Compare'
   *  RelationalOperator: '<S138>/Compare'
   *  Sum: '<S128>/Add'
   */
  if ((rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) && (rtb_IMAPve_d_LKA_Mode >=
       ((uint8)2U))) {
    rtb_Saturation1 = ((-1.0F) * rtb_L0_C0_d2) + rtb_R0_C0_f;
  } else {
    rtb_Saturation1 = LKAS_DW.Delay_DSTATE;
  }

  /* End of Switch: '<S128>/Switch' */

  /* Sum: '<S136>/Add1' incorporates:
   *  Memory: '<S136>/Memory'
   *  Product: '<S136>/Divide'
   *  Product: '<S136>/Divide1'
   */
  rtb_Abs_lt = (rtb_Saturation1 * LKAS_ConstB.Divide2) + (LKAS_ConstB.Add2 *
    LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S128>/Saturation1' */
  if (rtb_Abs_lt > 5.5F) {
    rtb_Saturation1 = 5.5F;
  } else if (rtb_Abs_lt < 2.5F) {
    rtb_Saturation1 = 2.5F;
  } else {
    rtb_Saturation1 = rtb_Abs_lt;
  }

  /* End of Saturate: '<S128>/Saturation1' */

  /* Switch: '<S111>/Switch1' incorporates:
   *  Gain: '<S120>/Gain'
   *  Sum: '<S120>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_h = rtb_L0_C0_d2;
  } else {
    rtb_L0_C0_h = (rtb_Saturation1 - rtb_R0_C0_f) * (-1.0F);
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_Lrg_C1_BACK' */
  Rte_Read_IMAPve_g_Lrg_C1_BACK_IMAPve_g_Lrg_C1_BACK(&rtb_L0_C1_d);

  /* Inport: '<Root>/IMAPve_g_L0_C1' */
  Rte_Read_IMAPve_g_L0_C1_IMAPve_g_L0_C1(&rtb_R0_C1_a);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S658>/Switch24' incorporates:
   *  Constant: '<S658>/LL_CompHdAg_C=0.005'
   */
  if (LKAS_ConstB.DataTypeConversion38 != 0.0F) {
    rtb_LL_CompHdAg_C = LKAS_ConstB.DataTypeConversion38;
  } else {
    rtb_LL_CompHdAg_C = LL_CompHdAg_C;
  }

  /* End of Switch: '<S658>/Switch24' */

  /* Switch: '<S123>/Switch1' incorporates:
   *  Constant: '<S132>/Constant'
   *  RelationalOperator: '<S132>/Compare'
   *  Switch: '<S124>/Switch1'
   */
  if (rtb_LFlg) {
    /* Switch: '<S125>/Switch1' incorporates:
     *  Constant: '<S133>/Constant'
     *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C1_BACK_1'
     *  RelationalOperator: '<S133>/Compare'
     *  Sum: '<S125>/Add'
     *  UnaryMinus: '<S110>/Unary Minus19'
     */
    if (rtb_Lrg_Q == ((uint8)3U)) {
      rtb_L0_C1_d = rtb_LL_CompHdAg_C + (-rtb_L0_C1_d);
    } else {
      rtb_L0_C1_d = -rtb_L0_C1_d;
    }

    /* End of Switch: '<S125>/Switch1' */
  } else if (rtb_L0_Q == ((uint8)3U)) {
    /* Switch: '<S124>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
     *  Sum: '<S124>/Add'
     *  UnaryMinus: '<S110>/Unary Minus1'
     */
    rtb_L0_C1_d = rtb_LL_CompHdAg_C + (-rtb_R0_C1_a);
  } else {
    /* Switch: '<S124>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
     *  UnaryMinus: '<S110>/Unary Minus1'
     */
    rtb_L0_C1_d = -rtb_R0_C1_a;
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_Rrg_C1_BACK' */
  Rte_Read_IMAPve_g_Rrg_C1_BACK_IMAPve_g_Rrg_C1_BACK(&rtb_L0_C2_g);

  /* Inport: '<Root>/IMAPve_g_R0_C1' */
  Rte_Read_IMAPve_g_R0_C1_IMAPve_g_R0_C1(&rtb_L0_C1_j);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S123>/Switch' incorporates:
   *  Constant: '<S134>/Constant'
   *  RelationalOperator: '<S134>/Compare'
   *  Switch: '<S126>/Switch1'
   */
  if (rtb_RFlg) {
    /* Switch: '<S127>/Switch1' incorporates:
     *  Constant: '<S135>/Constant'
     *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C1_BACK_1'
     *  RelationalOperator: '<S135>/Compare'
     *  Sum: '<S127>/Add'
     *  UnaryMinus: '<S110>/Unary Minus23'
     */
    if (rtb_Rrg_Q == ((uint8)3U)) {
      rtb_R0_C1_a = rtb_LL_CompHdAg_C + (-rtb_L0_C2_g);
    } else {
      rtb_R0_C1_a = -rtb_L0_C2_g;
    }

    /* End of Switch: '<S127>/Switch1' */
  } else if (rtb_EPS_LKA_Control == ((UInt8)((uint8)3U))) {
    /* Switch: '<S126>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
     *  Sum: '<S126>/Add'
     *  UnaryMinus: '<S110>/Unary Minus5'
     */
    rtb_R0_C1_a = rtb_LL_CompHdAg_C + (-rtb_L0_C1_j);
  } else {
    /* Switch: '<S126>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
     *  UnaryMinus: '<S110>/Unary Minus5'
     */
    rtb_R0_C1_a = -rtb_L0_C1_j;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single1'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C1_j = rtb_L0_C1_d;
  } else {
    rtb_L0_C1_j = rtb_R0_C1_a;
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C2_BACK_1'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  Inport: '<Root>/IMAPve_g_Lrg_C2_BACK'
   *  UnaryMinus: '<S110>/Unary Minus16'
   *  UnaryMinus: '<S110>/Unary Minus2'
   */
  if (rtb_LFlg) {
    Rte_Read_IMAPve_g_Lrg_C2_BACK_IMAPve_g_Lrg_C2_BACK(&rtb_L0_C2);
    rtb_L0_C2 = -rtb_L0_C2;
  } else {
    Rte_Read_IMAPve_g_L0_C2_IMAPve_g_L0_C2(&rtb_L0_C2);
    rtb_L0_C2 = -rtb_L0_C2;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C2_BACK_1'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   *  Inport: '<Root>/IMAPve_g_Rrg_C2_BACK'
   *  UnaryMinus: '<S110>/Unary Minus20'
   *  UnaryMinus: '<S110>/Unary Minus6'
   */
  if (rtb_RFlg) {
    Rte_Read_IMAPve_g_Rrg_C2_BACK_IMAPve_g_Rrg_C2_BACK(&rtb_R0_C2);
    rtb_R0_C2 = -rtb_R0_C2;
  } else {
    Rte_Read_IMAPve_g_R0_C2_IMAPve_g_R0_C2(&rtb_R0_C2);
    rtb_R0_C2 = -rtb_R0_C2;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single2'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C2_g = rtb_L0_C2;
  } else {
    rtb_L0_C2_g = rtb_R0_C2;
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C3_BACK_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  Inport: '<Root>/IMAPve_g_Lrg_C3_BACK'
   *  UnaryMinus: '<S110>/Unary Minus17'
   *  UnaryMinus: '<S110>/Unary Minus3'
   */
  if (rtb_LFlg) {
    Rte_Read_IMAPve_g_Lrg_C3_BACK_IMAPve_g_Lrg_C3_BACK(&rtb_L0_C3);
    rtb_L0_C3 = -rtb_L0_C3;
  } else {
    Rte_Read_IMAPve_g_L0_C3_IMAPve_g_L0_C3(&rtb_L0_C3);
    rtb_L0_C3 = -rtb_L0_C3;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C3_BACK_1'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   *  Inport: '<Root>/IMAPve_g_Rrg_C3_BACK'
   *  UnaryMinus: '<S110>/Unary Minus21'
   *  UnaryMinus: '<S110>/Unary Minus7'
   */
  if (rtb_RFlg) {
    Rte_Read_IMAPve_g_Rrg_C3_BACK_IMAPve_g_Rrg_C3_BACK(&rtb_R0_C2_e);
    rtb_R0_C3 = -rtb_R0_C2_e;
  } else {
    Rte_Read_IMAPve_g_R0_C3_IMAPve_g_R0_C3(&rtb_R0_C2_e);
    rtb_R0_C3 = -rtb_R0_C2_e;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_LL_CompHdAg_C = rtb_L0_C3;
  } else {
    rtb_LL_CompHdAg_C = rtb_R0_C3;
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single2'
   *  Sum: '<S122>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_L0_C1_d = rtb_R0_C1_a;
    rtb_R0_C2_e = rtb_R0_C2;
    rtb_L0_C3 = rtb_R0_C3;
  } else {
    rtb_R0_C0_f = rtb_Saturation1 + rtb_L0_C0_d2;
    rtb_R0_C2_e = rtb_L0_C2;
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_TCU_Actual_Gear' */
  Rte_Read_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear(&tmpRead_o);

  /* Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch' */
  Rte_Read_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
    (&tmpRead_m);

  /* Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch' */
  Rte_Read_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch(&tmpRead_l);

  /* Inport: '<Root>/IMAPve_d_BCM_Right_Light' */
  Rte_Read_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light(&tmpRead_k);

  /* Inport: '<Root>/IMAPve_d_BCM_Left_Light' */
  Rte_Read_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light(&tmpRead_j);

  /* Inport: '<Root>/IMAPve_g_ESC_VehSpd' */
  Rte_Read_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd
    (&rtb_LL_RlsDet_tiTrqChkT_DISABLE);

  /* Inport: '<Root>/IMAPve_g_EPS_SteeringAngle' */
  Rte_Read_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
    (&rtb_LL_RlsDet_tiTrqChkT_EPS_DIS);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Saturate: '<S107>/Saturation' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1'
   */
  rtb_ESC_VehSpd = fmaxf(rtb_LL_RlsDet_tiTrqChkT_DISABLE, 0.1F);

  /* Gain: '<S106>/Gain' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1'
   */
  rtb_L0_C0_d2 = 1.0F * rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;

  /* Logic: '<S101>/Logical Operator' incorporates:
   *  Constant: '<S108>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1'
   *  RelationalOperator: '<S108>/Compare'
   */
  rtb_BCM_Left_Light = ((((sint32)((uint8)tmpRead_j)) != 0) || (((uint8)
    tmpRead_l) == ((uint8)1U)));

  /* Logic: '<S101>/Logical Operator1' incorporates:
   *  Constant: '<S109>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1'
   *  RelationalOperator: '<S109>/Compare'
   */
  rtb_BCM_Right_Light = ((((sint32)((uint8)tmpRead_k)) != 0) || (((uint8)
    tmpRead_m) == ((uint8)1U)));

  /* MultiPortSwitch: '<S105>/Multiport Switch' incorporates:
   *  Constant: '<S105>/Constant1'
   *  Constant: '<S105>/Constant3'
   *  DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1'
   */
  switch ((uint8)tmpRead_o) {
   case 0:
    rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
    break;

   case 1:
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
    break;

   case 2:
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
    break;

   case 3:
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
    break;

   case 4:
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
    break;

   case 5:
    rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
    break;

   case 6:
    rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
    break;

   case 7:
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
    break;

   case 8:
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
    break;

   case 9:
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
    break;

   default:
    rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
    break;
  }

  /* End of MultiPortSwitch: '<S105>/Multiport Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/ADIAve_g_BSWFaultStatus' */
  Rte_Read_ADIAve_g_BSWFaultStatus_ADIAve_g_BSWFaultStatus(&tmpRead_r);

  /* Inport: '<Root>/ADIAve_g_ASWFaultStatus' */
  Rte_Read_ADIAve_g_ASWFaultStatus_ADIAve_g_ASWFaultStatus(&tmpRead_q);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S659>/Switch58' incorporates:
   *  Constant: '<S659>/LLSMConClb4'
   *
   * Block description for '<S659>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S659>/Switch58' */

  /* Gain: '<S664>/Gain' incorporates:
   *  Constant: '<S664>/Constant'
   *  Sum: '<S664>/Add'
   */
  rtb_Gain_a = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S659>/Switch84' incorporates:
   *  Constant: '<S659>/LLSMConClb5'
   *
   * Block description for '<S659>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S659>/Switch84' */

  /* Switch: '<S659>/Switch85' incorporates:
   *  Constant: '<S659>/LLSMConClb6'
   *
   * Block description for '<S659>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S659>/Switch85' */

  /* Switch: '<S659>/Switch86' incorporates:
   *  Constant: '<S659>/LLSMConClb7'
   *
   * Block description for '<S659>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S659>/Switch86' */

  /* Switch: '<S659>/Switch54' incorporates:
   *  Constant: '<S659>/LLSMConClb12'
   *
   * Block description for '<S659>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S659>/Switch54' */

  /* Switch: '<S659>/Switch55' incorporates:
   *  Constant: '<S659>/LLSMConClb13'
   *
   * Block description for '<S659>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S659>/Switch55' */

  /* Switch: '<S659>/Switch60' incorporates:
   *  Constant: '<S659>/LLSMConClb17'
   *
   * Block description for '<S659>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S659>/Switch60' */

  /* Switch: '<S659>/Switch57' incorporates:
   *  Constant: '<S659>/LLSMConClb18'
   *
   * Block description for '<S659>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S659>/Switch57' */

  /* Switch: '<S659>/Switch59' incorporates:
   *  Constant: '<S659>/LLSMConClb19'
   *
   * Block description for '<S659>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_R0_C1_a = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_R0_C1_a = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S659>/Switch59' */

  /* Switch: '<S659>/Switch69' incorporates:
   *  Constant: '<S659>/LLSMConClb22'
   *
   * Block description for '<S659>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S659>/Switch69' */

  /* Gain: '<S661>/Gain' incorporates:
   *  Constant: '<S661>/Constant'
   *  Sum: '<S661>/Add'
   */
  rtb_Gain_n = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S659>/Switch68' incorporates:
   *  Constant: '<S659>/LLSMConClb23'
   *
   * Block description for '<S659>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S659>/Switch68' */

  /* Switch: '<S659>/Switch70' incorporates:
   *  Constant: '<S659>/LLSMConClb24'
   *
   * Block description for '<S659>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S659>/Switch70' */

  /* Switch: '<S659>/Switch71' incorporates:
   *  Constant: '<S659>/LLSMConClb25'
   *
   * Block description for '<S659>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S659>/Switch71' */

  /* Switch: '<S659>/Switch73' incorporates:
   *  Constant: '<S659>/LLSMConClb27'
   *
   * Block description for '<S659>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S659>/Switch73' */

  /* Switch: '<S659>/Switch62' incorporates:
   *  Constant: '<S659>/LLSMConClb31'
   *
   * Block description for '<S659>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S659>/Switch62' */

  /* Switch: '<S659>/Switch63' incorporates:
   *  Constant: '<S659>/LLSMConClb32'
   *
   * Block description for '<S659>/LLSMConClb32':
   *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
   */
  if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LKAS_ConstB.DataTypeConversion78;
  } else {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LL_MAX_DELAY_EPSSTAR_TIME;
  }

  /* End of Switch: '<S659>/Switch63' */

  /* Switch: '<S659>/Switch66' incorporates:
   *  Constant: '<S659>/LLSMConClb35'
   *
   * Block description for '<S659>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S659>/Switch66' */

  /* Switch: '<S659>/Switch38' incorporates:
   *  Constant: '<S659>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
   *
   * Block description for '<S659>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
   *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
    rtb_LL_RlsDet_tiTrqChkT_DISABLE = LKAS_ConstB.DataTypeConversion6;
  } else {
    rtb_LL_RlsDet_tiTrqChkT_DISABLE = LL_RlsDet_tiTrqChkT_DISABLE;
  }

  /* End of Switch: '<S659>/Switch38' */

  /* Switch: '<S659>/Switch44' incorporates:
   *  Constant: '<S659>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
   *
   * Block description for '<S659>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
   *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
   */
  if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = LKAS_ConstB.DataTypeConversion8;
  } else {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
  }

  /* End of Switch: '<S659>/Switch44' */

  /* Switch: '<S659>/Switch3' incorporates:
   *  Constant: '<S659>/LL_RlsDet_tiTDelTime_DISABLE=3'
   *
   * Block description for '<S659>/LL_RlsDet_tiTDelTime_DISABLE=3':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
    rtb_LL_HandsOff_ExitTime = LKAS_ConstB.DataTypeConversion3;
  } else {
    rtb_LL_HandsOff_ExitTime = LL_HandsOff_ExitTime;
  }

  /* End of Switch: '<S659>/Switch3' */

  /* Switch: '<S659>/Switch4' incorporates:
   *  Constant: '<S659>/LL_RlsDet_tiTDelTime_DISABLE=4'
   *
   * Block description for '<S659>/LL_RlsDet_tiTDelTime_DISABLE=4':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_SingleLane_Disable_Swt = (LKAS_ConstB.DataTypeConversion4 != 0.0F);
  } else {
    rtb_LL_SingleLane_Disable_Swt = LL_SingleLane_Disable_Swt;
  }

  /* End of Switch: '<S659>/Switch4' */

  /* Switch: '<S659>/Switch81' incorporates:
   *  Constant: '<S659>/LLSMConClb36'
   *
   * Block description for '<S659>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S659>/Switch81' */

  /* Switch: '<S659>/Switch82' incorporates:
   *  Constant: '<S659>/LLSMConClb37'
   *
   * Block description for '<S659>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S659>/Switch82' */

  /* Switch: '<S659>/Switch83' incorporates:
   *  Constant: '<S659>/LLSMConClb38'
   *
   * Block description for '<S659>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S659>/Switch83' */

  /* Switch: '<S659>/Switch75' incorporates:
   *  Constant: '<S659>/LLSMConClb39'
   *
   * Block description for '<S659>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S659>/Switch75' */

  /* Switch: '<S659>/Switch76' incorporates:
   *  Constant: '<S659>/LLSMConClb40'
   *
   * Block description for '<S659>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S659>/Switch76' */

  /* Switch: '<S659>/Switch77' incorporates:
   *  Constant: '<S659>/LLSMConClb41'
   *
   * Block description for '<S659>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S659>/Switch77' */

  /* Switch: '<S659>/Switch78' incorporates:
   *  Constant: '<S659>/LLSMConClb42'
   *
   * Block description for '<S659>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S659>/Switch78' */

  /* Switch: '<S658>/Switch3' incorporates:
   *  Constant: '<S658>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3_b != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3_b;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S658>/Switch3' */

  /* Switch: '<S658>/Switch31' incorporates:
   *  Constant: '<S658>/LL_LFClb_TFC_KpVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_c != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LKAS_ConstB.DataTypeConversion14_c;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S658>/Switch31' */

  /* Switch: '<S658>/Switch34' incorporates:
   *  Constant: '<S658>/LL_LFClb_TFC_KpVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4_p != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LKAS_ConstB.DataTypeConversion4_p;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S658>/Switch34' */

  /* Switch: '<S658>/Switch33' incorporates:
   *  Constant: '<S658>/LL_LFClb_TFC_KpV1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_e != 0.0F) {
    rtb_LL_LFClb_TFC_KpV1_C = LKAS_ConstB.DataTypeConversion7_e;
  } else {
    rtb_LL_LFClb_TFC_KpV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S658>/Switch33' */

  /* Switch: '<S658>/Switch35' incorporates:
   *  Constant: '<S658>/LL_LFClb_TFC_KpV2_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion17_b != 0.0F) {
    rtb_LL_LFClb_TFC_KpV2_C = LKAS_ConstB.DataTypeConversion17_b;
  } else {
    rtb_LL_LFClb_TFC_KpV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S658>/Switch35' */

  /* Switch: '<S658>/Switch20' incorporates:
   *  Constant: '<S658>/LL_LFClb_TFC_KdVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LL_LFClb_TFC_KdVehSpdLwr_C;
  }

  /* End of Switch: '<S658>/Switch20' */

  /* Switch: '<S658>/Switch22' incorporates:
   *  Constant: '<S658>/LL_LFClb_TFC_KdVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LL_LFClb_TFC_KdVehSpdUpr_C;
  }

  /* End of Switch: '<S658>/Switch22' */

  /* Switch: '<S658>/Switch21' incorporates:
   *  Constant: '<S658>/LL_LFClb_TFC_KdV1_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV1_C = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LFClb_TFC_KdV1_C = LL_LFClb_TFC_KdV1_C;
  }

  /* End of Switch: '<S658>/Switch21' */

  /* Switch: '<S658>/Switch23' incorporates:
   *  Constant: '<S658>/LL_LFClb_TFC_KdV2_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV2_C = LKAS_ConstB.DataTypeConversion30;
  } else {
    rtb_LL_LFClb_TFC_KdV2_C = LL_LFClb_TFC_KdV2_C;
  }

  /* End of Switch: '<S658>/Switch23' */

  /* Switch: '<S658>/Switch9' incorporates:
   *  Constant: '<S658>/LL_LFClb_TFC_KdBalance_C=1.2'
   */
  if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
    rtb_R0_C3 = LKAS_ConstB.DataTypeConversion9;
  } else {
    rtb_R0_C3 = LL_LFClb_TFC_KdBalance_C;
  }

  /* End of Switch: '<S658>/Switch9' */

  /* Switch: '<S658>/Switch11' incorporates:
   *  Constant: '<S658>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_d != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12_d;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S658>/Switch11' */

  /* Switch: '<S658>/Switch13' incorporates:
   *  Constant: '<S658>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_o != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_o;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S658>/Switch13' */

  /* Switch: '<S658>/Switch55' incorporates:
   *  Constant: '<S658>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S658>/Switch55' */

  /* Switch: '<S658>/Switch54' incorporates:
   *  Constant: '<S658>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S658>/Switch54' */

  /* Switch: '<S658>/Switch44' incorporates:
   *  Constant: '<S658>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S658>/Switch44' */

  /* Switch: '<S658>/Switch25' incorporates:
   *  Constant: '<S658>/LL_LKAExPrcs_tiExitDelayTime3=0.5'
   */
  if (LKAS_ConstB.DataTypeConversion39 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LKAS_ConstB.DataTypeConversion39;
  } else {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LL_LKAExPrcs_tiExitDelayTime3;
  }

  /* End of Switch: '<S658>/Switch25' */

  /* Switch: '<S656>/Switch19' incorporates:
   *  Constant: '<S656>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_c != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_c;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S656>/Switch19' */

  /* Switch: '<S656>/Switch' incorporates:
   *  Constant: '<S656>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_h != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_h;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S656>/Switch' */

  /* Switch: '<S656>/Switch1' incorporates:
   *  Constant: '<S656>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_n != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_n;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S656>/Switch1' */

  /* Switch: '<S656>/Switch2' incorporates:
   *  Constant: '<S656>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_f != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_a = LKAS_ConstB.DataTypeConversion4_f;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_a = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S656>/Switch2' */

  /* Switch: '<S656>/Switch3' incorporates:
   *  Constant: '<S656>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_g != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_l = LKAS_ConstB.DataTypeConversion6_g;
  } else {
    LKAS_DW.LKA_StrRatio_C_l = LKA_StrRatio_C;
  }

  /* End of Switch: '<S656>/Switch3' */

  /* Switch: '<S656>/Switch11' incorporates:
   *  Constant: '<S656>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S656>/Switch11' */

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (rtb_LKA_Main_Switch) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S142>/Delay' */
      LKAS_DW.Delay_DSTATE_e = ((uint8)0U);

      /* InitializeConditions for Memory: '<S583>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = 0.0F;

      /* InitializeConditions for Delay: '<S143>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S526>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = 0.0F;

      /* InitializeConditions for Memory: '<S445>/Memory' */
      LKAS_DW.Memory_PreviousInput_j = 0.0F;

      /* InitializeConditions for UnitDelay: '<S458>/Delay Input1'
       *
       * Block description for '<S458>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S457>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_in = false;

      /* InitializeConditions for UnitDelay: '<S419>/Delay Input1'
       *
       * Block description for '<S419>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_f = false;

      /* InitializeConditions for UnitDelay: '<S417>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_b = false;

      /* InitializeConditions for UnitDelay: '<S418>/Delay Input1'
       *
       * Block description for '<S418>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_m = false;

      /* InitializeConditions for Memory: '<S384>/Memory' */
      LKAS_DW.Memory_PreviousInput_gv = false;

      /* InitializeConditions for Delay: '<S143>/Delay' */
      LKAS_DW.Delay_DSTATE_k = false;

      /* InitializeConditions for Delay: '<S143>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S432>/Memory' */
      LKAS_DW.Memory_PreviousInput_cp = ((uint8)0U);

      /* InitializeConditions for Memory: '<S358>/Memory' */
      LKAS_DW.Memory_PreviousInput_l = 0.0F;

      /* InitializeConditions for Memory: '<S394>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = 0.0F;

      /* InitializeConditions for Memory: '<S595>/Memory' */
      LKAS_DW.Memory_PreviousInput_e = 0.0F;

      /* InitializeConditions for Delay: '<S596>/Delay' */
      LKAS_DW.Delay_DSTATE_b = ((uint8)0U);

      /* InitializeConditions for Delay: '<S597>/Delay' */
      LKAS_DW.Delay_DSTATE_m = ((uint8)0U);

      /* InitializeConditions for Delay: '<S598>/Delay' */
      LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

      /* InitializeConditions for Delay: '<S143>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S143>/LDW_State_Machine'
       *
       * Block description for '<S143>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S143>/LKA_State_Machine'
       *
       * Block description for '<S143>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S297>/Add1' incorporates:
     *  MATLAB Function: '<S295>/MATLABFunction3'
     */
    x20 = rtb_L0_C0_h + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S297>/Gain1' incorporates:
     *  Product: '<S297>/Divide'
     *  Product: '<S297>/Divide1'
     *  Sum: '<S297>/Add1'
     *  Sum: '<S297>/Add5'
     *  Trigonometry: '<S297>/Cos2'
     *  Trigonometry: '<S297>/Sin'
     */
    rtb_Gain1 = ((x20 * cosf(rtb_L0_C1_j)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_j))) * (-1.0F);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S289>/Gain1' incorporates:
     *  Gain: '<S185>/Gain'
     *  Gain: '<S231>/kph To mps'
     *  Gain: '<S245>/kph to mps'
     *  Gain: '<S246>/kph to mps'
     *  Gain: '<S295>/Gain2'
     *  Gain: '<S302>/kph to mps'
     *  Gain: '<S308>/kph to mps'
     *  Gain: '<S317>/kph to mps'
     *  Gain: '<S318>/kph to mps'
     */
    rtb_Abs_p_tmp = 0.277777791F * rtb_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S289>/Divide4' incorporates:
     *  Constant: '<S289>/Constant2'
     *  Constant: '<S289>/Constant3'
     *  Gain: '<S289>/Gain1'
     */
    rtb_Abs_g = (rtb_Abs_p_tmp * 2.0F) * 0.1F;

    /* Sum: '<S289>/Add3' incorporates:
     *  Product: '<S289>/Divide3'
     */
    rtb_phiHdAg_Lft = (rtb_L0_C2_g * rtb_Abs_g) + rtb_L0_C1_j;

    /* Sum: '<S298>/Add1' incorporates:
     *  MATLAB Function: '<S295>/MATLABFunction4'
     */
    rtb_Add5_i_tmp = rtb_R0_C0_f - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S298>/Add5' incorporates:
     *  Product: '<S298>/Divide'
     *  Product: '<S298>/Divide1'
     *  Sum: '<S298>/Add1'
     *  Trigonometry: '<S298>/Cos2'
     *  Trigonometry: '<S298>/Sin'
     */
    rtb_Add5_i = (rtb_Add5_i_tmp * cosf(rtb_L0_C1_d)) + (rtb_LKA_Veh2CamL_C *
      sinf(rtb_L0_C1_d));

    /* Sum: '<S289>/Add1' incorporates:
     *  Product: '<S289>/Divide5'
     */
    rtb_phiHdAg_Rgt = (rtb_R0_C2_e * rtb_Abs_g) + rtb_L0_C1_d;

    /* Switch: '<S658>/Switch2' incorporates:
     *  Constant: '<S658>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_e != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_e;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S658>/Switch2' */

    /* Product: '<S302>/Divide' */
    rtb_Abs_g = rtb_Abs_p_tmp * x10;

    /* Gain: '<S299>/Gain' incorporates:
     *  Gain: '<S314>/Gain'
     *  Gain: '<S315>/Gain'
     *  Gain: '<S316>/Gain'
     */
    rtb_Add_o_tmp = 2.0F * rtb_L0_C2_g;

    /* Sum: '<S299>/Add' incorporates:
     *  Gain: '<S299>/Gain'
     *  Gain: '<S299>/Gain1'
     *  Product: '<S299>/Product'
     */
    rtb_Add_o = ((6.0F * rtb_LL_CompHdAg_C) * rtb_Abs_g) + rtb_Add_o_tmp;

    /* Gain: '<S300>/Gain' incorporates:
     *  Gain: '<S311>/Gain'
     *  Gain: '<S312>/Gain'
     *  Gain: '<S313>/Gain'
     */
    rtb_Add_a_tmp = 2.0F * rtb_R0_C2_e;

    /* Sum: '<S300>/Add' incorporates:
     *  Gain: '<S300>/Gain'
     *  Gain: '<S300>/Gain1'
     *  Product: '<S300>/Product'
     */
    rtb_Add_a = ((6.0F * rtb_L0_C3) * rtb_Abs_g) + rtb_Add_a_tmp;

    /* Product: '<S289>/Divide1' incorporates:
     *  Gain: '<S289>/Gain1'
     */
    rtb_Abs_g = rtb_phiHdAg_Lft * rtb_Abs_p_tmp;

    /* Saturate: '<S295>/Saturation2' incorporates:
     *  UnaryMinus: '<S295>/Unary Minus1'
     */
    if ((-rtb_Abs_g) > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else if ((-rtb_Abs_g) < (-2.0F)) {
      rtb_LKA_Veh2CamL_C = (-2.0F);
    } else {
      rtb_LKA_Veh2CamL_C = -rtb_Abs_g;
    }

    /* End of Saturate: '<S295>/Saturation2' */

    /* MATLAB Function: '<S295>/MATLABFunction' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction': '<S326>:1' */
    /* '<S326>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1 > 0.0F) && (rtb_Gain1 < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S326>:1:3' TTLC = -dvt/vy; */
      rtb_TTLC_f = (-rtb_Gain1) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S326>:1:4' else */
      /* '<S326>:1:5' TTLC = single(3); */
      rtb_TTLC_f = 3.0F;
    }

    /* End of MATLAB Function: '<S295>/MATLABFunction' */

    /* Saturate: '<S295>/Saturation' */
    if (rtb_TTLC_f > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_TTLC_f < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_TTLC_f;
    }

    /* End of Saturate: '<S295>/Saturation' */

    /* Product: '<S289>/Divide2' incorporates:
     *  Gain: '<S289>/Gain1'
     */
    rtb_Abs_n4 = rtb_phiHdAg_Rgt * rtb_Abs_p_tmp;

    /* Saturate: '<S295>/Saturation3' */
    if (rtb_Abs_n4 > 2.0F) {
      rtb_TTLC_f = 2.0F;
    } else if (rtb_Abs_n4 < (-2.0F)) {
      rtb_TTLC_f = (-2.0F);
    } else {
      rtb_TTLC_f = rtb_Abs_n4;
    }

    /* End of Saturate: '<S295>/Saturation3' */

    /* MATLAB Function: '<S295>/MATLABFunction1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction1': '<S327>:1' */
    /* '<S327>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_i > 0.0F) && (rtb_Add5_i < 2.0F)) && (rtb_TTLC_f < 0.0F)) &&
        (rtb_TTLC_f > -1.5F)) {
      /* '<S327>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_l = (-rtb_Add5_i) / rtb_TTLC_f;
    } else {
      /* '<S327>:1:4' else */
      /* '<S327>:1:5' TTLC = single(3); */
      rtb_TTLC_l = 3.0F;
    }

    /* End of MATLAB Function: '<S295>/MATLABFunction1' */

    /* Saturate: '<S295>/Saturation1' */
    if (rtb_TTLC_l > 2.0F) {
      rtb_TTLC_l = 2.0F;
    } else {
      if (rtb_TTLC_l < 0.6F) {
        rtb_TTLC_l = 0.6F;
      }
    }

    /* End of Saturate: '<S295>/Saturation1' */

    /* MATLAB Function: '<S295>/MATLABFunction5' incorporates:
     *  Gain: '<S325>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction5': '<S331>:1' */
    /* '<S331>:1:2' K = single(single(0.09)/single(vx)); */
    /* '<S331>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_L0_C0_d2) / (((((((0.09F / rtb_Abs_p_tmp) *
      rtb_Abs_p_tmp) * rtb_Abs_p_tmp) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_a) *
      LKAS_DW.LKA_StrRatio_C_l) * 2.0F);

    /* MATLAB Function: '<S295>/MATLABFunction3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction3': '<S329>:1' */
    /* '<S329>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2_g - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_j > 0.0F) || (rtb_L0_C1_j < 0.0F))) {
      /* '<S329>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_h) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_j;
      if (x10 > 0.0F) {
        /* '<S329>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_Abs_p_tmp;
      } else {
        /* '<S329>:1:9' else */
        /* '<S329>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_j * rtb_L0_C1_j) - ((x10 * 4.0F) * x20);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S329>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S329>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_j)) / x1;

        /* '<S329>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_j) - x20) / x1;

        /* '<S329>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S329>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S329>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S329>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_Abs_p_tmp;
        } else if (x1 > 0.0F) {
          /* '<S329>:1:19' elseif x1>0 */
          /* '<S329>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_Abs_p_tmp;
        } else {
          /* '<S329>:1:21' else */
          /* '<S329>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S329>:1:24' else */
        /* '<S329>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S329>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S295>/MATLABFunction4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction4': '<S330>:1' */
    /* '<S330>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_R0_C2_e - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_d > 0.0F) || (rtb_L0_C1_d < 0.0F))) {
      /* '<S330>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_R0_C0_f) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1_d;
      if (x10 > 0.0F) {
        /* '<S330>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_p_tmp;
      } else {
        /* '<S330>:1:9' else */
        /* '<S330>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_d * rtb_L0_C1_d) - ((x10 * 4.0F) * rtb_Add5_i_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S330>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S330>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_d)) / x1;

        /* '<S330>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_d) - x20) / x1;

        /* '<S330>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S330>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S330>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S330>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_p_tmp;
        } else if (x1 > 0.0F) {
          /* '<S330>:1:19' elseif x1>0 */
          /* '<S330>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_Abs_p_tmp;
        } else {
          /* '<S330>:1:21' else */
          /* '<S330>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S330>:1:24' else */
        /* '<S330>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S330>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S295>/MATLABFunction2' incorporates:
     *  Constant: '<S295>/Constant'
     *  Constant: '<S295>/Constant1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction2': '<S328>:1' */
    /* '<S328>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - 2.0F) / rtb_LftTTLC) <= 0.2F) {
      /* '<S328>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, 2.0F);
    } else {
      /* '<S328>:1:4' else */
      /* '<S328>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S328>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_l - 2.0F) / rtb_TTLC_l) <= 0.2F) {
      /* '<S328>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_l = fminf(rtb_TTLC_l, 2.0F);
    } else {
      /* '<S328>:1:10' else */
      /* '<S328>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S328>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_o) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S328>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S328>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_a) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_l)
           / rtb_TTLC_l) <= 0.7F)) && (rtb_TTLC_l <= 1.95F)) {
      /* '<S328>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_l = (rtb_TTLC_l + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S295>/Saturation7' incorporates:
     *  MATLAB Function: '<S295>/MATLABFunction2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S295>/Saturation7' */

    /* Saturate: '<S295>/Saturation8' incorporates:
     *  MATLAB Function: '<S295>/MATLABFunction2'
     */
    if (rtb_TTLC_l > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_l < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_l;
    }

    /* End of Saturate: '<S295>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S150>/Subsystem' incorporates:
     *  EnablePort: '<S159>/Enable'
     */
    /* Abs: '<S290>/Abs' incorporates:
     *  MATLAB Function: '<S159>/DriverSwaTrqAdd'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_L0_C0_h);

    /* Abs: '<S290>/Abs1' incorporates:
     *  MATLAB Function: '<S159>/DriverSwaTrqAdd'
     */
    rtb_Add5_i_tmp = fabsf(rtb_R0_C0_f);

    /* End of Outputs for SubSystem: '<S150>/Subsystem' */
    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Sum: '<S290>/Add' incorporates:
     *  Abs: '<S290>/Abs'
     *  Abs: '<S290>/Abs1'
     */
    rtb_LftTTLC = rtb_LKA_Veh2CamW_C + rtb_Add5_i_tmp;

    /* Saturate: '<S290>/Saturation' */
    if (rtb_LftTTLC > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_LftTTLC < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_LftTTLC;
    }

    /* End of Saturate: '<S290>/Saturation' */

    /* If: '<S301>/If' incorporates:
     *  Delay: '<S142>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE_e) == 1) {
      /* Outputs for IfAction SubSystem: '<S301>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S304>/Action Port'
       */
      LKAS_IfActionSubsystem2_e(rtb_Add_o, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S301>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE_e) == 2) {
      /* Outputs for IfAction SubSystem: '<S301>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S303>/Action Port'
       */
      LKAS_IfActionSubsystem2_e(rtb_Add_a, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S301>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S301>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S305>/Action Port'
       */
      /* Gain: '<S305>/Gain' incorporates:
       *  Sum: '<S305>/Add'
       */
      rtb_Merge = (rtb_Add_o + rtb_Add_a) * 0.5F;

      /* End of Outputs for SubSystem: '<S301>/If Action Subsystem3' */
    }

    /* End of If: '<S301>/If' */

    /* Switch: '<S585>/Switch' incorporates:
     *  Constant: '<S662>/Constant'
     *  Constant: '<S663>/Constant'
     *  Gain: '<S662>/Gain'
     *  Gain: '<S663>/Gain'
     *  Sum: '<S662>/Add'
     *  Sum: '<S663>/Add'
     *  Switch: '<S659>/Switch47'
     */
    if (LKAS_DW.LKA_Mode_g >= ((uint8)2U)) {
      /* Switch: '<S659>/Switch48' incorporates:
       *  Constant: '<S659>/LLSMConClb3'
       *
       * Block description for '<S659>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S659>/Switch48' */
      rtb_Switch_n = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S659>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S659>/Switch47' incorporates:
         *  Constant: '<S659>/LLSMConClb2'
         *
         * Block description for '<S659>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_n = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S585>/Switch' */

    /* Switch: '<S583>/Switch' incorporates:
     *  Constant: '<S583>/Constant'
     *  Constant: '<S583>/Constant1'
     *  Constant: '<S588>/Constant'
     *  Constant: '<S589>/Constant'
     *  Constant: '<S590>/Constant'
     *  Logic: '<S583>/Logical Operator'
     *  RelationalOperator: '<S588>/Compare'
     *  RelationalOperator: '<S589>/Compare'
     *  RelationalOperator: '<S590>/Compare'
     */
    if (((rtb_IMAPve_d_BCM_HazardLamp >= ((uint8)3U)) || (((sint32)
           (rtb_BCM_Left_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) ||
        (((sint32)(rtb_BCM_Right_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S583>/Switch' */

    /* Sum: '<S583>/Add' incorporates:
     *  Memory: '<S583>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_i;

    /* Saturate: '<S583>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_c = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_c = (-1.0F);
    } else {
      rtb_Saturation_c = rtb_LftTTLC;
    }

    /* End of Saturate: '<S583>/Saturation' */

    /* Abs: '<S577>/Abs1' incorporates:
     *  Abs: '<S482>/Abs1'
     */
    rtb_TLft = fabsf(rtb_LaneWidth);
    rtb_Abs1 = rtb_TLft;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S575>/Abs' incorporates:
     *  Abs: '<S170>/Abs'
     *  Abs: '<S171>/Abs'
     *  Abs: '<S172>/Abs4'
     *  Abs: '<S480>/Abs'
     *  MATLAB Function: '<S446>/MATLAB Function'
     */
    rtb_TTLC_l = fabsf(rtb_Merge);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC_l;

    /* Switch: '<S659>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S536>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S536>/Unary Minus' incorporates:
       *  Constant: '<S659>/LLSMConClb11'
       *
       * Block description for '<S659>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S659>/Switch53' */

    /* Switch: '<S659>/Switch87' incorporates:
     *  Constant: '<S659>/LLSMConClb8'
     *
     * Block description for '<S659>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S659>/Switch87' */

    /* Switch: '<S659>/Switch49' incorporates:
     *  Constant: '<S659>/LLSMConClb43'
     *
     * Block description for '<S659>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S659>/Switch49' */

    /* Switch: '<S659>/Switch88' incorporates:
     *  Constant: '<S659>/LLSMConClb9'
     *
     * Block description for '<S659>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_LftTTLC = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S659>/Switch88' */

    /* Switch: '<S659>/Switch50' incorporates:
     *  Constant: '<S659>/LLSMConClb10'
     *
     * Block description for '<S659>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      tmp = LKAS_ConstB.DataTypeConversion17;
    } else {
      tmp = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S659>/Switch50' */

    /* Abs: '<S573>/Abs' incorporates:
     *  Abs: '<S478>/Abs'
     *  Sum: '<S573>/Add'
     */
    x1 = fabsf(rtb_L0_C1_j - rtb_L0_C1_d);

    /* Abs: '<S536>/Abs2' incorporates:
     *  Abs: '<S320>/Abs2'
     *  Abs: '<S444>/Abs2'
     */
    rtb_TTLC = fabsf(rtb_L0_C0_d2);

    /* Abs: '<S536>/Abs3' incorporates:
     *  Abs: '<S444>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     */
    rtb_ThresDet_coefficient_c = fabsf(rtb_ThresDet_coefficient_c);

    /* Abs: '<S536>/Abs4' incorporates:
     *  Abs: '<S444>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     */
    rtb_LogicalOperator3_j_tmp = fabsf(rtb_Saturation_a1);

    /* Abs: '<S536>/Abs1' incorporates:
     *  Abs: '<S445>/Abs'
     *  Abs: '<S446>/Abs'
     */
    rtb_Saturation_a1 = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S537>/Logical Operator2' incorporates:
     *  Abs: '<S536>/Abs1'
     *  Abs: '<S536>/Abs2'
     *  Abs: '<S536>/Abs3'
     *  Abs: '<S536>/Abs4'
     *  Abs: '<S573>/Abs'
     *  Constant: '<S575>/Constant'
     *  Constant: '<S578>/Constant'
     *  Constant: '<S580>/Constant'
     *  Constant: '<S581>/Constant'
     *  Constant: '<S587>/Constant'
     *  Constant: '<S591>/Constant'
     *  Logic: '<S536>/Logical Operator3'
     *  Logic: '<S542>/FixPt Logical Operator'
     *  Logic: '<S574>/Logical Operator3'
     *  Logic: '<S576>/Logical Operator'
     *  Logic: '<S579>/FixPt Logical Operator'
     *  Logic: '<S582>/FixPt Logical Operator'
     *  Logic: '<S586>/Logical Operator'
     *  Logic: '<S592>/FixPt Logical Operator'
     *  RelationalOperator: '<S536>/Relational Operator'
     *  RelationalOperator: '<S536>/Relational Operator1'
     *  RelationalOperator: '<S536>/Relational Operator2'
     *  RelationalOperator: '<S536>/Relational Operator3'
     *  RelationalOperator: '<S542>/Lower Test'
     *  RelationalOperator: '<S542>/Upper Test'
     *  RelationalOperator: '<S578>/Compare'
     *  RelationalOperator: '<S579>/Lower Test'
     *  RelationalOperator: '<S579>/Upper Test'
     *  RelationalOperator: '<S580>/Compare'
     *  RelationalOperator: '<S581>/Compare'
     *  RelationalOperator: '<S582>/Lower Test'
     *  RelationalOperator: '<S582>/Upper Test'
     *  RelationalOperator: '<S587>/Compare'
     *  RelationalOperator: '<S591>/Compare'
     *  RelationalOperator: '<S592>/Lower Test'
     *  RelationalOperator: '<S592>/Upper Test'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_LogicalOperator3_pm = ((((((rtb_Gain_a <= rtb_ESC_VehSpd) &&
      (rtb_ESC_VehSpd <= rtb_Switch_n)) && (rtb_Saturation_c <= 0.0F)) &&
      (rtb_EPS_LKA_Control == ((UInt8)((uint8)3U)))) &&
      (((((rtb_FDMMve_d_LkaFcnConf > ((uint8)2U)) && (rtb_IMAPve_d_LKA_Mode >
      ((uint8)2U))) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) && (rtb_Abs1 <=
      rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) && (rtb_Abs <=
      rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) && (x1 <= 0.025F))) && (((((rtb_TTLC <
      x10) && (rtb_ThresDet_coefficient_c < x20)) && (rtb_Saturation_a1 <
      rtb_LftTTLC)) && (rtb_LogicalOperator3_j_tmp < tmp)) && ((rtb_UnaryMinus <
      rtb_IMAPve_g_ESC_LonAcc) && (rtb_IMAPve_g_ESC_LonAcc <
      rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* MATLAB Function: '<S570>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_LKA_EarliestWarnLine_C, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient);

    /* Product: '<S570>/Multiply' */
    rtb_Multiply = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_ThresDet_coefficient;

    /* Switch: '<S572>/Switch' incorporates:
     *  Constant: '<S570>/Constant'
     *  RelationalOperator: '<S572>/UpperRelop'
     */
    if (rtb_Multiply < 0.0F) {
      rtb_Switch_d = 0.0F;
    } else {
      rtb_Switch_d = rtb_Multiply;
    }

    /* End of Switch: '<S572>/Switch' */

    /* Switch: '<S572>/Switch2' incorporates:
     *  RelationalOperator: '<S572>/LowerRelop1'
     */
    if (rtb_Multiply > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_k = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_k = rtb_Switch_d;
    }

    /* End of Switch: '<S572>/Switch2' */

    /* Abs: '<S557>/Abs1' incorporates:
     *  Abs: '<S468>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S557>/Abs2' incorporates:
     *  Abs: '<S468>/Abs1'
     */
    x20 = fabsf(rtb_TTLC_f);

    /* If: '<S537>/If1' incorporates:
     *  Abs: '<S557>/Abs1'
     *  Abs: '<S557>/Abs2'
     *  Constant: '<S544>/Constant'
     *  Constant: '<S559>/Constant'
     *  Constant: '<S560>/Constant'
     *  Constant: '<S565>/Constant'
     *  Constant: '<S566>/Constant'
     *  Constant: '<S567>/Constant'
     *  Constant: '<S568>/Constant'
     *  Logic: '<S537>/Logical Operator1'
     *  Logic: '<S554>/Logical Operator'
     *  Logic: '<S556>/Logical Operator'
     *  Logic: '<S557>/Logical Operator'
     *  Logic: '<S558>/Logical Operator'
     *  RelationalOperator: '<S557>/Relational Operator2'
     *  RelationalOperator: '<S557>/Relational Operator3'
     *  RelationalOperator: '<S558>/Relational Operator1'
     *  RelationalOperator: '<S558>/Relational Operator2'
     *  RelationalOperator: '<S559>/Compare'
     *  RelationalOperator: '<S560>/Compare'
     *  RelationalOperator: '<S565>/Compare'
     *  RelationalOperator: '<S566>/Compare'
     *  RelationalOperator: '<S567>/Compare'
     *  RelationalOperator: '<S568>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode_g) == 2) && (rtb_LogicalOperator3_pm &&
         ((((LKAS_DW.LKA_Mode_g == ((uint8)2U)) && (((sint32)
              (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
                (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) ? 1 : 0)) ==
             ((sint32)(true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1 >= rtb_Switch2_k) &&
              (rtb_Add5_i >= rtb_Switch2_k)) ? 1 : 0)) == ((sint32)(true ? 1 : 0))))))
    {
      /* Outputs for IfAction SubSystem: '<S537>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S544>/Action Port'
       */
      LKAS_DW.Merge1_c = true;

      /* End of Outputs for SubSystem: '<S537>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S537>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S546>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_c);

      /* End of Outputs for SubSystem: '<S537>/If Action Subsystem4' */
    }

    /* End of If: '<S537>/If1' */

    /* Switch: '<S528>/Switch' incorporates:
     *  Constant: '<S660>/Constant'
     *  Constant: '<S665>/Constant'
     *  Gain: '<S660>/Gain'
     *  Gain: '<S665>/Gain'
     *  Sum: '<S660>/Add'
     *  Sum: '<S665>/Add'
     *  Switch: '<S659>/Switch67'
     */
    if (LKAS_DW.LKA_Mode_g >= ((uint8)2U)) {
      /* Switch: '<S659>/Switch80' incorporates:
       *  Constant: '<S659>/LLSMConClb21'
       *
       * Block description for '<S659>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_LftTTLC = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S659>/Switch80' */
      rtb_Switch_h = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S659>/Switch67' */
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S659>/Switch67' incorporates:
         *  Constant: '<S659>/LLSMConClb20'
         *
         * Block description for '<S659>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_LftTTLC = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_h = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S528>/Switch' */

    /* Logic: '<S528>/Logical Operator' incorporates:
     *  Logic: '<S535>/FixPt Logical Operator'
     *  RelationalOperator: '<S535>/Lower Test'
     *  RelationalOperator: '<S535>/Upper Test'
     */
    rtb_LogicalOperator_g = ((rtb_Gain_n >= rtb_ESC_VehSpd) || (rtb_ESC_VehSpd >=
      rtb_Switch_h));

    /* Logic: '<S526>/Logical Operator' incorporates:
     *  Logic: '<S347>/Logical Operator6'
     */
    rtb_RelationalOperator_l_tmp = !rtb_LL_SingleLane_Disable_Swt;

    /* Switch: '<S526>/Switch' incorporates:
     *  Constant: '<S526>/Constant'
     *  Constant: '<S526>/Constant1'
     *  Constant: '<S531>/Constant'
     *  Constant: '<S532>/Constant'
     *  Constant: '<S533>/Constant'
     *  Delay: '<S143>/Delay1'
     *  Logic: '<S526>/Logical Operator'
     *  Logic: '<S526>/Logical Operator1'
     *  Logic: '<S526>/Logical Operator2'
     *  Logic: '<S526>/Logical Operator3'
     *  Logic: '<S526>/Logical Operator4'
     *  Logic: '<S526>/Logical Operator5'
     *  RelationalOperator: '<S531>/Compare'
     *  RelationalOperator: '<S532>/Compare'
     *  RelationalOperator: '<S533>/Compare'
     */
    if (((((rtb_IMAPve_d_BCM_HazardLamp >= ((uint8)3U)) || (rtb_BCM_Left_Light &&
            rtb_RelationalOperator_l_tmp)) || (rtb_BCM_Right_Light &&
           rtb_RelationalOperator_l_tmp)) || (rtb_BCM_Left_Light &&
          (LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)))) || (rtb_BCM_Right_Light &&
         (LKAS_DW.Delay1_3_DSTATE == ((uint8)5U)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S526>/Switch' */

    /* Sum: '<S526>/Add' incorporates:
     *  Memory: '<S526>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_p;

    /* Saturate: '<S526>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_co = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_co = (-1.0F);
    } else {
      rtb_Saturation_co = rtb_LftTTLC;
    }

    /* End of Saturate: '<S526>/Saturation' */

    /* RelationalOperator: '<S530>/Compare' incorporates:
     *  Constant: '<S530>/Constant'
     */
    rtb_LL_SingleLane_Disable_Swt = (rtb_Saturation_co > 1.0F);

    /* RelationalOperator: '<S534>/Compare' incorporates:
     *  Constant: '<S534>/Constant'
     */
    rtb_Compare_gu = (rtb_EPS_LKA_Control != ((UInt8)((uint8)3U)));

    /* Logic: '<S481>/Logical Operator' incorporates:
     *  Constant: '<S485>/Constant'
     *  Constant: '<S486>/Constant'
     *  RelationalOperator: '<S485>/Compare'
     *  RelationalOperator: '<S486>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_LogicalOperator_jbm = ((rtb_FDMMve_d_LkaFcnConf < ((uint8)3U)) &&
      (rtb_IMAPve_d_LKA_Mode < ((uint8)3U)));

    /* Abs: '<S482>/Abs1' */
    rtb_Abs1_n = rtb_TLft;

    /* RelationalOperator: '<S487>/Compare' incorporates:
     *  Constant: '<S487>/Constant'
     *  Logic: '<S488>/FixPt Logical Operator'
     *  RelationalOperator: '<S488>/Lower Test'
     *  RelationalOperator: '<S488>/Upper Test'
     */
    rtb_Compare_ih = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_n) &&
      (rtb_Abs1_n <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S480>/Abs' */
    rtb_Abs_j = rtb_TTLC_l;

    /* Logic: '<S480>/Logical Operator' incorporates:
     *  Constant: '<S480>/Constant'
     *  Logic: '<S484>/FixPt Logical Operator'
     *  RelationalOperator: '<S484>/Lower Test'
     *  RelationalOperator: '<S484>/Upper Test'
     */
    rtb_LogicalOperator_ki = ((0.0F > rtb_Abs_j) || (rtb_Abs_j >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S483>/Compare' incorporates:
     *  Constant: '<S483>/Constant'
     */
    rtb_Compare_nm = (x1 > 0.04F);

    /* Switch: '<S659>/Switch72' incorporates:
     *  Constant: '<S659>/LLSMConClb26'
     *
     * Block description for '<S659>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S659>/Switch72' */

    /* RelationalOperator: '<S444>/Relational Operator1' */
    rtb_phiSWA_Thres = (rtb_TTLC >= rtb_LftTTLC);

    /* Switch: '<S659>/Switch74' incorporates:
     *  Constant: '<S659>/LLSMConClb28'
     *
     * Block description for '<S659>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S659>/Switch74' */

    /* RelationalOperator: '<S444>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_ThresDet_coefficient_c >= rtb_LftTTLC);

    /* Switch: '<S659>/Switch79' incorporates:
     *  Constant: '<S659>/LLSMConClb29'
     *
     * Block description for '<S659>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_LftTTLC = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S659>/Switch79' */

    /* Logic: '<S444>/Logical Operator1' incorporates:
     *  Constant: '<S447>/Constant'
     *  RelationalOperator: '<S444>/Relational Operator3'
     *  RelationalOperator: '<S447>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_j_tmp >= rtb_LftTTLC) &&
                       (rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)));

    /* Switch: '<S659>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S444>/Unary Minus' */
      rtb_UnaryMinus_f = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S444>/Unary Minus' incorporates:
       *  Constant: '<S659>/LLSMConClb30'
       *
       * Block description for '<S659>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_f = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S659>/Switch61' */

    /* RelationalOperator: '<S448>/Compare' incorporates:
     *  Constant: '<S448>/Constant'
     *  Logic: '<S449>/FixPt Logical Operator'
     *  RelationalOperator: '<S449>/Lower Test'
     *  RelationalOperator: '<S449>/Upper Test'
     */
    rtb_Compare_n5 = (((sint32)(((rtb_UnaryMinus_f < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                      ((sint32)(false ? 1 : 0)));

    /* Logic: '<S445>/Logical Operator3' incorporates:
     *  Abs: '<S445>/Abs1'
     *  Constant: '<S445>/Constant'
     *  Constant: '<S445>/Constant1'
     *  Memory: '<S445>/Memory'
     *  RelationalOperator: '<S445>/Relational Operator1'
     *  RelationalOperator: '<S445>/Relational Operator2'
     *  Sum: '<S445>/Add'
     */
    rtb_LogicalOperator3_ch = ((rtb_Saturation_a1 <= 0.8F) && (fabsf
      (LKAS_DW.Memory_PreviousInput_j - rtb_IMAPve_g_EPS_SW_Trq) <= 0.01F));

    /* Outputs for Enabled SubSystem: '<S445>/ExitCount1' */
    /* Constant: '<S445>/Constant2' */
    LKAS_ExitCount(rtb_LogicalOperator3_ch, rtb_LKA_SampleTime, 5.0F,
                   &LKAS_DW.RelationalOperator_l, &LKAS_DW.ExitCount1);

    /* End of Outputs for SubSystem: '<S445>/ExitCount1' */

    /* Switch: '<S445>/Switch' incorporates:
     *  Constant: '<S450>/Constant'
     *  RelationalOperator: '<S450>/Compare'
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      rtb_ThresDet_coefficient_c = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
    } else {
      rtb_ThresDet_coefficient_c = rtb_LL_RlsDet_tiTrqChkT_DISABLE;
    }

    /* End of Switch: '<S445>/Switch' */

    /* Logic: '<S445>/OR' incorporates:
     *  RelationalOperator: '<S445>/Relational Operator'
     */
    rtb_OR = ((rtb_Saturation_a1 <= rtb_ThresDet_coefficient_c) ||
              (LKAS_DW.RelationalOperator_l));

    /* Product: '<S445>/Divide' incorporates:
     *  Constant: '<S451>/Constant'
     *  Constant: '<S452>/Constant'
     *  Logic: '<S445>/Logical Operator1'
     *  Logic: '<S445>/Logical Operator2'
     *  RelationalOperator: '<S451>/Compare'
     *  RelationalOperator: '<S452>/Compare'
     */
    rtb_Divide_e = (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
                     (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) && rtb_OR) ?
      rtb_LKA_SampleTime : 0.0F;

    /* Outputs for Enabled SubSystem: '<S445>/ExitCount' */
    LKAS_ExitCount(rtb_OR, rtb_Divide_e, rtb_LL_HandsOff_ExitTime,
                   &LKAS_DW.RelationalOperator_n, &LKAS_DW.ExitCount);

    /* End of Outputs for SubSystem: '<S445>/ExitCount' */

    /* Saturate: '<S446>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S455>:1' */
    /* '<S455>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S455>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S455>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S455>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_ESC_VehSpd > 80.0F) {
      rtb_LftTTLC = 80.0F;
    } else if (rtb_ESC_VehSpd < 60.0F) {
      rtb_LftTTLC = 60.0F;
    } else {
      rtb_LftTTLC = rtb_ESC_VehSpd;
    }

    /* End of Saturate: '<S446>/Saturation' */

    /* MATLAB Function: '<S446>/MATLAB Function' */
    if (rtb_Saturation_a1 >= fminf(fmaxf(1.5F, ((1.5F *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL) - ((rtb_LftTTLC / 180.0F) *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL)) + (rtb_TTLC_l / 0.005F)), 2.75F))
    {
      /* Outputs for Enabled SubSystem: '<S446>/Sum Condition1' incorporates:
       *  EnablePort: '<S456>/state = reset'
       */
      /* '<S455>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_o) {
        /* InitializeConditions for Memory: '<S456>/Memory' */
        LKAS_DW.Memory_PreviousInput_m = 0.0F;
        LKAS_DW.SumCondition1_MODE_o = true;
      }

      /* Sum: '<S456>/Add1' incorporates:
       *  Memory: '<S456>/Memory'
       */
      rtb_Saturation_a1 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_m;

      /* Saturate: '<S456>/Saturation' */
      if (rtb_Saturation_a1 > 5000.0F) {
        rtb_Saturation_a1 = 5000.0F;
      } else {
        if (rtb_Saturation_a1 < 0.0F) {
          rtb_Saturation_a1 = 0.0F;
        }
      }

      /* End of Saturate: '<S456>/Saturation' */
      /* End of Outputs for SubSystem: '<S446>/Sum Condition1' */

      /* Switch: '<S659>/Switch65' incorporates:
       *  Constant: '<S659>/LLSMConClb34'
       *
       * Block description for '<S659>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_LftTTLC = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S659>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S446>/Sum Condition1' incorporates:
       *  EnablePort: '<S456>/state = reset'
       */
      /* RelationalOperator: '<S456>/Relational Operator' */
      LKAS_DW.RelationalOperator_e = (rtb_Saturation_a1 >= rtb_LftTTLC);

      /* Update for Memory: '<S456>/Memory' */
      LKAS_DW.Memory_PreviousInput_m = rtb_Saturation_a1;

      /* End of Outputs for SubSystem: '<S446>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S446>/Sum Condition1' incorporates:
       *  EnablePort: '<S456>/state = reset'
       */
      /* '<S455>:1:7' else */
      /* '<S455>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S456>/Out' */
        LKAS_DW.RelationalOperator_e = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }

      /* End of Outputs for SubSystem: '<S446>/Sum Condition1' */
    }

    /* RelationalOperator: '<S462>/Compare' incorporates:
     *  Constant: '<S462>/Constant'
     */
    rtb_Compare_f = (((sint32)(LKAS_DW.RelationalOperator_e ? 1 : 0)) > ((sint32)
      (false ? 1 : 0)));

    /* UnitDelay: '<S457>/Unit Delay' */
    rtb_UnitDelay_c = LKAS_DW.UnitDelay_DSTATE_in;

    /* If: '<S457>/If' incorporates:
     *  Constant: '<S459>/Constant'
     *  RelationalOperator: '<S458>/FixPt Relational Operator'
     *  UnitDelay: '<S458>/Delay Input1'
     *
     * Block description for '<S458>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if (((sint32)(rtb_Compare_f ? 1 : 0)) > ((sint32)(LKAS_DW.DelayInput1_DSTATE
          ? 1 : 0))) {
      /* Outputs for IfAction SubSystem: '<S457>/If Action Subsystem' incorporates:
       *  ActionPort: '<S459>/Action Port'
       */
      rtb_Merge_o = true;

      /* End of Outputs for SubSystem: '<S457>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S457>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S460>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_c, &rtb_Merge_o);

      /* End of Outputs for SubSystem: '<S457>/If Action Subsystem3' */
    }

    /* End of If: '<S457>/If' */

    /* Outputs for Enabled SubSystem: '<S457>/Sum Condition1' incorporates:
     *  EnablePort: '<S461>/state = reset'
     */
    if (rtb_Merge_o) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S461>/Memory' */
        LKAS_DW.Memory_PreviousInput_g1 = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S461>/Add1' incorporates:
       *  Memory: '<S461>/Memory'
       */
      rtb_Saturation_a1 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_g1;

      /* Saturate: '<S461>/Saturation' */
      if (rtb_Saturation_a1 > 10.0F) {
        rtb_Saturation_a1 = 10.0F;
      } else {
        if (rtb_Saturation_a1 < 0.0F) {
          rtb_Saturation_a1 = 0.0F;
        }
      }

      /* End of Saturate: '<S461>/Saturation' */

      /* RelationalOperator: '<S461>/Relational Operator' */
      LKAS_DW.RelationalOperator_j = (rtb_Saturation_a1 <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S461>/Memory' */
      LKAS_DW.Memory_PreviousInput_g1 = rtb_Saturation_a1;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S461>/Out' */
        LKAS_DW.RelationalOperator_j = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S457>/Sum Condition1' */

    /* Logic: '<S457>/Logical Operator' */
    rtb_stDvrTkConFlg_d = ((LKAS_DW.RelationalOperator_e) ||
      (LKAS_DW.RelationalOperator_j));

    /* Logic: '<S430>/Logical Operator2' incorporates:
     *  Logic: '<S443>/Logical Operator1'
     *  Logic: '<S444>/Logical Operator'
     *  Logic: '<S479>/Logical Operator3'
     *  Logic: '<S529>/Logical Operator3'
     */
    rtb_RelationalOperator_ct = ((((rtb_LogicalOperator_g ||
      rtb_LL_SingleLane_Disable_Swt) || rtb_Compare_gu) ||
      (((rtb_LogicalOperator_jbm || rtb_Compare_ih) || rtb_LogicalOperator_ki) ||
       rtb_Compare_nm)) || (((((rtb_phiSWA_Thres || rtb_dphiSWARate_Thres) ||
      rtb_aLAcc_Thres) || rtb_Compare_n5) || (LKAS_DW.RelationalOperator_n)) ||
      rtb_stDvrTkConFlg_d));

    /* Logic: '<S468>/Logical Operator' incorporates:
     *  RelationalOperator: '<S468>/Relational Operator1'
     *  RelationalOperator: '<S468>/Relational Operator2'
     */
    rtb_LogicalOperator_bp = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S469>/Logical Operator' incorporates:
     *  RelationalOperator: '<S469>/Relational Operator1'
     *  RelationalOperator: '<S469>/Relational Operator2'
     */
    rtb_LogicalOperator_mk = ((rtb_Gain1 <= rtb_R0_C1_a) || (rtb_Add5_i <=
      rtb_R0_C1_a));

    /* If: '<S430>/If2' incorporates:
     *  Constant: '<S439>/Constant'
     *  Constant: '<S474>/Constant'
     *  Constant: '<S475>/Constant'
     *  Constant: '<S477>/Constant'
     *  Logic: '<S430>/Logical Operator1'
     *  Logic: '<S467>/Logical Operator'
     *  Logic: '<S467>/Logical Operator1'
     *  RelationalOperator: '<S474>/Compare'
     *  RelationalOperator: '<S475>/Compare'
     *  RelationalOperator: '<S477>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode_g) == 2) && (rtb_RelationalOperator_ct ||
         ((LKAS_DW.LKA_Mode_g == ((uint8)2U)) && ((rtb_LogicalOperator_bp ==
            true) || (rtb_LogicalOperator_mk == true))))) {
      /* Outputs for IfAction SubSystem: '<S430>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S439>/Action Port'
       */
      LKAS_DW.Merge2 = true;

      /* End of Outputs for SubSystem: '<S430>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S430>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S441>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2);

      /* End of Outputs for SubSystem: '<S430>/If Action Subsystem3' */
    }

    /* End of If: '<S430>/If2' */

    /* If: '<S367>/If' */
    if ((rtb_Abs_g >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_n4 >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S367>/Ph1SWA' incorporates:
       *  ActionPort: '<S371>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S367>/Ph1SWA' */
    } else if ((rtb_Abs_g <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_n4 <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S367>/Ph2SWA' incorporates:
       *  ActionPort: '<S372>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S367>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S367>/Ph3SWA' incorporates:
       *  ActionPort: '<S373>/Action Port'
       */
      LKAS_Ph3SWA_m(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S367>/Ph3SWA' */
    }

    /* End of If: '<S367>/If' */

    /* Saturate: '<S345>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_Saturation_a1 = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_Saturation_a1 = (-2.0F);
    } else {
      rtb_Saturation_a1 = rtb_Gain1;
    }

    /* End of Saturate: '<S345>/Saturation5' */

    /* MATLAB Function: '<S354>/MATLAB Function' incorporates:
     *  MATLAB Function: '<S390>/MATLAB Function'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S357>:1' */
    /* '<S357>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S357>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S357>:1:5' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S357>:1:6' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S357>:1:7' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_ThresDet_coefficient_c = (2.0F * rtb_LL_ThresDet_lDvtThresUprLDW) +
      rtb_LKA_CarWidth;
    rtb_ThresDet_coefficient_c = fminf(fmaxf(0.0F, (fminf(fmaxf
      (rtb_ThresDet_coefficient_c, rtb_LaneWidth), (6.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth) -
      rtb_ThresDet_coefficient_c) / (4.0F * rtb_LL_ThresDet_lDvtThresUprLDW)),
      1.0F);

    /* Product: '<S354>/Divide5' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_LftTTLC = rtb_ThresDet_coefficient_c * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S354>/Divide6' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_TTLC_f = rtb_ThresDet_coefficient_c * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S369>/Abs' incorporates:
     *  Abs: '<S360>/Abs'
     *  Abs: '<S396>/Abs'
     */
    x20 = fabsf(rtb_Abs_g);

    /* Product: '<S369>/Divide' incorporates:
     *  Abs: '<S369>/Abs'
     */
    rtb_Divide_g = rtb_TTLC_f * x20;

    /* Product: '<S354>/Divide4' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S374>/Switch' incorporates:
     *  RelationalOperator: '<S374>/UpperRelop'
     */
    if (rtb_Divide_g < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_i = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_i = rtb_Divide_g;
    }

    /* End of Switch: '<S374>/Switch' */

    /* Switch: '<S374>/Switch2' incorporates:
     *  RelationalOperator: '<S374>/LowerRelop1'
     */
    if (rtb_Divide_g > rtb_LftTTLC) {
      rtb_Switch2_o = rtb_LftTTLC;
    } else {
      rtb_Switch2_o = rtb_Switch_i;
    }

    /* End of Switch: '<S374>/Switch2' */

    /* Saturate: '<S345>/Saturation1' */
    if (rtb_Add5_i > 2.0F) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 2.0F;
    } else if (rtb_Add5_i < (-2.0F)) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = (-2.0F);
    } else {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_Add5_i;
    }

    /* End of Saturate: '<S345>/Saturation1' */

    /* Abs: '<S370>/Abs' incorporates:
     *  Abs: '<S361>/Abs'
     *  Abs: '<S397>/Abs'
     */
    rtb_TLft = fabsf(rtb_Abs_n4);

    /* Product: '<S370>/Divide' incorporates:
     *  Abs: '<S370>/Abs'
     */
    rtb_Divide_h = rtb_TTLC_f * rtb_TLft;

    /* Switch: '<S375>/Switch' incorporates:
     *  RelationalOperator: '<S375>/UpperRelop'
     */
    if (rtb_Divide_h < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_ik = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_ik = rtb_Divide_h;
    }

    /* End of Switch: '<S375>/Switch' */

    /* Switch: '<S375>/Switch2' incorporates:
     *  RelationalOperator: '<S375>/LowerRelop1'
     */
    if (rtb_Divide_h > rtb_LftTTLC) {
      rtb_Switch2_g = rtb_LftTTLC;
    } else {
      rtb_Switch2_g = rtb_Switch_ik;
    }

    /* End of Switch: '<S375>/Switch2' */

    /* Switch: '<S368>/Switch3' incorporates:
     *  Constant: '<S370>/Constant'
     *  Gain: '<S368>/Gain1'
     *  Logic: '<S370>/Logical Operator'
     *  RelationalOperator: '<S370>/Relational Operator1'
     *  RelationalOperator: '<S370>/Relational Operator2'
     */
    if (rtb_Merge1 >= 0.0F) {
      /* Switch: '<S368>/Switch2' incorporates:
       *  Constant: '<S368>/Constant2'
       *  Constant: '<S369>/Constant'
       *  DataTypeConversion: '<S368>/Cast To Single'
       *  Logic: '<S369>/Logical Operator'
       *  RelationalOperator: '<S369>/Relational Operator1'
       *  RelationalOperator: '<S369>/Relational Operator3'
       */
      if (rtb_Merge1 > 0.0F) {
        rtb_EPS_LKA_Control = (UInt8)(((0.0F < rtb_Saturation_a1) &&
          (rtb_Saturation_a1 <= rtb_Switch2_o)) ? 1 : 0);
      } else {
        rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
      }

      /* End of Switch: '<S368>/Switch2' */
    } else {
      rtb_EPS_LKA_Control = (UInt8)((((uint32)(((0.0F <
        rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
        rtb_Switch2_g)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S368>/Switch3' */

    /* DataTypeConversion: '<S347>/Data Type Conversion' incorporates:
     *  Constant: '<S378>/Constant'
     *  Constant: '<S379>/Constant'
     *  Constant: '<S380>/Constant'
     *  Constant: '<S381>/Constant'
     *  Logic: '<S347>/Logical Operator'
     *  Logic: '<S347>/Logical Operator1'
     *  Logic: '<S347>/Logical Operator2'
     *  Logic: '<S347>/Logical Operator3'
     *  Logic: '<S347>/Logical Operator4'
     *  Logic: '<S347>/Logical Operator5'
     *  Logic: '<S347>/Logical Operator7'
     *  RelationalOperator: '<S378>/Compare'
     *  RelationalOperator: '<S379>/Compare'
     *  RelationalOperator: '<S380>/Compare'
     *  RelationalOperator: '<S381>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((((rtb_RelationalOperator_l_tmp ||
      (!rtb_BCM_Right_Light)) && (rtb_IMAPve_d_LKA_Mode > ((uint8)2U))) &&
      (rtb_EPS_LKA_Control == ((UInt8)((uint8)2U)))) ||
      (((rtb_RelationalOperator_l_tmp || (!rtb_BCM_Left_Light)) &&
        (rtb_EPS_LKA_Control == ((UInt8)((uint8)1U)))) &&
       (rtb_FDMMve_d_LkaFcnConf > ((uint8)2U)))) ? 1 : 0);

    /* DataTypeConversion: '<S346>/Data Type Conversion' incorporates:
     *  Constant: '<S376>/Constant'
     *  Constant: '<S377>/Constant'
     *  Logic: '<S346>/Logical Operator'
     *  RelationalOperator: '<S376>/Compare'
     *  RelationalOperator: '<S377>/Compare'
     */
    rtb_L0_Q = (uint8)(((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
                        (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? 1 : 0);

    /* If: '<S344>/If1' incorporates:
     *  Constant: '<S349>/Constant'
     *  Constant: '<S352>/Constant'
     *  Constant: '<S353>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode_g) == 2) && (((sint32)rtb_EPS_LKA_Control) ==
           1)) && (((sint32)rtb_L0_Q) == 1)) && (((sint32)
          rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S344>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S352>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S344>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode_g) == 2) && (((sint32)
        rtb_EPS_LKA_Control) == 2)) && (((sint32)rtb_L0_Q) == 1)) && (((sint32)
                 rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S344>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S353>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S344>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S344>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S349>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S344>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S344>/If1' */

    /* If: '<S404>/If' */
    if ((rtb_Abs_g >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_n4 >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S404>/Ph1SWA' incorporates:
       *  ActionPort: '<S408>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_i);

      /* End of Outputs for SubSystem: '<S404>/Ph1SWA' */
    } else if ((rtb_Abs_g <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_Abs_n4 <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S404>/Ph2SWA' incorporates:
       *  ActionPort: '<S409>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_i);

      /* End of Outputs for SubSystem: '<S404>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S404>/Ph3SWA' incorporates:
       *  ActionPort: '<S410>/Action Port'
       */
      LKAS_Ph3SWA_m(&rtb_Merge1_i);

      /* End of Outputs for SubSystem: '<S404>/Ph3SWA' */
    }

    /* End of If: '<S404>/If' */

    /* Saturate: '<S383>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_TTLC_f = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_TTLC_f = (-2.0F);
    } else {
      rtb_TTLC_f = rtb_Gain1;
    }

    /* End of Saturate: '<S383>/Saturation5' */

    /* Product: '<S390>/Divide5' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S393>:1' */
    /* '<S393>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S393>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S393>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S393>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S393>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_LL_ThresDet_lDvtThresUprLKA *= rtb_ThresDet_coefficient_c;

    /* Product: '<S390>/Divide6' */
    rtb_LKA_Veh2CamL_C = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S406>/Divide' incorporates:
     *  Abs: '<S406>/Abs'
     */
    rtb_Divide_c = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_g);

    /* Product: '<S390>/Divide4' */
    rtb_LftTTLC = rtb_ThresDet_coefficient_c * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S411>/Switch' incorporates:
     *  RelationalOperator: '<S411>/UpperRelop'
     */
    if (rtb_Divide_c < rtb_LftTTLC) {
      rtb_Switch_o = rtb_LftTTLC;
    } else {
      rtb_Switch_o = rtb_Divide_c;
    }

    /* End of Switch: '<S411>/Switch' */

    /* Switch: '<S411>/Switch2' incorporates:
     *  RelationalOperator: '<S411>/LowerRelop1'
     */
    if (rtb_Divide_c > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_i = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_i = rtb_Switch_o;
    }

    /* End of Switch: '<S411>/Switch2' */

    /* Saturate: '<S383>/Saturation1' */
    if (rtb_Add5_i > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_i < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_i;
    }

    /* End of Saturate: '<S383>/Saturation1' */

    /* Product: '<S407>/Divide' incorporates:
     *  Abs: '<S407>/Abs'
     */
    rtb_Divide_k = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_n4);

    /* Switch: '<S412>/Switch' incorporates:
     *  RelationalOperator: '<S412>/UpperRelop'
     */
    if (rtb_Divide_k < rtb_LftTTLC) {
      rtb_Switch_b = rtb_LftTTLC;
    } else {
      rtb_Switch_b = rtb_Divide_k;
    }

    /* End of Switch: '<S412>/Switch' */

    /* Switch: '<S412>/Switch2' incorporates:
     *  RelationalOperator: '<S412>/LowerRelop1'
     */
    if (rtb_Divide_k > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_p = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_p = rtb_Switch_b;
    }

    /* End of Switch: '<S412>/Switch2' */

    /* Switch: '<S405>/Switch3' incorporates:
     *  Constant: '<S407>/Constant'
     *  Gain: '<S405>/Gain1'
     *  Logic: '<S407>/Logical Operator'
     *  RelationalOperator: '<S407>/Relational Operator1'
     *  RelationalOperator: '<S407>/Relational Operator2'
     */
    if (rtb_Merge1_i >= 0.0F) {
      /* Switch: '<S405>/Switch2' incorporates:
       *  Constant: '<S405>/Constant2'
       *  Constant: '<S406>/Constant'
       *  DataTypeConversion: '<S405>/Cast To Single'
       *  Logic: '<S406>/Logical Operator'
       *  RelationalOperator: '<S406>/Relational Operator1'
       *  RelationalOperator: '<S406>/Relational Operator3'
       */
      if (rtb_Merge1_i > 0.0F) {
        rtb_EPS_LKA_Control = (UInt8)(((0.0F < rtb_TTLC_f) && (rtb_TTLC_f <=
          rtb_Switch2_i)) ? 1 : 0);
      } else {
        rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
      }

      /* End of Switch: '<S405>/Switch2' */
    } else {
      rtb_EPS_LKA_Control = (UInt8)((((uint32)(((0.0F <
        rtb_LL_ThresDet_lDvtThresLwrLKA) && (rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_p)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S405>/Switch3' */

    /* MATLAB Function: '<S384>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S416>:1' */
    /* '<S416>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S416>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S416>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S416>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge), 0.005F)) / 0.005F);

    /* '<S416>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_EPS_LKA_Control) == 2) && (rtb_IMAPve_g_EPS_SW_Trq >
          rtb_LL_MAX_DRIVER_TORQUE_DISABL)) || ((((sint32)rtb_EPS_LKA_Control) ==
          1) && (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL))))
    {
      /* Outputs for Enabled SubSystem: '<S384>/Count 0.2s' incorporates:
       *  EnablePort: '<S415>/Enable'
       */
      /* '<S416>:1:7' stDvrTkConFlg=1; */
      /* '<S416>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S416>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S415>/Memory' */
        LKAS_DW.Memory_PreviousInput_ix = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S415>/Add' incorporates:
       *  Memory: '<S415>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_ix;

      /* Saturate: '<S415>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S415>/Saturation' */
      /* End of Outputs for SubSystem: '<S384>/Count 0.2s' */

      /* Switch: '<S659>/Switch16' incorporates:
       *  Constant: '<S659>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S659>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S659>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S384>/Count 0.2s' incorporates:
       *  EnablePort: '<S415>/Enable'
       */
      /* RelationalOperator: '<S415>/Relational Operator' */
      LKAS_DW.RelationalOperator_k = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S415>/Memory' */
      LKAS_DW.Memory_PreviousInput_ix = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S384>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S384>/Count 0.2s' incorporates:
       *  EnablePort: '<S415>/Enable'
       */
      /* '<S416>:1:10' else */
      /* '<S416>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S415>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S384>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S384>/MATLAB Function' */

    /* RelationalOperator: '<S425>/Compare' incorporates:
     *  Constant: '<S425>/Constant'
     */
    rtb_Compare_a = (((sint32)(LKAS_DW.RelationalOperator_k ? 1 : 0)) > ((sint32)
      (false ? 1 : 0)));

    /* UnitDelay: '<S417>/Unit Delay' */
    rtb_UnitDelay_b = LKAS_DW.UnitDelay_DSTATE_b;

    /* RelationalOperator: '<S424>/Compare' incorporates:
     *  Constant: '<S424>/Constant'
     */
    rtb_Compare_pv = (((sint32)(rtb_UnitDelay_b ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S417>/If' incorporates:
     *  Constant: '<S420>/Constant'
     *  Constant: '<S421>/Constant'
     *  RelationalOperator: '<S418>/FixPt Relational Operator'
     *  RelationalOperator: '<S419>/FixPt Relational Operator'
     *  UnitDelay: '<S418>/Delay Input1'
     *  UnitDelay: '<S419>/Delay Input1'
     *
     * Block description for '<S418>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S419>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_k) && (((sint32)(rtb_Compare_a ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_f ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S417>/If Action Subsystem' incorporates:
       *  ActionPort: '<S420>/Action Port'
       */
      rtb_Merge_cl = true;

      /* End of Outputs for SubSystem: '<S417>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_b) && (((sint32)(rtb_Compare_pv ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_m ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S417>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S421>/Action Port'
       */
      rtb_Merge_cl = false;

      /* End of Outputs for SubSystem: '<S417>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S417>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S422>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_b, &rtb_Merge_cl);

      /* End of Outputs for SubSystem: '<S417>/If Action Subsystem3' */
    }

    /* End of If: '<S417>/If' */

    /* Outputs for Enabled SubSystem: '<S384>/Count' incorporates:
     *  EnablePort: '<S414>/Enable'
     */
    /* Logic: '<S384>/Logical Operator' incorporates:
     *  Constant: '<S413>/Constant'
     *  Memory: '<S384>/Memory'
     *  RelationalOperator: '<S413>/Compare'
     */
    if ((rtb_EPS_LKA_Control > ((UInt8)((uint8)0U))) &&
        (LKAS_DW.Memory_PreviousInput_gv)) {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S414>/Memory' */
        LKAS_DW.Memory_PreviousInput_d = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S414>/Add' incorporates:
       *  Memory: '<S414>/Memory'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_d;

      /* Saturate: '<S414>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_LftTTLC;
      }

      /* End of Saturate: '<S414>/Saturation' */

      /* Update for Memory: '<S414>/Memory' */
      LKAS_DW.Memory_PreviousInput_d = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S414>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S384>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S384>/Count' */

    /* Outputs for Enabled SubSystem: '<S417>/Sum Condition1' incorporates:
     *  EnablePort: '<S423>/state = reset'
     */
    if (rtb_Merge_cl) {
      if (!LKAS_DW.SumCondition1_MODE_n) {
        /* InitializeConditions for Memory: '<S423>/Memory' */
        LKAS_DW.Memory_PreviousInput_i1 = 0.0F;
        LKAS_DW.SumCondition1_MODE_n = true;
      }

      /* Sum: '<S423>/Add1' incorporates:
       *  Memory: '<S423>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_i1;

      /* Saturate: '<S423>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 5.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 5.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S423>/Saturation' */

      /* Switch: '<S659>/Switch40' incorporates:
       *  Constant: '<S659>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S659>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S659>/Switch40' */

      /* RelationalOperator: '<S423>/Relational Operator' incorporates:
       *  Sum: '<S384>/Add'
       */
      LKAS_DW.RelationalOperator_jo = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S423>/Memory' */
      LKAS_DW.Memory_PreviousInput_i1 = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_n) {
        /* Disable for Outport: '<S423>/Out' */
        LKAS_DW.RelationalOperator_jo = false;
        LKAS_DW.SumCondition1_MODE_n = false;
      }
    }

    /* End of Outputs for SubSystem: '<S417>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S385>/Sum Condition1' incorporates:
     *  EnablePort: '<S429>/state = reset'
     */
    /* Logic: '<S385>/Logical Operator' incorporates:
     *  Constant: '<S427>/Constant'
     *  Constant: '<S428>/Constant'
     *  Delay: '<S143>/Delay1'
     *  RelationalOperator: '<S427>/Compare'
     *  RelationalOperator: '<S428>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_j) {
        /* InitializeConditions for Memory: '<S429>/Memory' */
        LKAS_DW.Memory_PreviousInput_o = 0.0F;
        LKAS_DW.SumCondition1_MODE_j = true;
      }

      /* Sum: '<S429>/Add1' incorporates:
       *  Memory: '<S429>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_o;

      /* Saturate: '<S429>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S429>/Saturation' */

      /* RelationalOperator: '<S429>/Relational Operator' */
      LKAS_DW.RelationalOperator_a = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S429>/Memory' */
      LKAS_DW.Memory_PreviousInput_o = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_j) {
        /* Disable for Outport: '<S429>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE_j = false;
      }
    }

    /* End of Logic: '<S385>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S385>/Sum Condition1' */

    /* If: '<S382>/If1' incorporates:
     *  Constant: '<S387>/Constant'
     *  Constant: '<S389>/Constant'
     *  Constant: '<S426>/Constant'
     *  Delay: '<S143>/Delay'
     *  Logic: '<S382>/Logical Operator'
     *  Logic: '<S385>/Logical Operator1'
     *  RelationalOperator: '<S426>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode_g) == 2) && (((LKAS_DW.RelationalOperator_jo)
          || ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
              (LKAS_DW.RelationalOperator_a))) || (LKAS_DW.Delay_DSTATE_k))) {
      /* Outputs for IfAction SubSystem: '<S382>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S389>/Action Port'
       */
      LKAS_DW.Merge1_n = true;

      /* End of Outputs for SubSystem: '<S382>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S382>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S387>/Action Port'
       */
      LKAS_DW.Merge1_n = false;

      /* End of Outputs for SubSystem: '<S382>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S382>/If1' */

    /* MATLAB Function: '<S551>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_ThresDet_lDvtThresUprLDW, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient_e);

    /* Product: '<S551>/Multiply' */
    rtb_Multiply_a = rtb_LL_ThresDet_lDvtThresUprLDW *
      rtb_ThresDet_coefficient_e;

    /* Switch: '<S553>/Switch' incorporates:
     *  Constant: '<S551>/Constant'
     *  RelationalOperator: '<S553>/UpperRelop'
     */
    if (rtb_Multiply_a < 0.0F) {
      rtb_Switch_j = 0.0F;
    } else {
      rtb_Switch_j = rtb_Multiply_a;
    }

    /* End of Switch: '<S553>/Switch' */

    /* Switch: '<S553>/Switch2' incorporates:
     *  RelationalOperator: '<S553>/LowerRelop1'
     */
    if (rtb_Multiply_a > rtb_LL_ThresDet_lDvtThresUprLDW) {
      rtb_Switch2_f = rtb_LL_ThresDet_lDvtThresUprLDW;
    } else {
      rtb_Switch2_f = rtb_Switch_j;
    }

    /* End of Switch: '<S553>/Switch2' */

    /* Logic: '<S537>/Logical Operator3' incorporates:
     *  Constant: '<S549>/Constant'
     *  Constant: '<S550>/Constant'
     *  Logic: '<S547>/Logical Operator'
     *  Logic: '<S548>/Logical Operator'
     *  RelationalOperator: '<S548>/Relational Operator1'
     *  RelationalOperator: '<S548>/Relational Operator2'
     *  RelationalOperator: '<S549>/Compare'
     *  RelationalOperator: '<S550>/Compare'
     */
    rtb_LogicalOperator3_pm = (((LKAS_DW.LKA_Mode_g >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1 >= rtb_Switch2_f) && (rtb_Add5_i >= rtb_Switch2_f)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_pm);

    /* If: '<S537>/If' incorporates:
     *  Constant: '<S543>/Constant'
     *  DataTypeConversion: '<S537>/Cast To Single'
     */
    if (((((sint32)LKAS_DW.LKA_Mode_g) == 1) || (((sint32)LKAS_DW.LKA_Mode_g) ==
          2)) && rtb_LogicalOperator3_pm) {
      /* Outputs for IfAction SubSystem: '<S537>/If Action Subsystem' incorporates:
       *  ActionPort: '<S543>/Action Port'
       */
      LKAS_DW.Merge_d = true;

      /* End of Outputs for SubSystem: '<S537>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S537>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S545>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_d);

      /* End of Outputs for SubSystem: '<S537>/If Action Subsystem3' */
    }

    /* End of If: '<S537>/If' */

    /* Delay: '<S143>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S432>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S432>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_cp != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S432>/If Action Subsystem' incorporates:
         *  ActionPort: '<S463>/Action Port'
         */
        /* InitializeConditions for If: '<S432>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S463>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_ed = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S432>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S432>/If Action Subsystem' incorporates:
       *  ActionPort: '<S463>/Action Port'
       */
      /* Sum: '<S463>/Add1' incorporates:
       *  Memory: '<S463>/Memory'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_ed;

      /* Saturate: '<S463>/Saturation' */
      if (rtb_LL_TkOvStChk_tiTDelTime > 10.0F) {
        rtb_LL_TkOvStChk_tiTDelTime = 10.0F;
      } else {
        if (rtb_LL_TkOvStChk_tiTDelTime < 0.0F) {
          rtb_LL_TkOvStChk_tiTDelTime = 0.0F;
        }
      }

      /* End of Saturate: '<S463>/Saturation' */
      /* End of Outputs for SubSystem: '<S432>/If Action Subsystem' */

      /* Switch: '<S659>/Switch64' incorporates:
       *  Constant: '<S659>/LLSMConClb33'
       *
       * Block description for '<S659>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S659>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S432>/If Action Subsystem' incorporates:
       *  ActionPort: '<S463>/Action Port'
       */
      /* RelationalOperator: '<S463>/Relational Operator' */
      rtb_Merge_p = (rtb_LL_TkOvStChk_tiTDelTime >= x10);

      /* Update for Memory: '<S463>/Memory' */
      LKAS_DW.Memory_PreviousInput_ed = rtb_LL_TkOvStChk_tiTDelTime;

      /* End of Outputs for SubSystem: '<S432>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S432>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S464>/Action Port'
       */
      /* SignalConversion: '<S464>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S464>/Constant'
       */
      rtb_Merge_p = false;

      /* End of Outputs for SubSystem: '<S432>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S432>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S433>/Logical Operator1' incorporates:
     *  Constant: '<S465>/Constant'
     *  Logic: '<S433>/Logical Operator'
     *  RelationalOperator: '<S433>/Relational Operator1'
     *  RelationalOperator: '<S433>/Relational Operator2'
     *  RelationalOperator: '<S465>/Compare'
     */
    rtb_BCM_Left_Light = ((LKAS_DW.LKA_Mode_g >= ((uint8)1U)) && ((rtb_Gain1 <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_i <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S430>/Logical Operator3' */
    rtb_RelationalOperator_ct = ((rtb_BCM_Left_Light || rtb_Merge_p) ||
      rtb_RelationalOperator_ct);

    /* If: '<S430>/If1' incorporates:
     *  Constant: '<S440>/Constant'
     *  DataTypeConversion: '<S430>/Cast To Single'
     */
    if (((((sint32)LKAS_DW.LKA_Mode_g) == 1) || (((sint32)LKAS_DW.LKA_Mode_g) ==
          2)) && rtb_RelationalOperator_ct) {
      /* Outputs for IfAction SubSystem: '<S430>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S440>/Action Port'
       */
      LKAS_DW.Merge1_h = true;

      /* End of Outputs for SubSystem: '<S430>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S430>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S442>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_h);

      /* End of Outputs for SubSystem: '<S430>/If Action Subsystem4' */
    }

    /* End of If: '<S430>/If1' */

    /* Memory: '<S358>/Memory' */
    rtb_Memory = LKAS_DW.Memory_PreviousInput_l;

    /* If: '<S358>/If' */
    if ((rtb_Abs_g >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_n4 >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S358>/Ph1SWA' incorporates:
       *  ActionPort: '<S362>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S358>/Ph1SWA' */
    } else if ((rtb_Abs_g <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_n4 <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S358>/Ph2SWA' incorporates:
       *  ActionPort: '<S363>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S358>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S358>/Ph3SWA' incorporates:
       *  ActionPort: '<S364>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory, &rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S358>/Ph3SWA' */
    }

    /* End of If: '<S358>/If' */

    /* Product: '<S354>/Divide2' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S354>/Divide3' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S360>/Divide' */
    rtb_Divide_i = rtb_LKA_Veh2CamL_C * x20;

    /* Product: '<S354>/Divide1' incorporates:
     *  MATLAB Function: '<S354>/MATLAB Function'
     */
    rtb_LftTTLC = rtb_ThresDet_coefficient_c * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S365>/Switch' incorporates:
     *  RelationalOperator: '<S365>/UpperRelop'
     */
    if (rtb_Divide_i < rtb_LftTTLC) {
      rtb_Switch_m = rtb_LftTTLC;
    } else {
      rtb_Switch_m = rtb_Divide_i;
    }

    /* End of Switch: '<S365>/Switch' */

    /* Switch: '<S365>/Switch2' incorporates:
     *  RelationalOperator: '<S365>/LowerRelop1'
     */
    if (rtb_Divide_i > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_po = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_po = rtb_Switch_m;
    }

    /* End of Switch: '<S365>/Switch2' */

    /* Product: '<S361>/Divide' */
    rtb_Divide_b = rtb_LKA_Veh2CamL_C * rtb_TLft;

    /* Switch: '<S366>/Switch' incorporates:
     *  RelationalOperator: '<S366>/UpperRelop'
     */
    if (rtb_Divide_b < rtb_LftTTLC) {
      rtb_Switch_k = rtb_LftTTLC;
    } else {
      rtb_Switch_k = rtb_Divide_b;
    }

    /* End of Switch: '<S366>/Switch' */

    /* Switch: '<S366>/Switch2' incorporates:
     *  RelationalOperator: '<S366>/LowerRelop1'
     */
    if (rtb_Divide_b > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_d = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_d = rtb_Switch_k;
    }

    /* End of Switch: '<S366>/Switch2' */

    /* Switch: '<S359>/Switch3' incorporates:
     *  Gain: '<S359>/Gain1'
     *  RelationalOperator: '<S361>/Relational Operator2'
     */
    if (rtb_Merge1_a >= 0.0F) {
      /* Switch: '<S359>/Switch2' incorporates:
       *  Constant: '<S359>/Constant2'
       *  DataTypeConversion: '<S359>/Cast To Single'
       *  RelationalOperator: '<S360>/Relational Operator2'
       */
      if (rtb_Merge1_a > 0.0F) {
        rtb_L0_Q = (uint8)((rtb_Saturation_a1 <= rtb_Switch2_po) ? 1 : 0);
      } else {
        rtb_L0_Q = ((uint8)0U);
      }

      /* End of Switch: '<S359>/Switch2' */
    } else {
      rtb_L0_Q = (uint8)((((uint32)((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
        rtb_Switch2_d) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S359>/Switch3' */

    /* If: '<S344>/If' incorporates:
     *  Constant: '<S348>/Constant'
     *  Constant: '<S350>/Constant'
     *  Constant: '<S351>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode_g) == 1) || (((sint32)LKAS_DW.LKA_Mode_g) ==
           2)) && (((sint32)rtb_L0_Q) == 1)) && (((sint32)
          rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S344>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S350>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S344>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode_g) == 1) || (((sint32)
        LKAS_DW.LKA_Mode_g) == 2)) && (((sint32)rtb_L0_Q) == 2)) && (((sint32)
                 rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S344>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S351>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S344>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S344>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S348>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S344>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S344>/If' */

    /* Memory: '<S394>/Memory' */
    rtb_Memory_p = LKAS_DW.Memory_PreviousInput_g;

    /* If: '<S394>/If' */
    if ((rtb_Abs_g >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_n4 >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S394>/Ph1SWA' incorporates:
       *  ActionPort: '<S398>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_g);

      /* End of Outputs for SubSystem: '<S394>/Ph1SWA' */
    } else if ((rtb_Abs_g <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_n4 <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S394>/Ph2SWA' incorporates:
       *  ActionPort: '<S399>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_g);

      /* End of Outputs for SubSystem: '<S394>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S394>/Ph3SWA' incorporates:
       *  ActionPort: '<S400>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_p, &rtb_Merge1_g);

      /* End of Outputs for SubSystem: '<S394>/Ph3SWA' */
    }

    /* End of If: '<S394>/If' */

    /* Product: '<S390>/Divide2' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S390>/Divide3' */
    rtb_LKA_Veh2CamL_C = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S396>/Divide' */
    rtb_Divide_i4 = rtb_LKA_Veh2CamL_C * x20;

    /* Product: '<S390>/Divide1' */
    rtb_LftTTLC = rtb_ThresDet_coefficient_c * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S402>/Switch' incorporates:
     *  RelationalOperator: '<S402>/UpperRelop'
     */
    if (rtb_Divide_i4 < rtb_LftTTLC) {
      rtb_Switch_ir = rtb_LftTTLC;
    } else {
      rtb_Switch_ir = rtb_Divide_i4;
    }

    /* End of Switch: '<S402>/Switch' */

    /* Switch: '<S402>/Switch2' incorporates:
     *  RelationalOperator: '<S402>/LowerRelop1'
     */
    if (rtb_Divide_i4 > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_j = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_j = rtb_Switch_ir;
    }

    /* End of Switch: '<S402>/Switch2' */

    /* Product: '<S397>/Divide' */
    rtb_Divide_o = rtb_LKA_Veh2CamL_C * rtb_TLft;

    /* Switch: '<S403>/Switch' incorporates:
     *  RelationalOperator: '<S403>/UpperRelop'
     */
    if (rtb_Divide_o < rtb_LftTTLC) {
      rtb_Switch_l = rtb_LftTTLC;
    } else {
      rtb_Switch_l = rtb_Divide_o;
    }

    /* End of Switch: '<S403>/Switch' */

    /* Switch: '<S403>/Switch2' incorporates:
     *  RelationalOperator: '<S403>/LowerRelop1'
     */
    if (rtb_Divide_o > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_c = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_c = rtb_Switch_l;
    }

    /* End of Switch: '<S403>/Switch2' */

    /* Switch: '<S395>/Switch3' incorporates:
     *  Gain: '<S395>/Gain1'
     *  RelationalOperator: '<S397>/Relational Operator2'
     */
    if (rtb_Merge1_g >= 0.0F) {
      /* Switch: '<S395>/Switch2' incorporates:
       *  Constant: '<S395>/Constant2'
       *  DataTypeConversion: '<S395>/Cast To Single'
       *  RelationalOperator: '<S396>/Relational Operator2'
       */
      if (rtb_Merge1_g > 0.0F) {
        rtb_IMAPve_d_BCM_HazardLamp = (uint8)((rtb_TTLC_f <= rtb_Switch2_j) ? 1 :
          0);
      } else {
        rtb_IMAPve_d_BCM_HazardLamp = ((uint8)0U);
      }

      /* End of Switch: '<S395>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((((uint32)
        ((rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_c) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S395>/Switch3' */

    /* Outputs for Enabled SubSystem: '<S395>/Sum Condition' incorporates:
     *  EnablePort: '<S401>/Enable'
     */
    if (((sint32)rtb_IMAPve_d_BCM_HazardLamp) > 0) {
      if (!LKAS_DW.SumCondition_MODE) {
        /* InitializeConditions for Memory: '<S401>/Memory' */
        LKAS_DW.Memory_PreviousInput_b = 0.0F;
        LKAS_DW.SumCondition_MODE = true;
      }

      /* Sum: '<S401>/Add1' incorporates:
       *  Memory: '<S401>/Memory'
       */
      rtb_Saturation_a1 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_b;

      /* Saturate: '<S401>/Saturation' */
      if (rtb_Saturation_a1 > 5.0F) {
        rtb_Saturation_a1 = 5.0F;
      } else {
        if (rtb_Saturation_a1 < 0.0F) {
          rtb_Saturation_a1 = 0.0F;
        }
      }

      /* End of Saturate: '<S401>/Saturation' */

      /* RelationalOperator: '<S401>/Relational Operator' incorporates:
       *  Constant: '<S395>/Constant'
       */
      LKAS_DW.RelationalOperator_eo = (rtb_Saturation_a1 <= 2.0F);

      /* Update for Memory: '<S401>/Memory' */
      LKAS_DW.Memory_PreviousInput_b = rtb_Saturation_a1;
    } else {
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S401>/Out' */
        LKAS_DW.RelationalOperator_eo = false;
        LKAS_DW.SumCondition_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S395>/Sum Condition' */

    /* If: '<S382>/If' incorporates:
     *  Constant: '<S386>/Constant'
     *  Constant: '<S388>/Constant'
     *  DataTypeConversion: '<S395>/Cast To Single3'
     *  DataTypeConversion: '<S395>/Cast To Single4'
     *  Product: '<S395>/Divide'
     */
    if (((((sint32)LKAS_DW.LKA_Mode_g) == 1) || (((sint32)LKAS_DW.LKA_Mode_g) ==
          2)) && (((sint32)((uint32)(((uint32)rtb_IMAPve_d_BCM_HazardLamp) *
            (LKAS_DW.RelationalOperator_eo ? 1U : 0U)))) == 0)) {
      /* Outputs for IfAction SubSystem: '<S382>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S388>/Action Port'
       */
      LKAS_DW.LKA_Fault = true;

      /* End of Outputs for SubSystem: '<S382>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S382>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S386>/Action Port'
       */
      LKAS_DW.LKA_Fault = false;

      /* End of Outputs for SubSystem: '<S382>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S382>/If' */

    /* Logic: '<S343>/Logical Operator1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     */
    rtb_BCM_Right_Light = ((tmpRead_q != ((T_M_Nm_Float32)0.0F)) || (tmpRead_r
      != ((T_M_Nm_Float32)0.0F)));

    /* Logic: '<S343>/Logical Operator10' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     */
    LKAS_DW.LDW_Fault = ((tmpRead_r != ((T_M_Nm_Float32)0.0F)) ||
                         rtb_BCM_Right_Light);

    /* Chart: '<S143>/LDW_State_Machine'
     *
     * Block description for '<S143>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* Sum: '<S595>/Add' incorporates:
     *  Memory: '<S595>/Memory'
     */
    rtb_LftTTLC = LKAS_DW.Memory_PreviousInput_e + rtb_LKA_SampleTime;

    /* Saturate: '<S595>/Saturation' */
    if (rtb_LftTTLC > 11.0F) {
      rtb_Saturation_k = 11.0F;
    } else if (rtb_LftTTLC < 0.0F) {
      rtb_Saturation_k = 0.0F;
    } else {
      rtb_Saturation_k = rtb_LftTTLC;
    }

    /* End of Saturate: '<S595>/Saturation' */

    /* Logic: '<S343>/Logical Operator8' incorporates:
     *  Constant: '<S594>/Constant'
     *  Constant: '<S595>/Constant1'
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  Logic: '<S343>/AND'
     *  RelationalOperator: '<S594>/Compare'
     *  RelationalOperator: '<S595>/Relational Operator'
     */
    LKAS_DW.LKA_Fault = (((tmpRead_r != ((T_M_Nm_Float32)0.0F)) ||
                          rtb_BCM_Right_Light) || ((rtb_IMAPve_d_EPS_LKA_State ==
      ((uint8)4U)) && (rtb_Saturation_k >= ((float32)((uint16)5U)))));

    /* Chart: '<S143>/LKA_State_Machine'
     *
     * Block description for '<S143>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S320>/Subsystem' incorporates:
     *  EnablePort: '<S324>/Enable'
     */
    /* Logic: '<S320>/Logical Operator3' incorporates:
     *  Abs: '<S320>/Abs4'
     *  Abs: '<S320>/Abs5'
     *  Abs: '<S320>/Abs6'
     *  Abs: '<S320>/Abs7'
     *  Constant: '<S320>/Constant'
     *  Constant: '<S320>/Constant1'
     *  Constant: '<S320>/Constant4'
     *  Constant: '<S320>/Constant5'
     *  Constant: '<S322>/Constant'
     *  Constant: '<S323>/Constant'
     *  Logic: '<S320>/Logical Operator'
     *  Logic: '<S320>/Logical Operator1'
     *  Logic: '<S320>/Logical Operator4'
     *  RelationalOperator: '<S320>/Relational Operator'
     *  RelationalOperator: '<S320>/Relational Operator1'
     *  RelationalOperator: '<S320>/Relational Operator2'
     *  RelationalOperator: '<S320>/Relational Operator3'
     *  RelationalOperator: '<S320>/Relational Operator6'
     *  RelationalOperator: '<S320>/Relational Operator7'
     *  RelationalOperator: '<S322>/Compare'
     *  RelationalOperator: '<S323>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_j) <= 0.008F) && (fabsf(rtb_L0_C1_d) <= 0.008F)) &&
           ((fabsf(rtb_L0_C2_g) <= 0.0001F) && (fabsf(rtb_R0_C2_e) <= 0.0001F)))
          && ((rtb_FDMMve_d_LkaFcnConf == ((uint8)3U)) && (rtb_IMAPve_d_LKA_Mode
            == ((uint8)3U)))) && (rtb_ESC_VehSpd >= 35.0F)) && (rtb_TTLC <= 4.0F))
    {
      if (!LKAS_DW.Subsystem_MODE_j) {
        /* InitializeConditions for Memory: '<S324>/Memory' */
        LKAS_DW.Memory_PreviousInput_og = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_j = true;
      }

      /* Sum: '<S324>/Add1' incorporates:
       *  Memory: '<S324>/Memory'
       */
      rtb_Saturation_fq = (uint16)(1U + ((uint32)LKAS_DW.Memory_PreviousInput_og));

      /* Saturate: '<S324>/Saturation' */
      if (rtb_Saturation_fq >= ((uint16)3000U)) {
        rtb_Saturation_fq = ((uint16)3000U);
      }

      /* End of Saturate: '<S324>/Saturation' */

      /* RelationalOperator: '<S324>/Relational Operator' incorporates:
       *  Constant: '<S320>/Constant3'
       *  DataTypeConversion: '<S324>/Cast To Single1'
       *  Product: '<S320>/Divide'
       */
      LKAS_DW.RelationalOperator_c = (rtb_Saturation_fq >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S324>/Memory' */
      LKAS_DW.Memory_PreviousInput_og = rtb_Saturation_fq;
    } else {
      if (LKAS_DW.Subsystem_MODE_j) {
        /* Disable for Outport: '<S324>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.Subsystem_MODE_j = false;
      }
    }

    /* End of Logic: '<S320>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S320>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S294>/Subsystem' incorporates:
     *  EnablePort: '<S319>/Enable'
     */
    if (LKAS_DW.RelationalOperator_c) {
      /* Sum: '<S321>/Add2' incorporates:
       *  Constant: '<S321>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S321>/Memory3'
       */
      rtb_Saturation_a1 = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S321>/Saturation' */
      if (rtb_Saturation_a1 > 50.0F) {
        rtb_Saturation_a1 = 50.0F;
      } else {
        if (rtb_Saturation_a1 < 0.0F) {
          rtb_Saturation_a1 = 0.0F;
        }
      }

      /* End of Saturate: '<S321>/Saturation' */

      /* Switch: '<S321>/Switch' incorporates:
       *  Constant: '<S319>/Constant'
       *  Product: '<S321>/Divide'
       *  Product: '<S321>/Divide1'
       *  Sum: '<S321>/Add'
       *  Sum: '<S321>/Add1'
       *  UnitDelay: '<S321>/Unit Delay'
       */
      if (rtb_Saturation_a1 > 1.0F) {
        rtb_ThresDet_coefficient_c = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_L0_C0_d2 - LKAS_DW.UnitDelay_DSTATE)) + LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_ThresDet_coefficient_c = rtb_L0_C0_d2;
      }

      /* End of Switch: '<S321>/Switch' */

      /* Saturate: '<S319>/Saturation' */
      if (rtb_ThresDet_coefficient_c > 3.0F) {
        LKAS_DW.Saturation_a = 3.0F;
      } else if (rtb_ThresDet_coefficient_c < (-3.0F)) {
        LKAS_DW.Saturation_a = (-3.0F);
      } else {
        LKAS_DW.Saturation_a = rtb_ThresDet_coefficient_c;
      }

      /* End of Saturate: '<S319>/Saturation' */

      /* Update for UnitDelay: '<S321>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_ThresDet_coefficient_c;

      /* Update for Memory: '<S321>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_Saturation_a1;
    }

    /* End of Outputs for SubSystem: '<S294>/Subsystem' */

    /* Saturate: '<S296>/Saturation' */
    if (rtb_ESC_VehSpd > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else if (rtb_ESC_VehSpd < 0.001F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.001F;
    } else {
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ESC_VehSpd;
    }

    /* End of Saturate: '<S296>/Saturation' */

    /* Gain: '<S332>/kph To mps' incorporates:
     *  Gain: '<S333>/kph To mps'
     */
    rtb_LL_LDW_LatestWarnLine_C = 0.277777791F * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S332>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S334>:1' */
    /* '<S334>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_Saturation_a1 = 150.0F;
    } else if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
      rtb_Saturation_a1 = 60.0F;
    } else {
      rtb_Saturation_a1 = rtb_LL_ThresDet_lDvtThresUprLKA;
    }

    /* End of Saturate: '<S332>/Saturation3' */

    /* Product: '<S332>/Divide1' incorporates:
     *  Constant: '<S332>/Constant'
     */
    rtb_LftTTLC = 0.09F / rtb_Saturation_a1;

    /* Saturate: '<S332>/Saturation1' */
    if (rtb_LftTTLC > 0.0117F) {
      rtb_LftTTLC = 0.0117F;
    } else {
      if (rtb_LftTTLC < 0.00237F) {
        rtb_LftTTLC = 0.00237F;
      }
    }

    /* End of Saturate: '<S332>/Saturation1' */

    /* Switch: '<S658>/Switch7' incorporates:
     *  Constant: '<S658>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_d != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_d;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S658>/Switch7' */

    /* MATLAB Function: '<S332>/MATLAB Function' incorporates:
     *  Gain: '<S332>/kph To mps'
     */
    rtb_Saturation_a1 = ((((((((rtb_LftTTLC * rtb_LL_LDW_LatestWarnLine_C) *
      rtb_LL_LDW_LatestWarnLine_C) + 1.0F) * x10) * LKAS_DW.LKA_StrRatio_C_l) *
      LKAS_DW.LKA_WhlBaseL_C_a) / (rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_LDW_LatestWarnLine_C)) * 180.0F) / 3.14F;

    /* Saturate: '<S333>/Saturation3' */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 60.0F;
      }
    }

    /* End of Saturate: '<S333>/Saturation3' */

    /* Product: '<S333>/Divide1' incorporates:
     *  Constant: '<S333>/Constant'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = 0.09F / rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S333>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S335>:1' */
    /* '<S335>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 0.0117F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.0117F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 0.00237F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 0.00237F;
      }
    }

    /* End of Saturate: '<S333>/Saturation1' */

    /* Switch: '<S658>/Switch4' incorporates:
     *  Constant: '<S658>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_e != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_e;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S658>/Switch4' */

    /* MATLAB Function: '<S333>/MATLAB Function' */
    rtb_ThresDet_coefficient_c = ((((((((rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_LDW_LatestWarnLine_C) * rtb_LL_LDW_LatestWarnLine_C) + 1.0F) * x10)
      * LKAS_DW.LKA_StrRatio_C_l) * LKAS_DW.LKA_WhlBaseL_C_a) /
      (rtb_LL_LDW_LatestWarnLine_C * rtb_LL_LDW_LatestWarnLine_C)) * 180.0F) /
      3.14F;

    /* Gain: '<S291>/Gain1' incorporates:
     *  Sum: '<S291>/Add1'
     */
    rtb_LL_LDW_LatestWarnLine_C = (rtb_Add_o + rtb_Add_a) * 0.5F;

    /* Switch: '<S293>/Switch' incorporates:
     *  Constant: '<S309>/Constant'
     *  RelationalOperator: '<S309>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_LftTTLC = rtb_LFTTTLC;
    } else {
      rtb_LftTTLC = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S293>/Switch' */

    /* Saturate: '<S293>/Saturation' */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else {
      if (rtb_LftTTLC < 0.5F) {
        rtb_LftTTLC = 0.5F;
      }
    }

    /* End of Saturate: '<S293>/Saturation' */

    /* Product: '<S317>/Divide' */
    rtb_Divide_d1 = rtb_Abs_p_tmp * rtb_LftTTLC;

    /* Switch: '<S293>/Switch1' incorporates:
     *  Constant: '<S310>/Constant'
     *  RelationalOperator: '<S310>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S293>/Switch1' */

    /* Saturate: '<S293>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S293>/Saturation1' */

    /* Product: '<S318>/Divide' */
    rtb_Divide_n = rtb_Abs_p_tmp * rtb_LL_HdAgPrvwT_C;

    /* Gain: '<S293>/Gain1' incorporates:
     *  Sum: '<S293>/Add1'
     */
    rtb_LL_HdAgPrvwT_C = (rtb_Divide_d1 + rtb_Divide_n) * 0.5F;

    /* Switch: '<S658>/Switch8' incorporates:
     *  Constant: '<S658>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_p != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_p;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S658>/Switch8' */

    /* Product: '<S308>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_Abs_p_tmp * x10;

    /* Product: '<S306>/Z*Z' incorporates:
     *  Product: '<S307>/Z*Z'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Sum: '<S306>/Add' incorporates:
     *  Product: '<S306>/Product'
     *  Product: '<S306>/Product3'
     *  Product: '<S306>/Product4'
     *  Product: '<S306>/Z*Z'
     *  Product: '<S306>/Z*Z*Z'
     */
    rtb_Add_ah = (((rtb_L0_C1_j * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_L0_C0_h)
                  + (rtb_L0_C2_g * rtb_LL_ThresDet_lDvtThresLwrLDW)) +
      ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_ThresDet_lDvtThresLwrLDW) *
       rtb_LL_CompHdAg_C);

    /* Sum: '<S307>/Add' incorporates:
     *  Product: '<S307>/Product'
     *  Product: '<S307>/Product3'
     *  Product: '<S307>/Product4'
     *  Product: '<S307>/Z*Z*Z'
     */
    rtb_Add_g = (((rtb_L0_C1_d * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_R0_C0_f)
                 + (rtb_R0_C2_e * rtb_LL_ThresDet_lDvtThresLwrLDW)) +
      ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_ThresDet_lDvtThresLwrLDW) *
       rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S170>/Memory' */
        LKAS_DW.Memory_PreviousInput_ox = 0.0F;

        /* InitializeConditions for Memory: '<S201>/Memory' */
        LKAS_DW.Memory_PreviousInput_jj = ((uint16)0U);

        /* InitializeConditions for Memory: '<S188>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_i = ((uint8)0U);

        /* InitializeConditions for Memory: '<S200>/Memory' */
        LKAS_DW.Memory_PreviousInput_cy = ((uint16)0U);

        /* InitializeConditions for Memory: '<S202>/Memory' */
        LKAS_DW.Memory_PreviousInput_po = ((uint16)0U);

        /* InitializeConditions for Memory: '<S197>/Memory' */
        LKAS_DW.Memory_PreviousInput_js = ((uint16)0U);

        /* InitializeConditions for Memory: '<S185>/Memory' */
        LKAS_DW.Memory_PreviousInput_lw = 0.0F;

        /* InitializeConditions for Memory: '<S171>/Memory' */
        LKAS_DW.Memory_PreviousInput_a = 0.0F;

        /* InitializeConditions for Memory: '<S172>/Memory' */
        LKAS_DW.Memory_PreviousInput_h = 0.0F;

        /* InitializeConditions for UnitDelay: '<S174>/Delay Input1'
         *
         * Block description for '<S174>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_c = false;

        /* InitializeConditions for Memory: '<S172>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_e = false;

        /* InitializeConditions for Memory: '<S163>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_i = 0.0F;

        /* InitializeConditions for Memory: '<S264>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_j = 0.0F;

        /* InitializeConditions for Memory: '<S247>/Memory' */
        LKAS_DW.Memory_PreviousInput_hq = 0.0F;

        /* InitializeConditions for UnitDelay: '<S245>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_l = 0.0F;

        /* InitializeConditions for Memory: '<S253>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_je = 0.0F;

        /* InitializeConditions for Memory: '<S259>/Memory' */
        LKAS_DW.Memory_PreviousInput_hk = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S263>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_i = 0.0F;

        /* InitializeConditions for Memory: '<S263>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_k = 0.0F;

        /* InitializeConditions for UnitDelay: '<S240>/Delay Input2'
         *
         * Block description for '<S240>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_k = 0.0F;

        /* InitializeConditions for Memory: '<S240>/Memory' */
        LKAS_DW.Memory_PreviousInput_jq = ((uint16)0U);

        /* InitializeConditions for Memory: '<S196>/Memory' */
        LKAS_DW.Memory_PreviousInput_ac = ((uint16)0U);

        /* InitializeConditions for Memory: '<S198>/Memory' */
        LKAS_DW.Memory_PreviousInput_hd = ((uint16)0U);

        /* InitializeConditions for Memory: '<S199>/Memory' */
        LKAS_DW.Memory_PreviousInput_ph = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S158>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S158>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S172>/Moving Standard Deviation1' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S172>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S172>/Moving Standard Deviation2' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation2_j);

        /* End of SystemReset for SubSystem: '<S172>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Memory: '<S170>/Memory' */
      rtb_Divide3_j = LKAS_DW.Memory_PreviousInput_ox;

      /* Sum: '<S170>/Add2' */
      rtb_Divide3_j += rtb_LKA_SampleTime;

      /* Saturate: '<S170>/Saturation2' */
      if (rtb_Divide3_j > 20.0F) {
        rtb_Saturation2_m = 20.0F;
      } else if (rtb_Divide3_j < 0.0F) {
        rtb_Saturation2_m = 0.0F;
      } else {
        rtb_Saturation2_m = rtb_Divide3_j;
      }

      /* End of Saturate: '<S170>/Saturation2' */

      /* Abs: '<S170>/Abs' */
      rtb_Divide3_j = rtb_TTLC_l;

      /* Saturate: '<S170>/Saturation' */
      if (rtb_Divide3_j > 0.004F) {
        rtb_Divide3_j = 0.004F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S170>/Saturation' */

      /* RelationalOperator: '<S170>/Relational Operator4' incorporates:
       *  Constant: '<S170>/Constant'
       *  Constant: '<S170>/Constant1'
       *  Product: '<S170>/Divide'
       *  Sum: '<S170>/Add'
       */
      rtb_BCM_Right_Light = (rtb_Saturation2_m >=
        ((((rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F) * rtb_Divide3_j) / 0.004F) +
         rtb_LL_LKAExPrcs_tiExitTime1));

      /* Abs: '<S171>/Abs' */
      rtb_Divide3_j = rtb_TTLC_l;

      /* Saturate: '<S171>/Saturation' */
      if (rtb_Divide3_j > 0.004F) {
        rtb_Divide3_j = 0.004F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S171>/Saturation' */

      /* Product: '<S171>/Divide' incorporates:
       *  Constant: '<S171>/Constant'
       *  Constant: '<S171>/Constant1'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = ((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) *
        rtb_Divide3_j) / 0.004F;

      /* Sum: '<S201>/Add' incorporates:
       *  Constant: '<S201>/Constant'
       *  Memory: '<S201>/Memory'
       */
      rtb_Saturation_fq = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_jj));

      /* Saturate: '<S201>/Saturation1' */
      if (rtb_Saturation_fq < ((uint16)10000U)) {
        rtb_Saturation1_p = rtb_Saturation_fq;
      } else {
        rtb_Saturation1_p = ((uint16)10000U);
      }

      /* End of Saturate: '<S201>/Saturation1' */

      /* Gain: '<S246>/kph to mps' */
      rtb_Divide3_j = rtb_Abs_p_tmp;

      /* Saturate: '<S246>/Saturation3' */
      if (rtb_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_ESC_VehSpd;
      }

      /* End of Saturate: '<S246>/Saturation3' */

      /* Product: '<S246>/Divide2' incorporates:
       *  Constant: '<S246>/Constant'
       */
      rtb_LftTTLC = 0.09F / x10;

      /* Switch: '<S658>/Switch36' incorporates:
       *  Constant: '<S658>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_d != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_d;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S658>/Switch36' */

      /* Saturate: '<S246>/Saturation1' */
      if (rtb_LftTTLC > 0.01F) {
        rtb_LftTTLC = 0.01F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S246>/Saturation1' */

      /* Gain: '<S246>/Gain2' incorporates:
       *  Constant: '<S246>/Constant1'
       *  Gain: '<S246>/rad to deg'
       *  Gain: '<S291>/Gain1'
       *  Math: '<S246>/Math Function'
       *  Product: '<S246>/Divide'
       *  Product: '<S246>/Divide1'
       *  Product: '<S246>/Product'
       *  Product: '<S246>/Product1'
       *  Product: '<S246>/Product2'
       *  Product: '<S246>/Product3'
       *  Sum: '<S246>/Add'
       *
       * About '<S246>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = (((((((rtb_Divide3_j * rtb_Divide3_j) *
        rtb_LftTTLC) + 1.0F) / (rtb_Divide3_j / LKAS_DW.LKA_WhlBaseL_C_a)) *
        ((rtb_Divide3_j * rtb_LL_LDW_LatestWarnLine_C) * 57.2957802F)) * x10) *
        LKAS_DW.LKA_StrRatio_C_l) * (-1.0F);

      /* Sum: '<S184>/Add1' */
      rtb_Add1_or = (rtb_L0_C0_d2 - rtb_LL_LKAExPrcs_tiExitTime1) -
        LKAS_DW.Saturation_a;

      /* If: '<S201>/If' incorporates:
       *  Constant: '<S201>/Constant2'
       */
      if (rtb_Saturation1_p == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S201>/if action ' incorporates:
         *  ActionPort: '<S224>/Action Port'
         */
        LKAS_ifaction(rtb_Add1_or, &LKAS_DW.In_j);

        /* End of Outputs for SubSystem: '<S201>/if action ' */
      }

      /* End of If: '<S201>/If' */

      /* Sum: '<S188>/Add' incorporates:
       *  Constant: '<S188>/Constant'
       *  Memory: '<S188>/Memory1'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_i));

      /* Saturate: '<S188>/Saturation1' */
      if (rtb_IMAPve_d_BCM_HazardLamp < ((uint8)5U)) {
        rtb_Saturation1_l = rtb_IMAPve_d_BCM_HazardLamp;
      } else {
        rtb_Saturation1_l = ((uint8)5U);
      }

      /* End of Saturate: '<S188>/Saturation1' */

      /* Saturate: '<S184>/Saturation3' */
      if (rtb_ESC_VehSpd > 150.0F) {
        rtb_Divide3_j = 150.0F;
      } else if (rtb_ESC_VehSpd < 60.0F) {
        rtb_Divide3_j = 60.0F;
      } else {
        rtb_Divide3_j = rtb_ESC_VehSpd;
      }

      /* End of Saturate: '<S184>/Saturation3' */

      /* Product: '<S184>/Divide1' incorporates:
       *  Constant: '<S184>/Constant'
       */
      rtb_Divide3_j = 0.09F / rtb_Divide3_j;

      /* Saturate: '<S184>/Saturation1' */
      if (rtb_Divide3_j > 0.0117F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.0117F;
      } else if (rtb_Divide3_j < 0.00237F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.MPInP_StbFacm_SY = rtb_Divide3_j;
      }

      /* End of Saturate: '<S184>/Saturation1' */

      /* Gain: '<S184>/Gain' */
      LKAS_DW.MPInP_dphiSWARMax = 1.0F * rtb_ThresDet_coefficient_c;

      /* Sum: '<S200>/Add' incorporates:
       *  Constant: '<S200>/Constant'
       *  Memory: '<S200>/Memory'
       */
      rtb_Saturation_fq = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_cy));

      /* Saturate: '<S200>/Saturation1' */
      if (rtb_Saturation_fq < ((uint16)10000U)) {
        rtb_Saturation1_g = rtb_Saturation_fq;
      } else {
        rtb_Saturation1_g = ((uint16)10000U);
      }

      /* End of Saturate: '<S200>/Saturation1' */

      /* If: '<S191>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S191>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S205>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_LFTTTLC, &rtb_Merge_l);

        /* End of Outputs for SubSystem: '<S191>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S191>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S204>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_RGTTTLC, &rtb_Merge_l);

        /* End of Outputs for SubSystem: '<S191>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S191>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S206>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_l);

        /* End of Outputs for SubSystem: '<S191>/If Action Subsystem3' */
      }

      /* End of If: '<S191>/If' */

      /* If: '<S200>/If' incorporates:
       *  Constant: '<S200>/Constant2'
       */
      if (rtb_Saturation1_g == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S200>/if action ' incorporates:
         *  ActionPort: '<S223>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_l, &LKAS_DW.In_i);

        /* End of Outputs for SubSystem: '<S200>/if action ' */
      }

      /* End of If: '<S200>/If' */

      /* Saturate: '<S184>/Saturation2' */
      if (LKAS_DW.In_i > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_i < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_i;
      }

      /* End of Saturate: '<S184>/Saturation2' */

      /* Sum: '<S202>/Add' incorporates:
       *  Constant: '<S202>/Constant'
       *  Memory: '<S202>/Memory'
       */
      rtb_Saturation_fq = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_po));

      /* Saturate: '<S202>/Saturation1' */
      if (rtb_Saturation_fq < ((uint16)10000U)) {
        rtb_Saturation1_p2 = rtb_Saturation_fq;
      } else {
        rtb_Saturation1_p2 = ((uint16)10000U);
      }

      /* End of Saturate: '<S202>/Saturation1' */

      /* If: '<S202>/If' incorporates:
       *  Constant: '<S202>/Constant2'
       */
      if (rtb_Saturation1_p2 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S202>/if action ' incorporates:
         *  ActionPort: '<S225>/Action Port'
         */
        LKAS_ifaction(rtb_ESC_VehSpd, &LKAS_DW.In_c);

        /* End of Outputs for SubSystem: '<S202>/if action ' */
      }

      /* End of If: '<S202>/If' */

      /* Sum: '<S197>/Add' incorporates:
       *  Constant: '<S197>/Constant'
       *  Memory: '<S197>/Memory'
       */
      rtb_Saturation_fq = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_js));

      /* Saturate: '<S197>/Saturation1' */
      if (rtb_Saturation_fq < ((uint16)10000U)) {
        rtb_Saturation1_m = rtb_Saturation_fq;
      } else {
        rtb_Saturation1_m = ((uint16)10000U);
      }

      /* End of Saturate: '<S197>/Saturation1' */

      /* Product: '<S315>/Z*Z' incorporates:
       *  Product: '<S312>/Z*Z'
       */
      rtb_LL_ThresDet_tiTTLCThresLDW = rtb_Divide_d1 * rtb_Divide_d1;

      /* Gain: '<S315>/Gain1' incorporates:
       *  Gain: '<S314>/Gain1'
       *  Gain: '<S316>/Gain1'
       */
      rtb_LL_CompHdAg_C *= 3.0F;

      /* Gain: '<S312>/Gain1' incorporates:
       *  Gain: '<S311>/Gain1'
       *  Gain: '<S313>/Gain1'
       */
      rtb_L0_C3 *= 3.0F;

      /* Gain: '<S192>/Gain' incorporates:
       *  Gain: '<S312>/Gain1'
       *  Gain: '<S315>/Gain1'
       *  Product: '<S312>/Product3'
       *  Product: '<S312>/Product4'
       *  Product: '<S315>/Product3'
       *  Product: '<S315>/Product4'
       *  Product: '<S315>/Z*Z'
       *  Sum: '<S192>/Add'
       *  Sum: '<S312>/Add'
       *  Sum: '<S315>/Add'
       */
      rtb_Gain_gy = ((((rtb_Add_o_tmp * rtb_Divide_d1) + rtb_L0_C1_j) +
                      (rtb_LL_CompHdAg_C * rtb_LL_ThresDet_tiTTLCThresLDW)) +
                     (((rtb_Add_a_tmp * rtb_Divide_d1) + rtb_L0_C1_d) +
                      (rtb_L0_C3 * rtb_LL_ThresDet_tiTTLCThresLDW))) * 0.5F;

      /* Product: '<S316>/Z*Z' incorporates:
       *  Product: '<S313>/Z*Z'
       */
      rtb_LL_ThresDet_tiTTLCThresLDW = rtb_Divide_n * rtb_Divide_n;

      /* Gain: '<S192>/Gain1' incorporates:
       *  Product: '<S313>/Product3'
       *  Product: '<S313>/Product4'
       *  Product: '<S316>/Product3'
       *  Product: '<S316>/Product4'
       *  Product: '<S316>/Z*Z'
       *  Sum: '<S192>/Add1'
       *  Sum: '<S313>/Add'
       *  Sum: '<S316>/Add'
       */
      rtb_Gain1_e = ((((rtb_Add_o_tmp * rtb_Divide_n) + rtb_L0_C1_j) +
                      (rtb_LL_CompHdAg_C * rtb_LL_ThresDet_tiTTLCThresLDW)) +
                     (((rtb_Add_a_tmp * rtb_Divide_n) + rtb_L0_C1_d) +
                      (rtb_L0_C3 * rtb_LL_ThresDet_tiTTLCThresLDW))) * 0.5F;

      /* If: '<S192>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S192>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S208>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_Gain_gy, &rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S192>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S207>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_Gain1_e, &rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S192>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S209>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem3' */
      }

      /* End of If: '<S192>/If' */

      /* If: '<S194>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S194>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S214>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_Divide_d1, &rtb_Gain2_l);

        /* End of Outputs for SubSystem: '<S194>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S194>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S213>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_Divide_n, &rtb_Gain2_l);

        /* End of Outputs for SubSystem: '<S194>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S194>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S215>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Gain2_l);

        /* End of Outputs for SubSystem: '<S194>/If Action Subsystem3' */
      }

      /* End of If: '<S194>/If' */

      /* Sum: '<S184>/Add' incorporates:
       *  Gain: '<S291>/Gain1'
       *  Product: '<S184>/Divide2'
       */
      rtb_Add_jl = rtb_Divide3_j - (rtb_LL_LDW_LatestWarnLine_C * rtb_Gain2_l);

      /* If: '<S197>/If' incorporates:
       *  Constant: '<S197>/Constant2'
       */
      if (rtb_Saturation1_m == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S197>/if action ' incorporates:
         *  ActionPort: '<S220>/Action Port'
         */
        LKAS_ifaction(rtb_Add_jl, &LKAS_DW.In_a);

        /* End of Outputs for SubSystem: '<S197>/if action ' */
      }

      /* End of If: '<S197>/If' */

      /* If: '<S203>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S203>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S227>/Action Port'
         */
        /* SignalConversion: '<S227>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S227>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S203>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S203>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S226>/Action Port'
         */
        /* SignalConversion: '<S226>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S226>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S203>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S203>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S228>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S203>/If Action Subsystem3' */
      }

      /* End of If: '<S203>/If' */

      /* If: '<S188>/If' incorporates:
       *  Constant: '<S188>/Constant19'
       */
      rtAction = -1;
      if (rtb_Saturation1_l == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        /* Outputs for IfAction SubSystem: '<S152>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S183>/Action Port'
         *
         * Block description for '<S152>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S152>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S188>/If' */

      /* Memory: '<S185>/Memory' */
      rtb_Gain2_l = LKAS_DW.Memory_PreviousInput_lw;

      /* Sum: '<S185>/Add' incorporates:
       *  Gain: '<S185>/Gain1'
       *  Product: '<S185>/Divide'
       *  Product: '<S185>/Product'
       */
      rtb_Add_ni = ((rtb_Abs_p_tmp * rtb_LKA_SampleTime) / (0.277777791F *
        LKAS_DW.In_c)) + rtb_Gain2_l;

      /* MATLAB Function: '<S186>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S229>:1' */
      /* '<S229>:1:19' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S229>:1:20' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S229>:1:21' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S229>:1:22' Delte2PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S229>:1:23' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S229>:1:24' NomT = SWACmd_tiNomT; */
      /* '<S229>:1:25' T1 = K1K2Det_T1; */
      /* '<S229>:1:26' T2 = T1; */
      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S229>:1:34' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_ni < LKAS_DW.K1K2Det_T1) && (rtb_Add_ni >= 0.0F)) {
        /* '<S229>:1:35' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_ni) +
          LKAS_DW.In_j;
      } else if ((rtb_Add_ni <= LKAS_DW.K1K2Det_T1) && (rtb_Add_ni >=
                  LKAS_DW.K1K2Det_T1)) {
        /* '<S229>:1:36' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S229>:1:38' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
          LKAS_DW.K1K2Det_T1) + LKAS_DW.In_j;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_ni >= LKAS_DW.K1K2Det_T1) {
          /* '<S229>:1:40' elseif(NomT >= T2) */
          /* '<S229>:1:41' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
            LKAS_DW.K1K2Det_T1) + LKAS_DW.In_j;

          /*    DelteSWCmd = single(0); */
        }
      }

      /* Saturate: '<S152>/Saturation6' incorporates:
       *  MATLAB Function: '<S186>/SWACmd'
       */
      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S229>:1:47' SWACmd_phiSWACmd = DelteSWCmd; */
      if (LKAS_DW.K1K2Det_T1 > 2.0F) {
        rtb_Saturation6 = 2.0F;
      } else if (LKAS_DW.K1K2Det_T1 < 0.2F) {
        rtb_Saturation6 = 0.2F;
      } else {
        rtb_Saturation6 = LKAS_DW.K1K2Det_T1;
      }

      /* End of Saturate: '<S152>/Saturation6' */

      /* Memory: '<S171>/Memory' */
      rtb_Gain2_l = LKAS_DW.Memory_PreviousInput_a;

      /* Sum: '<S171>/Add2' */
      rtb_Gain2_l += rtb_LKA_SampleTime;

      /* Saturate: '<S171>/Saturation2' */
      if (rtb_Gain2_l > 12.0F) {
        rtb_Saturation2_h = 12.0F;
      } else if (rtb_Gain2_l < 0.0F) {
        rtb_Saturation2_h = 0.0F;
      } else {
        rtb_Saturation2_h = rtb_Gain2_l;
      }

      /* End of Saturate: '<S171>/Saturation2' */

      /* Abs: '<S171>/Abs2' */
      rtb_Gain2_l = fabsf(rtb_Gain1);

      /* Sum: '<S171>/Add3' incorporates:
       *  Sum: '<S172>/Add'
       *  Sum: '<S231>/Add'
       *  Sum: '<S252>/Add6'
       */
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Gain: '<S171>/Gain' incorporates:
       *  Sum: '<S171>/Add3'
       */
      rtb_Divide3_j = rtb_LL_ThresDet_lDvtThresUprLKA * 0.166666672F;

      /* RelationalOperator: '<S171>/Relational Operator2' */
      rtb_LogicalOperator3_pm = (rtb_Gain2_l >= rtb_Divide3_j);

      /* Abs: '<S171>/Abs3' */
      rtb_Gain2_l = fabsf(rtb_Add5_i);

      /* Outputs for Enabled SubSystem: '<S171>/Sum Condition1' incorporates:
       *  EnablePort: '<S173>/Enable'
       */
      /* Logic: '<S171>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S171>/Relational Operator3'
       *  RelationalOperator: '<S171>/Relational Operator4'
       */
      if (((rtb_Saturation2_h >= rtb_Saturation6) && rtb_LogicalOperator3_pm) &&
          (rtb_Gain2_l >= rtb_Divide3_j)) {
        if (!LKAS_DW.SumCondition1_MODE_a) {
          /* InitializeConditions for Memory: '<S173>/Memory' */
          LKAS_DW.Memory_PreviousInput_hp = 0.0F;
          LKAS_DW.SumCondition1_MODE_a = true;
        }

        /* Sum: '<S173>/Add1' incorporates:
         *  Memory: '<S173>/Memory'
         */
        rtb_LL_ThresDet_tiTTLCThresLDW = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_hp;

        /* Saturate: '<S173>/Saturation' */
        if (rtb_LL_ThresDet_tiTTLCThresLDW > 10.0F) {
          rtb_LL_ThresDet_tiTTLCThresLDW = 10.0F;
        } else {
          if (rtb_LL_ThresDet_tiTTLCThresLDW < 0.0F) {
            rtb_LL_ThresDet_tiTTLCThresLDW = 0.0F;
          }
        }

        /* End of Saturate: '<S173>/Saturation' */

        /* RelationalOperator: '<S173>/Relational Operator' incorporates:
         *  Sum: '<S171>/Add1'
         */
        LKAS_DW.RelationalOperator_k1 = (rtb_LL_ThresDet_tiTTLCThresLDW >=
          (rtb_LL_LKAExPrcs_tiExitTime2 + rtb_LL_ThresDet_lDvtThresLwrLDW));

        /* Update for Memory: '<S173>/Memory' */
        LKAS_DW.Memory_PreviousInput_hp = rtb_LL_ThresDet_tiTTLCThresLDW;
      } else {
        if (LKAS_DW.SumCondition1_MODE_a) {
          /* Disable for Outport: '<S173>/Out' */
          LKAS_DW.RelationalOperator_k1 = false;
          LKAS_DW.SumCondition1_MODE_a = false;
        }
      }

      /* End of Logic: '<S171>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S171>/Sum Condition1' */

      /* Memory: '<S172>/Memory' */
      rtb_Gain2_l = LKAS_DW.Memory_PreviousInput_h;

      /* Sum: '<S172>/Add2' */
      rtb_Gain2_l += rtb_LKA_SampleTime;

      /* Saturate: '<S172>/Saturation2' */
      if (rtb_Gain2_l > 10.0F) {
        rtb_Saturation2_g = 10.0F;
      } else if (rtb_Gain2_l < 0.0F) {
        rtb_Saturation2_g = 0.0F;
      } else {
        rtb_Saturation2_g = rtb_Gain2_l;
      }

      /* End of Saturate: '<S172>/Saturation2' */

      /* Gain: '<S172>/Gain' */
      rtb_Gain2_l = rtb_LL_ThresDet_lDvtThresUprLKA * 0.333333343F;

      /* Logic: '<S172>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S172>/Relational Operator2'
       *  RelationalOperator: '<S172>/Relational Operator3'
       *  RelationalOperator: '<S172>/Relational Operator4'
       */
      rtb_LogicalOperator3_pm = (((rtb_Saturation2_g >= rtb_Saturation6) &&
        (rtb_Gain1 >= rtb_Gain2_l)) && (rtb_Add5_i >= rtb_Gain2_l));

      /* Abs: '<S172>/Abs4' */
      rtb_Gain2_l = rtb_TTLC_l;

      /* Saturate: '<S172>/Saturation' */
      if (rtb_Gain2_l > 0.004F) {
        rtb_Gain2_l = 0.004F;
      } else {
        if (rtb_Gain2_l < 0.0F) {
          rtb_Gain2_l = 0.0F;
        }
      }

      /* End of Saturate: '<S172>/Saturation' */

      /* Switch: '<S658>/Switch45' incorporates:
       *  Constant: '<S658>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S658>/Switch45' */

      /* Sum: '<S172>/Add6' incorporates:
       *  Constant: '<S172>/Constant'
       *  Constant: '<S172>/Constant7'
       *  Product: '<S172>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Gain2_l) / 0.004F) + x10;

      /* Outputs for Atomic SubSystem: '<S158>/Moving Standard Deviation2' */
      LKAS_MovingStandardDeviation2(rtb_IMAPve_g_EPS_SW_Trq, &rtb_kphTomps_a,
        &rtb_Merge_h, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S158>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S172>/Moving Standard Deviation1' */
      rtb_Gain_b = (float32) LKAS_MovingStandardDeviation1(rtb_Add5_i,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S172>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S172>/Relational Operator6' */
      rtb_RelationalOperator6_i = (rtb_Gain_b <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S172>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_i, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_kc, &LKAS_DW.SumCondition1_o);

      /* End of Outputs for SubSystem: '<S172>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S172>/Moving Standard Deviation2' */
      rtb_Gain_b = (float32) LKAS_MovingStandardDeviation1(rtb_Gain1,
        &LKAS_DW.MovingStandardDeviation2_j);

      /* End of Outputs for SubSystem: '<S172>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S172>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain_b <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S172>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_h, &LKAS_DW.SumCondition_pu);

      /* End of Outputs for SubSystem: '<S172>/Sum Condition' */

      /* RelationalOperator: '<S182>/Compare' incorporates:
       *  Constant: '<S182>/Constant'
       *  Constant: '<S658>/LL_LKAExPrcs_ExitC0Swt=1'
       *  Logic: '<S172>/Logical Operator2'
       *  Switch: '<S658>/Switch46'
       */
      rtb_Compare_gm = (((sint32)((((rtb_LogicalOperator3_pm &&
        (LKAS_DW.RelationalOperator_kc)) && (LKAS_DW.RelationalOperator_h)) &&
        ((LKAS_ConstB.DataTypeConversion35) || (LL_LKAExPrcs_ExitC0Swt))) ? 1 :
        0)) > ((sint32)(false ? 1 : 0)));

      /* Memory: '<S172>/Memory1' */
      rtb_Memory1_n = LKAS_DW.Memory1_PreviousInput_e;

      /* If: '<S172>/If' incorporates:
       *  Constant: '<S175>/Constant'
       *  RelationalOperator: '<S174>/FixPt Relational Operator'
       *  UnitDelay: '<S174>/Delay Input1'
       *
       * Block description for '<S174>/Delay Input1':
       *
       *  Store in Global RAM
       */
      if (((sint32)(rtb_Compare_gm ? 1 : 0)) > ((sint32)
           (LKAS_DW.DelayInput1_DSTATE_c ? 1 : 0))) {
        /* Outputs for IfAction SubSystem: '<S172>/If Action Subsystem' incorporates:
         *  ActionPort: '<S175>/Action Port'
         */
        rtb_Merge_n = true;

        /* End of Outputs for SubSystem: '<S172>/If Action Subsystem' */
      } else {
        /* Outputs for IfAction SubSystem: '<S172>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S176>/Action Port'
         */
        LKAS_IfActionSubsystem3(rtb_Memory1_n, &rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S172>/If Action Subsystem3' */
      }

      /* End of If: '<S172>/If' */

      /* Outputs for Enabled SubSystem: '<S158>/Sum Condition2' incorporates:
       *  EnablePort: '<S162>/state = reset'
       */
      /* Outputs for Enabled SubSystem: '<S172>/Sum Condition2' incorporates:
       *  EnablePort: '<S181>/state = reset'
       */
      if (rtb_Merge_n) {
        if (!LKAS_DW.SumCondition2_MODE) {
          /* InitializeConditions for Memory: '<S181>/Memory' */
          LKAS_DW.Memory_PreviousInput_jg = 0.0F;
          LKAS_DW.SumCondition2_MODE = true;
        }

        /* Sum: '<S181>/Add1' incorporates:
         *  Memory: '<S181>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_jg;

        /* Saturate: '<S181>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S181>/Saturation' */

        /* RelationalOperator: '<S181>/Relational Operator' */
        LKAS_DW.RelationalOperator_m = (rtb_LL_LKAExPrcs_tiExitTime2 >=
          rtb_LL_LKAExPrcs_tiExitDelayTim);

        /* Update for Memory: '<S181>/Memory' */
        LKAS_DW.Memory_PreviousInput_jg = rtb_LL_LKAExPrcs_tiExitTime2;
        if (!LKAS_DW.SumCondition2_MODE_m) {
          /* InitializeConditions for Memory: '<S162>/Memory' */
          LKAS_DW.Memory_PreviousInput_gm = 0.0F;
          LKAS_DW.SumCondition2_MODE_m = true;
        }

        /* Sum: '<S162>/Add1' incorporates:
         *  Memory: '<S162>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_gm;

        /* Saturate: '<S162>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S162>/Saturation' */

        /* Product: '<S162>/Divide' */
        rtb_LftTTLC = rtb_LL_LKAExPrcs_tiExitTime2 /
          rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Switch: '<S658>/Switch28' incorporates:
         *  Constant: '<S658>/LL_LKASWASyn_M4K=0.1'
         */
        if (LKAS_ConstB.DataTypeConversion42 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion42;
        } else {
          x10 = LL_LKASWASyn_M4K;
        }

        /* End of Switch: '<S658>/Switch28' */

        /* Sum: '<S162>/Add2' incorporates:
         *  Constant: '<S162>/Constant1'
         */
        rtb_LL_LKAExPrcs_ExitC0Dvt = x10 - 1.0F;

        /* Saturate: '<S162>/Saturation1' */
        if (rtb_LftTTLC > 1.0F) {
          rtb_LftTTLC = 1.0F;
        } else {
          if (rtb_LftTTLC < 0.0F) {
            rtb_LftTTLC = 0.0F;
          }
        }

        /* End of Saturate: '<S162>/Saturation1' */

        /* Saturate: '<S162>/Saturation2' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 0.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < (-1.0F)) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = (-1.0F);
          }
        }

        /* End of Saturate: '<S162>/Saturation2' */

        /* Sum: '<S162>/Add3' incorporates:
         *  Constant: '<S162>/Constant2'
         *  Product: '<S162>/Divide1'
         */
        rtb_LftTTLC = (rtb_LftTTLC * rtb_LL_LKAExPrcs_ExitC0Dvt) + 1.0F;

        /* Saturate: '<S162>/Saturation3' */
        if (rtb_LftTTLC > 1.0F) {
          LKAS_DW.Saturation3 = 1.0F;
        } else if (rtb_LftTTLC < 0.0F) {
          LKAS_DW.Saturation3 = 0.0F;
        } else {
          LKAS_DW.Saturation3 = rtb_LftTTLC;
        }

        /* End of Saturate: '<S162>/Saturation3' */

        /* Update for Memory: '<S162>/Memory' */
        LKAS_DW.Memory_PreviousInput_gm = rtb_LL_LKAExPrcs_tiExitTime2;
      } else {
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S181>/Out' */
          LKAS_DW.RelationalOperator_m = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        if (LKAS_DW.SumCondition2_MODE_m) {
          /* Disable for Outport: '<S162>/M4K' */
          LKAS_DW.Saturation3 = 1.0F;
          LKAS_DW.SumCondition2_MODE_m = false;
        }
      }

      /* End of Outputs for SubSystem: '<S172>/Sum Condition2' */
      /* End of Outputs for SubSystem: '<S158>/Sum Condition2' */

      /* Fcn: '<S151>/Fcn' incorporates:
       *  DataTypeConversion: '<S151>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((LKAS_DW.RelationalOperator_m ? 1 : 0) *
        (LKAS_DW.RelationalOperator_m ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!LKAS_DW.RelationalOperator_m) ? 1 : 0)) *
        (LKAS_DW.RelationalOperator_k1 ? 1 : 0)) * ((sint32)2.0F))) + (((sint32)
        (((!LKAS_DW.RelationalOperator_k1) && (!LKAS_DW.RelationalOperator_m)) ?
         1 : 0)) * (rtb_BCM_Right_Light ? 1 : 0))));

      /* Logic: '<S151>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_BCM_Right_Light ||
        (LKAS_DW.RelationalOperator_k1)) || (LKAS_DW.RelationalOperator_m));

      /* DataTypeConversion: '<S154>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Sum: '<S158>/Add' */
      rtb_Gain2_l = rtb_IMAPve_g_EPS_SW_Trq - rtb_kphTomps_a;

      /* Saturate: '<S158>/Saturation4' */
      if (rtb_Gain2_l > 2.0F) {
        rtb_Gain2_l = 2.0F;
      } else {
        if (rtb_Gain2_l < 0.0F) {
          rtb_Gain2_l = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation4' */

      /* Abs: '<S158>/Abs' */
      rtb_Gain2_l = fabsf(rtb_Gain2_l);

      /* Saturate: '<S158>/Saturation7' */
      if (rtb_Gain2_l > 1.0F) {
        rtb_Gain2_l = 1.0F;
      } else {
        if (rtb_Gain2_l < 0.0F) {
          rtb_Gain2_l = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation7' */

      /* Switch: '<S658>/Switch26' incorporates:
       *  Constant: '<S658>/LL_LKASWASyn_M3D=0.5'
       */
      if (LKAS_ConstB.DataTypeConversion40 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion40;
      } else {
        x10 = LL_LKASWASyn_M3D;
      }

      /* End of Switch: '<S658>/Switch26' */

      /* Product: '<S158>/Divide2' */
      rtb_Gain2_l /= x10;

      /* Saturate: '<S158>/Saturation5' */
      if (rtb_Gain2_l > 1.0F) {
        rtb_Gain2_l = 1.0F;
      } else {
        if (rtb_Gain2_l < 0.0F) {
          rtb_Gain2_l = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation5' */

      /* Switch: '<S658>/Switch18' incorporates:
       *  Constant: '<S658>/LL_LKASWASyn_M3K_DT=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion25;
      } else {
        x10 = LL_LKASWASyn_M3K_DT;
      }

      /* End of Switch: '<S658>/Switch18' */

      /* Product: '<S158>/Divide1' */
      rtb_Gain2_l *= x10;

      /* Saturate: '<S158>/Saturation3' */
      if (rtb_Gain2_l > 0.4F) {
        rtb_Gain2_l = 0.4F;
      } else {
        if (rtb_Gain2_l < 0.0F) {
          rtb_Gain2_l = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation3' */

      /* Switch: '<S658>/Switch27' incorporates:
       *  Constant: '<S658>/LL_LKASWASyn_M3K_MSD=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion41 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion41;
      } else {
        x10 = LL_LKASWASyn_M3K_MSD;
      }

      /* End of Switch: '<S658>/Switch27' */

      /* Product: '<S158>/Divide' */
      rtb_Divide3_j = rtb_Merge_h * x10;

      /* Saturate: '<S158>/Saturation1' */
      if (rtb_Divide3_j > 0.4F) {
        rtb_Divide3_j = 0.4F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S158>/Saturation1' */

      /* Sum: '<S163>/Add2' incorporates:
       *  Memory: '<S163>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_i;

      /* Saturate: '<S163>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_n = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_n = 0.0F;
      } else {
        rtb_Saturation_n = rtb_LftTTLC;
      }

      /* End of Saturate: '<S163>/Saturation' */

      /* MATLAB Function: '<S158>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Driver Torque Assist/MATLAB Function': '<S160>:1' */
      /* '<S160>:1:2' if T<T1 */
      if (rtb_Saturation_n < rtb_Saturation6) {
        /* '<S160>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_LL_LKASWASyn_M0 += ((rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6) * rtb_Saturation_n;
      } else if ((rtb_Saturation_n >= rtb_Saturation6) && (rtb_Saturation_n <=
                  (rtb_Saturation6 + rtb_Saturation6))) {
        /* Switch: '<S658>/Switch14' incorporates:
         *  Constant: '<S658>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S160>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S160>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_o != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_o;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (((x10 - rtb_LL_LKASWASyn_M1) / rtb_Saturation6) *
          (rtb_Saturation_n - rtb_Saturation6)) + rtb_LL_LKASWASyn_M1;
      } else {
        /* Switch: '<S658>/Switch14' incorporates:
         *  Constant: '<S658>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S160>:1:6' else */
        /* '<S160>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_o != 0.0F) {
          rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20_o;
        } else {
          rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S158>/MATLAB Function' */

      /* Sum: '<S158>/Add1' */
      rtb_Gain2_l = (rtb_LL_LKASWASyn_M0 - rtb_Gain2_l) - rtb_Divide3_j;

      /* Saturate: '<S158>/Saturation6' */
      if (rtb_Gain2_l > 1.0F) {
        rtb_Gain2_l = 1.0F;
      } else {
        if (rtb_Gain2_l < 0.01F) {
          rtb_Gain2_l = 0.01F;
        }
      }

      /* End of Saturate: '<S158>/Saturation6' */

      /* Product: '<S158>/Divide5' */
      rtb_Gain2_l *= LKAS_DW.Saturation3;

      /* Saturate: '<S158>/Saturation2' */
      if (rtb_Gain2_l > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Gain2_l < 0.01F) {
        LKAS_DW.Saturation2 = 0.01F;
      } else {
        LKAS_DW.Saturation2 = rtb_Gain2_l;
      }

      /* End of Saturate: '<S158>/Saturation2' */

      /* Outputs for Enabled SubSystem: '<S150>/Subsystem' incorporates:
       *  EnablePort: '<S159>/Enable'
       */
      /* RelationalOperator: '<S157>/Compare' incorporates:
       *  Constant: '<S157>/Constant'
       *  Constant: '<S658>/LL_LKASWASyn_TrqSwaAddSwt=1'
       *  Switch: '<S658>/Switch47'
       */
      if (((sint32)(((LKAS_ConstB.DataTypeConversion47_h) ||
                     (LL_LKASWASyn_TrqSwaAddSwt)) ? 1 : 0)) > ((sint32)(false ?
            1 : 0))) {
        if (!LKAS_DW.Subsystem_MODE_l) {
          LKAS_DW.Subsystem_MODE_l = true;
        }

        /* MATLAB Function: '<S159>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S164>:1' */
        /* '<S164>:1:2' Swaadd=single(0); */
        /* '<S164>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S164>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S164>:1:5' l0c0=abs(l0c0); */
        /* '<S164>:1:6' r0c0=abs(r0c0); */
        /* '<S164>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_LL_LKASWASyn_M1 = fmaxf(fminf(rtb_LKA_Veh2CamW_C + rtb_Add5_i_tmp,
          5.4F), 2.5F);

        /* '<S164>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_LL_LKASWASyn_M1 > 2.5F) && (rtb_LL_LKASWASyn_M1 < 5.4F)) {
          /* '<S164>:1:9' leftlane=l0c0/lanewidth; */
          rtb_LL_LKAExPrcs_tiExitDelayTim = rtb_LKA_Veh2CamW_C /
            rtb_LL_LKASWASyn_M1;

          /* '<S164>:1:10' rightlane=r0c0/lanewidth; */
          rtb_LL_LKASWASyn_M0 = rtb_Add5_i_tmp / rtb_LL_LKASWASyn_M1;
        } else {
          /* '<S164>:1:11' else */
          /* '<S164>:1:12' leftlane=single(0.5); */
          rtb_LL_LKAExPrcs_tiExitDelayTim = 0.5F;

          /* '<S164>:1:13' rightlane=single(0.5); */
          rtb_LL_LKASWASyn_M0 = 0.5F;
        }

        /* '<S164>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S164>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S164>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S658>/Switch42' incorporates:
           *  Constant: '<S658>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S164>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S658>/Switch43' incorporates:
           *  Constant: '<S658>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M0 = (((((180.0F - fmaxf(fminf(rtb_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_LL_LKAExPrcs_tiExitDelayTim) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S658>/Switch42' incorporates:
           *  Constant: '<S658>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S164>:1:19' else */
          /* '<S164>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S658>/Switch43' incorporates:
           *  Constant: '<S658>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M0 = (((((180.0F - fmaxf(fminf(rtb_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_LL_LKASWASyn_M0) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S165>/Add2' incorporates:
         *  Constant: '<S165>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S165>/Memory3'
         */
        rtb_LL_LKASWASyn_M1 = 1.0F + LKAS_DW.Memory3_PreviousInput_o;

        /* Saturate: '<S165>/Saturation' */
        if (rtb_LL_LKASWASyn_M1 > 50.0F) {
          rtb_LL_LKASWASyn_M1 = 50.0F;
        } else {
          if (rtb_LL_LKASWASyn_M1 < 0.0F) {
            rtb_LL_LKASWASyn_M1 = 0.0F;
          }
        }

        /* End of Saturate: '<S165>/Saturation' */

        /* Switch: '<S165>/Switch' incorporates:
         *  Product: '<S165>/Divide'
         *  Product: '<S165>/Divide1'
         *  Sum: '<S165>/Add'
         *  Sum: '<S165>/Add1'
         *  UnitDelay: '<S165>/Unit Delay'
         */
        if (rtb_LL_LKASWASyn_M1 > 1.0F) {
          /* Switch: '<S658>/Switch50' incorporates:
           *  Constant: '<S658>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S658>/Switch50' */
          rtb_LL_LKASWASyn_M0 = ((rtb_LKA_SampleTime / x10) *
            (rtb_LL_LKASWASyn_M0 - LKAS_DW.UnitDelay_DSTATE_c)) +
            LKAS_DW.UnitDelay_DSTATE_c;
        }

        /* End of Switch: '<S165>/Switch' */

        /* SampleTimeMath: '<S168>/TSamp'
         *
         * About '<S168>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_LKAExPrcs_tiExitDelayTim = rtb_LL_LKASWASyn_M0 * 100.0F;

        /* Sum: '<S166>/Add2' incorporates:
         *  Constant: '<S166>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S166>/Memory3'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = 1.0F + LKAS_DW.Memory3_PreviousInput_ku;

        /* Saturate: '<S166>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 50.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 50.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S166>/Saturation' */

        /* Switch: '<S166>/Switch' incorporates:
         *  Product: '<S166>/Divide'
         *  Product: '<S166>/Divide1'
         *  Sum: '<S166>/Add'
         *  Sum: '<S166>/Add1'
         *  Sum: '<S168>/Diff'
         *  UnitDelay: '<S166>/Unit Delay'
         *  UnitDelay: '<S168>/UD'
         *
         * Block description for '<S168>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S168>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 2.0F) {
          /* Switch: '<S658>/Switch52' incorporates:
           *  Constant: '<S658>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S658>/Switch52' */
          rtb_LL_LKAExPrcs_ExitC0Dvt = (((rtb_LL_LKAExPrcs_tiExitDelayTim -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_a) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_a;
        } else {
          rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LL_LKAExPrcs_tiExitDelayTim -
            LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S166>/Switch' */

        /* Saturate: '<S159>/Saturation' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 30.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 30.0F;
        } else if (rtb_LL_LKAExPrcs_ExitC0Dvt < (-30.0F)) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = (-30.0F);
        } else {
          rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LL_LKAExPrcs_ExitC0Dvt;
        }

        /* End of Saturate: '<S159>/Saturation' */

        /* Switch: '<S658>/Switch53' incorporates:
         *  Constant: '<S658>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S658>/Switch53' */

        /* Sum: '<S167>/Difference Inputs1' incorporates:
         *  Product: '<S159>/Divide1'
         *  Product: '<S159>/Divide3'
         *  Sum: '<S159>/Add'
         *  UnitDelay: '<S167>/Delay Input2'
         *
         * Block description for '<S167>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S167>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_ThresDet_lDvtThresLwrLDW = ((rtb_LL_ThresDet_lDvtThresLwrLDW *
          x10) + rtb_LL_LKASWASyn_M0) - LKAS_DW.DelayInput2_DSTATE_e;

        /* Product: '<S167>/delta rise limit' incorporates:
         *  Constant: '<S159>/Constant1'
         *  SampleTimeMath: '<S167>/sample time'
         *
         * About '<S167>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_ThresDet_tiTTLCThresLDW = 5.0F * 0.01F;

        /* Product: '<S167>/delta fall limit' incorporates:
         *  Constant: '<S159>/Constant2'
         *  SampleTimeMath: '<S167>/sample time'
         *
         * About '<S167>/sample time':
         *  y = K where K = ( w * Ts )
         */
        x10 = (-5.0F) * 0.01F;

        /* Switch: '<S169>/Switch2' incorporates:
         *  Product: '<S167>/delta fall limit'
         *  Product: '<S167>/delta rise limit'
         *  RelationalOperator: '<S169>/LowerRelop1'
         *  RelationalOperator: '<S169>/UpperRelop'
         *  Switch: '<S169>/Switch'
         */
        if (rtb_LL_ThresDet_lDvtThresLwrLDW > rtb_LL_ThresDet_tiTTLCThresLDW) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LL_ThresDet_tiTTLCThresLDW;
        } else {
          if (rtb_LL_ThresDet_lDvtThresLwrLDW < x10) {
            /* Switch: '<S169>/Switch' incorporates:
             *  Product: '<S167>/delta fall limit'
             */
            rtb_LL_ThresDet_lDvtThresLwrLDW = x10;
          }
        }

        /* End of Switch: '<S169>/Switch2' */

        /* Sum: '<S167>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S167>/Delay Input2'
         *
         * Block description for '<S167>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S167>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_d = rtb_LL_ThresDet_lDvtThresLwrLDW +
          LKAS_DW.DelayInput2_DSTATE_e;

        /* Update for UnitDelay: '<S165>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_c = rtb_LL_LKASWASyn_M0;

        /* Update for Memory: '<S165>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_o = rtb_LL_LKASWASyn_M1;

        /* Update for UnitDelay: '<S168>/UD'
         *
         * Block description for '<S168>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Update for UnitDelay: '<S166>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_a = rtb_LL_LKAExPrcs_ExitC0Dvt;

        /* Update for Memory: '<S166>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_ku = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for UnitDelay: '<S167>/Delay Input2'
         *
         * Block description for '<S167>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_e = LKAS_DW.DifferenceInputs2_d;
      } else {
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S159>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_d = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }
      }

      /* End of RelationalOperator: '<S157>/Compare' */
      /* End of Outputs for SubSystem: '<S150>/Subsystem' */

      /* Sum: '<S264>/Add2' incorporates:
       *  Memory: '<S264>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_j;

      /* Saturate: '<S264>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_gk = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_gk = 0.0F;
      } else {
        rtb_Saturation_gk = rtb_LftTTLC;
      }

      /* End of Saturate: '<S264>/Saturation' */

      /* If: '<S262>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       *  Inport: '<S270>/Plan'
       *  Inport: '<S270>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_n;
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_n = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S262>/If Action Subsystem' incorporates:
           *  ActionPort: '<S268>/Action Port'
           */
          /* InitializeConditions for If: '<S262>/If' incorporates:
           *  Memory: '<S268>/Memory'
           *  UnitDelay: '<S272>/Delay Input1'
           *
           * Block description for '<S272>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_j = false;
          LKAS_DW.Memory_PreviousInput_f = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S262>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S262>/If Action Subsystem' incorporates:
         *  ActionPort: '<S268>/Action Port'
         */
        /* RelationalOperator: '<S271>/Compare' incorporates:
         *  Constant: '<S271>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Lft >= 0.0F);

        /* Memory: '<S268>/Memory' */
        rtb_Plan_g = LKAS_DW.Memory_PreviousInput_f;

        /* Sum: '<S268>/Add' incorporates:
         *  Logic: '<S268>/Logical Operator'
         *  RelationalOperator: '<S268>/Relational Operator'
         *  RelationalOperator: '<S272>/FixPt Relational Operator'
         *  UnitDelay: '<S272>/Delay Input1'
         *
         * Block description for '<S272>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_f = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_j ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_gk)) ? 1 : 0)) + rtb_Plan_g;

        /* Saturate: '<S268>/Saturation' */
        if (rtb_T1_f > 5.0F) {
          rtb_Saturation_jw = 5.0F;
        } else if (rtb_T1_f < 0.0F) {
          rtb_Saturation_jw = 0.0F;
        } else {
          rtb_Saturation_jw = rtb_T1_f;
        }

        /* End of Saturate: '<S268>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S268>/If Action Subsystem' */
        LKAS_IfActionSubsystem_dv(rtb_Saturation_jw, rtb_Saturation_gk,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_p, &LKAS_DW.In_fb,
          &LKAS_DW.IfActionSubsystem_dv);

        /* End of Outputs for SubSystem: '<S268>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S268>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_g(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_f, &rtb_Plan_g);

        /* End of Outputs for SubSystem: '<S268>/If Action Subsystem2' */

        /* Switch: '<S268>/Switch' incorporates:
         *  Switch: '<S268>/Switch1'
         */
        if (rtb_Saturation_jw > 0.0F) {
          LKAS_DW.Merge_n = LKAS_DW.In_p;
          LKAS_DW.Merge1 = LKAS_DW.In_fb;
        } else {
          LKAS_DW.Merge_n = rtb_T1_f;
          LKAS_DW.Merge1 = rtb_Plan_g;
        }

        /* End of Switch: '<S268>/Switch' */

        /* Update for UnitDelay: '<S272>/Delay Input1'
         *
         * Block description for '<S272>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_j = rtb_BCM_Right_Light;

        /* Update for Memory: '<S268>/Memory' */
        LKAS_DW.Memory_PreviousInput_f = rtb_Saturation_jw;

        /* End of Outputs for SubSystem: '<S262>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S262>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S269>/Action Port'
           */
          /* InitializeConditions for If: '<S262>/If' incorporates:
           *  Memory: '<S269>/Memory'
           *  UnitDelay: '<S280>/Delay Input1'
           *
           * Block description for '<S280>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_h = false;
          LKAS_DW.Memory_PreviousInput_lh = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S262>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S262>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S269>/Action Port'
         */
        /* RelationalOperator: '<S279>/Compare' incorporates:
         *  Constant: '<S279>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Rgt <= 0.0F);

        /* Memory: '<S269>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_lh;

        /* Sum: '<S269>/Add' incorporates:
         *  Logic: '<S269>/Logical Operator'
         *  RelationalOperator: '<S269>/Relational Operator'
         *  RelationalOperator: '<S280>/FixPt Relational Operator'
         *  UnitDelay: '<S280>/Delay Input1'
         *
         * Block description for '<S280>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_k = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_h ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_gk)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S269>/Saturation' */
        if (rtb_T1_k > 5.0F) {
          rtb_Saturation_m = 5.0F;
        } else if (rtb_T1_k < 0.0F) {
          rtb_Saturation_m = 0.0F;
        } else {
          rtb_Saturation_m = rtb_T1_k;
        }

        /* End of Saturate: '<S269>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S269>/If Action Subsystem' */
        LKAS_IfActionSubsystem_dv(rtb_Saturation_m, rtb_Saturation_gk,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_f, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_gs);

        /* End of Outputs for SubSystem: '<S269>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S269>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_g(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_k, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S269>/If Action Subsystem2' */

        /* Switch: '<S269>/Switch' incorporates:
         *  Switch: '<S269>/Switch1'
         */
        if (rtb_Saturation_m > 0.0F) {
          LKAS_DW.Merge_n = LKAS_DW.In_f;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_n = rtb_T1_k;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S269>/Switch' */

        /* Update for UnitDelay: '<S280>/Delay Input1'
         *
         * Block description for '<S280>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_h = rtb_BCM_Right_Light;

        /* Update for Memory: '<S269>/Memory' */
        LKAS_DW.Memory_PreviousInput_lh = rtb_Saturation_m;

        /* End of Outputs for SubSystem: '<S262>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S262>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S270>/Action Port'
         */
        LKAS_DW.Merge_n = rtb_Saturation6;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S262>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S262>/If' */

      /* Saturate: '<S156>/Saturation6' */
      if (LKAS_DW.Merge_n > 0.5F) {
        rtb_LL_LKASWASyn_M0 = 0.5F;
      } else if (LKAS_DW.Merge_n < 0.2F) {
        rtb_LL_LKASWASyn_M0 = 0.2F;
      } else {
        rtb_LL_LKASWASyn_M0 = LKAS_DW.Merge_n;
      }

      /* End of Saturate: '<S156>/Saturation6' */

      /* Product: '<S156>/Divide' incorporates:
       *  Product: '<S156>/Divide4'
       *  Product: '<S265>/Divide'
       *  Sum: '<S156>/Add2'
       */
      rtb_LL_LKASWASyn_M0 = (rtb_Saturation_gk - LKAS_DW.Merge_n) /
        rtb_LL_LKASWASyn_M0;
      rtb_Gain2_l = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S156>/Saturation2' */
      if (rtb_Gain2_l > 1.0F) {
        rtb_Gain2_l = 1.0F;
      } else {
        if (rtb_Gain2_l < 0.0F) {
          rtb_Gain2_l = 0.0F;
        }
      }

      /* End of Saturate: '<S156>/Saturation2' */

      /* Sum: '<S156>/Add5' incorporates:
       *  Constant: '<S156>/Constant2'
       */
      rtb_LL_LKASWASyn_M1 = 1.0F - rtb_Gain2_l;

      /* Memory: '<S247>/Memory' */
      rtb_Divide3_j = LKAS_DW.Memory_PreviousInput_hq;

      /* Product: '<S314>/Z*Z' incorporates:
       *  Product: '<S311>/Z*Z'
       */
      rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LL_HdAgPrvwT_C * rtb_LL_HdAgPrvwT_C;

      /* Sum: '<S247>/Add1' incorporates:
       *  Gain: '<S293>/Gain2'
       *  Product: '<S247>/Divide'
       *  Product: '<S247>/Divide1'
       *  Product: '<S311>/Product3'
       *  Product: '<S311>/Product4'
       *  Product: '<S314>/Product3'
       *  Product: '<S314>/Product4'
       *  Product: '<S314>/Z*Z'
       *  Sum: '<S293>/Add2'
       *  Sum: '<S311>/Add'
       *  Sum: '<S314>/Add'
       */
      rtb_Add1_j = ((((((rtb_Add_o_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_j) +
                       (rtb_LL_CompHdAg_C * rtb_LL_LKAExPrcs_tiExitTime2)) +
                      (((rtb_Add_a_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_d) +
                       (rtb_L0_C3 * rtb_LL_LKAExPrcs_tiExitTime2))) * 0.5F) *
                    LKAS_ConstB.Divide2_b) + (LKAS_ConstB.Add2_p * rtb_Divide3_j);

      /* Product: '<S245>/Divide3' incorporates:
       *  Gain: '<S291>/Gain1'
       */
      rtb_Divide3_j = rtb_LL_HdAgPrvwT_C * rtb_LL_LDW_LatestWarnLine_C;

      /* Gain: '<S245>/kph to mps' */
      rtb_kphtomps_m = rtb_Abs_p_tmp;

      /* MATLAB Function: '<S245>/Saturable Gain Lut (SatGainLut)' */
      LKAS_SaturableGainLutSatGainLut(rtb_ESC_VehSpd,
        rtb_LL_LFClb_TFC_KpVehSpdLwr_C, rtb_LL_LFClb_TFC_KpVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KpV1_C, rtb_LL_LFClb_TFC_KpV2_C, &rtb_Gain_b);

      /* Switch: '<S658>/Switch32' incorporates:
       *  Constant: '<S658>/LL_LFClb_TFC_PrvwT_C=2'
       */
      if (LKAS_ConstB.DataTypeConversion15_n != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_n;
      } else {
        x10 = LL_LFClb_TFC_PrvwT_C;
      }

      /* End of Switch: '<S658>/Switch32' */

      /* Product: '<S245>/Divide1' */
      rtb_LftTTLC = x10 * rtb_kphtomps_m;

      /* Switch: '<S658>/Switch30' incorporates:
       *  Constant: '<S658>/LL_LFClb_TFC_KpKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_n != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_n;
      } else {
        x10 = LL_LFClb_TFC_KpKlat_C;
      }

      /* End of Switch: '<S658>/Switch30' */

      /* Saturate: '<S245>/Saturation' */
      if (rtb_LftTTLC > 40.0F) {
        rtb_LftTTLC = 40.0F;
      } else {
        if (rtb_LftTTLC < 5.0F) {
          rtb_LftTTLC = 5.0F;
        }
      }

      /* End of Saturate: '<S245>/Saturation' */

      /* Sum: '<S245>/Subtract2' incorporates:
       *  Sum: '<S245>/Add1'
       */
      rtb_LL_HdAgPrvwT_C = rtb_Add1_j - rtb_Divide3_j;

      /* Product: '<S245>/Product4' incorporates:
       *  Gain: '<S292>/Gain1'
       *  Product: '<S245>/Divide'
       *  Product: '<S245>/Product1'
       *  Sum: '<S245>/Subtract1'
       *  Sum: '<S245>/Subtract2'
       *  Sum: '<S292>/Add1'
       */
      rtb_L0_C1_d = (((((rtb_Add_ah + rtb_Add_g) * 0.5F) / rtb_LftTTLC) * x10) -
                     rtb_LL_HdAgPrvwT_C) * rtb_Gain_b;

      /* Switch: '<S658>/Switch19' incorporates:
       *  Constant: '<S658>/LL_LFClb_TFC_Kp_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion26_m != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion26_m;
      } else {
        x10 = LL_LFClb_TFC_Kp_C;
      }

      /* End of Switch: '<S658>/Switch19' */

      /* Product: '<S245>/Product2' */
      rtb_Merge_h = rtb_L0_C1_d * x10;

      /* Saturate: '<S245>/Saturation2' */
      if (rtb_Merge_h > 360.0F) {
        rtb_Merge_h = 360.0F;
      } else {
        if (rtb_Merge_h < (-360.0F)) {
          rtb_Merge_h = (-360.0F);
        }
      }

      /* End of Saturate: '<S245>/Saturation2' */

      /* Abs: '<S245>/Abs' incorporates:
       *  Gain: '<S291>/Gain1'
       */
      rtb_kphTomps_a = fabsf(rtb_LL_LDW_LatestWarnLine_C);

      /* Saturate: '<S245>/Saturation1' */
      if (rtb_kphTomps_a > 0.004F) {
        rtb_kphTomps_a = 0.004F;
      } else {
        if (rtb_kphTomps_a < 1.0E-5F) {
          rtb_kphTomps_a = 1.0E-5F;
        }
      }

      /* End of Saturate: '<S245>/Saturation1' */

      /* Switch: '<S658>/Switch39' incorporates:
       *  Constant: '<S658>/LL_LFClb_TFC_KiMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_KiMaxSWA_C;
      }

      /* End of Switch: '<S658>/Switch39' */

      /* Sum: '<S245>/Add3' incorporates:
       *  Constant: '<S245>/Constant3'
       *  Constant: '<S245>/Constant4'
       *  Product: '<S245>/Divide4'
       *  Sum: '<S245>/Add5'
       */
      rtb_kphTomps_a = (((x10 - 1.0F) * rtb_kphTomps_a) / 0.004F) + 1.0F;

      /* Sum: '<S253>/Add2' incorporates:
       *  Memory: '<S253>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_je;

      /* Saturate: '<S253>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_bi = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_bi = 0.0F;
      } else {
        rtb_Saturation_bi = rtb_LftTTLC;
      }

      /* End of Saturate: '<S253>/Saturation' */

      /* Switch: '<S245>/Switch2' incorporates:
       *  Product: '<S245>/Divide2'
       *  Sum: '<S245>/Add'
       *  Sum: '<S245>/Add2'
       *  Switch: '<S658>/Switch40'
       *  UnitDelay: '<S245>/Unit Delay'
       */
      if ((rtb_Saturation_bi - rtb_Saturation6) >= 0.0F) {
        /* Switch: '<S658>/Switch40' incorporates:
         *  Constant: '<S658>/LL_LFClb_TFC_Ki_C=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_k2 = (rtb_L0_C1_d * x10) + LKAS_DW.UnitDelay_DSTATE_l;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S658>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S658>/Switch40' incorporates:
           *  Constant: '<S658>/LL_LFClb_TFC_Ki_C=0.01'
           */
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_k2 = rtb_L0_C1_d * x10;
      }

      /* End of Switch: '<S245>/Switch2' */

      /* Gain: '<S245>/Gain' */
      rtb_L0_C1_d = (-1.0F) * rtb_kphTomps_a;

      /* Switch: '<S250>/Switch' incorporates:
       *  RelationalOperator: '<S250>/UpperRelop'
       */
      if (rtb_Switch2_k2 < rtb_L0_C1_d) {
        rtb_Switch_ny = rtb_L0_C1_d;
      } else {
        rtb_Switch_ny = rtb_Switch2_k2;
      }

      /* End of Switch: '<S250>/Switch' */

      /* Switch: '<S250>/Switch2' incorporates:
       *  RelationalOperator: '<S250>/LowerRelop1'
       */
      if (rtb_Switch2_k2 > rtb_kphTomps_a) {
        rtb_Switch2_pe = rtb_kphTomps_a;
      } else {
        rtb_Switch2_pe = rtb_Switch_ny;
      }

      /* End of Switch: '<S250>/Switch2' */

      /* Product: '<S156>/Divide1' incorporates:
       *  Sum: '<S156>/Add3'
       */
      rtb_L0_C1_j = (rtb_Merge_h + rtb_Switch2_pe) * rtb_Gain2_l;

      /* Switch: '<S658>/Switch49' incorporates:
       *  Constant: '<S658>/LL_LFClb_TFC_KdMaxSWA_C=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_KdMaxSWA_C;
      }

      /* End of Switch: '<S658>/Switch49' */

      /* Product: '<S245>/Divide8' incorporates:
       *  Constant: '<S245>/Constant7'
       *  Constant: '<S245>/Constant8'
       *  Sum: '<S245>/Add4'
       */
      rtb_kphTomps_a = ((180.0F - rtb_kphtomps_m) * x10) / 120.0F;

      /* MATLAB Function: '<S245>/Saturable Gain Lut (SatGainLut)1' */
      LKAS_SaturableGainLutSatGainLut(rtb_kphtomps_m,
        rtb_LL_LFClb_TFC_KdVehSpdLwr_C, rtb_LL_LFClb_TFC_KdVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KdV1_C, rtb_LL_LFClb_TFC_KdV2_C, &rtb_Gain_b);

      /* Product: '<S252>/Divide1' incorporates:
       *  Constant: '<S252>/Constant3'
       *  Sum: '<S252>/Add4'
       */
      rtb_Merge_h = (1.0F + rtb_R0_C3) * rtb_Gain_b;

      /* Gain: '<S252>/Gain' incorporates:
       *  Abs: '<S252>/Abs'
       */
      rtb_L0_C1_d = fabsf(rtb_LL_ThresDet_lDvtThresUprLKA) * 0.5F;

      /* Gain: '<S252>/Gain1' incorporates:
       *  Sum: '<S252>/Add2'
       */
      rtb_Gain1_c = (rtb_L0_C0_h + rtb_R0_C0_f) * 0.5F;

      /* Gain: '<S252>/Gain2' */
      rtb_Gain2_l = (-1.0F) * rtb_L0_C1_d;

      /* Switch: '<S257>/Switch' incorporates:
       *  RelationalOperator: '<S257>/UpperRelop'
       */
      if (rtb_Gain1_c < rtb_Gain2_l) {
        rtb_Switch_c = rtb_Gain2_l;
      } else {
        rtb_Switch_c = rtb_Gain1_c;
      }

      /* End of Switch: '<S257>/Switch' */

      /* Switch: '<S257>/Switch2' incorporates:
       *  RelationalOperator: '<S257>/LowerRelop1'
       */
      if (rtb_Gain1_c > rtb_L0_C1_d) {
        rtb_Switch2_jn = rtb_L0_C1_d;
      } else {
        rtb_Switch2_jn = rtb_Switch_c;
      }

      /* End of Switch: '<S257>/Switch2' */

      /* Product: '<S252>/Divide4' */
      rtb_L0_C1_d = (rtb_Switch2_jn / rtb_L0_C1_d) * rtb_R0_C3;

      /* Product: '<S252>/Divide5' incorporates:
       *  Constant: '<S252>/Constant2'
       *  Sum: '<S252>/Add5'
       */
      rtb_Divide5_n = (1.0F + rtb_L0_C1_d) * rtb_Gain_b;

      /* Product: '<S252>/Divide2' incorporates:
       *  Constant: '<S252>/Constant2'
       *  Sum: '<S252>/Add1'
       */
      rtb_Divide2_n = (1.0F - rtb_L0_C1_d) * rtb_Gain_b;

      /* Sum: '<S259>/Add' incorporates:
       *  Constant: '<S259>/Constant'
       *  Memory: '<S259>/Memory'
       */
      rtb_Saturation_fq = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_hk));

      /* Saturate: '<S259>/Saturation1' */
      if (rtb_Saturation_fq < ((uint16)10000U)) {
        rtb_Saturation1_dg = rtb_Saturation_fq;
      } else {
        rtb_Saturation1_dg = ((uint16)10000U);
      }

      /* End of Saturate: '<S259>/Saturation1' */

      /* If: '<S259>/If' incorporates:
       *  Constant: '<S259>/Constant2'
       *  DataTypeConversion: '<S141>/Cast To Single'
       *  Inport: '<S260>/In'
       */
      if (rtb_Saturation1_dg == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S259>/if action ' incorporates:
         *  ActionPort: '<S260>/Action Port'
         */
        LKAS_DW.In_k = LKAS_DW.stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S259>/if action ' */
      }

      /* End of If: '<S259>/If' */

      /* If: '<S252>/If' incorporates:
       *  Inport: '<S256>/In1'
       */
      if (((sint32)LKAS_DW.In_k) == 1) {
        /* Outputs for IfAction SubSystem: '<S252>/If Action Subsystem' incorporates:
         *  ActionPort: '<S254>/Action Port'
         */
        LKAS_IfActionSubsystem_d(rtb_Divide2_n, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S252>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_k) == 2) {
        /* Outputs for IfAction SubSystem: '<S252>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S255>/Action Port'
         */
        LKAS_IfActionSubsystem_d(rtb_Divide5_n, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S252>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S252>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S256>/Action Port'
         */
        rtb_Merge_k = rtb_Gain_b;

        /* End of Outputs for SubSystem: '<S252>/If Action Subsystem2' */
      }

      /* End of If: '<S252>/If' */

      /* Product: '<S252>/Divide3' incorporates:
       *  Constant: '<S252>/Constant1'
       *  Sum: '<S252>/Add3'
       */
      rtb_L0_C1_d = (1.0F - rtb_R0_C3) * rtb_Gain_b;

      /* Switch: '<S258>/Switch' incorporates:
       *  RelationalOperator: '<S258>/UpperRelop'
       */
      if (rtb_Merge_k < rtb_L0_C1_d) {
        rtb_Switch_ok = rtb_L0_C1_d;
      } else {
        rtb_Switch_ok = rtb_Merge_k;
      }

      /* End of Switch: '<S258>/Switch' */

      /* Switch: '<S258>/Switch2' incorporates:
       *  RelationalOperator: '<S258>/LowerRelop1'
       */
      if (rtb_Merge_k > rtb_Merge_h) {
        rtb_Switch2_c3 = rtb_Merge_h;
      } else {
        rtb_Switch2_c3 = rtb_Switch_ok;
      }

      /* End of Switch: '<S258>/Switch2' */

      /* Product: '<S245>/Divide7' incorporates:
       *  Gain: '<S245>/Gain1'
       */
      rtb_Divide7 = (rtb_LL_HdAgPrvwT_C * (-1.0F)) * rtb_Switch2_c3;

      /* Gain: '<S245>/Gain3' */
      rtb_Merge_h = (-1.0F) * rtb_kphTomps_a;

      /* Switch: '<S251>/Switch' incorporates:
       *  RelationalOperator: '<S251>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_Merge_h) {
        rtb_Switch_hb = rtb_Merge_h;
      } else {
        rtb_Switch_hb = rtb_Divide7;
      }

      /* End of Switch: '<S251>/Switch' */

      /* Switch: '<S251>/Switch2' incorporates:
       *  RelationalOperator: '<S251>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_kphTomps_a) {
        rtb_Switch2_dj = rtb_kphTomps_a;
      } else {
        rtb_Switch2_dj = rtb_Switch_hb;
      }

      /* End of Switch: '<S251>/Switch2' */

      /* Product: '<S156>/Divide4' */
      rtb_kphTomps_a = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S156>/Saturation1' */
      if (rtb_kphTomps_a > 1.0F) {
        rtb_kphTomps_a = 1.0F;
      } else {
        if (rtb_kphTomps_a < 0.0F) {
          rtb_kphTomps_a = 0.0F;
        }
      }

      /* End of Saturate: '<S156>/Saturation1' */

      /* Product: '<S156>/Divide2' */
      rtb_R0_C0_f = rtb_Switch2_dj * rtb_kphTomps_a;

      /* Saturate: '<S265>/Saturation4' */
      if (rtb_LL_LKASWASyn_M0 > 1.0F) {
        rtb_LL_LKASWASyn_M0 = 1.0F;
      } else {
        if (rtb_LL_LKASWASyn_M0 < 0.0F) {
          rtb_LL_LKASWASyn_M0 = 0.0F;
        }
      }

      /* End of Saturate: '<S265>/Saturation4' */

      /* Product: '<S156>/Divide5' incorporates:
       *  Constant: '<S265>/Constant1'
       *  Product: '<S265>/Divide8'
       *  Sum: '<S265>/Add1'
       */
      rtb_kphTomps_a = ((LKAS_ConstB.Add3 * rtb_LL_LKASWASyn_M0) + 0.0F) *
        rtb_LL_LKAExPrcs_tiExitTime1;

      /* Saturate: '<S156>/Saturation3' */
      if (rtb_Merge > 0.004F) {
        rtb_Merge_h = 0.004F;
      } else if (rtb_Merge < (-0.004F)) {
        rtb_Merge_h = (-0.004F);
      } else {
        rtb_Merge_h = rtb_Merge;
      }

      /* End of Saturate: '<S156>/Saturation3' */

      /* Product: '<S156>/Divide3' */
      rtb_LftTTLC = rtb_Saturation_gk / LKAS_DW.Merge_n;

      /* Saturate: '<S156>/Saturation' */
      if (rtb_LftTTLC > 1.0F) {
        rtb_LftTTLC = 1.0F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S156>/Saturation' */

      /* Sum: '<S156>/Add4' incorporates:
       *  Product: '<S156>/Divide6'
       *  Product: '<S156>/Divide7'
       *  Sum: '<S156>/Add6'
       */
      rtb_R0_C0_f = (((((LKAS_DW.Merge1 + rtb_LL_LKAExPrcs_tiExitTime1) *
                        rtb_LL_LKASWASyn_M1) + rtb_L0_C1_j) + rtb_R0_C0_f) +
                     rtb_kphTomps_a) + (LKAS_DW.DifferenceInputs2_d *
        rtb_LftTTLC);

      /* Memory: '<S263>/Memory3' */
      rtb_kphTomps_a = LKAS_DW.Memory3_PreviousInput_k;

      /* Sum: '<S263>/Add2' incorporates:
       *  Constant: '<S263>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_kphTomps_a += 1.0F;

      /* Saturate: '<S263>/Saturation' */
      if (rtb_kphTomps_a > 50.0F) {
        rtb_Saturation_c1 = 50.0F;
      } else if (rtb_kphTomps_a < 0.0F) {
        rtb_Saturation_c1 = 0.0F;
      } else {
        rtb_Saturation_c1 = rtb_kphTomps_a;
      }

      /* End of Saturate: '<S263>/Saturation' */

      /* Switch: '<S263>/Switch' incorporates:
       *  Constant: '<S156>/Constant1'
       *  Product: '<S263>/Divide'
       *  Product: '<S263>/Divide1'
       *  Sum: '<S263>/Add'
       *  Sum: '<S263>/Add1'
       *  UnitDelay: '<S263>/Unit Delay'
       */
      if (rtb_Saturation_c1 > 30.0F) {
        rtb_Switch_c1 = ((rtb_LKA_SampleTime / 0.1F) * (rtb_R0_C0_f -
          LKAS_DW.UnitDelay_DSTATE_i)) + LKAS_DW.UnitDelay_DSTATE_i;
      } else {
        rtb_Switch_c1 = rtb_R0_C0_f;
      }

      /* End of Switch: '<S263>/Switch' */

      /* Switch: '<S658>/Switch17' incorporates:
       *  Constant: '<S658>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S658>/Switch17' */

      /* Sum: '<S153>/Add' */
      rtb_Add_d1 = (rtb_Switch_c1 - x10) + LKAS_DW.Saturation_a;

      /* Sum: '<S153>/Add1' */
      rtb_kphTomps_a = rtb_LL_LKAExPrcs_tiExitTime1 + rtb_Saturation_a1;

      /* Sum: '<S153>/Add2' incorporates:
       *  Gain: '<S153>/Gain2'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 += (-1.0F) * rtb_Saturation_a1;

      /* Switch: '<S241>/Switch' incorporates:
       *  RelationalOperator: '<S241>/UpperRelop'
       */
      if (rtb_Add_d1 < rtb_LL_LKAExPrcs_tiExitTime1) {
        rtb_Switch_jv = rtb_LL_LKAExPrcs_tiExitTime1;
      } else {
        rtb_Switch_jv = rtb_Add_d1;
      }

      /* End of Switch: '<S241>/Switch' */

      /* Switch: '<S241>/Switch2' incorporates:
       *  RelationalOperator: '<S241>/LowerRelop1'
       */
      if (rtb_Add_d1 > rtb_kphTomps_a) {
        rtb_Switch2_e = rtb_kphTomps_a;
      } else {
        rtb_Switch2_e = rtb_Switch_jv;
      }

      /* End of Switch: '<S241>/Switch2' */

      /* Sum: '<S240>/Add1' incorporates:
       *  Constant: '<S240>/Constant'
       *  Memory: '<S240>/Memory'
       */
      rtb_Saturation_fq = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_jq));

      /* Switch: '<S240>/Switch' incorporates:
       *  Constant: '<S240>/LatchTime_SY'
       *  RelationalOperator: '<S240>/Relational Operator'
       *  UnitDelay: '<S240>/Delay Input2'
       *
       * Block description for '<S240>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_fq <= ((uint16)1U)) {
        rtb_kphTomps_a = rtb_Switch2_e;
      } else {
        rtb_kphTomps_a = LKAS_DW.DelayInput2_DSTATE_k;
      }

      /* End of Switch: '<S240>/Switch' */

      /* Sum: '<S240>/Difference Inputs1'
       *
       * Block description for '<S240>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_g = rtb_Switch2_e - rtb_kphTomps_a;

      /* SampleTimeMath: '<S240>/sample time'
       *
       * About '<S240>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_Merge_h = 0.01F;

      /* Product: '<S240>/delta rise limit' incorporates:
       *  Gain: '<S153>/Gain3'
       */
      rtb_L0_C1_d = (1.4F * rtb_ThresDet_coefficient_c) * rtb_Merge_h;

      /* Product: '<S240>/delta fall limit' incorporates:
       *  Gain: '<S153>/Gain1'
       */
      rtb_Merge_h *= (-1.4F) * rtb_ThresDet_coefficient_c;

      /* Switch: '<S242>/Switch' incorporates:
       *  RelationalOperator: '<S242>/UpperRelop'
       */
      if (rtb_UkYk1_g < rtb_Merge_h) {
        rtb_Switch_cd = rtb_Merge_h;
      } else {
        rtb_Switch_cd = rtb_UkYk1_g;
      }

      /* End of Switch: '<S242>/Switch' */

      /* Switch: '<S242>/Switch2' incorporates:
       *  RelationalOperator: '<S242>/LowerRelop1'
       */
      if (rtb_UkYk1_g > rtb_L0_C1_d) {
        rtb_Switch2_n = rtb_L0_C1_d;
      } else {
        rtb_Switch2_n = rtb_Switch_cd;
      }

      /* End of Switch: '<S242>/Switch2' */

      /* Sum: '<S240>/Difference Inputs2'
       *
       * Block description for '<S240>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_n + rtb_kphTomps_a;

      /* Saturate: '<S240>/Saturation2' */
      if (rtb_Saturation_fq < ((uint16)10000U)) {
        rtb_Saturation2_d = rtb_Saturation_fq;
      } else {
        rtb_Saturation2_d = ((uint16)10000U);
      }

      /* End of Saturate: '<S240>/Saturation2' */

      /* DataTypeConversion: '<S154>/CastLKA3' */
      LKAS_DW.T1_Mon_f = LKAS_DW.Merge_n;

      /* If: '<S193>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S211>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_Add_ah, &rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S210>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_Add_g, &rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S212>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem3' */
      }

      /* End of If: '<S193>/If' */

      /* If: '<S195>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S195>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S217>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_phiHdAg_Lft, &rtb_Merge_lz);

        /* End of Outputs for SubSystem: '<S195>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S195>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S216>/Action Port'
         */
        LKAS_IfActionSubsystem2_e(rtb_phiHdAg_Rgt, &rtb_Merge_lz);

        /* End of Outputs for SubSystem: '<S195>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S195>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S218>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_lz);

        /* End of Outputs for SubSystem: '<S195>/If Action Subsystem3' */
      }

      /* End of If: '<S195>/If' */

      /* DataTypeConversion: '<S235>/Data Type Conversion' incorporates:
       *  Constant: '<S236>/Constant'
       *  RelationalOperator: '<S236>/Compare'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((rtb_Merge <= 0.0F) ? 1 : 0);

      /* Gain: '<S231>/kph To mps' */
      rtb_kphTomps_a = rtb_Abs_p_tmp;

      /* Switch: '<S658>/Switch5' incorporates:
       *  Constant: '<S658>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_l != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_l;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S658>/Switch5' */

      /* Product: '<S235>/Divide' */
      rtb_Merge_h = (rtb_Merge * rtb_kphTomps_a) * x10;

      /* Abs: '<S235>/Abs1' incorporates:
       *  Abs: '<S235>/Abs'
       */
      rtb_R0_C0_f = fabsf(rtb_Merge_h);
      rtb_Abs1_k = rtb_R0_C0_f;

      /* Abs: '<S235>/Abs' */
      rtb_Abs_k = rtb_R0_C0_f;

      /* If: '<S235>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.stLKAActvFlg) == 1) && (((sint32)
            rtb_IMAPve_d_BCM_HazardLamp) == 0)) {
        /* Outputs for IfAction SubSystem: '<S235>/If Action Subsystem' incorporates:
         *  ActionPort: '<S237>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_k, &rtb_Merge_h);

        /* End of Outputs for SubSystem: '<S235>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.stLKAActvFlg) == 2) && (((sint32)
                   rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
        /* Outputs for IfAction SubSystem: '<S235>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S239>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_k, &rtb_Merge_h);

        /* End of Outputs for SubSystem: '<S235>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S235>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S238>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_h);

        /* End of Outputs for SubSystem: '<S235>/If Action Subsystem2' */
      }

      /* End of If: '<S235>/If' */

      /* Switch: '<S658>/Switch6' incorporates:
       *  Constant: '<S658>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_f != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_f;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S658>/Switch6' */

      /* Sum: '<S231>/Add1' incorporates:
       *  Product: '<S231>/Divide'
       *  Product: '<S231>/Divide1'
       */
      rtb_Add1_j3 = (((1.0F / x10) * rtb_LL_ThresDet_lDvtThresUprLKA) /
                     rtb_kphTomps_a) + rtb_Merge_h;

      /* If: '<S187>/If' incorporates:
       *  Constant: '<S234>/Constant2'
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S187>/If Action Subsystem' incorporates:
         *  ActionPort: '<S232>/Action Port'
         */
        /* Gain: '<S232>/Gain2' */
        rtb_Merge_g = (-1.0F) * rtb_Add1_j3;

        /* End of Outputs for SubSystem: '<S187>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S187>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S233>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_j3, &rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S187>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S187>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S234>/Action Port'
         */
        rtb_Merge_g = 0.0F;

        /* End of Outputs for SubSystem: '<S187>/If Action Subsystem2' */
      }

      /* End of If: '<S187>/If' */

      /* Sum: '<S196>/Add' incorporates:
       *  Constant: '<S196>/Constant'
       *  Memory: '<S196>/Memory'
       */
      rtb_Add_nv = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ac));

      /* Saturate: '<S196>/Saturation1' */
      if (rtb_Add_nv < ((uint16)10000U)) {
        rtb_Saturation_fq = rtb_Add_nv;
      } else {
        rtb_Saturation_fq = ((uint16)10000U);
      }

      /* End of Saturate: '<S196>/Saturation1' */

      /* If: '<S196>/If' incorporates:
       *  Constant: '<S196>/Constant2'
       */
      if (rtb_Saturation_fq == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S196>/if action ' incorporates:
         *  ActionPort: '<S219>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_g, &rtb_In_n);

        /* End of Outputs for SubSystem: '<S196>/if action ' */
      }

      /* End of If: '<S196>/If' */

      /* Sum: '<S198>/Add' incorporates:
       *  Constant: '<S198>/Constant'
       *  Memory: '<S198>/Memory'
       */
      rtb_Saturation_fq = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_hd));

      /* Saturate: '<S198>/Saturation1' */
      if (rtb_Saturation_fq < ((uint16)10000U)) {
        rtb_Saturation1_h = rtb_Saturation_fq;
      } else {
        rtb_Saturation1_h = ((uint16)10000U);
      }

      /* End of Saturate: '<S198>/Saturation1' */

      /* If: '<S198>/If' incorporates:
       *  Constant: '<S198>/Constant2'
       */
      if (rtb_Saturation1_h == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S198>/if action ' incorporates:
         *  ActionPort: '<S221>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_c, &rtb_In_i);

        /* End of Outputs for SubSystem: '<S198>/if action ' */
      }

      /* End of If: '<S198>/If' */

      /* Sum: '<S199>/Add' incorporates:
       *  Constant: '<S199>/Constant'
       *  Memory: '<S199>/Memory'
       */
      rtb_Saturation_fq = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ph));

      /* Saturate: '<S199>/Saturation1' */
      if (rtb_Saturation_fq < ((uint16)10000U)) {
        rtb_Saturation1_ey = rtb_Saturation_fq;
      } else {
        rtb_Saturation1_ey = ((uint16)10000U);
      }

      /* End of Saturate: '<S199>/Saturation1' */

      /* If: '<S199>/If' incorporates:
       *  Constant: '<S199>/Constant2'
       */
      if (rtb_Saturation1_ey == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S199>/if action ' incorporates:
         *  ActionPort: '<S222>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_lz, &rtb_In);

        /* End of Outputs for SubSystem: '<S199>/if action ' */
      }

      /* End of If: '<S199>/If' */

      /* DataTypeConversion: '<S184>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_ESC_VehSpd;

      /* DataTypeConversion: '<S154>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon_k = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S188>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_a) {
          /* Disable for Outport: '<S173>/Out' */
          LKAS_DW.RelationalOperator_k1 = false;
          LKAS_DW.SumCondition1_MODE_a = false;
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_o.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_kc,
            &LKAS_DW.SumCondition1_o);
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition' */
        if (LKAS_DW.SumCondition_pu.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_h,
            &LKAS_DW.SumCondition_pu);
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S181>/Out' */
          LKAS_DW.RelationalOperator_m = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S158>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_m) {
          /* Disable for Outport: '<S162>/M4K' */
          LKAS_DW.Saturation3 = 1.0F;
          LKAS_DW.SumCondition2_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S158>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S150>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S159>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_d = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S150>/Subsystem' */

        /* Disable for If: '<S262>/If' */
        LKAS_DW.If_ActiveSubsystem_n = -1;

        /* Disable for Outport: '<S141>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S141>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S141>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S141>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_k = 0.0F;
        LKAS_DW.T1_Mon_f = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon_k;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.T1_Mon = LKAS_DW.T1_Mon_f;

    /* Switch: '<S596>/Switch1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  Delay: '<S596>/Delay'
     *  S-Function (sfix_bitop): '<S599>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S599>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S599>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S607>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(LKAS_DW.Delay_DSTATE_b | ((uint8)1U));
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_b)) | ((uint8)1U))));
    }

    /* End of Switch: '<S596>/Switch1' */

    /* Switch: '<S596>/Switch2' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean2'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S600>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S600>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S600>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S608>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)2U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)2U))));
    }

    /* End of Switch: '<S596>/Switch2' */

    /* Switch: '<S596>/Switch3' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean3'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S601>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S601>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S601>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S609>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)4U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)4U))));
    }

    /* End of Switch: '<S596>/Switch3' */

    /* Switch: '<S596>/Switch4' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean9'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S602>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S602>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S602>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S610>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)8U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)8U))));
    }

    /* End of Switch: '<S596>/Switch4' */

    /* Switch: '<S596>/Switch5' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean10'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S604>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S604>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S604>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S611>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)16U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)16U))));
    }

    /* End of Switch: '<S596>/Switch5' */

    /* Switch: '<S596>/Switch6' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean11'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S603>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S603>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S603>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S612>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)32U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)32U))));
    }

    /* End of Switch: '<S596>/Switch6' */

    /* Switch: '<S596>/Switch7' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean12'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S613>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)64U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)64U))));
    }

    /* End of Switch: '<S596>/Switch7' */

    /* Switch: '<S596>/Switch8' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean21'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S614>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_Switch8 = (uint8)(rtb_IMAPve_d_BCM_HazardLamp | ((uint8)128U));
    } else {
      rtb_Switch8 = (uint8)(~((uint8)(((uint8)(~rtb_IMAPve_d_BCM_HazardLamp)) |
        ((uint8)128U))));
    }

    /* End of Switch: '<S596>/Switch8' */

    /* Switch: '<S597>/Switch1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean15'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  Delay: '<S597>/Delay'
     *  S-Function (sfix_bitop): '<S615>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S615>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S615>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(LKAS_DW.Delay_DSTATE_m | ((uint8)1U));
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_m)) | ((uint8)1U))));
    }

    /* End of Switch: '<S597>/Switch1' */

    /* Switch: '<S597>/Switch2' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean16'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S624>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)2U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)2U))));
    }

    /* End of Switch: '<S597>/Switch2' */

    /* Switch: '<S597>/Switch3' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean19'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S625>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)4U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)4U))));
    }

    /* End of Switch: '<S597>/Switch3' */

    /* Switch: '<S597>/Switch4' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean20'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S626>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)8U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)8U))));
    }

    /* End of Switch: '<S597>/Switch4' */

    /* Switch: '<S597>/Switch5' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean35'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S627>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)16U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)16U))));
    }

    /* End of Switch: '<S597>/Switch5' */

    /* Switch: '<S597>/Switch6' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean36'
     *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S628>/FixPt Bitwise Operator1'
     */
    if (tmpRead_q != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)32U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)32U))));
    }

    /* End of Switch: '<S597>/Switch6' */

    /* Switch: '<S597>/Switch7' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S629>/FixPt Bitwise Operator1'
     */
    if (tmpRead_r != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)64U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)64U))));
    }

    /* End of Switch: '<S597>/Switch7' */

    /* Switch: '<S597>/Switch8' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S630>/FixPt Bitwise Operator1'
     */
    if (tmpRead_r != ((T_M_Nm_Float32)0.0F)) {
      rtb_Switch8_k = (uint8)(rtb_IMAPve_d_BCM_HazardLamp | ((uint8)128U));
    } else {
      rtb_Switch8_k = (uint8)(~((uint8)(((uint8)(~rtb_IMAPve_d_BCM_HazardLamp)) |
        ((uint8)128U))));
    }

    /* End of Switch: '<S597>/Switch8' */

    /* Switch: '<S598>/Switch1' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean2'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  Delay: '<S598>/Delay'
     *  S-Function (sfix_bitop): '<S631>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S631>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S631>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator1'
     */
    if (tmpRead_r != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(LKAS_DW.Delay_DSTATE_o | ((uint8)1U));
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_o)) | ((uint8)1U))));
    }

    /* End of Switch: '<S598>/Switch1' */

    /* Switch: '<S598>/Switch2' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean3'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S640>/FixPt Bitwise Operator1'
     */
    if (tmpRead_r != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)2U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)2U))));
    }

    /* End of Switch: '<S598>/Switch2' */

    /* Switch: '<S598>/Switch3' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean4'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S641>/FixPt Bitwise Operator1'
     */
    if (tmpRead_r != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)4U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)4U))));
    }

    /* End of Switch: '<S598>/Switch3' */

    /* Switch: '<S598>/Switch4' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean6'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S642>/FixPt Bitwise Operator1'
     */
    if (tmpRead_r != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)8U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)8U))));
    }

    /* End of Switch: '<S598>/Switch4' */

    /* Switch: '<S598>/Switch5' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean8'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S643>/FixPt Bitwise Operator1'
     */
    if (tmpRead_r != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)16U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)16U))));
    }

    /* End of Switch: '<S598>/Switch5' */

    /* Switch: '<S598>/Switch6' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean9'
     *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S644>/FixPt Bitwise Operator1'
     */
    if (tmpRead_r != ((T_M_Nm_Float32)0.0F)) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)32U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)32U))));
    }

    /* End of Switch: '<S598>/Switch6' */

    /* Switch: '<S598>/Switch7' incorporates:
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S645>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LDW_Fault) {
      rtb_IMAPve_d_BCM_HazardLamp |= ((uint8)64U);
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(~((uint8)(((uint8)
        (~rtb_IMAPve_d_BCM_HazardLamp)) | ((uint8)64U))));
    }

    /* End of Switch: '<S598>/Switch7' */

    /* Switch: '<S598>/Switch8' incorporates:
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S646>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LKA_Fault) {
      rtb_Switch8_p = (uint8)(rtb_IMAPve_d_BCM_HazardLamp | ((uint8)128U));
    } else {
      rtb_Switch8_p = (uint8)(~((uint8)(((uint8)(~rtb_IMAPve_d_BCM_HazardLamp)) |
        ((uint8)128U))));
    }

    /* End of Switch: '<S598>/Switch8' */

    /* Sum: '<S593>/Add' incorporates:
     *  ArithShift: '<S593>/Shift Arithmetic'
     *  ArithShift: '<S593>/Shift Arithmetic1'
     *  DataTypeConversion: '<S593>/Data Type Conversion'
     *  DataTypeConversion: '<S593>/Data Type Conversion1'
     *  DataTypeConversion: '<S593>/Data Type Conversion2'
     */
    rtb_Add = ((((uint32)rtb_Switch8_k) << 8) + ((uint32)rtb_Switch8)) +
      (((uint32)rtb_Switch8_p) << 16);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Fault_Reason = rtb_Add;

    /* DataTypeConversion: '<S338>/Cast2' */
    ob_LKA_Fault_Reason = rtb_Add;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_State_Mon = LKAS_DW.stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LDW_State_Mon = LKAS_DW.stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S140>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S145>/If' */
      if (((sint32)LKAS_DW.stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S145>/If Action Subsystem' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        /* Gain: '<S146>/rad to deg' incorporates:
         *  Gain: '<S146>/Gain'
         */
        LKAS_DW.Merge_i = ((-1.0F) * rtb_phiHdAg_Lft) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S145>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S145>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        /* Gain: '<S147>/rad to deg' */
        LKAS_DW.Merge_i = 57.2957802F * rtb_phiHdAg_Rgt;

        /* End of Outputs for SubSystem: '<S145>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S145>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_i);

        /* End of Outputs for SubSystem: '<S145>/If Action Subsystem2' */
      }

      /* End of If: '<S145>/If' */

      /* Switch: '<S657>/Switch2' incorporates:
       *  Constant: '<S657>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_e != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_e;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S657>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S145>/Sum Condition' incorporates:
       *  EnablePort: '<S149>/Enable'
       */
      /* RelationalOperator: '<S145>/Relational Operator' */
      if (LKAS_DW.Merge_i >= x10) {
        if (!LKAS_DW.SumCondition_MODE_f) {
          /* InitializeConditions for Memory: '<S149>/Memory' */
          LKAS_DW.Memory_PreviousInput_c = 0.0F;
          LKAS_DW.SumCondition_MODE_f = true;
        }

        /* Sum: '<S149>/Add1' incorporates:
         *  Memory: '<S149>/Memory'
         */
        rtb_R0_C0_f = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_c;

        /* Saturate: '<S149>/Saturation' */
        if (rtb_R0_C0_f > 0.6F) {
          rtb_R0_C0_f = 0.6F;
        } else {
          if (rtb_R0_C0_f < 0.0F) {
            rtb_R0_C0_f = 0.0F;
          }
        }

        /* End of Saturate: '<S149>/Saturation' */

        /* RelationalOperator: '<S149>/Relational Operator' incorporates:
         *  Constant: '<S145>/Constant'
         */
        LKAS_DW.RelationalOperator_ep = (rtb_R0_C0_f >= 0.05F);

        /* Update for Memory: '<S149>/Memory' */
        LKAS_DW.Memory_PreviousInput_c = rtb_R0_C0_f;
      } else {
        if (LKAS_DW.SumCondition_MODE_f) {
          /* Disable for Outport: '<S149>/Out' */
          LKAS_DW.RelationalOperator_ep = false;
          LKAS_DW.SumCondition_MODE_f = false;
        }
      }

      /* End of RelationalOperator: '<S145>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S145>/Sum Condition' */

      /* Product: '<S140>/Product' incorporates:
       *  Logic: '<S140>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_ep) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S145>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_f) {
          /* Disable for Outport: '<S149>/Out' */
          LKAS_DW.RelationalOperator_ep = false;
          LKAS_DW.SumCondition_MODE_f = false;
        }

        /* End of Disable for SubSystem: '<S145>/Sum Condition' */

        /* Disable for Outport: '<S140>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* If: '<S466>/If' incorporates:
     *  Constant: '<S472>/Constant'
     *  Delay: '<S143>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_IMAPve_d_EPS_LKA_State) != 1)) {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem' incorporates:
       *  ActionPort: '<S470>/Action Port'
       */
      LKAS_IfActionSubsystem_o(&rtb_Merge_a);

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_IMAPve_d_EPS_LKA_State) != 3)) {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S471>/Action Port'
       */
      LKAS_IfActionSubsystem_o(&rtb_Merge_a);

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S472>/Action Port'
       */
      rtb_Merge_a = false;

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem3' */
    }

    /* End of If: '<S466>/If' */

    /* Outputs for Enabled SubSystem: '<S466>/Sum Condition1' */
    LKAS_SumCondition1(rtb_Merge_a, rtb_LKA_SampleTime,
                       rtb_LL_MAX_DELAY_EPSSTAR_TIME,
                       &LKAS_DW.RelationalOperator, &LKAS_DW.SumCondition1_d);

    /* End of Outputs for SubSystem: '<S466>/Sum Condition1' */

    /* SignalConversion: '<S525>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S437>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LogicalOperator_g;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_LL_SingleLane_Disable_Swt;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_Compare_gu;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_jbm;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_ih;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_ki;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_nm;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_n5;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_n;
    rtb_TmpSignalConversionAtSFunct[12] = rtb_stDvrTkConFlg_d;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_LogicalOperator_bp;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_mk;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_BCM_Left_Light;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge_p;

    /* MATLAB Function: '<S437>/Disable Reason' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S525>:1' */
    /* '<S525>:1:2' y = single(0); */
    rtb_R0_C0_f = 0.0F;

    /* '<S525>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S525>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S525>:1:5' y = single(i); */
        rtb_R0_C0_f = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Disable_Reason = rtb_R0_C0_f;

    /* DataTypeConversion: '<S338>/Cast' */
    ob_LKA_Disable_Reason = rtb_R0_C0_f;

    /* RelationalOperator: '<S476>/Compare' incorporates:
     *  Constant: '<S476>/Constant'
     */
    rtb_Compare_nr = (LKAS_DW.RelationalOperator == true);

    /* DataTypeConversion: '<S338>/Cast1' */
    ob_LKA_LKADeactvCSyn = (float32)(LKAS_DW.Merge1_n ? 1.0F : 0.0F);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LFTTTLC_Mon = rtb_LFTTTLC;

    /* Gain: '<S289>/Gain' incorporates:
     *  Sum: '<S289>/Add4'
     */
    rtb_phiHdAg = (rtb_phiHdAg_Lft + rtb_phiHdAg_Rgt) * 0.5F;

    /* Logic: '<S558>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S558>/Relational Operator3'
     *  RelationalOperator: '<S558>/Relational Operator4'
     */
    rtb_LogicalOperator1_k = ((rtb_Gain1 <= rtb_R0_C1_a) || (rtb_Add5_i <=
      rtb_R0_C1_a));

    /* Gain: '<S288>/Gain' incorporates:
     *  Sum: '<S288>/Add'
     */
    rtb_lDvt = (rtb_Gain1 + rtb_Add5_i) * 0.5F;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_Mode = LKAS_DW.LKA_Mode_g;

    /* Gain: '<S287>/Gain' incorporates:
     *  Sum: '<S287>/Add'
     */
    rtb_crCrvt = (rtb_L0_C2_g + rtb_R0_C2_e) * 0.5F;

    /* Delay: '<S143>/Delay1' */
    rtb_LKA_Mode = LKAS_DW.Delay1_2_DSTATE;
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S445>/ExitCount1' */
      if (LKAS_DW.ExitCount1.ExitCount_MODE) {
        LKAS_ExitCount_Disable(&LKAS_DW.RelationalOperator_l,
          &LKAS_DW.ExitCount1);
      }

      /* End of Disable for SubSystem: '<S445>/ExitCount1' */

      /* Disable for Enabled SubSystem: '<S445>/ExitCount' */
      if (LKAS_DW.ExitCount.ExitCount_MODE) {
        LKAS_ExitCount_Disable(&LKAS_DW.RelationalOperator_n, &LKAS_DW.ExitCount);
      }

      /* End of Disable for SubSystem: '<S445>/ExitCount' */

      /* Disable for Enabled SubSystem: '<S446>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S456>/Out' */
        LKAS_DW.RelationalOperator_e = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }

      /* End of Disable for SubSystem: '<S446>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S457>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S461>/Out' */
        LKAS_DW.RelationalOperator_j = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S457>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S384>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S415>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S384>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S384>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S414>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S384>/Count' */

      /* Disable for Enabled SubSystem: '<S417>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_n) {
        /* Disable for Outport: '<S423>/Out' */
        LKAS_DW.RelationalOperator_jo = false;
        LKAS_DW.SumCondition1_MODE_n = false;
      }

      /* End of Disable for SubSystem: '<S417>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S385>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_j) {
        /* Disable for Outport: '<S429>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE_j = false;
      }

      /* End of Disable for SubSystem: '<S385>/Sum Condition1' */

      /* Disable for If: '<S432>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S395>/Sum Condition' */
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S401>/Out' */
        LKAS_DW.RelationalOperator_eo = false;
        LKAS_DW.SumCondition_MODE = false;
      }

      /* End of Disable for SubSystem: '<S395>/Sum Condition' */

      /* Disable for Enabled SubSystem: '<S320>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_j) {
        /* Disable for Outport: '<S324>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.Subsystem_MODE_j = false;
      }

      /* End of Disable for SubSystem: '<S320>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S188>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_a) {
          /* Disable for Outport: '<S173>/Out' */
          LKAS_DW.RelationalOperator_k1 = false;
          LKAS_DW.SumCondition1_MODE_a = false;
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_o.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_kc,
            &LKAS_DW.SumCondition1_o);
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition' */
        if (LKAS_DW.SumCondition_pu.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_h,
            &LKAS_DW.SumCondition_pu);
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S172>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S181>/Out' */
          LKAS_DW.RelationalOperator_m = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S172>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S158>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_m) {
          /* Disable for Outport: '<S162>/M4K' */
          LKAS_DW.Saturation3 = 1.0F;
          LKAS_DW.SumCondition2_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S158>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S150>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S159>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_d = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S150>/Subsystem' */

        /* Disable for If: '<S262>/If' */
        LKAS_DW.If_ActiveSubsystem_n = -1;

        /* Disable for Outport: '<S141>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S141>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S141>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S141>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_k = 0.0F;
        LKAS_DW.T1_Mon_f = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S145>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_f) {
          /* Disable for Outport: '<S149>/Out' */
          LKAS_DW.RelationalOperator_ep = false;
          LKAS_DW.SumCondition_MODE_f = false;
        }

        /* End of Disable for SubSystem: '<S145>/Sum Condition' */

        /* Disable for Outport: '<S140>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Enabled SubSystem: '<S466>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_d.SumCondition1_MODE) {
        LKAS_SumCondition1_Disable(&LKAS_DW.RelationalOperator,
          &LKAS_DW.SumCondition1_d);
      }

      /* End of Disable for SubSystem: '<S466>/Sum Condition1' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.LKA_Mode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S11>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_IMAPve_d_BCM_HazardLamp = ((uint8)1U);
    break;

   case 1:
    rtb_IMAPve_d_BCM_HazardLamp = ((uint8)1U);
    break;

   case 2:
    rtb_IMAPve_d_BCM_HazardLamp = ((uint8)2U);
    break;

   case 3:
    rtb_IMAPve_d_BCM_HazardLamp = ((uint8)3U);
    break;

   case 4:
    rtb_IMAPve_d_BCM_HazardLamp = ((uint8)4U);
    break;

   case 5:
    rtb_IMAPve_d_BCM_HazardLamp = ((uint8)4U);
    break;

   default:
    rtb_IMAPve_d_BCM_HazardLamp = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S11>/Multiport Switch' */

  /* RelationalOperator: '<S648>/Compare' incorporates:
   *  Constant: '<S648>/Constant'
   */
  rtb_Merge_p = (rtb_IMAPve_d_BCM_HazardLamp == ((uint8)4U));

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/x1'
   */
  if (rtb_Merge_p) {
    rtb_R0_C0_f = LKAS_DW.OutputM;
  } else {
    rtb_R0_C0_f = (float32)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_g_EPS_Factor_Control_1'
   */
  (void) Rte_Write_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_R0_C0_f);

  /* Switch: '<S11>/Switch1' incorporates:
   *  Constant: '<S11>/1'
   *  Constant: '<S11>/x0'
   */
  if (rtb_Merge_p) {
    rtb_EPS_LKA_Control = (UInt8)((uint8)1U);
  } else {
    rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single1'
   *  DataTypeConversion: '<S1>/LKASve_y_LKATorqueReq_1'
   */
  (void) Rte_Write_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq
    (rtb_EPS_LKA_Control);

  /* Outputs for Enabled SubSystem: '<S647>/Subsystem' incorporates:
   *  EnablePort: '<S654>/Enable'
   */
  if (((sint32)rtb_EPS_LKA_Control) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S654>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S654>/Add' */
    rtb_R0_C0_f = LKAS_DW.OutputSWACmd - rtb_L0_C0_d2;

    /* Sum: '<S654>/Add1' incorporates:
     *  Constant: '<S654>/Ki'
     *  Delay: '<S654>/Delay1'
     *  Product: '<S654>/Product2'
     */
    rtb_L0_C0_h = (rtb_R0_C0_f * 0.0005F) + LKAS_DW.Delay1_DSTATE;

    /* Saturate: '<S654>/Saturation' */
    if (rtb_L0_C0_h > 0.5F) {
      rtb_L0_C0_h = 0.5F;
    } else {
      if (rtb_L0_C0_h < (-0.5F)) {
        rtb_L0_C0_h = (-0.5F);
      }
    }

    /* End of Saturate: '<S654>/Saturation' */

    /* Fcn: '<S654>/Fcn' */
    rtb_L0_C0_d2 = LKAS_DW.OutputSWACmd * LKAS_DW.OutputSWACmd;

    /* Sum: '<S654>/Add2' incorporates:
     *  Constant: '<S654>/Kp'
     *  Fcn: '<S654>/Fcn'
     *  Product: '<S654>/Product1'
     */
    LKAS_DW.in_trq = (((((rtb_L0_C0_d2 * LKAS_DW.OutputSWACmd) * 2.0e-6F) +
                        (rtb_L0_C0_d2 * -0.0005F)) + (LKAS_DW.OutputSWACmd *
      0.0505F)) + (rtb_R0_C0_f * 0.02F)) + rtb_L0_C0_h;

    /* Update for Delay: '<S654>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_L0_C0_h;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S654>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S647>/Subsystem' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_Camera_Status' */
  Rte_Read_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status(&tmpRead_t);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Sum: '<S652>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S652>/Delay Input2'
   *
   * Block description for '<S652>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S652>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_R0_C0_f = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S652>/delta rise limit' incorporates:
   *  Constant: '<S647>/Constant'
   *  SampleTimeMath: '<S652>/sample time'
   *
   * About '<S652>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C0_h = 5.0F * 0.01F;

  /* Product: '<S652>/delta fall limit' incorporates:
   *  Constant: '<S647>/Constant1'
   *  SampleTimeMath: '<S652>/sample time'
   *
   * About '<S652>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C2_g = (-5.0F) * 0.01F;

  /* Switch: '<S655>/Switch2' incorporates:
   *  Product: '<S652>/delta fall limit'
   *  Product: '<S652>/delta rise limit'
   *  RelationalOperator: '<S655>/LowerRelop1'
   *  RelationalOperator: '<S655>/UpperRelop'
   *  Switch: '<S655>/Switch'
   */
  if (rtb_R0_C0_f > rtb_L0_C0_h) {
    rtb_R0_C0_f = rtb_L0_C0_h;
  } else {
    if (rtb_R0_C0_f < rtb_L0_C2_g) {
      /* Switch: '<S655>/Switch' incorporates:
       *  Product: '<S652>/delta fall limit'
       */
      rtb_R0_C0_f = rtb_L0_C2_g;
    }
  }

  /* End of Switch: '<S655>/Switch2' */

  /* Sum: '<S652>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S652>/Delay Input2'
   *
   * Block description for '<S652>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S652>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_R0_C0_f += LKAS_DW.DelayInput2_DSTATE;

  /* Switch: '<S653>/Switch2' incorporates:
   *  Constant: '<S647>/Constant3'
   *  Constant: '<S647>/Constant4'
   *  RelationalOperator: '<S653>/LowerRelop1'
   *  RelationalOperator: '<S653>/UpperRelop'
   *  Switch: '<S653>/Switch'
   */
  if (rtb_R0_C0_f > 5.0F) {
    rtb_L0_C0_d2 = 5.0F;
  } else if (rtb_R0_C0_f < (-5.0F)) {
    /* Switch: '<S653>/Switch' incorporates:
     *  Constant: '<S647>/Constant4'
     */
    rtb_L0_C0_d2 = (-5.0F);
  } else {
    rtb_L0_C0_d2 = rtb_R0_C0_f;
  }

  /* End of Switch: '<S653>/Switch2' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_g_LKATorqueReq_Value_1'
   */
  (void) Rte_Write_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_L0_C0_d2);

  /* Switch: '<S11>/Switch2' incorporates:
   *  Constant: '<S11>/2'
   *  Constant: '<S11>/x2'
   *  Constant: '<S650>/Constant'
   *  Constant: '<S651>/Constant'
   *  Logic: '<S11>/Logical Operator'
   *  RelationalOperator: '<S650>/Compare'
   *  RelationalOperator: '<S651>/Compare'
   */
  if ((rtb_IMAPve_d_BCM_HazardLamp == ((uint8)4U)) ||
      (rtb_IMAPve_d_BCM_HazardLamp == ((uint8)3U))) {
    rtb_EPS_LKA_Control = (UInt8)((uint8)1U);
  } else {
    rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch2' */

  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_EPS_LKA_Control_1'
   */
  (void) Rte_Write_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    (rtb_EPS_LKA_Control);

  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_EPS_State_Control_1'
   */
  (void) Rte_Write_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control((UInt8)
    rtb_IMAPve_d_BCM_HazardLamp);

  /* Switch: '<S88>/Switch' incorporates:
   *  Constant: '<S90>/Constant'
   *  RelationalOperator: '<S90>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_LL_RlsDet_tiTrqChkT_DISABLE = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  }

  /* End of Switch: '<S88>/Switch' */

  /* Logic: '<S88>/Logical Operator2' incorporates:
   *  Abs: '<S88>/Abs'
   *  Constant: '<S91>/Constant'
   *  Constant: '<S92>/Constant'
   *  Constant: '<S93>/Constant'
   *  Constant: '<S94>/Constant'
   *  Constant: '<S95>/Constant'
   *  Constant: '<S96>/Constant'
   *  Constant: '<S97>/Constant'
   *  Constant: '<S98>/Constant'
   *  Logic: '<S88>/Logical Operator1'
   *  Logic: '<S88>/Logical Operator3'
   *  RelationalOperator: '<S88>/Relational Operator'
   *  RelationalOperator: '<S91>/Compare'
   *  RelationalOperator: '<S92>/Compare'
   *  RelationalOperator: '<S93>/Compare'
   *  RelationalOperator: '<S94>/Compare'
   *  RelationalOperator: '<S95>/Compare'
   *  RelationalOperator: '<S96>/Compare'
   *  RelationalOperator: '<S97>/Compare'
   *  RelationalOperator: '<S98>/Compare'
   */
  rtb_LogicalOperator2 = ((((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (LKAS_DW.LKA_State == ((uint8)5U))) || (LKAS_DW.LKA_State == ((uint8)4U))) ||
    (LKAS_DW.LKA_State == ((uint8)3U))) && ((rtb_IMAPve_d_EPS_LKA_State ==
    ((uint8)3U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)))) && (fabsf
    (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_LL_RlsDet_tiTrqChkT_DISABLE));

  /* Switch: '<S659>/Switch1' incorporates:
   *  Constant: '<S659>/LL_RlsDet_tiTDelTime_DISABLE=1'
   *
   * Block description for '<S659>/LL_RlsDet_tiTDelTime_DISABLE=1':
   *  ��ʻԱ���ֿ�ʼ�����ܷ����������ѵ�ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_HandsOff_TextTime = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_HandsOff_TextTime = LL_HandsOff_TextTime;
  }

  /* End of Switch: '<S659>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_TextTime, &LKAS_DW.RelationalOperator_i,
                     &LKAS_DW.SumCondition1);

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */

  /* MATLAB Function: '<S8>/HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S82>:1' */
  /* '<S82>:1:2' if (LKA_Mode==1||LKA_Mode==2)&&(Camera_Status==5) */
  if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2)) &&
      (((sint32)((uint8)tmpRead_t)) == 5)) {
    /* ����ͷ���ڵ� */
    /* '<S82>:1:3' HMI_Popup_Status=uint8(4); */
    rtb_IMAPve_d_EPS_LKA_State = 4U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) ==
    2)) && (LKAS_DW.RelationalOperator_i)) {
    /* '<S82>:1:4' elseif (LKA_Mode==1||LKA_Mode==2) && HandsOff1_Text==1 */
    /* ���շ����� */
    /* '<S82>:1:5' HMI_Popup_Status=uint8(2); */
    rtb_IMAPve_d_EPS_LKA_State = 2U;
  } else {
    /* '<S82>:1:6' else */
    /* '<S82>:1:7' HMI_Popup_Status=uint8(0); */
    rtb_IMAPve_d_EPS_LKA_State = 0U;
  }

  /* End of MATLAB Function: '<S8>/HMI_Popup_Status' */

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_HMI_Popup_Status_1'
   *  DataTypeConversion: '<S8>/Cast To Single6'
   */
  (void) Rte_Write_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status((UInt8)
    rtb_IMAPve_d_EPS_LKA_State);

  /* Switch: '<S659>/Switch2' incorporates:
   *  Constant: '<S659>/LL_RlsDet_tiTDelTime_DISABLE=2'
   *
   * Block description for '<S659>/LL_RlsDet_tiTDelTime_DISABLE=2':
   *  ��ʻԱ���ֿ�ʼ����������������ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion2_o != 0.0F) {
    rtb_LL_HandsOff_WarnTime = LKAS_ConstB.DataTypeConversion2_o;
  } else {
    rtb_LL_HandsOff_WarnTime = LL_HandsOff_WarnTime;
  }

  /* End of Switch: '<S659>/Switch2' */

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition2' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_WarnTime, &LKAS_DW.RelationalOperator_af,
                     &LKAS_DW.SumCondition2);

  /* End of Outputs for SubSystem: '<S88>/Sum Condition2' */

  /* MATLAB Function: '<S8>/Hands_Off_Warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_Off_Warning': '<S83>:1' */
  /* '<S83>:1:2' if HandsOff==0 */
  if (!LKAS_DW.RelationalOperator_af) {
    /* '<S83>:1:3' Hands_Off_Warning= uint8(0); */
    rtb_IMAPve_d_EPS_LKA_State = 0U;
  } else {
    /* '<S83>:1:4' elseif HandsOff==1 */
    /* '<S83>:1:5' Hands_Off_Warning= uint8(1); */
    rtb_IMAPve_d_EPS_LKA_State = 1U;
  }

  /* End of MATLAB Function: '<S8>/Hands_Off_Warning' */

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_Hands_Off_Warning_1'
   *  DataTypeConversion: '<S8>/Cast To Single4'
   */
  (void) Rte_Write_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning((UInt8)
    rtb_IMAPve_d_EPS_LKA_State);

  /* MATLAB Function: '<S8>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S85>:1' */
  /* '<S85>:1:2' if  LKA_Mode==1 && (LDW_Warn_Mode==0 || LDW_Warn_Mode==2) */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && ((((sint32)rtb_IMAPve_d_LDW_Warn_Mode)
        == 0) || (((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 2))) {
    /* '<S85>:1:3' if LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S85>:1:4' LDW_Flag=uint8(1); */
      rtb_IMAPve_d_EPS_LKA_State = 1U;
      break;

     case 2:
      /* '<S85>:1:5' elseif LDWWarnInfo==2 */
      /* '<S85>:1:6' LDW_Flag=uint8(2); */
      rtb_IMAPve_d_EPS_LKA_State = 2U;
      break;

     default:
      /* '<S85>:1:7' else */
      /* '<S85>:1:8' LDW_Flag=uint8(0); */
      rtb_IMAPve_d_EPS_LKA_State = 0U;
      break;
    }
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)
                rtb_IMAPve_d_LDW_Warn_Mode) == 0) || (((sint32)
                rtb_IMAPve_d_LDW_Warn_Mode) == 2))) {
    /* '<S85>:1:10' elseif (LKA_Mode==2) && (LDW_Warn_Mode==0 || LDW_Warn_Mode==2) */
    /* '<S85>:1:11' if LDWWarnInfo==1 && LKA_State==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S85>:1:12' LDW_Flag=uint8(1); */
      rtb_IMAPve_d_EPS_LKA_State = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S85>:1:13' elseif LDWWarnInfo==2 && LKA_State==5 */
      /* '<S85>:1:14' LDW_Flag=uint8(2); */
      rtb_IMAPve_d_EPS_LKA_State = 2U;
    } else {
      /* '<S85>:1:15' else */
      /* '<S85>:1:16' LDW_Flag=uint8(0); */
      rtb_IMAPve_d_EPS_LKA_State = 0U;
    }
  } else {
    /* '<S85>:1:18' else */
    /* '<S85>:1:19' LDW_Flag=uint8(0); */
    rtb_IMAPve_d_EPS_LKA_State = 0U;
  }

  /* End of MATLAB Function: '<S8>/LDW_Flag' */

  /* MATLAB Function: '<S8>/HapticAlarmReq' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HapticAlarmReq': '<S84>:1' */
  /* '<S84>:1:2' if  LDW_Flag==1 && (LDW_Warn_Mode == 1 || LDW_Warn_Mode == 2) */
  if ((((sint32)rtb_IMAPve_d_EPS_LKA_State) == 1) && ((((sint32)
         rtb_IMAPve_d_LDW_Warn_Mode) == 1) || (((sint32)
         rtb_IMAPve_d_LDW_Warn_Mode) == 2))) {
    /* '<S84>:1:3' HapticAlarmReq= uint8(1); */
    rtb_IMAPve_d_LDW_Warn_Mode = 1U;
  } else {
    /* '<S84>:1:4' else */
    /* '<S84>:1:5' HapticAlarmReq= uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  }

  /* End of MATLAB Function: '<S8>/HapticAlarmReq' */

  /* Outport: '<Root>/LKASve_y_HapticAlarmReq' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_HapticAlarmReq_1'
   *  DataTypeConversion: '<S8>/Cast To Single8'
   */
  (void) Rte_Write_LKASve_y_HapticAlarmReq_LKASve_y_HapticAlarmReq((UInt8)
    rtb_IMAPve_d_LDW_Warn_Mode);

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_LDW_Flag_1'
   *  DataTypeConversion: '<S8>/Cast To Single3'
   */
  (void) Rte_Write_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    rtb_IMAPve_d_EPS_LKA_State);

  /* MATLAB Function: '<S8>/Status_Display' */
  /*  ֻ��LDW����� */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Status_Display': '<S87>:1' */
  /* '<S87>:1:3' if (LKA_Mode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S87>:1:4' LDW_Status_Display=uint8(1); */
    rtb_IMAPve_d_LDW_Warn_Mode = 1U;

    /* '<S87>:1:5' LKA_Status_Display=uint8(0); */
    rtb_IMAPve_d_EPS_LKA_State = 0U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S87>:1:6' elseif (LKA_Mode==1)&&LDW_STATE==6 */
    /* '<S87>:1:7' LDW_Status_Display=uint8(2); */
    rtb_IMAPve_d_LDW_Warn_Mode = 2U;

    /* '<S87>:1:8' LKA_Status_Display=uint8(0); */
    rtb_IMAPve_d_EPS_LKA_State = 0U;

    /*  ֻ��LKA����� */
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State)
              != 6)) {
    /* '<S87>:1:11' elseif  (LKA_Mode==2)&&LKA_STATE~=6 */
    /* '<S87>:1:12' LDW_Status_Display=uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;

    /* '<S87>:1:13' LKA_Status_Display=uint8(1); */
    rtb_IMAPve_d_EPS_LKA_State = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S87>:1:14' elseif (LKA_Mode==2)&&LKA_STATE==6 */
    /* '<S87>:1:15' LDW_Status_Display=uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;

    /* '<S87>:1:16' LKA_Status_Display=uint8(2); */
    rtb_IMAPve_d_EPS_LKA_State = 2U;
  } else {
    /* '<S87>:1:17' else */
    /* '<S87>:1:18' LDW_Status_Display=uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;

    /* '<S87>:1:19' LKA_Status_Display=uint8(0); */
    rtb_IMAPve_d_EPS_LKA_State = 0U;
  }

  /* End of MATLAB Function: '<S8>/Status_Display' */

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_LDW_Status_Display_1'
   *  DataTypeConversion: '<S8>/Cast To Single1'
   */
  (void) Rte_Write_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_IMAPve_d_LDW_Warn_Mode);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_LKA_Status_Display_1'
   *  DataTypeConversion: '<S8>/Cast To Single2'
   */
  (void) Rte_Write_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)rtb_IMAPve_d_EPS_LKA_State);

  /* MATLAB Function: '<S8>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S86>:1' */
  /* '<S86>:1:2' if LKA_Mode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S86>:1:3' LKA_Action_Indication=uint8(1); */
    rtb_IMAPve_d_LDW_Warn_Mode = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S86>:1:4' elseif LKA_Mode==2&&LKA_STATE==3 */
    /* '<S86>:1:5' LKA_Action_Indication=uint8(2); */
    rtb_IMAPve_d_LDW_Warn_Mode = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S86>:1:6' elseif LKA_Mode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S86>:1:7' LKA_Action_Indication=uint8(3); */
    rtb_IMAPve_d_LDW_Warn_Mode = 3U;
  } else {
    /* '<S86>:1:8' else */
    /* '<S86>:1:9' LKA_Action_Indication=uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  }

  /* End of MATLAB Function: '<S8>/LKA_action_indication' */

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_LKA_Action_Indication_1'
   *  DataTypeConversion: '<S8>/Cast To Single5'
   */
  (void) Rte_Write_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_IMAPve_d_LDW_Warn_Mode);

  /* MATLAB Function: '<S8>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S111>/Switch'
   *  Switch: '<S111>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S89>:1' */
  /* '<S89>:1:2' if stDACmode==1 */
  if (((sint32)LKAS_DW.LKA_Mode) == 1) {
    /* '<S89>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_FDMMve_d_LkaFcnConf)
          != 3)) || (((sint32)rtb_IMAPve_d_LKA_Mode) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)
             rtb_FDMMve_d_LkaFcnConf) != 3)) && (((sint32)rtb_IMAPve_d_LKA_Mode)
           == 3)) {
        /* '<S89>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:6' Vehicle_Lane_Display=uint8(4); */
        rtb_FDMMve_d_LkaFcnConf = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) == 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* '<S89>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:8' Vehicle_Lane_Display=uint8(5); */
        rtb_FDMMve_d_LkaFcnConf = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) == 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) != 3)) {
        /* '<S89>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S89>:1:10' Vehicle_Lane_Display=uint8(10); */
        rtb_FDMMve_d_LkaFcnConf = 10U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) != 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* '<S89>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:12' Vehicle_Lane_Display=uint8(11); */
        rtb_FDMMve_d_LkaFcnConf = 11U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) == 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* '<S89>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:14' Vehicle_Lane_Display=uint8(12); */
        rtb_FDMMve_d_LkaFcnConf = 12U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) == 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* '<S89>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:16' Vehicle_Lane_Display=uint8(13); */
        rtb_FDMMve_d_LkaFcnConf = 13U;
      } else {
        /* '<S89>:1:17' else */
        /* '<S89>:1:18' Vehicle_Lane_Display=uint8(1); */
        rtb_FDMMve_d_LkaFcnConf = 1U;
      }
    } else {
      /* '<S89>:1:4' Vehicle_Lane_Display=uint8(3); */
    }
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
              3)) {
    /* '<S89>:1:20' elseif stDACmode==2 || stDACmode==3 */
    /* '<S89>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_FDMMve_d_LkaFcnConf)
          != 3)) || (((sint32)rtb_IMAPve_d_LKA_Mode) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)
             rtb_FDMMve_d_LkaFcnConf) != 3)) && (((sint32)rtb_IMAPve_d_LKA_Mode)
           == 3)) {
        /* '<S89>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:24' Vehicle_Lane_Display=uint8(4); */
        rtb_FDMMve_d_LkaFcnConf = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) == 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* '<S89>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:26' Vehicle_Lane_Display=uint8(5); */
        rtb_FDMMve_d_LkaFcnConf = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) == 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) != 3)) {
        /* '<S89>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S89>:1:28' Vehicle_Lane_Display=uint8(6); */
        rtb_FDMMve_d_LkaFcnConf = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) != 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* '<S89>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:30' Vehicle_Lane_Display=uint8(7); */
        rtb_FDMMve_d_LkaFcnConf = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) == 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* '<S89>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:32' Vehicle_Lane_Display=uint8(8); */
        rtb_FDMMve_d_LkaFcnConf = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)
                    rtb_FDMMve_d_LkaFcnConf) == 3)) && (((sint32)
                   rtb_IMAPve_d_LKA_Mode) == 3)) {
        /* '<S89>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:34' Vehicle_Lane_Display=uint8(9); */
        rtb_FDMMve_d_LkaFcnConf = 9U;
      } else {
        /* '<S89>:1:35' else */
        /* '<S89>:1:36' Vehicle_Lane_Display=uint8(1); */
        rtb_FDMMve_d_LkaFcnConf = 1U;
      }
    } else {
      /* '<S89>:1:22' Vehicle_Lane_Display=uint8(3); */
    }
  } else {
    /* '<S89>:1:38' else */
    /* '<S89>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_FDMMve_d_LkaFcnConf = 0U;
  }

  /* End of MATLAB Function: '<S8>/Vehicle_Lane_Display' */

  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_Vehicle_Lane_Display_1'
   *  DataTypeConversion: '<S8>/Cast To Single'
   */
  (void) Rte_Write_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_FDMMve_d_LkaFcnConf);

  /* DataTypeConversion: '<S11>/Cast To Single10' incorporates:
   *  Constant: '<S649>/Constant'
   *  RelationalOperator: '<S649>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.LKA_Mode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S4>/Cast To Single1' */
  LKAS_DW.CastToSingle1 = LKAS_DW.LFTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single2' */
  LKAS_DW.CastToSingle2 = LKAS_DW.RGTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single3' */
  LKAS_DW.CastToSingle3 = (float32)LKAS_DW.LDW_State_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single4' */
  LKAS_DW.CastToSingle4 = (float32)LKAS_DW.LKA_State_Mon;

  /* S-Function (scanpack): '<S4>/CAN Pack' */
  /* S-Function (scanpack): '<S4>/CAN Pack' */
  LKAS_DW.CANPack.ID = 1U;
  LKAS_DW.CANPack.Length = 8U;
  LKAS_DW.CANPack.Extended = 0U;
  LKAS_DW.CANPack.Remote = 0;
  LKAS_DW.CANPack.Data[0] = 0;
  LKAS_DW.CANPack.Data[1] = 0;
  LKAS_DW.CANPack.Data[2] = 0;
  LKAS_DW.CANPack.Data[3] = 0;
  LKAS_DW.CANPack.Data[4] = 0;
  LKAS_DW.CANPack.Data[5] = 0;
  LKAS_DW.CANPack.Data[6] = 0;
  LKAS_DW.CANPack.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle1;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[1] = LKAS_DW.CANPack.Data[1] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[0] = LKAS_DW.CANPack.Data[0] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle2;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[3] = LKAS_DW.CANPack.Data[3] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[2] = LKAS_DW.CANPack.Data[2] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle3;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[5] = LKAS_DW.CANPack.Data[5] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[4] = LKAS_DW.CANPack.Data[4] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle4;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[7] = LKAS_DW.CANPack.Data[7] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[6] = LKAS_DW.CANPack.Data[6] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack' */
    if ((8 == LKAS_DW.CANPack.Length) && (LKAS_DW.CANPack.ID != INVALID_CAN_ID) )
    {
      if ((1 == LKAS_DW.CANPack.ID) && (0U == LKAS_DW.CANPack.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5L_10 = result;
            }
          }
        }
      }
    }
  }

  /* Outport: '<Root>/LKASve_g_ob5H_10' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_g_ob5H_10_1'
   */
  (void) Rte_Write_LKASve_g_ob5H_10_LKASve_g_ob5H_10((T_M_Nm_Float32)
    LKAS_DW.LKASve_g_ob5H_10);

  /* Outport: '<Root>/LKASve_g_ob5L_10' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_g_ob5L_10_1'
   */
  (void) Rte_Write_LKASve_g_ob5L_10_LKASve_g_ob5L_10((T_M_Nm_Float32)
    LKAS_DW.LKASve_g_ob5L_10);

  /* DataTypeConversion: '<S4>/Cast To Single' */
  LKAS_DW.CastToSingle = LKAS_DW.Fault_Reason;

  /* DataTypeConversion: '<S4>/Cast To Single6' */
  LKAS_DW.CastToSingle6 = LKAS_DW.LKA_SampleTime_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single7' */
  LKAS_DW.CastToSingle7 = LKAS_DW.T1_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single5' */
  LKAS_DW.CastToSingle5 = (uint16)LKAS_DW.Disable_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  LKAS_DW.CANPack1.ID = 2U;
  LKAS_DW.CANPack1.Length = 8U;
  LKAS_DW.CANPack1.Extended = 0U;
  LKAS_DW.CANPack1.Remote = 0;
  LKAS_DW.CANPack1.Data[0] = 0;
  LKAS_DW.CANPack1.Data[1] = 0;
  LKAS_DW.CANPack1.Data[2] = 0;
  LKAS_DW.CANPack1.Data[3] = 0;
  LKAS_DW.CANPack1.Data[4] = 0;
  LKAS_DW.CANPack1.Data[5] = 0;
  LKAS_DW.CANPack1.Data[6] = 0;
  LKAS_DW.CANPack1.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 16
     *  length                  = 24
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 1.0
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      uint32 packingValue = 0;

      {
        uint32 result = (uint32) (LKAS_DW.CastToSingle);

        /* no scaling required */
        packingValue = result;
      }

      {
        uint32 packedValue;
        if (packingValue > (uint32)(16777215)) {
          packedValue = (uint32) 16777215;
        } else {
          packedValue = (uint32) (packingValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[2] = LKAS_DW.CANPack1.Data[2] | (uint8)
              ((uint32)(packedValue & (uint32)0xFFU));
            LKAS_DW.CANPack1.Data[1] = LKAS_DW.CANPack1.Data[1] | (uint8)
              ((uint32)((uint32)(packedValue & (uint32)0xFF00U) >> 8));
            LKAS_DW.CANPack1.Data[0] = LKAS_DW.CANPack1.Data[0] | (uint8)
              ((uint32)((uint32)(packedValue & (uint32)0xFF0000U) >> 16));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 8
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle6;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint8 packedValue;
        if (outValue > (float32)(255)) {
          packedValue = (uint8) 255;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint8) 0;
        } else {
          packedValue = (uint8) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[3] = LKAS_DW.CANPack1.Data[3] | (uint8)
              (packedValue);
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle7;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[5] = LKAS_DW.CANPack1.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[4] = LKAS_DW.CANPack1.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 1.0
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      uint32 packingValue = 0;

      {
        uint32 result = (uint32) (LKAS_DW.CastToSingle5);

        /* no scaling required */
        packingValue = result;
      }

      {
        uint16 packedValue;
        packedValue = (uint16) (packingValue);

        {
          {
            LKAS_DW.CANPack1.Data[7] = LKAS_DW.CANPack1.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[6] = LKAS_DW.CANPack1.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
    if ((8 == LKAS_DW.CANPack1.Length) && (LKAS_DW.CANPack1.ID != INVALID_CAN_ID)
        ) {
      if ((2 == LKAS_DW.CANPack1.ID) && (0U == LKAS_DW.CANPack1.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6L_10 = result;
            }
          }
        }
      }
    }
  }

  /* Outport: '<Root>/LKASve_g_ob6H_10' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_g_ob6H_10_1'
   */
  (void) Rte_Write_LKASve_g_ob6H_10_LKASve_g_ob6H_10((T_M_Nm_Float32)
    LKAS_DW.LKASve_g_ob6H_10);

  /* Outport: '<Root>/LKASve_g_ob6L_10' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_g_ob6L_10_1'
   */
  (void) Rte_Write_LKASve_g_ob6L_10_LKASve_g_ob6L_10((T_M_Nm_Float32)
    LKAS_DW.LKASve_g_ob6L_10);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single'
   *  DataTypeConversion: '<S1>/LKASve_g_LKA_SWA_Control_1'
   */
  (void) Rte_Write_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* DataTypeConversion: '<S12>/Cast To Boolean37' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_14B_InvOorReal = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean38' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxN = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean39' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxT = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean40' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinN = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean41' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinT = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S13>/Cast To Boolean' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_e_Node_ACU_Validity = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S13>/Cast To Boolean10' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_e_Node_EPB_Validity = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S13>/Cast To Boolean11' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIA_Inner_FRadar_FaultStat = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S13>/Cast To Boolean12' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_d_sen_sta_Corner_rad = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S13>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_e_Node_EMS_Validity = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S13>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   */
  rtb_ADIAve_e_Node_TBOX_Validity = (tmpRead_r != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean1' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC_EPBErrorStatus = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean13' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorTCS = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean14' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorVeh = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean17' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_MP5_366_OorAEBButt = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean18' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_MP5_366_OorFCWButt = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean22' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorSta = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean23' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorYaw = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean24' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC6_123_InvOorDyn = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean25' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC6_123_InvUnfilY = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean26' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehDri = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean27' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehHol = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean28' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_GW_MP5_413_OorISAM = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean29' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_SCC_309_OorACCButt = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean4' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_BCM3_33C_InvBrkLig = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS_14A_OorACCStat = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean6' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS10_88_InvAccPed = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS5_E0_InvOorBrkP = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* DataTypeConversion: '<S12>/Cast To Boolean8' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   */
  rtb_ADIA_DTC_EMS5_E0_OorEngineS = (tmpRead_q != ((T_M_Nm_Float32)0.0F));

  /* Switch: '<S119>/Switch3' incorporates:
   *  Constant: '<S119>/Constant'
   *  Inport: '<Root>/IMAPve_d_L1_Q'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S131>:1' */
  /* '<S131>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S131>:1:3' cur=min(single(0.004),cur); */
  /* '<S131>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S131>:1:5' offset=min(single(0.5),offset); */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    Rte_Read_IMAPve_d_L1_Q_IMAPve_d_L1_Q(&tmpRead_14);

    /* DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     */
    rtb_FDMMve_d_LkaFcnConf = (uint8)tmpRead_14;

    /* Switch: '<S113>/Switch1' incorporates:
     *  Constant: '<S113>/Constant1'
     */
    if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
      rtb_L1_Q = (uint16)((uint8)3U);
    } else {
      rtb_L1_Q = (uint16)rtb_FDMMve_d_LkaFcnConf;
    }

    /* End of Switch: '<S113>/Switch1' */
  } else {
    rtb_L1_Q = ((uint16)0U);
  }

  /* End of Switch: '<S119>/Switch3' */

  /* Switch: '<S121>/Switch3' incorporates:
   *  Constant: '<S121>/Constant'
   *  Inport: '<Root>/IMAPve_d_R1_Q'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    Rte_Read_IMAPve_d_R1_Q_IMAPve_d_R1_Q(&tmpRead_1a);

    /* DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    rtb_FDMMve_d_LkaFcnConf = (uint8)tmpRead_1a;

    /* Switch: '<S114>/Switch1' incorporates:
     *  Constant: '<S114>/Constant1'
     */
    if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
      rtb_R1_Q = (uint16)((uint8)3U);
    } else {
      rtb_R1_Q = (uint16)rtb_FDMMve_d_LkaFcnConf;
    }

    /* End of Switch: '<S114>/Switch1' */
  } else {
    rtb_R1_Q = ((uint16)0U);
  }

  /* End of Switch: '<S121>/Switch3' */

  /* Switch: '<S123>/Switch' incorporates:
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   *  Inport: '<Root>/IMAPve_g_Rrg_VR_End_BACK'
   */
  if (rtb_RFlg) {
    Rte_Read_IMAPve_g_Rrg_VR_End_BACK_IMAPve_g_Rrg_VR_End_BACK(&rtb_R0_VR);
  } else {
    Rte_Read_IMAPve_g_R0_VR_IMAPve_g_R0_VR(&rtb_R0_VR);
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   *  Inport: '<Root>/IMAPve_g_Lrg_VR_End_BACK'
   */
  if (rtb_LFlg) {
    Rte_Read_IMAPve_g_Lrg_VR_End_BACK_IMAPve_g_Lrg_VR_End_BACK(&rtb_L0_VR);
  } else {
    Rte_Read_IMAPve_g_L0_VR_IMAPve_g_L0_VR(&rtb_L0_VR);
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_VR_k = rtb_R0_VR;
  } else {
    rtb_R0_VR_k = rtb_L0_VR;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_p = rtb_L0_VR;
  } else {
    rtb_L0_VR_p = rtb_R0_VR;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_Rrg_TYPE_BACK_1'
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   *  Inport: '<Root>/IMAPve_d_Rrg_TYPE_BACK'
   */
  if (rtb_RFlg) {
    Rte_Read_IMAPve_d_Rrg_TYPE_BACK_IMAPve_d_Rrg_TYPE_BACK(&tmpRead_z);
    rtb_FDMMve_d_LkaFcnConf = (uint8)tmpRead_z;
  } else {
    Rte_Read_IMAPve_d_R0_Type_IMAPve_d_R0_Type(&tmpRead_z);
    rtb_FDMMve_d_LkaFcnConf = (uint8)tmpRead_z;
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_Lrg_TYPE_BACK_1'
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   *  Inport: '<Root>/IMAPve_d_Lrg_TYPE_BACK'
   */
  if (rtb_LFlg) {
    Rte_Read_IMAPve_d_Lrg_TYPE_BACK_IMAPve_d_Lrg_TYPE_BACK(&tmpRead_x);
    rtb_IMAPve_d_LKA_Mode = (uint8)tmpRead_x;
  } else {
    Rte_Read_IMAPve_d_L0_Type_IMAPve_d_L0_Type(&tmpRead_x);
    rtb_IMAPve_d_LKA_Mode = (uint8)tmpRead_x;
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_o = rtb_FDMMve_d_LkaFcnConf;
  } else {
    rtb_R0_Type_o = rtb_IMAPve_d_LKA_Mode;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_f = rtb_IMAPve_d_LKA_Mode;
  } else {
    rtb_L0_Type_f = rtb_FDMMve_d_LkaFcnConf;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  if (rtb_RFlg) {
    rtb_R0_W = 0.0F;
  } else {
    Rte_Read_IMAPve_g_R0_W_IMAPve_g_R0_W(&rtb_R0_W);
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_W'
   */
  if (rtb_LFlg) {
    rtb_L0_W = 0.0F;
  } else {
    Rte_Read_IMAPve_g_L0_W_IMAPve_g_L0_W(&rtb_L0_W);
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_b = rtb_R0_W;
  } else {
    rtb_R0_W_b = rtb_L0_W;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_g = rtb_L0_W;
  } else {
    rtb_L0_W_g = rtb_R0_W;
  }

  /* DataTypeConversion: '<S110>/Cast To Single12' incorporates:
   *  Inport: '<Root>/IMAPve_g_Rrg_VR_Start_BACK'
   */
  Rte_Read_IMAPve_g_Rrg_VR_Start_BACK_IMAPve_g_Rrg_VR_Start_BACK(&rtb_R1_VR_i);

  /* DataTypeConversion: '<S110>/Cast To Single4' incorporates:
   *  Inport: '<Root>/IMAPve_g_Lrg_VR_Start_BACK'
   */
  Rte_Read_IMAPve_g_Lrg_VR_Start_BACK_IMAPve_g_Lrg_VR_Start_BACK(&rtb_R1_VR);

  /* DataTypeConversion: '<S110>/Cast To Single52' incorporates:
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  Rte_Read_IMAPve_g_R1_W_IMAPve_g_R1_W(&rtb_R1_W);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_R1_Type' */
  Rte_Read_IMAPve_d_R1_Type_IMAPve_d_R1_Type(&tmpRead_1b);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S110>/Cast To Single50' incorporates:
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  Rte_Read_IMAPve_g_R1_VR_IMAPve_g_R1_VR(&rtb_R1_VR_m);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_R1_C3' */
  Rte_Read_IMAPve_g_R1_C3_IMAPve_g_R1_C3(&tmpRead_19);

  /* Inport: '<Root>/IMAPve_g_R1_C2' */
  Rte_Read_IMAPve_g_R1_C2_IMAPve_g_R1_C2(&tmpRead_18);

  /* Inport: '<Root>/IMAPve_g_R1_C1' */
  Rte_Read_IMAPve_g_R1_C1_IMAPve_g_R1_C1(&tmpRead_17);

  /* Inport: '<Root>/IMAPve_g_R1_C0' */
  Rte_Read_IMAPve_g_R1_C0_IMAPve_g_R1_C0(&tmpRead_16);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S110>/Cast To Single74' incorporates:
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  Rte_Read_IMAPve_g_L1_W_IMAPve_g_L1_W(&rtb_L1_W);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_L1_Type' */
  Rte_Read_IMAPve_d_L1_Type_IMAPve_d_L1_Type(&tmpRead_15);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S110>/Cast To Single78' incorporates:
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  Rte_Read_IMAPve_g_L1_VR_IMAPve_g_L1_VR(&rtb_L1_VR);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_L1_C3' */
  Rte_Read_IMAPve_g_L1_C3_IMAPve_g_L1_C3(&tmpRead_13);

  /* Inport: '<Root>/IMAPve_g_L1_C2' */
  Rte_Read_IMAPve_g_L1_C2_IMAPve_g_L1_C2(&tmpRead_12);

  /* Inport: '<Root>/IMAPve_g_L1_C1' */
  Rte_Read_IMAPve_g_L1_C1_IMAPve_g_L1_C1(&tmpRead_11);

  /* Inport: '<Root>/IMAPve_g_L1_C0' */
  Rte_Read_IMAPve_g_L1_C0_IMAPve_g_L1_C0(&tmpRead_10);

  /* Inport: '<Root>/IMAPve_d_Fusion_Status' */
  Rte_Read_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status(&tmpRead_v);

  /* Inport: '<Root>/IMAPve_d_Sensor_Status' */
  Rte_Read_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status(&tmpRead_u);

  /* Inport: '<Root>/ADIAve_d_FuncFaultStatus' */
  Rte_Read_ADIAve_d_FuncFaultStatus_ADIAve_d_FuncFaultStatus(&tmpRead_s);

  /* Inport: '<Root>/IMAPve_d_TCU_TCU_Available' */
  Rte_Read_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available(&tmpRead_p);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  Rte_Read_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal
    (&rtb_IMAPve_g_EMS_RealPedal);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_BCM_HazardLamp_Switch' */
  Rte_Read_IMAPve_d_BCM_HazardLamp_Switch_IMAPve_d_BCM_HazardLamp_Switch
    (&tmpRead_n);

  /* Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid' */
  Rte_Read_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid(&tmpRead_i);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  Rte_Read_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    (&rtb_IMAPve_g_ESC_Brake_Press);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid' */
  Rte_Read_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid(&tmpRead_h);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  Rte_Read_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate
    (&rtb_IMAPve_g_ESC_UnYawRate);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid' */
  Rte_Read_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid(&tmpRead_g);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  Rte_Read_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate(&rtb_IMAPve_g_ESC_YawRate);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid' */
  Rte_Read_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid(&tmpRead_f);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  Rte_Read_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle(&rtb_IMAPve_g_SW_Angle);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag' */
  Rte_Read_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    (&tmpRead_e);

  /* Inport: '<Root>/IMAPve_d_EPS_ESA_State' */
  Rte_Read_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State(&tmpRead_d);

  /* Inport: '<Root>/IMAPve_d_EPS_Driver_Override' */
  Rte_Read_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override(&tmpRead_c);

  /* Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State' */
  Rte_Read_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    (&tmpRead_b);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  Rte_Read_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    (&rtb_IMAPve_g_EPS_LKA_Current);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_EPS_TrqLim_State' */
  Rte_Read_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State(&tmpRead_a);

  /* Inport: '<Root>/IMAPve_d_SWS_Failure_Status' */
  Rte_Read_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status(&tmpRead_9);

  /* Inport: '<Root>/IMAPve_d_SAS_Trim_State' */
  Rte_Read_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State(&tmpRead_8);

  /* Inport: '<Root>/IMAPve_d_SAS_Clb_State' */
  Rte_Read_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State(&tmpRead_7);

  /* Inport: '<Root>/IMAPve_d_EPS_Trq_State' */
  Rte_Read_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State(&tmpRead_6);

  /* Inport: '<Root>/IMAPve_d_MP5_Work_State' */
  Rte_Read_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State(&tmpRead_4);

  /* Inport: '<Root>/IMAPve_d_APA_AutoPark_WorkSt' */
  Rte_Read_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt(&tmpRead_3);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_APA_AutoPark_WorkSt_1' */
  rtb_IMAPve_d_APA_AutoPark_WorkS = (uint8)tmpRead_3;

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_Switch_1' */
  rtb_IMAPve_d_BCM_HazardLamp_Swi = (uint8)tmpRead_n;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)tmpRead_c;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)tmpRead_d;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)tmpRead_b;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)tmpRead_e;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1' */
  rtb_IMAPve_d_EPS_TrqLim_State = (uint8)tmpRead_a;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1' */
  rtb_IMAPve_d_EPS_Trq_State = (uint8)tmpRead_6;

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1' */
  rtb_IMAPve_d_ESC_LatAcc_Valid = (uint8)tmpRead_f;

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1' */
  rtb_IMAPve_d_ESC_LonAcc_Valid = (uint8)tmpRead_h;

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1' */
  rtb_IMAPve_d_ESC_VehSpd_Valid = (uint8)tmpRead_i;

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1' */
  rtb_IMAPve_d_ESC_YawRate_Valid = (uint8)tmpRead_g;

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' */
  rtb_IMAPve_d_Fusion_Status = (uint8)tmpRead_v;

  /* DataTypeConversion: '<S110>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   */
  rtb_L1_Type = (uint8)tmpRead_15;

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' */
  rtb_IMAPve_d_MP5_Work_State = (uint8)tmpRead_4;

  /* DataTypeConversion: '<S110>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   */
  rtb_R1_Type = (uint8)tmpRead_1b;

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1' */
  rtb_IMAPve_d_SAS_Clb_State = (uint8)tmpRead_7;

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1' */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)tmpRead_8;

  /* DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1' */
  rtb_IMAPve_d_SWS_Failure_Status = (uint8)tmpRead_9;

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' */
  rtb_IMAPve_d_Sensor_Status = (uint8)tmpRead_u;

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)tmpRead_p;

  /* DataTypeConversion: '<S110>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  UnaryMinus: '<S110>/Unary Minus8'
   */
  rtb_L1_C0 = (float32)((T_M_Nm_Float32)(-tmpRead_10));

  /* DataTypeConversion: '<S110>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  UnaryMinus: '<S110>/Unary Minus9'
   */
  rtb_L1_C1 = (float32)((T_M_Nm_Float32)(-tmpRead_11));

  /* DataTypeConversion: '<S110>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  UnaryMinus: '<S110>/Unary Minus10'
   */
  rtb_L1_C2 = (float32)((T_M_Nm_Float32)(-tmpRead_12));

  /* DataTypeConversion: '<S110>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  UnaryMinus: '<S110>/Unary Minus11'
   */
  rtb_L1_C3 = (float32)((T_M_Nm_Float32)(-tmpRead_13));

  /* DataTypeConversion: '<S110>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  UnaryMinus: '<S110>/Unary Minus14'
   */
  rtb_R1_C0 = (float32)((T_M_Nm_Float32)(-tmpRead_16));

  /* DataTypeConversion: '<S110>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  UnaryMinus: '<S110>/Unary Minus15'
   */
  rtb_R1_C1 = (float32)((T_M_Nm_Float32)(-tmpRead_17));

  /* DataTypeConversion: '<S110>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  UnaryMinus: '<S110>/Unary Minus12'
   */
  rtb_R1_C2 = (float32)((T_M_Nm_Float32)(-tmpRead_18));

  /* DataTypeConversion: '<S110>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  UnaryMinus: '<S110>/Unary Minus13'
   */
  rtb_R1_C3 = (float32)((T_M_Nm_Float32)(-tmpRead_19));

  /* Switch: '<S658>/Switch1' incorporates:
   *  Constant: '<S658>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1_k != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1_k;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S658>/Switch1' */

  /* Switch: '<S658>/Switch15' incorporates:
   *  Constant: '<S658>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    rtb_LL_lStpLngth_C = LKAS_ConstB.DataTypeConversion21;
  } else {
    rtb_LL_lStpLngth_C = LL_lStpLngth_C;
  }

  /* End of Switch: '<S658>/Switch15' */

  /* Switch: '<S658>/Switch10' incorporates:
   *  Constant: '<S658>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22_h != 0.0F) {
    rtb_LL_DesDvt_C = LKAS_ConstB.DataTypeConversion22_h;
  } else {
    rtb_LL_DesDvt_C = LL_DesDvt_C;
  }

  /* End of Switch: '<S658>/Switch10' */

  /* Switch: '<S658>/Switch12' incorporates:
   *  Constant: '<S658>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S658>/Switch12' */

  /* Switch: '<S658>/Switch16' incorporates:
   *  Constant: '<S658>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S658>/Switch16' */

  /* Switch: '<S659>/Switch56' incorporates:
   *  Constant: '<S659>/LLSMConClb14'
   *
   * Block description for '<S659>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_m != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_m;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S659>/Switch56' */

  /* Switch: '<S659>/Switch51' incorporates:
   *  Constant: '<S659>/LLSMConClb15'
   *
   * Block description for '<S659>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_f != 0.0F) {
    rtb_LL_DvtComp_C_e = LKAS_ConstB.DataTypeConversion25_f;
  } else {
    rtb_LL_DvtComp_C_e = LL_DvtComp_C;
  }

  /* End of Switch: '<S659>/Switch51' */

  /* Switch: '<S659>/Switch52' incorporates:
   *  Constant: '<S659>/LLSMConClb16'
   *
   * Block description for '<S659>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36_d != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36_d;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S659>/Switch52' */

  /* Switch: '<S659>/Switch46' incorporates:
   *  Constant: '<S659>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S659>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_o != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_o;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S659>/Switch46' */

  /* Abs: '<S123>/Abs' incorporates:
   *  Sum: '<S123>/Add2'
   */
  rtb_LftTTLC = fabsf(rtb_L0_C2 + rtb_R0_C2);

  /* Saturate: '<S123>/Saturation' */
  if (rtb_LftTTLC > 0.004F) {
    rtb_LftTTLC = 0.004F;
  } else {
    if (rtb_LftTTLC < 0.0F) {
      rtb_LftTTLC = 0.0F;
    }
  }

  /* End of Saturate: '<S123>/Saturation' */

  /* Update for Memory: '<S123>/Memory1' incorporates:
   *  MATLAB Function: '<S123>/get_roadside_offset'
   */
  LKAS_DW.Memory1_PreviousInput = fminf(0.5F, (((fminf(0.004F, rtb_LftTTLC) /
    0.004F) + 1.0F) * 0.2F) * (fminf(4.0F, rtb_Saturation1) - 2.0F));

  /* Update for Delay: '<S128>/Delay' */
  LKAS_DW.Delay_DSTATE = rtb_Saturation1;

  /* Update for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Abs_lt;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S142>/Delay' */
    LKAS_DW.Delay_DSTATE_e = LKAS_DW.stLKAActvFlg;

    /* Update for Memory: '<S583>/Memory' */
    LKAS_DW.Memory_PreviousInput_i = rtb_Saturation_c;

    /* Update for Delay: '<S143>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.stLKAState;

    /* Update for Memory: '<S526>/Memory' */
    LKAS_DW.Memory_PreviousInput_p = rtb_Saturation_co;

    /* Update for Memory: '<S445>/Memory' */
    LKAS_DW.Memory_PreviousInput_j = rtb_IMAPve_g_EPS_SW_Trq;

    /* Update for UnitDelay: '<S458>/Delay Input1'
     *
     * Block description for '<S458>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_f;

    /* Update for UnitDelay: '<S457>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_in = LKAS_DW.RelationalOperator_j;

    /* Update for UnitDelay: '<S419>/Delay Input1'
     *
     * Block description for '<S419>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_f = rtb_Compare_a;

    /* Update for UnitDelay: '<S417>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_b = LKAS_DW.RelationalOperator_jo;

    /* Update for UnitDelay: '<S418>/Delay Input1'
     *
     * Block description for '<S418>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_m = rtb_Compare_pv;

    /* Update for Memory: '<S384>/Memory' */
    LKAS_DW.Memory_PreviousInput_gv = LKAS_DW.RelationalOperator_jo;

    /* Update for Delay: '<S143>/Delay' */
    LKAS_DW.Delay_DSTATE_k = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S143>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.stLDWState;

    /* Update for Memory: '<S432>/Memory' */
    LKAS_DW.Memory_PreviousInput_cp = rtb_LDW_State;

    /* Update for Memory: '<S358>/Memory' */
    LKAS_DW.Memory_PreviousInput_l = rtb_Merge1_a;

    /* Update for Memory: '<S394>/Memory' */
    LKAS_DW.Memory_PreviousInput_g = rtb_Merge1_g;

    /* Update for Memory: '<S595>/Memory' */
    LKAS_DW.Memory_PreviousInput_e = rtb_Saturation_k;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S170>/Memory' */
      LKAS_DW.Memory_PreviousInput_ox = rtb_Saturation2_m;

      /* Update for Memory: '<S201>/Memory' */
      LKAS_DW.Memory_PreviousInput_jj = rtb_Saturation1_p;

      /* Update for Memory: '<S188>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_i = rtb_Saturation1_l;

      /* Update for Memory: '<S200>/Memory' */
      LKAS_DW.Memory_PreviousInput_cy = rtb_Saturation1_g;

      /* Update for Memory: '<S202>/Memory' */
      LKAS_DW.Memory_PreviousInput_po = rtb_Saturation1_p2;

      /* Update for Memory: '<S197>/Memory' */
      LKAS_DW.Memory_PreviousInput_js = rtb_Saturation1_m;

      /* Update for Memory: '<S185>/Memory' */
      LKAS_DW.Memory_PreviousInput_lw = rtb_Add_ni;

      /* Update for Memory: '<S171>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = rtb_Saturation2_h;

      /* Update for Memory: '<S172>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = rtb_Saturation2_g;

      /* Update for UnitDelay: '<S174>/Delay Input1'
       *
       * Block description for '<S174>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_c = rtb_Compare_gm;

      /* Update for Memory: '<S172>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_e = rtb_Merge_n;

      /* Update for Memory: '<S163>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_i = rtb_Saturation_n;

      /* Update for Memory: '<S264>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_j = rtb_Saturation_gk;

      /* Update for Memory: '<S247>/Memory' */
      LKAS_DW.Memory_PreviousInput_hq = rtb_Add1_j;

      /* Update for UnitDelay: '<S245>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_l = rtb_Switch2_pe;

      /* Update for Memory: '<S253>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_je = rtb_Saturation_bi;

      /* Update for Memory: '<S259>/Memory' */
      LKAS_DW.Memory_PreviousInput_hk = rtb_Saturation1_dg;

      /* Update for UnitDelay: '<S263>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_i = rtb_Switch_c1;

      /* Update for Memory: '<S263>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_k = rtb_Saturation_c1;

      /* Update for UnitDelay: '<S240>/Delay Input2'
       *
       * Block description for '<S240>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_k = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S240>/Memory' */
      LKAS_DW.Memory_PreviousInput_jq = rtb_Saturation2_d;

      /* Update for Memory: '<S196>/Memory' */
      LKAS_DW.Memory_PreviousInput_ac = rtb_Add_nv;

      /* Update for Memory: '<S198>/Memory' */
      LKAS_DW.Memory_PreviousInput_hd = rtb_Saturation1_h;

      /* Update for Memory: '<S199>/Memory' */
      LKAS_DW.Memory_PreviousInput_ph = rtb_Saturation1_ey;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S596>/Delay' */
    LKAS_DW.Delay_DSTATE_b = rtb_Switch8;

    /* Update for Delay: '<S597>/Delay' */
    LKAS_DW.Delay_DSTATE_m = rtb_Switch8_k;

    /* Update for Delay: '<S598>/Delay' */
    LKAS_DW.Delay_DSTATE_o = rtb_Switch8_p;

    /* Update for Delay: '<S143>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.LKA_Mode_g;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S652>/Delay Input2'
   *
   * Block description for '<S652>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_R0_C0_f;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S432>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S188>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S262>/If' */
  LKAS_DW.If_ActiveSubsystem_n = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack' */

  /*-----------S-Function Block: <S4>/CAN Unpack -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack1' */

  /*-----------S-Function Block: <S4>/CAN Unpack1 -----------------*/

  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* ConstCode for Constant: '<S2>/Version' */
  ob_LKA_Version = 220323.0F;

  /* End of ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S142>/Delay' */
  LKAS_DW.Delay_DSTATE_e = ((uint8)0U);

  /* InitializeConditions for Memory: '<S583>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = 0.0F;

  /* InitializeConditions for Delay: '<S143>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S526>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = 0.0F;

  /* InitializeConditions for Memory: '<S445>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = 0.0F;

  /* InitializeConditions for UnitDelay: '<S458>/Delay Input1'
   *
   * Block description for '<S458>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S457>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_in = false;

  /* InitializeConditions for UnitDelay: '<S419>/Delay Input1'
   *
   * Block description for '<S419>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_f = false;

  /* InitializeConditions for UnitDelay: '<S417>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_b = false;

  /* InitializeConditions for UnitDelay: '<S418>/Delay Input1'
   *
   * Block description for '<S418>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_m = false;

  /* InitializeConditions for Memory: '<S384>/Memory' */
  LKAS_DW.Memory_PreviousInput_gv = false;

  /* InitializeConditions for Delay: '<S143>/Delay' */
  LKAS_DW.Delay_DSTATE_k = false;

  /* InitializeConditions for Delay: '<S143>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S432>/Memory' */
  LKAS_DW.Memory_PreviousInput_cp = ((uint8)0U);

  /* InitializeConditions for Memory: '<S358>/Memory' */
  LKAS_DW.Memory_PreviousInput_l = 0.0F;

  /* InitializeConditions for Memory: '<S394>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 0.0F;

  /* InitializeConditions for Memory: '<S595>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = 0.0F;

  /* InitializeConditions for Delay: '<S596>/Delay' */
  LKAS_DW.Delay_DSTATE_b = ((uint8)0U);

  /* InitializeConditions for Delay: '<S597>/Delay' */
  LKAS_DW.Delay_DSTATE_m = ((uint8)0U);

  /* InitializeConditions for Delay: '<S598>/Delay' */
  LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

  /* InitializeConditions for Delay: '<S143>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S445>/ExitCount1' */
  LKAS_ExitCount_Init(&LKAS_DW.ExitCount1);

  /* End of SystemInitialize for SubSystem: '<S445>/ExitCount1' */

  /* SystemInitialize for Enabled SubSystem: '<S445>/ExitCount' */
  LKAS_ExitCount_Init(&LKAS_DW.ExitCount);

  /* End of SystemInitialize for SubSystem: '<S445>/ExitCount' */

  /* SystemInitialize for Enabled SubSystem: '<S446>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S456>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S446>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S457>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S461>/Memory' */
  LKAS_DW.Memory_PreviousInput_g1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S457>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S384>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S415>/Memory' */
  LKAS_DW.Memory_PreviousInput_ix = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S384>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S384>/Count' */
  /* InitializeConditions for Memory: '<S414>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S384>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S417>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S423>/Memory' */
  LKAS_DW.Memory_PreviousInput_i1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S417>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S385>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S429>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S385>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S432>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S463>/Memory' */
  LKAS_DW.Memory_PreviousInput_ed = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S432>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S395>/Sum Condition' */
  /* InitializeConditions for Memory: '<S401>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S395>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S320>/Subsystem' */
  /* InitializeConditions for Memory: '<S324>/Memory' */
  LKAS_DW.Memory_PreviousInput_og = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S320>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S170>/Memory' */
  LKAS_DW.Memory_PreviousInput_ox = 0.0F;

  /* InitializeConditions for Memory: '<S201>/Memory' */
  LKAS_DW.Memory_PreviousInput_jj = ((uint16)0U);

  /* InitializeConditions for Memory: '<S188>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_i = ((uint8)0U);

  /* InitializeConditions for Memory: '<S200>/Memory' */
  LKAS_DW.Memory_PreviousInput_cy = ((uint16)0U);

  /* InitializeConditions for Memory: '<S202>/Memory' */
  LKAS_DW.Memory_PreviousInput_po = ((uint16)0U);

  /* InitializeConditions for Memory: '<S197>/Memory' */
  LKAS_DW.Memory_PreviousInput_js = ((uint16)0U);

  /* InitializeConditions for Memory: '<S185>/Memory' */
  LKAS_DW.Memory_PreviousInput_lw = 0.0F;

  /* InitializeConditions for Memory: '<S171>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S172>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = 0.0F;

  /* InitializeConditions for UnitDelay: '<S174>/Delay Input1'
   *
   * Block description for '<S174>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_c = false;

  /* InitializeConditions for Memory: '<S172>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_e = false;

  /* InitializeConditions for Memory: '<S163>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_i = 0.0F;

  /* InitializeConditions for Memory: '<S264>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_j = 0.0F;

  /* InitializeConditions for Memory: '<S247>/Memory' */
  LKAS_DW.Memory_PreviousInput_hq = 0.0F;

  /* InitializeConditions for UnitDelay: '<S245>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_l = 0.0F;

  /* InitializeConditions for Memory: '<S253>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_je = 0.0F;

  /* InitializeConditions for Memory: '<S259>/Memory' */
  LKAS_DW.Memory_PreviousInput_hk = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S263>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_i = 0.0F;

  /* InitializeConditions for Memory: '<S263>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_k = 0.0F;

  /* InitializeConditions for UnitDelay: '<S240>/Delay Input2'
   *
   * Block description for '<S240>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_k = 0.0F;

  /* InitializeConditions for Memory: '<S240>/Memory' */
  LKAS_DW.Memory_PreviousInput_jq = ((uint16)0U);

  /* InitializeConditions for Memory: '<S196>/Memory' */
  LKAS_DW.Memory_PreviousInput_ac = ((uint16)0U);

  /* InitializeConditions for Memory: '<S198>/Memory' */
  LKAS_DW.Memory_PreviousInput_hd = ((uint16)0U);

  /* InitializeConditions for Memory: '<S199>/Memory' */
  LKAS_DW.Memory_PreviousInput_ph = ((uint16)0U);

  /* SystemInitialize for Enabled SubSystem: '<S171>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S173>/Memory' */
  LKAS_DW.Memory_PreviousInput_hp = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S171>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S158>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S158>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S172>/Moving Standard Deviation1' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S172>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S172>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_o);

  /* End of SystemInitialize for SubSystem: '<S172>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S172>/Moving Standard Deviation2' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation2_j);

  /* End of SystemInitialize for SubSystem: '<S172>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S172>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_pu);

  /* End of SystemInitialize for SubSystem: '<S172>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S172>/Sum Condition2' */
  /* InitializeConditions for Memory: '<S181>/Memory' */
  LKAS_DW.Memory_PreviousInput_jg = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S172>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S158>/Sum Condition2' */
  /* InitializeConditions for Memory: '<S162>/Memory' */
  LKAS_DW.Memory_PreviousInput_gm = 0.0F;

  /* SystemInitialize for Outport: '<S162>/M4K' */
  LKAS_DW.Saturation3 = 1.0F;

  /* End of SystemInitialize for SubSystem: '<S158>/Sum Condition2' */

  /* SystemInitialize for IfAction SubSystem: '<S262>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S272>/Delay Input1'
   *
   * Block description for '<S272>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_j = false;

  /* InitializeConditions for Memory: '<S268>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S262>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S262>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S280>/Delay Input1'
   *
   * Block description for '<S280>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_h = false;

  /* InitializeConditions for Memory: '<S269>/Memory' */
  LKAS_DW.Memory_PreviousInput_lh = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S262>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S262>/Merge' */
  LKAS_DW.Merge_n = 1.0F;

  /* SystemInitialize for Merge: '<S262>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S145>/Merge' */
  LKAS_DW.Merge_i = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S145>/Sum Condition' */
  /* InitializeConditions for Memory: '<S149>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S145>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */

  /* SystemInitialize for Enabled SubSystem: '<S466>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1_d);

  /* End of SystemInitialize for SubSystem: '<S466>/Sum Condition1' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S647>/Subsystem' */
  /* InitializeConditions for Delay: '<S654>/Delay1' */
  LKAS_DW.Delay1_DSTATE = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S647>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S88>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1);

  /* End of SystemInitialize for SubSystem: '<S88>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S88>/Sum Condition2' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition2);

  /* End of SystemInitialize for SubSystem: '<S88>/Sum Condition2' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
