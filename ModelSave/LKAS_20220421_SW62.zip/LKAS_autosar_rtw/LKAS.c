/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Apr 21 17:57:52 2022
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S143>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S143>/LKA_State_Machine' */
#define LKAS_IN_Fault_j                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_d      ((uint8)0U)
#define LKAS_IN_Normal_f               ((uint8)2U)
#define LKAS_IN_SysOff_j               ((uint8)2U)
#define LKAS_IN_SysOn_o                ((uint8)3U)
#define LKAS_IN_Unavailable_i          ((uint8)1U)
#define LKAS_IN_Unselected_f           ((uint8)2U)

/* Named constants for Chart: '<S111>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NO_ACTIVE_CHILD_c      ((uint8)0U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Named constants for Chart: '<S160>/Chart' */
#define LKAS_IN_ADASAct                ((uint8)1U)
#define LKAS_IN_DriverAct              ((uint8)2U)

/* Exported data definition */

/* Definition for custom storage class: Default */
float32 ob_LKA_Disable_Reason;
uint32 ob_LKA_Fault_Reason;
float32 ob_LKA_LKADeactvCSyn;
float32 ob_LKA_Version;

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * System initialize for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S477>/Sum Condition1'
 */
void LKAS_SumCondition1_Init(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S99>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S477>/Sum Condition1'
 */
void LKAS_SumCondition1_Reset(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S99>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S477>/Sum Condition1'
 */
void LKAS_SumCondition1_Disable(boolean *rty_Out, DW_SumCondition1_LKAS_T
  *localDW)
{
  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' incorporates:
   *  EnablePort: '<S99>/state = reset'
   */
  /* Disable for Outport: '<S99>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */
  localDW->SumCondition1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S477>/Sum Condition1'
 */
void LKAS_SumCondition1(boolean rtu_statereset, float32 rtu_SampleTime, float32
  rtu_Sum, boolean *rty_Out, DW_SumCondition1_LKAS_T *localDW)
{
  float32 rtb_Saturation_f1;

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' incorporates:
   *  EnablePort: '<S99>/state = reset'
   */
  if (rtu_statereset) {
    if (!localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Reset(localDW);
      localDW->SumCondition1_MODE = true;
    }

    /* Sum: '<S99>/Add1' incorporates:
     *  Memory: '<S99>/Memory'
     */
    rtb_Saturation_f1 = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S99>/Saturation' */
    if (rtb_Saturation_f1 > 60.0F) {
      rtb_Saturation_f1 = 60.0F;
    } else {
      if (rtb_Saturation_f1 < 0.0F) {
        rtb_Saturation_f1 = 0.0F;
      }
    }

    /* End of Saturate: '<S99>/Saturation' */

    /* RelationalOperator: '<S99>/Relational Operator' */
    *rty_Out = (rtb_Saturation_f1 >= rtu_Sum);

    /* Update for Memory: '<S99>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_f1;
  } else {
    if (localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */
}

/*
 * Output and update for action system:
 *    '<S145>/If Action Subsystem2'
 *    '<S202>/If Action Subsystem3'
 *    '<S203>/If Action Subsystem3'
 *    '<S204>/If Action Subsystem3'
 *    '<S205>/If Action Subsystem3'
 *    '<S206>/If Action Subsystem3'
 *    '<S214>/If Action Subsystem3'
 *    '<S246>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S148>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S148>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/* System initialize for atomic system: '<S158>/Moving Standard Deviation2' */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S162>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S162>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* System reset for atomic system: '<S158>/Moving Standard Deviation2' */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S162>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S162>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S162>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* Output and update for atomic system: '<S158>/Moving Standard Deviation2' */
void LKAS_MovingStandardDeviation2(float32 rtu_In1, float32 *rty_Out2, float32
  *rty_Out1, DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_h;
  float32 rtb_Delay1_p;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_SumofElements;
  float32 rtb_TmpSignalConversionAtStanda[50];
  sint32 tmp;
  sint32 i;
  float32 rtb_Saturation_gh;

  /* Delay: '<S162>/Delay' */
  rtb_Delay_h = localDW->Delay_DSTATE;

  /* Delay: '<S162>/Delay1' */
  rtb_Delay1_p = localDW->Delay1_DSTATE;

  /* Delay: '<S162>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S162>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S162>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S162>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S162>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S162>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S162>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S162>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S162>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S162>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S162>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S162>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S162>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S162>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S162>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S162>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S162>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S162>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S162>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S162>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S162>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S162>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S162>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S162>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S162>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S162>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S162>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S162>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S162>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S162>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S162>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S162>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S162>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S162>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S162>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S162>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S162>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S162>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S162>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S162>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S162>/Delay47' */
  rtb_SumofElements = localDW->Delay47_DSTATE;

  /* Delay: '<S162>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S162>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S162>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S162>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S162>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S162>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S162>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_h;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_p;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_SumofElements;

  /* Sum: '<S162>/Sum of Elements' */
  tmp = 0;
  rtb_Saturation_gh = -0.0F;
  for (i = 0; i < 50; i++) {
    rtb_Saturation_gh += rtb_TmpSignalConversionAtStanda[i];
  }

  rtb_SumofElements = rtb_Saturation_gh;

  /* End of Sum: '<S162>/Sum of Elements' */

  /* Sum: '<S162>/Add2' incorporates:
   *  Constant: '<S162>/Constant'
   *  Memory: '<S162>/Memory3'
   */
  rtb_Saturation_gh = (float32)((uint8)(((uint32)((uint8)1U)) + ((uint32)((uint8)
    localDW->Memory3_PreviousInput))));

  /* Saturate: '<S162>/Saturation' */
  if (rtb_Saturation_gh > 50.0F) {
    rtb_Saturation_gh = 50.0F;
  } else {
    if (rtb_Saturation_gh < 1.0F) {
      rtb_Saturation_gh = 1.0F;
    }
  }

  /* End of Saturate: '<S162>/Saturation' */

  /* Product: '<S162>/Divide' */
  *rty_Out2 = rtb_SumofElements / rtb_Saturation_gh;

  /* S-Function (sdspstatfcns): '<S162>/Standard Deviation' incorporates:
   *  SignalConversion: '<S162>/TmpSignal ConversionAtStandard DeviationInport1'
   */
  while (tmp < 1) {
    localDW->StandardDeviation_AccVal = rtu_In1;
    localDW->StandardDeviation_SqData = rtu_In1 * rtu_In1;
    tmp = 1;
    for (i = 48; i >= 0; i--) {
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[tmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[tmp] *
        rtb_TmpSignalConversionAtStanda[tmp];
      tmp++;
    }

    *rty_Out1 = (localDW->StandardDeviation_SqData -
                 ((localDW->StandardDeviation_AccVal *
                   localDW->StandardDeviation_AccVal) / 50.0F)) / 49.0F;
    *rty_Out1 = sqrtf(fabsf(*rty_Out1));
    tmp = 1;
  }

  /* End of S-Function (sdspstatfcns): '<S162>/Standard Deviation' */

  /* Update for Delay: '<S162>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S162>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_h;

  /* Update for Delay: '<S162>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S162>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S162>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S162>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S162>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S162>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S162>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S162>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S162>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S162>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S162>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_p;

  /* Update for Delay: '<S162>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S162>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S162>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S162>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S162>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S162>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S162>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S162>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S162>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S162>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S162>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S162>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S162>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S162>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S162>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S162>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S162>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S162>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S162>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S162>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S162>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S162>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S162>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S162>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S162>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S162>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S162>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S162>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S162>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S162>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S162>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S162>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S162>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S162>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S162>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S162>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;

  /* Update for Memory: '<S162>/Memory3' */
  localDW->Memory3_PreviousInput = rtb_Saturation_gh;
}

/* System initialize for atomic system: '<S160>/Moving Standard Deviation2' */
void MovingStandardDeviation2_p_Init(DW_MovingStandardDeviation2_p_T *localDW)
{
  /* InitializeConditions for Memory: '<S176>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;
}

/* System reset for atomic system: '<S160>/Moving Standard Deviation2' */
void MovingStandardDeviation_i_Reset(DW_MovingStandardDeviation2_p_T *localDW)
{
  /* InitializeConditions for Memory: '<S176>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;
}

/* Output and update for atomic system: '<S160>/Moving Standard Deviation2' */
float32 LKAS_MovingStandardDeviation2_l(float32 rtu_In1,
  DW_MovingStandardDeviation2_p_T *localDW)
{
  float32 rty_Out2_0;
  float32 rtb_Divide_kv;
  float32 rtb_Saturation_de;
  float32 tmpForInput[30];
  sint32 i;
  float32 rtb_Delay_de;
  float32 rtb_Delay1_h;
  float32 rtb_Delay2_p;
  float32 rtb_Delay3_dg;
  float32 rtb_Delay4_e;
  float32 rtb_Delay5_b;
  float32 rtb_Delay6_o;
  float32 rtb_Delay7_j;
  float32 rtb_Delay8_m;
  float32 rtb_Delay9_l;
  float32 rtb_Delay10_p;
  float32 rtb_Delay11_g;
  float32 rtb_Delay12_h;
  float32 rtb_Delay13_h;
  float32 rtb_Delay14_d;
  float32 rtb_Delay15_i;
  float32 rtb_Delay16_h;
  float32 rtb_Delay17_p;
  float32 rtb_Delay18_i;
  float32 rtb_Delay28_g;
  float32 rtb_Delay19_a;
  float32 rtb_Delay20_c;
  float32 rtb_Delay21_a;
  float32 rtb_Delay22_m;
  float32 rtb_Delay23_l;
  float32 rtb_Delay24_g;
  float32 rtb_Delay25_n;
  float32 rtb_Delay26_a;

  /* Sum: '<S176>/Add2' incorporates:
   *  Constant: '<S176>/Constant'
   *  Memory: '<S176>/Memory3'
   */
  rtb_Saturation_de = 1.0F + localDW->Memory3_PreviousInput;

  /* Saturate: '<S176>/Saturation' */
  if (rtb_Saturation_de > 30.0F) {
    rtb_Saturation_de = 30.0F;
  } else {
    if (rtb_Saturation_de < 1.0F) {
      rtb_Saturation_de = 1.0F;
    }
  }

  /* End of Saturate: '<S176>/Saturation' */

  /* Delay: '<S176>/Delay' */
  rtb_Delay_de = localDW->Delay_DSTATE;

  /* Delay: '<S176>/Delay1' */
  rtb_Delay1_h = localDW->Delay1_DSTATE;

  /* Delay: '<S176>/Delay2' */
  rtb_Delay2_p = localDW->Delay2_DSTATE;

  /* Delay: '<S176>/Delay3' */
  rtb_Delay3_dg = localDW->Delay3_DSTATE;

  /* Delay: '<S176>/Delay4' */
  rtb_Delay4_e = localDW->Delay4_DSTATE;

  /* Delay: '<S176>/Delay5' */
  rtb_Delay5_b = localDW->Delay5_DSTATE;

  /* Delay: '<S176>/Delay6' */
  rtb_Delay6_o = localDW->Delay6_DSTATE;

  /* Delay: '<S176>/Delay7' */
  rtb_Delay7_j = localDW->Delay7_DSTATE;

  /* Delay: '<S176>/Delay8' */
  rtb_Delay8_m = localDW->Delay8_DSTATE;

  /* Delay: '<S176>/Delay9' */
  rtb_Delay9_l = localDW->Delay9_DSTATE;

  /* Delay: '<S176>/Delay10' */
  rtb_Delay10_p = localDW->Delay10_DSTATE;

  /* Delay: '<S176>/Delay11' */
  rtb_Delay11_g = localDW->Delay11_DSTATE;

  /* Delay: '<S176>/Delay12' */
  rtb_Delay12_h = localDW->Delay12_DSTATE;

  /* Delay: '<S176>/Delay13' */
  rtb_Delay13_h = localDW->Delay13_DSTATE;

  /* Delay: '<S176>/Delay14' */
  rtb_Delay14_d = localDW->Delay14_DSTATE;

  /* Delay: '<S176>/Delay15' */
  rtb_Delay15_i = localDW->Delay15_DSTATE;

  /* Delay: '<S176>/Delay16' */
  rtb_Delay16_h = localDW->Delay16_DSTATE;

  /* Delay: '<S176>/Delay17' */
  rtb_Delay17_p = localDW->Delay17_DSTATE;

  /* Delay: '<S176>/Delay18' */
  rtb_Delay18_i = localDW->Delay18_DSTATE;

  /* Delay: '<S176>/Delay28' */
  rtb_Delay28_g = localDW->Delay28_DSTATE;

  /* Delay: '<S176>/Delay19' */
  rtb_Delay19_a = localDW->Delay19_DSTATE;

  /* Delay: '<S176>/Delay20' */
  rtb_Delay20_c = localDW->Delay20_DSTATE;

  /* Delay: '<S176>/Delay21' */
  rtb_Delay21_a = localDW->Delay21_DSTATE;

  /* Delay: '<S176>/Delay22' */
  rtb_Delay22_m = localDW->Delay22_DSTATE;

  /* Delay: '<S176>/Delay23' */
  rtb_Delay23_l = localDW->Delay23_DSTATE;

  /* Delay: '<S176>/Delay24' */
  rtb_Delay24_g = localDW->Delay24_DSTATE;

  /* Delay: '<S176>/Delay25' */
  rtb_Delay25_n = localDW->Delay25_DSTATE;

  /* Delay: '<S176>/Delay26' */
  rtb_Delay26_a = localDW->Delay26_DSTATE;

  /* Sum: '<S176>/Sum of Elements' incorporates:
   *  Delay: '<S176>/Delay'
   *  Delay: '<S176>/Delay1'
   *  Delay: '<S176>/Delay10'
   *  Delay: '<S176>/Delay11'
   *  Delay: '<S176>/Delay12'
   *  Delay: '<S176>/Delay13'
   *  Delay: '<S176>/Delay14'
   *  Delay: '<S176>/Delay15'
   *  Delay: '<S176>/Delay16'
   *  Delay: '<S176>/Delay17'
   *  Delay: '<S176>/Delay18'
   *  Delay: '<S176>/Delay19'
   *  Delay: '<S176>/Delay2'
   *  Delay: '<S176>/Delay20'
   *  Delay: '<S176>/Delay21'
   *  Delay: '<S176>/Delay22'
   *  Delay: '<S176>/Delay23'
   *  Delay: '<S176>/Delay24'
   *  Delay: '<S176>/Delay25'
   *  Delay: '<S176>/Delay26'
   *  Delay: '<S176>/Delay27'
   *  Delay: '<S176>/Delay28'
   *  Delay: '<S176>/Delay3'
   *  Delay: '<S176>/Delay4'
   *  Delay: '<S176>/Delay5'
   *  Delay: '<S176>/Delay6'
   *  Delay: '<S176>/Delay7'
   *  Delay: '<S176>/Delay8'
   *  Delay: '<S176>/Delay9'
   *  Math: '<S176>/Math Function'
   *  Math: '<S176>/Math Function1'
   *  Math: '<S176>/Math Function10'
   *  Math: '<S176>/Math Function11'
   *  Math: '<S176>/Math Function12'
   *  Math: '<S176>/Math Function13'
   *  Math: '<S176>/Math Function14'
   *  Math: '<S176>/Math Function15'
   *  Math: '<S176>/Math Function16'
   *  Math: '<S176>/Math Function17'
   *  Math: '<S176>/Math Function18'
   *  Math: '<S176>/Math Function19'
   *  Math: '<S176>/Math Function2'
   *  Math: '<S176>/Math Function20'
   *  Math: '<S176>/Math Function21'
   *  Math: '<S176>/Math Function22'
   *  Math: '<S176>/Math Function23'
   *  Math: '<S176>/Math Function24'
   *  Math: '<S176>/Math Function25'
   *  Math: '<S176>/Math Function26'
   *  Math: '<S176>/Math Function27'
   *  Math: '<S176>/Math Function28'
   *  Math: '<S176>/Math Function29'
   *  Math: '<S176>/Math Function3'
   *  Math: '<S176>/Math Function4'
   *  Math: '<S176>/Math Function5'
   *  Math: '<S176>/Math Function6'
   *  Math: '<S176>/Math Function7'
   *  Math: '<S176>/Math Function8'
   *  Math: '<S176>/Math Function9'
   *
   * About '<S176>/Math Function':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function1':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function10':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function11':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function12':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function13':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function14':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function15':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function16':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function17':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function18':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function19':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function2':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function20':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function21':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function22':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function23':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function24':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function25':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function26':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function27':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function28':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function29':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function3':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function4':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function5':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function6':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function7':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function8':
   *  Operator: magnitude^2
   *
   * About '<S176>/Math Function9':
   *  Operator: magnitude^2
   */
  tmpForInput[0] = rtu_In1 * rtu_In1;
  tmpForInput[1] = localDW->Delay_DSTATE * localDW->Delay_DSTATE;
  tmpForInput[2] = localDW->Delay1_DSTATE * localDW->Delay1_DSTATE;
  tmpForInput[3] = localDW->Delay2_DSTATE * localDW->Delay2_DSTATE;
  tmpForInput[4] = localDW->Delay3_DSTATE * localDW->Delay3_DSTATE;
  tmpForInput[5] = localDW->Delay4_DSTATE * localDW->Delay4_DSTATE;
  tmpForInput[6] = localDW->Delay5_DSTATE * localDW->Delay5_DSTATE;
  tmpForInput[7] = localDW->Delay6_DSTATE * localDW->Delay6_DSTATE;
  tmpForInput[8] = localDW->Delay7_DSTATE * localDW->Delay7_DSTATE;
  tmpForInput[9] = localDW->Delay8_DSTATE * localDW->Delay8_DSTATE;
  tmpForInput[10] = localDW->Delay9_DSTATE * localDW->Delay9_DSTATE;
  tmpForInput[11] = localDW->Delay10_DSTATE * localDW->Delay10_DSTATE;
  tmpForInput[12] = localDW->Delay11_DSTATE * localDW->Delay11_DSTATE;
  tmpForInput[13] = localDW->Delay12_DSTATE * localDW->Delay12_DSTATE;
  tmpForInput[14] = localDW->Delay13_DSTATE * localDW->Delay13_DSTATE;
  tmpForInput[15] = localDW->Delay14_DSTATE * localDW->Delay14_DSTATE;
  tmpForInput[16] = localDW->Delay15_DSTATE * localDW->Delay15_DSTATE;
  tmpForInput[17] = localDW->Delay16_DSTATE * localDW->Delay16_DSTATE;
  tmpForInput[18] = localDW->Delay17_DSTATE * localDW->Delay17_DSTATE;
  tmpForInput[19] = localDW->Delay18_DSTATE * localDW->Delay18_DSTATE;
  tmpForInput[20] = localDW->Delay28_DSTATE * localDW->Delay28_DSTATE;
  tmpForInput[21] = localDW->Delay19_DSTATE * localDW->Delay19_DSTATE;
  tmpForInput[22] = localDW->Delay20_DSTATE * localDW->Delay20_DSTATE;
  tmpForInput[23] = localDW->Delay21_DSTATE * localDW->Delay21_DSTATE;
  tmpForInput[24] = localDW->Delay22_DSTATE * localDW->Delay22_DSTATE;
  tmpForInput[25] = localDW->Delay23_DSTATE * localDW->Delay23_DSTATE;
  tmpForInput[26] = localDW->Delay24_DSTATE * localDW->Delay24_DSTATE;
  tmpForInput[27] = localDW->Delay25_DSTATE * localDW->Delay25_DSTATE;
  tmpForInput[28] = localDW->Delay26_DSTATE * localDW->Delay26_DSTATE;
  tmpForInput[29] = localDW->Delay27_DSTATE * localDW->Delay27_DSTATE;
  rtb_Divide_kv = -0.0F;
  for (i = 0; i < 30; i++) {
    rtb_Divide_kv += tmpForInput[i];
  }

  /* End of Sum: '<S176>/Sum of Elements' */

  /* Product: '<S176>/Divide' */
  rtb_Divide_kv /= rtb_Saturation_de;

  /* Sqrt: '<S176>/Sqrt' */
  rty_Out2_0 = sqrtf(rtb_Divide_kv);

  /* Update for Memory: '<S176>/Memory3' */
  localDW->Memory3_PreviousInput = rtb_Saturation_de;

  /* Update for Delay: '<S176>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S176>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_de;

  /* Update for Delay: '<S176>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_h;

  /* Update for Delay: '<S176>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2_p;

  /* Update for Delay: '<S176>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3_dg;

  /* Update for Delay: '<S176>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4_e;

  /* Update for Delay: '<S176>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5_b;

  /* Update for Delay: '<S176>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6_o;

  /* Update for Delay: '<S176>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7_j;

  /* Update for Delay: '<S176>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8_m;

  /* Update for Delay: '<S176>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9_l;

  /* Update for Delay: '<S176>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10_p;

  /* Update for Delay: '<S176>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11_g;

  /* Update for Delay: '<S176>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12_h;

  /* Update for Delay: '<S176>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13_h;

  /* Update for Delay: '<S176>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14_d;

  /* Update for Delay: '<S176>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15_i;

  /* Update for Delay: '<S176>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16_h;

  /* Update for Delay: '<S176>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17_p;

  /* Update for Delay: '<S176>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18_i;

  /* Update for Delay: '<S176>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28_g;

  /* Update for Delay: '<S176>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19_a;

  /* Update for Delay: '<S176>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20_c;

  /* Update for Delay: '<S176>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21_a;

  /* Update for Delay: '<S176>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22_m;

  /* Update for Delay: '<S176>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23_l;

  /* Update for Delay: '<S176>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24_g;

  /* Update for Delay: '<S176>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25_n;

  /* Update for Delay: '<S176>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26_a;
  return rty_Out2_0;
}

/*
 * Output and update for action system:
 *    '<S183>/If Action Subsystem3'
 *    '<S428>/If Action Subsystem3'
 *    '<S468>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S187>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * System initialize for atomic system:
 *    '<S183>/Moving Standard Deviation1'
 *    '<S183>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation1_Init(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S188>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S183>/Moving Standard Deviation1'
 *    '<S183>/Moving Standard Deviation2'
 */
void MovingStandardDeviation1_Reset(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S188>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S188>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S183>/Moving Standard Deviation1'
 *    '<S183>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation1(float32 rtu_In1,
  DW_MovingStandardDeviation1_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_d4;
  float32 rtb_Delay1_n;
  float32 rtb_Delay10_k;
  float32 rtb_Delay11_d;
  float32 rtb_Delay12_a;
  float32 rtb_Delay13_g;
  float32 rtb_Delay14_e;
  float32 rtb_Delay15_c;
  float32 rtb_Delay16_l;
  float32 rtb_Delay17_nn;
  float32 rtb_Delay18_d;
  float32 rtb_Delay19_k;
  float32 rtb_Delay2_a;
  float32 rtb_Delay20_g;
  float32 rtb_Delay21_j;
  float32 rtb_Delay22_h;
  float32 rtb_Delay23_a;
  float32 rtb_Delay24_a;
  float32 rtb_Delay25_i;
  float32 rtb_Delay26_c;
  float32 rtb_Delay27_e;
  float32 rtb_Delay28_a;
  float32 rtb_Delay29_c;
  float32 rtb_Delay3_k;
  float32 rtb_Delay30_a;
  float32 rtb_Delay31_c;
  float32 rtb_Delay32_e;
  float32 rtb_Delay33_c;
  float32 rtb_Delay34_o;
  float32 rtb_Delay35_i;
  float32 rtb_Delay36_e;
  float32 rtb_Delay37_k;
  float32 rtb_Delay38_g;
  float32 rtb_Delay39_n;
  float32 rtb_Delay4_l;
  float32 rtb_Delay40_k;
  float32 rtb_Delay41_a;
  float32 rtb_Delay42_j;
  float32 rtb_Delay43_f;
  float32 rtb_Delay44_c;
  float32 rtb_Delay45_l;
  float32 rtb_Delay46_f;
  float32 rtb_Delay48_a;
  float32 rtb_Delay5_e;
  float32 rtb_Delay6_k;
  float32 rtb_Delay7_i;
  float32 rtb_Delay8_i;
  float32 rtb_Delay9_d;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S188>/Delay' */
  rtb_Delay_d4 = localDW->Delay_DSTATE;

  /* Delay: '<S188>/Delay1' */
  rtb_Delay1_n = localDW->Delay1_DSTATE;

  /* Delay: '<S188>/Delay10' */
  rtb_Delay10_k = localDW->Delay10_DSTATE;

  /* Delay: '<S188>/Delay11' */
  rtb_Delay11_d = localDW->Delay11_DSTATE;

  /* Delay: '<S188>/Delay12' */
  rtb_Delay12_a = localDW->Delay12_DSTATE;

  /* Delay: '<S188>/Delay13' */
  rtb_Delay13_g = localDW->Delay13_DSTATE;

  /* Delay: '<S188>/Delay14' */
  rtb_Delay14_e = localDW->Delay14_DSTATE;

  /* Delay: '<S188>/Delay15' */
  rtb_Delay15_c = localDW->Delay15_DSTATE;

  /* Delay: '<S188>/Delay16' */
  rtb_Delay16_l = localDW->Delay16_DSTATE;

  /* Delay: '<S188>/Delay17' */
  rtb_Delay17_nn = localDW->Delay17_DSTATE;

  /* Delay: '<S188>/Delay18' */
  rtb_Delay18_d = localDW->Delay18_DSTATE;

  /* Delay: '<S188>/Delay19' */
  rtb_Delay19_k = localDW->Delay19_DSTATE;

  /* Delay: '<S188>/Delay2' */
  rtb_Delay2_a = localDW->Delay2_DSTATE;

  /* Delay: '<S188>/Delay20' */
  rtb_Delay20_g = localDW->Delay20_DSTATE;

  /* Delay: '<S188>/Delay21' */
  rtb_Delay21_j = localDW->Delay21_DSTATE;

  /* Delay: '<S188>/Delay22' */
  rtb_Delay22_h = localDW->Delay22_DSTATE;

  /* Delay: '<S188>/Delay23' */
  rtb_Delay23_a = localDW->Delay23_DSTATE;

  /* Delay: '<S188>/Delay24' */
  rtb_Delay24_a = localDW->Delay24_DSTATE;

  /* Delay: '<S188>/Delay25' */
  rtb_Delay25_i = localDW->Delay25_DSTATE;

  /* Delay: '<S188>/Delay26' */
  rtb_Delay26_c = localDW->Delay26_DSTATE;

  /* Delay: '<S188>/Delay27' */
  rtb_Delay27_e = localDW->Delay27_DSTATE;

  /* Delay: '<S188>/Delay28' */
  rtb_Delay28_a = localDW->Delay28_DSTATE;

  /* Delay: '<S188>/Delay29' */
  rtb_Delay29_c = localDW->Delay29_DSTATE;

  /* Delay: '<S188>/Delay3' */
  rtb_Delay3_k = localDW->Delay3_DSTATE;

  /* Delay: '<S188>/Delay30' */
  rtb_Delay30_a = localDW->Delay30_DSTATE;

  /* Delay: '<S188>/Delay31' */
  rtb_Delay31_c = localDW->Delay31_DSTATE;

  /* Delay: '<S188>/Delay32' */
  rtb_Delay32_e = localDW->Delay32_DSTATE;

  /* Delay: '<S188>/Delay33' */
  rtb_Delay33_c = localDW->Delay33_DSTATE;

  /* Delay: '<S188>/Delay34' */
  rtb_Delay34_o = localDW->Delay34_DSTATE;

  /* Delay: '<S188>/Delay35' */
  rtb_Delay35_i = localDW->Delay35_DSTATE;

  /* Delay: '<S188>/Delay36' */
  rtb_Delay36_e = localDW->Delay36_DSTATE;

  /* Delay: '<S188>/Delay37' */
  rtb_Delay37_k = localDW->Delay37_DSTATE;

  /* Delay: '<S188>/Delay38' */
  rtb_Delay38_g = localDW->Delay38_DSTATE;

  /* Delay: '<S188>/Delay39' */
  rtb_Delay39_n = localDW->Delay39_DSTATE;

  /* Delay: '<S188>/Delay4' */
  rtb_Delay4_l = localDW->Delay4_DSTATE;

  /* Delay: '<S188>/Delay40' */
  rtb_Delay40_k = localDW->Delay40_DSTATE;

  /* Delay: '<S188>/Delay41' */
  rtb_Delay41_a = localDW->Delay41_DSTATE;

  /* Delay: '<S188>/Delay42' */
  rtb_Delay42_j = localDW->Delay42_DSTATE;

  /* Delay: '<S188>/Delay43' */
  rtb_Delay43_f = localDW->Delay43_DSTATE;

  /* Delay: '<S188>/Delay44' */
  rtb_Delay44_c = localDW->Delay44_DSTATE;

  /* Delay: '<S188>/Delay45' */
  rtb_Delay45_l = localDW->Delay45_DSTATE;

  /* Delay: '<S188>/Delay46' */
  rtb_Delay46_f = localDW->Delay46_DSTATE;

  /* Delay: '<S188>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S188>/Delay48' */
  rtb_Delay48_a = localDW->Delay48_DSTATE;

  /* Delay: '<S188>/Delay5' */
  rtb_Delay5_e = localDW->Delay5_DSTATE;

  /* Delay: '<S188>/Delay6' */
  rtb_Delay6_k = localDW->Delay6_DSTATE;

  /* Delay: '<S188>/Delay7' */
  rtb_Delay7_i = localDW->Delay7_DSTATE;

  /* Delay: '<S188>/Delay8' */
  rtb_Delay8_i = localDW->Delay8_DSTATE;

  /* Delay: '<S188>/Delay9' */
  rtb_Delay9_d = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S188>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_d4;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_n;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2_a;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3_k;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4_l;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5_e;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6_k;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7_i;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8_i;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9_d;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10_k;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11_d;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12_a;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13_g;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14_e;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15_c;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16_l;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17_nn;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18_d;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28_a;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19_k;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20_g;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21_j;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22_h;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23_a;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24_a;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25_i;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26_c;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27_e;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38_g;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29_c;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30_a;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31_c;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32_e;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33_c;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34_o;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35_i;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36_e;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37_k;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48_a;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39_n;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40_k;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41_a;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42_j;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43_f;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44_c;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45_l;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46_f;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S188>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S188>/Standard Deviation' */

  /* Update for Delay: '<S188>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S188>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_d4;

  /* Update for Delay: '<S188>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9_d;

  /* Update for Delay: '<S188>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10_k;

  /* Update for Delay: '<S188>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11_d;

  /* Update for Delay: '<S188>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12_a;

  /* Update for Delay: '<S188>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13_g;

  /* Update for Delay: '<S188>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14_e;

  /* Update for Delay: '<S188>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15_c;

  /* Update for Delay: '<S188>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16_l;

  /* Update for Delay: '<S188>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17_nn;

  /* Update for Delay: '<S188>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28_a;

  /* Update for Delay: '<S188>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_n;

  /* Update for Delay: '<S188>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19_k;

  /* Update for Delay: '<S188>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20_g;

  /* Update for Delay: '<S188>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21_j;

  /* Update for Delay: '<S188>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22_h;

  /* Update for Delay: '<S188>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23_a;

  /* Update for Delay: '<S188>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24_a;

  /* Update for Delay: '<S188>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25_i;

  /* Update for Delay: '<S188>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26_c;

  /* Update for Delay: '<S188>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18_d;

  /* Update for Delay: '<S188>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38_g;

  /* Update for Delay: '<S188>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2_a;

  /* Update for Delay: '<S188>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29_c;

  /* Update for Delay: '<S188>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30_a;

  /* Update for Delay: '<S188>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31_c;

  /* Update for Delay: '<S188>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32_e;

  /* Update for Delay: '<S188>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33_c;

  /* Update for Delay: '<S188>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34_o;

  /* Update for Delay: '<S188>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35_i;

  /* Update for Delay: '<S188>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36_e;

  /* Update for Delay: '<S188>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27_e;

  /* Update for Delay: '<S188>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48_a;

  /* Update for Delay: '<S188>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3_k;

  /* Update for Delay: '<S188>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39_n;

  /* Update for Delay: '<S188>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40_k;

  /* Update for Delay: '<S188>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41_a;

  /* Update for Delay: '<S188>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42_j;

  /* Update for Delay: '<S188>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43_f;

  /* Update for Delay: '<S188>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44_c;

  /* Update for Delay: '<S188>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45_l;

  /* Update for Delay: '<S188>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46_f;

  /* Update for Delay: '<S188>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37_k;

  /* Update for Delay: '<S188>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4_l;

  /* Update for Delay: '<S188>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5_e;

  /* Update for Delay: '<S188>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6_k;

  /* Update for Delay: '<S188>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7_i;

  /* Update for Delay: '<S188>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8_i;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S183>/Sum Condition'
 *    '<S183>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S190>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S183>/Sum Condition'
 *    '<S183>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S190>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S183>/Sum Condition'
 *    '<S183>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S183>/Sum Condition' incorporates:
   *  EnablePort: '<S190>/Enable'
   */
  /* Disable for Outport: '<S190>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S183>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S183>/Sum Condition'
 *    '<S183>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_mw;

  /* Outputs for Enabled SubSystem: '<S183>/Sum Condition' incorporates:
   *  EnablePort: '<S190>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S190>/Add1' incorporates:
     *  Memory: '<S190>/Memory'
     */
    rtb_Saturation_mw = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S190>/Saturation' */
    if (rtb_Saturation_mw > 100.0F) {
      rtb_Saturation_mw = 100.0F;
    } else {
      if (rtb_Saturation_mw < 0.0F) {
        rtb_Saturation_mw = 0.0F;
      }
    }

    /* End of Saturate: '<S190>/Saturation' */

    /* RelationalOperator: '<S190>/Relational Operator' */
    *rty_Out = (rtb_Saturation_mw >= rtu_In1);

    /* Update for Memory: '<S190>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_mw;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S183>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S202>/If Action Subsystem2'
 *    '<S202>/If Action Subsystem1'
 *    '<S203>/If Action Subsystem2'
 *    '<S203>/If Action Subsystem1'
 *    '<S204>/If Action Subsystem2'
 *    '<S204>/If Action Subsystem1'
 *    '<S205>/If Action Subsystem2'
 *    '<S205>/If Action Subsystem1'
 *    '<S206>/If Action Subsystem2'
 *    '<S206>/If Action Subsystem1'
 *    ...
 */
void LKAS_IfActionSubsystem2_f(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S216>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S207>/if action '
 *    '<S208>/if action '
 *    '<S209>/if action '
 *    '<S210>/if action '
 *    '<S211>/if action '
 *    '<S212>/if action '
 *    '<S213>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S230>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S246>/If Action Subsystem'
 *    '<S246>/If Action Subsystem4'
 *    '<S198>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S248>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system: '<S152>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S152>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  float32 K1K2Det_T1;
  float32 DelteSW0;
  float32 u;
  float32 KMax;
  float32 DelteSW1;
  float32 tmp;

  /* MATLAB Function: '<S194>/MATLABFunction1' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLABFunction1': '<S201>:1' */
  /* '<S201>:1:34' LDDir = K1K2Det_stLDDir; */
  /*     D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S201>:1:36' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_f * 0.0174532924F;

  /* '<S201>:1:37' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S201>:1:38' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S201>:1:39' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S201>:1:40' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S201>:1:41' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S201>:1:42' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_h / 3.6F;

  /* '<S201>:1:43' Kw= u/(L*(1+K*u*u)*i); */
  /* '<S201>:1:44' KMax = K1K2Det_dphiSWARMax/180*pi; */
  KMax = (LKAS_DW.MPInP_dphiSWARMax / 180.0F) * 3.14159274F;

  /* '<S201>:1:45' Delte_Psi1 = PrvwHdAg; */
  /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
  /* '<S201>:1:47' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
  u = ((-2.0F * LKAS_DW.In_mp) / (((u / (((((LKAS_DW.MPInP_StbFacm_SY * u) * u)
             + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_o) * LKAS_DW.LKA_StrRatio_C_c)) *
         LKAS_DW.MPInP_tiTTLCIni) * LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F *
    DelteSW0) / LKAS_DW.MPInP_tiTTLCIni);

  /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
  /* '<S201>:1:49' DelteSW1 = DelteSW0+K1*TTLC; */
  DelteSW1 = (u * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

  /* '<S201>:1:50' K1K2Det_T1 = TTLC; */
  K1K2Det_T1 = LKAS_DW.MPInP_tiTTLCIni;

  /* '<S201>:1:51' if ~(K1<abs(KMax) && K1>-abs(KMax)) */
  tmp = fabsf(KMax);
  if ((u >= tmp) || (u <= (-tmp))) {
    /*  ������ת������ */
    /* '<S201>:1:52' K1 = LDDir*KMax; */
    u = LKAS_DW.Merge * KMax;

    /* '<S201>:1:53' K1K2Det_T1 = max((-DelteSW0+sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1,(-DelteSW0-sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1); */
    KMax = sqrtf((DelteSW0 * DelteSW0) - ((2.0F * u) * LKAS_DW.In_mp));
    K1K2Det_T1 = fmaxf((KMax + (-DelteSW0)) / u, ((-DelteSW0) - KMax) / u);

    /* '<S201>:1:54' DelteSW1 = (K1*K1K2Det_T1+DelteSW0); */
    DelteSW1 = (u * K1K2Det_T1) + DelteSW0;
  }

  /* '<S201>:1:56' if LDDir>0 && K1<0 && DelteSW0>0 && Delte_Psi1<0 */
  if ((((LKAS_DW.Merge > 0.0F) && (u < 0.0F)) && (DelteSW0 > 0.0F)) &&
      (LKAS_DW.In_mp < 0.0F)) {
    /* '<S201>:1:57' K1 = single(0); */
    u = 0.0F;

    /* '<S201>:1:58' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S201>:1:59' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_mp) / DelteSW0;
  }

  /* '<S201>:1:61' if LDDir<0 && K1>0 && DelteSW0<0 && Delte_Psi1>0 */
  if ((((LKAS_DW.Merge < 0.0F) && (u > 0.0F)) && (DelteSW0 < 0.0F)) &&
      (LKAS_DW.In_mp > 0.0F)) {
    /* '<S201>:1:62' K1 = single(0); */
    u = 0.0F;

    /* '<S201>:1:63' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S201>:1:64' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_mp) / DelteSW0;
  }

  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S201>:1:67' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S201>:1:69' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = u * 57.2957802F;
  LKAS_DW.K1K2Det_T1 = K1K2Det_T1;

  /* End of MATLAB Function: '<S194>/MATLABFunction1' */
}

/*
 * Output and update for atomic system:
 *    '<S256>/Saturable Gain Lut (SatGainLut)'
 *    '<S256>/Saturable Gain Lut (SatGainLut)1'
 */
void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32 rtu_InputLimLwr,
  float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32 rtu_GainLimUpr,
  float32 *rty_Gain)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S259>:1' */
  /*  Function Name: Saturable Gain Lut */
  /*  */
  /*  Description:  */
  /*    Saturable Gain Lookup Table. */
  /*  */
  /*  Assumptions and Limitation: */
  /*    The data type of all inputs and output is single. */
  /*  */
  /*  Inputs: */
  /*    Input: */
  /*    InputLimLwr: */
  /*    InputLimUpr: */
  /*    GainLimLwr: */
  /*    GainLimUpr: */
  /*  */
  /*  Outputs: */
  /*    Gain: The result of Looking up table. */
  /*  $Revision: 1.0$ */
  /*  $Author: Zhang Jianwei$ */
  /*  $Date: January 27, 2019$ */
  /*  ________________________________________ */
  /* '<S259>:1:25' if Input <= InputLimLwr */
  if (rtu_Input <= rtu_InputLimLwr) {
    /* '<S259>:1:26' Gain = GainLimLwr; */
    *rty_Gain = rtu_GainLimLwr;
  } else if (rtu_Input >= rtu_InputLimUpr) {
    /* '<S259>:1:27' elseif Input >= InputLimUpr */
    /* '<S259>:1:28' Gain = GainLimUpr; */
    *rty_Gain = rtu_GainLimUpr;
  } else {
    /* '<S259>:1:29' else */
    /* '<S259>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
    /* '<S259>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
    *rty_Gain = (((rtu_Input - rtu_InputLimLwr) / (rtu_InputLimUpr -
      rtu_InputLimLwr)) * (rtu_GainLimUpr - rtu_GainLimLwr)) + rtu_GainLimLwr;
  }
}

/*
 * Output and update for action system:
 *    '<S263>/If Action Subsystem'
 *    '<S263>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_d(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S265>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S286>/if action '
 *    '<S287>/if action '
 *    '<S294>/if action '
 *    '<S295>/if action '
 */
void LKAS_ifaction_g(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S288>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S279>/If Action Subsystem'
 *    '<S280>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_f(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_c_T *localDW)
{
  uint16 rtb_Saturation1_mn;
  uint16 rtb_Saturation1_cq;

  /* Outputs for Enabled SubSystem: '<S279>/If Action Subsystem' incorporates:
   *  EnablePort: '<S284>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S286>/Add' incorporates:
     *  Constant: '<S286>/Constant'
     *  Memory: '<S286>/Memory'
     */
    rtb_Saturation1_mn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S286>/Saturation1' */
    if (rtb_Saturation1_mn >= ((uint16)10000U)) {
      rtb_Saturation1_mn = ((uint16)10000U);
    }

    /* End of Saturate: '<S286>/Saturation1' */

    /* If: '<S286>/If' incorporates:
     *  Constant: '<S286>/Constant2'
     */
    if (rtb_Saturation1_mn <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S286>/if action ' incorporates:
       *  ActionPort: '<S288>/Action Port'
       */
      LKAS_ifaction_g(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S286>/if action ' */
    }

    /* End of If: '<S286>/If' */

    /* Sum: '<S287>/Add' incorporates:
     *  Constant: '<S287>/Constant'
     *  Memory: '<S287>/Memory'
     */
    rtb_Saturation1_cq = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_m));

    /* Saturate: '<S287>/Saturation1' */
    if (rtb_Saturation1_cq >= ((uint16)10000U)) {
      rtb_Saturation1_cq = ((uint16)10000U);
    }

    /* End of Saturate: '<S287>/Saturation1' */

    /* If: '<S287>/If' incorporates:
     *  Constant: '<S287>/Constant2'
     */
    if (rtb_Saturation1_cq == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S287>/if action ' incorporates:
       *  ActionPort: '<S289>/Action Port'
       */
      LKAS_ifaction_g(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S287>/if action ' */
    }

    /* End of If: '<S287>/If' */

    /* Update for Memory: '<S286>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_mn;

    /* Update for Memory: '<S287>/Memory' */
    localDW->Memory_PreviousInput_m = rtb_Saturation1_cq;
  }

  /* End of Outputs for SubSystem: '<S279>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S279>/If Action Subsystem2'
 *    '<S280>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_i(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S285>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S285>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S143>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_p = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c63_LKAS = 0U;
  LKAS_DW.is_c63_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.stLDWActvFlg = 0U;
  LKAS_DW.stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S143>/LDW_State_Machine'
 * Block description for: '<S143>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S143>/LDW_State_Machine'
   *
   * Block description for '<S143>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c63_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c63_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S347>:2' */
    LKAS_DW.is_c63_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S347>:1' */
    /* Transition: '<S347>:31' */
    LKAS_DW.is_SysOff_p = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S347>:30' */
    LKAS_DW.stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c63_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S347>:36' */
      tmp = !LKAS_DW.LDW_Fault;
      if (tmp && ((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)
             LKAS_DW.LKA_Mode_k) == 2))) {
        /* Transition: '<S347>:38' */
        /* Exit Internal 'Fault': '<S347>:36' */
        LKAS_DW.is_c63_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S347>:3' */
        /* Transition: '<S347>:77' */
        LKAS_DW.is_SysOn_n = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S347>:47' */
        LKAS_DW.stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.LKA_Mode_k) == 0) && tmp) {
        /* Transition: '<S347>:40' */
        /* Exit Internal 'Fault': '<S347>:36' */
        LKAS_DW.is_c63_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_p = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S347>:32' */
        LKAS_DW.stLDWState = 1U;
      } else {
        LKAS_DW.stLDWState = 6U;

        /* During 'LDWFault': '<S347>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S347>:1' */
      if (((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
            2)) && (LKAS_DW.LDW_Fault)) {
        /* Transition: '<S347>:39' */
        /* Exit Internal 'SysOff': '<S347>:1' */
        LKAS_DW.is_SysOff_p = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c63_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S347>:36' */
        /* Transition: '<S347>:75' */
        /* Entry 'LDWFault': '<S347>:73' */
        LKAS_DW.stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)
                   LKAS_DW.LKA_Mode_k) == 2)) {
        /* Transition: '<S347>:41' */
        /* Exit Internal 'SysOff': '<S347>:1' */
        LKAS_DW.is_SysOff_p = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c63_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S347>:3' */
        /* Transition: '<S347>:77' */
        LKAS_DW.is_SysOn_n = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S347>:47' */
        LKAS_DW.stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_p) == LKAS_IN_Unavailable) {
        LKAS_DW.stLDWState = 0U;

        /* During 'Unavailable': '<S347>:30' */
        if (((sint32)LKAS_DW.LKA_Mode_k) == 0) {
          /* Transition: '<S347>:35' */
          LKAS_DW.is_SysOff_p = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S347>:32' */
          LKAS_DW.stLDWState = 1U;
        }
      } else {
        LKAS_DW.stLDWState = 1U;

        /* During 'Unselected': '<S347>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S347>:3' */
      if (LKAS_DW.LDW_Fault) {
        /* Transition: '<S347>:37' */
        /* Exit Internal 'SysOn': '<S347>:3' */
        if (((uint32)LKAS_DW.is_SysOn_n) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S347>:102' */
          switch (LKAS_DW.is_Normal_g) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S347>:114' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S347>:115' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c63_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S347>:36' */
        /* Transition: '<S347>:75' */
        /* Entry 'LDWFault': '<S347>:73' */
        LKAS_DW.stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode_k) != 1) && (((sint32)
                   LKAS_DW.LKA_Mode_k) != 2)) {
        /* Transition: '<S347>:42' */
        /* Exit Internal 'SysOn': '<S347>:3' */
        if (((uint32)LKAS_DW.is_SysOn_n) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S347>:102' */
          switch (LKAS_DW.is_Normal_g) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S347>:114' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S347>:115' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c63_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_p = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S347>:32' */
        LKAS_DW.stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_n) == LKAS_IN_LDWSelected) {
        LKAS_DW.stLDWState = 2U;

        /* During 'LDWSelected': '<S347>:47' */
        if ((LKAS_DW.Merge_k) && (!LKAS_DW.Merge1_p)) {
          /* Transition: '<S347>:50' */
          LKAS_DW.is_SysOn_n = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S347>:102' */
          /* Transition: '<S347>:113' */
          LKAS_DW.is_Normal_g = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S347>:112' */
          LKAS_DW.stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S347>:102' */
        if (LKAS_DW.Merge1_p) {
          /* Transition: '<S347>:44' */
          /* Exit Internal 'Normal': '<S347>:102' */
          switch (LKAS_DW.is_Normal_g) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S347>:114' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S347>:115' */
            LKAS_DW.stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_n = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S347>:47' */
          LKAS_DW.stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_g) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.stLDWState = 3U;

            /* During 'LDWEnable': '<S347>:112' */
            if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.LKA_Fault))
            {
              /* Transition: '<S347>:118' */
              LKAS_DW.is_Normal_g = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S347>:114' */
              LKAS_DW.stLDWState = 4U;
              LKAS_DW.stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S347>:119' */
                LKAS_DW.is_Normal_g = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S347>:115' */
                LKAS_DW.stLDWState = 5U;
                LKAS_DW.stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.stLDWState = 4U;

            /* During 'LDWLeftActive': '<S347>:114' */
            if (LKAS_DW.LKA_Fault) {
              /* Transition: '<S347>:116' */
              /* Exit 'LDWLeftActive': '<S347>:114' */
              LKAS_DW.stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_g = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S347>:112' */
              LKAS_DW.stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S347>:120' */
                /* Exit 'LDWLeftActive': '<S347>:114' */
                LKAS_DW.is_Normal_g = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S347>:115' */
                LKAS_DW.stLDWState = 5U;
                LKAS_DW.stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.stLDWState = 5U;

            /* During 'LDWRightActive': '<S347>:115' */
            if (LKAS_DW.LKA_Fault) {
              /* Transition: '<S347>:117' */
              /* Exit 'LDWRightActive': '<S347>:115' */
              LKAS_DW.stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_g = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S347>:112' */
              LKAS_DW.stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S347>:121' */
                /* Exit 'LDWRightActive': '<S347>:115' */
                LKAS_DW.is_Normal_g = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S347>:114' */
                LKAS_DW.stLDWState = 4U;
                LKAS_DW.stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S143>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S143>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_d;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_d;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
  LKAS_DW.is_active_c64_LKAS = 0U;
  LKAS_DW.is_c64_LKAS = LKAS_IN_NO_ACTIVE_CHILD_d;
  LKAS_DW.stLKAActvFlg = 0U;
  LKAS_DW.stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S143>/LKA_State_Machine'
 * Block description for: '<S143>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S143>/LKA_State_Machine'
   *
   * Block description for '<S143>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  if (((uint32)LKAS_DW.is_active_c64_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    LKAS_DW.is_active_c64_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    /* Transition: '<S348>:2' */
    LKAS_DW.is_c64_LKAS = LKAS_IN_SysOff_j;

    /* Entry Internal 'SysOff': '<S348>:1' */
    /* Transition: '<S348>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_i;

    /* Entry 'Unavailable': '<S348>:30' */
    LKAS_DW.stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c64_LKAS) {
     case LKAS_IN_Fault_j:
      /* During 'Fault': '<S348>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.LKA_Mode_k) == 2)) {
        /* Transition: '<S348>:38' */
        /* Exit Internal 'Fault': '<S348>:36' */
        LKAS_DW.is_c64_LKAS = LKAS_IN_SysOn_o;

        /* Entry Internal 'SysOn': '<S348>:3' */
        /* Transition: '<S348>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S348>:19' */
        LKAS_DW.stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.LKA_Mode_k) == 0) || (((sint32)
                    LKAS_DW.LKA_Mode_k) == 1)) && tmp) {
        /* Transition: '<S348>:40' */
        /* Exit Internal 'Fault': '<S348>:36' */
        LKAS_DW.is_c64_LKAS = LKAS_IN_SysOff_j;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_f;

        /* Entry 'Unselected': '<S348>:32' */
        LKAS_DW.stLKAState = 1U;
      } else {
        LKAS_DW.stLKAState = 6U;

        /* During 'LKAFault': '<S348>:72' */
      }
      break;

     case LKAS_IN_SysOff_j:
      /* During 'SysOff': '<S348>:1' */
      if ((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S348>:39' */
        /* Exit Internal 'SysOff': '<S348>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_d;
        LKAS_DW.is_c64_LKAS = LKAS_IN_Fault_j;

        /* Entry Internal 'Fault': '<S348>:36' */
        /* Transition: '<S348>:74' */
        /* Entry 'LKAFault': '<S348>:72' */
        LKAS_DW.stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode_k) == 2) {
        /* Transition: '<S348>:41' */
        /* Exit Internal 'SysOff': '<S348>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_d;
        LKAS_DW.is_c64_LKAS = LKAS_IN_SysOn_o;

        /* Entry Internal 'SysOn': '<S348>:3' */
        /* Transition: '<S348>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S348>:19' */
        LKAS_DW.stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_i) {
        LKAS_DW.stLKAState = 0U;

        /* During 'Unavailable': '<S348>:30' */
        if ((((sint32)LKAS_DW.LKA_Mode_k) == 0) || (((sint32)LKAS_DW.LKA_Mode_k)
             == 1)) {
          /* Transition: '<S348>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_f;

          /* Entry 'Unselected': '<S348>:32' */
          LKAS_DW.stLKAState = 1U;
        }
      } else {
        LKAS_DW.stLKAState = 1U;

        /* During 'Unselected': '<S348>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S348>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S348>:37' */
        /* Exit Internal 'SysOn': '<S348>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_f) {
          /* Exit Internal 'Normal': '<S348>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S348>:109' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S348>:110' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_d;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_d;
        }

        LKAS_DW.is_c64_LKAS = LKAS_IN_Fault_j;

        /* Entry Internal 'Fault': '<S348>:36' */
        /* Transition: '<S348>:74' */
        /* Entry 'LKAFault': '<S348>:72' */
        LKAS_DW.stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode_k) != 2) {
        /* Transition: '<S348>:42' */
        /* Exit Internal 'SysOn': '<S348>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_f) {
          /* Exit Internal 'Normal': '<S348>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S348>:109' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S348>:110' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_d;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_d;
        }

        LKAS_DW.is_c64_LKAS = LKAS_IN_SysOff_j;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_f;

        /* Entry 'Unselected': '<S348>:32' */
        LKAS_DW.stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.stLKAState = 2U;

        /* During 'LKASelected': '<S348>:19' */
        if ((LKAS_DW.Merge1_e) && (!LKAS_DW.Merge2)) {
          /* Transition: '<S348>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_f;

          /* Entry Internal 'Normal': '<S348>:102' */
          /* Transition: '<S348>:103' */
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S348>:108' */
          LKAS_DW.stLKAState = 3U;
        }
      } else {
        /* During 'Normal': '<S348>:102' */
        if (LKAS_DW.Merge2) {
          /* Transition: '<S348>:25' */
          /* Exit Internal 'Normal': '<S348>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S348>:109' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S348>:110' */
            LKAS_DW.stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_d;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

          /* Entry 'LKASelected': '<S348>:19' */
          LKAS_DW.stLKAState = 2U;
        } else {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKAEnable:
            LKAS_DW.stLKAState = 3U;

            /* During 'LKAEnable': '<S348>:108' */
            if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_c)) {
              /* Transition: '<S348>:105' */
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

              /* Entry 'LKALeftActive': '<S348>:109' */
              LKAS_DW.stLKAState = 4U;
              LKAS_DW.stLKAActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S348>:104' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S348>:110' */
                LKAS_DW.stLKAState = 5U;
                LKAS_DW.stLKAActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LKALeftActive:
            LKAS_DW.stLKAState = 4U;

            /* During 'LKALeftActive': '<S348>:109' */
            if (LKAS_DW.Merge1_c) {
              /* Transition: '<S348>:106' */
              /* Exit 'LKALeftActive': '<S348>:109' */
              LKAS_DW.stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S348>:108' */
              LKAS_DW.stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S348>:111' */
                /* Exit 'LKALeftActive': '<S348>:109' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S348>:110' */
                LKAS_DW.stLKAState = 5U;
                LKAS_DW.stLKAActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.stLKAState = 5U;

            /* During 'LKARightActive': '<S348>:110' */
            if (LKAS_DW.Merge1_c) {
              /* Transition: '<S348>:107' */
              /* Exit 'LKARightActive': '<S348>:110' */
              LKAS_DW.stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S348>:108' */
              LKAS_DW.stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S348>:112' */
                /* Exit 'LKARightActive': '<S348>:110' */
                LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

                /* Entry 'LKALeftActive': '<S348>:109' */
                LKAS_DW.stLKAState = 4U;
                LKAS_DW.stLKAActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S143>/LKA_State_Machine' */
}

/*
 * Output and update for action system:
 *    '<S369>/Ph1SWA'
 *    '<S378>/Ph1SWA'
 *    '<S405>/Ph1SWA'
 *    '<S415>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S373>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S373>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S369>/Ph2SWA'
 *    '<S378>/Ph2SWA'
 *    '<S405>/Ph2SWA'
 *    '<S415>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S374>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S374>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S369>/Ph3SWA'
 *    '<S405>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S375>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S378>/Ph3SWA'
 *    '<S415>/Ph3SWA'
 */
void LKAS_Ph3SWA_m(float32 *rty_Out)
{
  /* SignalConversion: '<S384>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S384>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S441>/If Action Subsystem4'
 *    '<S441>/If Action Subsystem3'
 *    '<S551>/If Action Subsystem3'
 *    '<S551>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S453>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S453>/Constant'
   */
  *rty_Out = false;
}

/*
 * System initialize for enable system:
 *    '<S456>/ExitCount'
 *    '<S456>/ExitCount1'
 */
void LKAS_ExitCount_Init(DW_ExitCount_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S464>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S456>/ExitCount'
 *    '<S456>/ExitCount1'
 */
void LKAS_ExitCount_Reset(DW_ExitCount_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S464>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S456>/ExitCount'
 *    '<S456>/ExitCount1'
 */
void LKAS_ExitCount_Disable(boolean *rty_Out, DW_ExitCount_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S456>/ExitCount' incorporates:
   *  EnablePort: '<S464>/Enable'
   */
  /* Disable for Outport: '<S464>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S456>/ExitCount' */
  localDW->ExitCount_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S456>/ExitCount'
 *    '<S456>/ExitCount1'
 */
void LKAS_ExitCount(boolean rtu_Enable, float32 rtu_SampleTime, float32
                    rtu_ExitTime, boolean *rty_Out, DW_ExitCount_LKAS_T *localDW)
{
  float32 rtb_Saturation_n;

  /* Outputs for Enabled SubSystem: '<S456>/ExitCount' incorporates:
   *  EnablePort: '<S464>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->ExitCount_MODE) {
      LKAS_ExitCount_Reset(localDW);
      localDW->ExitCount_MODE = true;
    }

    /* Sum: '<S464>/Add' incorporates:
     *  Memory: '<S464>/Memory'
     */
    rtb_Saturation_n = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S464>/Saturation' */
    if (rtb_Saturation_n > 60.0F) {
      rtb_Saturation_n = 60.0F;
    } else {
      if (rtb_Saturation_n < 0.0F) {
        rtb_Saturation_n = 0.0F;
      }
    }

    /* End of Saturate: '<S464>/Saturation' */

    /* RelationalOperator: '<S464>/Relational Operator' */
    *rty_Out = (rtb_Saturation_n >= rtu_ExitTime);

    /* Update for Memory: '<S464>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_n;
  } else {
    if (localDW->ExitCount_MODE) {
      LKAS_ExitCount_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S456>/ExitCount' */
}

/*
 * Output and update for action system:
 *    '<S477>/If Action Subsystem'
 *    '<S477>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_fo(boolean *rty_Out)
{
  /* SignalConversion: '<S481>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S481>/Constant'
   */
  *rty_Out = true;
}

/*
 * Output and update for atomic system:
 *    '<S565>/MATLAB Function'
 *    '<S584>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_LKA_EnableLine_Max, float32
  rtu_LaneWid_DvtMin, float32 rtu_LaneWid_DvtMax, float32 rtu_LaneWidth, float32
  rtu_LKA_CarWidth, float32 *rty_LKA_Enable_Line)
{
  float32 LanWidmin;
  float32 LanWidmax;

  /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Enable Condition  (EnaC)/LDW Own Condition (LDWOwnC)/Vehicle Position Check (VehPosChk)/Subsystem1/MATLAB Function': '<S566>:1' */
  /* '<S566>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*LaneWid_DvtMin); */
  LanWidmin = (2.0F * rtu_LaneWid_DvtMin) + rtu_LKA_CarWidth;

  /* '<S566>:1:3' LanWidmax = single(LKA_CarWidth+single(2)*LaneWid_DvtMax); */
  LanWidmax = (2.0F * rtu_LaneWid_DvtMax) + rtu_LKA_CarWidth;

  /* '<S566>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
  /*   LKA_Enable_Line = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
  /* '<S566>:1:6' LKA_Enable_Line = LKA_EnableLine_Max*(single(LanWid-LanWidmin))/single(LanWidmax-LanWidmin); */
  *rty_LKA_Enable_Line = ((fminf(fmaxf(LanWidmin, rtu_LaneWidth), LanWidmax) -
    LanWidmin) * rtu_LKA_EnableLine_Max) / (LanWidmax - LanWidmin);
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPva_g_obj_acc_x[40];
  float32 rtb_IMAPva_g_obj_acc_y[40];
  float32 rtb_IMAPva_g_obj_length[40];
  float32 rtb_IMAPva_g_obj_pos_var_x[40];
  float32 rtb_IMAPva_g_obj_pos_var_xy[40];
  float32 rtb_IMAPva_g_obj_pos_var_y[40];
  float32 rtb_IMAPva_g_obj_pos_x[40];
  float32 rtb_IMAPva_g_obj_pos_y[40];
  float32 rtb_IMAPva_g_obj_vel_x[40];
  float32 rtb_IMAPva_g_obj_vel_y[40];
  float32 rtb_IMAPva_g_obj_width[40];
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_ESC_VehSpd;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_Gain_a;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_LL_LKA_EnableLine_Max;
  float32 rtb_LL_LKA_EnableLine_DvtMin;
  float32 rtb_LL_LKA_EnableLine_DvtMax;
  float32 rtb_Gain_jm;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_MAX_DELAY_EPSSTAR_TIME;
  float32 rtb_LL_HandsOff_ExitTime;
  float32 rtb_LL_LFClb_TFC_KpVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KpVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KpV1_C;
  float32 rtb_LL_LFClb_TFC_KpV2_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KdV1_C;
  float32 rtb_LL_LFClb_TFC_KdV2_C;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_LL_HandsOff_WarnTime;
  float32 rtb_LL_HandsOff_TextTime;
  float32 rtb_R0_VR_p;
  float32 rtb_L0_VR_b;
  float32 rtb_R0_W_f;
  float32 rtb_L0_W_f;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_R1_VR;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_VR_i;
  float32 rtb_R1_W;
  float32 rtb_R1_VR_d;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_lStpLngth_C;
  float32 rtb_LL_DesDvt_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_l;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1;
  float32 rtb_phiHdAg_Lft;
  float32 rtb_Add5_g;
  float32 rtb_phiHdAg_Rgt;
  float32 rtb_Add_gv;
  float32 rtb_Add_a;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge;
  float32 rtb_Switch_h;
  float32 rtb_Saturation_j;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Switch_f;
  float32 rtb_Switch2_d;
  float32 rtb_Switch_m;
  float32 rtb_Saturation_l;
  float32 rtb_Abs1_b;
  float32 rtb_Abs_k;
  float32 rtb_UnaryMinus_m;
  float32 rtb_Divide_e;
  float32 rtb_Merge1;
  float32 rtb_Divide_h;
  float32 rtb_Switch_p;
  float32 rtb_Switch2_m;
  float32 rtb_Divide_g;
  float32 rtb_Switch_pc;
  float32 rtb_Switch2_k;
  float32 rtb_Merge1_h;
  float32 rtb_Divide_a;
  float32 rtb_Switch_eo;
  float32 rtb_Switch2_e;
  float32 rtb_Divide_on;
  float32 rtb_Switch_g;
  float32 rtb_Switch2_g;
  float32 rtb_Switch_e0;
  float32 rtb_Switch2_i;
  float32 rtb_Memory;
  float32 rtb_Merge1_a;
  float32 rtb_Divide_pi;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_iy;
  float32 rtb_Divide_c;
  float32 rtb_Switch_k;
  float32 rtb_Switch2_id;
  float32 rtb_Memory_a;
  float32 rtb_Merge1_d;
  float32 rtb_Divide_hn;
  float32 rtb_Switch_d;
  float32 rtb_Switch2_mr;
  float32 rtb_Divide_ha;
  float32 rtb_Switch_a;
  float32 rtb_Switch2_e2;
  float32 rtb_Saturation_e;
  float32 rtb_Divide_l;
  float32 rtb_Divide_k;
  float32 rtb_Add_ohd;
  float32 rtb_Add_k;
  float32 rtb_phiHdAg;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_LKA_Enable_Line;
  float32 rtb_LKA_Enable_Line_g;
  float32 rtb_Saturation2_p;
  float32 rtb_Add1_b;
  float32 rtb_Merge_g;
  float32 rtb_Gain_db;
  float32 rtb_Gain1_d5;
  float32 rtb_Add_ed;
  float32 rtb_Add_jv;
  float32 rtb_Saturation6;
  float32 rtb_Saturation2_pb;
  float32 rtb_Saturation2_a;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_f;
  float32 rtb_Yk1_k;
  float32 rtb_Saturation1_g;
  float32 rtb_deltariselimit_g;
  float32 rtb_Yk1_j;
  float32 rtb_deltariselimit_l;
  float32 rtb_Switch1;
  float32 rtb_UkYk1_p;
  float32 rtb_deltafalllimit_b;
  float32 rtb_Switch_dy;
  float32 rtb_Switch2_a;
  float32 rtb_DifferenceInputs2_k;
  float32 rtb_UkYk1_a;
  float32 rtb_deltafalllimit_l;
  float32 rtb_Switch_di;
  float32 rtb_Switch2_b;
  float32 rtb_DifferenceInputs2_g;
  float32 rtb_Saturation_oq;
  float32 rtb_Add1_my;
  float32 rtb_kphtomps_m;
  float32 rtb_Saturation_jf;
  float32 rtb_Switch2_px;
  float32 rtb_Switch_mj;
  float32 rtb_Switch2_f;
  float32 rtb_Gain1_as;
  float32 rtb_Switch_gg;
  float32 rtb_Switch2_fq;
  float32 rtb_Divide5_a;
  float32 rtb_Divide2_jb;
  float32 rtb_Merge_p;
  float32 rtb_Switch_o;
  float32 rtb_Switch2_k2;
  float32 rtb_Divide7;
  float32 rtb_Switch_g1;
  float32 rtb_Switch2_oo;
  float32 rtb_Saturation_fr;
  float32 rtb_Switch_nb;
  float32 rtb_Add_ln;
  float32 rtb_Switch_g3;
  float32 rtb_Switch2_do;
  float32 rtb_UkYk1_d;
  float32 rtb_Switch_ed;
  float32 rtb_Switch2_oc;
  float32 rtb_Abs1_bz;
  float32 rtb_Abs_c;
  float32 rtb_Add1_mr;
  float32 rtb_Merge_d;
  float32 rtb_Merge_o;
  float32 rtb_Merge_i;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_ev;
  float32 rtb_Saturation_m;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_In;
  float32 rtb_In_i;
  float32 rtb_In_h;
  float32 rtb_TrqFactor;
  float32 rtb_Divide_jg;
  float32 rtb_StandardDeviation;
  float32 rtb_Plan;
  float32 rtb_T1_g;
  float32 rtb_Plan_m;
  float32 rtb_T1_p;
  float32 rtb_Gain_k;
  float32 rtb_Merge_a;
  float32 rtb_Divide3_j;
  float32 rtb_Gain2_i;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_n;
  uint16 rtb_Saturation1_j;
  uint16 rtb_Saturation1_pr;
  uint16 rtb_Saturation1_an;
  uint16 rtb_Saturation1_n1;
  uint16 rtb_Saturation2_px;
  uint16 rtb_Add_h;
  uint16 rtb_Saturation1_b;
  uint16 rtb_Saturation1_g3;
  uint8 rtb_IMAPva_d_obj_MotionStatus[40];
  uint8 rtb_IMAPva_d_obj_class[40];
  uint8 rtb_IMAPva_d_obj_id[40];
  uint8 rtb_IMAPva_d_obj_lane[40];
  uint8 rtb_IMAPva_d_obj_status[40];
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_o;
  uint8 rtb_L0_Type_k;
  uint8 rtb_EWWWve_y_BSD_LCAWarning;
  uint8 rtb_EWWWve_y_BSD_LCWWorkingSt;
  uint8 rtb_EWWWve_y_BSD_S_LCAWarning;
  uint8 rtb_EWWWve_y_BSD_S_LCWWorkingSt;
  uint8 rtb_FDMMve_d_ElkFcnConf;
  uint8 rtb_IMAPve_d_APA_AutoPark_WorkS;
  uint8 rtb_IMAPve_d_BCM_HazardLamp_Swi;
  uint8 rtb_IMAPve_d_ELK_Switch;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_EPS_TrqLim_State;
  uint8 rtb_IMAPve_d_EPS_Trq_State;
  uint8 rtb_IMAPve_d_ESC_VehSpd_Valid;
  uint8 rtb_IMAPve_d_ESC_YawRate_Valid;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L1_Type;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_R1_Type;
  uint8 rtb_IMAPve_d_SAS_Clb_State;
  uint8 rtb_IMAPve_d_SAS_Trim_State;
  uint8 rtb_IMAPve_d_SWS_Failure_Status;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_IMAPve_d_obj_Num;
  uint8 rtb_LDW_State;
  uint8 rtb_Switch8;
  uint8 rtb_Switch8_p;
  uint8 rtb_Switch8_c;
  uint8 rtb_LKA_Mode;
  uint8 rtb_Saturation1_br;
  boolean rtb_LogicalOperator2;
  boolean rtb_ADIA_DTC_EMS_14B_InvOorReal;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxT;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinT;
  boolean rtb_ADIAve_e_Node_ACU_Validity;
  boolean rtb_ADIAve_e_Node_EPB_Validity;
  boolean rtb_ADIA_Inner_FRadar_FaultStat;
  boolean rtb_ADIAve_d_sen_sta_Corner_rad;
  boolean rtb_ADIAve_e_Node_EMS_Validity;
  boolean rtb_ADIAve_e_Node_IC_Validity;
  boolean rtb_ADIAve_e_Node_TBOX_Validity;
  boolean rtb_ADIA_DTC_ESC_EPBErrorStatus;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorTCS;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorVeh;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorLat;
  boolean rtb_ADIA_DTC_MP5_366_OorAEBButt;
  boolean rtb_ADIA_DTC_MP5_366_OorFCWButt;
  boolean rtb_ADIA_DTC_SAS_A5_InvOorSteAn;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorLon;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorSta;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorYaw;
  boolean rtb_ADIA_DTC_ESC6_123_InvOorDyn;
  boolean rtb_ADIA_DTC_ESC6_123_InvUnfilY;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehDri;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehHol;
  boolean rtb_ADIA_DTC_GW_MP5_413_OorISAM;
  boolean rtb_ADIA_DTC_SCC_309_OorACCButt;
  boolean rtb_ADIA_DTC_TCU1_93_InvOorGear;
  boolean rtb_ADIA_DTC_BCM3_33C_InvBrkLig;
  boolean rtb_ADIA_DTC_EMS_14A_OorACCStat;
  boolean rtb_ADIA_DTC_EMS10_88_InvAccPed;
  boolean rtb_ADIA_DTC_EMS5_E0_InvOorBrkP;
  boolean rtb_ADIA_DTC_EMS5_E0_OorEngineS;
  boolean rtb_LogicalOperator3_do;
  boolean rtb_OR_b;
  boolean rtb_Compare_neb;
  boolean rtb_UnitDelay_na;
  boolean rtb_Merge_f;
  boolean rtb_Compare_bo;
  boolean rtb_UnitDelay_c;
  boolean rtb_Compare_bn;
  boolean rtb_Merge_o0;
  boolean rtb_Merge_dz;
  boolean rtb_Compare_ff;
  boolean rtb_LogicalOperator1_f;
  boolean rtb_RelationalOperator6_i;
  boolean rtb_RelationalOperator5;
  boolean rtb_Compare_jr;
  boolean rtb_Memory1_a;
  boolean rtb_Merge_p1;
  boolean rtb_LKA_Main_Switch;
  boolean rtb_LKA_Switch;
  float32 x10;
  float32 x20;
  float32 x1;
  const UInt16 *tmpIRead;
  const T_M_Nm_Float32 *tmpIRead_0;
  const T_M_Nm_Float32 *tmpIRead_1;
  const T_M_Nm_Float32 *tmpIRead_2;
  const T_M_Nm_Float32 *tmpIRead_3;
  const T_M_Nm_Float32 *tmpIRead_4;
  const T_M_Nm_Float32 *tmpIRead_5;
  const T_M_Nm_Float32 *tmpIRead_6;
  const T_M_Nm_Float32 *tmpIRead_7;
  const T_M_Nm_Float32 *tmpIRead_8;
  const T_M_Nm_Float32 *tmpIRead_9;
  const T_M_Nm_Float32 *tmpIRead_a;
  const UInt16 *tmpIRead_b;
  const UInt16 *tmpIRead_c;
  const UInt16 *tmpIRead_d;
  const UInt16 *tmpIRead_e;
  uint8 rtb_FDMMve_d_LkaFcnConf;
  uint8 rtb_IMAPve_d_LKA_Mode;
  uint8 rtb_IMAPve_d_LDW_Warn_Mode;
  float32 rtb_Abs_n;
  float32 rtb_L0_C0;
  float32 rtb_R0_C0;
  uint8 rtb_R0_Q_c;
  float32 rtb_SW_Angle;
  boolean rtb_BCM_Left_Light;
  boolean rtb_BCM_Right_Light;
  uint8 rtb_TCU_ActualGear;
  uint8 rtb_HMI_Popup_Status_f;
  uint8 rtb_LKA_Action_Indication_m;
  float32 rtb_R0_C2;
  uint8 rtb_L0_Q;
  uint8 rtb_Lrg_Q;
  boolean rtb_LFlg;
  uint8 rtb_Rrg_Q;
  boolean rtb_RFlg;
  float32 rtb_L0_C0_g;
  float32 rtb_R0_C0_j;
  float32 rtb_L0_C0_c;
  float32 rtb_L0_C1_h5;
  float32 rtb_R0_C1_g;
  float32 rtb_L0_C1_c;
  float32 rtb_L0_C2_f;
  float32 rtb_L0_C3;
  float32 rtb_R0_C3;
  float32 rtb_L0_C3_i;
  float32 rtb_R0_C2_b;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_LKA_LatestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  float32 rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  boolean rtb_LL_SingleLane_Disable_Swt;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LFClb_TFC_KdBalance_C;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LL_LKAExPrcs_tiExitDelayTim;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_Abs_g;
  float32 rtb_Abs_a;
  float32 rtb_TTLC_h;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_l;
  boolean rtb_LogicalOperator3_c;
  boolean rtb_RelationalOperator_n;
  boolean rtb_LogicalOperator_fs;
  boolean rtb_Compare_nvo;
  boolean rtb_Compare_o3;
  boolean rtb_LogicalOperator_hu;
  boolean rtb_Compare_mws;
  boolean rtb_LogicalOperator_g;
  boolean rtb_Compare_j2;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_pe;
  boolean rtb_stDvrTkConFlg_n;
  boolean rtb_LogicalOperator_kx;
  boolean rtb_LogicalOperator_aq;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge_n;
  uint32 rtb_Add;
  uint8 rtb_L0_Type;
  uint16 rtb_Saturation_b;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  float32 rtb_TTLC;
  float32 rtb_TLft;
  uint8 rtb_L1_Q_a;
  sint32 i;
  float32 tmp;
  float32 rtb_Abs_b_tmp;
  float32 rtb_Add5_g_tmp;
  float32 rtb_LogicalOperator3_l_tmp;
  float32 rtb_LogicalOperator3_l_tmp_0;
  float32 rtb_LogicalOperator3_l_tmp_1;
  float32 rtb_Add_gv_tmp;
  float32 rtb_Add_a_tmp;
  boolean exitg1;

  /* Inport: '<Root>/IMAPva_d_obj_MotionStatus' */
  tmpIRead_e =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_MotionStatus_IMAPva_d_obj_MotionStatus
    ();

  /* Inport: '<Root>/IMAPva_d_obj_status' */
  tmpIRead_d =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_status_IMAPva_d_obj_status();

  /* Inport: '<Root>/IMAPva_d_obj_lane' */
  tmpIRead_c = Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_lane_IMAPva_d_obj_lane();

  /* Inport: '<Root>/IMAPva_d_obj_class' */
  tmpIRead_b =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_class_IMAPva_d_obj_class();

  /* Inport: '<Root>/IMAPva_g_obj_length' */
  tmpIRead_a =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_length_IMAPva_g_obj_length();

  /* Inport: '<Root>/IMAPva_g_obj_width' */
  tmpIRead_9 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_width_IMAPva_g_obj_width();

  /* Inport: '<Root>/IMAPva_g_obj_pos_var_xy' */
  tmpIRead_8 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_var_xy_IMAPva_g_obj_pos_var_xy
    ();

  /* Inport: '<Root>/IMAPva_g_obj_pos_var_y' */
  tmpIRead_7 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_var_y_IMAPva_g_obj_pos_var_y();

  /* Inport: '<Root>/IMAPva_g_obj_pos_var_x' */
  tmpIRead_6 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_var_x_IMAPva_g_obj_pos_var_x();

  /* Inport: '<Root>/IMAPva_g_obj_acc_y' */
  tmpIRead_5 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_acc_y_IMAPva_g_obj_acc_y();

  /* Inport: '<Root>/IMAPva_g_obj_acc_x' */
  tmpIRead_4 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_acc_x_IMAPva_g_obj_acc_x();

  /* Inport: '<Root>/IMAPva_g_obj_vel_y' */
  tmpIRead_3 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_vel_y_IMAPva_g_obj_vel_y();

  /* Inport: '<Root>/IMAPva_g_obj_vel_x' */
  tmpIRead_2 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_vel_x_IMAPva_g_obj_vel_x();

  /* Inport: '<Root>/IMAPva_g_obj_pos_y' */
  tmpIRead_1 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_y_IMAPva_g_obj_pos_y();

  /* Inport: '<Root>/IMAPva_g_obj_pos_x' */
  tmpIRead_0 =
    Rte_IRead_Runnable_LKAS_Step_IMAPva_g_obj_pos_x_IMAPva_g_obj_pos_x();

  /* Inport: '<Root>/IMAPva_d_obj_id' */
  tmpIRead = Rte_IRead_Runnable_LKAS_Step_IMAPva_d_obj_id_IMAPva_d_obj_id();

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPva_d_obj_MotionStatus_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_MotionStatus[i] = (uint8)tmpIRead_e[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_MotionStatus_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_class_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_class[i] = (uint8)tmpIRead_b[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_class_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_id_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_id[i] = (uint8)tmpIRead[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_id_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_lane_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_lane[i] = (uint8)tmpIRead_c[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_lane_1' */

  /* DataTypeConversion: '<S1>/IMAPva_d_obj_status_1' */
  for (i = 0; i < 40; i++) {
    rtb_IMAPva_d_obj_status[i] = (uint8)tmpIRead_d[i];
  }

  /* End of DataTypeConversion: '<S1>/IMAPva_d_obj_status_1' */

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_acc_x_1' */
  memcpy(&rtb_IMAPva_g_obj_acc_x[0], &tmpIRead_4[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_acc_y_1' */
  memcpy(&rtb_IMAPva_g_obj_acc_y[0], &tmpIRead_5[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_length_1' */
  memcpy(&rtb_IMAPva_g_obj_length[0], &tmpIRead_a[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_var_x_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_var_x[0], &tmpIRead_6[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_var_xy_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_var_xy[0], &tmpIRead_8[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_var_y_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_var_y[0], &tmpIRead_7[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_x_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_x[0], &tmpIRead_0[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_pos_y_1' */
  memcpy(&rtb_IMAPva_g_obj_pos_y[0], &tmpIRead_1[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_vel_x_1' */
  memcpy(&rtb_IMAPva_g_obj_vel_x[0], &tmpIRead_2[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_vel_y_1' */
  memcpy(&rtb_IMAPva_g_obj_vel_y[0], &tmpIRead_3[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/IMAPva_g_obj_width_1' */
  memcpy(&rtb_IMAPva_g_obj_width[0], &tmpIRead_9[0], 40U * (sizeof(float32)));

  /* DataTypeConversion: '<S1>/FDMMve_d_LkaFcnConf_1' incorporates:
   *  Inport: '<Root>/FDMMve_d_LkaFcnConf'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf();

  /* DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LKA_Mode'
   */
  rtb_IMAPve_d_LKA_Mode = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode();

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LDW_Warn_Mode'
   */
  rtb_IMAPve_d_LDW_Warn_Mode = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode();

  /* MATLAB Function: '<S104>/MATLAB Function' incorporates:
   *  DataTypeConversion: '<S104>/Cast To Boolean'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  Inport: '<Root>/IMAPve_d_LKA_Main_Switch'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsMP5Info/MATLAB Function': '<S139>:1' */
  /* '<S139>:1:2' LKA_Switch = (LkaFcnConf > 0 || LKA_Main_Switch_In > 0); */
  rtb_LFlg = ((((sint32)rtb_FDMMve_d_LkaFcnConf) > 0) || (((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch
    ())) != 0));
  rtb_LKA_Switch = rtb_LFlg;

  /* '<S139>:1:3' LKA_Main_Switch = LKA_Switch; */
  rtb_LKA_Main_Switch = rtb_LFlg;

  /* '<S139>:1:5' if LDW_Warn_Mode_In == 2 || LkaFcnConf == 3 || LkaFcnConf == 6 || LkaFcnConf == 9 || LkaFcnConf == 12 */
  if (((((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 2) || (((sint32)
           rtb_FDMMve_d_LkaFcnConf) == 3)) || (((sint32)rtb_FDMMve_d_LkaFcnConf)
         == 6)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 9)) || (((sint32)
        rtb_FDMMve_d_LkaFcnConf) == 12)) {
    /* '<S139>:1:6' LDW_Warn_Mode = uint8(2); */
    rtb_IMAPve_d_LDW_Warn_Mode = 2U;
  } else if (((((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 1) || (((sint32)
      rtb_FDMMve_d_LkaFcnConf) == 2)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 5))
              || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 8)) || (((sint32)
               rtb_FDMMve_d_LkaFcnConf) == 11)) {
    /* '<S139>:1:7' elseif  LDW_Warn_Mode_In == 1 || LkaFcnConf == 2 || LkaFcnConf == 5 || LkaFcnConf == 8 || LkaFcnConf == 11 */
    /* '<S139>:1:8' LDW_Warn_Mode = uint8(1); */
    rtb_IMAPve_d_LDW_Warn_Mode = 1U;
  } else if (((((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 0) || (((sint32)
      rtb_FDMMve_d_LkaFcnConf) == 1)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 4))
              || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 7)) || (((sint32)
               rtb_FDMMve_d_LkaFcnConf) == 10)) {
    /* '<S139>:1:9' elseif  LDW_Warn_Mode_In == 0 || LkaFcnConf == 1 || LkaFcnConf == 4 || LkaFcnConf == 7 || LkaFcnConf == 10 */
    /* '<S139>:1:10' LDW_Warn_Mode = uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  } else {
    /* '<S139>:1:11' else */
    /* '<S139>:1:12' LDW_Warn_Mode = uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  }

  /* '<S139>:1:15' if LKA_Switch */
  if (rtb_LFlg) {
    /* '<S139>:1:16' if LkaFcnConf == 4 || LkaFcnConf == 5 || LkaFcnConf == 6 || LkaFcnConf == 10 || LkaFcnConf == 11 || LkaFcnConf == 12 || LKA_Mode_In == 1 */
    if (((((((((sint32)rtb_FDMMve_d_LkaFcnConf) == 4) || (((sint32)
               rtb_FDMMve_d_LkaFcnConf) == 5)) || (((sint32)
              rtb_FDMMve_d_LkaFcnConf) == 6)) || (((sint32)
             rtb_FDMMve_d_LkaFcnConf) == 10)) || (((sint32)
            rtb_FDMMve_d_LkaFcnConf) == 11)) || (((sint32)
           rtb_FDMMve_d_LkaFcnConf) == 12)) || (((sint32)rtb_IMAPve_d_LKA_Mode) ==
         1)) {
      /* '<S139>:1:17' LKA_Mode = uint8(2); */
      LKAS_DW.LKA_Mode_k = 2U;
    } else if (((((((((sint32)rtb_FDMMve_d_LkaFcnConf) == 1) || (((sint32)
        rtb_FDMMve_d_LkaFcnConf) == 2)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) ==
      3)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) == 7)) || (((sint32)
        rtb_FDMMve_d_LkaFcnConf) == 8)) || (((sint32)rtb_FDMMve_d_LkaFcnConf) ==
      9)) || (((sint32)rtb_IMAPve_d_LKA_Mode) == 0)) {
      /* '<S139>:1:18' elseif LkaFcnConf == 1 || LkaFcnConf == 2 || LkaFcnConf == 3 || LkaFcnConf == 7 || LkaFcnConf == 8 || LkaFcnConf == 9 || LKA_Mode_In == 0 */
      /* '<S139>:1:19' LKA_Mode = uint8(1); */
      LKAS_DW.LKA_Mode_k = 1U;
    } else {
      /* '<S139>:1:20' else */
      /* '<S139>:1:21' LKA_Mode = uint8(0); */
      LKAS_DW.LKA_Mode_k = 0U;
    }
  } else {
    /* '<S139>:1:23' else */
    /* '<S139>:1:24' LKA_Mode = uint8(0); */
    LKAS_DW.LKA_Mode_k = 0U;
  }

  /* End of MATLAB Function: '<S104>/MATLAB Function' */

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Q'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q();

  /* Switch: '<S116>/Switch' incorporates:
   *  Constant: '<S116>/Constant'
   */
  if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = rtb_FDMMve_d_LkaFcnConf;
  }

  /* End of Switch: '<S116>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_Lrg_Q_BACK_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Lrg_Q_BACK'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Lrg_Q_BACK_IMAPve_d_Lrg_Q_BACK();

  /* Switch: '<S115>/Switch1' incorporates:
   *  Constant: '<S115>/Constant1'
   */
  if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
    rtb_Lrg_Q = ((uint8)3U);
  } else {
    rtb_Lrg_Q = rtb_FDMMve_d_LkaFcnConf;
  }

  /* End of Switch: '<S115>/Switch1' */

  /* DataTypeConversion: '<S110>/Cast To Single64' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   *  UnaryMinus: '<S110>/Unary Minus'
   */
  rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0
    ()));

  /* UnaryMinus: '<S110>/Unary Minus18' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C0_BACK_1'
   *  Inport: '<Root>/IMAPve_g_Lrg_C0_BACK'
   */
  rtb_Abs_n = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C0_BACK_IMAPve_g_Lrg_C0_BACK
    ()));

  /* MATLAB Function: '<S123>/Switch_L0_or_Lrg' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single2'
   *  Memory: '<S123>/Memory1'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/Switch_L0_or_Lrg': '<S129>:1' */
  rtb_R0_C2 = rtb_Abs_n;

  /* '<S129>:1:2' if Lrg_Q == 3 */
  if (((sint32)rtb_Lrg_Q) == 3) {
    /* '<S129>:1:3' Lrg_C0 = Lrg_C0 + Offset; */
    rtb_R0_C2 = rtb_Abs_n + LKAS_DW.Memory1_PreviousInput;

    /* '<S129>:1:4' if L0_Q == 3 */
    if (((sint32)rtb_L0_Q) == 3) {
      /* '<S129>:1:5' if Lrg_C0 > L0_C0 */
      if (rtb_R0_C2 > rtb_L0_C0) {
        /* '<S129>:1:6' LFlg = true; */
        rtb_LFlg = true;

        /* Switch: '<S123>/Switch1' */
        rtb_IMAPve_d_LKA_Mode = 3U;
      } else {
        /* '<S129>:1:7' else */
        /* '<S129>:1:8' LFlg = false; */
        rtb_LFlg = false;

        /* Switch: '<S123>/Switch1' */
        rtb_IMAPve_d_LKA_Mode = rtb_L0_Q;
      }
    } else {
      /* '<S129>:1:10' else */
      /* '<S129>:1:11' LFlg = true; */
      rtb_LFlg = true;

      /* Switch: '<S123>/Switch1' */
      rtb_IMAPve_d_LKA_Mode = 3U;
    }
  } else {
    /* '<S129>:1:13' else */
    /* '<S129>:1:14' LFlg = false; */
    rtb_LFlg = false;

    /* Switch: '<S123>/Switch1' */
    rtb_IMAPve_d_LKA_Mode = rtb_L0_Q;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_Rrg_Q_BACK_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Rrg_Q_BACK'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Rrg_Q_BACK_IMAPve_d_Rrg_Q_BACK();

  /* Switch: '<S117>/Switch1' incorporates:
   *  Constant: '<S117>/Constant1'
   */
  if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
    rtb_Rrg_Q = ((uint8)3U);
  } else {
    rtb_Rrg_Q = rtb_FDMMve_d_LkaFcnConf;
  }

  /* End of Switch: '<S117>/Switch1' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Q'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q();

  /* Switch: '<S112>/Switch1' incorporates:
   *  Constant: '<S112>/Constant1'
   */
  if (rtb_FDMMve_d_LkaFcnConf >= ((uint8)2U)) {
    rtb_FDMMve_d_LkaFcnConf = ((uint8)3U);
  }

  /* End of Switch: '<S112>/Switch1' */

  /* DataTypeConversion: '<S110>/Cast To Single55' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   *  UnaryMinus: '<S110>/Unary Minus4'
   */
  rtb_R0_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0
    ()));

  /* UnaryMinus: '<S110>/Unary Minus22' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C0_BACK_1'
   *  Inport: '<Root>/IMAPve_g_Rrg_C0_BACK'
   */
  rtb_Abs_n = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C0_BACK_IMAPve_g_Rrg_C0_BACK
    ()));

  /* MATLAB Function: '<S123>/Switch_R0_or_Rrg' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single10'
   *  Memory: '<S123>/Memory1'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/Switch_R0_or_Rrg': '<S130>:1' */
  /* '<S130>:1:2' if Rrg_Q == 3 */
  if (((sint32)rtb_Rrg_Q) == 3) {
    /* '<S130>:1:3' Rrg_C0 = Rrg_C0 - Offset; */
    rtb_Abs_n -= LKAS_DW.Memory1_PreviousInput;

    /* '<S130>:1:4' if R0_Q == 3 */
    if (((sint32)rtb_FDMMve_d_LkaFcnConf) == 3) {
      /* '<S130>:1:5' if Rrg_C0 < R0_C0 */
      if (rtb_Abs_n < rtb_R0_C0) {
        /* '<S130>:1:6' RFlg = true; */
        rtb_RFlg = true;

        /* Switch: '<S123>/Switch' */
        rtb_R0_Q_c = 3U;
      } else {
        /* '<S130>:1:7' else */
        /* '<S130>:1:8' RFlg = false; */
        rtb_RFlg = false;

        /* Switch: '<S123>/Switch' */
        rtb_R0_Q_c = rtb_FDMMve_d_LkaFcnConf;
      }
    } else {
      /* '<S130>:1:10' else */
      /* '<S130>:1:11' RFlg = true; */
      rtb_RFlg = true;

      /* Switch: '<S123>/Switch' */
      rtb_R0_Q_c = 3U;
    }
  } else {
    /* '<S130>:1:13' else */
    /* '<S130>:1:14' RFlg = false; */
    rtb_RFlg = false;

    /* Switch: '<S123>/Switch' */
    rtb_R0_Q_c = rtb_FDMMve_d_LkaFcnConf;
  }

  /* Chart: '<S111>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c9_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c9_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S118>:4' */
    LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S118>:3' */
    /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c9_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S118>:9' */
      /* '<S118>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* Transition: '<S118>:13' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S118>:3' */
        /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) < 3))
        {
          /* Transition: '<S118>:14' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S118>:7' */
          /* '<S118>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S118>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S118>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_IMAPve_d_LKA_Mode) < 3) && (((sint32)rtb_R0_Q_c) ==
               3)) {
            /* Transition: '<S118>:23' */
            LKAS_DW.is_c9_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S118>:5' */
            /* '<S118>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S118>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S118>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S118>:5' */
      /* '<S118>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* Transition: '<S118>:16' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S118>:3' */
        /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) < 3))
        {
          /* Transition: '<S118>:18' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S118>:7' */
          /* '<S118>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S118>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S118>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_R0_Q_c) < 3) {
            /* Transition: '<S118>:11' */
            LKAS_DW.is_c9_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S118>:3' */
      /* '<S118>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_IMAPve_d_LKA_Mode) < 3) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* Transition: '<S118>:6' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S118>:5' */
        /* '<S118>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S118>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S118>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) < 3))
        {
          /* Transition: '<S118>:8' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S118>:7' */
          /* '<S118>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S118>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S118>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_IMAPve_d_LKA_Mode) < 3) && (((sint32)rtb_R0_Q_c) < 3))
          {
            /* Transition: '<S118>:10' */
            /* '<S118>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c9_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S118>:7' */
      /* '<S118>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_IMAPve_d_LKA_Mode) == 3) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* Transition: '<S118>:17' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S118>:3' */
        /* '<S118>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S118>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S118>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S118>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_IMAPve_d_LKA_Mode) < 3) && (((sint32)rtb_R0_Q_c) == 3))
        {
          /* Transition: '<S118>:19' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S118>:5' */
          /* '<S118>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S118>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S118>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S118>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_IMAPve_d_LKA_Mode) < 3) {
            /* Transition: '<S118>:12' */
            LKAS_DW.is_c9_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S111>/LaneReconstructSM' */

  /* Switch: '<S123>/Switch1' incorporates:
   *  MATLAB Function: '<S123>/Switch_L0_or_Lrg'
   */
  if (rtb_LFlg) {
    rtb_L0_C0_g = rtb_R0_C2;
  } else {
    rtb_L0_C0_g = rtb_L0_C0;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  MATLAB Function: '<S123>/Switch_R0_or_Rrg'
   */
  if (rtb_RFlg) {
    rtb_R0_C0_j = rtb_Abs_n;
  } else {
    rtb_R0_C0_j = rtb_R0_C0;
  }

  /* Switch: '<S128>/Switch' incorporates:
   *  Constant: '<S137>/Constant'
   *  Constant: '<S138>/Constant'
   *  Delay: '<S128>/Delay'
   *  Gain: '<S128>/Gain'
   *  Logic: '<S128>/Logical Operator'
   *  RelationalOperator: '<S137>/Compare'
   *  RelationalOperator: '<S138>/Compare'
   *  Sum: '<S128>/Add'
   */
  if ((rtb_IMAPve_d_LKA_Mode >= ((uint8)2U)) && (rtb_R0_Q_c >= ((uint8)2U))) {
    rtb_L0_C0 = ((-1.0F) * rtb_L0_C0_g) + rtb_R0_C0_j;
  } else {
    rtb_L0_C0 = LKAS_DW.Delay_DSTATE;
  }

  /* End of Switch: '<S128>/Switch' */

  /* Sum: '<S136>/Add1' incorporates:
   *  Memory: '<S136>/Memory'
   *  Product: '<S136>/Divide'
   *  Product: '<S136>/Divide1'
   */
  rtb_Abs_n = (rtb_L0_C0 * LKAS_ConstB.Divide2) + (LKAS_ConstB.Add2 *
    LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S128>/Saturation1' */
  if (rtb_Abs_n > 5.5F) {
    rtb_R0_C0 = 5.5F;
  } else if (rtb_Abs_n < 2.5F) {
    rtb_R0_C0 = 2.5F;
  } else {
    rtb_R0_C0 = rtb_Abs_n;
  }

  /* End of Saturate: '<S128>/Saturation1' */

  /* Switch: '<S111>/Switch1' incorporates:
   *  Gain: '<S120>/Gain'
   *  Sum: '<S120>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_c = rtb_L0_C0_g;
  } else {
    rtb_L0_C0_c = (rtb_R0_C0 - rtb_R0_C0_j) * (-1.0F);
  }

  /* Switch: '<S677>/Switch24' incorporates:
   *  Constant: '<S677>/LL_CompHdAg_C=0.005'
   */
  if (LKAS_ConstB.DataTypeConversion38 != 0.0F) {
    rtb_L0_C0 = LKAS_ConstB.DataTypeConversion38;
  } else {
    rtb_L0_C0 = LL_CompHdAg_C;
  }

  /* End of Switch: '<S677>/Switch24' */

  /* Switch: '<S123>/Switch1' incorporates:
   *  Constant: '<S132>/Constant'
   *  RelationalOperator: '<S132>/Compare'
   *  Switch: '<S124>/Switch1'
   */
  if (rtb_LFlg) {
    /* Switch: '<S125>/Switch1' incorporates:
     *  Constant: '<S133>/Constant'
     *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C1_BACK_1'
     *  Inport: '<Root>/IMAPve_g_Lrg_C1_BACK'
     *  RelationalOperator: '<S133>/Compare'
     *  Sum: '<S125>/Add'
     *  UnaryMinus: '<S110>/Unary Minus19'
     */
    if (rtb_Lrg_Q == ((uint8)3U)) {
      rtb_L0_C1_h5 = rtb_L0_C0 + ((float32)((T_M_Nm_Float32)
        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C1_BACK_IMAPve_g_Lrg_C1_BACK
         ())));
    } else {
      rtb_L0_C1_h5 = (float32)((T_M_Nm_Float32)
        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C1_BACK_IMAPve_g_Lrg_C1_BACK
         ()));
    }

    /* End of Switch: '<S125>/Switch1' */
  } else if (rtb_L0_Q == ((uint8)3U)) {
    /* Switch: '<S124>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
     *  Inport: '<Root>/IMAPve_g_L0_C1'
     *  Sum: '<S124>/Add'
     *  UnaryMinus: '<S110>/Unary Minus1'
     */
    rtb_L0_C1_h5 = rtb_L0_C0 + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1())));
  } else {
    /* Switch: '<S124>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
     *  Inport: '<Root>/IMAPve_g_L0_C1'
     *  UnaryMinus: '<S110>/Unary Minus1'
     */
    rtb_L0_C1_h5 = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1()));
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  Constant: '<S134>/Constant'
   *  RelationalOperator: '<S134>/Compare'
   *  Switch: '<S126>/Switch1'
   */
  if (rtb_RFlg) {
    /* Switch: '<S127>/Switch1' incorporates:
     *  Constant: '<S135>/Constant'
     *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C1_BACK_1'
     *  Inport: '<Root>/IMAPve_g_Rrg_C1_BACK'
     *  RelationalOperator: '<S135>/Compare'
     *  Sum: '<S127>/Add'
     *  UnaryMinus: '<S110>/Unary Minus23'
     */
    if (rtb_Rrg_Q == ((uint8)3U)) {
      rtb_R0_C1_g = rtb_L0_C0 + ((float32)((T_M_Nm_Float32)
        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C1_BACK_IMAPve_g_Rrg_C1_BACK
         ())));
    } else {
      rtb_R0_C1_g = (float32)((T_M_Nm_Float32)
        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C1_BACK_IMAPve_g_Rrg_C1_BACK
         ()));
    }

    /* End of Switch: '<S127>/Switch1' */
  } else if (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U)) {
    /* Switch: '<S126>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
     *  Inport: '<Root>/IMAPve_g_R0_C1'
     *  Sum: '<S126>/Add'
     *  UnaryMinus: '<S110>/Unary Minus5'
     */
    rtb_R0_C1_g = rtb_L0_C0 + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1())));
  } else {
    /* Switch: '<S126>/Switch1' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
     *  Inport: '<Root>/IMAPve_g_R0_C1'
     *  UnaryMinus: '<S110>/Unary Minus5'
     */
    rtb_R0_C1_g = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1()));
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single1'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C1_c = rtb_L0_C1_h5;
  } else {
    rtb_L0_C1_c = rtb_R0_C1_g;
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C2_BACK_1'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  Inport: '<Root>/IMAPve_g_Lrg_C2_BACK'
   *  UnaryMinus: '<S110>/Unary Minus16'
   *  UnaryMinus: '<S110>/Unary Minus2'
   */
  if (rtb_LFlg) {
    rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C2_BACK_IMAPve_g_Lrg_C2_BACK
      ()));
  } else {
    rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2
      ()));
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C2_BACK_1'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   *  Inport: '<Root>/IMAPve_g_Rrg_C2_BACK'
   *  UnaryMinus: '<S110>/Unary Minus20'
   *  UnaryMinus: '<S110>/Unary Minus6'
   */
  if (rtb_RFlg) {
    rtb_R0_C2 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C2_BACK_IMAPve_g_Rrg_C2_BACK
      ()));
  } else {
    rtb_R0_C2 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2
      ()));
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single2'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C2_f = rtb_L0_C0;
  } else {
    rtb_L0_C2_f = rtb_R0_C2;
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_C3_BACK_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  Inport: '<Root>/IMAPve_g_Lrg_C3_BACK'
   *  UnaryMinus: '<S110>/Unary Minus17'
   *  UnaryMinus: '<S110>/Unary Minus3'
   */
  if (rtb_LFlg) {
    rtb_L0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_C3_BACK_IMAPve_g_Lrg_C3_BACK
      ()));
  } else {
    rtb_L0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3
      ()));
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_C3_BACK_1'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   *  Inport: '<Root>/IMAPve_g_Rrg_C3_BACK'
   *  UnaryMinus: '<S110>/Unary Minus21'
   *  UnaryMinus: '<S110>/Unary Minus7'
   */
  if (rtb_RFlg) {
    rtb_R0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_C3_BACK_IMAPve_g_Rrg_C3_BACK
      ()));
  } else {
    rtb_R0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3
      ()));
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C3_i = rtb_L0_C3;
  } else {
    rtb_L0_C3_i = rtb_R0_C3;
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single2'
   *  Sum: '<S122>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_L0_C1_h5 = rtb_R0_C1_g;
    rtb_R0_C2_b = rtb_R0_C2;
    rtb_L0_C3 = rtb_R0_C3;
  } else {
    rtb_R0_C0_j = rtb_R0_C0 + rtb_L0_C0_g;
    rtb_R0_C2_b = rtb_L0_C0;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_LKA_State'
   */
  rtb_FDMMve_d_LkaFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  rtb_IMAPve_g_EPS_SW_Trq = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid'
   */
  rtb_L0_Q = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid
    ();

  /* Saturate: '<S107>/Saturation' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1'
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  rtb_ESC_VehSpd = fmaxf((float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd(), 0.1F);

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  rtb_IMAPve_g_ESC_LonAcc = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid'
   */
  rtb_Lrg_Q = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid
    ();

  /* Gain: '<S106>/Gain' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1'
   *  Inport: '<Root>/IMAPve_g_EPS_SteeringAngle'
   */
  rtb_SW_Angle = 1.0F * ((float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
    ());

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp'
   */
  rtb_Rrg_Q = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp
    ();

  /* Logic: '<S101>/Logical Operator' incorporates:
   *  Constant: '<S108>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Left_Light'
   *  RelationalOperator: '<S108>/Compare'
   */
  rtb_BCM_Left_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch
                    ()) == ((uint8)1U)));

  /* Logic: '<S101>/Logical Operator1' incorporates:
   *  Constant: '<S109>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Right_Light'
   *  RelationalOperator: '<S109>/Compare'
   */
  rtb_BCM_Right_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
                    ()) == ((uint8)1U)));

  /* MultiPortSwitch: '<S105>/Multiport Switch' incorporates:
   *  Constant: '<S105>/Constant1'
   *  Constant: '<S105>/Constant3'
   *  DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1'
   *  Inport: '<Root>/IMAPve_d_TCU_Actual_Gear'
   */
  switch ((uint8)
          Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear
          ()) {
   case 0:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 1:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 2:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 3:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 4:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 5:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 6:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 7:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 8:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 9:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   default:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;
  }

  /* End of MultiPortSwitch: '<S105>/Multiport Switch' */

  /* Switch: '<S678>/Switch58' incorporates:
   *  Constant: '<S678>/LLSMConClb4'
   *
   * Block description for '<S678>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S678>/Switch58' */

  /* Gain: '<S683>/Gain' incorporates:
   *  Constant: '<S683>/Constant'
   *  Sum: '<S683>/Add'
   */
  rtb_Gain_a = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S678>/Switch84' incorporates:
   *  Constant: '<S678>/LLSMConClb5'
   *
   * Block description for '<S678>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S678>/Switch84' */

  /* Switch: '<S678>/Switch85' incorporates:
   *  Constant: '<S678>/LLSMConClb6'
   *
   * Block description for '<S678>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S678>/Switch85' */

  /* Switch: '<S678>/Switch86' incorporates:
   *  Constant: '<S678>/LLSMConClb7'
   *
   * Block description for '<S678>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S678>/Switch86' */

  /* Switch: '<S678>/Switch54' incorporates:
   *  Constant: '<S678>/LLSMConClb12'
   *
   * Block description for '<S678>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S678>/Switch54' */

  /* Switch: '<S678>/Switch55' incorporates:
   *  Constant: '<S678>/LLSMConClb13'
   *
   * Block description for '<S678>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S678>/Switch55' */

  /* Switch: '<S678>/Switch60' incorporates:
   *  Constant: '<S678>/LLSMConClb17'
   *
   * Block description for '<S678>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S678>/Switch60' */

  /* Switch: '<S678>/Switch59' incorporates:
   *  Constant: '<S678>/LLSMConClb19'
   *
   * Block description for '<S678>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_LL_LKA_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_LL_LKA_LatestWarnLine_C = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S678>/Switch59' */

  /* Switch: '<S678>/Switch5' incorporates:
   *  Constant: '<S678>/LLSMConClb1'
   *
   * Block description for '<S678>/LLSMConClb1':
   *  LKA���ܵ�ƫ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    rtb_LL_LKA_EnableLine_Max = LKAS_ConstB.DataTypeConversion22;
  } else {
    rtb_LL_LKA_EnableLine_Max = LL_LKA_EnableLine_Max;
  }

  /* End of Switch: '<S678>/Switch5' */

  /* Switch: '<S678>/Switch6' incorporates:
   *  Constant: '<S678>/LLSMConClb44'
   *
   * Block description for '<S678>/LLSMConClb44':
   *  LKA���ܵ�ʹ����С�������ȼ�������
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_LKA_EnableLine_DvtMin = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_LKA_EnableLine_DvtMin = LL_LKA_EnableLine_DvtMin;
  }

  /* End of Switch: '<S678>/Switch6' */

  /* Switch: '<S678>/Switch7' incorporates:
   *  Constant: '<S678>/LLSMConClb45'
   *
   * Block description for '<S678>/LLSMConClb45':
   *  LKA���ܵ�ʹ����󳵵����ȼ�������
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_LL_LKA_EnableLine_DvtMax = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_LL_LKA_EnableLine_DvtMax = LL_LKA_EnableLine_DvtMax;
  }

  /* End of Switch: '<S678>/Switch7' */

  /* Switch: '<S678>/Switch69' incorporates:
   *  Constant: '<S678>/LLSMConClb22'
   *
   * Block description for '<S678>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S678>/Switch69' */

  /* Gain: '<S680>/Gain' incorporates:
   *  Constant: '<S680>/Constant'
   *  Sum: '<S680>/Add'
   */
  rtb_Gain_jm = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S678>/Switch68' incorporates:
   *  Constant: '<S678>/LLSMConClb23'
   *
   * Block description for '<S678>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S678>/Switch68' */

  /* Switch: '<S678>/Switch70' incorporates:
   *  Constant: '<S678>/LLSMConClb24'
   *
   * Block description for '<S678>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S678>/Switch70' */

  /* Switch: '<S678>/Switch71' incorporates:
   *  Constant: '<S678>/LLSMConClb25'
   *
   * Block description for '<S678>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S678>/Switch71' */

  /* Switch: '<S678>/Switch73' incorporates:
   *  Constant: '<S678>/LLSMConClb27'
   *
   * Block description for '<S678>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S678>/Switch73' */

  /* Switch: '<S678>/Switch62' incorporates:
   *  Constant: '<S678>/LLSMConClb31'
   *
   * Block description for '<S678>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S678>/Switch62' */

  /* Switch: '<S678>/Switch63' incorporates:
   *  Constant: '<S678>/LLSMConClb32'
   *
   * Block description for '<S678>/LLSMConClb32':
   *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
   */
  if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LKAS_ConstB.DataTypeConversion78;
  } else {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LL_MAX_DELAY_EPSSTAR_TIME;
  }

  /* End of Switch: '<S678>/Switch63' */

  /* Switch: '<S678>/Switch66' incorporates:
   *  Constant: '<S678>/LLSMConClb35'
   *
   * Block description for '<S678>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S678>/Switch66' */

  /* Switch: '<S678>/Switch38' incorporates:
   *  Constant: '<S678>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
   *
   * Block description for '<S678>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
   *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
    rtb_R0_C1_g = LKAS_ConstB.DataTypeConversion6;
  } else {
    rtb_R0_C1_g = LL_RlsDet_tiTrqChkT_DISABLE;
  }

  /* End of Switch: '<S678>/Switch38' */

  /* Switch: '<S678>/Switch44' incorporates:
   *  Constant: '<S678>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
   *
   * Block description for '<S678>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
   *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
   */
  if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = LKAS_ConstB.DataTypeConversion8;
  } else {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
  }

  /* End of Switch: '<S678>/Switch44' */

  /* Switch: '<S678>/Switch3' incorporates:
   *  Constant: '<S678>/LL_RlsDet_tiTDelTime_DISABLE=3'
   *
   * Block description for '<S678>/LL_RlsDet_tiTDelTime_DISABLE=3':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
    rtb_LL_HandsOff_ExitTime = LKAS_ConstB.DataTypeConversion3;
  } else {
    rtb_LL_HandsOff_ExitTime = LL_HandsOff_ExitTime;
  }

  /* End of Switch: '<S678>/Switch3' */

  /* Switch: '<S678>/Switch4' incorporates:
   *  Constant: '<S678>/LL_RlsDet_tiTDelTime_DISABLE=4'
   *
   * Block description for '<S678>/LL_RlsDet_tiTDelTime_DISABLE=4':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_SingleLane_Disable_Swt = (LKAS_ConstB.DataTypeConversion4 != 0.0F);
  } else {
    rtb_LL_SingleLane_Disable_Swt = LL_SingleLane_Disable_Swt;
  }

  /* End of Switch: '<S678>/Switch4' */

  /* Switch: '<S678>/Switch81' incorporates:
   *  Constant: '<S678>/LLSMConClb36'
   *
   * Block description for '<S678>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S678>/Switch81' */

  /* Switch: '<S678>/Switch82' incorporates:
   *  Constant: '<S678>/LLSMConClb37'
   *
   * Block description for '<S678>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S678>/Switch82' */

  /* Switch: '<S678>/Switch83' incorporates:
   *  Constant: '<S678>/LLSMConClb38'
   *
   * Block description for '<S678>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S678>/Switch83' */

  /* Switch: '<S678>/Switch75' incorporates:
   *  Constant: '<S678>/LLSMConClb39'
   *
   * Block description for '<S678>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S678>/Switch75' */

  /* Switch: '<S678>/Switch76' incorporates:
   *  Constant: '<S678>/LLSMConClb40'
   *
   * Block description for '<S678>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S678>/Switch76' */

  /* Switch: '<S678>/Switch77' incorporates:
   *  Constant: '<S678>/LLSMConClb41'
   *
   * Block description for '<S678>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S678>/Switch77' */

  /* Switch: '<S678>/Switch78' incorporates:
   *  Constant: '<S678>/LLSMConClb42'
   *
   * Block description for '<S678>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S678>/Switch78' */

  /* Switch: '<S677>/Switch3' incorporates:
   *  Constant: '<S677>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3_d != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3_d;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S677>/Switch3' */

  /* Switch: '<S677>/Switch31' incorporates:
   *  Constant: '<S677>/LL_LFClb_TFC_KpVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_p != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LKAS_ConstB.DataTypeConversion14_p;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S677>/Switch31' */

  /* Switch: '<S677>/Switch34' incorporates:
   *  Constant: '<S677>/LL_LFClb_TFC_KpVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4_l != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LKAS_ConstB.DataTypeConversion4_l;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S677>/Switch34' */

  /* Switch: '<S677>/Switch33' incorporates:
   *  Constant: '<S677>/LL_LFClb_TFC_KpV1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_h != 0.0F) {
    rtb_LL_LFClb_TFC_KpV1_C = LKAS_ConstB.DataTypeConversion7_h;
  } else {
    rtb_LL_LFClb_TFC_KpV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S677>/Switch33' */

  /* Switch: '<S677>/Switch35' incorporates:
   *  Constant: '<S677>/LL_LFClb_TFC_KpV2_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion17_o != 0.0F) {
    rtb_LL_LFClb_TFC_KpV2_C = LKAS_ConstB.DataTypeConversion17_o;
  } else {
    rtb_LL_LFClb_TFC_KpV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S677>/Switch35' */

  /* Switch: '<S677>/Switch20' incorporates:
   *  Constant: '<S677>/LL_LFClb_TFC_KdVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LL_LFClb_TFC_KdVehSpdLwr_C;
  }

  /* End of Switch: '<S677>/Switch20' */

  /* Switch: '<S677>/Switch22' incorporates:
   *  Constant: '<S677>/LL_LFClb_TFC_KdVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LL_LFClb_TFC_KdVehSpdUpr_C;
  }

  /* End of Switch: '<S677>/Switch22' */

  /* Switch: '<S677>/Switch21' incorporates:
   *  Constant: '<S677>/LL_LFClb_TFC_KdV1_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV1_C = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LFClb_TFC_KdV1_C = LL_LFClb_TFC_KdV1_C;
  }

  /* End of Switch: '<S677>/Switch21' */

  /* Switch: '<S677>/Switch23' incorporates:
   *  Constant: '<S677>/LL_LFClb_TFC_KdV2_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV2_C = LKAS_ConstB.DataTypeConversion30;
  } else {
    rtb_LL_LFClb_TFC_KdV2_C = LL_LFClb_TFC_KdV2_C;
  }

  /* End of Switch: '<S677>/Switch23' */

  /* Switch: '<S677>/Switch9' incorporates:
   *  Constant: '<S677>/LL_LFClb_TFC_KdBalance_C=1.2'
   */
  if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
    rtb_LL_LFClb_TFC_KdBalance_C = LKAS_ConstB.DataTypeConversion9;
  } else {
    rtb_LL_LFClb_TFC_KdBalance_C = LL_LFClb_TFC_KdBalance_C;
  }

  /* End of Switch: '<S677>/Switch9' */

  /* Switch: '<S677>/Switch11' incorporates:
   *  Constant: '<S677>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_k != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12_k;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S677>/Switch11' */

  /* Switch: '<S677>/Switch13' incorporates:
   *  Constant: '<S677>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_a != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_a;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S677>/Switch13' */

  /* Switch: '<S677>/Switch55' incorporates:
   *  Constant: '<S677>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S677>/Switch55' */

  /* Switch: '<S677>/Switch54' incorporates:
   *  Constant: '<S677>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S677>/Switch54' */

  /* Switch: '<S677>/Switch44' incorporates:
   *  Constant: '<S677>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S677>/Switch44' */

  /* Switch: '<S677>/Switch25' incorporates:
   *  Constant: '<S677>/LL_LKAExPrcs_tiExitDelayTime3=0.5'
   */
  if (LKAS_ConstB.DataTypeConversion39 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LKAS_ConstB.DataTypeConversion39;
  } else {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LL_LKAExPrcs_tiExitDelayTime3;
  }

  /* End of Switch: '<S677>/Switch25' */

  /* Switch: '<S675>/Switch19' incorporates:
   *  Constant: '<S675>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_o != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_o;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S675>/Switch19' */

  /* Switch: '<S675>/Switch' incorporates:
   *  Constant: '<S675>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_n != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_n;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S675>/Switch' */

  /* Switch: '<S675>/Switch1' incorporates:
   *  Constant: '<S675>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_c != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_c;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S675>/Switch1' */

  /* Switch: '<S675>/Switch2' incorporates:
   *  Constant: '<S675>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_k != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_o = LKAS_ConstB.DataTypeConversion4_k;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_o = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S675>/Switch2' */

  /* Switch: '<S675>/Switch3' incorporates:
   *  Constant: '<S675>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_b != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_c = LKAS_ConstB.DataTypeConversion6_b;
  } else {
    LKAS_DW.LKA_StrRatio_C_c = LKA_StrRatio_C;
  }

  /* End of Switch: '<S675>/Switch3' */

  /* Switch: '<S675>/Switch11' incorporates:
   *  Constant: '<S675>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22_e != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22_e;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S675>/Switch11' */

  /* DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1' incorporates:
   *  Inport: '<Root>/ADIAve_g_ASWFaultStatus'
   */
  rtb_L0_C0_g = (float32)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_ASWFaultStatus_ADIAve_g_ASWFaultStatus
    ();

  /* DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1' incorporates:
   *  Inport: '<Root>/ADIAve_g_BSWFaultStatus'
   */
  rtb_R0_C3 = (float32)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_BSWFaultStatus_ADIAve_g_BSWFaultStatus
    ();

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (rtb_LKA_Main_Switch) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S142>/Delay' */
      LKAS_DW.Delay_DSTATE_f = ((uint8)0U);

      /* InitializeConditions for Memory: '<S598>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = 0.0F;

      /* InitializeConditions for Delay: '<S143>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S538>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = 0.0F;

      /* InitializeConditions for Memory: '<S456>/Memory' */
      LKAS_DW.Memory_PreviousInput_e = 0.0F;

      /* InitializeConditions for UnitDelay: '<S469>/Delay Input1'
       *
       * Block description for '<S469>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S468>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_e = false;

      /* InitializeConditions for UnitDelay: '<S430>/Delay Input1'
       *
       * Block description for '<S430>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_e = false;

      /* InitializeConditions for UnitDelay: '<S428>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_n = false;

      /* InitializeConditions for UnitDelay: '<S429>/Delay Input1'
       *
       * Block description for '<S429>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_d = false;

      /* InitializeConditions for Memory: '<S395>/Memory' */
      LKAS_DW.Memory_PreviousInput_pk = false;

      /* InitializeConditions for Delay: '<S143>/Delay' */
      LKAS_DW.Delay_DSTATE_c = false;

      /* InitializeConditions for Delay: '<S143>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S443>/Memory' */
      LKAS_DW.Memory_PreviousInput_hd = ((uint8)0U);

      /* InitializeConditions for Memory: '<S369>/Memory' */
      LKAS_DW.Memory_PreviousInput_gk = 0.0F;

      /* InitializeConditions for Memory: '<S405>/Memory' */
      LKAS_DW.Memory_PreviousInput_c = 0.0F;

      /* InitializeConditions for Memory: '<S612>/Memory' */
      LKAS_DW.Memory_PreviousInput_iu = 0.0F;

      /* InitializeConditions for Delay: '<S613>/Delay' */
      LKAS_DW.Delay_DSTATE_p = ((uint8)0U);

      /* InitializeConditions for Delay: '<S614>/Delay' */
      LKAS_DW.Delay_DSTATE_d = ((uint8)0U);

      /* InitializeConditions for Delay: '<S615>/Delay' */
      LKAS_DW.Delay_DSTATE_p3 = ((uint8)0U);

      /* InitializeConditions for Delay: '<S143>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S143>/LDW_State_Machine'
       *
       * Block description for '<S143>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S143>/LKA_State_Machine'
       *
       * Block description for '<S143>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S308>/Add1' incorporates:
     *  MATLAB Function: '<S306>/MATLABFunction3'
     */
    x20 = rtb_L0_C0_c + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S308>/Gain1' incorporates:
     *  Product: '<S308>/Divide'
     *  Product: '<S308>/Divide1'
     *  Sum: '<S308>/Add1'
     *  Sum: '<S308>/Add5'
     *  Trigonometry: '<S308>/Cos2'
     *  Trigonometry: '<S308>/Sin'
     */
    rtb_Gain1 = ((x20 * cosf(rtb_L0_C1_c)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_c))) * (-1.0F);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S300>/Gain1' incorporates:
     *  Gain: '<S196>/Gain'
     *  Gain: '<S242>/kph To mps'
     *  Gain: '<S256>/kph to mps'
     *  Gain: '<S257>/kph to mps'
     *  Gain: '<S306>/Gain2'
     *  Gain: '<S313>/kph to mps'
     *  Gain: '<S319>/kph to mps'
     *  Gain: '<S328>/kph to mps'
     *  Gain: '<S329>/kph to mps'
     */
    rtb_Abs_b_tmp = 0.277777791F * rtb_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S300>/Divide4' incorporates:
     *  Constant: '<S300>/Constant2'
     *  Constant: '<S300>/Constant3'
     *  Gain: '<S300>/Gain1'
     */
    rtb_Abs_a = (rtb_Abs_b_tmp * 2.0F) * 0.1F;

    /* Sum: '<S300>/Add3' incorporates:
     *  Product: '<S300>/Divide3'
     */
    rtb_phiHdAg_Lft = (rtb_L0_C2_f * rtb_Abs_a) + rtb_L0_C1_c;

    /* Sum: '<S309>/Add1' incorporates:
     *  MATLAB Function: '<S306>/MATLABFunction4'
     */
    rtb_Add5_g_tmp = rtb_R0_C0_j - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S309>/Add5' incorporates:
     *  Product: '<S309>/Divide'
     *  Product: '<S309>/Divide1'
     *  Sum: '<S309>/Add1'
     *  Trigonometry: '<S309>/Cos2'
     *  Trigonometry: '<S309>/Sin'
     */
    rtb_Add5_g = (rtb_Add5_g_tmp * cosf(rtb_L0_C1_h5)) + (rtb_LKA_Veh2CamL_C *
      sinf(rtb_L0_C1_h5));

    /* Sum: '<S300>/Add1' incorporates:
     *  Product: '<S300>/Divide5'
     */
    rtb_phiHdAg_Rgt = (rtb_R0_C2_b * rtb_Abs_a) + rtb_L0_C1_h5;

    /* Switch: '<S677>/Switch2' incorporates:
     *  Constant: '<S677>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_i != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_i;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S677>/Switch2' */

    /* Product: '<S313>/Divide' */
    rtb_Abs_a = rtb_Abs_b_tmp * x10;

    /* Gain: '<S310>/Gain' incorporates:
     *  Gain: '<S325>/Gain'
     *  Gain: '<S326>/Gain'
     *  Gain: '<S327>/Gain'
     */
    rtb_Add_gv_tmp = 2.0F * rtb_L0_C2_f;

    /* Sum: '<S310>/Add' incorporates:
     *  Gain: '<S310>/Gain'
     *  Gain: '<S310>/Gain1'
     *  Product: '<S310>/Product'
     */
    rtb_Add_gv = ((6.0F * rtb_L0_C3_i) * rtb_Abs_a) + rtb_Add_gv_tmp;

    /* Gain: '<S311>/Gain' incorporates:
     *  Gain: '<S322>/Gain'
     *  Gain: '<S323>/Gain'
     *  Gain: '<S324>/Gain'
     */
    rtb_Add_a_tmp = 2.0F * rtb_R0_C2_b;

    /* Sum: '<S311>/Add' incorporates:
     *  Gain: '<S311>/Gain'
     *  Gain: '<S311>/Gain1'
     *  Product: '<S311>/Product'
     */
    rtb_Add_a = ((6.0F * rtb_L0_C3) * rtb_Abs_a) + rtb_Add_a_tmp;

    /* Product: '<S300>/Divide1' incorporates:
     *  Gain: '<S300>/Gain1'
     */
    rtb_Abs_a = rtb_phiHdAg_Lft * rtb_Abs_b_tmp;

    /* Saturate: '<S306>/Saturation2' incorporates:
     *  UnaryMinus: '<S306>/Unary Minus1'
     */
    if ((-rtb_Abs_a) > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else if ((-rtb_Abs_a) < (-2.0F)) {
      rtb_LKA_Veh2CamL_C = (-2.0F);
    } else {
      rtb_LKA_Veh2CamL_C = -rtb_Abs_a;
    }

    /* End of Saturate: '<S306>/Saturation2' */

    /* MATLAB Function: '<S306>/MATLABFunction' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction': '<S337>:1' */
    /* '<S337>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1 > 0.0F) && (rtb_Gain1 < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S337>:1:3' TTLC = -dvt/vy; */
      rtb_TTLC_h = (-rtb_Gain1) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S337>:1:4' else */
      /* '<S337>:1:5' TTLC = single(3); */
      rtb_TTLC_h = 3.0F;
    }

    /* End of MATLAB Function: '<S306>/MATLABFunction' */

    /* Saturate: '<S306>/Saturation' */
    if (rtb_TTLC_h > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_TTLC_h < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_TTLC_h;
    }

    /* End of Saturate: '<S306>/Saturation' */

    /* Product: '<S300>/Divide2' incorporates:
     *  Gain: '<S300>/Gain1'
     */
    rtb_Abs_g = rtb_phiHdAg_Rgt * rtb_Abs_b_tmp;

    /* Saturate: '<S306>/Saturation3' */
    if (rtb_Abs_g > 2.0F) {
      rtb_TTLC_h = 2.0F;
    } else if (rtb_Abs_g < (-2.0F)) {
      rtb_TTLC_h = (-2.0F);
    } else {
      rtb_TTLC_h = rtb_Abs_g;
    }

    /* End of Saturate: '<S306>/Saturation3' */

    /* MATLAB Function: '<S306>/MATLABFunction1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction1': '<S338>:1' */
    /* '<S338>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_g > 0.0F) && (rtb_Add5_g < 2.0F)) && (rtb_TTLC_h < 0.0F)) &&
        (rtb_TTLC_h > -1.5F)) {
      /* '<S338>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_l = (-rtb_Add5_g) / rtb_TTLC_h;
    } else {
      /* '<S338>:1:4' else */
      /* '<S338>:1:5' TTLC = single(3); */
      rtb_TTLC_l = 3.0F;
    }

    /* End of MATLAB Function: '<S306>/MATLABFunction1' */

    /* Saturate: '<S306>/Saturation1' */
    if (rtb_TTLC_l > 2.0F) {
      rtb_TTLC_l = 2.0F;
    } else {
      if (rtb_TTLC_l < 0.6F) {
        rtb_TTLC_l = 0.6F;
      }
    }

    /* End of Saturate: '<S306>/Saturation1' */

    /* MATLAB Function: '<S306>/MATLABFunction5' incorporates:
     *  Gain: '<S336>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction5': '<S342>:1' */
    /* '<S342>:1:2' K = single(single(0.09)/single(vx)); */
    /* '<S342>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_SW_Angle) / (((((((0.09F / rtb_Abs_b_tmp) *
      rtb_Abs_b_tmp) * rtb_Abs_b_tmp) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_o) *
      LKAS_DW.LKA_StrRatio_C_c) * 2.0F);

    /* MATLAB Function: '<S306>/MATLABFunction3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction3': '<S340>:1' */
    /* '<S340>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2_f - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_c > 0.0F) || (rtb_L0_C1_c < 0.0F))) {
      /* '<S340>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_c) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_c;
      if (x10 > 0.0F) {
        /* '<S340>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_Abs_b_tmp;
      } else {
        /* '<S340>:1:9' else */
        /* '<S340>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_c * rtb_L0_C1_c) - ((x10 * 4.0F) * x20);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S340>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S340>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_c)) / x1;

        /* '<S340>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_c) - x20) / x1;

        /* '<S340>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S340>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S340>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S340>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_Abs_b_tmp;
        } else if (x1 > 0.0F) {
          /* '<S340>:1:19' elseif x1>0 */
          /* '<S340>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_Abs_b_tmp;
        } else {
          /* '<S340>:1:21' else */
          /* '<S340>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S340>:1:24' else */
        /* '<S340>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S340>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S306>/MATLABFunction4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction4': '<S341>:1' */
    /* '<S341>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_R0_C2_b - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_h5 > 0.0F) || (rtb_L0_C1_h5 < 0.0F))) {
      /* '<S341>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_R0_C0_j) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1_h5;
      if (x10 > 0.0F) {
        /* '<S341>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_b_tmp;
      } else {
        /* '<S341>:1:9' else */
        /* '<S341>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_h5 * rtb_L0_C1_h5) - ((x10 * 4.0F) * rtb_Add5_g_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S341>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S341>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_h5)) / x1;

        /* '<S341>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_h5) - x20) / x1;

        /* '<S341>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S341>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S341>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S341>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_b_tmp;
        } else if (x1 > 0.0F) {
          /* '<S341>:1:19' elseif x1>0 */
          /* '<S341>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_Abs_b_tmp;
        } else {
          /* '<S341>:1:21' else */
          /* '<S341>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S341>:1:24' else */
        /* '<S341>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S341>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S306>/MATLABFunction2' incorporates:
     *  Constant: '<S306>/Constant'
     *  Constant: '<S306>/Constant1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction2': '<S339>:1' */
    /* '<S339>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - 2.0F) / rtb_LftTTLC) <= 0.2F) {
      /* '<S339>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, 2.0F);
    } else {
      /* '<S339>:1:4' else */
      /* '<S339>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S339>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_l - 2.0F) / rtb_TTLC_l) <= 0.2F) {
      /* '<S339>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_l = fminf(rtb_TTLC_l, 2.0F);
    } else {
      /* '<S339>:1:10' else */
      /* '<S339>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S339>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_gv) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S339>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S339>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_a) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_l)
           / rtb_TTLC_l) <= 0.7F)) && (rtb_TTLC_l <= 1.95F)) {
      /* '<S339>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_l = (rtb_TTLC_l + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S306>/Saturation7' incorporates:
     *  MATLAB Function: '<S306>/MATLABFunction2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S306>/Saturation7' */

    /* Saturate: '<S306>/Saturation8' incorporates:
     *  MATLAB Function: '<S306>/MATLABFunction2'
     */
    if (rtb_TTLC_l > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_l < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_l;
    }

    /* End of Saturate: '<S306>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S150>/Subsystem' incorporates:
     *  EnablePort: '<S159>/Enable'
     */
    /* Abs: '<S301>/Abs' incorporates:
     *  MATLAB Function: '<S159>/DriverSwaTrqAdd'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_L0_C0_c);

    /* Abs: '<S301>/Abs1' incorporates:
     *  MATLAB Function: '<S159>/DriverSwaTrqAdd'
     */
    rtb_Add5_g_tmp = fabsf(rtb_R0_C0_j);

    /* End of Outputs for SubSystem: '<S150>/Subsystem' */
    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Sum: '<S301>/Add' incorporates:
     *  Abs: '<S301>/Abs'
     *  Abs: '<S301>/Abs1'
     */
    rtb_LftTTLC = rtb_LKA_Veh2CamW_C + rtb_Add5_g_tmp;

    /* Saturate: '<S301>/Saturation' */
    if (rtb_LftTTLC > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_LftTTLC < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_LftTTLC;
    }

    /* End of Saturate: '<S301>/Saturation' */

    /* If: '<S312>/If' incorporates:
     *  Delay: '<S142>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE_f) == 1) {
      /* Outputs for IfAction SubSystem: '<S312>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S315>/Action Port'
       */
      LKAS_IfActionSubsystem2_f(rtb_Add_gv, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S312>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE_f) == 2) {
      /* Outputs for IfAction SubSystem: '<S312>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S314>/Action Port'
       */
      LKAS_IfActionSubsystem2_f(rtb_Add_a, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S312>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S312>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S316>/Action Port'
       */
      /* Gain: '<S316>/Gain' incorporates:
       *  Sum: '<S316>/Add'
       */
      rtb_Merge = (rtb_Add_gv + rtb_Add_a) * 0.5F;

      /* End of Outputs for SubSystem: '<S312>/If Action Subsystem3' */
    }

    /* End of If: '<S312>/If' */

    /* Switch: '<S600>/Switch' incorporates:
     *  Constant: '<S681>/Constant'
     *  Constant: '<S682>/Constant'
     *  Gain: '<S681>/Gain'
     *  Gain: '<S682>/Gain'
     *  Sum: '<S681>/Add'
     *  Sum: '<S682>/Add'
     *  Switch: '<S678>/Switch47'
     */
    if (LKAS_DW.LKA_Mode_k >= ((uint8)2U)) {
      /* Switch: '<S678>/Switch48' incorporates:
       *  Constant: '<S678>/LLSMConClb3'
       *
       * Block description for '<S678>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S678>/Switch48' */
      rtb_Switch_h = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S678>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S678>/Switch47' incorporates:
         *  Constant: '<S678>/LLSMConClb2'
         *
         * Block description for '<S678>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_h = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S600>/Switch' */

    /* Switch: '<S598>/Switch' incorporates:
     *  Constant: '<S598>/Constant'
     *  Constant: '<S598>/Constant1'
     *  Constant: '<S605>/Constant'
     *  Constant: '<S606>/Constant'
     *  Constant: '<S607>/Constant'
     *  Logic: '<S598>/Logical Operator'
     *  RelationalOperator: '<S605>/Compare'
     *  RelationalOperator: '<S606>/Compare'
     *  RelationalOperator: '<S607>/Compare'
     */
    if (((rtb_Rrg_Q >= ((uint8)3U)) || (((sint32)(rtb_BCM_Left_Light ? 1 : 0)) >
          ((sint32)(false ? 1 : 0)))) || (((sint32)(rtb_BCM_Right_Light ? 1 : 0))
         > ((sint32)(false ? 1 : 0)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S598>/Switch' */

    /* Sum: '<S598>/Add' incorporates:
     *  Memory: '<S598>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_i;

    /* Saturate: '<S598>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_j = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_j = (-1.0F);
    } else {
      rtb_Saturation_j = rtb_LftTTLC;
    }

    /* End of Saturate: '<S598>/Saturation' */

    /* Abs: '<S591>/Abs1' incorporates:
     *  Abs: '<S493>/Abs1'
     */
    x1 = fabsf(rtb_LaneWidth);
    rtb_Abs1 = x1;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S589>/Abs' incorporates:
     *  Abs: '<S181>/Abs'
     *  Abs: '<S182>/Abs'
     *  Abs: '<S183>/Abs4'
     *  Abs: '<S491>/Abs'
     *  MATLAB Function: '<S457>/MATLAB Function'
     */
    rtb_TTLC_l = fabsf(rtb_Merge);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC_l;

    /* Switch: '<S678>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S550>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S550>/Unary Minus' incorporates:
       *  Constant: '<S678>/LLSMConClb11'
       *
       * Block description for '<S678>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S678>/Switch53' */

    /* Switch: '<S678>/Switch87' incorporates:
     *  Constant: '<S678>/LLSMConClb8'
     *
     * Block description for '<S678>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S678>/Switch87' */

    /* Switch: '<S678>/Switch49' incorporates:
     *  Constant: '<S678>/LLSMConClb43'
     *
     * Block description for '<S678>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S678>/Switch49' */

    /* Switch: '<S678>/Switch88' incorporates:
     *  Constant: '<S678>/LLSMConClb9'
     *
     * Block description for '<S678>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_LftTTLC = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S678>/Switch88' */

    /* Switch: '<S678>/Switch50' incorporates:
     *  Constant: '<S678>/LLSMConClb10'
     *
     * Block description for '<S678>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      tmp = LKAS_ConstB.DataTypeConversion17;
    } else {
      tmp = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S678>/Switch50' */

    /* Abs: '<S587>/Abs' incorporates:
     *  Abs: '<S489>/Abs'
     *  Sum: '<S587>/Add'
     */
    rtb_LogicalOperator3_l_tmp = fabsf(rtb_L0_C1_c - rtb_L0_C1_h5);

    /* Abs: '<S550>/Abs2' incorporates:
     *  Abs: '<S331>/Abs2'
     *  Abs: '<S455>/Abs2'
     */
    rtb_TTLC = fabsf(rtb_SW_Angle);

    /* Abs: '<S550>/Abs3' incorporates:
     *  Abs: '<S455>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     *  Inport: '<Root>/IMAPve_g_SW_Angle_Speed'
     */
    rtb_LogicalOperator3_l_tmp_0 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
      ());

    /* Abs: '<S550>/Abs4' incorporates:
     *  Abs: '<S455>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     *  Inport: '<Root>/IMAPve_g_ESC_LatAcc'
     */
    rtb_LogicalOperator3_l_tmp_1 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc());

    /* Abs: '<S550>/Abs1' incorporates:
     *  Abs: '<S456>/Abs'
     *  Abs: '<S457>/Abs'
     */
    rtb_TLft = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S551>/Logical Operator2' incorporates:
     *  Abs: '<S550>/Abs1'
     *  Abs: '<S550>/Abs2'
     *  Abs: '<S550>/Abs3'
     *  Abs: '<S550>/Abs4'
     *  Abs: '<S587>/Abs'
     *  Constant: '<S589>/Constant'
     *  Constant: '<S592>/Constant'
     *  Constant: '<S594>/Constant'
     *  Constant: '<S595>/Constant'
     *  Constant: '<S602>/Constant'
     *  Constant: '<S603>/Constant'
     *  Constant: '<S604>/Constant'
     *  Constant: '<S608>/Constant'
     *  Logic: '<S550>/Logical Operator3'
     *  Logic: '<S556>/FixPt Logical Operator'
     *  Logic: '<S588>/Logical Operator3'
     *  Logic: '<S590>/Logical Operator'
     *  Logic: '<S593>/FixPt Logical Operator'
     *  Logic: '<S596>/FixPt Logical Operator'
     *  Logic: '<S597>/Logical Operator'
     *  Logic: '<S601>/Logical Operator'
     *  Logic: '<S609>/FixPt Logical Operator'
     *  RelationalOperator: '<S550>/Relational Operator'
     *  RelationalOperator: '<S550>/Relational Operator1'
     *  RelationalOperator: '<S550>/Relational Operator2'
     *  RelationalOperator: '<S550>/Relational Operator3'
     *  RelationalOperator: '<S556>/Lower Test'
     *  RelationalOperator: '<S556>/Upper Test'
     *  RelationalOperator: '<S592>/Compare'
     *  RelationalOperator: '<S593>/Lower Test'
     *  RelationalOperator: '<S593>/Upper Test'
     *  RelationalOperator: '<S594>/Compare'
     *  RelationalOperator: '<S595>/Compare'
     *  RelationalOperator: '<S596>/Lower Test'
     *  RelationalOperator: '<S596>/Upper Test'
     *  RelationalOperator: '<S602>/Compare'
     *  RelationalOperator: '<S603>/Compare'
     *  RelationalOperator: '<S604>/Compare'
     *  RelationalOperator: '<S608>/Compare'
     *  RelationalOperator: '<S609>/Lower Test'
     *  RelationalOperator: '<S609>/Upper Test'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_LogicalOperator3_c = (((((((rtb_Gain_a <= rtb_ESC_VehSpd) &&
      (rtb_ESC_VehSpd <= rtb_Switch_h)) && ((rtb_L0_Q == ((uint8)0U)) &&
      (rtb_Lrg_Q == ((uint8)0U)))) && (rtb_Saturation_j <= 0.0F)) &&
      (rtb_TCU_ActualGear == ((uint8)3U))) && (((((rtb_IMAPve_d_LKA_Mode >
      ((uint8)2U)) && (rtb_R0_Q_c > ((uint8)2U))) &&
      ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) && (rtb_Abs1 <=
      rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) && (rtb_Abs <=
      rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) && (rtb_LogicalOperator3_l_tmp <=
      0.025F))) && (((((rtb_TTLC < x10) && (rtb_LogicalOperator3_l_tmp_0 < x20))
                      && (rtb_TLft < rtb_LftTTLC)) &&
                     (rtb_LogicalOperator3_l_tmp_1 < tmp)) && ((rtb_UnaryMinus <
      rtb_IMAPve_g_ESC_LonAcc) && (rtb_IMAPve_g_ESC_LonAcc <
      rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* MATLAB Function: '<S584>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_LKA_EnableLine_Max, rtb_LL_LKA_EnableLine_DvtMin,
                        rtb_LL_LKA_EnableLine_DvtMax, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_LKA_Enable_Line);

    /* Switch: '<S586>/Switch' incorporates:
     *  Constant: '<S584>/Constant'
     *  RelationalOperator: '<S586>/UpperRelop'
     */
    if (rtb_LKA_Enable_Line < 0.0F) {
      rtb_Switch_f = 0.0F;
    } else {
      rtb_Switch_f = rtb_LKA_Enable_Line;
    }

    /* End of Switch: '<S586>/Switch' */

    /* Switch: '<S586>/Switch2' incorporates:
     *  RelationalOperator: '<S586>/LowerRelop1'
     */
    if (rtb_LKA_Enable_Line > rtb_LL_LKA_EnableLine_Max) {
      rtb_Switch2_d = rtb_LL_LKA_EnableLine_Max;
    } else {
      rtb_Switch2_d = rtb_Switch_f;
    }

    /* End of Switch: '<S586>/Switch2' */

    /* Abs: '<S571>/Abs1' incorporates:
     *  Abs: '<S479>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S571>/Abs2' incorporates:
     *  Abs: '<S479>/Abs1'
     */
    x20 = fabsf(rtb_TTLC_h);

    /* If: '<S551>/If1' incorporates:
     *  Abs: '<S571>/Abs1'
     *  Abs: '<S571>/Abs2'
     *  Constant: '<S558>/Constant'
     *  Constant: '<S573>/Constant'
     *  Constant: '<S574>/Constant'
     *  Constant: '<S579>/Constant'
     *  Constant: '<S580>/Constant'
     *  Constant: '<S581>/Constant'
     *  Constant: '<S582>/Constant'
     *  Logic: '<S551>/Logical Operator1'
     *  Logic: '<S568>/Logical Operator'
     *  Logic: '<S570>/Logical Operator'
     *  Logic: '<S571>/Logical Operator'
     *  Logic: '<S572>/Logical Operator'
     *  RelationalOperator: '<S571>/Relational Operator2'
     *  RelationalOperator: '<S571>/Relational Operator3'
     *  RelationalOperator: '<S572>/Relational Operator1'
     *  RelationalOperator: '<S572>/Relational Operator2'
     *  RelationalOperator: '<S573>/Compare'
     *  RelationalOperator: '<S574>/Compare'
     *  RelationalOperator: '<S579>/Compare'
     *  RelationalOperator: '<S580>/Compare'
     *  RelationalOperator: '<S581>/Compare'
     *  RelationalOperator: '<S582>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (rtb_LogicalOperator3_c &&
         ((((LKAS_DW.LKA_Mode_k == ((uint8)2U)) && (((sint32)
              (((rtb_FDMMve_d_LkaFcnConf == ((uint8)2U)) ||
                (rtb_FDMMve_d_LkaFcnConf == ((uint8)1U))) ? 1 : 0)) == ((sint32)
              (true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1 >= rtb_Switch2_d) &&
              (rtb_Add5_g >= rtb_Switch2_d)) ? 1 : 0)) == ((sint32)(true ? 1 : 0))))))
    {
      /* Outputs for IfAction SubSystem: '<S551>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S558>/Action Port'
       */
      LKAS_DW.Merge1_e = true;

      /* End of Outputs for SubSystem: '<S551>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S551>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S560>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_e);

      /* End of Outputs for SubSystem: '<S551>/If Action Subsystem4' */
    }

    /* End of If: '<S551>/If1' */

    /* Switch: '<S540>/Switch' incorporates:
     *  Constant: '<S679>/Constant'
     *  Constant: '<S684>/Constant'
     *  Gain: '<S679>/Gain'
     *  Gain: '<S684>/Gain'
     *  Sum: '<S679>/Add'
     *  Sum: '<S684>/Add'
     *  Switch: '<S678>/Switch67'
     */
    if (LKAS_DW.LKA_Mode_k >= ((uint8)2U)) {
      /* Switch: '<S678>/Switch80' incorporates:
       *  Constant: '<S678>/LLSMConClb21'
       *
       * Block description for '<S678>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_LftTTLC = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S678>/Switch80' */
      rtb_Switch_m = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S678>/Switch67' */
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S678>/Switch67' incorporates:
         *  Constant: '<S678>/LLSMConClb20'
         *
         * Block description for '<S678>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_LftTTLC = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_m = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S540>/Switch' */

    /* Logic: '<S540>/Logical Operator' incorporates:
     *  Logic: '<S549>/FixPt Logical Operator'
     *  RelationalOperator: '<S549>/Lower Test'
     *  RelationalOperator: '<S549>/Upper Test'
     */
    rtb_LogicalOperator_fs = ((rtb_Gain_jm >= rtb_ESC_VehSpd) || (rtb_ESC_VehSpd
      >= rtb_Switch_m));

    /* Logic: '<S538>/Logical Operator' incorporates:
     *  Logic: '<S358>/Logical Operator6'
     */
    rtb_LL_SingleLane_Disable_Swt = !rtb_LL_SingleLane_Disable_Swt;

    /* Switch: '<S538>/Switch' incorporates:
     *  Constant: '<S538>/Constant'
     *  Constant: '<S538>/Constant1'
     *  Constant: '<S545>/Constant'
     *  Constant: '<S546>/Constant'
     *  Constant: '<S547>/Constant'
     *  Delay: '<S143>/Delay1'
     *  Logic: '<S538>/Logical Operator'
     *  Logic: '<S538>/Logical Operator1'
     *  Logic: '<S538>/Logical Operator2'
     *  Logic: '<S538>/Logical Operator3'
     *  Logic: '<S538>/Logical Operator4'
     *  Logic: '<S538>/Logical Operator5'
     *  RelationalOperator: '<S545>/Compare'
     *  RelationalOperator: '<S546>/Compare'
     *  RelationalOperator: '<S547>/Compare'
     */
    if (((((rtb_Rrg_Q >= ((uint8)3U)) || (rtb_BCM_Left_Light &&
            rtb_LL_SingleLane_Disable_Swt)) || (rtb_BCM_Right_Light &&
           rtb_LL_SingleLane_Disable_Swt)) || (rtb_BCM_Left_Light &&
          (LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)))) || (rtb_BCM_Right_Light &&
         (LKAS_DW.Delay1_3_DSTATE == ((uint8)5U)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S538>/Switch' */

    /* Sum: '<S538>/Add' incorporates:
     *  Memory: '<S538>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_g;

    /* Saturate: '<S538>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_l = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_l = (-1.0F);
    } else {
      rtb_Saturation_l = rtb_LftTTLC;
    }

    /* End of Saturate: '<S538>/Saturation' */

    /* RelationalOperator: '<S544>/Compare' incorporates:
     *  Constant: '<S544>/Constant'
     */
    rtb_Compare_nvo = (rtb_Saturation_l > 1.0F);

    /* RelationalOperator: '<S548>/Compare' incorporates:
     *  Constant: '<S548>/Constant'
     */
    rtb_Compare_o3 = (rtb_TCU_ActualGear != ((uint8)3U));

    /* Logic: '<S492>/Logical Operator' incorporates:
     *  Constant: '<S496>/Constant'
     *  Constant: '<S497>/Constant'
     *  RelationalOperator: '<S496>/Compare'
     *  RelationalOperator: '<S497>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_LogicalOperator_hu = ((rtb_IMAPve_d_LKA_Mode < ((uint8)3U)) &&
      (rtb_R0_Q_c < ((uint8)3U)));

    /* Abs: '<S493>/Abs1' */
    rtb_Abs1_b = x1;

    /* RelationalOperator: '<S498>/Compare' incorporates:
     *  Constant: '<S498>/Constant'
     *  Logic: '<S499>/FixPt Logical Operator'
     *  RelationalOperator: '<S499>/Lower Test'
     *  RelationalOperator: '<S499>/Upper Test'
     */
    rtb_Compare_mws = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_b) &&
      (rtb_Abs1_b <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S491>/Abs' */
    rtb_Abs_k = rtb_TTLC_l;

    /* Logic: '<S491>/Logical Operator' incorporates:
     *  Constant: '<S491>/Constant'
     *  Logic: '<S495>/FixPt Logical Operator'
     *  RelationalOperator: '<S495>/Lower Test'
     *  RelationalOperator: '<S495>/Upper Test'
     */
    rtb_LogicalOperator_g = ((0.0F > rtb_Abs_k) || (rtb_Abs_k >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S494>/Compare' incorporates:
     *  Constant: '<S494>/Constant'
     */
    rtb_Compare_j2 = (rtb_LogicalOperator3_l_tmp > 0.04F);

    /* Switch: '<S678>/Switch72' incorporates:
     *  Constant: '<S678>/LLSMConClb26'
     *
     * Block description for '<S678>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S678>/Switch72' */

    /* RelationalOperator: '<S455>/Relational Operator1' */
    rtb_phiSWA_Thres = (rtb_TTLC >= rtb_LftTTLC);

    /* Switch: '<S678>/Switch74' incorporates:
     *  Constant: '<S678>/LLSMConClb28'
     *
     * Block description for '<S678>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S678>/Switch74' */

    /* RelationalOperator: '<S455>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_LogicalOperator3_l_tmp_0 >= rtb_LftTTLC);

    /* Switch: '<S678>/Switch79' incorporates:
     *  Constant: '<S678>/LLSMConClb29'
     *
     * Block description for '<S678>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_LftTTLC = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S678>/Switch79' */

    /* Logic: '<S455>/Logical Operator1' incorporates:
     *  Constant: '<S458>/Constant'
     *  RelationalOperator: '<S455>/Relational Operator3'
     *  RelationalOperator: '<S458>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_l_tmp_1 >= rtb_LftTTLC) &&
                       (rtb_FDMMve_d_LkaFcnConf != ((uint8)3U)));

    /* Switch: '<S678>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S455>/Unary Minus' */
      rtb_UnaryMinus_m = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S455>/Unary Minus' incorporates:
       *  Constant: '<S678>/LLSMConClb30'
       *
       * Block description for '<S678>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_m = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S678>/Switch61' */

    /* RelationalOperator: '<S459>/Compare' incorporates:
     *  Constant: '<S459>/Constant'
     *  Logic: '<S460>/FixPt Logical Operator'
     *  RelationalOperator: '<S460>/Lower Test'
     *  RelationalOperator: '<S460>/Upper Test'
     */
    rtb_Compare_pe = (((sint32)(((rtb_UnaryMinus_m < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                      ((sint32)(false ? 1 : 0)));

    /* Logic: '<S456>/Logical Operator3' incorporates:
     *  Abs: '<S456>/Abs1'
     *  Constant: '<S456>/Constant'
     *  Constant: '<S456>/Constant1'
     *  Memory: '<S456>/Memory'
     *  RelationalOperator: '<S456>/Relational Operator1'
     *  RelationalOperator: '<S456>/Relational Operator2'
     *  Sum: '<S456>/Add'
     */
    rtb_LogicalOperator3_do = ((rtb_TLft <= 0.8F) && (fabsf
      (LKAS_DW.Memory_PreviousInput_e - rtb_IMAPve_g_EPS_SW_Trq) <= 0.01F));

    /* Outputs for Enabled SubSystem: '<S456>/ExitCount1' */
    /* Constant: '<S456>/Constant2' */
    LKAS_ExitCount(rtb_LogicalOperator3_do, rtb_LKA_SampleTime, 5.0F,
                   &LKAS_DW.RelationalOperator_j, &LKAS_DW.ExitCount1);

    /* End of Outputs for SubSystem: '<S456>/ExitCount1' */

    /* Switch: '<S456>/Switch' incorporates:
     *  Constant: '<S461>/Constant'
     *  RelationalOperator: '<S461>/Compare'
     */
    if (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U)) {
      rtb_TTLC_h = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
    } else {
      rtb_TTLC_h = rtb_R0_C1_g;
    }

    /* End of Switch: '<S456>/Switch' */

    /* Logic: '<S456>/OR' incorporates:
     *  RelationalOperator: '<S456>/Relational Operator'
     */
    rtb_OR_b = ((rtb_TLft <= rtb_TTLC_h) || (LKAS_DW.RelationalOperator_j));

    /* Product: '<S456>/Divide' incorporates:
     *  Constant: '<S462>/Constant'
     *  Constant: '<S463>/Constant'
     *  Logic: '<S456>/Logical Operator1'
     *  Logic: '<S456>/Logical Operator2'
     *  RelationalOperator: '<S462>/Compare'
     *  RelationalOperator: '<S463>/Compare'
     */
    rtb_Divide_e = (((rtb_FDMMve_d_LkaFcnConf == ((uint8)1U)) ||
                     (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U))) && rtb_OR_b) ?
      rtb_LKA_SampleTime : 0.0F;

    /* Outputs for Enabled SubSystem: '<S456>/ExitCount' */
    LKAS_ExitCount(rtb_OR_b, rtb_Divide_e, rtb_LL_HandsOff_ExitTime,
                   &LKAS_DW.RelationalOperator_o, &LKAS_DW.ExitCount);

    /* End of Outputs for SubSystem: '<S456>/ExitCount' */

    /* Saturate: '<S457>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S466>:1' */
    /* '<S466>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S466>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S466>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S466>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_ESC_VehSpd > 80.0F) {
      rtb_LftTTLC = 80.0F;
    } else if (rtb_ESC_VehSpd < 60.0F) {
      rtb_LftTTLC = 60.0F;
    } else {
      rtb_LftTTLC = rtb_ESC_VehSpd;
    }

    /* End of Saturate: '<S457>/Saturation' */

    /* MATLAB Function: '<S457>/MATLAB Function' */
    if (rtb_TLft >= fminf(fmaxf(1.5F, ((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
           - ((rtb_LftTTLC / 180.0F) * rtb_LL_MAX_DRIVER_TORQUE_DISABL)) +
          (rtb_TTLC_l / 0.005F)), 2.75F)) {
      /* Outputs for Enabled SubSystem: '<S457>/Sum Condition1' incorporates:
       *  EnablePort: '<S467>/state = reset'
       */
      /* '<S466>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_i) {
        /* InitializeConditions for Memory: '<S467>/Memory' */
        LKAS_DW.Memory_PreviousInput_l = 0.0F;
        LKAS_DW.SumCondition1_MODE_i = true;
      }

      /* Sum: '<S467>/Add1' incorporates:
       *  Memory: '<S467>/Memory'
       */
      rtb_LKA_Veh2CamL_C = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_l;

      /* Saturate: '<S467>/Saturation' */
      if (rtb_LKA_Veh2CamL_C > 5000.0F) {
        rtb_LKA_Veh2CamL_C = 5000.0F;
      } else {
        if (rtb_LKA_Veh2CamL_C < 0.0F) {
          rtb_LKA_Veh2CamL_C = 0.0F;
        }
      }

      /* End of Saturate: '<S467>/Saturation' */
      /* End of Outputs for SubSystem: '<S457>/Sum Condition1' */

      /* Switch: '<S678>/Switch65' incorporates:
       *  Constant: '<S678>/LLSMConClb34'
       *
       * Block description for '<S678>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_LftTTLC = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S678>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S457>/Sum Condition1' incorporates:
       *  EnablePort: '<S467>/state = reset'
       */
      /* RelationalOperator: '<S467>/Relational Operator' */
      LKAS_DW.RelationalOperator_m = (rtb_LKA_Veh2CamL_C >= rtb_LftTTLC);

      /* Update for Memory: '<S467>/Memory' */
      LKAS_DW.Memory_PreviousInput_l = rtb_LKA_Veh2CamL_C;

      /* End of Outputs for SubSystem: '<S457>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S457>/Sum Condition1' incorporates:
       *  EnablePort: '<S467>/state = reset'
       */
      /* '<S466>:1:7' else */
      /* '<S466>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S467>/Out' */
        LKAS_DW.RelationalOperator_m = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Outputs for SubSystem: '<S457>/Sum Condition1' */
    }

    /* RelationalOperator: '<S473>/Compare' incorporates:
     *  Constant: '<S473>/Constant'
     */
    rtb_Compare_neb = (((sint32)(LKAS_DW.RelationalOperator_m ? 1 : 0)) >
                       ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S468>/Unit Delay' */
    rtb_UnitDelay_na = LKAS_DW.UnitDelay_DSTATE_e;

    /* If: '<S468>/If' incorporates:
     *  Constant: '<S470>/Constant'
     *  RelationalOperator: '<S469>/FixPt Relational Operator'
     *  UnitDelay: '<S469>/Delay Input1'
     *
     * Block description for '<S469>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if (((sint32)(rtb_Compare_neb ? 1 : 0)) > ((sint32)
         (LKAS_DW.DelayInput1_DSTATE ? 1 : 0))) {
      /* Outputs for IfAction SubSystem: '<S468>/If Action Subsystem' incorporates:
       *  ActionPort: '<S470>/Action Port'
       */
      rtb_Merge_f = true;

      /* End of Outputs for SubSystem: '<S468>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S468>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S471>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_na, &rtb_Merge_f);

      /* End of Outputs for SubSystem: '<S468>/If Action Subsystem3' */
    }

    /* End of If: '<S468>/If' */

    /* Outputs for Enabled SubSystem: '<S468>/Sum Condition1' incorporates:
     *  EnablePort: '<S472>/state = reset'
     */
    if (rtb_Merge_f) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S472>/Memory' */
        LKAS_DW.Memory_PreviousInput_b = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S472>/Add1' incorporates:
       *  Memory: '<S472>/Memory'
       */
      rtb_LKA_Veh2CamL_C = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_b;

      /* Saturate: '<S472>/Saturation' */
      if (rtb_LKA_Veh2CamL_C > 10.0F) {
        rtb_LKA_Veh2CamL_C = 10.0F;
      } else {
        if (rtb_LKA_Veh2CamL_C < 0.0F) {
          rtb_LKA_Veh2CamL_C = 0.0F;
        }
      }

      /* End of Saturate: '<S472>/Saturation' */

      /* RelationalOperator: '<S472>/Relational Operator' */
      LKAS_DW.RelationalOperator_h = (rtb_LKA_Veh2CamL_C <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S472>/Memory' */
      LKAS_DW.Memory_PreviousInput_b = rtb_LKA_Veh2CamL_C;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S472>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S468>/Sum Condition1' */

    /* Logic: '<S468>/Logical Operator' */
    rtb_stDvrTkConFlg_n = ((LKAS_DW.RelationalOperator_m) ||
      (LKAS_DW.RelationalOperator_h));

    /* Logic: '<S441>/Logical Operator2' incorporates:
     *  Constant: '<S542>/Constant'
     *  Constant: '<S543>/Constant'
     *  Logic: '<S454>/Logical Operator1'
     *  Logic: '<S455>/Logical Operator'
     *  Logic: '<S490>/Logical Operator3'
     *  Logic: '<S537>/OR'
     *  Logic: '<S541>/Logical Operator3'
     *  RelationalOperator: '<S542>/Compare'
     *  RelationalOperator: '<S543>/Compare'
     */
    rtb_RelationalOperator_n = (((((rtb_LogicalOperator_fs || ((rtb_L0_Q ==
      ((uint8)1U)) || (rtb_Lrg_Q == ((uint8)1U)))) || rtb_Compare_nvo) ||
      rtb_Compare_o3) || (((rtb_LogicalOperator_hu || rtb_Compare_mws) ||
      rtb_LogicalOperator_g) || rtb_Compare_j2)) || (((((rtb_phiSWA_Thres ||
      rtb_dphiSWARate_Thres) || rtb_aLAcc_Thres) || rtb_Compare_pe) ||
      (LKAS_DW.RelationalOperator_o)) || rtb_stDvrTkConFlg_n));

    /* Logic: '<S479>/Logical Operator' incorporates:
     *  RelationalOperator: '<S479>/Relational Operator1'
     *  RelationalOperator: '<S479>/Relational Operator2'
     */
    rtb_LogicalOperator_kx = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S480>/Logical Operator' incorporates:
     *  RelationalOperator: '<S480>/Relational Operator1'
     *  RelationalOperator: '<S480>/Relational Operator2'
     */
    rtb_LogicalOperator_aq = ((rtb_Gain1 <= rtb_LL_LKA_LatestWarnLine_C) ||
      (rtb_Add5_g <= rtb_LL_LKA_LatestWarnLine_C));

    /* If: '<S441>/If2' incorporates:
     *  Constant: '<S450>/Constant'
     *  Constant: '<S485>/Constant'
     *  Constant: '<S486>/Constant'
     *  Constant: '<S488>/Constant'
     *  Logic: '<S441>/Logical Operator1'
     *  Logic: '<S478>/Logical Operator'
     *  Logic: '<S478>/Logical Operator1'
     *  RelationalOperator: '<S485>/Compare'
     *  RelationalOperator: '<S486>/Compare'
     *  RelationalOperator: '<S488>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (rtb_RelationalOperator_n ||
         ((LKAS_DW.LKA_Mode_k == ((uint8)2U)) && ((rtb_LogicalOperator_kx ==
            true) || (rtb_LogicalOperator_aq == true))))) {
      /* Outputs for IfAction SubSystem: '<S441>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S450>/Action Port'
       */
      LKAS_DW.Merge2 = true;

      /* End of Outputs for SubSystem: '<S441>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S441>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S452>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2);

      /* End of Outputs for SubSystem: '<S441>/If Action Subsystem3' */
    }

    /* End of If: '<S441>/If2' */

    /* If: '<S378>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_g >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S378>/Ph1SWA' incorporates:
       *  ActionPort: '<S382>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S378>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_g <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S378>/Ph2SWA' incorporates:
       *  ActionPort: '<S383>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S378>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S378>/Ph3SWA' incorporates:
       *  ActionPort: '<S384>/Action Port'
       */
      LKAS_Ph3SWA_m(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S378>/Ph3SWA' */
    }

    /* End of If: '<S378>/If' */

    /* Saturate: '<S356>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = (-2.0F);
    } else {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_Gain1;
    }

    /* End of Saturate: '<S356>/Saturation5' */

    /* MATLAB Function: '<S365>/MATLAB Function' incorporates:
     *  MATLAB Function: '<S401>/MATLAB Function'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S368>:1' */
    /* '<S368>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S368>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S368>:1:5' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S368>:1:6' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S368>:1:7' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    x20 = (2.0F * rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth;
    x20 = fminf(fmaxf(0.0F, (fminf(fmaxf(x20, rtb_LaneWidth), (6.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth) - x20) / (4.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW)), 1.0F);

    /* Product: '<S365>/Divide5' incorporates:
     *  MATLAB Function: '<S365>/MATLAB Function'
     */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S365>/Divide6' incorporates:
     *  MATLAB Function: '<S365>/MATLAB Function'
     */
    rtb_TLft = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S380>/Abs' incorporates:
     *  Abs: '<S371>/Abs'
     *  Abs: '<S407>/Abs'
     */
    x1 = fabsf(rtb_Abs_a);

    /* Product: '<S380>/Divide' incorporates:
     *  Abs: '<S380>/Abs'
     */
    rtb_Divide_h = rtb_TLft * x1;

    /* Product: '<S365>/Divide4' incorporates:
     *  MATLAB Function: '<S365>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S385>/Switch' incorporates:
     *  RelationalOperator: '<S385>/UpperRelop'
     */
    if (rtb_Divide_h < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_p = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_p = rtb_Divide_h;
    }

    /* End of Switch: '<S385>/Switch' */

    /* Switch: '<S385>/Switch2' incorporates:
     *  RelationalOperator: '<S385>/LowerRelop1'
     */
    if (rtb_Divide_h > rtb_LftTTLC) {
      rtb_Switch2_m = rtb_LftTTLC;
    } else {
      rtb_Switch2_m = rtb_Switch_p;
    }

    /* End of Switch: '<S385>/Switch2' */

    /* Saturate: '<S356>/Saturation1' */
    if (rtb_Add5_g > 2.0F) {
      rtb_TTLC_h = 2.0F;
    } else if (rtb_Add5_g < (-2.0F)) {
      rtb_TTLC_h = (-2.0F);
    } else {
      rtb_TTLC_h = rtb_Add5_g;
    }

    /* End of Saturate: '<S356>/Saturation1' */

    /* Abs: '<S381>/Abs' incorporates:
     *  Abs: '<S372>/Abs'
     *  Abs: '<S408>/Abs'
     */
    rtb_LogicalOperator3_l_tmp = fabsf(rtb_Abs_g);

    /* Product: '<S381>/Divide' incorporates:
     *  Abs: '<S381>/Abs'
     */
    rtb_Divide_g = rtb_TLft * rtb_LogicalOperator3_l_tmp;

    /* Switch: '<S386>/Switch' incorporates:
     *  RelationalOperator: '<S386>/UpperRelop'
     */
    if (rtb_Divide_g < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_pc = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_pc = rtb_Divide_g;
    }

    /* End of Switch: '<S386>/Switch' */

    /* Switch: '<S386>/Switch2' incorporates:
     *  RelationalOperator: '<S386>/LowerRelop1'
     */
    if (rtb_Divide_g > rtb_LftTTLC) {
      rtb_Switch2_k = rtb_LftTTLC;
    } else {
      rtb_Switch2_k = rtb_Switch_pc;
    }

    /* End of Switch: '<S386>/Switch2' */

    /* Switch: '<S379>/Switch3' incorporates:
     *  Constant: '<S381>/Constant'
     *  Gain: '<S379>/Gain1'
     *  Logic: '<S381>/Logical Operator'
     *  RelationalOperator: '<S381>/Relational Operator1'
     *  RelationalOperator: '<S381>/Relational Operator2'
     */
    if (rtb_Merge1 >= 0.0F) {
      /* Switch: '<S379>/Switch2' incorporates:
       *  Constant: '<S379>/Constant2'
       *  Constant: '<S380>/Constant'
       *  DataTypeConversion: '<S379>/Cast To Single'
       *  Logic: '<S380>/Logical Operator'
       *  RelationalOperator: '<S380>/Relational Operator1'
       *  RelationalOperator: '<S380>/Relational Operator3'
       */
      if (rtb_Merge1 > 0.0F) {
        rtb_Lrg_Q = (uint8)(((0.0F < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) &&
                             (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <= rtb_Switch2_m))
                            ? 1 : 0);
      } else {
        rtb_Lrg_Q = ((uint8)0U);
      }

      /* End of Switch: '<S379>/Switch2' */
    } else {
      rtb_Lrg_Q = (uint8)((((uint32)(((0.0F < rtb_TTLC_h) && (rtb_TTLC_h <=
        rtb_Switch2_k)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S379>/Switch3' */

    /* DataTypeConversion: '<S358>/Data Type Conversion' incorporates:
     *  Constant: '<S389>/Constant'
     *  Constant: '<S390>/Constant'
     *  Constant: '<S391>/Constant'
     *  Constant: '<S392>/Constant'
     *  Logic: '<S358>/Logical Operator'
     *  Logic: '<S358>/Logical Operator1'
     *  Logic: '<S358>/Logical Operator2'
     *  Logic: '<S358>/Logical Operator3'
     *  Logic: '<S358>/Logical Operator4'
     *  Logic: '<S358>/Logical Operator5'
     *  Logic: '<S358>/Logical Operator7'
     *  RelationalOperator: '<S389>/Compare'
     *  RelationalOperator: '<S390>/Compare'
     *  RelationalOperator: '<S391>/Compare'
     *  RelationalOperator: '<S392>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_L0_Q = (uint8)(((((rtb_LL_SingleLane_Disable_Swt ||
      (!rtb_BCM_Right_Light)) && (rtb_R0_Q_c > ((uint8)2U))) && (rtb_Lrg_Q ==
      ((uint8)2U))) || (((rtb_LL_SingleLane_Disable_Swt || (!rtb_BCM_Left_Light))
                         && (rtb_Lrg_Q == ((uint8)1U))) &&
                        (rtb_IMAPve_d_LKA_Mode > ((uint8)2U)))) ? 1 : 0);

    /* DataTypeConversion: '<S357>/Data Type Conversion' incorporates:
     *  Constant: '<S387>/Constant'
     *  Constant: '<S388>/Constant'
     *  Logic: '<S357>/Logical Operator'
     *  RelationalOperator: '<S387>/Compare'
     *  RelationalOperator: '<S388>/Compare'
     */
    rtb_Rrg_Q = (uint8)(((rtb_FDMMve_d_LkaFcnConf == ((uint8)1U)) ||
                         (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U))) ? 1 : 0);

    /* If: '<S355>/If1' incorporates:
     *  Constant: '<S360>/Constant'
     *  Constant: '<S363>/Constant'
     *  Constant: '<S364>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (((sint32)rtb_Lrg_Q) == 1)) &&
         (((sint32)rtb_Rrg_Q) == 1)) && (((sint32)rtb_L0_Q) == 1)) {
      /* Outputs for IfAction SubSystem: '<S355>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S363>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S355>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (((sint32)rtb_Lrg_Q) ==
                  2)) && (((sint32)rtb_Rrg_Q) == 1)) && (((sint32)rtb_L0_Q) == 1))
    {
      /* Outputs for IfAction SubSystem: '<S355>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S364>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S355>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S355>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S360>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S355>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S355>/If1' */

    /* If: '<S415>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_g >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S415>/Ph1SWA' incorporates:
       *  ActionPort: '<S419>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_h);

      /* End of Outputs for SubSystem: '<S415>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_Abs_g <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S415>/Ph2SWA' incorporates:
       *  ActionPort: '<S420>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_h);

      /* End of Outputs for SubSystem: '<S415>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S415>/Ph3SWA' incorporates:
       *  ActionPort: '<S421>/Action Port'
       */
      LKAS_Ph3SWA_m(&rtb_Merge1_h);

      /* End of Outputs for SubSystem: '<S415>/Ph3SWA' */
    }

    /* End of If: '<S415>/If' */

    /* Saturate: '<S394>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_TLft = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_TLft = (-2.0F);
    } else {
      rtb_TLft = rtb_Gain1;
    }

    /* End of Saturate: '<S394>/Saturation5' */

    /* Product: '<S401>/Divide5' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S404>:1' */
    /* '<S404>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S404>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S404>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S404>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S404>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_LL_ThresDet_lDvtThresUprLKA *= x20;

    /* Product: '<S401>/Divide6' */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S417>/Divide' incorporates:
     *  Abs: '<S417>/Abs'
     */
    rtb_Divide_a = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_a);

    /* Product: '<S401>/Divide4' */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S422>/Switch' incorporates:
     *  RelationalOperator: '<S422>/UpperRelop'
     */
    if (rtb_Divide_a < rtb_LftTTLC) {
      rtb_Switch_eo = rtb_LftTTLC;
    } else {
      rtb_Switch_eo = rtb_Divide_a;
    }

    /* End of Switch: '<S422>/Switch' */

    /* Switch: '<S422>/Switch2' incorporates:
     *  RelationalOperator: '<S422>/LowerRelop1'
     */
    if (rtb_Divide_a > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_e = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_e = rtb_Switch_eo;
    }

    /* End of Switch: '<S422>/Switch2' */

    /* Saturate: '<S394>/Saturation1' */
    if (rtb_Add5_g > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_g < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_g;
    }

    /* End of Saturate: '<S394>/Saturation1' */

    /* Product: '<S418>/Divide' incorporates:
     *  Abs: '<S418>/Abs'
     */
    rtb_Divide_on = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_g);

    /* Switch: '<S423>/Switch' incorporates:
     *  RelationalOperator: '<S423>/UpperRelop'
     */
    if (rtb_Divide_on < rtb_LftTTLC) {
      rtb_Switch_g = rtb_LftTTLC;
    } else {
      rtb_Switch_g = rtb_Divide_on;
    }

    /* End of Switch: '<S423>/Switch' */

    /* Switch: '<S423>/Switch2' incorporates:
     *  RelationalOperator: '<S423>/LowerRelop1'
     */
    if (rtb_Divide_on > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_g = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_g = rtb_Switch_g;
    }

    /* End of Switch: '<S423>/Switch2' */

    /* Switch: '<S416>/Switch3' incorporates:
     *  Constant: '<S418>/Constant'
     *  Gain: '<S416>/Gain1'
     *  Logic: '<S418>/Logical Operator'
     *  RelationalOperator: '<S418>/Relational Operator1'
     *  RelationalOperator: '<S418>/Relational Operator2'
     */
    if (rtb_Merge1_h >= 0.0F) {
      /* Switch: '<S416>/Switch2' incorporates:
       *  Constant: '<S416>/Constant2'
       *  Constant: '<S417>/Constant'
       *  DataTypeConversion: '<S416>/Cast To Single'
       *  Logic: '<S417>/Logical Operator'
       *  RelationalOperator: '<S417>/Relational Operator1'
       *  RelationalOperator: '<S417>/Relational Operator3'
       */
      if (rtb_Merge1_h > 0.0F) {
        rtb_Lrg_Q = (uint8)(((0.0F < rtb_TLft) && (rtb_TLft <= rtb_Switch2_e)) ?
                            1 : 0);
      } else {
        rtb_Lrg_Q = ((uint8)0U);
      }

      /* End of Switch: '<S416>/Switch2' */
    } else {
      rtb_Lrg_Q = (uint8)((((uint32)(((0.0F < rtb_LL_ThresDet_lDvtThresLwrLKA) &&
        (rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_g)) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S416>/Switch3' */

    /* MATLAB Function: '<S395>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S427>:1' */
    /* '<S427>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S427>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S427>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S427>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge), 0.005F)) / 0.005F);

    /* '<S427>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_Lrg_Q) == 2) && (rtb_IMAPve_g_EPS_SW_Trq >
          rtb_LL_MAX_DRIVER_TORQUE_DISABL)) || ((((sint32)rtb_Lrg_Q) == 1) &&
         (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL)))) {
      /* Outputs for Enabled SubSystem: '<S395>/Count 0.2s' incorporates:
       *  EnablePort: '<S426>/Enable'
       */
      /* '<S427>:1:7' stDvrTkConFlg=1; */
      /* '<S427>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S427>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S426>/Memory' */
        LKAS_DW.Memory_PreviousInput_h = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S426>/Add' incorporates:
       *  Memory: '<S426>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_h;

      /* Saturate: '<S426>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S426>/Saturation' */
      /* End of Outputs for SubSystem: '<S395>/Count 0.2s' */

      /* Switch: '<S678>/Switch16' incorporates:
       *  Constant: '<S678>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S678>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S678>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S395>/Count 0.2s' incorporates:
       *  EnablePort: '<S426>/Enable'
       */
      /* RelationalOperator: '<S426>/Relational Operator' */
      LKAS_DW.RelationalOperator_oi = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S426>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S395>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S395>/Count 0.2s' incorporates:
       *  EnablePort: '<S426>/Enable'
       */
      /* '<S427>:1:10' else */
      /* '<S427>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S426>/Out' */
        LKAS_DW.RelationalOperator_oi = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S395>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S395>/MATLAB Function' */

    /* RelationalOperator: '<S436>/Compare' incorporates:
     *  Constant: '<S436>/Constant'
     */
    rtb_Compare_bo = (((sint32)(LKAS_DW.RelationalOperator_oi ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S428>/Unit Delay' */
    rtb_UnitDelay_c = LKAS_DW.UnitDelay_DSTATE_n;

    /* RelationalOperator: '<S435>/Compare' incorporates:
     *  Constant: '<S435>/Constant'
     */
    rtb_Compare_bn = (((sint32)(rtb_UnitDelay_c ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S428>/If' incorporates:
     *  Constant: '<S431>/Constant'
     *  Constant: '<S432>/Constant'
     *  RelationalOperator: '<S429>/FixPt Relational Operator'
     *  RelationalOperator: '<S430>/FixPt Relational Operator'
     *  UnitDelay: '<S429>/Delay Input1'
     *  UnitDelay: '<S430>/Delay Input1'
     *
     * Block description for '<S429>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S430>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_oi) && (((sint32)(rtb_Compare_bo ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_e ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S428>/If Action Subsystem' incorporates:
       *  ActionPort: '<S431>/Action Port'
       */
      rtb_Merge_o0 = true;

      /* End of Outputs for SubSystem: '<S428>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_c) && (((sint32)(rtb_Compare_bn ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_d ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S428>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S432>/Action Port'
       */
      rtb_Merge_o0 = false;

      /* End of Outputs for SubSystem: '<S428>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S428>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S433>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_c, &rtb_Merge_o0);

      /* End of Outputs for SubSystem: '<S428>/If Action Subsystem3' */
    }

    /* End of If: '<S428>/If' */

    /* Outputs for Enabled SubSystem: '<S395>/Count' incorporates:
     *  EnablePort: '<S425>/Enable'
     */
    /* Logic: '<S395>/Logical Operator' incorporates:
     *  Constant: '<S424>/Constant'
     *  Memory: '<S395>/Memory'
     *  RelationalOperator: '<S424>/Compare'
     */
    if ((rtb_Lrg_Q > ((uint8)0U)) && (LKAS_DW.Memory_PreviousInput_pk)) {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S425>/Memory' */
        LKAS_DW.Memory_PreviousInput_g3 = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S425>/Add' incorporates:
       *  Memory: '<S425>/Memory'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_g3;

      /* Saturate: '<S425>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_LftTTLC;
      }

      /* End of Saturate: '<S425>/Saturation' */

      /* Update for Memory: '<S425>/Memory' */
      LKAS_DW.Memory_PreviousInput_g3 = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S425>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S395>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S395>/Count' */

    /* Outputs for Enabled SubSystem: '<S428>/Sum Condition1' incorporates:
     *  EnablePort: '<S434>/state = reset'
     */
    if (rtb_Merge_o0) {
      if (!LKAS_DW.SumCondition1_MODE_m) {
        /* InitializeConditions for Memory: '<S434>/Memory' */
        LKAS_DW.Memory_PreviousInput_n = 0.0F;
        LKAS_DW.SumCondition1_MODE_m = true;
      }

      /* Sum: '<S434>/Add1' incorporates:
       *  Memory: '<S434>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_n;

      /* Saturate: '<S434>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 5.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 5.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S434>/Saturation' */

      /* Switch: '<S678>/Switch40' incorporates:
       *  Constant: '<S678>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S678>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S678>/Switch40' */

      /* RelationalOperator: '<S434>/Relational Operator' incorporates:
       *  Sum: '<S395>/Add'
       */
      LKAS_DW.RelationalOperator_p = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S434>/Memory' */
      LKAS_DW.Memory_PreviousInput_n = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S434>/Out' */
        LKAS_DW.RelationalOperator_p = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }
    }

    /* End of Outputs for SubSystem: '<S428>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S396>/Sum Condition1' incorporates:
     *  EnablePort: '<S440>/state = reset'
     */
    /* Logic: '<S396>/Logical Operator' incorporates:
     *  Constant: '<S438>/Constant'
     *  Constant: '<S439>/Constant'
     *  Delay: '<S143>/Delay1'
     *  RelationalOperator: '<S438>/Compare'
     *  RelationalOperator: '<S439>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_l) {
        /* InitializeConditions for Memory: '<S440>/Memory' */
        LKAS_DW.Memory_PreviousInput_j = 0.0F;
        LKAS_DW.SumCondition1_MODE_l = true;
      }

      /* Sum: '<S440>/Add1' incorporates:
       *  Memory: '<S440>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_j;

      /* Saturate: '<S440>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S440>/Saturation' */

      /* RelationalOperator: '<S440>/Relational Operator' */
      LKAS_DW.RelationalOperator_c = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S440>/Memory' */
      LKAS_DW.Memory_PreviousInput_j = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_l) {
        /* Disable for Outport: '<S440>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_l = false;
      }
    }

    /* End of Logic: '<S396>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S396>/Sum Condition1' */

    /* If: '<S393>/If1' incorporates:
     *  Constant: '<S398>/Constant'
     *  Constant: '<S400>/Constant'
     *  Constant: '<S437>/Constant'
     *  Delay: '<S143>/Delay'
     *  Logic: '<S393>/Logical Operator'
     *  Logic: '<S396>/Logical Operator1'
     *  RelationalOperator: '<S437>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode_k) == 2) && (((LKAS_DW.RelationalOperator_p) ||
          ((rtb_FDMMve_d_LkaFcnConf != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_c))) || (LKAS_DW.Delay_DSTATE_c))) {
      /* Outputs for IfAction SubSystem: '<S393>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S400>/Action Port'
       */
      LKAS_DW.Merge1_c = true;

      /* End of Outputs for SubSystem: '<S393>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S393>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S398>/Action Port'
       */
      LKAS_DW.Merge1_c = false;

      /* End of Outputs for SubSystem: '<S393>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S393>/If1' */

    /* MATLAB Function: '<S565>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_LKA_EnableLine_Max, rtb_LL_LKA_EnableLine_DvtMin,
                        rtb_LL_LKA_EnableLine_DvtMax, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_LKA_Enable_Line_g);

    /* Switch: '<S567>/Switch' incorporates:
     *  Constant: '<S565>/Constant'
     *  RelationalOperator: '<S567>/UpperRelop'
     */
    if (rtb_LKA_Enable_Line_g < 0.0F) {
      rtb_Switch_e0 = 0.0F;
    } else {
      rtb_Switch_e0 = rtb_LKA_Enable_Line_g;
    }

    /* End of Switch: '<S567>/Switch' */

    /* Switch: '<S567>/Switch2' incorporates:
     *  RelationalOperator: '<S567>/LowerRelop1'
     */
    if (rtb_LKA_Enable_Line_g > rtb_LL_LKA_EnableLine_Max) {
      rtb_Switch2_i = rtb_LL_LKA_EnableLine_Max;
    } else {
      rtb_Switch2_i = rtb_Switch_e0;
    }

    /* End of Switch: '<S567>/Switch2' */

    /* Logic: '<S551>/Logical Operator3' incorporates:
     *  Constant: '<S563>/Constant'
     *  Constant: '<S564>/Constant'
     *  Logic: '<S561>/Logical Operator'
     *  Logic: '<S562>/Logical Operator'
     *  RelationalOperator: '<S562>/Relational Operator1'
     *  RelationalOperator: '<S562>/Relational Operator2'
     *  RelationalOperator: '<S563>/Compare'
     *  RelationalOperator: '<S564>/Compare'
     */
    rtb_LogicalOperator3_c = (((LKAS_DW.LKA_Mode_k >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1 >= rtb_Switch2_i) && (rtb_Add5_g >= rtb_Switch2_i)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_c);

    /* If: '<S551>/If' incorporates:
     *  Constant: '<S557>/Constant'
     *  DataTypeConversion: '<S551>/Cast To Single'
     */
    if (((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
          2)) && rtb_LogicalOperator3_c) {
      /* Outputs for IfAction SubSystem: '<S551>/If Action Subsystem' incorporates:
       *  ActionPort: '<S557>/Action Port'
       */
      LKAS_DW.Merge_k = true;

      /* End of Outputs for SubSystem: '<S551>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S551>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S559>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_k);

      /* End of Outputs for SubSystem: '<S551>/If Action Subsystem3' */
    }

    /* End of If: '<S551>/If' */

    /* Delay: '<S143>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S443>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S443>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_hd != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S443>/If Action Subsystem' incorporates:
         *  ActionPort: '<S474>/Action Port'
         */
        /* InitializeConditions for If: '<S443>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S474>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_ip = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S443>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S443>/If Action Subsystem' incorporates:
       *  ActionPort: '<S474>/Action Port'
       */
      /* Sum: '<S474>/Add1' incorporates:
       *  Memory: '<S474>/Memory'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_ip;

      /* Saturate: '<S474>/Saturation' */
      if (rtb_LL_TkOvStChk_tiTDelTime > 10.0F) {
        rtb_LL_TkOvStChk_tiTDelTime = 10.0F;
      } else {
        if (rtb_LL_TkOvStChk_tiTDelTime < 0.0F) {
          rtb_LL_TkOvStChk_tiTDelTime = 0.0F;
        }
      }

      /* End of Saturate: '<S474>/Saturation' */
      /* End of Outputs for SubSystem: '<S443>/If Action Subsystem' */

      /* Switch: '<S678>/Switch64' incorporates:
       *  Constant: '<S678>/LLSMConClb33'
       *
       * Block description for '<S678>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S678>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S443>/If Action Subsystem' incorporates:
       *  ActionPort: '<S474>/Action Port'
       */
      /* RelationalOperator: '<S474>/Relational Operator' */
      rtb_Merge_n = (rtb_LL_TkOvStChk_tiTDelTime >= x10);

      /* Update for Memory: '<S474>/Memory' */
      LKAS_DW.Memory_PreviousInput_ip = rtb_LL_TkOvStChk_tiTDelTime;

      /* End of Outputs for SubSystem: '<S443>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S443>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S475>/Action Port'
       */
      /* SignalConversion: '<S475>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S475>/Constant'
       */
      rtb_Merge_n = false;

      /* End of Outputs for SubSystem: '<S443>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S443>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S444>/Logical Operator1' incorporates:
     *  Constant: '<S476>/Constant'
     *  Logic: '<S444>/Logical Operator'
     *  RelationalOperator: '<S444>/Relational Operator1'
     *  RelationalOperator: '<S444>/Relational Operator2'
     *  RelationalOperator: '<S476>/Compare'
     */
    rtb_BCM_Left_Light = ((LKAS_DW.LKA_Mode_k >= ((uint8)1U)) && ((rtb_Gain1 <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_g <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S441>/Logical Operator3' */
    rtb_RelationalOperator_n = ((rtb_BCM_Left_Light || rtb_Merge_n) ||
      rtb_RelationalOperator_n);

    /* If: '<S441>/If1' incorporates:
     *  Constant: '<S451>/Constant'
     *  DataTypeConversion: '<S441>/Cast To Single'
     */
    if (((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
          2)) && rtb_RelationalOperator_n) {
      /* Outputs for IfAction SubSystem: '<S441>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S451>/Action Port'
       */
      LKAS_DW.Merge1_p = true;

      /* End of Outputs for SubSystem: '<S441>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S441>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S453>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_p);

      /* End of Outputs for SubSystem: '<S441>/If Action Subsystem4' */
    }

    /* End of If: '<S441>/If1' */

    /* Memory: '<S369>/Memory' */
    rtb_Memory = LKAS_DW.Memory_PreviousInput_gk;

    /* If: '<S369>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_g >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S369>/Ph1SWA' incorporates:
       *  ActionPort: '<S373>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S369>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_g <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S369>/Ph2SWA' incorporates:
       *  ActionPort: '<S374>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S369>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S369>/Ph3SWA' incorporates:
       *  ActionPort: '<S375>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory, &rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S369>/Ph3SWA' */
    }

    /* End of If: '<S369>/If' */

    /* Product: '<S365>/Divide2' incorporates:
     *  MATLAB Function: '<S365>/MATLAB Function'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S365>/Divide3' incorporates:
     *  MATLAB Function: '<S365>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S371>/Divide' */
    rtb_Divide_pi = rtb_LKA_Veh2CamL_C * x1;

    /* Product: '<S365>/Divide1' incorporates:
     *  MATLAB Function: '<S365>/MATLAB Function'
     */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S376>/Switch' incorporates:
     *  RelationalOperator: '<S376>/UpperRelop'
     */
    if (rtb_Divide_pi < rtb_LftTTLC) {
      rtb_Switch_i = rtb_LftTTLC;
    } else {
      rtb_Switch_i = rtb_Divide_pi;
    }

    /* End of Switch: '<S376>/Switch' */

    /* Switch: '<S376>/Switch2' incorporates:
     *  RelationalOperator: '<S376>/LowerRelop1'
     */
    if (rtb_Divide_pi > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_iy = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_iy = rtb_Switch_i;
    }

    /* End of Switch: '<S376>/Switch2' */

    /* Product: '<S372>/Divide' */
    rtb_Divide_c = rtb_LKA_Veh2CamL_C * rtb_LogicalOperator3_l_tmp;

    /* Switch: '<S377>/Switch' incorporates:
     *  RelationalOperator: '<S377>/UpperRelop'
     */
    if (rtb_Divide_c < rtb_LftTTLC) {
      rtb_Switch_k = rtb_LftTTLC;
    } else {
      rtb_Switch_k = rtb_Divide_c;
    }

    /* End of Switch: '<S377>/Switch' */

    /* Switch: '<S377>/Switch2' incorporates:
     *  RelationalOperator: '<S377>/LowerRelop1'
     */
    if (rtb_Divide_c > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_id = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_id = rtb_Switch_k;
    }

    /* End of Switch: '<S377>/Switch2' */

    /* Switch: '<S370>/Switch3' incorporates:
     *  Gain: '<S370>/Gain1'
     *  RelationalOperator: '<S372>/Relational Operator2'
     */
    if (rtb_Merge1_a >= 0.0F) {
      /* Switch: '<S370>/Switch2' incorporates:
       *  Constant: '<S370>/Constant2'
       *  DataTypeConversion: '<S370>/Cast To Single'
       *  RelationalOperator: '<S371>/Relational Operator2'
       */
      if (rtb_Merge1_a > 0.0F) {
        rtb_Rrg_Q = (uint8)((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <= rtb_Switch2_iy) ?
                            1 : 0);
      } else {
        rtb_Rrg_Q = ((uint8)0U);
      }

      /* End of Switch: '<S370>/Switch2' */
    } else {
      rtb_Rrg_Q = (uint8)((((uint32)((rtb_TTLC_h <= rtb_Switch2_id) ? 1 : 0)) *
                           ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S370>/Switch3' */

    /* If: '<S355>/If' incorporates:
     *  Constant: '<S359>/Constant'
     *  Constant: '<S361>/Constant'
     *  Constant: '<S362>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
           2)) && (((sint32)rtb_Rrg_Q) == 1)) && (((sint32)rtb_L0_Q) == 1)) {
      /* Outputs for IfAction SubSystem: '<S355>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S361>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S355>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)
        LKAS_DW.LKA_Mode_k) == 2)) && (((sint32)rtb_Rrg_Q) == 2)) && (((sint32)
                 rtb_L0_Q) == 1)) {
      /* Outputs for IfAction SubSystem: '<S355>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S362>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S355>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S355>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S359>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S355>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S355>/If' */

    /* Memory: '<S405>/Memory' */
    rtb_Memory_a = LKAS_DW.Memory_PreviousInput_c;

    /* If: '<S405>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_g >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S405>/Ph1SWA' incorporates:
       *  ActionPort: '<S409>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S405>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_g <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S405>/Ph2SWA' incorporates:
       *  ActionPort: '<S410>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S405>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S405>/Ph3SWA' incorporates:
       *  ActionPort: '<S411>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_a, &rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S405>/Ph3SWA' */
    }

    /* End of If: '<S405>/If' */

    /* Product: '<S401>/Divide2' */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S401>/Divide3' */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S407>/Divide' */
    rtb_Divide_hn = rtb_LKA_Veh2CamL_C * x1;

    /* Product: '<S401>/Divide1' */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S413>/Switch' incorporates:
     *  RelationalOperator: '<S413>/UpperRelop'
     */
    if (rtb_Divide_hn < rtb_LftTTLC) {
      rtb_Switch_d = rtb_LftTTLC;
    } else {
      rtb_Switch_d = rtb_Divide_hn;
    }

    /* End of Switch: '<S413>/Switch' */

    /* Switch: '<S413>/Switch2' incorporates:
     *  RelationalOperator: '<S413>/LowerRelop1'
     */
    if (rtb_Divide_hn > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_mr = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_mr = rtb_Switch_d;
    }

    /* End of Switch: '<S413>/Switch2' */

    /* Product: '<S408>/Divide' */
    rtb_Divide_ha = rtb_LKA_Veh2CamL_C * rtb_LogicalOperator3_l_tmp;

    /* Switch: '<S414>/Switch' incorporates:
     *  RelationalOperator: '<S414>/UpperRelop'
     */
    if (rtb_Divide_ha < rtb_LftTTLC) {
      rtb_Switch_a = rtb_LftTTLC;
    } else {
      rtb_Switch_a = rtb_Divide_ha;
    }

    /* End of Switch: '<S414>/Switch' */

    /* Switch: '<S414>/Switch2' incorporates:
     *  RelationalOperator: '<S414>/LowerRelop1'
     */
    if (rtb_Divide_ha > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_e2 = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_e2 = rtb_Switch_a;
    }

    /* End of Switch: '<S414>/Switch2' */

    /* Switch: '<S406>/Switch3' incorporates:
     *  Gain: '<S406>/Gain1'
     *  RelationalOperator: '<S408>/Relational Operator2'
     */
    if (rtb_Merge1_d >= 0.0F) {
      /* Switch: '<S406>/Switch2' incorporates:
       *  Constant: '<S406>/Constant2'
       *  DataTypeConversion: '<S406>/Cast To Single'
       *  RelationalOperator: '<S407>/Relational Operator2'
       */
      if (rtb_Merge1_d > 0.0F) {
        rtb_L0_Q = (uint8)((rtb_TLft <= rtb_Switch2_mr) ? 1 : 0);
      } else {
        rtb_L0_Q = ((uint8)0U);
      }

      /* End of Switch: '<S406>/Switch2' */
    } else {
      rtb_L0_Q = (uint8)((((uint32)((rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_e2) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S406>/Switch3' */

    /* Outputs for Enabled SubSystem: '<S406>/Sum Condition' incorporates:
     *  EnablePort: '<S412>/Enable'
     */
    if (((sint32)rtb_L0_Q) > 0) {
      if (!LKAS_DW.SumCondition_MODE) {
        /* InitializeConditions for Memory: '<S412>/Memory' */
        LKAS_DW.Memory_PreviousInput_cy = 0.0F;
        LKAS_DW.SumCondition_MODE = true;
      }

      /* Sum: '<S412>/Add1' incorporates:
       *  Memory: '<S412>/Memory'
       */
      rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_cy;

      /* Saturate: '<S412>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 5.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 5.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S412>/Saturation' */

      /* RelationalOperator: '<S412>/Relational Operator' incorporates:
       *  Constant: '<S406>/Constant'
       */
      LKAS_DW.RelationalOperator_g = (rtb_LL_LDW_LatestWarnLine_C <= 2.0F);

      /* Update for Memory: '<S412>/Memory' */
      LKAS_DW.Memory_PreviousInput_cy = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S412>/Out' */
        LKAS_DW.RelationalOperator_g = false;
        LKAS_DW.SumCondition_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S406>/Sum Condition' */

    /* If: '<S393>/If' incorporates:
     *  Constant: '<S397>/Constant'
     *  Constant: '<S399>/Constant'
     *  DataTypeConversion: '<S406>/Cast To Single3'
     *  DataTypeConversion: '<S406>/Cast To Single4'
     *  Product: '<S406>/Divide'
     */
    if (((((sint32)LKAS_DW.LKA_Mode_k) == 1) || (((sint32)LKAS_DW.LKA_Mode_k) ==
          2)) && (((sint32)((uint32)(((uint32)rtb_L0_Q) *
            (LKAS_DW.RelationalOperator_g ? 1U : 0U)))) == 0)) {
      /* Outputs for IfAction SubSystem: '<S393>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S399>/Action Port'
       */
      LKAS_DW.LKA_Fault = true;

      /* End of Outputs for SubSystem: '<S393>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S393>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S397>/Action Port'
       */
      LKAS_DW.LKA_Fault = false;

      /* End of Outputs for SubSystem: '<S393>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S393>/If' */

    /* Logic: '<S354>/Logical Operator2' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  DataTypeConversion: '<S54>/Extract Desired Bits'
     */
    rtb_LL_SingleLane_Disable_Swt = (rtb_R0_C3 != 0.0F);

    /* Logic: '<S354>/Logical Operator1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  DataTypeConversion: '<S15>/Extract Desired Bits'
     *  DataTypeConversion: '<S46>/Extract Desired Bits'
     */
    rtb_BCM_Right_Light = ((rtb_L0_C0_g != 0.0F) || (rtb_R0_C3 != 0.0F));

    /* Logic: '<S354>/Logical Operator10' */
    LKAS_DW.LDW_Fault = (rtb_LL_SingleLane_Disable_Swt || rtb_BCM_Right_Light);

    /* Chart: '<S143>/LDW_State_Machine'
     *
     * Block description for '<S143>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* Sum: '<S612>/Add' incorporates:
     *  Memory: '<S612>/Memory'
     */
    rtb_LftTTLC = LKAS_DW.Memory_PreviousInput_iu + rtb_LKA_SampleTime;

    /* Saturate: '<S612>/Saturation' */
    if (rtb_LftTTLC > 11.0F) {
      rtb_Saturation_e = 11.0F;
    } else if (rtb_LftTTLC < 0.0F) {
      rtb_Saturation_e = 0.0F;
    } else {
      rtb_Saturation_e = rtb_LftTTLC;
    }

    /* End of Saturate: '<S612>/Saturation' */

    /* Logic: '<S354>/Logical Operator8' incorporates:
     *  Constant: '<S611>/Constant'
     *  Constant: '<S612>/Constant1'
     *  Logic: '<S354>/AND'
     *  RelationalOperator: '<S611>/Compare'
     *  RelationalOperator: '<S612>/Relational Operator'
     */
    LKAS_DW.LKA_Fault = ((rtb_LL_SingleLane_Disable_Swt || rtb_BCM_Right_Light) ||
                         ((rtb_FDMMve_d_LkaFcnConf == ((uint8)4U)) &&
                          (rtb_Saturation_e >= ((float32)((uint16)5U)))));

    /* Chart: '<S143>/LKA_State_Machine'
     *
     * Block description for '<S143>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S331>/Subsystem' incorporates:
     *  EnablePort: '<S335>/Enable'
     */
    /* Logic: '<S331>/Logical Operator3' incorporates:
     *  Abs: '<S331>/Abs4'
     *  Abs: '<S331>/Abs5'
     *  Abs: '<S331>/Abs6'
     *  Abs: '<S331>/Abs7'
     *  Constant: '<S331>/Constant'
     *  Constant: '<S331>/Constant1'
     *  Constant: '<S331>/Constant4'
     *  Constant: '<S331>/Constant5'
     *  Constant: '<S333>/Constant'
     *  Constant: '<S334>/Constant'
     *  Logic: '<S331>/Logical Operator'
     *  Logic: '<S331>/Logical Operator1'
     *  Logic: '<S331>/Logical Operator4'
     *  RelationalOperator: '<S331>/Relational Operator'
     *  RelationalOperator: '<S331>/Relational Operator1'
     *  RelationalOperator: '<S331>/Relational Operator2'
     *  RelationalOperator: '<S331>/Relational Operator3'
     *  RelationalOperator: '<S331>/Relational Operator6'
     *  RelationalOperator: '<S331>/Relational Operator7'
     *  RelationalOperator: '<S333>/Compare'
     *  RelationalOperator: '<S334>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_c) <= 0.008F) && (fabsf(rtb_L0_C1_h5) <= 0.008F)) &&
           ((fabsf(rtb_L0_C2_f) <= 0.0001F) && (fabsf(rtb_R0_C2_b) <= 0.0001F)))
          && ((rtb_IMAPve_d_LKA_Mode == ((uint8)3U)) && (rtb_R0_Q_c == ((uint8)
             3U)))) && (rtb_ESC_VehSpd >= 35.0F)) && (rtb_TTLC <= 4.0F)) {
      if (!LKAS_DW.Subsystem_MODE_f) {
        /* InitializeConditions for Memory: '<S335>/Memory' */
        LKAS_DW.Memory_PreviousInput_p2 = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_f = true;
      }

      /* Sum: '<S335>/Add1' incorporates:
       *  Memory: '<S335>/Memory'
       */
      rtb_Saturation_b = (uint16)(1U + ((uint32)LKAS_DW.Memory_PreviousInput_p2));

      /* Saturate: '<S335>/Saturation' */
      if (rtb_Saturation_b >= ((uint16)3000U)) {
        rtb_Saturation_b = ((uint16)3000U);
      }

      /* End of Saturate: '<S335>/Saturation' */

      /* RelationalOperator: '<S335>/Relational Operator' incorporates:
       *  Constant: '<S331>/Constant3'
       *  DataTypeConversion: '<S335>/Cast To Single1'
       *  Product: '<S331>/Divide'
       */
      LKAS_DW.RelationalOperator_pz = (rtb_Saturation_b >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S335>/Memory' */
      LKAS_DW.Memory_PreviousInput_p2 = rtb_Saturation_b;
    } else {
      if (LKAS_DW.Subsystem_MODE_f) {
        /* Disable for Outport: '<S335>/Out' */
        LKAS_DW.RelationalOperator_pz = false;
        LKAS_DW.Subsystem_MODE_f = false;
      }
    }

    /* End of Logic: '<S331>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S331>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S305>/Subsystem' incorporates:
     *  EnablePort: '<S330>/Enable'
     */
    if (LKAS_DW.RelationalOperator_pz) {
      /* Sum: '<S332>/Add2' incorporates:
       *  Constant: '<S332>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S332>/Memory3'
       */
      rtb_LL_LDW_LatestWarnLine_C = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S332>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 50.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 50.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S332>/Saturation' */

      /* Switch: '<S332>/Switch' incorporates:
       *  Constant: '<S330>/Constant'
       *  Product: '<S332>/Divide'
       *  Product: '<S332>/Divide1'
       *  Sum: '<S332>/Add'
       *  Sum: '<S332>/Add1'
       *  UnitDelay: '<S332>/Unit Delay'
       */
      if (rtb_LL_LDW_LatestWarnLine_C > 1.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_SW_Angle - LKAS_DW.UnitDelay_DSTATE)) + LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_SW_Angle;
      }

      /* End of Switch: '<S332>/Switch' */

      /* Saturate: '<S330>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 3.0F) {
        LKAS_DW.Saturation_m = 3.0F;
      } else if (rtb_LL_ThresDet_lDvtThresLwrLDW < (-3.0F)) {
        LKAS_DW.Saturation_m = (-3.0F);
      } else {
        LKAS_DW.Saturation_m = rtb_LL_ThresDet_lDvtThresLwrLDW;
      }

      /* End of Saturate: '<S330>/Saturation' */

      /* Update for UnitDelay: '<S332>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Update for Memory: '<S332>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Outputs for SubSystem: '<S305>/Subsystem' */

    /* Saturate: '<S307>/Saturation' */
    if (rtb_ESC_VehSpd > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else if (rtb_ESC_VehSpd < 0.001F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.001F;
    } else {
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ESC_VehSpd;
    }

    /* End of Saturate: '<S307>/Saturation' */

    /* Gain: '<S343>/kph To mps' incorporates:
     *  Gain: '<S344>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = 0.277777791F *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S343>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S345>:1' */
    /* '<S345>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 60.0F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_LL_ThresDet_lDvtThresUprLKA;
    }

    /* End of Saturate: '<S343>/Saturation3' */

    /* Product: '<S343>/Divide1' incorporates:
     *  Constant: '<S343>/Constant'
     */
    rtb_LftTTLC = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S343>/Saturation1' */
    if (rtb_LftTTLC > 0.0117F) {
      rtb_LftTTLC = 0.0117F;
    } else {
      if (rtb_LftTTLC < 0.00237F) {
        rtb_LftTTLC = 0.00237F;
      }
    }

    /* End of Saturate: '<S343>/Saturation1' */

    /* Switch: '<S677>/Switch7' incorporates:
     *  Constant: '<S677>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_o != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_o;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S677>/Switch7' */

    /* MATLAB Function: '<S343>/MATLAB Function' incorporates:
     *  Gain: '<S343>/kph To mps'
     */
    rtb_LL_LDW_LatestWarnLine_C = ((((((((rtb_LftTTLC *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_c) * LKAS_DW.LKA_WhlBaseL_C_o) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S344>/Saturation3' */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 60.0F;
      }
    }

    /* End of Saturate: '<S344>/Saturation3' */

    /* Product: '<S344>/Divide1' incorporates:
     *  Constant: '<S344>/Constant'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = 0.09F / rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S344>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S346>:1' */
    /* '<S346>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 0.0117F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.0117F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 0.00237F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 0.00237F;
      }
    }

    /* End of Saturate: '<S344>/Saturation1' */

    /* Switch: '<S677>/Switch4' incorporates:
     *  Constant: '<S677>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_d != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_d;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S677>/Switch4' */

    /* MATLAB Function: '<S344>/MATLAB Function' */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_c) * LKAS_DW.LKA_WhlBaseL_C_o) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Gain: '<S302>/Gain1' incorporates:
     *  Sum: '<S302>/Add1'
     */
    rtb_LL_ThresDet_lDvtThresUprLDW = (rtb_Add_gv + rtb_Add_a) * 0.5F;

    /* Switch: '<S304>/Switch' incorporates:
     *  Constant: '<S320>/Constant'
     *  RelationalOperator: '<S320>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_LftTTLC = rtb_LFTTTLC;
    } else {
      rtb_LftTTLC = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S304>/Switch' */

    /* Saturate: '<S304>/Saturation' */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else {
      if (rtb_LftTTLC < 0.5F) {
        rtb_LftTTLC = 0.5F;
      }
    }

    /* End of Saturate: '<S304>/Saturation' */

    /* Product: '<S328>/Divide' */
    rtb_Divide_l = rtb_Abs_b_tmp * rtb_LftTTLC;

    /* Switch: '<S304>/Switch1' incorporates:
     *  Constant: '<S321>/Constant'
     *  RelationalOperator: '<S321>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S304>/Switch1' */

    /* Saturate: '<S304>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S304>/Saturation1' */

    /* Product: '<S329>/Divide' */
    rtb_Divide_k = rtb_Abs_b_tmp * rtb_LL_HdAgPrvwT_C;

    /* Gain: '<S304>/Gain1' incorporates:
     *  Sum: '<S304>/Add1'
     */
    rtb_LL_HdAgPrvwT_C = (rtb_Divide_l + rtb_Divide_k) * 0.5F;

    /* Switch: '<S677>/Switch8' incorporates:
     *  Constant: '<S677>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_g != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_g;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S677>/Switch8' */

    /* Product: '<S319>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_Abs_b_tmp * x10;

    /* Product: '<S317>/Z*Z' incorporates:
     *  Product: '<S318>/Z*Z'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Sum: '<S317>/Add' incorporates:
     *  Product: '<S317>/Product'
     *  Product: '<S317>/Product3'
     *  Product: '<S317>/Product4'
     *  Product: '<S317>/Z*Z'
     *  Product: '<S317>/Z*Z*Z'
     */
    rtb_Add_ohd = (((rtb_L0_C1_c * rtb_LL_ThresDet_lDvtThresUprLKA) +
                    rtb_L0_C0_c) + (rtb_L0_C2_f * rtb_LL_ThresDet_tiTTLCThresLDW))
      + ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_ThresDet_tiTTLCThresLDW) *
         rtb_L0_C3_i);

    /* Sum: '<S318>/Add' incorporates:
     *  Product: '<S318>/Product'
     *  Product: '<S318>/Product3'
     *  Product: '<S318>/Product4'
     *  Product: '<S318>/Z*Z*Z'
     */
    rtb_Add_k = (((rtb_L0_C1_h5 * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_R0_C0_j)
                 + (rtb_R0_C2_b * rtb_LL_ThresDet_tiTTLCThresLDW)) +
      ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_ThresDet_tiTTLCThresLDW) *
       rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S181>/Memory' */
        LKAS_DW.Memory_PreviousInput_ht = 0.0F;

        /* InitializeConditions for Memory: '<S212>/Memory' */
        LKAS_DW.Memory_PreviousInput_f = ((uint16)0U);

        /* InitializeConditions for Memory: '<S199>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_g = ((uint8)0U);

        /* InitializeConditions for Memory: '<S211>/Memory' */
        LKAS_DW.Memory_PreviousInput_oc = ((uint16)0U);

        /* InitializeConditions for Memory: '<S213>/Memory' */
        LKAS_DW.Memory_PreviousInput_ci = ((uint16)0U);

        /* InitializeConditions for Memory: '<S208>/Memory' */
        LKAS_DW.Memory_PreviousInput_bh = ((uint16)0U);

        /* InitializeConditions for Memory: '<S196>/Memory' */
        LKAS_DW.Memory_PreviousInput_p = 0.0F;

        /* InitializeConditions for Memory: '<S182>/Memory' */
        LKAS_DW.Memory_PreviousInput_cw = 0.0F;

        /* InitializeConditions for Memory: '<S183>/Memory' */
        LKAS_DW.Memory_PreviousInput_ij = 0.0F;

        /* InitializeConditions for UnitDelay: '<S185>/Delay Input1'
         *
         * Block description for '<S185>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_m = false;

        /* InitializeConditions for Memory: '<S183>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_c = false;

        /* InitializeConditions for Memory: '<S164>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_m = 0.0F;

        /* InitializeConditions for UnitDelay: '<S178>/Delay Input2'
         *
         * Block description for '<S178>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_a = 0.0F;

        /* InitializeConditions for Memory: '<S160>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_n = 0.0F;

        /* InitializeConditions for Memory: '<S160>/Memory' */
        LKAS_DW.Memory_PreviousInput_em = 0.0F;

        /* InitializeConditions for UnitDelay: '<S177>/Delay Input2'
         *
         * Block description for '<S177>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_b = 0.0F;

        /* InitializeConditions for Memory: '<S275>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_p = 0.0F;

        /* InitializeConditions for Memory: '<S258>/Memory' */
        LKAS_DW.Memory_PreviousInput_e4 = 0.0F;

        /* InitializeConditions for UnitDelay: '<S256>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_p = 0.0F;

        /* InitializeConditions for Memory: '<S264>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_d = 0.0F;

        /* InitializeConditions for Memory: '<S270>/Memory' */
        LKAS_DW.Memory_PreviousInput_bd = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S274>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_o = 0.0F;

        /* InitializeConditions for Memory: '<S274>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_f = 0.0F;

        /* InitializeConditions for UnitDelay: '<S251>/Delay Input2'
         *
         * Block description for '<S251>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_i = 0.0F;

        /* InitializeConditions for Memory: '<S251>/Memory' */
        LKAS_DW.Memory_PreviousInput_da = ((uint16)0U);

        /* InitializeConditions for Memory: '<S207>/Memory' */
        LKAS_DW.Memory_PreviousInput_ni = ((uint16)0U);

        /* InitializeConditions for Memory: '<S209>/Memory' */
        LKAS_DW.Memory_PreviousInput_hk = ((uint16)0U);

        /* InitializeConditions for Memory: '<S210>/Memory' */
        LKAS_DW.Memory_PreviousInput_ei = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S158>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S158>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S183>/Moving Standard Deviation1' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S183>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S183>/Moving Standard Deviation2' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation2_g);

        /* End of SystemReset for SubSystem: '<S183>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S160>/Moving Standard Deviation2' */
        MovingStandardDeviation_i_Reset(&LKAS_DW.MovingStandardDeviation2_l);

        /* End of SystemReset for SubSystem: '<S160>/Moving Standard Deviation2' */

        /* SystemReset for Chart: '<S160>/Chart' */
        LKAS_DW.temporalCounter_i1 = 0U;
        LKAS_DW.is_active_c2_LKAS = 0U;
        LKAS_DW.is_c2_LKAS = LKAS_IN_NO_ACTIVE_CHILD_c;
        LKAS_DW.LKA_MODE = true;
      }

      /* Memory: '<S181>/Memory' */
      rtb_Divide3_j = LKAS_DW.Memory_PreviousInput_ht;

      /* Sum: '<S181>/Add2' */
      rtb_Divide3_j += rtb_LKA_SampleTime;

      /* Saturate: '<S181>/Saturation2' */
      if (rtb_Divide3_j > 20.0F) {
        rtb_Saturation2_p = 20.0F;
      } else if (rtb_Divide3_j < 0.0F) {
        rtb_Saturation2_p = 0.0F;
      } else {
        rtb_Saturation2_p = rtb_Divide3_j;
      }

      /* End of Saturate: '<S181>/Saturation2' */

      /* Abs: '<S181>/Abs' */
      rtb_Divide3_j = rtb_TTLC_l;

      /* Saturate: '<S181>/Saturation' */
      if (rtb_Divide3_j > 0.004F) {
        rtb_Divide3_j = 0.004F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S181>/Saturation' */

      /* RelationalOperator: '<S181>/Relational Operator4' incorporates:
       *  Constant: '<S181>/Constant'
       *  Constant: '<S181>/Constant1'
       *  Product: '<S181>/Divide'
       *  Sum: '<S181>/Add'
       */
      rtb_BCM_Right_Light = (rtb_Saturation2_p >=
        ((((rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F) * rtb_Divide3_j) / 0.004F) +
         rtb_LL_LKAExPrcs_tiExitTime1));

      /* Abs: '<S182>/Abs' */
      rtb_Divide3_j = rtb_TTLC_l;

      /* Saturate: '<S182>/Saturation' */
      if (rtb_Divide3_j > 0.004F) {
        rtb_Divide3_j = 0.004F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S182>/Saturation' */

      /* Product: '<S182>/Divide' incorporates:
       *  Constant: '<S182>/Constant'
       *  Constant: '<S182>/Constant1'
       */
      rtb_LL_ThresDet_tiTTLCThresLDW = ((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) *
        rtb_Divide3_j) / 0.004F;

      /* Sum: '<S212>/Add' incorporates:
       *  Constant: '<S212>/Constant'
       *  Memory: '<S212>/Memory'
       */
      rtb_Saturation_b = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_f));

      /* Saturate: '<S212>/Saturation1' */
      if (rtb_Saturation_b < ((uint16)10000U)) {
        rtb_Saturation1_n = rtb_Saturation_b;
      } else {
        rtb_Saturation1_n = ((uint16)10000U);
      }

      /* End of Saturate: '<S212>/Saturation1' */

      /* Gain: '<S257>/kph to mps' */
      rtb_Divide3_j = rtb_Abs_b_tmp;

      /* Saturate: '<S257>/Saturation3' */
      if (rtb_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_ESC_VehSpd;
      }

      /* End of Saturate: '<S257>/Saturation3' */

      /* Product: '<S257>/Divide2' incorporates:
       *  Constant: '<S257>/Constant'
       */
      rtb_LftTTLC = 0.09F / x10;

      /* Switch: '<S677>/Switch36' incorporates:
       *  Constant: '<S677>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_i != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_i;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S677>/Switch36' */

      /* Saturate: '<S257>/Saturation1' */
      if (rtb_LftTTLC > 0.01F) {
        rtb_LftTTLC = 0.01F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S257>/Saturation1' */

      /* Gain: '<S257>/Gain2' incorporates:
       *  Constant: '<S257>/Constant1'
       *  Gain: '<S257>/rad to deg'
       *  Gain: '<S302>/Gain1'
       *  Math: '<S257>/Math Function'
       *  Product: '<S257>/Divide'
       *  Product: '<S257>/Divide1'
       *  Product: '<S257>/Product'
       *  Product: '<S257>/Product1'
       *  Product: '<S257>/Product2'
       *  Product: '<S257>/Product3'
       *  Sum: '<S257>/Add'
       *
       * About '<S257>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = (((((((rtb_Divide3_j * rtb_Divide3_j) *
        rtb_LftTTLC) + 1.0F) / (rtb_Divide3_j / LKAS_DW.LKA_WhlBaseL_C_o)) *
        ((rtb_Divide3_j * rtb_LL_ThresDet_lDvtThresUprLDW) * 57.2957802F)) * x10)
        * LKAS_DW.LKA_StrRatio_C_c) * (-1.0F);

      /* Sum: '<S195>/Add1' */
      rtb_Add1_b = (rtb_SW_Angle - rtb_LL_LKAExPrcs_tiExitTime1) -
        LKAS_DW.Saturation_m;

      /* If: '<S212>/If' incorporates:
       *  Constant: '<S212>/Constant2'
       */
      if (rtb_Saturation1_n == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S212>/if action ' incorporates:
         *  ActionPort: '<S235>/Action Port'
         */
        LKAS_ifaction(rtb_Add1_b, &LKAS_DW.In_f);

        /* End of Outputs for SubSystem: '<S212>/if action ' */
      }

      /* End of If: '<S212>/If' */

      /* Sum: '<S199>/Add' incorporates:
       *  Constant: '<S199>/Constant'
       *  Memory: '<S199>/Memory1'
       */
      rtb_L0_Q = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_g));

      /* Saturate: '<S199>/Saturation1' */
      if (rtb_L0_Q < ((uint8)5U)) {
        rtb_Saturation1_br = rtb_L0_Q;
      } else {
        rtb_Saturation1_br = ((uint8)5U);
      }

      /* End of Saturate: '<S199>/Saturation1' */

      /* Saturate: '<S195>/Saturation3' */
      if (rtb_ESC_VehSpd > 150.0F) {
        rtb_Divide3_j = 150.0F;
      } else if (rtb_ESC_VehSpd < 60.0F) {
        rtb_Divide3_j = 60.0F;
      } else {
        rtb_Divide3_j = rtb_ESC_VehSpd;
      }

      /* End of Saturate: '<S195>/Saturation3' */

      /* Product: '<S195>/Divide1' incorporates:
       *  Constant: '<S195>/Constant'
       */
      rtb_Divide3_j = 0.09F / rtb_Divide3_j;

      /* Saturate: '<S195>/Saturation1' */
      if (rtb_Divide3_j > 0.0117F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.0117F;
      } else if (rtb_Divide3_j < 0.00237F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.MPInP_StbFacm_SY = rtb_Divide3_j;
      }

      /* End of Saturate: '<S195>/Saturation1' */

      /* Gain: '<S195>/Gain' */
      LKAS_DW.MPInP_dphiSWARMax = 1.0F * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S211>/Add' incorporates:
       *  Constant: '<S211>/Constant'
       *  Memory: '<S211>/Memory'
       */
      rtb_Saturation_b = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_oc));

      /* Saturate: '<S211>/Saturation1' */
      if (rtb_Saturation_b < ((uint16)10000U)) {
        rtb_Saturation1_j = rtb_Saturation_b;
      } else {
        rtb_Saturation1_j = ((uint16)10000U);
      }

      /* End of Saturate: '<S211>/Saturation1' */

      /* If: '<S202>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S202>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S216>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_LFTTTLC, &rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S202>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S202>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S215>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_RGTTTLC, &rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S202>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S202>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S217>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S202>/If Action Subsystem3' */
      }

      /* End of If: '<S202>/If' */

      /* If: '<S211>/If' incorporates:
       *  Constant: '<S211>/Constant2'
       */
      if (rtb_Saturation1_j == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S211>/if action ' incorporates:
         *  ActionPort: '<S234>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_g, &LKAS_DW.In_k);

        /* End of Outputs for SubSystem: '<S211>/if action ' */
      }

      /* End of If: '<S211>/If' */

      /* Saturate: '<S195>/Saturation2' */
      if (LKAS_DW.In_k > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_k < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_k;
      }

      /* End of Saturate: '<S195>/Saturation2' */

      /* Sum: '<S213>/Add' incorporates:
       *  Constant: '<S213>/Constant'
       *  Memory: '<S213>/Memory'
       */
      rtb_Saturation_b = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ci));

      /* Saturate: '<S213>/Saturation1' */
      if (rtb_Saturation_b < ((uint16)10000U)) {
        rtb_Saturation1_pr = rtb_Saturation_b;
      } else {
        rtb_Saturation1_pr = ((uint16)10000U);
      }

      /* End of Saturate: '<S213>/Saturation1' */

      /* If: '<S213>/If' incorporates:
       *  Constant: '<S213>/Constant2'
       */
      if (rtb_Saturation1_pr == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S213>/if action ' incorporates:
         *  ActionPort: '<S236>/Action Port'
         */
        LKAS_ifaction(rtb_ESC_VehSpd, &LKAS_DW.In_h);

        /* End of Outputs for SubSystem: '<S213>/if action ' */
      }

      /* End of If: '<S213>/If' */

      /* Sum: '<S208>/Add' incorporates:
       *  Constant: '<S208>/Constant'
       *  Memory: '<S208>/Memory'
       */
      rtb_Saturation_b = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_bh));

      /* Saturate: '<S208>/Saturation1' */
      if (rtb_Saturation_b < ((uint16)10000U)) {
        rtb_Saturation1_an = rtb_Saturation_b;
      } else {
        rtb_Saturation1_an = ((uint16)10000U);
      }

      /* End of Saturate: '<S208>/Saturation1' */

      /* Product: '<S326>/Z*Z' incorporates:
       *  Product: '<S323>/Z*Z'
       */
      x10 = rtb_Divide_l * rtb_Divide_l;

      /* Gain: '<S326>/Gain1' incorporates:
       *  Gain: '<S325>/Gain1'
       *  Gain: '<S327>/Gain1'
       */
      rtb_LL_ThresDet_lDvtThresUprLKA = 3.0F * rtb_L0_C3_i;

      /* Gain: '<S323>/Gain1' incorporates:
       *  Gain: '<S322>/Gain1'
       *  Gain: '<S324>/Gain1'
       */
      rtb_L0_C3 *= 3.0F;

      /* Gain: '<S203>/Gain' incorporates:
       *  Gain: '<S323>/Gain1'
       *  Gain: '<S326>/Gain1'
       *  Product: '<S323>/Product3'
       *  Product: '<S323>/Product4'
       *  Product: '<S326>/Product3'
       *  Product: '<S326>/Product4'
       *  Product: '<S326>/Z*Z'
       *  Sum: '<S203>/Add'
       *  Sum: '<S323>/Add'
       *  Sum: '<S326>/Add'
       */
      rtb_Gain_db = ((((rtb_Add_gv_tmp * rtb_Divide_l) + rtb_L0_C1_c) +
                      (rtb_LL_ThresDet_lDvtThresUprLKA * x10)) +
                     (((rtb_Add_a_tmp * rtb_Divide_l) + rtb_L0_C1_h5) +
                      (rtb_L0_C3 * x10))) * 0.5F;

      /* Product: '<S327>/Z*Z' incorporates:
       *  Product: '<S324>/Z*Z'
       */
      rtb_L0_C3_i = rtb_Divide_k * rtb_Divide_k;

      /* Gain: '<S203>/Gain1' incorporates:
       *  Product: '<S324>/Product3'
       *  Product: '<S324>/Product4'
       *  Product: '<S327>/Product3'
       *  Product: '<S327>/Product4'
       *  Product: '<S327>/Z*Z'
       *  Sum: '<S203>/Add1'
       *  Sum: '<S324>/Add'
       *  Sum: '<S327>/Add'
       */
      rtb_Gain1_d5 = ((((rtb_Add_gv_tmp * rtb_Divide_k) + rtb_L0_C1_c) +
                       (rtb_LL_ThresDet_lDvtThresUprLKA * rtb_L0_C3_i)) +
                      (((rtb_Add_a_tmp * rtb_Divide_k) + rtb_L0_C1_h5) +
                       (rtb_L0_C3 * rtb_L0_C3_i))) * 0.5F;

      /* If: '<S203>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S203>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S219>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_Gain_db, &rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S203>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S203>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S218>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_Gain1_d5, &rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S203>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S203>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S220>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S203>/If Action Subsystem3' */
      }

      /* End of If: '<S203>/If' */

      /* If: '<S205>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S205>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S225>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_Divide_l, &rtb_Gain2_i);

        /* End of Outputs for SubSystem: '<S205>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S205>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S224>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_Divide_k, &rtb_Gain2_i);

        /* End of Outputs for SubSystem: '<S205>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S205>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S226>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Gain2_i);

        /* End of Outputs for SubSystem: '<S205>/If Action Subsystem3' */
      }

      /* End of If: '<S205>/If' */

      /* Sum: '<S195>/Add' incorporates:
       *  Gain: '<S302>/Gain1'
       *  Product: '<S195>/Divide2'
       */
      rtb_Add_ed = rtb_Divide3_j - (rtb_LL_ThresDet_lDvtThresUprLDW *
        rtb_Gain2_i);

      /* If: '<S208>/If' incorporates:
       *  Constant: '<S208>/Constant2'
       */
      if (rtb_Saturation1_an == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S208>/if action ' incorporates:
         *  ActionPort: '<S231>/Action Port'
         */
        LKAS_ifaction(rtb_Add_ed, &LKAS_DW.In_mp);

        /* End of Outputs for SubSystem: '<S208>/if action ' */
      }

      /* End of If: '<S208>/If' */

      /* If: '<S214>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S214>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S238>/Action Port'
         */
        /* SignalConversion: '<S238>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S238>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S214>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S214>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S237>/Action Port'
         */
        /* SignalConversion: '<S237>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S237>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S214>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S214>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S239>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S214>/If Action Subsystem3' */
      }

      /* End of If: '<S214>/If' */

      /* If: '<S199>/If' incorporates:
       *  Constant: '<S199>/Constant19'
       */
      rtAction = -1;
      if (rtb_Saturation1_br == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        /* Outputs for IfAction SubSystem: '<S152>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S194>/Action Port'
         *
         * Block description for '<S152>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S152>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S199>/If' */

      /* Memory: '<S196>/Memory' */
      rtb_Gain2_i = LKAS_DW.Memory_PreviousInput_p;

      /* Sum: '<S196>/Add' incorporates:
       *  Gain: '<S196>/Gain1'
       *  Product: '<S196>/Divide'
       *  Product: '<S196>/Product'
       */
      rtb_Add_jv = ((rtb_Abs_b_tmp * rtb_LKA_SampleTime) / (0.277777791F *
        LKAS_DW.In_h)) + rtb_Gain2_i;

      /* MATLAB Function: '<S197>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S240>:1' */
      /* '<S240>:1:19' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S240>:1:20' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S240>:1:21' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S240>:1:22' Delte2PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S240>:1:23' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S240>:1:24' NomT = SWACmd_tiNomT; */
      /* '<S240>:1:25' T1 = K1K2Det_T1; */
      /* '<S240>:1:26' T2 = T1; */
      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S240>:1:34' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_jv < LKAS_DW.K1K2Det_T1) && (rtb_Add_jv >= 0.0F)) {
        /* '<S240>:1:35' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_jv) +
          LKAS_DW.In_f;
      } else if ((rtb_Add_jv <= LKAS_DW.K1K2Det_T1) && (rtb_Add_jv >=
                  LKAS_DW.K1K2Det_T1)) {
        /* '<S240>:1:36' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S240>:1:38' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
          LKAS_DW.K1K2Det_T1) + LKAS_DW.In_f;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_jv >= LKAS_DW.K1K2Det_T1) {
          /* '<S240>:1:40' elseif(NomT >= T2) */
          /* '<S240>:1:41' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
            LKAS_DW.K1K2Det_T1) + LKAS_DW.In_f;

          /*    DelteSWCmd = single(0); */
        }
      }

      /* Saturate: '<S152>/Saturation6' incorporates:
       *  MATLAB Function: '<S197>/SWACmd'
       */
      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S240>:1:47' SWACmd_phiSWACmd = DelteSWCmd; */
      if (LKAS_DW.K1K2Det_T1 > 2.0F) {
        rtb_Saturation6 = 2.0F;
      } else if (LKAS_DW.K1K2Det_T1 < 0.2F) {
        rtb_Saturation6 = 0.2F;
      } else {
        rtb_Saturation6 = LKAS_DW.K1K2Det_T1;
      }

      /* End of Saturate: '<S152>/Saturation6' */

      /* Memory: '<S182>/Memory' */
      rtb_Gain2_i = LKAS_DW.Memory_PreviousInput_cw;

      /* Sum: '<S182>/Add2' */
      rtb_Gain2_i += rtb_LKA_SampleTime;

      /* Saturate: '<S182>/Saturation2' */
      if (rtb_Gain2_i > 12.0F) {
        rtb_Saturation2_pb = 12.0F;
      } else if (rtb_Gain2_i < 0.0F) {
        rtb_Saturation2_pb = 0.0F;
      } else {
        rtb_Saturation2_pb = rtb_Gain2_i;
      }

      /* End of Saturate: '<S182>/Saturation2' */

      /* Abs: '<S182>/Abs2' */
      rtb_Gain2_i = fabsf(rtb_Gain1);

      /* Sum: '<S182>/Add3' incorporates:
       *  Sum: '<S183>/Add'
       *  Sum: '<S242>/Add'
       *  Sum: '<S263>/Add6'
       */
      rtb_L0_C3_i = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Gain: '<S182>/Gain' incorporates:
       *  Sum: '<S182>/Add3'
       */
      rtb_Divide3_j = rtb_L0_C3_i * 0.166666672F;

      /* RelationalOperator: '<S182>/Relational Operator2' */
      rtb_LogicalOperator3_c = (rtb_Gain2_i >= rtb_Divide3_j);

      /* Abs: '<S182>/Abs3' */
      rtb_Gain2_i = fabsf(rtb_Add5_g);

      /* Outputs for Enabled SubSystem: '<S182>/Sum Condition1' incorporates:
       *  EnablePort: '<S184>/Enable'
       */
      /* Logic: '<S182>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S182>/Relational Operator3'
       *  RelationalOperator: '<S182>/Relational Operator4'
       */
      if (((rtb_Saturation2_pb >= rtb_Saturation6) && rtb_LogicalOperator3_c) &&
          (rtb_Gain2_i >= rtb_Divide3_j)) {
        if (!LKAS_DW.SumCondition1_MODE_j) {
          /* InitializeConditions for Memory: '<S184>/Memory' */
          LKAS_DW.Memory_PreviousInput_h0 = 0.0F;
          LKAS_DW.SumCondition1_MODE_j = true;
        }

        /* Sum: '<S184>/Add1' incorporates:
         *  Memory: '<S184>/Memory'
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_h0;

        /* Saturate: '<S184>/Saturation' */
        if (rtb_LL_DvtSpdDet_vDvtSpdMin_C > 10.0F) {
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = 10.0F;
        } else {
          if (rtb_LL_DvtSpdDet_vDvtSpdMin_C < 0.0F) {
            rtb_LL_DvtSpdDet_vDvtSpdMin_C = 0.0F;
          }
        }

        /* End of Saturate: '<S184>/Saturation' */

        /* RelationalOperator: '<S184>/Relational Operator' incorporates:
         *  Sum: '<S182>/Add1'
         */
        LKAS_DW.RelationalOperator_d = (rtb_LL_DvtSpdDet_vDvtSpdMin_C >=
          (rtb_LL_LKAExPrcs_tiExitTime2 + rtb_LL_ThresDet_tiTTLCThresLDW));

        /* Update for Memory: '<S184>/Memory' */
        LKAS_DW.Memory_PreviousInput_h0 = rtb_LL_DvtSpdDet_vDvtSpdMin_C;
      } else {
        if (LKAS_DW.SumCondition1_MODE_j) {
          /* Disable for Outport: '<S184>/Out' */
          LKAS_DW.RelationalOperator_d = false;
          LKAS_DW.SumCondition1_MODE_j = false;
        }
      }

      /* End of Logic: '<S182>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S182>/Sum Condition1' */

      /* Memory: '<S183>/Memory' */
      rtb_Gain2_i = LKAS_DW.Memory_PreviousInput_ij;

      /* Sum: '<S183>/Add2' */
      rtb_Gain2_i += rtb_LKA_SampleTime;

      /* Saturate: '<S183>/Saturation2' */
      if (rtb_Gain2_i > 10.0F) {
        rtb_Saturation2_a = 10.0F;
      } else if (rtb_Gain2_i < 0.0F) {
        rtb_Saturation2_a = 0.0F;
      } else {
        rtb_Saturation2_a = rtb_Gain2_i;
      }

      /* End of Saturate: '<S183>/Saturation2' */

      /* Gain: '<S183>/Gain' */
      rtb_Gain2_i = rtb_L0_C3_i * 0.333333343F;

      /* Logic: '<S183>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S183>/Relational Operator2'
       *  RelationalOperator: '<S183>/Relational Operator3'
       *  RelationalOperator: '<S183>/Relational Operator4'
       */
      rtb_LogicalOperator3_c = (((rtb_Saturation2_a >= rtb_Saturation6) &&
        (rtb_Gain1 >= rtb_Gain2_i)) && (rtb_Add5_g >= rtb_Gain2_i));

      /* Abs: '<S183>/Abs4' */
      rtb_Gain2_i = rtb_TTLC_l;

      /* Saturate: '<S183>/Saturation' */
      if (rtb_Gain2_i > 0.004F) {
        rtb_Gain2_i = 0.004F;
      } else {
        if (rtb_Gain2_i < 0.0F) {
          rtb_Gain2_i = 0.0F;
        }
      }

      /* End of Saturate: '<S183>/Saturation' */

      /* Switch: '<S677>/Switch45' incorporates:
       *  Constant: '<S677>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S677>/Switch45' */

      /* Sum: '<S183>/Add6' incorporates:
       *  Constant: '<S183>/Constant'
       *  Constant: '<S183>/Constant7'
       *  Product: '<S183>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Gain2_i) / 0.004F) + x10;

      /* Outputs for Atomic SubSystem: '<S158>/Moving Standard Deviation2' */
      LKAS_MovingStandardDeviation2(rtb_IMAPve_g_EPS_SW_Trq, &rtb_Divide_jg,
        &rtb_StandardDeviation, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S158>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S183>/Moving Standard Deviation1' */
      rtb_Gain_k = (float32) LKAS_MovingStandardDeviation1(rtb_Add5_g,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S183>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S183>/Relational Operator6' */
      rtb_RelationalOperator6_i = (rtb_Gain_k <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S183>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_i, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_j0, &LKAS_DW.SumCondition1_k);

      /* End of Outputs for SubSystem: '<S183>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S183>/Moving Standard Deviation2' */
      rtb_Gain_k = (float32) LKAS_MovingStandardDeviation1(rtb_Gain1,
        &LKAS_DW.MovingStandardDeviation2_g);

      /* End of Outputs for SubSystem: '<S183>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S183>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain_k <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S183>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_j4, &LKAS_DW.SumCondition_d);

      /* End of Outputs for SubSystem: '<S183>/Sum Condition' */

      /* RelationalOperator: '<S193>/Compare' incorporates:
       *  Constant: '<S193>/Constant'
       *  Constant: '<S677>/LL_LKAExPrcs_ExitC0Swt=1'
       *  Logic: '<S183>/Logical Operator2'
       *  Switch: '<S677>/Switch46'
       */
      rtb_Compare_jr = (((sint32)((((rtb_LogicalOperator3_c &&
        (LKAS_DW.RelationalOperator_j0)) && (LKAS_DW.RelationalOperator_j4)) &&
        ((LKAS_ConstB.DataTypeConversion35) || (LL_LKAExPrcs_ExitC0Swt))) ? 1 :
        0)) > ((sint32)(false ? 1 : 0)));

      /* Memory: '<S183>/Memory1' */
      rtb_Memory1_a = LKAS_DW.Memory1_PreviousInput_c;

      /* If: '<S183>/If' incorporates:
       *  Constant: '<S186>/Constant'
       *  RelationalOperator: '<S185>/FixPt Relational Operator'
       *  UnitDelay: '<S185>/Delay Input1'
       *
       * Block description for '<S185>/Delay Input1':
       *
       *  Store in Global RAM
       */
      if (((sint32)(rtb_Compare_jr ? 1 : 0)) > ((sint32)
           (LKAS_DW.DelayInput1_DSTATE_m ? 1 : 0))) {
        /* Outputs for IfAction SubSystem: '<S183>/If Action Subsystem' incorporates:
         *  ActionPort: '<S186>/Action Port'
         */
        rtb_Merge_p1 = true;

        /* End of Outputs for SubSystem: '<S183>/If Action Subsystem' */
      } else {
        /* Outputs for IfAction SubSystem: '<S183>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S187>/Action Port'
         */
        LKAS_IfActionSubsystem3(rtb_Memory1_a, &rtb_Merge_p1);

        /* End of Outputs for SubSystem: '<S183>/If Action Subsystem3' */
      }

      /* End of If: '<S183>/If' */

      /* Outputs for Enabled SubSystem: '<S158>/Sum Condition2' incorporates:
       *  EnablePort: '<S163>/state = reset'
       */
      /* Outputs for Enabled SubSystem: '<S183>/Sum Condition2' incorporates:
       *  EnablePort: '<S192>/state = reset'
       */
      if (rtb_Merge_p1) {
        if (!LKAS_DW.SumCondition2_MODE) {
          /* InitializeConditions for Memory: '<S192>/Memory' */
          LKAS_DW.Memory_PreviousInput_k = 0.0F;
          LKAS_DW.SumCondition2_MODE = true;
        }

        /* Sum: '<S192>/Add1' incorporates:
         *  Memory: '<S192>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_k;

        /* Saturate: '<S192>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S192>/Saturation' */

        /* RelationalOperator: '<S192>/Relational Operator' */
        LKAS_DW.RelationalOperator_js = (rtb_LL_LKAExPrcs_tiExitTime2 >=
          rtb_LL_LKAExPrcs_tiExitDelayTim);

        /* Update for Memory: '<S192>/Memory' */
        LKAS_DW.Memory_PreviousInput_k = rtb_LL_LKAExPrcs_tiExitTime2;
        if (!LKAS_DW.SumCondition2_MODE_m) {
          /* InitializeConditions for Memory: '<S163>/Memory' */
          LKAS_DW.Memory_PreviousInput_ne = 0.0F;
          LKAS_DW.SumCondition2_MODE_m = true;
        }

        /* Sum: '<S163>/Add1' incorporates:
         *  Memory: '<S163>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_ne;

        /* Saturate: '<S163>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S163>/Saturation' */

        /* Switch: '<S677>/Switch28' incorporates:
         *  Constant: '<S677>/LL_LKASWASyn_M4K=0.1'
         */
        if (LKAS_ConstB.DataTypeConversion42 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion42;
        } else {
          x10 = LL_LKASWASyn_M4K;
        }

        /* End of Switch: '<S677>/Switch28' */

        /* Sum: '<S163>/Add2' incorporates:
         *  Constant: '<S163>/Constant1'
         */
        rtb_LftTTLC = x10 - 1.0F;

        /* Product: '<S163>/Divide' */
        rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LL_LKAExPrcs_tiExitTime2 /
          rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Saturate: '<S163>/Saturation1' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 1.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 1.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        /* End of Saturate: '<S163>/Saturation1' */

        /* Saturate: '<S163>/Saturation2' */
        if (rtb_LftTTLC > 0.0F) {
          rtb_LftTTLC = 0.0F;
        } else {
          if (rtb_LftTTLC < (-1.0F)) {
            rtb_LftTTLC = (-1.0F);
          }
        }

        /* End of Saturate: '<S163>/Saturation2' */

        /* Sum: '<S163>/Add3' incorporates:
         *  Constant: '<S163>/Constant2'
         *  Product: '<S163>/Divide1'
         */
        rtb_LftTTLC = (rtb_LL_LKAExPrcs_ExitC0Dvt * rtb_LftTTLC) + 1.0F;

        /* Saturate: '<S163>/Saturation3' */
        if (rtb_LftTTLC > 1.0F) {
          LKAS_DW.Saturation3 = 1.0F;
        } else if (rtb_LftTTLC < 0.0F) {
          LKAS_DW.Saturation3 = 0.0F;
        } else {
          LKAS_DW.Saturation3 = rtb_LftTTLC;
        }

        /* End of Saturate: '<S163>/Saturation3' */

        /* Update for Memory: '<S163>/Memory' */
        LKAS_DW.Memory_PreviousInput_ne = rtb_LL_LKAExPrcs_tiExitTime2;
      } else {
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S192>/Out' */
          LKAS_DW.RelationalOperator_js = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        if (LKAS_DW.SumCondition2_MODE_m) {
          /* Disable for Outport: '<S163>/M4K' */
          LKAS_DW.Saturation3 = 1.0F;
          LKAS_DW.SumCondition2_MODE_m = false;
        }
      }

      /* End of Outputs for SubSystem: '<S183>/Sum Condition2' */
      /* End of Outputs for SubSystem: '<S158>/Sum Condition2' */

      /* Fcn: '<S151>/Fcn' incorporates:
       *  DataTypeConversion: '<S151>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((LKAS_DW.RelationalOperator_js ? 1 : 0) *
        (LKAS_DW.RelationalOperator_js ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!LKAS_DW.RelationalOperator_js) ? 1 : 0)) *
        (LKAS_DW.RelationalOperator_d ? 1 : 0)) * ((sint32)2.0F))) + (((sint32)
        (((!LKAS_DW.RelationalOperator_d) && (!LKAS_DW.RelationalOperator_js)) ?
         1 : 0)) * (rtb_BCM_Right_Light ? 1 : 0))));

      /* Logic: '<S151>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_BCM_Right_Light ||
        (LKAS_DW.RelationalOperator_d)) || (LKAS_DW.RelationalOperator_js));

      /* DataTypeConversion: '<S154>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon_m = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Memory: '<S164>/Memory3' */
      rtb_Gain2_i = LKAS_DW.Memory3_PreviousInput_m;

      /* Sum: '<S164>/Add2' */
      rtb_Gain2_i += rtb_LKA_SampleTime;

      /* Saturate: '<S164>/Saturation' */
      if (rtb_Gain2_i > 50.0F) {
        rtb_Saturation_f = 50.0F;
      } else if (rtb_Gain2_i < 0.0F) {
        rtb_Saturation_f = 0.0F;
      } else {
        rtb_Saturation_f = rtb_Gain2_i;
      }

      /* End of Saturate: '<S164>/Saturation' */

      /* MATLAB Function: '<S158>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Driver Torque Assist/MATLAB Function': '<S161>:1' */
      /* '<S161>:1:2' if T<T1 */
      if (rtb_Saturation_f < rtb_Saturation6) {
        /* '<S161>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_LL_LKASWASyn_M0 += ((rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6) * rtb_Saturation_f;
      } else if ((rtb_Saturation_f >= rtb_Saturation6) && (rtb_Saturation_f <=
                  (rtb_Saturation6 + rtb_Saturation6))) {
        /* Switch: '<S677>/Switch14' incorporates:
         *  Constant: '<S677>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S161>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S161>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_h != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_h;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (((x10 - rtb_LL_LKASWASyn_M1) / rtb_Saturation6) *
          (rtb_Saturation_f - rtb_Saturation6)) + rtb_LL_LKASWASyn_M1;
      } else {
        /* Switch: '<S677>/Switch14' incorporates:
         *  Constant: '<S677>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S161>:1:6' else */
        /* '<S161>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_h != 0.0F) {
          rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20_h;
        } else {
          rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S158>/MATLAB Function' */

      /* UnitDelay: '<S178>/Delay Input2'
       *
       * Block description for '<S178>/Delay Input2':
       *
       *  Store in Global RAM
       */
      rtb_Yk1_k = LKAS_DW.DelayInput2_DSTATE_a;

      /* Memory: '<S160>/Memory1' */
      rtb_Gain2_i = LKAS_DW.Memory1_PreviousInput_n;

      /* Sum: '<S160>/Add' */
      rtb_Gain2_i += rtb_LKA_SampleTime;

      /* Saturate: '<S160>/Saturation1' */
      if (rtb_Gain2_i > 0.3F) {
        rtb_Saturation1_g = 0.3F;
      } else if (rtb_Gain2_i < (-0.5F)) {
        rtb_Saturation1_g = (-0.5F);
      } else {
        rtb_Saturation1_g = rtb_Gain2_i;
      }

      /* End of Saturate: '<S160>/Saturation1' */

      /* Memory: '<S160>/Memory' */
      rtb_Gain2_i = LKAS_DW.Memory_PreviousInput_em;

      /* Switch: '<S160>/Switch' incorporates:
       *  Constant: '<S160>/Constant3'
       *  Constant: '<S160>/Constant4'
       *  Constant: '<S172>/Constant'
       *  Constant: '<S174>/Constant'
       *  Logic: '<S160>/OR1'
       *  RelationalOperator: '<S172>/Compare'
       *  RelationalOperator: '<S174>/Compare'
       */
      if ((rtb_Saturation1_g <= 0.2F) || (rtb_Gain2_i > 0.4F)) {
        rtb_Gain2_i = 5.0F;
      } else {
        rtb_Gain2_i = 0.4F;
      }

      /* End of Switch: '<S160>/Switch' */

      /* SampleTimeMath: '<S178>/sample time'
       *
       * About '<S178>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_Divide3_j = 0.01F;

      /* Product: '<S178>/delta rise limit' */
      rtb_deltariselimit_g = rtb_Gain2_i * rtb_Divide3_j;

      /* Outputs for Enabled SubSystem: '<S150>/Subsystem' incorporates:
       *  EnablePort: '<S159>/Enable'
       */
      /* RelationalOperator: '<S157>/Compare' incorporates:
       *  Constant: '<S157>/Constant'
       *  Constant: '<S677>/LL_LKASWASyn_TrqSwaAddSwt=1'
       *  Switch: '<S677>/Switch47'
       */
      if (((sint32)(((LKAS_ConstB.DataTypeConversion47_d) ||
                     (LL_LKASWASyn_TrqSwaAddSwt)) ? 1 : 0)) > ((sint32)(false ?
            1 : 0))) {
        if (!LKAS_DW.Subsystem_MODE_h) {
          LKAS_DW.Subsystem_MODE_h = true;
        }

        /* MATLAB Function: '<S159>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S165>:1' */
        /* '<S165>:1:2' Swaadd=single(0); */
        /* '<S165>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S165>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S165>:1:5' l0c0=abs(l0c0); */
        /* '<S165>:1:6' r0c0=abs(r0c0); */
        /* '<S165>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_LL_LKAExPrcs_tiExitDelayTim = fmaxf(fminf(rtb_LKA_Veh2CamW_C +
          rtb_Add5_g_tmp, 5.4F), 2.5F);

        /* '<S165>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_LL_LKAExPrcs_tiExitDelayTim > 2.5F) &&
            (rtb_LL_LKAExPrcs_tiExitDelayTim < 5.4F)) {
          /* '<S165>:1:9' leftlane=l0c0/lanewidth; */
          rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_Veh2CamW_C /
            rtb_LL_LKAExPrcs_tiExitDelayTim;

          /* '<S165>:1:10' rightlane=r0c0/lanewidth; */
          rtb_LL_LKASWASyn_M1 = rtb_Add5_g_tmp / rtb_LL_LKAExPrcs_tiExitDelayTim;
        } else {
          /* '<S165>:1:11' else */
          /* '<S165>:1:12' leftlane=single(0.5); */
          rtb_LL_LKAExPrcs_tiExitTime2 = 0.5F;

          /* '<S165>:1:13' rightlane=single(0.5); */
          rtb_LL_LKASWASyn_M1 = 0.5F;
        }

        /* '<S165>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S165>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S165>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S677>/Switch42' incorporates:
           *  Constant: '<S677>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S165>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S677>/Switch43' incorporates:
           *  Constant: '<S677>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M1 = (((((180.0F - fmaxf(fminf(rtb_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_LL_LKAExPrcs_tiExitTime2) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S677>/Switch42' incorporates:
           *  Constant: '<S677>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S165>:1:19' else */
          /* '<S165>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S677>/Switch43' incorporates:
           *  Constant: '<S677>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M1 = (((((180.0F - fmaxf(fminf(rtb_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_LL_LKASWASyn_M1) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S166>/Add2' incorporates:
         *  Constant: '<S166>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S166>/Memory3'
         */
        rtb_LL_LKAExPrcs_tiExitDelayTim = 1.0F + LKAS_DW.Memory3_PreviousInput_i;

        /* Saturate: '<S166>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitDelayTim > 50.0F) {
          rtb_LL_LKAExPrcs_tiExitDelayTim = 50.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitDelayTim < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitDelayTim = 0.0F;
          }
        }

        /* End of Saturate: '<S166>/Saturation' */

        /* Switch: '<S166>/Switch' incorporates:
         *  Product: '<S166>/Divide'
         *  Product: '<S166>/Divide1'
         *  Sum: '<S166>/Add'
         *  Sum: '<S166>/Add1'
         *  UnitDelay: '<S166>/Unit Delay'
         */
        if (rtb_LL_LKAExPrcs_tiExitDelayTim > 1.0F) {
          /* Switch: '<S677>/Switch50' incorporates:
           *  Constant: '<S677>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S677>/Switch50' */
          rtb_LL_LKASWASyn_M1 = ((rtb_LKA_SampleTime / x10) *
            (rtb_LL_LKASWASyn_M1 - LKAS_DW.UnitDelay_DSTATE_i)) +
            LKAS_DW.UnitDelay_DSTATE_i;
        }

        /* End of Switch: '<S166>/Switch' */

        /* SampleTimeMath: '<S169>/TSamp'
         *
         * About '<S169>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LL_LKASWASyn_M1 * 100.0F;

        /* Sum: '<S167>/Add2' incorporates:
         *  Constant: '<S167>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S167>/Memory3'
         */
        rtb_LL_LKAExPrcs_ExitC0Dvt = 1.0F + LKAS_DW.Memory3_PreviousInput_e;

        /* Saturate: '<S167>/Saturation' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 50.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 50.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        /* End of Saturate: '<S167>/Saturation' */

        /* Switch: '<S167>/Switch' incorporates:
         *  Product: '<S167>/Divide'
         *  Product: '<S167>/Divide1'
         *  Sum: '<S167>/Add'
         *  Sum: '<S167>/Add1'
         *  Sum: '<S169>/Diff'
         *  UnitDelay: '<S167>/Unit Delay'
         *  UnitDelay: '<S169>/UD'
         *
         * Block description for '<S169>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S169>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 2.0F) {
          /* Switch: '<S677>/Switch52' incorporates:
           *  Constant: '<S677>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S677>/Switch52' */
          rtb_LL_ThresDet_tiTTLCThresLDW = (((rtb_LL_LKAExPrcs_tiExitTime2 -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_j) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_j;
        } else {
          rtb_LL_ThresDet_tiTTLCThresLDW = rtb_LL_LKAExPrcs_tiExitTime2 -
            LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S167>/Switch' */

        /* Saturate: '<S159>/Saturation' */
        if (rtb_LL_ThresDet_tiTTLCThresLDW > 30.0F) {
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = 30.0F;
        } else if (rtb_LL_ThresDet_tiTTLCThresLDW < (-30.0F)) {
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = (-30.0F);
        } else {
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_LL_ThresDet_tiTTLCThresLDW;
        }

        /* End of Saturate: '<S159>/Saturation' */

        /* Switch: '<S677>/Switch53' incorporates:
         *  Constant: '<S677>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S677>/Switch53' */

        /* Sum: '<S168>/Difference Inputs1' incorporates:
         *  Product: '<S159>/Divide1'
         *  Product: '<S159>/Divide3'
         *  Sum: '<S159>/Add'
         *  UnitDelay: '<S168>/Delay Input2'
         *
         * Block description for '<S168>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S168>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = ((rtb_LL_DvtSpdDet_vDvtSpdMin_C * x10) +
          rtb_LL_LKASWASyn_M1) - LKAS_DW.DelayInput2_DSTATE_io;

        /* Product: '<S168>/delta rise limit' incorporates:
         *  Constant: '<S159>/Constant1'
         *  SampleTimeMath: '<S168>/sample time'
         *
         * About '<S168>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_Abs_g = 5.0F * 0.01F;

        /* Product: '<S168>/delta fall limit' incorporates:
         *  Constant: '<S159>/Constant2'
         *  SampleTimeMath: '<S168>/sample time'
         *
         * About '<S168>/sample time':
         *  y = K where K = ( w * Ts )
         */
        x10 = (-5.0F) * 0.01F;

        /* Switch: '<S170>/Switch2' incorporates:
         *  Product: '<S168>/delta fall limit'
         *  RelationalOperator: '<S170>/LowerRelop1'
         *  RelationalOperator: '<S170>/UpperRelop'
         *  Switch: '<S170>/Switch'
         */
        if (rtb_LL_DvtSpdDet_vDvtSpdMin_C > rtb_Abs_g) {
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_Abs_g;
        } else {
          if (rtb_LL_DvtSpdDet_vDvtSpdMin_C < x10) {
            /* Switch: '<S170>/Switch' incorporates:
             *  Product: '<S168>/delta fall limit'
             */
            rtb_LL_DvtSpdDet_vDvtSpdMin_C = x10;
          }
        }

        /* End of Switch: '<S170>/Switch2' */

        /* Sum: '<S168>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S168>/Delay Input2'
         *
         * Block description for '<S168>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S168>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_j = rtb_LL_DvtSpdDet_vDvtSpdMin_C +
          LKAS_DW.DelayInput2_DSTATE_io;

        /* Update for UnitDelay: '<S166>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_i = rtb_LL_LKASWASyn_M1;

        /* Update for Memory: '<S166>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_i = rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Update for UnitDelay: '<S169>/UD'
         *
         * Block description for '<S169>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for UnitDelay: '<S167>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_j = rtb_LL_ThresDet_tiTTLCThresLDW;

        /* Update for Memory: '<S167>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e = rtb_LL_LKAExPrcs_ExitC0Dvt;

        /* Update for UnitDelay: '<S168>/Delay Input2'
         *
         * Block description for '<S168>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_io = LKAS_DW.DifferenceInputs2_j;
      } else {
        if (LKAS_DW.Subsystem_MODE_h) {
          /* Disable for Outport: '<S159>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_j = 0.0F;
          LKAS_DW.Subsystem_MODE_h = false;
        }
      }

      /* End of RelationalOperator: '<S157>/Compare' */
      /* End of Outputs for SubSystem: '<S150>/Subsystem' */

      /* UnitDelay: '<S177>/Delay Input2'
       *
       * Block description for '<S177>/Delay Input2':
       *
       *  Store in Global RAM
       */
      rtb_Yk1_j = LKAS_DW.DelayInput2_DSTATE_b;

      /* Product: '<S177>/delta rise limit' incorporates:
       *  SampleTimeMath: '<S177>/sample time'
       *
       * About '<S177>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_deltariselimit_l = rtb_Gain2_i * 0.01F;

      /* Outputs for Atomic SubSystem: '<S160>/Moving Standard Deviation2' */
      rtb_Gain_k = (float32) LKAS_MovingStandardDeviation2_l
        (rtb_IMAPve_g_EPS_SW_Trq, &LKAS_DW.MovingStandardDeviation2_l);

      /* End of Outputs for SubSystem: '<S160>/Moving Standard Deviation2' */

      /* Abs: '<S160>/Abs' */
      rtb_Gain2_i = fabsf(rtb_Gain_k);

      /* Fcn: '<S160>/Fcn' */
      rtb_LL_LKASWASyn_M1 = (-0.6F * rtb_Gain2_i) + 0.75F;

      /* Switch: '<S160>/Switch1' incorporates:
       *  Constant: '<S160>/Constant'
       *  Constant: '<S175>/Constant'
       *  RelationalOperator: '<S175>/Compare'
       *  Saturate: '<S160>/Saturation'
       */
      if (rtb_LL_LKASWASyn_M1 > 0.4F) {
        rtb_Switch1 = 1.0F;
      } else if (rtb_LL_LKASWASyn_M1 > 0.4F) {
        /* Saturate: '<S160>/Saturation' */
        rtb_Switch1 = 0.4F;
      } else if (rtb_LL_LKASWASyn_M1 < 0.0F) {
        /* Saturate: '<S160>/Saturation' */
        rtb_Switch1 = 0.0F;
      } else {
        /* Saturate: '<S160>/Saturation' */
        rtb_Switch1 = rtb_LL_LKASWASyn_M1;
      }

      /* End of Switch: '<S160>/Switch1' */

      /* Sum: '<S177>/Difference Inputs1'
       *
       * Block description for '<S177>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_p = rtb_Switch1 - rtb_Yk1_j;

      /* Product: '<S177>/delta fall limit' incorporates:
       *  Constant: '<S160>/Constant5'
       *  SampleTimeMath: '<S177>/sample time'
       *
       * About '<S177>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_deltafalllimit_b = (-5.0F) * 0.01F;

      /* Switch: '<S179>/Switch' incorporates:
       *  RelationalOperator: '<S179>/UpperRelop'
       */
      if (rtb_UkYk1_p < rtb_deltafalllimit_b) {
        rtb_Switch_dy = rtb_deltafalllimit_b;
      } else {
        rtb_Switch_dy = rtb_UkYk1_p;
      }

      /* End of Switch: '<S179>/Switch' */

      /* Switch: '<S179>/Switch2' incorporates:
       *  RelationalOperator: '<S179>/LowerRelop1'
       */
      if (rtb_UkYk1_p > rtb_deltariselimit_l) {
        rtb_Switch2_a = rtb_deltariselimit_l;
      } else {
        rtb_Switch2_a = rtb_Switch_dy;
      }

      /* End of Switch: '<S179>/Switch2' */

      /* Sum: '<S177>/Difference Inputs2'
       *
       * Block description for '<S177>/Difference Inputs2':
       *
       *  Add in CPU
       */
      rtb_DifferenceInputs2_k = rtb_Switch2_a + rtb_Yk1_j;

      /* RelationalOperator: '<S173>/Compare' incorporates:
       *  Constant: '<S173>/Constant'
       */
      rtb_BCM_Right_Light = (rtb_DifferenceInputs2_k < 0.01F);

      /* Chart: '<S160>/Chart' */
      if (((uint32)LKAS_DW.temporalCounter_i1) < 127U) {
        LKAS_DW.temporalCounter_i1 = (uint8)(((uint32)LKAS_DW.temporalCounter_i1)
          + 1U);
      }

      /* Gateway: LKAS/LL/LLOn/LKA/Driver Torque Addition
         (DTA)/Subsystem1/Chart */
      /* During: LKAS/LL/LLOn/LKA/Driver Torque Addition
         (DTA)/Subsystem1/Chart */
      if (((uint32)LKAS_DW.is_active_c2_LKAS) == 0U) {
        /* Entry: LKAS/LL/LLOn/LKA/Driver Torque Addition
           (DTA)/Subsystem1/Chart */
        LKAS_DW.is_active_c2_LKAS = 1U;

        /* Entry Internal: LKAS/LL/LLOn/LKA/Driver Torque Addition
           (DTA)/Subsystem1/Chart */
        /* Transition: '<S171>:14' */
        /* '<S171>:10:1' sf_internal_predicateOutput = DriverAct == 1; */
        if (rtb_BCM_Right_Light) {
          /* Transition: '<S171>:10' */
          LKAS_DW.is_c2_LKAS = LKAS_IN_DriverAct;
          LKAS_DW.temporalCounter_i1 = 0U;

          /* Entry 'DriverAct': '<S171>:4' */
          /* '<S171>:4:1' TrqFactor = single(0); */
          rtb_TrqFactor = 0.0F;
        } else {
          /* Transition: '<S171>:5' */
          LKAS_DW.is_c2_LKAS = LKAS_IN_ADASAct;

          /* Entry 'ADASAct': '<S171>:7' */
          /* '<S171>:7:1' TrqFactor = TrqFactorIn; */
          rtb_TrqFactor = rtb_DifferenceInputs2_k;
        }
      } else if (((uint32)LKAS_DW.is_c2_LKAS) == LKAS_IN_ADASAct) {
        /* During 'ADASAct': '<S171>:7' */
        /* '<S171>:9:1' sf_internal_predicateOutput = DriverAct == 1; */
        if (rtb_BCM_Right_Light) {
          /* Transition: '<S171>:9' */
          LKAS_DW.is_c2_LKAS = LKAS_IN_DriverAct;
          LKAS_DW.temporalCounter_i1 = 0U;

          /* Entry 'DriverAct': '<S171>:4' */
          /* '<S171>:4:1' TrqFactor = single(0); */
          rtb_TrqFactor = 0.0F;
        } else {
          /* '<S171>:7:1' TrqFactor = TrqFactorIn; */
          rtb_TrqFactor = rtb_DifferenceInputs2_k;
        }
      } else {
        /* During 'DriverAct': '<S171>:4' */
        /* '<S171>:8:1' sf_internal_predicateOutput = DriverAct == 0 & after(1,sec); */
        if ((!rtb_BCM_Right_Light) && (((uint32)LKAS_DW.temporalCounter_i1) >=
             100U)) {
          /* Transition: '<S171>:8' */
          LKAS_DW.is_c2_LKAS = LKAS_IN_ADASAct;

          /* Entry 'ADASAct': '<S171>:7' */
          /* '<S171>:7:1' TrqFactor = TrqFactorIn; */
          rtb_TrqFactor = rtb_DifferenceInputs2_k;
        } else {
          /* '<S171>:4:1' TrqFactor =single(0); */
          rtb_TrqFactor = 0.0F;
        }
      }

      /* End of Chart: '<S160>/Chart' */

      /* Sum: '<S178>/Difference Inputs1'
       *
       * Block description for '<S178>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_a = rtb_TrqFactor - rtb_Yk1_k;

      /* Product: '<S178>/delta fall limit' incorporates:
       *  Constant: '<S160>/Constant6'
       */
      rtb_deltafalllimit_l = (-5.0F) * rtb_Divide3_j;

      /* Switch: '<S180>/Switch' incorporates:
       *  RelationalOperator: '<S180>/UpperRelop'
       */
      if (rtb_UkYk1_a < rtb_deltafalllimit_l) {
        rtb_Switch_di = rtb_deltafalllimit_l;
      } else {
        rtb_Switch_di = rtb_UkYk1_a;
      }

      /* End of Switch: '<S180>/Switch' */

      /* Switch: '<S180>/Switch2' incorporates:
       *  RelationalOperator: '<S180>/LowerRelop1'
       */
      if (rtb_UkYk1_a > rtb_deltariselimit_g) {
        rtb_Switch2_b = rtb_deltariselimit_g;
      } else {
        rtb_Switch2_b = rtb_Switch_di;
      }

      /* End of Switch: '<S180>/Switch2' */

      /* Sum: '<S178>/Difference Inputs2'
       *
       * Block description for '<S178>/Difference Inputs2':
       *
       *  Add in CPU
       */
      rtb_DifferenceInputs2_g = rtb_Switch2_b + rtb_Yk1_k;

      /* Switch: '<S150>/Switch' incorporates:
       *  Constant: '<S677>/LL_LKASWASyn_TrqFctSwt=0'
       *  Switch: '<S677>/Switch29'
       */
      if ((LKAS_ConstB.DataTypeConversion43) || (LL_LKASWASyn_TrqFctSwt)) {
        /* Switch: '<S677>/Switch27' incorporates:
         *  Constant: '<S677>/LL_LKASWASyn_M3K_MSD=0.2'
         */
        if (LKAS_ConstB.DataTypeConversion41 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion41;
        } else {
          x10 = LL_LKASWASyn_M3K_MSD;
        }

        /* End of Switch: '<S677>/Switch27' */

        /* Product: '<S158>/Divide' */
        rtb_LftTTLC = rtb_StandardDeviation * x10;

        /* Sum: '<S158>/Add' */
        rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_IMAPve_g_EPS_SW_Trq - rtb_Divide_jg;

        /* Saturate: '<S158>/Saturation4' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 2.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 2.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        /* End of Saturate: '<S158>/Saturation4' */

        /* Abs: '<S158>/Abs' */
        rtb_LL_LKAExPrcs_ExitC0Dvt = fabsf(rtb_LL_LKAExPrcs_ExitC0Dvt);

        /* Saturate: '<S158>/Saturation7' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 1.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 1.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        /* End of Saturate: '<S158>/Saturation7' */

        /* Switch: '<S677>/Switch26' incorporates:
         *  Constant: '<S677>/LL_LKASWASyn_M3D=0.5'
         */
        if (LKAS_ConstB.DataTypeConversion40 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion40;
        } else {
          x10 = LL_LKASWASyn_M3D;
        }

        /* End of Switch: '<S677>/Switch26' */

        /* Product: '<S158>/Divide2' */
        rtb_LL_LKAExPrcs_ExitC0Dvt /= x10;

        /* Saturate: '<S158>/Saturation5' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 1.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 1.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        /* End of Saturate: '<S158>/Saturation5' */

        /* Switch: '<S677>/Switch18' incorporates:
         *  Constant: '<S677>/LL_LKASWASyn_M3K_DT=0.2'
         */
        if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion25;
        } else {
          x10 = LL_LKASWASyn_M3K_DT;
        }

        /* End of Switch: '<S677>/Switch18' */

        /* Product: '<S158>/Divide1' */
        rtb_LL_LKAExPrcs_ExitC0Dvt *= x10;

        /* Saturate: '<S158>/Saturation3' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 0.4F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 0.4F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        /* End of Saturate: '<S158>/Saturation3' */

        /* Saturate: '<S158>/Saturation1' */
        if (rtb_LftTTLC > 0.4F) {
          rtb_LftTTLC = 0.4F;
        } else {
          if (rtb_LftTTLC < 0.0F) {
            rtb_LftTTLC = 0.0F;
          }
        }

        /* End of Saturate: '<S158>/Saturation1' */

        /* Sum: '<S158>/Add1' */
        rtb_LftTTLC = (rtb_LL_LKASWASyn_M0 - rtb_LL_LKAExPrcs_ExitC0Dvt) -
          rtb_LftTTLC;

        /* Saturate: '<S158>/Saturation6' */
        if (rtb_LftTTLC > 1.0F) {
          rtb_LftTTLC = 1.0F;
        } else {
          if (rtb_LftTTLC < 0.01F) {
            rtb_LftTTLC = 0.01F;
          }
        }

        /* End of Saturate: '<S158>/Saturation6' */

        /* Product: '<S158>/Divide5' */
        rtb_LftTTLC *= LKAS_DW.Saturation3;

        /* Saturate: '<S158>/Saturation2' */
        if (rtb_LftTTLC > 1.0F) {
          LKAS_DW.Switch = 1.0F;
        } else if (rtb_LftTTLC < 0.01F) {
          LKAS_DW.Switch = 0.01F;
        } else {
          LKAS_DW.Switch = rtb_LftTTLC;
        }

        /* End of Saturate: '<S158>/Saturation2' */
      } else {
        LKAS_DW.Switch = rtb_DifferenceInputs2_g;
      }

      /* End of Switch: '<S150>/Switch' */

      /* Sum: '<S275>/Add2' incorporates:
       *  Memory: '<S275>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_p;

      /* Saturate: '<S275>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_oq = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_oq = 0.0F;
      } else {
        rtb_Saturation_oq = rtb_LftTTLC;
      }

      /* End of Saturate: '<S275>/Saturation' */

      /* If: '<S273>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       *  Inport: '<S281>/Plan'
       *  Inport: '<S281>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_d;
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_d = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S273>/If Action Subsystem' incorporates:
           *  ActionPort: '<S279>/Action Port'
           */
          /* InitializeConditions for If: '<S273>/If' incorporates:
           *  Memory: '<S279>/Memory'
           *  UnitDelay: '<S283>/Delay Input1'
           *
           * Block description for '<S283>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_j = false;
          LKAS_DW.Memory_PreviousInput_d = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S273>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S273>/If Action Subsystem' incorporates:
         *  ActionPort: '<S279>/Action Port'
         */
        /* RelationalOperator: '<S282>/Compare' incorporates:
         *  Constant: '<S282>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Lft >= 0.0F);

        /* Memory: '<S279>/Memory' */
        rtb_Plan_m = LKAS_DW.Memory_PreviousInput_d;

        /* Sum: '<S279>/Add' incorporates:
         *  Logic: '<S279>/Logical Operator'
         *  RelationalOperator: '<S279>/Relational Operator'
         *  RelationalOperator: '<S283>/FixPt Relational Operator'
         *  UnitDelay: '<S283>/Delay Input1'
         *
         * Block description for '<S283>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_p = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_j ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_oq)) ? 1 : 0)) + rtb_Plan_m;

        /* Saturate: '<S279>/Saturation' */
        if (rtb_T1_p > 5.0F) {
          rtb_Saturation_m = 5.0F;
        } else if (rtb_T1_p < 0.0F) {
          rtb_Saturation_m = 0.0F;
        } else {
          rtb_Saturation_m = rtb_T1_p;
        }

        /* End of Saturate: '<S279>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S279>/If Action Subsystem' */
        LKAS_IfActionSubsystem_f(rtb_Saturation_m, rtb_Saturation_oq,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_j, &LKAS_DW.In_m,
          &LKAS_DW.IfActionSubsystem_fw);

        /* End of Outputs for SubSystem: '<S279>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S279>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_i(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_p, &rtb_Plan_m);

        /* End of Outputs for SubSystem: '<S279>/If Action Subsystem2' */

        /* Switch: '<S279>/Switch' incorporates:
         *  Switch: '<S279>/Switch1'
         */
        if (rtb_Saturation_m > 0.0F) {
          LKAS_DW.Merge_a = LKAS_DW.In_j;
          LKAS_DW.Merge1 = LKAS_DW.In_m;
        } else {
          LKAS_DW.Merge_a = rtb_T1_p;
          LKAS_DW.Merge1 = rtb_Plan_m;
        }

        /* End of Switch: '<S279>/Switch' */

        /* Update for UnitDelay: '<S283>/Delay Input1'
         *
         * Block description for '<S283>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_j = rtb_BCM_Right_Light;

        /* Update for Memory: '<S279>/Memory' */
        LKAS_DW.Memory_PreviousInput_d = rtb_Saturation_m;

        /* End of Outputs for SubSystem: '<S273>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S273>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S280>/Action Port'
           */
          /* InitializeConditions for If: '<S273>/If' incorporates:
           *  Memory: '<S280>/Memory'
           *  UnitDelay: '<S291>/Delay Input1'
           *
           * Block description for '<S291>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_ej = false;
          LKAS_DW.Memory_PreviousInput_o = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S273>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S273>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S280>/Action Port'
         */
        /* RelationalOperator: '<S290>/Compare' incorporates:
         *  Constant: '<S290>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Rgt <= 0.0F);

        /* Memory: '<S280>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_o;

        /* Sum: '<S280>/Add' incorporates:
         *  Logic: '<S280>/Logical Operator'
         *  RelationalOperator: '<S280>/Relational Operator'
         *  RelationalOperator: '<S291>/FixPt Relational Operator'
         *  UnitDelay: '<S291>/Delay Input1'
         *
         * Block description for '<S291>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_g = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_ej ? 1 : 0))) && (rtb_Saturation6
          >= rtb_Saturation_oq)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S280>/Saturation' */
        if (rtb_T1_g > 5.0F) {
          rtb_Saturation_ev = 5.0F;
        } else if (rtb_T1_g < 0.0F) {
          rtb_Saturation_ev = 0.0F;
        } else {
          rtb_Saturation_ev = rtb_T1_g;
        }

        /* End of Saturate: '<S280>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S280>/If Action Subsystem' */
        LKAS_IfActionSubsystem_f(rtb_Saturation_ev, rtb_Saturation_oq,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_o, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_hc);

        /* End of Outputs for SubSystem: '<S280>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S280>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_i(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_g, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S280>/If Action Subsystem2' */

        /* Switch: '<S280>/Switch' incorporates:
         *  Switch: '<S280>/Switch1'
         */
        if (rtb_Saturation_ev > 0.0F) {
          LKAS_DW.Merge_a = LKAS_DW.In_o;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_a = rtb_T1_g;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S280>/Switch' */

        /* Update for UnitDelay: '<S291>/Delay Input1'
         *
         * Block description for '<S291>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_ej = rtb_BCM_Right_Light;

        /* Update for Memory: '<S280>/Memory' */
        LKAS_DW.Memory_PreviousInput_o = rtb_Saturation_ev;

        /* End of Outputs for SubSystem: '<S273>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S273>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S281>/Action Port'
         */
        LKAS_DW.Merge_a = rtb_Saturation6;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S273>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S273>/If' */

      /* Saturate: '<S156>/Saturation6' */
      if (LKAS_DW.Merge_a > 0.5F) {
        rtb_LL_LKASWASyn_M0 = 0.5F;
      } else if (LKAS_DW.Merge_a < 0.2F) {
        rtb_LL_LKASWASyn_M0 = 0.2F;
      } else {
        rtb_LL_LKASWASyn_M0 = LKAS_DW.Merge_a;
      }

      /* End of Saturate: '<S156>/Saturation6' */

      /* Product: '<S156>/Divide' incorporates:
       *  Product: '<S276>/Divide'
       *  Sum: '<S156>/Add2'
       */
      rtb_LL_LKAExPrcs_tiExitTime2 = (rtb_Saturation_oq - LKAS_DW.Merge_a) /
        rtb_LL_LKASWASyn_M0;
      rtb_Gain2_i = rtb_LL_LKAExPrcs_tiExitTime2;

      /* Saturate: '<S156>/Saturation2' */
      if (rtb_Gain2_i > 1.0F) {
        rtb_Gain2_i = 1.0F;
      } else {
        if (rtb_Gain2_i < 0.0F) {
          rtb_Gain2_i = 0.0F;
        }
      }

      /* End of Saturate: '<S156>/Saturation2' */

      /* Sum: '<S156>/Add5' incorporates:
       *  Constant: '<S156>/Constant2'
       */
      rtb_LL_LKASWASyn_M1 = 1.0F - rtb_Gain2_i;

      /* Memory: '<S258>/Memory' */
      rtb_Divide3_j = LKAS_DW.Memory_PreviousInput_e4;

      /* Product: '<S325>/Z*Z' incorporates:
       *  Product: '<S322>/Z*Z'
       */
      rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LL_HdAgPrvwT_C * rtb_LL_HdAgPrvwT_C;

      /* Sum: '<S258>/Add1' incorporates:
       *  Gain: '<S304>/Gain2'
       *  Product: '<S258>/Divide'
       *  Product: '<S258>/Divide1'
       *  Product: '<S322>/Product3'
       *  Product: '<S322>/Product4'
       *  Product: '<S325>/Product3'
       *  Product: '<S325>/Product4'
       *  Product: '<S325>/Z*Z'
       *  Sum: '<S304>/Add2'
       *  Sum: '<S322>/Add'
       *  Sum: '<S325>/Add'
       */
      rtb_Add1_my = ((((((rtb_Add_gv_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_c) +
                        (rtb_LL_ThresDet_lDvtThresUprLKA *
                         rtb_LL_LKAExPrcs_ExitC0Dvt)) + (((rtb_Add_a_tmp *
        rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_h5) + (rtb_L0_C3 *
        rtb_LL_LKAExPrcs_ExitC0Dvt))) * 0.5F) * LKAS_ConstB.Divide2_i) +
        (LKAS_ConstB.Add2_h * rtb_Divide3_j);

      /* Product: '<S256>/Divide3' incorporates:
       *  Gain: '<S302>/Gain1'
       */
      rtb_Divide3_j = rtb_LL_HdAgPrvwT_C * rtb_LL_ThresDet_lDvtThresUprLDW;

      /* Gain: '<S256>/kph to mps' */
      rtb_kphtomps_m = rtb_Abs_b_tmp;

      /* MATLAB Function: '<S256>/Saturable Gain Lut (SatGainLut)' */
      LKAS_SaturableGainLutSatGainLut(rtb_ESC_VehSpd,
        rtb_LL_LFClb_TFC_KpVehSpdLwr_C, rtb_LL_LFClb_TFC_KpVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KpV1_C, rtb_LL_LFClb_TFC_KpV2_C, &rtb_Gain_k);

      /* Switch: '<S677>/Switch32' incorporates:
       *  Constant: '<S677>/LL_LFClb_TFC_PrvwT_C=2'
       */
      if (LKAS_ConstB.DataTypeConversion15_n != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_n;
      } else {
        x10 = LL_LFClb_TFC_PrvwT_C;
      }

      /* End of Switch: '<S677>/Switch32' */

      /* Product: '<S256>/Divide1' */
      rtb_LftTTLC = x10 * rtb_kphtomps_m;

      /* Switch: '<S677>/Switch30' incorporates:
       *  Constant: '<S677>/LL_LFClb_TFC_KpKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_m != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_m;
      } else {
        x10 = LL_LFClb_TFC_KpKlat_C;
      }

      /* End of Switch: '<S677>/Switch30' */

      /* Saturate: '<S256>/Saturation' */
      if (rtb_LftTTLC > 40.0F) {
        rtb_LftTTLC = 40.0F;
      } else {
        if (rtb_LftTTLC < 5.0F) {
          rtb_LftTTLC = 5.0F;
        }
      }

      /* End of Saturate: '<S256>/Saturation' */

      /* Sum: '<S256>/Subtract2' incorporates:
       *  Sum: '<S256>/Add1'
       */
      rtb_LL_HdAgPrvwT_C = rtb_Add1_my - rtb_Divide3_j;

      /* Product: '<S256>/Product4' incorporates:
       *  Gain: '<S303>/Gain1'
       *  Product: '<S256>/Divide'
       *  Product: '<S256>/Product1'
       *  Sum: '<S256>/Subtract1'
       *  Sum: '<S256>/Subtract2'
       *  Sum: '<S303>/Add1'
       */
      rtb_L0_C3 = (((((rtb_Add_ohd + rtb_Add_k) * 0.5F) / rtb_LftTTLC) * x10) -
                   rtb_LL_HdAgPrvwT_C) * rtb_Gain_k;

      /* Switch: '<S677>/Switch19' incorporates:
       *  Constant: '<S677>/LL_LFClb_TFC_Kp_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion26_c != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion26_c;
      } else {
        x10 = LL_LFClb_TFC_Kp_C;
      }

      /* End of Switch: '<S677>/Switch19' */

      /* Product: '<S256>/Product2' */
      rtb_Merge_a = rtb_L0_C3 * x10;

      /* Saturate: '<S256>/Saturation2' */
      if (rtb_Merge_a > 360.0F) {
        rtb_Merge_a = 360.0F;
      } else {
        if (rtb_Merge_a < (-360.0F)) {
          rtb_Merge_a = (-360.0F);
        }
      }

      /* End of Saturate: '<S256>/Saturation2' */

      /* Abs: '<S256>/Abs' incorporates:
       *  Gain: '<S302>/Gain1'
       */
      rtb_LftTTLC = fabsf(rtb_LL_ThresDet_lDvtThresUprLDW);

      /* Saturate: '<S256>/Saturation1' */
      if (rtb_LftTTLC > 0.004F) {
        rtb_LftTTLC = 0.004F;
      } else {
        if (rtb_LftTTLC < 1.0E-5F) {
          rtb_LftTTLC = 1.0E-5F;
        }
      }

      /* End of Saturate: '<S256>/Saturation1' */

      /* Switch: '<S677>/Switch39' incorporates:
       *  Constant: '<S677>/LL_LFClb_TFC_KiMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_KiMaxSWA_C;
      }

      /* End of Switch: '<S677>/Switch39' */

      /* Sum: '<S256>/Add3' incorporates:
       *  Constant: '<S256>/Constant3'
       *  Constant: '<S256>/Constant4'
       *  Product: '<S256>/Divide4'
       *  Sum: '<S256>/Add5'
       */
      rtb_L0_C1_h5 = (((x10 - 1.0F) * rtb_LftTTLC) / 0.004F) + 1.0F;

      /* Sum: '<S264>/Add2' incorporates:
       *  Memory: '<S264>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_d;

      /* Saturate: '<S264>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_jf = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_jf = 0.0F;
      } else {
        rtb_Saturation_jf = rtb_LftTTLC;
      }

      /* End of Saturate: '<S264>/Saturation' */

      /* Switch: '<S256>/Switch2' incorporates:
       *  Product: '<S256>/Divide2'
       *  Sum: '<S256>/Add'
       *  Sum: '<S256>/Add2'
       *  Switch: '<S677>/Switch40'
       *  UnitDelay: '<S256>/Unit Delay'
       */
      if ((rtb_Saturation_jf - rtb_Saturation6) >= 0.0F) {
        /* Switch: '<S677>/Switch40' incorporates:
         *  Constant: '<S677>/LL_LFClb_TFC_Ki_C=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_px = (rtb_L0_C3 * x10) + LKAS_DW.UnitDelay_DSTATE_p;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S677>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S677>/Switch40' incorporates:
           *  Constant: '<S677>/LL_LFClb_TFC_Ki_C=0.01'
           */
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_px = rtb_L0_C3 * x10;
      }

      /* End of Switch: '<S256>/Switch2' */

      /* Gain: '<S256>/Gain' */
      rtb_L0_C3 = (-1.0F) * rtb_L0_C1_h5;

      /* Switch: '<S261>/Switch' incorporates:
       *  RelationalOperator: '<S261>/UpperRelop'
       */
      if (rtb_Switch2_px < rtb_L0_C3) {
        rtb_Switch_mj = rtb_L0_C3;
      } else {
        rtb_Switch_mj = rtb_Switch2_px;
      }

      /* End of Switch: '<S261>/Switch' */

      /* Switch: '<S261>/Switch2' incorporates:
       *  RelationalOperator: '<S261>/LowerRelop1'
       */
      if (rtb_Switch2_px > rtb_L0_C1_h5) {
        rtb_Switch2_f = rtb_L0_C1_h5;
      } else {
        rtb_Switch2_f = rtb_Switch_mj;
      }

      /* End of Switch: '<S261>/Switch2' */

      /* Product: '<S156>/Divide1' incorporates:
       *  Sum: '<S156>/Add3'
       */
      rtb_L0_C1_c = (rtb_Merge_a + rtb_Switch2_f) * rtb_Gain2_i;

      /* Switch: '<S677>/Switch49' incorporates:
       *  Constant: '<S677>/LL_LFClb_TFC_KdMaxSWA_C=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_KdMaxSWA_C;
      }

      /* End of Switch: '<S677>/Switch49' */

      /* Product: '<S256>/Divide8' incorporates:
       *  Constant: '<S256>/Constant7'
       *  Constant: '<S256>/Constant8'
       *  Sum: '<S256>/Add4'
       */
      rtb_L0_C1_h5 = ((180.0F - rtb_kphtomps_m) * x10) / 120.0F;

      /* MATLAB Function: '<S256>/Saturable Gain Lut (SatGainLut)1' */
      LKAS_SaturableGainLutSatGainLut(rtb_kphtomps_m,
        rtb_LL_LFClb_TFC_KdVehSpdLwr_C, rtb_LL_LFClb_TFC_KdVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KdV1_C, rtb_LL_LFClb_TFC_KdV2_C, &rtb_Gain_k);

      /* Product: '<S263>/Divide1' incorporates:
       *  Constant: '<S263>/Constant3'
       *  Sum: '<S263>/Add4'
       */
      rtb_Merge_a = (1.0F + rtb_LL_LFClb_TFC_KdBalance_C) * rtb_Gain_k;

      /* Gain: '<S263>/Gain' incorporates:
       *  Abs: '<S263>/Abs'
       */
      rtb_L0_C3 = fabsf(rtb_L0_C3_i) * 0.5F;

      /* Gain: '<S263>/Gain1' incorporates:
       *  Sum: '<S263>/Add2'
       */
      rtb_Gain1_as = (rtb_L0_C0_c + rtb_R0_C0_j) * 0.5F;

      /* Gain: '<S263>/Gain2' */
      rtb_Gain2_i = (-1.0F) * rtb_L0_C3;

      /* Switch: '<S268>/Switch' incorporates:
       *  RelationalOperator: '<S268>/UpperRelop'
       */
      if (rtb_Gain1_as < rtb_Gain2_i) {
        rtb_Switch_gg = rtb_Gain2_i;
      } else {
        rtb_Switch_gg = rtb_Gain1_as;
      }

      /* End of Switch: '<S268>/Switch' */

      /* Switch: '<S268>/Switch2' incorporates:
       *  RelationalOperator: '<S268>/LowerRelop1'
       */
      if (rtb_Gain1_as > rtb_L0_C3) {
        rtb_Switch2_fq = rtb_L0_C3;
      } else {
        rtb_Switch2_fq = rtb_Switch_gg;
      }

      /* End of Switch: '<S268>/Switch2' */

      /* Product: '<S263>/Divide4' */
      rtb_L0_C3 = (rtb_Switch2_fq / rtb_L0_C3) * rtb_LL_LFClb_TFC_KdBalance_C;

      /* Product: '<S263>/Divide5' incorporates:
       *  Constant: '<S263>/Constant2'
       *  Sum: '<S263>/Add5'
       */
      rtb_Divide5_a = (1.0F + rtb_L0_C3) * rtb_Gain_k;

      /* Product: '<S263>/Divide2' incorporates:
       *  Constant: '<S263>/Constant2'
       *  Sum: '<S263>/Add1'
       */
      rtb_Divide2_jb = (1.0F - rtb_L0_C3) * rtb_Gain_k;

      /* Sum: '<S270>/Add' incorporates:
       *  Constant: '<S270>/Constant'
       *  Memory: '<S270>/Memory'
       */
      rtb_Saturation_b = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_bd));

      /* Saturate: '<S270>/Saturation1' */
      if (rtb_Saturation_b < ((uint16)10000U)) {
        rtb_Saturation1_n1 = rtb_Saturation_b;
      } else {
        rtb_Saturation1_n1 = ((uint16)10000U);
      }

      /* End of Saturate: '<S270>/Saturation1' */

      /* If: '<S270>/If' incorporates:
       *  Constant: '<S270>/Constant2'
       *  DataTypeConversion: '<S141>/Cast To Single'
       *  Inport: '<S271>/In'
       */
      if (rtb_Saturation1_n1 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S270>/if action ' incorporates:
         *  ActionPort: '<S271>/Action Port'
         */
        LKAS_DW.In_d = LKAS_DW.stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S270>/if action ' */
      }

      /* End of If: '<S270>/If' */

      /* If: '<S263>/If' incorporates:
       *  Inport: '<S267>/In1'
       */
      if (((sint32)LKAS_DW.In_d) == 1) {
        /* Outputs for IfAction SubSystem: '<S263>/If Action Subsystem' incorporates:
         *  ActionPort: '<S265>/Action Port'
         */
        LKAS_IfActionSubsystem_d(rtb_Divide2_jb, &rtb_Merge_p);

        /* End of Outputs for SubSystem: '<S263>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_d) == 2) {
        /* Outputs for IfAction SubSystem: '<S263>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S266>/Action Port'
         */
        LKAS_IfActionSubsystem_d(rtb_Divide5_a, &rtb_Merge_p);

        /* End of Outputs for SubSystem: '<S263>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S263>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S267>/Action Port'
         */
        rtb_Merge_p = rtb_Gain_k;

        /* End of Outputs for SubSystem: '<S263>/If Action Subsystem2' */
      }

      /* End of If: '<S263>/If' */

      /* Product: '<S263>/Divide3' incorporates:
       *  Constant: '<S263>/Constant1'
       *  Sum: '<S263>/Add3'
       */
      rtb_L0_C3 = (1.0F - rtb_LL_LFClb_TFC_KdBalance_C) * rtb_Gain_k;

      /* Switch: '<S269>/Switch' incorporates:
       *  RelationalOperator: '<S269>/UpperRelop'
       */
      if (rtb_Merge_p < rtb_L0_C3) {
        rtb_Switch_o = rtb_L0_C3;
      } else {
        rtb_Switch_o = rtb_Merge_p;
      }

      /* End of Switch: '<S269>/Switch' */

      /* Switch: '<S269>/Switch2' incorporates:
       *  RelationalOperator: '<S269>/LowerRelop1'
       */
      if (rtb_Merge_p > rtb_Merge_a) {
        rtb_Switch2_k2 = rtb_Merge_a;
      } else {
        rtb_Switch2_k2 = rtb_Switch_o;
      }

      /* End of Switch: '<S269>/Switch2' */

      /* Product: '<S256>/Divide7' incorporates:
       *  Gain: '<S256>/Gain1'
       */
      rtb_Divide7 = (rtb_LL_HdAgPrvwT_C * (-1.0F)) * rtb_Switch2_k2;

      /* Gain: '<S256>/Gain3' */
      rtb_Merge_a = (-1.0F) * rtb_L0_C1_h5;

      /* Switch: '<S262>/Switch' incorporates:
       *  RelationalOperator: '<S262>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_Merge_a) {
        rtb_Switch_g1 = rtb_Merge_a;
      } else {
        rtb_Switch_g1 = rtb_Divide7;
      }

      /* End of Switch: '<S262>/Switch' */

      /* Switch: '<S262>/Switch2' incorporates:
       *  RelationalOperator: '<S262>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_L0_C1_h5) {
        rtb_Switch2_oo = rtb_L0_C1_h5;
      } else {
        rtb_Switch2_oo = rtb_Switch_g1;
      }

      /* End of Switch: '<S262>/Switch2' */

      /* Sum: '<S156>/Add1' */
      rtb_R0_C0_j = rtb_Saturation_oq - LKAS_DW.Merge_a;

      /* Product: '<S156>/Divide4' */
      rtb_LftTTLC = rtb_R0_C0_j / rtb_LL_LKASWASyn_M0;
      rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_R0_C0_j / rtb_LL_LKASWASyn_M0;

      /* Product: '<S276>/Divide' */
      rtb_LL_LKASWASyn_M0 = rtb_LL_LKAExPrcs_tiExitTime2;

      /* Saturate: '<S276>/Saturation4' */
      if (rtb_LL_LKAExPrcs_tiExitTime2 > 1.0F) {
        rtb_LL_LKASWASyn_M0 = 1.0F;
      } else {
        if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
          rtb_LL_LKASWASyn_M0 = 0.0F;
        }
      }

      /* End of Saturate: '<S276>/Saturation4' */

      /* Saturate: '<S156>/Saturation3' */
      if (rtb_Merge > 0.004F) {
        rtb_Merge_a = 0.004F;
      } else if (rtb_Merge < (-0.004F)) {
        rtb_Merge_a = (-0.004F);
      } else {
        rtb_Merge_a = rtb_Merge;
      }

      /* End of Saturate: '<S156>/Saturation3' */

      /* Sum: '<S274>/Add2' incorporates:
       *  Constant: '<S274>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S274>/Memory3'
       */
      rtb_R0_C0_j = 1.0F + LKAS_DW.Memory3_PreviousInput_f;

      /* Saturate: '<S274>/Saturation' */
      if (rtb_R0_C0_j > 50.0F) {
        rtb_Saturation_fr = 50.0F;
      } else if (rtb_R0_C0_j < 0.0F) {
        rtb_Saturation_fr = 0.0F;
      } else {
        rtb_Saturation_fr = rtb_R0_C0_j;
      }

      /* End of Saturate: '<S274>/Saturation' */

      /* Switch: '<S274>/Switch' incorporates:
       *  Constant: '<S156>/Constant1'
       *  Constant: '<S276>/Constant1'
       *  Product: '<S156>/Divide2'
       *  Product: '<S156>/Divide5'
       *  Product: '<S156>/Divide6'
       *  Product: '<S156>/Divide7'
       *  Product: '<S274>/Divide'
       *  Product: '<S274>/Divide1'
       *  Product: '<S276>/Divide8'
       *  Sum: '<S156>/Add4'
       *  Sum: '<S156>/Add6'
       *  Sum: '<S274>/Add'
       *  Sum: '<S274>/Add1'
       *  Sum: '<S276>/Add1'
       *  UnitDelay: '<S274>/Unit Delay'
       */
      if (rtb_Saturation_fr > 30.0F) {
        /* Product: '<S156>/Divide3' */
        rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_Saturation_oq / LKAS_DW.Merge_a;

        /* Saturate: '<S156>/Saturation1' */
        if (rtb_LftTTLC > 1.0F) {
          rtb_LftTTLC = 1.0F;
        } else {
          if (rtb_LftTTLC < 0.0F) {
            rtb_LftTTLC = 0.0F;
          }
        }

        /* Saturate: '<S156>/Saturation' incorporates:
         *  Product: '<S156>/Divide3'
         */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 1.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 1.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        rtb_Switch_nb = ((((((((LKAS_DW.Merge1 + rtb_LL_LKAExPrcs_tiExitTime1) *
          rtb_LL_LKASWASyn_M1) + rtb_L0_C1_c) + (rtb_Switch2_oo * rtb_LftTTLC))
                            + (((LKAS_ConstB.Add3 * rtb_LL_LKASWASyn_M0) + 0.0F)
          * rtb_LL_LKAExPrcs_tiExitTime1)) + (LKAS_DW.DifferenceInputs2_j *
          rtb_LL_LKAExPrcs_ExitC0Dvt)) - LKAS_DW.UnitDelay_DSTATE_o) *
                         (rtb_LKA_SampleTime / 0.1F)) +
          LKAS_DW.UnitDelay_DSTATE_o;
      } else {
        /* Product: '<S156>/Divide3' */
        rtb_LKA_Veh2CamW_C = rtb_Saturation_oq / LKAS_DW.Merge_a;

        /* Saturate: '<S156>/Saturation1' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 1.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 1.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        /* Saturate: '<S156>/Saturation' incorporates:
         *  Product: '<S156>/Divide3'
         */
        if (rtb_LKA_Veh2CamW_C > 1.0F) {
          rtb_LKA_Veh2CamW_C = 1.0F;
        } else {
          if (rtb_LKA_Veh2CamW_C < 0.0F) {
            rtb_LKA_Veh2CamW_C = 0.0F;
          }
        }

        rtb_Switch_nb = (((((LKAS_DW.Merge1 + rtb_LL_LKAExPrcs_tiExitTime1) *
                            rtb_LL_LKASWASyn_M1) + rtb_L0_C1_c) +
                          (rtb_Switch2_oo * rtb_LL_LKAExPrcs_ExitC0Dvt)) +
                         (((LKAS_ConstB.Add3 * rtb_LL_LKASWASyn_M0) + 0.0F) *
                          rtb_LL_LKAExPrcs_tiExitTime1)) +
          (LKAS_DW.DifferenceInputs2_j * rtb_LKA_Veh2CamW_C);
      }

      /* End of Switch: '<S274>/Switch' */

      /* Switch: '<S677>/Switch17' incorporates:
       *  Constant: '<S677>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S677>/Switch17' */

      /* Sum: '<S153>/Add' */
      rtb_Add_ln = (rtb_Switch_nb - x10) + LKAS_DW.Saturation_m;

      /* Sum: '<S153>/Add1' */
      rtb_L0_C1_h5 = rtb_LL_LKAExPrcs_tiExitTime1 + rtb_LL_LDW_LatestWarnLine_C;

      /* Sum: '<S153>/Add2' incorporates:
       *  Gain: '<S153>/Gain2'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 += (-1.0F) * rtb_LL_LDW_LatestWarnLine_C;

      /* Switch: '<S252>/Switch' incorporates:
       *  RelationalOperator: '<S252>/UpperRelop'
       */
      if (rtb_Add_ln < rtb_LL_LKAExPrcs_tiExitTime1) {
        rtb_Switch_g3 = rtb_LL_LKAExPrcs_tiExitTime1;
      } else {
        rtb_Switch_g3 = rtb_Add_ln;
      }

      /* End of Switch: '<S252>/Switch' */

      /* Switch: '<S252>/Switch2' incorporates:
       *  RelationalOperator: '<S252>/LowerRelop1'
       */
      if (rtb_Add_ln > rtb_L0_C1_h5) {
        rtb_Switch2_do = rtb_L0_C1_h5;
      } else {
        rtb_Switch2_do = rtb_Switch_g3;
      }

      /* End of Switch: '<S252>/Switch2' */

      /* Sum: '<S251>/Add1' incorporates:
       *  Constant: '<S251>/Constant'
       *  Memory: '<S251>/Memory'
       */
      rtb_Saturation_b = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_da));

      /* Switch: '<S251>/Switch' incorporates:
       *  Constant: '<S251>/LatchTime_SY'
       *  RelationalOperator: '<S251>/Relational Operator'
       *  UnitDelay: '<S251>/Delay Input2'
       *
       * Block description for '<S251>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_b <= ((uint16)1U)) {
        rtb_L0_C1_h5 = rtb_Switch2_do;
      } else {
        rtb_L0_C1_h5 = LKAS_DW.DelayInput2_DSTATE_i;
      }

      /* End of Switch: '<S251>/Switch' */

      /* Sum: '<S251>/Difference Inputs1'
       *
       * Block description for '<S251>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_d = rtb_Switch2_do - rtb_L0_C1_h5;

      /* SampleTimeMath: '<S251>/sample time'
       *
       * About '<S251>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_Merge_a = 0.01F;

      /* Product: '<S251>/delta rise limit' incorporates:
       *  Gain: '<S153>/Gain3'
       */
      rtb_L0_C3 = (1.4F * rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_Merge_a;

      /* Product: '<S251>/delta fall limit' incorporates:
       *  Gain: '<S153>/Gain1'
       */
      rtb_Merge_a *= (-1.4F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S253>/Switch' incorporates:
       *  RelationalOperator: '<S253>/UpperRelop'
       */
      if (rtb_UkYk1_d < rtb_Merge_a) {
        rtb_Switch_ed = rtb_Merge_a;
      } else {
        rtb_Switch_ed = rtb_UkYk1_d;
      }

      /* End of Switch: '<S253>/Switch' */

      /* Switch: '<S253>/Switch2' incorporates:
       *  RelationalOperator: '<S253>/LowerRelop1'
       */
      if (rtb_UkYk1_d > rtb_L0_C3) {
        rtb_Switch2_oc = rtb_L0_C3;
      } else {
        rtb_Switch2_oc = rtb_Switch_ed;
      }

      /* End of Switch: '<S253>/Switch2' */

      /* Sum: '<S251>/Difference Inputs2'
       *
       * Block description for '<S251>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_oc + rtb_L0_C1_h5;

      /* Saturate: '<S251>/Saturation2' */
      if (rtb_Saturation_b < ((uint16)10000U)) {
        rtb_Saturation2_px = rtb_Saturation_b;
      } else {
        rtb_Saturation2_px = ((uint16)10000U);
      }

      /* End of Saturate: '<S251>/Saturation2' */

      /* DataTypeConversion: '<S154>/CastLKA3' */
      LKAS_DW.T1_Mon_g = LKAS_DW.Merge_a;

      /* If: '<S204>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S204>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S222>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_Add_ohd, &rtb_Merge_o);

        /* End of Outputs for SubSystem: '<S204>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S204>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S221>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_Add_k, &rtb_Merge_o);

        /* End of Outputs for SubSystem: '<S204>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S204>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S223>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_o);

        /* End of Outputs for SubSystem: '<S204>/If Action Subsystem3' */
      }

      /* End of If: '<S204>/If' */

      /* If: '<S206>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S206>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S228>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_phiHdAg_Lft, &rtb_Merge_i);

        /* End of Outputs for SubSystem: '<S206>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S206>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S227>/Action Port'
         */
        LKAS_IfActionSubsystem2_f(rtb_phiHdAg_Rgt, &rtb_Merge_i);

        /* End of Outputs for SubSystem: '<S206>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S206>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S229>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_i);

        /* End of Outputs for SubSystem: '<S206>/If Action Subsystem3' */
      }

      /* End of If: '<S206>/If' */

      /* DataTypeConversion: '<S246>/Data Type Conversion' incorporates:
       *  Constant: '<S247>/Constant'
       *  RelationalOperator: '<S247>/Compare'
       */
      rtb_L0_Q = (uint8)((rtb_Merge <= 0.0F) ? 1 : 0);

      /* Switch: '<S677>/Switch5' incorporates:
       *  Constant: '<S677>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_e != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_e;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S677>/Switch5' */

      /* Product: '<S246>/Divide' */
      rtb_Merge_a = (rtb_Merge * rtb_Abs_b_tmp) * x10;

      /* Abs: '<S246>/Abs1' incorporates:
       *  Abs: '<S246>/Abs'
       */
      rtb_R0_C0_j = fabsf(rtb_Merge_a);
      rtb_Abs1_bz = rtb_R0_C0_j;

      /* Abs: '<S246>/Abs' */
      rtb_Abs_c = rtb_R0_C0_j;

      /* If: '<S246>/If' incorporates:
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.stLKAActvFlg) == 1) && (((sint32)rtb_L0_Q) == 0)) {
        /* Outputs for IfAction SubSystem: '<S246>/If Action Subsystem' incorporates:
         *  ActionPort: '<S248>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_c, &rtb_Merge_a);

        /* End of Outputs for SubSystem: '<S246>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.stLKAActvFlg) == 2) && (((sint32)rtb_L0_Q) ==
                  1)) {
        /* Outputs for IfAction SubSystem: '<S246>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S250>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_bz, &rtb_Merge_a);

        /* End of Outputs for SubSystem: '<S246>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S246>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S249>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_a);

        /* End of Outputs for SubSystem: '<S246>/If Action Subsystem2' */
      }

      /* End of If: '<S246>/If' */

      /* Switch: '<S677>/Switch6' incorporates:
       *  Constant: '<S677>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_j != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_j;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S677>/Switch6' */

      /* Sum: '<S242>/Add1' incorporates:
       *  Product: '<S242>/Divide'
       *  Product: '<S242>/Divide1'
       */
      rtb_Add1_mr = (((1.0F / x10) * rtb_L0_C3_i) / rtb_Abs_b_tmp) + rtb_Merge_a;

      /* If: '<S198>/If' incorporates:
       *  Constant: '<S245>/Constant2'
       *  DataTypeConversion: '<S141>/Cast To Single'
       */
      if (((sint32)LKAS_DW.stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S198>/If Action Subsystem' incorporates:
         *  ActionPort: '<S243>/Action Port'
         */
        /* Gain: '<S243>/Gain2' */
        rtb_Merge_d = (-1.0F) * rtb_Add1_mr;

        /* End of Outputs for SubSystem: '<S198>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S198>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S244>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_mr, &rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S198>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S198>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S245>/Action Port'
         */
        rtb_Merge_d = 0.0F;

        /* End of Outputs for SubSystem: '<S198>/If Action Subsystem2' */
      }

      /* End of If: '<S198>/If' */

      /* Sum: '<S207>/Add' incorporates:
       *  Constant: '<S207>/Constant'
       *  Memory: '<S207>/Memory'
       */
      rtb_Add_h = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ni));

      /* Saturate: '<S207>/Saturation1' */
      if (rtb_Add_h < ((uint16)10000U)) {
        rtb_Saturation_b = rtb_Add_h;
      } else {
        rtb_Saturation_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S207>/Saturation1' */

      /* If: '<S207>/If' incorporates:
       *  Constant: '<S207>/Constant2'
       */
      if (rtb_Saturation_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S207>/if action ' incorporates:
         *  ActionPort: '<S230>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_d, &rtb_In_h);

        /* End of Outputs for SubSystem: '<S207>/if action ' */
      }

      /* End of If: '<S207>/If' */

      /* Sum: '<S209>/Add' incorporates:
       *  Constant: '<S209>/Constant'
       *  Memory: '<S209>/Memory'
       */
      rtb_Saturation_b = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_hk));

      /* Saturate: '<S209>/Saturation1' */
      if (rtb_Saturation_b < ((uint16)10000U)) {
        rtb_Saturation1_b = rtb_Saturation_b;
      } else {
        rtb_Saturation1_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S209>/Saturation1' */

      /* If: '<S209>/If' incorporates:
       *  Constant: '<S209>/Constant2'
       */
      if (rtb_Saturation1_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S209>/if action ' incorporates:
         *  ActionPort: '<S232>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_o, &rtb_In_i);

        /* End of Outputs for SubSystem: '<S209>/if action ' */
      }

      /* End of If: '<S209>/If' */

      /* Sum: '<S210>/Add' incorporates:
       *  Constant: '<S210>/Constant'
       *  Memory: '<S210>/Memory'
       */
      rtb_Saturation_b = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ei));

      /* Saturate: '<S210>/Saturation1' */
      if (rtb_Saturation_b < ((uint16)10000U)) {
        rtb_Saturation1_g3 = rtb_Saturation_b;
      } else {
        rtb_Saturation1_g3 = ((uint16)10000U);
      }

      /* End of Saturate: '<S210>/Saturation1' */

      /* If: '<S210>/If' incorporates:
       *  Constant: '<S210>/Constant2'
       */
      if (rtb_Saturation1_g3 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S210>/if action ' incorporates:
         *  ActionPort: '<S233>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_i, &rtb_In);

        /* End of Outputs for SubSystem: '<S210>/if action ' */
      }

      /* End of If: '<S210>/If' */

      /* DataTypeConversion: '<S195>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_ESC_VehSpd;

      /* DataTypeConversion: '<S154>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon_h = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S199>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S182>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_j) {
          /* Disable for Outport: '<S184>/Out' */
          LKAS_DW.RelationalOperator_d = false;
          LKAS_DW.SumCondition1_MODE_j = false;
        }

        /* End of Disable for SubSystem: '<S182>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S183>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_k.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_j0,
            &LKAS_DW.SumCondition1_k);
        }

        /* End of Disable for SubSystem: '<S183>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S183>/Sum Condition' */
        if (LKAS_DW.SumCondition_d.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_j4,
            &LKAS_DW.SumCondition_d);
        }

        /* End of Disable for SubSystem: '<S183>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S183>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S192>/Out' */
          LKAS_DW.RelationalOperator_js = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S183>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S158>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_m) {
          /* Disable for Outport: '<S163>/M4K' */
          LKAS_DW.Saturation3 = 1.0F;
          LKAS_DW.SumCondition2_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S158>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S150>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_h) {
          /* Disable for Outport: '<S159>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_j = 0.0F;
          LKAS_DW.Subsystem_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S150>/Subsystem' */

        /* Disable for If: '<S273>/If' */
        LKAS_DW.If_ActiveSubsystem_d = -1;

        /* Disable for Outport: '<S141>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S141>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S141>/LKA_M' */
        LKAS_DW.Switch = 0.0F;

        /* Disable for Outport: '<S141>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_m = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_h = 0.0F;
        LKAS_DW.T1_Mon_g = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon_m;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon_h;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.T1_Mon = LKAS_DW.T1_Mon_g;

    /* Switch: '<S613>/Switch1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S15>/Extract Desired Bits'
     *  Delay: '<S613>/Delay'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S624>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S625>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S626>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S627>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S628>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S629>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S630>/FixPt Bitwise Operator1'
     *  Switch: '<S613>/Switch2'
     *  Switch: '<S613>/Switch3'
     *  Switch: '<S613>/Switch4'
     *  Switch: '<S613>/Switch5'
     *  Switch: '<S613>/Switch6'
     *  Switch: '<S613>/Switch7'
     */
    if (rtb_L0_C0_g != 0.0F) {
      rtb_L0_Q = (uint8)(((((((LKAS_DW.Delay_DSTATE_p | ((uint8)1U)) | ((uint8)
        2U)) | ((uint8)4U)) | ((uint8)8U)) | ((uint8)16U)) | ((uint8)32U)) |
                         ((uint8)64U));
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~((uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)(~((uint8)
        (~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)
        (((uint8)(~LKAS_DW.Delay_DSTATE_p)) | ((uint8)1U))))))) | ((uint8)2U)))))))
        | ((uint8)4U))))))) | ((uint8)8U))))))) | ((uint8)16U))))))) | ((uint8)
        32U))))))) | ((uint8)64U))));
    }

    /* End of Switch: '<S613>/Switch1' */

    /* Switch: '<S613>/Switch8' incorporates:
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator5'
     */
    rtb_Switch8 = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)128U))));

    /* Switch: '<S614>/Switch2' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean16'
     *  DataTypeConversion: '<S39>/Extract Desired Bits'
     *  Delay: '<S614>/Delay'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S641>/FixPt Bitwise Operator1'
     *  Switch: '<S614>/Switch1'
     */
    if (rtb_L0_C0_g != 0.0F) {
      rtb_L0_Q = (uint8)(((uint8)(~((uint8)(((uint8)(~LKAS_DW.Delay_DSTATE_d)) |
        ((uint8)1U))))) | ((uint8)2U));
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_d)) | ((uint8)1U))))))) | ((uint8)2U))));
    }

    /* End of Switch: '<S614>/Switch2' */

    /* Switch: '<S614>/Switch3' incorporates:
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator5'
     */
    rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)4U))));

    /* Switch: '<S614>/Switch4' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean20'
     *  DataTypeConversion: '<S28>/Extract Desired Bits'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S643>/FixPt Bitwise Operator1'
     */
    if (rtb_L0_C0_g != 0.0F) {
      rtb_L0_Q |= ((uint8)8U);
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)8U))));
    }

    /* End of Switch: '<S614>/Switch4' */

    /* Switch: '<S614>/Switch5' incorporates:
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator5'
     */
    rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)16U))));

    /* Switch: '<S614>/Switch6' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean36'
     *  DataTypeConversion: '<S31>/Extract Desired Bits'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S645>/FixPt Bitwise Operator1'
     */
    if (rtb_L0_C0_g != 0.0F) {
      rtb_L0_Q |= ((uint8)32U);
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)32U))));
    }

    /* End of Switch: '<S614>/Switch6' */

    /* Switch: '<S614>/Switch7' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  DataTypeConversion: '<S46>/Extract Desired Bits'
     *  Delay: '<S615>/Delay'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S646>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S647>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S648>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S648>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S648>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S649>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S649>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S649>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S650>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S650>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S650>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S656>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S657>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S658>/FixPt Bitwise Operator1'
     *  Switch: '<S614>/Switch8'
     *  Switch: '<S615>/Switch1'
     *  Switch: '<S615>/Switch2'
     *  Switch: '<S615>/Switch3'
     */
    if (rtb_R0_C3 != 0.0F) {
      rtb_Switch8_p = (uint8)((rtb_L0_Q | ((uint8)64U)) | ((uint8)128U));
      rtb_L0_Q = (uint8)(((LKAS_DW.Delay_DSTATE_p3 | ((uint8)1U)) | ((uint8)2U))
                         | ((uint8)4U));
    } else {
      rtb_Switch8_p = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~rtb_L0_Q)) | ((uint8)64U))))))) | ((uint8)128U))));
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~((uint8)(~((uint8)(((uint8)(~LKAS_DW.Delay_DSTATE_p3)) | ((uint8)1U)))))))
        | ((uint8)2U))))))) | ((uint8)4U))));
    }

    /* End of Switch: '<S614>/Switch7' */

    /* Switch: '<S615>/Switch4' incorporates:
     *  S-Function (sfix_bitop): '<S651>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S651>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S651>/FixPt Bitwise Operator5'
     */
    rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)8U))));

    /* Switch: '<S615>/Switch5' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean8'
     *  DataTypeConversion: '<S64>/Extract Desired Bits'
     *  S-Function (sfix_bitop): '<S652>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S652>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S652>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S653>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S653>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S653>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S660>/FixPt Bitwise Operator1'
     *  S-Function (sfix_bitop): '<S661>/FixPt Bitwise Operator1'
     *  Switch: '<S615>/Switch6'
     */
    if (rtb_R0_C3 != 0.0F) {
      rtb_L0_Q = (uint8)((rtb_L0_Q | ((uint8)16U)) | ((uint8)32U));
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~((uint8)(~((uint8)(((uint8)
        (~rtb_L0_Q)) | ((uint8)16U))))))) | ((uint8)32U))));
    }

    /* End of Switch: '<S615>/Switch5' */

    /* Switch: '<S615>/Switch7' incorporates:
     *  S-Function (sfix_bitop): '<S654>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S654>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S654>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S662>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LDW_Fault) {
      rtb_L0_Q |= ((uint8)64U);
    } else {
      rtb_L0_Q = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)64U))));
    }

    /* End of Switch: '<S615>/Switch7' */

    /* Switch: '<S615>/Switch8' incorporates:
     *  S-Function (sfix_bitop): '<S655>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S655>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S655>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S663>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LKA_Fault) {
      rtb_Switch8_c = (uint8)(rtb_L0_Q | ((uint8)128U));
    } else {
      rtb_Switch8_c = (uint8)(~((uint8)(((uint8)(~rtb_L0_Q)) | ((uint8)128U))));
    }

    /* End of Switch: '<S615>/Switch8' */

    /* Sum: '<S610>/Add' incorporates:
     *  ArithShift: '<S610>/Shift Arithmetic'
     *  ArithShift: '<S610>/Shift Arithmetic1'
     *  DataTypeConversion: '<S610>/Data Type Conversion'
     *  DataTypeConversion: '<S610>/Data Type Conversion1'
     *  DataTypeConversion: '<S610>/Data Type Conversion2'
     */
    rtb_Add = ((((uint32)rtb_Switch8_p) << 8) + ((uint32)rtb_Switch8)) +
      (((uint32)rtb_Switch8_c) << 16);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Fault_Reason = rtb_Add;

    /* DataTypeConversion: '<S349>/Cast2' */
    ob_LKA_Fault_Reason = rtb_Add;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Switch;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_State_Mon = LKAS_DW.stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LDW_State_Mon = LKAS_DW.stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S140>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S145>/If' */
      if (((sint32)LKAS_DW.stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S145>/If Action Subsystem' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        /* Gain: '<S146>/rad to deg' incorporates:
         *  Gain: '<S146>/Gain'
         */
        LKAS_DW.Merge_p = ((-1.0F) * rtb_phiHdAg_Lft) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S145>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S145>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        /* Gain: '<S147>/rad to deg' */
        LKAS_DW.Merge_p = 57.2957802F * rtb_phiHdAg_Rgt;

        /* End of Outputs for SubSystem: '<S145>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S145>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_p);

        /* End of Outputs for SubSystem: '<S145>/If Action Subsystem2' */
      }

      /* End of If: '<S145>/If' */

      /* Switch: '<S676>/Switch2' incorporates:
       *  Constant: '<S676>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_h;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S676>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S145>/Sum Condition' incorporates:
       *  EnablePort: '<S149>/Enable'
       */
      /* RelationalOperator: '<S145>/Relational Operator' */
      if (LKAS_DW.Merge_p >= x10) {
        if (!LKAS_DW.SumCondition_MODE_g) {
          /* InitializeConditions for Memory: '<S149>/Memory' */
          LKAS_DW.Memory_PreviousInput_lr = 0.0F;
          LKAS_DW.SumCondition_MODE_g = true;
        }

        /* Sum: '<S149>/Add1' incorporates:
         *  Memory: '<S149>/Memory'
         */
        rtb_R0_C0_j = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_lr;

        /* Saturate: '<S149>/Saturation' */
        if (rtb_R0_C0_j > 0.6F) {
          rtb_R0_C0_j = 0.6F;
        } else {
          if (rtb_R0_C0_j < 0.0F) {
            rtb_R0_C0_j = 0.0F;
          }
        }

        /* End of Saturate: '<S149>/Saturation' */

        /* RelationalOperator: '<S149>/Relational Operator' incorporates:
         *  Constant: '<S145>/Constant'
         */
        LKAS_DW.RelationalOperator_oy = (rtb_R0_C0_j >= 0.05F);

        /* Update for Memory: '<S149>/Memory' */
        LKAS_DW.Memory_PreviousInput_lr = rtb_R0_C0_j;
      } else {
        if (LKAS_DW.SumCondition_MODE_g) {
          /* Disable for Outport: '<S149>/Out' */
          LKAS_DW.RelationalOperator_oy = false;
          LKAS_DW.SumCondition_MODE_g = false;
        }
      }

      /* End of RelationalOperator: '<S145>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S145>/Sum Condition' */

      /* Product: '<S140>/Product' incorporates:
       *  Logic: '<S140>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_oy) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S145>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_g) {
          /* Disable for Outport: '<S149>/Out' */
          LKAS_DW.RelationalOperator_oy = false;
          LKAS_DW.SumCondition_MODE_g = false;
        }

        /* End of Disable for SubSystem: '<S145>/Sum Condition' */

        /* Disable for Outport: '<S140>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* If: '<S477>/If' incorporates:
     *  Constant: '<S483>/Constant'
     *  Delay: '<S143>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_FDMMve_d_LkaFcnConf) != 1)) {
      /* Outputs for IfAction SubSystem: '<S477>/If Action Subsystem' incorporates:
       *  ActionPort: '<S481>/Action Port'
       */
      LKAS_IfActionSubsystem_fo(&rtb_Merge_dz);

      /* End of Outputs for SubSystem: '<S477>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_FDMMve_d_LkaFcnConf) != 3)) {
      /* Outputs for IfAction SubSystem: '<S477>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S482>/Action Port'
       */
      LKAS_IfActionSubsystem_fo(&rtb_Merge_dz);

      /* End of Outputs for SubSystem: '<S477>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S477>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S483>/Action Port'
       */
      rtb_Merge_dz = false;

      /* End of Outputs for SubSystem: '<S477>/If Action Subsystem3' */
    }

    /* End of If: '<S477>/If' */

    /* Outputs for Enabled SubSystem: '<S477>/Sum Condition1' */
    LKAS_SumCondition1(rtb_Merge_dz, rtb_LKA_SampleTime,
                       rtb_LL_MAX_DELAY_EPSSTAR_TIME,
                       &LKAS_DW.RelationalOperator, &LKAS_DW.SumCondition1_jk);

    /* End of Outputs for SubSystem: '<S477>/Sum Condition1' */

    /* SignalConversion: '<S536>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S448>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LogicalOperator_fs;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_Compare_nvo;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_Compare_o3;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_hu;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_mws;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_g;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_j2;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_pe;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_o;
    rtb_TmpSignalConversionAtSFunct[12] = rtb_stDvrTkConFlg_n;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_LogicalOperator_kx;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_aq;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_BCM_Left_Light;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge_n;

    /* MATLAB Function: '<S448>/Disable Reason' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S536>:1' */
    /* '<S536>:1:2' y = single(0); */
    rtb_R0_C0_j = 0.0F;

    /* '<S536>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S536>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S536>:1:5' y = single(i); */
        rtb_R0_C0_j = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Disable_Reason = rtb_R0_C0_j;

    /* DataTypeConversion: '<S349>/Cast' */
    ob_LKA_Disable_Reason = rtb_R0_C0_j;

    /* RelationalOperator: '<S487>/Compare' incorporates:
     *  Constant: '<S487>/Constant'
     */
    rtb_Compare_ff = (LKAS_DW.RelationalOperator == true);

    /* DataTypeConversion: '<S349>/Cast1' */
    ob_LKA_LKADeactvCSyn = (float32)(LKAS_DW.Merge1_c ? 1.0F : 0.0F);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LFTTTLC_Mon = rtb_LFTTTLC;

    /* Gain: '<S300>/Gain' incorporates:
     *  Sum: '<S300>/Add4'
     */
    rtb_phiHdAg = (rtb_phiHdAg_Lft + rtb_phiHdAg_Rgt) * 0.5F;

    /* Logic: '<S572>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S572>/Relational Operator3'
     *  RelationalOperator: '<S572>/Relational Operator4'
     */
    rtb_LogicalOperator1_f = ((rtb_Gain1 <= rtb_LL_LKA_LatestWarnLine_C) ||
      (rtb_Add5_g <= rtb_LL_LKA_LatestWarnLine_C));

    /* Gain: '<S299>/Gain' incorporates:
     *  Sum: '<S299>/Add'
     */
    rtb_lDvt = (rtb_Gain1 + rtb_Add5_g) * 0.5F;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_Mode = LKAS_DW.LKA_Mode_k;

    /* Gain: '<S298>/Gain' incorporates:
     *  Sum: '<S298>/Add'
     */
    rtb_crCrvt = (rtb_L0_C2_f + rtb_R0_C2_b) * 0.5F;

    /* Delay: '<S143>/Delay1' */
    rtb_LKA_Mode = LKAS_DW.Delay1_2_DSTATE;
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S456>/ExitCount1' */
      if (LKAS_DW.ExitCount1.ExitCount_MODE) {
        LKAS_ExitCount_Disable(&LKAS_DW.RelationalOperator_j,
          &LKAS_DW.ExitCount1);
      }

      /* End of Disable for SubSystem: '<S456>/ExitCount1' */

      /* Disable for Enabled SubSystem: '<S456>/ExitCount' */
      if (LKAS_DW.ExitCount.ExitCount_MODE) {
        LKAS_ExitCount_Disable(&LKAS_DW.RelationalOperator_o, &LKAS_DW.ExitCount);
      }

      /* End of Disable for SubSystem: '<S456>/ExitCount' */

      /* Disable for Enabled SubSystem: '<S457>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S467>/Out' */
        LKAS_DW.RelationalOperator_m = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Disable for SubSystem: '<S457>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S468>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S472>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S468>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S395>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S426>/Out' */
        LKAS_DW.RelationalOperator_oi = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S395>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S395>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S425>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S395>/Count' */

      /* Disable for Enabled SubSystem: '<S428>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S434>/Out' */
        LKAS_DW.RelationalOperator_p = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }

      /* End of Disable for SubSystem: '<S428>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S396>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_l) {
        /* Disable for Outport: '<S440>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_l = false;
      }

      /* End of Disable for SubSystem: '<S396>/Sum Condition1' */

      /* Disable for If: '<S443>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S406>/Sum Condition' */
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S412>/Out' */
        LKAS_DW.RelationalOperator_g = false;
        LKAS_DW.SumCondition_MODE = false;
      }

      /* End of Disable for SubSystem: '<S406>/Sum Condition' */

      /* Disable for Enabled SubSystem: '<S331>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_f) {
        /* Disable for Outport: '<S335>/Out' */
        LKAS_DW.RelationalOperator_pz = false;
        LKAS_DW.Subsystem_MODE_f = false;
      }

      /* End of Disable for SubSystem: '<S331>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S199>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S182>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_j) {
          /* Disable for Outport: '<S184>/Out' */
          LKAS_DW.RelationalOperator_d = false;
          LKAS_DW.SumCondition1_MODE_j = false;
        }

        /* End of Disable for SubSystem: '<S182>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S183>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_k.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_j0,
            &LKAS_DW.SumCondition1_k);
        }

        /* End of Disable for SubSystem: '<S183>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S183>/Sum Condition' */
        if (LKAS_DW.SumCondition_d.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_j4,
            &LKAS_DW.SumCondition_d);
        }

        /* End of Disable for SubSystem: '<S183>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S183>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S192>/Out' */
          LKAS_DW.RelationalOperator_js = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S183>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S158>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_m) {
          /* Disable for Outport: '<S163>/M4K' */
          LKAS_DW.Saturation3 = 1.0F;
          LKAS_DW.SumCondition2_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S158>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S150>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_h) {
          /* Disable for Outport: '<S159>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_j = 0.0F;
          LKAS_DW.Subsystem_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S150>/Subsystem' */

        /* Disable for If: '<S273>/If' */
        LKAS_DW.If_ActiveSubsystem_d = -1;

        /* Disable for Outport: '<S141>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S141>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S141>/LKA_M' */
        LKAS_DW.Switch = 0.0F;

        /* Disable for Outport: '<S141>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_m = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_h = 0.0F;
        LKAS_DW.T1_Mon_g = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S145>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_g) {
          /* Disable for Outport: '<S149>/Out' */
          LKAS_DW.RelationalOperator_oy = false;
          LKAS_DW.SumCondition_MODE_g = false;
        }

        /* End of Disable for SubSystem: '<S145>/Sum Condition' */

        /* Disable for Outport: '<S140>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Enabled SubSystem: '<S477>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_jk.SumCondition1_MODE) {
        LKAS_SumCondition1_Disable(&LKAS_DW.RelationalOperator,
          &LKAS_DW.SumCondition1_jk);
      }

      /* End of Disable for SubSystem: '<S477>/Sum Condition1' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.LKA_Mode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MATLAB Function: '<S8>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S111>/Switch'
   *  Switch: '<S111>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S89>:1' */
  /* '<S89>:1:2' if stDACmode==1 */
  if (((sint32)LKAS_DW.LKA_Mode) == 1) {
    /* '<S89>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_IMAPve_d_LKA_Mode)
          != 3)) || (((sint32)rtb_R0_Q_c) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_IMAPve_d_LKA_Mode)
            != 3)) && (((sint32)rtb_R0_Q_c) == 3)) {
        /* '<S89>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:6' Vehicle_Lane_Display=uint8(4); */
        rtb_IMAPve_d_LKA_Mode = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:8' Vehicle_Lane_Display=uint8(5); */
        rtb_IMAPve_d_LKA_Mode = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) != 3))
      {
        /* '<S89>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S89>:1:10' Vehicle_Lane_Display=uint8(10); */
        rtb_IMAPve_d_LKA_Mode = 10U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) != 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:12' Vehicle_Lane_Display=uint8(11); */
        rtb_IMAPve_d_LKA_Mode = 11U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:14' Vehicle_Lane_Display=uint8(12); */
        rtb_IMAPve_d_LKA_Mode = 12U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:16' Vehicle_Lane_Display=uint8(13); */
        rtb_IMAPve_d_LKA_Mode = 13U;
      } else {
        /* '<S89>:1:17' else */
        /* '<S89>:1:18' Vehicle_Lane_Display=uint8(1); */
        rtb_IMAPve_d_LKA_Mode = 1U;
      }
    } else {
      /* '<S89>:1:4' Vehicle_Lane_Display=uint8(3); */
    }
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
              3)) {
    /* '<S89>:1:20' elseif stDACmode==2 || stDACmode==3 */
    /* '<S89>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_IMAPve_d_LKA_Mode)
          != 3)) || (((sint32)rtb_R0_Q_c) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_IMAPve_d_LKA_Mode)
            != 3)) && (((sint32)rtb_R0_Q_c) == 3)) {
        /* '<S89>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:24' Vehicle_Lane_Display=uint8(4); */
        rtb_IMAPve_d_LKA_Mode = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:26' Vehicle_Lane_Display=uint8(5); */
        rtb_IMAPve_d_LKA_Mode = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) != 3))
      {
        /* '<S89>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S89>:1:28' Vehicle_Lane_Display=uint8(6); */
        rtb_IMAPve_d_LKA_Mode = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) != 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:30' Vehicle_Lane_Display=uint8(7); */
        rtb_IMAPve_d_LKA_Mode = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:32' Vehicle_Lane_Display=uint8(8); */
        rtb_IMAPve_d_LKA_Mode = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)
                    rtb_IMAPve_d_LKA_Mode) == 3)) && (((sint32)rtb_R0_Q_c) == 3))
      {
        /* '<S89>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:34' Vehicle_Lane_Display=uint8(9); */
        rtb_IMAPve_d_LKA_Mode = 9U;
      } else {
        /* '<S89>:1:35' else */
        /* '<S89>:1:36' Vehicle_Lane_Display=uint8(1); */
        rtb_IMAPve_d_LKA_Mode = 1U;
      }
    } else {
      /* '<S89>:1:22' Vehicle_Lane_Display=uint8(3); */
    }
  } else {
    /* '<S89>:1:38' else */
    /* '<S89>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_IMAPve_d_LKA_Mode = 0U;
  }

  /* End of MATLAB Function: '<S8>/Vehicle_Lane_Display' */

  /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S11>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_R0_Q_c = ((uint8)1U);
    break;

   case 1:
    rtb_R0_Q_c = ((uint8)1U);
    break;

   case 2:
    rtb_R0_Q_c = ((uint8)2U);
    break;

   case 3:
    rtb_R0_Q_c = ((uint8)3U);
    break;

   case 4:
    rtb_R0_Q_c = ((uint8)4U);
    break;

   case 5:
    rtb_R0_Q_c = ((uint8)4U);
    break;

   default:
    rtb_R0_Q_c = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S11>/Multiport Switch' */

  /* RelationalOperator: '<S665>/Compare' incorporates:
   *  Constant: '<S665>/Constant'
   */
  rtb_Merge_n = (rtb_R0_Q_c == ((uint8)4U));

  /* Switch: '<S11>/Switch1' incorporates:
   *  Constant: '<S11>/1'
   *  Constant: '<S11>/x0'
   */
  if (rtb_Merge_n) {
    rtb_L0_Q = ((uint8)1U);
  } else {
    rtb_L0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S664>/Subsystem' incorporates:
   *  EnablePort: '<S672>/Enable'
   */
  if (((sint32)rtb_L0_Q) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S672>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S672>/Add' */
    rtb_L0_C2_f = LKAS_DW.OutputSWACmd - rtb_SW_Angle;

    /* Sum: '<S672>/Add1' incorporates:
     *  Constant: '<S672>/Ki'
     *  Delay: '<S672>/Delay1'
     *  Product: '<S672>/Product2'
     */
    rtb_R0_C0_j = (rtb_L0_C2_f * 0.0005F) + LKAS_DW.Delay1_DSTATE;

    /* Saturate: '<S672>/Saturation' */
    if (rtb_R0_C0_j > 0.5F) {
      rtb_R0_C0_j = 0.5F;
    } else {
      if (rtb_R0_C0_j < (-0.5F)) {
        rtb_R0_C0_j = (-0.5F);
      }
    }

    /* End of Saturate: '<S672>/Saturation' */

    /* Fcn: '<S672>/Fcn' */
    rtb_R0_C2_b = LKAS_DW.OutputSWACmd * LKAS_DW.OutputSWACmd;

    /* Sum: '<S672>/Add2' incorporates:
     *  Constant: '<S672>/Kp'
     *  Fcn: '<S672>/Fcn'
     *  Product: '<S672>/Product1'
     */
    LKAS_DW.in_trq = (((((rtb_R0_C2_b * LKAS_DW.OutputSWACmd) * 2.0e-6F) +
                        (rtb_R0_C2_b * -0.0005F)) + (LKAS_DW.OutputSWACmd *
      0.0505F)) + (rtb_L0_C2_f * 0.02F)) + rtb_R0_C0_j;

    /* Update for Delay: '<S672>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_R0_C0_j;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S672>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S664>/Subsystem' */

  /* Sum: '<S670>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S670>/Delay Input2'
   *
   * Block description for '<S670>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S670>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2_f = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S670>/delta rise limit' incorporates:
   *  Constant: '<S664>/Constant'
   *  SampleTimeMath: '<S670>/sample time'
   *
   * About '<S670>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_R0_C0_j = 5.0F * 0.01F;

  /* Product: '<S670>/delta fall limit' incorporates:
   *  Constant: '<S664>/Constant1'
   *  SampleTimeMath: '<S670>/sample time'
   *
   * About '<S670>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_R0_C2_b = (-5.0F) * 0.01F;

  /* Switch: '<S673>/Switch2' incorporates:
   *  Product: '<S670>/delta fall limit'
   *  RelationalOperator: '<S673>/LowerRelop1'
   *  RelationalOperator: '<S673>/UpperRelop'
   *  Switch: '<S673>/Switch'
   */
  if (rtb_L0_C2_f > rtb_R0_C0_j) {
    rtb_L0_C2_f = rtb_R0_C0_j;
  } else {
    if (rtb_L0_C2_f < rtb_R0_C2_b) {
      /* Switch: '<S673>/Switch' incorporates:
       *  Product: '<S670>/delta fall limit'
       */
      rtb_L0_C2_f = rtb_R0_C2_b;
    }
  }

  /* End of Switch: '<S673>/Switch2' */

  /* Sum: '<S670>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S670>/Delay Input2'
   *
   * Block description for '<S670>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S670>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2_f += LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S669>/delta rise limit' incorporates:
   *  Constant: '<S11>/Constant7'
   *  SampleTimeMath: '<S669>/sample time'
   *
   * About '<S669>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_R0_C0_j = 5.0F * 0.01F;

  /* Sum: '<S669>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S669>/Delay Input2'
   *
   * Block description for '<S669>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S669>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_R0_C2_b = LKAS_DW.OutputM - LKAS_DW.DelayInput2_DSTATE_f;

  /* Product: '<S669>/delta fall limit' incorporates:
   *  Constant: '<S11>/Constant8'
   *  SampleTimeMath: '<S669>/sample time'
   *
   * About '<S669>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C0_c = (-5.0F) * 0.01F;

  /* Switch: '<S674>/Switch2' incorporates:
   *  Product: '<S669>/delta fall limit'
   *  RelationalOperator: '<S674>/LowerRelop1'
   *  RelationalOperator: '<S674>/UpperRelop'
   *  Switch: '<S674>/Switch'
   */
  if (rtb_R0_C2_b > rtb_R0_C0_j) {
    rtb_R0_C2_b = rtb_R0_C0_j;
  } else {
    if (rtb_R0_C2_b < rtb_L0_C0_c) {
      /* Switch: '<S674>/Switch' incorporates:
       *  Product: '<S669>/delta fall limit'
       */
      rtb_R0_C2_b = rtb_L0_C0_c;
    }
  }

  /* End of Switch: '<S674>/Switch2' */

  /* Sum: '<S669>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S669>/Delay Input2'
   *
   * Block description for '<S669>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S669>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_R0_C0_j = rtb_R0_C2_b + LKAS_DW.DelayInput2_DSTATE_f;

  /* MATLAB Function: '<S8>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S85>:1' */
  /* '<S85>:1:2' if  LKA_Mode==1 && (LDW_Warn_Mode==0 || LDW_Warn_Mode==2) */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && ((((sint32)rtb_IMAPve_d_LDW_Warn_Mode)
        == 0) || (((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 2))) {
    /* '<S85>:1:3' if LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S85>:1:4' LDW_Flag=uint8(1); */
      rtb_Lrg_Q = 1U;
      break;

     case 2:
      /* '<S85>:1:5' elseif LDWWarnInfo==2 */
      /* '<S85>:1:6' LDW_Flag=uint8(2); */
      rtb_Lrg_Q = 2U;
      break;

     default:
      /* '<S85>:1:7' else */
      /* '<S85>:1:8' LDW_Flag=uint8(0); */
      rtb_Lrg_Q = 0U;
      break;
    }
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)
                rtb_IMAPve_d_LDW_Warn_Mode) == 0) || (((sint32)
                rtb_IMAPve_d_LDW_Warn_Mode) == 2))) {
    /* '<S85>:1:10' elseif (LKA_Mode==2) && (LDW_Warn_Mode==0 || LDW_Warn_Mode==2) */
    /* '<S85>:1:11' if LDWWarnInfo==1 && LKA_State==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S85>:1:12' LDW_Flag=uint8(1); */
      rtb_Lrg_Q = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S85>:1:13' elseif LDWWarnInfo==2 && LKA_State==5 */
      /* '<S85>:1:14' LDW_Flag=uint8(2); */
      rtb_Lrg_Q = 2U;
    } else {
      /* '<S85>:1:15' else */
      /* '<S85>:1:16' LDW_Flag=uint8(0); */
      rtb_Lrg_Q = 0U;
    }
  } else {
    /* '<S85>:1:18' else */
    /* '<S85>:1:19' LDW_Flag=uint8(0); */
    rtb_Lrg_Q = 0U;
  }

  /* End of MATLAB Function: '<S8>/LDW_Flag' */

  /* MATLAB Function: '<S8>/HapticAlarmReq' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HapticAlarmReq': '<S84>:1' */
  /* '<S84>:1:2' if  LDW_Flag==1 && (LDW_Warn_Mode == 1 || LDW_Warn_Mode == 2) */
  if ((((sint32)rtb_Lrg_Q) == 1) && ((((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 1)
       || (((sint32)rtb_IMAPve_d_LDW_Warn_Mode) == 2))) {
    /* '<S84>:1:3' HapticAlarmReq= uint8(1); */
    rtb_IMAPve_d_LDW_Warn_Mode = 1U;
  } else {
    /* '<S84>:1:4' else */
    /* '<S84>:1:5' HapticAlarmReq= uint8(0); */
    rtb_IMAPve_d_LDW_Warn_Mode = 0U;
  }

  /* End of MATLAB Function: '<S8>/HapticAlarmReq' */

  /* MATLAB Function: '<S8>/Status_Display' */
  /*  ֻ��LDW����� */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Status_Display': '<S87>:1' */
  /* '<S87>:1:3' if (LKA_Mode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S87>:1:4' LDW_Status_Display=uint8(1); */
    rtb_Rrg_Q = 1U;

    /* '<S87>:1:5' LKA_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S87>:1:6' elseif (LKA_Mode==1)&&LDW_STATE==6 */
    /* '<S87>:1:7' LDW_Status_Display=uint8(2); */
    rtb_Rrg_Q = 2U;

    /* '<S87>:1:8' LKA_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;

    /*  ֻ��LKA����� */
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State)
              != 6)) {
    /* '<S87>:1:11' elseif  (LKA_Mode==2)&&LKA_STATE~=6 */
    /* '<S87>:1:12' LDW_Status_Display=uint8(0); */
    rtb_Rrg_Q = 0U;

    /* '<S87>:1:13' LKA_Status_Display=uint8(1); */
    rtb_TCU_ActualGear = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S87>:1:14' elseif (LKA_Mode==2)&&LKA_STATE==6 */
    /* '<S87>:1:15' LDW_Status_Display=uint8(0); */
    rtb_Rrg_Q = 0U;

    /* '<S87>:1:16' LKA_Status_Display=uint8(2); */
    rtb_TCU_ActualGear = 2U;
  } else {
    /* '<S87>:1:17' else */
    /* '<S87>:1:18' LDW_Status_Display=uint8(0); */
    rtb_Rrg_Q = 0U;

    /* '<S87>:1:19' LKA_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;
  }

  /* End of MATLAB Function: '<S8>/Status_Display' */

  /* Switch: '<S88>/Switch' incorporates:
   *  Constant: '<S90>/Constant'
   *  RelationalOperator: '<S90>/Compare'
   */
  if (rtb_FDMMve_d_LkaFcnConf == ((uint8)3U)) {
    rtb_R0_C1_g = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  }

  /* End of Switch: '<S88>/Switch' */

  /* Logic: '<S88>/Logical Operator2' incorporates:
   *  Abs: '<S88>/Abs'
   *  Constant: '<S91>/Constant'
   *  Constant: '<S92>/Constant'
   *  Constant: '<S93>/Constant'
   *  Constant: '<S94>/Constant'
   *  Constant: '<S95>/Constant'
   *  Constant: '<S96>/Constant'
   *  Constant: '<S97>/Constant'
   *  Constant: '<S98>/Constant'
   *  Logic: '<S88>/Logical Operator1'
   *  Logic: '<S88>/Logical Operator3'
   *  RelationalOperator: '<S88>/Relational Operator'
   *  RelationalOperator: '<S91>/Compare'
   *  RelationalOperator: '<S92>/Compare'
   *  RelationalOperator: '<S93>/Compare'
   *  RelationalOperator: '<S94>/Compare'
   *  RelationalOperator: '<S95>/Compare'
   *  RelationalOperator: '<S96>/Compare'
   *  RelationalOperator: '<S97>/Compare'
   *  RelationalOperator: '<S98>/Compare'
   */
  rtb_LogicalOperator2 = ((((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (LKAS_DW.LKA_State == ((uint8)5U))) || (LKAS_DW.LKA_State == ((uint8)4U))) ||
    (LKAS_DW.LKA_State == ((uint8)3U))) && ((rtb_FDMMve_d_LkaFcnConf == ((uint8)
    3U)) || (rtb_FDMMve_d_LkaFcnConf == ((uint8)1U)))) && (fabsf
    (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_R0_C1_g));

  /* Switch: '<S678>/Switch2' incorporates:
   *  Constant: '<S678>/LL_RlsDet_tiTDelTime_DISABLE=2'
   *
   * Block description for '<S678>/LL_RlsDet_tiTDelTime_DISABLE=2':
   *  ��ʻԱ���ֿ�ʼ����������������ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion2_g != 0.0F) {
    rtb_LL_HandsOff_WarnTime = LKAS_ConstB.DataTypeConversion2_g;
  } else {
    rtb_LL_HandsOff_WarnTime = LL_HandsOff_WarnTime;
  }

  /* End of Switch: '<S678>/Switch2' */

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition2' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_WarnTime, &LKAS_DW.RelationalOperator_g0,
                     &LKAS_DW.SumCondition2);

  /* End of Outputs for SubSystem: '<S88>/Sum Condition2' */

  /* MATLAB Function: '<S8>/Hands_Off_Warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_Off_Warning': '<S83>:1' */
  /* '<S83>:1:2' if HandsOff==0 */
  if (!LKAS_DW.RelationalOperator_g0) {
    /* '<S83>:1:3' Hands_Off_Warning= uint8(0); */
    rtb_FDMMve_d_LkaFcnConf = 0U;
  } else {
    /* '<S83>:1:4' elseif HandsOff==1 */
    /* '<S83>:1:5' Hands_Off_Warning= uint8(1); */
    rtb_FDMMve_d_LkaFcnConf = 1U;
  }

  /* End of MATLAB Function: '<S8>/Hands_Off_Warning' */

  /* Switch: '<S678>/Switch1' incorporates:
   *  Constant: '<S678>/LL_RlsDet_tiTDelTime_DISABLE=1'
   *
   * Block description for '<S678>/LL_RlsDet_tiTDelTime_DISABLE=1':
   *  ��ʻԱ���ֿ�ʼ�����ܷ����������ѵ�ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_HandsOff_TextTime = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_HandsOff_TextTime = LL_HandsOff_TextTime;
  }

  /* End of Switch: '<S678>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_TextTime, &LKAS_DW.RelationalOperator_o2,
                     &LKAS_DW.SumCondition1);

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */

  /* MATLAB Function: '<S8>/HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1'
   *  Inport: '<Root>/IMAPve_d_Camera_Status'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S82>:1' */
  /* '<S82>:1:2' if (LKA_Mode==1||LKA_Mode==2)&&(Camera_Status==5) */
  if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2)) &&
      (((sint32)((uint8)
                 Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status
                 ())) == 5)) {
    /* ����ͷ���ڵ� */
    /* '<S82>:1:3' HMI_Popup_Status=uint8(4); */
    rtb_HMI_Popup_Status_f = 4U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) ==
    2)) && (LKAS_DW.RelationalOperator_o2)) {
    /* '<S82>:1:4' elseif (LKA_Mode==1||LKA_Mode==2) && HandsOff1_Text==1 */
    /* ���շ����� */
    /* '<S82>:1:5' HMI_Popup_Status=uint8(2); */
    rtb_HMI_Popup_Status_f = 2U;
  } else {
    /* '<S82>:1:6' else */
    /* '<S82>:1:7' HMI_Popup_Status=uint8(0); */
    rtb_HMI_Popup_Status_f = 0U;
  }

  /* End of MATLAB Function: '<S8>/HMI_Popup_Status' */

  /* MATLAB Function: '<S8>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S86>:1' */
  /* '<S86>:1:2' if LKA_Mode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S86>:1:3' LKA_Action_Indication=uint8(1); */
    rtb_LKA_Action_Indication_m = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S86>:1:4' elseif LKA_Mode==2&&LKA_STATE==3 */
    /* '<S86>:1:5' LKA_Action_Indication=uint8(2); */
    rtb_LKA_Action_Indication_m = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S86>:1:6' elseif LKA_Mode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S86>:1:7' LKA_Action_Indication=uint8(3); */
    rtb_LKA_Action_Indication_m = 3U;
  } else {
    /* '<S86>:1:8' else */
    /* '<S86>:1:9' LKA_Action_Indication=uint8(0); */
    rtb_LKA_Action_Indication_m = 0U;
  }

  /* End of MATLAB Function: '<S8>/LKA_action_indication' */

  /* DataTypeConversion: '<S11>/Cast To Single10' incorporates:
   *  Constant: '<S666>/Constant'
   *  RelationalOperator: '<S666>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.LKA_Mode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S4>/Cast To Single1' */
  LKAS_DW.CastToSingle1 = LKAS_DW.LFTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single2' */
  LKAS_DW.CastToSingle2 = LKAS_DW.RGTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single3' */
  LKAS_DW.CastToSingle3 = (float32)LKAS_DW.LDW_State_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single4' */
  LKAS_DW.CastToSingle4 = (float32)LKAS_DW.LKA_State_Mon;

  /* S-Function (scanpack): '<S4>/CAN Pack' */
  /* S-Function (scanpack): '<S4>/CAN Pack' */
  LKAS_DW.CANPack.ID = 1U;
  LKAS_DW.CANPack.Length = 8U;
  LKAS_DW.CANPack.Extended = 0U;
  LKAS_DW.CANPack.Remote = 0;
  LKAS_DW.CANPack.Data[0] = 0;
  LKAS_DW.CANPack.Data[1] = 0;
  LKAS_DW.CANPack.Data[2] = 0;
  LKAS_DW.CANPack.Data[3] = 0;
  LKAS_DW.CANPack.Data[4] = 0;
  LKAS_DW.CANPack.Data[5] = 0;
  LKAS_DW.CANPack.Data[6] = 0;
  LKAS_DW.CANPack.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle1;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[1] = LKAS_DW.CANPack.Data[1] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[0] = LKAS_DW.CANPack.Data[0] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle2;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[3] = LKAS_DW.CANPack.Data[3] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[2] = LKAS_DW.CANPack.Data[2] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle3;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[5] = LKAS_DW.CANPack.Data[5] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[4] = LKAS_DW.CANPack.Data[4] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle4;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[7] = LKAS_DW.CANPack.Data[7] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[6] = LKAS_DW.CANPack.Data[6] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single5' */
  LKAS_DW.CastToSingle5 = LKAS_DW.LKA_ExitFlg_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single6' */
  LKAS_DW.CastToSingle6 = LKAS_DW.LKA_SampleTime_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single7' */
  LKAS_DW.CastToSingle7 = LKAS_DW.T1_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single8' */
  LKAS_DW.CastToSingle8 = LKAS_DW.Disable_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  LKAS_DW.CANPack1.ID = 2U;
  LKAS_DW.CANPack1.Length = 8U;
  LKAS_DW.CANPack1.Extended = 0U;
  LKAS_DW.CANPack1.Remote = 0;
  LKAS_DW.CANPack1.Data[0] = 0;
  LKAS_DW.CANPack1.Data[1] = 0;
  LKAS_DW.CANPack1.Data[2] = 0;
  LKAS_DW.CANPack1.Data[3] = 0;
  LKAS_DW.CANPack1.Data[4] = 0;
  LKAS_DW.CANPack1.Data[5] = 0;
  LKAS_DW.CANPack1.Data[6] = 0;
  LKAS_DW.CANPack1.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle5;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[1] = LKAS_DW.CANPack1.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[0] = LKAS_DW.CANPack1.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle6;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[3] = LKAS_DW.CANPack1.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[2] = LKAS_DW.CANPack1.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle7;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[5] = LKAS_DW.CANPack1.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[4] = LKAS_DW.CANPack1.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle8;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[7] = LKAS_DW.CANPack1.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[6] = LKAS_DW.CANPack1.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single9' */
  LKAS_DW.CastToSingle9 = (float32)LKAS_DW.Fault_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack2' */
  /* S-Function (scanpack): '<S4>/CAN Pack2' */
  LKAS_DW.CANPack2.ID = 3U;
  LKAS_DW.CANPack2.Length = 8U;
  LKAS_DW.CANPack2.Extended = 0U;
  LKAS_DW.CANPack2.Remote = 0;
  LKAS_DW.CANPack2.Data[0] = 0;
  LKAS_DW.CANPack2.Data[1] = 0;
  LKAS_DW.CANPack2.Data[2] = 0;
  LKAS_DW.CANPack2.Data[3] = 0;
  LKAS_DW.CANPack2.Data[4] = 0;
  LKAS_DW.CANPack2.Data[5] = 0;
  LKAS_DW.CANPack2.Data[6] = 0;
  LKAS_DW.CANPack2.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle9;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[1] = LKAS_DW.CANPack2.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[0] = LKAS_DW.CANPack2.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle10;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[3] = LKAS_DW.CANPack2.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[2] = LKAS_DW.CANPack2.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle21;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[5] = LKAS_DW.CANPack2.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[4] = LKAS_DW.CANPack2.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle22;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[7] = LKAS_DW.CANPack2.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[6] = LKAS_DW.CANPack2.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack' */
    if ((8 == LKAS_DW.CANPack.Length) && (LKAS_DW.CANPack.ID != INVALID_CAN_ID) )
    {
      if ((1 == LKAS_DW.CANPack.ID) && (0U == LKAS_DW.CANPack.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
    if ((8 == LKAS_DW.CANPack1.Length) && (LKAS_DW.CANPack1.ID != INVALID_CAN_ID)
        ) {
      if ((2 == LKAS_DW.CANPack1.ID) && (0U == LKAS_DW.CANPack1.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
    if ((8 == LKAS_DW.CANPack2.Length) && (LKAS_DW.CANPack2.ID != INVALID_CAN_ID)
        ) {
      if ((3 == LKAS_DW.CANPack2.ID) && (0U == LKAS_DW.CANPack2.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack2.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack2.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07L_100 = result;
            }
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S12>/Cast To Boolean37' incorporates:
   *  DataTypeConversion: '<S41>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_14B_InvOorReal = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean38' incorporates:
   *  DataTypeConversion: '<S42>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxN = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean39' incorporates:
   *  DataTypeConversion: '<S43>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxT = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean40' incorporates:
   *  DataTypeConversion: '<S44>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinN = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean41' incorporates:
   *  DataTypeConversion: '<S45>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinT = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean' incorporates:
   *  DataTypeConversion: '<S53>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_ACU_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean10' incorporates:
   *  DataTypeConversion: '<S55>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_EPB_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean11' incorporates:
   *  DataTypeConversion: '<S56>/Extract Desired Bits'
   */
  rtb_ADIA_Inner_FRadar_FaultStat = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean12' incorporates:
   *  DataTypeConversion: '<S57>/Extract Desired Bits'
   */
  rtb_ADIAve_d_sen_sta_Corner_rad = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S61>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_EMS_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean6' incorporates:
   *  DataTypeConversion: '<S62>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_IC_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S13>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S63>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_TBOX_Validity = (rtb_R0_C3 != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean1' incorporates:
   *  DataTypeConversion: '<S16>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC_EPBErrorStatus = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean13' incorporates:
   *  DataTypeConversion: '<S20>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorTCS = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean14' incorporates:
   *  DataTypeConversion: '<S21>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorVeh = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean15' incorporates:
   *  DataTypeConversion: '<S22>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorLat = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean17' incorporates:
   *  DataTypeConversion: '<S40>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_MP5_366_OorAEBButt = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean18' incorporates:
   *  DataTypeConversion: '<S25>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_MP5_366_OorFCWButt = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean19' incorporates:
   *  DataTypeConversion: '<S26>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_SAS_A5_InvOorSteAn = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean21' incorporates:
   *  DataTypeConversion: '<S23>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorLon = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean22' incorporates:
   *  DataTypeConversion: '<S24>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorSta = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean23' incorporates:
   *  DataTypeConversion: '<S32>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorYaw = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean24' incorporates:
   *  DataTypeConversion: '<S33>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvOorDyn = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean25' incorporates:
   *  DataTypeConversion: '<S34>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvUnfilY = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean26' incorporates:
   *  DataTypeConversion: '<S35>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehDri = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean27' incorporates:
   *  DataTypeConversion: '<S36>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehHol = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean28' incorporates:
   *  DataTypeConversion: '<S37>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_GW_MP5_413_OorISAM = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean29' incorporates:
   *  DataTypeConversion: '<S29>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_SCC_309_OorACCButt = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean35' incorporates:
   *  DataTypeConversion: '<S30>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_TCU1_93_InvOorGear = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean4' incorporates:
   *  DataTypeConversion: '<S47>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_BCM3_33C_InvBrkLig = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S48>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_14A_OorACCStat = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean6' incorporates:
   *  DataTypeConversion: '<S49>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS10_88_InvAccPed = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S50>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS5_E0_InvOorBrkP = (rtb_L0_C0_g != 0.0F);

  /* DataTypeConversion: '<S12>/Cast To Boolean8' incorporates:
   *  DataTypeConversion: '<S51>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS5_E0_OorEngineS = (rtb_L0_C0_g != 0.0F);

  /* Switch: '<S119>/Switch3' incorporates:
   *  Constant: '<S119>/Constant'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S131>:1' */
  /* '<S131>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S131>:1:3' cur=min(single(0.004),cur); */
  /* '<S131>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S131>:1:5' offset=min(single(0.5),offset); */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    /* DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     */
    rtb_L1_Q_a = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q
      ();

    /* Switch: '<S113>/Switch1' incorporates:
     *  Constant: '<S113>/Constant1'
     */
    if (rtb_L1_Q_a >= ((uint8)2U)) {
      rtb_L1_Q = (uint16)((uint8)3U);
    } else {
      rtb_L1_Q = (uint16)rtb_L1_Q_a;
    }

    /* End of Switch: '<S113>/Switch1' */
  } else {
    rtb_L1_Q = ((uint16)0U);
  }

  /* End of Switch: '<S119>/Switch3' */

  /* Switch: '<S121>/Switch3' incorporates:
   *  Constant: '<S121>/Constant'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    /* DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    rtb_L1_Q_a = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q
      ();

    /* Switch: '<S114>/Switch1' incorporates:
     *  Constant: '<S114>/Constant1'
     */
    if (rtb_L1_Q_a >= ((uint8)2U)) {
      rtb_R1_Q = (uint16)((uint8)3U);
    } else {
      rtb_R1_Q = (uint16)rtb_L1_Q_a;
    }

    /* End of Switch: '<S114>/Switch1' */
  } else {
    rtb_R1_Q = ((uint16)0U);
  }

  /* End of Switch: '<S121>/Switch3' */

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_VR_End_BACK_1'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   *  Inport: '<Root>/IMAPve_g_Rrg_VR_End_BACK'
   */
  if (rtb_RFlg) {
    rtb_R0_C1_g = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_VR_End_BACK_IMAPve_g_Rrg_VR_End_BACK
      ();
  } else {
    rtb_R0_C1_g = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR();
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_VR_End_BACK_1'
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   *  Inport: '<Root>/IMAPve_g_Lrg_VR_End_BACK'
   */
  if (rtb_LFlg) {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_VR_End_BACK_IMAPve_g_Lrg_VR_End_BACK
      ();
  } else {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR();
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_VR_p = rtb_R0_C1_g;
  } else {
    rtb_R0_VR_p = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_b = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  } else {
    rtb_L0_VR_b = rtb_R0_C1_g;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_Rrg_TYPE_BACK_1'
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   *  Inport: '<Root>/IMAPve_d_Rrg_TYPE_BACK'
   */
  if (rtb_RFlg) {
    rtb_L1_Q_a = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Rrg_TYPE_BACK_IMAPve_d_Rrg_TYPE_BACK
      ();
  } else {
    rtb_L1_Q_a = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type();
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_Lrg_TYPE_BACK_1'
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   *  Inport: '<Root>/IMAPve_d_Lrg_TYPE_BACK'
   */
  if (rtb_LFlg) {
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Lrg_TYPE_BACK_IMAPve_d_Lrg_TYPE_BACK
      ();
  } else {
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type();
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_o = rtb_L1_Q_a;
  } else {
    rtb_R0_Type_o = rtb_L0_Type;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_k = rtb_L0_Type;
  } else {
    rtb_L0_Type_k = rtb_L1_Q_a;
  }

  /* Switch: '<S123>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  if (rtb_RFlg) {
    rtb_R0_C1_g = 0.0F;
  } else {
    rtb_R0_C1_g = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W();
  }

  /* Switch: '<S123>/Switch1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_W_1'
   *  Inport: '<Root>/IMAPve_g_L0_W'
   */
  if (rtb_LFlg) {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = 0.0F;
  } else {
    rtb_LL_RlsDet_tiTrqChkT_EPS_DIS = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W();
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S122>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_f = rtb_R0_C1_g;
  } else {
    rtb_R0_W_f = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_f = rtb_LL_RlsDet_tiTrqChkT_EPS_DIS;
  } else {
    rtb_L0_W_f = rtb_R0_C1_g;
  }

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_LCAWarning_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_LCAWarning'
   */
  rtb_EWWWve_y_BSD_LCAWarning = (uint8)
    Rte_IRead_Runnable_LKAS_Step_EWWWve_y_BSD_LCAWarning_EWWWve_y_BSD_LCAWarning
    ();

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_LCWWorkingSt_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_LCWWorkingSt'
   */
  rtb_EWWWve_y_BSD_LCWWorkingSt = (uint8)
    Rte_IRead_Runnable_LKAS_Step_EWWWve_y_BSD_LCWWorkingSt_EWWWve_y_BSD_LCWWorkingSt
    ();

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_S_LCAWarning_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_S_LCAWarning'
   */
  rtb_EWWWve_y_BSD_S_LCAWarning = (uint8)
    Rte_IRead_Runnable_LKAS_Step_EWWWve_y_BSD_S_LCAWarning_EWWWve_y_BSD_S_LCAWarning
    ();

  /* DataTypeConversion: '<S1>/EWWWve_y_BSD_S_LCWWorkingSt_1' incorporates:
   *  Inport: '<Root>/EWWWve_y_BSD_S_LCWWorkingSt'
   */
  rtb_EWWWve_y_BSD_S_LCWWorkingSt = (uint8)
    Rte_IRead_Runnable_LKAS_Step_EWWWve_y_BSD_S_LCWWorkingSt_EWWWve_y_BSD_S_LCWWorkingSt
    ();

  /* DataTypeConversion: '<S1>/FDMMve_d_ElkFcnConf_1' incorporates:
   *  Inport: '<Root>/FDMMve_d_ElkFcnConf'
   */
  rtb_FDMMve_d_ElkFcnConf = (uint8)
    Rte_IRead_Runnable_LKAS_Step_FDMMve_d_ElkFcnConf_FDMMve_d_ElkFcnConf();

  /* DataTypeConversion: '<S1>/IMAPve_d_APA_AutoPark_WorkSt_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_APA_AutoPark_WorkSt'
   */
  rtb_IMAPve_d_APA_AutoPark_WorkS = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp_Switch'
   */
  rtb_IMAPve_d_BCM_HazardLamp_Swi = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_Switch_IMAPve_d_BCM_HazardLamp_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ELK_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ELK_Switch'
   */
  rtb_IMAPve_d_ELK_Switch = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ELK_Switch_IMAPve_d_ELK_Switch();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Override'
   */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_ESA_State'
   */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State'
   */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag'
   */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_TrqLim_State'
   */
  rtb_IMAPve_d_EPS_TrqLim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Trq_State'
   */
  rtb_IMAPve_d_EPS_Trq_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid'
   */
  rtb_IMAPve_d_ESC_VehSpd_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid'
   */
  rtb_IMAPve_d_ESC_YawRate_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Fusion_Status'
   */
  rtb_IMAPve_d_Fusion_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status();

  /* DataTypeConversion: '<S110>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   */
  rtb_L1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_Work_State'
   */
  rtb_IMAPve_d_MP5_Work_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State
    ();

  /* DataTypeConversion: '<S110>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   */
  rtb_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SAS_Clb_State'
   */
  rtb_IMAPve_d_SAS_Clb_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SAS_Trim_State'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SWS_Failure_Status'
   */
  rtb_IMAPve_d_SWS_Failure_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Sensor_Status'
   */
  rtb_IMAPve_d_Sensor_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_TCU_Available'
   */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_obj_Num_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_obj_Num'
   */
  rtb_IMAPve_d_obj_Num = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_obj_Num_IMAPve_d_obj_Num();

  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  rtb_IMAPve_g_EMS_RealPedal = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  rtb_IMAPve_g_EPS_LKA_Current = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  rtb_IMAPve_g_ESC_Brake_Press = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  rtb_IMAPve_g_ESC_UnYawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  rtb_IMAPve_g_ESC_YawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate();

  /* DataTypeConversion: '<S110>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   *  UnaryMinus: '<S110>/Unary Minus8'
   */
  rtb_L1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   *  UnaryMinus: '<S110>/Unary Minus9'
   */
  rtb_L1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   *  UnaryMinus: '<S110>/Unary Minus10'
   */
  rtb_L1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   *  UnaryMinus: '<S110>/Unary Minus11'
   */
  rtb_L1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single78' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  rtb_L1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR();

  /* DataTypeConversion: '<S110>/Cast To Single74' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  rtb_L1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W();

  /* DataTypeConversion: '<S110>/Cast To Single4' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Lrg_VR_Start_BACK_1'
   *  Inport: '<Root>/IMAPve_g_Lrg_VR_Start_BACK'
   */
  rtb_R1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Lrg_VR_Start_BACK_IMAPve_g_Lrg_VR_Start_BACK
    ();

  /* DataTypeConversion: '<S110>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   *  UnaryMinus: '<S110>/Unary Minus14'
   */
  rtb_R1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   *  UnaryMinus: '<S110>/Unary Minus15'
   */
  rtb_R1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   *  UnaryMinus: '<S110>/Unary Minus12'
   */
  rtb_R1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   *  UnaryMinus: '<S110>/Unary Minus13'
   */
  rtb_R1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single50' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  rtb_R1_VR_i = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR();

  /* DataTypeConversion: '<S110>/Cast To Single52' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  rtb_R1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W();

  /* DataTypeConversion: '<S110>/Cast To Single12' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_Rrg_VR_Start_BACK_1'
   *  Inport: '<Root>/IMAPve_g_Rrg_VR_Start_BACK'
   */
  rtb_R1_VR_d = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_Rrg_VR_Start_BACK_IMAPve_g_Rrg_VR_Start_BACK
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  rtb_IMAPve_g_SW_Angle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle();

  /* Switch: '<S677>/Switch1' incorporates:
   *  Constant: '<S677>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1_k != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1_k;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S677>/Switch1' */

  /* Switch: '<S677>/Switch15' incorporates:
   *  Constant: '<S677>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    rtb_LL_lStpLngth_C = LKAS_ConstB.DataTypeConversion21;
  } else {
    rtb_LL_lStpLngth_C = LL_lStpLngth_C;
  }

  /* End of Switch: '<S677>/Switch15' */

  /* Switch: '<S677>/Switch10' incorporates:
   *  Constant: '<S677>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22_c != 0.0F) {
    rtb_LL_DesDvt_C = LKAS_ConstB.DataTypeConversion22_c;
  } else {
    rtb_LL_DesDvt_C = LL_DesDvt_C;
  }

  /* End of Switch: '<S677>/Switch10' */

  /* Switch: '<S677>/Switch12' incorporates:
   *  Constant: '<S677>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23_m != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23_m;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S677>/Switch12' */

  /* Switch: '<S677>/Switch16' incorporates:
   *  Constant: '<S677>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24_m != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24_m;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S677>/Switch16' */

  /* Switch: '<S678>/Switch56' incorporates:
   *  Constant: '<S678>/LLSMConClb14'
   *
   * Block description for '<S678>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_a != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_a;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S678>/Switch56' */

  /* Switch: '<S678>/Switch51' incorporates:
   *  Constant: '<S678>/LLSMConClb15'
   *
   * Block description for '<S678>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_e != 0.0F) {
    rtb_LL_DvtComp_C_l = LKAS_ConstB.DataTypeConversion25_e;
  } else {
    rtb_LL_DvtComp_C_l = LL_DvtComp_C;
  }

  /* End of Switch: '<S678>/Switch51' */

  /* Switch: '<S678>/Switch52' incorporates:
   *  Constant: '<S678>/LLSMConClb16'
   *
   * Block description for '<S678>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36_f != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36_f;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S678>/Switch52' */

  /* Switch: '<S678>/Switch57' incorporates:
   *  Constant: '<S678>/LLSMConClb18'
   *
   * Block description for '<S678>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S678>/Switch57' */

  /* Switch: '<S678>/Switch46' incorporates:
   *  Constant: '<S678>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S678>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_d != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_d;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S678>/Switch46' */

  /* Abs: '<S123>/Abs' incorporates:
   *  Sum: '<S123>/Add2'
   */
  rtb_LftTTLC = fabsf(rtb_L0_C0 + rtb_R0_C2);

  /* Saturate: '<S123>/Saturation' */
  if (rtb_LftTTLC > 0.004F) {
    rtb_LftTTLC = 0.004F;
  } else {
    if (rtb_LftTTLC < 0.0F) {
      rtb_LftTTLC = 0.0F;
    }
  }

  /* End of Saturate: '<S123>/Saturation' */

  /* Update for Memory: '<S123>/Memory1' incorporates:
   *  MATLAB Function: '<S123>/get_roadside_offset'
   */
  LKAS_DW.Memory1_PreviousInput = fminf(0.5F, (((fminf(0.004F, rtb_LftTTLC) /
    0.004F) + 1.0F) * 0.2F) * (fminf(4.0F, rtb_R0_C0) - 2.0F));

  /* Update for Delay: '<S128>/Delay' */
  LKAS_DW.Delay_DSTATE = rtb_R0_C0;

  /* Update for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Abs_n;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S142>/Delay' */
    LKAS_DW.Delay_DSTATE_f = LKAS_DW.stLKAActvFlg;

    /* Update for Memory: '<S598>/Memory' */
    LKAS_DW.Memory_PreviousInput_i = rtb_Saturation_j;

    /* Update for Delay: '<S143>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.stLKAState;

    /* Update for Memory: '<S538>/Memory' */
    LKAS_DW.Memory_PreviousInput_g = rtb_Saturation_l;

    /* Update for Memory: '<S456>/Memory' */
    LKAS_DW.Memory_PreviousInput_e = rtb_IMAPve_g_EPS_SW_Trq;

    /* Update for UnitDelay: '<S469>/Delay Input1'
     *
     * Block description for '<S469>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_neb;

    /* Update for UnitDelay: '<S468>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_e = LKAS_DW.RelationalOperator_h;

    /* Update for UnitDelay: '<S430>/Delay Input1'
     *
     * Block description for '<S430>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_e = rtb_Compare_bo;

    /* Update for UnitDelay: '<S428>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_n = LKAS_DW.RelationalOperator_p;

    /* Update for UnitDelay: '<S429>/Delay Input1'
     *
     * Block description for '<S429>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_d = rtb_Compare_bn;

    /* Update for Memory: '<S395>/Memory' */
    LKAS_DW.Memory_PreviousInput_pk = LKAS_DW.RelationalOperator_p;

    /* Update for Delay: '<S143>/Delay' */
    LKAS_DW.Delay_DSTATE_c = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S143>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.stLDWState;

    /* Update for Memory: '<S443>/Memory' */
    LKAS_DW.Memory_PreviousInput_hd = rtb_LDW_State;

    /* Update for Memory: '<S369>/Memory' */
    LKAS_DW.Memory_PreviousInput_gk = rtb_Merge1_a;

    /* Update for Memory: '<S405>/Memory' */
    LKAS_DW.Memory_PreviousInput_c = rtb_Merge1_d;

    /* Update for Memory: '<S612>/Memory' */
    LKAS_DW.Memory_PreviousInput_iu = rtb_Saturation_e;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S141>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S181>/Memory' */
      LKAS_DW.Memory_PreviousInput_ht = rtb_Saturation2_p;

      /* Update for Memory: '<S212>/Memory' */
      LKAS_DW.Memory_PreviousInput_f = rtb_Saturation1_n;

      /* Update for Memory: '<S199>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_g = rtb_Saturation1_br;

      /* Update for Memory: '<S211>/Memory' */
      LKAS_DW.Memory_PreviousInput_oc = rtb_Saturation1_j;

      /* Update for Memory: '<S213>/Memory' */
      LKAS_DW.Memory_PreviousInput_ci = rtb_Saturation1_pr;

      /* Update for Memory: '<S208>/Memory' */
      LKAS_DW.Memory_PreviousInput_bh = rtb_Saturation1_an;

      /* Update for Memory: '<S196>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = rtb_Add_jv;

      /* Update for Memory: '<S182>/Memory' */
      LKAS_DW.Memory_PreviousInput_cw = rtb_Saturation2_pb;

      /* Update for Memory: '<S183>/Memory' */
      LKAS_DW.Memory_PreviousInput_ij = rtb_Saturation2_a;

      /* Update for UnitDelay: '<S185>/Delay Input1'
       *
       * Block description for '<S185>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_m = rtb_Compare_jr;

      /* Update for Memory: '<S183>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_c = rtb_Merge_p1;

      /* Update for Memory: '<S164>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_m = rtb_Saturation_f;

      /* Update for UnitDelay: '<S178>/Delay Input2'
       *
       * Block description for '<S178>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_a = rtb_DifferenceInputs2_g;

      /* Update for Memory: '<S160>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_n = rtb_Saturation1_g;

      /* Update for Memory: '<S160>/Memory' */
      LKAS_DW.Memory_PreviousInput_em = rtb_DifferenceInputs2_g;

      /* Update for UnitDelay: '<S177>/Delay Input2'
       *
       * Block description for '<S177>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_b = rtb_DifferenceInputs2_k;

      /* Update for Memory: '<S275>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_p = rtb_Saturation_oq;

      /* Update for Memory: '<S258>/Memory' */
      LKAS_DW.Memory_PreviousInput_e4 = rtb_Add1_my;

      /* Update for UnitDelay: '<S256>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_p = rtb_Switch2_f;

      /* Update for Memory: '<S264>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_d = rtb_Saturation_jf;

      /* Update for Memory: '<S270>/Memory' */
      LKAS_DW.Memory_PreviousInput_bd = rtb_Saturation1_n1;

      /* Update for UnitDelay: '<S274>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_o = rtb_Switch_nb;

      /* Update for Memory: '<S274>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_f = rtb_Saturation_fr;

      /* Update for UnitDelay: '<S251>/Delay Input2'
       *
       * Block description for '<S251>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_i = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S251>/Memory' */
      LKAS_DW.Memory_PreviousInput_da = rtb_Saturation2_px;

      /* Update for Memory: '<S207>/Memory' */
      LKAS_DW.Memory_PreviousInput_ni = rtb_Add_h;

      /* Update for Memory: '<S209>/Memory' */
      LKAS_DW.Memory_PreviousInput_hk = rtb_Saturation1_b;

      /* Update for Memory: '<S210>/Memory' */
      LKAS_DW.Memory_PreviousInput_ei = rtb_Saturation1_g3;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S613>/Delay' */
    LKAS_DW.Delay_DSTATE_p = rtb_Switch8;

    /* Update for Delay: '<S614>/Delay' */
    LKAS_DW.Delay_DSTATE_d = rtb_Switch8_p;

    /* Update for Delay: '<S615>/Delay' */
    LKAS_DW.Delay_DSTATE_p3 = rtb_Switch8_c;

    /* Update for Delay: '<S143>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.LKA_Mode_k;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S670>/Delay Input2'
   *
   * Block description for '<S670>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_L0_C2_f;

  /* Update for UnitDelay: '<S669>/Delay Input2'
   *
   * Block description for '<S669>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_f = rtb_R0_C0_j;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_IMAPve_d_LKA_Mode);

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_Rrg_Q);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single2'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)rtb_TCU_ActualGear);

  /* Outport: '<Root>/LKASve_y_ELK_Status_Display' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single16'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_ELK_Status_Display_LKASve_y_ELK_Status_Display
    (LKAS_ConstB.ELK_Status_Display);

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single3'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    rtb_Lrg_Q);

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single4'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning
    ((UInt8)rtb_FDMMve_d_LkaFcnConf);

  /* Outport: '<Root>/LKASve_y_HapticAlarmReq' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single8'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HapticAlarmReq_LKASve_y_HapticAlarmReq
    ((UInt8)rtb_IMAPve_d_LDW_Warn_Mode);

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single5'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_LKA_Action_Indication_m);

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single6'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status
    ((UInt8)rtb_HMI_Popup_Status_f);

  /* Outport: '<Root>/LKASve_y_HMI_ELKPopupMessage' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single14'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_ELKPopupMessage_LKASve_y_HMI_ELKPopupMessage
    (LKAS_ConstB.HMI_ELKPopupMessage);

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq
    ((UInt8)rtb_L0_Q);

  /* Switch: '<S671>/Switch2' incorporates:
   *  Constant: '<S664>/Constant3'
   *  Constant: '<S664>/Constant4'
   *  RelationalOperator: '<S671>/LowerRelop1'
   *  RelationalOperator: '<S671>/UpperRelop'
   *  Switch: '<S671>/Switch'
   */
  if (rtb_L0_C2_f > 5.0F) {
    rtb_L0_C2_f = 5.0F;
  } else {
    if (rtb_L0_C2_f < (-5.0F)) {
      /* Switch: '<S671>/Switch' incorporates:
       *  Constant: '<S664>/Constant4'
       */
      rtb_L0_C2_f = (-5.0F);
    }
  }

  /* End of Switch: '<S671>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_L0_C2_f);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single8'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control
    ((UInt8)rtb_R0_Q_c);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/x1'
   */
  if (!rtb_Merge_n) {
    rtb_R0_C0_j = (float32)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_R0_C0_j);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S11>/Switch2' incorporates:
   *  Constant: '<S11>/2'
   *  Constant: '<S11>/x2'
   *  Constant: '<S667>/Constant'
   *  Constant: '<S668>/Constant'
   *  Logic: '<S11>/Logical Operator'
   *  RelationalOperator: '<S667>/Compare'
   *  RelationalOperator: '<S668>/Compare'
   */
  if ((rtb_R0_Q_c == ((uint8)4U)) || (rtb_R0_Q_c == ((uint8)3U))) {
    rtb_R0_Q_c = ((uint8)1U);
  } else {
    rtb_R0_Q_c = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    ((UInt8)rtb_R0_Q_c);

  /* Outport: '<Root>/LKASve_g_ob5H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5H_10_LKASve_g_ob5H_10
    (LKAS_DW.LKASve_g_ob5H_10);

  /* Outport: '<Root>/LKASve_g_ob5L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5L_10_LKASve_g_ob5L_10
    (LKAS_DW.LKASve_g_ob5L_10);

  /* Outport: '<Root>/LKASve_g_ob6H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6H_10_LKASve_g_ob6H_10
    (LKAS_DW.LKASve_g_ob6H_10);

  /* Outport: '<Root>/LKASve_g_ob6L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6L_10_LKASve_g_ob6L_10
    (LKAS_DW.LKASve_g_ob6L_10);

  /* Outport: '<Root>/LKASve_g_ob07H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07H_100_LKASve_g_ob07H_100
    (LKAS_DW.LKASve_g_ob07H_100);

  /* Outport: '<Root>/LKASve_g_ob07L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07L_100_LKASve_g_ob07L_100
    (LKAS_DW.LKASve_g_ob07L_100);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_g_ob08H_100' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single26'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08H_100_LKASve_g_ob08H_100((UInt32)
    ((uint32)rtb_L0_C0_g));

  /* Outport: '<Root>/LKASve_g_ob08L_100' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single23'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08L_100_LKASve_g_ob08L_100((UInt32)
    ((uint32)rtb_R0_C3));

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S443>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S199>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S273>/If' */
  LKAS_DW.If_ActiveSubsystem_d = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack' */

  /*-----------S-Function Block: <S4>/CAN Unpack -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack1' */

  /*-----------S-Function Block: <S4>/CAN Unpack1 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack2' */

  /*-----------S-Function Block: <S4>/CAN Unpack2 -----------------*/

  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* ConstCode for Constant: '<S2>/Version' */
  ob_LKA_Version = 220421.0F;

  /* End of ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S142>/Delay' */
  LKAS_DW.Delay_DSTATE_f = ((uint8)0U);

  /* InitializeConditions for Memory: '<S598>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = 0.0F;

  /* InitializeConditions for Delay: '<S143>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S538>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 0.0F;

  /* InitializeConditions for Memory: '<S456>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = 0.0F;

  /* InitializeConditions for UnitDelay: '<S469>/Delay Input1'
   *
   * Block description for '<S469>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S468>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_e = false;

  /* InitializeConditions for UnitDelay: '<S430>/Delay Input1'
   *
   * Block description for '<S430>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_e = false;

  /* InitializeConditions for UnitDelay: '<S428>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_n = false;

  /* InitializeConditions for UnitDelay: '<S429>/Delay Input1'
   *
   * Block description for '<S429>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_d = false;

  /* InitializeConditions for Memory: '<S395>/Memory' */
  LKAS_DW.Memory_PreviousInput_pk = false;

  /* InitializeConditions for Delay: '<S143>/Delay' */
  LKAS_DW.Delay_DSTATE_c = false;

  /* InitializeConditions for Delay: '<S143>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S443>/Memory' */
  LKAS_DW.Memory_PreviousInput_hd = ((uint8)0U);

  /* InitializeConditions for Memory: '<S369>/Memory' */
  LKAS_DW.Memory_PreviousInput_gk = 0.0F;

  /* InitializeConditions for Memory: '<S405>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 0.0F;

  /* InitializeConditions for Memory: '<S612>/Memory' */
  LKAS_DW.Memory_PreviousInput_iu = 0.0F;

  /* InitializeConditions for Delay: '<S613>/Delay' */
  LKAS_DW.Delay_DSTATE_p = ((uint8)0U);

  /* InitializeConditions for Delay: '<S614>/Delay' */
  LKAS_DW.Delay_DSTATE_d = ((uint8)0U);

  /* InitializeConditions for Delay: '<S615>/Delay' */
  LKAS_DW.Delay_DSTATE_p3 = ((uint8)0U);

  /* InitializeConditions for Delay: '<S143>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S456>/ExitCount1' */
  LKAS_ExitCount_Init(&LKAS_DW.ExitCount1);

  /* End of SystemInitialize for SubSystem: '<S456>/ExitCount1' */

  /* SystemInitialize for Enabled SubSystem: '<S456>/ExitCount' */
  LKAS_ExitCount_Init(&LKAS_DW.ExitCount);

  /* End of SystemInitialize for SubSystem: '<S456>/ExitCount' */

  /* SystemInitialize for Enabled SubSystem: '<S457>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S467>/Memory' */
  LKAS_DW.Memory_PreviousInput_l = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S457>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S468>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S472>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S468>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S395>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S426>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S395>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S395>/Count' */
  /* InitializeConditions for Memory: '<S425>/Memory' */
  LKAS_DW.Memory_PreviousInput_g3 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S395>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S428>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S434>/Memory' */
  LKAS_DW.Memory_PreviousInput_n = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S428>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S396>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S440>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S396>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S443>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S474>/Memory' */
  LKAS_DW.Memory_PreviousInput_ip = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S443>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S406>/Sum Condition' */
  /* InitializeConditions for Memory: '<S412>/Memory' */
  LKAS_DW.Memory_PreviousInput_cy = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S406>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S331>/Subsystem' */
  /* InitializeConditions for Memory: '<S335>/Memory' */
  LKAS_DW.Memory_PreviousInput_p2 = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S331>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S181>/Memory' */
  LKAS_DW.Memory_PreviousInput_ht = 0.0F;

  /* InitializeConditions for Memory: '<S212>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = ((uint16)0U);

  /* InitializeConditions for Memory: '<S199>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_g = ((uint8)0U);

  /* InitializeConditions for Memory: '<S211>/Memory' */
  LKAS_DW.Memory_PreviousInput_oc = ((uint16)0U);

  /* InitializeConditions for Memory: '<S213>/Memory' */
  LKAS_DW.Memory_PreviousInput_ci = ((uint16)0U);

  /* InitializeConditions for Memory: '<S208>/Memory' */
  LKAS_DW.Memory_PreviousInput_bh = ((uint16)0U);

  /* InitializeConditions for Memory: '<S196>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = 0.0F;

  /* InitializeConditions for Memory: '<S182>/Memory' */
  LKAS_DW.Memory_PreviousInput_cw = 0.0F;

  /* InitializeConditions for Memory: '<S183>/Memory' */
  LKAS_DW.Memory_PreviousInput_ij = 0.0F;

  /* InitializeConditions for UnitDelay: '<S185>/Delay Input1'
   *
   * Block description for '<S185>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_m = false;

  /* InitializeConditions for Memory: '<S183>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_c = false;

  /* InitializeConditions for Memory: '<S164>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_m = 0.0F;

  /* InitializeConditions for UnitDelay: '<S178>/Delay Input2'
   *
   * Block description for '<S178>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_a = 0.0F;

  /* InitializeConditions for Memory: '<S160>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_n = 0.0F;

  /* InitializeConditions for Memory: '<S160>/Memory' */
  LKAS_DW.Memory_PreviousInput_em = 0.0F;

  /* InitializeConditions for UnitDelay: '<S177>/Delay Input2'
   *
   * Block description for '<S177>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_b = 0.0F;

  /* InitializeConditions for Memory: '<S275>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_p = 0.0F;

  /* InitializeConditions for Memory: '<S258>/Memory' */
  LKAS_DW.Memory_PreviousInput_e4 = 0.0F;

  /* InitializeConditions for UnitDelay: '<S256>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_p = 0.0F;

  /* InitializeConditions for Memory: '<S264>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_d = 0.0F;

  /* InitializeConditions for Memory: '<S270>/Memory' */
  LKAS_DW.Memory_PreviousInput_bd = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S274>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_o = 0.0F;

  /* InitializeConditions for Memory: '<S274>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_f = 0.0F;

  /* InitializeConditions for UnitDelay: '<S251>/Delay Input2'
   *
   * Block description for '<S251>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_i = 0.0F;

  /* InitializeConditions for Memory: '<S251>/Memory' */
  LKAS_DW.Memory_PreviousInput_da = ((uint16)0U);

  /* InitializeConditions for Memory: '<S207>/Memory' */
  LKAS_DW.Memory_PreviousInput_ni = ((uint16)0U);

  /* InitializeConditions for Memory: '<S209>/Memory' */
  LKAS_DW.Memory_PreviousInput_hk = ((uint16)0U);

  /* InitializeConditions for Memory: '<S210>/Memory' */
  LKAS_DW.Memory_PreviousInput_ei = ((uint16)0U);

  /* SystemInitialize for Enabled SubSystem: '<S182>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S184>/Memory' */
  LKAS_DW.Memory_PreviousInput_h0 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S182>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S158>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S158>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S183>/Moving Standard Deviation1' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S183>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S183>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_k);

  /* End of SystemInitialize for SubSystem: '<S183>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S183>/Moving Standard Deviation2' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation2_g);

  /* End of SystemInitialize for SubSystem: '<S183>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S183>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_d);

  /* End of SystemInitialize for SubSystem: '<S183>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S183>/Sum Condition2' */
  /* InitializeConditions for Memory: '<S192>/Memory' */
  LKAS_DW.Memory_PreviousInput_k = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S183>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S158>/Sum Condition2' */
  /* InitializeConditions for Memory: '<S163>/Memory' */
  LKAS_DW.Memory_PreviousInput_ne = 0.0F;

  /* SystemInitialize for Outport: '<S163>/M4K' */
  LKAS_DW.Saturation3 = 1.0F;

  /* End of SystemInitialize for SubSystem: '<S158>/Sum Condition2' */

  /* SystemInitialize for Atomic SubSystem: '<S160>/Moving Standard Deviation2' */
  MovingStandardDeviation2_p_Init(&LKAS_DW.MovingStandardDeviation2_l);

  /* End of SystemInitialize for SubSystem: '<S160>/Moving Standard Deviation2' */

  /* SystemInitialize for IfAction SubSystem: '<S273>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S283>/Delay Input1'
   *
   * Block description for '<S283>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_j = false;

  /* InitializeConditions for Memory: '<S279>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S273>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S273>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S291>/Delay Input1'
   *
   * Block description for '<S291>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_ej = false;

  /* InitializeConditions for Memory: '<S280>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S273>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S273>/Merge' */
  LKAS_DW.Merge_a = 1.0F;

  /* SystemInitialize for Merge: '<S273>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S145>/Merge' */
  LKAS_DW.Merge_p = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S145>/Sum Condition' */
  /* InitializeConditions for Memory: '<S149>/Memory' */
  LKAS_DW.Memory_PreviousInput_lr = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S145>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */

  /* SystemInitialize for Enabled SubSystem: '<S477>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1_jk);

  /* End of SystemInitialize for SubSystem: '<S477>/Sum Condition1' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S664>/Subsystem' */
  /* InitializeConditions for Delay: '<S672>/Delay1' */
  LKAS_DW.Delay1_DSTATE = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S664>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S88>/Sum Condition2' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition2);

  /* End of SystemInitialize for SubSystem: '<S88>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S88>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1);

  /* End of SystemInitialize for SubSystem: '<S88>/Sum Condition1' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
