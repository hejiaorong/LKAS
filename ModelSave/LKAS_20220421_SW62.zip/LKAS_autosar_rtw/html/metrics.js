function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["LKAS_DW"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	size: 1418};
	 this.metricsArray.var["ob_LKA_Disable_Reason"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	size: 4};
	 this.metricsArray.var["ob_LKA_Fault_Reason"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	size: 4};
	 this.metricsArray.var["ob_LKA_LKADeactvCSyn"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	size: 4};
	 this.metricsArray.var["ob_LKA_Version"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	size: 4};
	 this.metricsArray.fcn["LKAMotionPlanningCalculationLKA"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["LKAS_ExitCount"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["LKAS_ExitCount_Disable"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_ExitCount_Init"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_ExitCount_Reset"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem2"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem2_f"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem2_i"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem3"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem4"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem_d"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem_f"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["LKAS_IfActionSubsystem_fo"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_LDW_State_Machine"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 1,
	stackTotal: 1};
	 this.metricsArray.fcn["LKAS_LDW_State_Machine_Reset"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_LKA_State_Machine"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 1,
	stackTotal: 1};
	 this.metricsArray.fcn["LKAS_LKA_State_Machine_Reset"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_MATLABFunction"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["LKAS_MovingStandardDeviation1"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 416,
	stackTotal: 416};
	 this.metricsArray.fcn["LKAS_MovingStandardDeviation2"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 408,
	stackTotal: 408};
	 this.metricsArray.fcn["LKAS_MovingStandardDeviation2_l"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 248,
	stackTotal: 248};
	 this.metricsArray.fcn["LKAS_Ph1SWA"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_Ph2SWA"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_Ph3SWA"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_Ph3SWA_m"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SaturableGainLutSatGainLut"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["LKAS_SumCondition1"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["LKAS_SumCondition1_Disable"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition1_Init"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition1_Reset"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition_Disable"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition_Init"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_SumCondition_Reset"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_ifaction"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["LKAS_ifaction_g"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["L_MovingStandardDeviation1_Init"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["L_MovingStandardDeviation2_Init"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MovingStandardDeviation1_Reset"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MovingStandardDeviation2_Reset"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MovingStandardDeviation2_p_Init"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MovingStandardDeviation_i_Reset"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_ADIAve_g_ASWFaultStatus_ADIAve_g_ASWFaultStatus"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_ADIAve_g_BSWFaultStatus_ADIAve_g_BSWFaultStatus"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_EWWWve_y_BSD_LCAWarning_EWWWve_y_BSD_LCAWarning"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_EWWWve_y_BSD_LCWWorkingSt_EWWWve_y_BSD_LCWWorkingSt"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_EWWWve_y_BSD_S_LCAWarning_EWWWve_y_BSD_S_LCAWarning"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_EWWWve_y_BSD_S_LCWWorkingSt_EWWWve_y_BSD_S_LCWWorkingSt"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_FDMMve_d_ElkFcnConf_FDMMve_d_ElkFcnConf"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_d_obj_MotionStatus_IMAPva_d_obj_MotionStatus"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_d_obj_class_IMAPva_d_obj_class"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_d_obj_id_IMAPva_d_obj_id"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_d_obj_lane_IMAPva_d_obj_lane"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_d_obj_status_IMAPva_d_obj_status"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_acc_x_IMAPva_g_obj_acc_x"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_acc_y_IMAPva_g_obj_acc_y"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_length_IMAPva_g_obj_length"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_pos_var_x_IMAPva_g_obj_pos_var_x"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_pos_var_xy_IMAPva_g_obj_pos_var_xy"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_pos_var_y_IMAPva_g_obj_pos_var_y"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_pos_x_IMAPva_g_obj_pos_x"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_pos_y_IMAPva_g_obj_pos_y"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_vel_x_IMAPva_g_obj_vel_x"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_vel_y_IMAPva_g_obj_vel_y"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPva_g_obj_width_IMAPva_g_obj_width"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_Switch_IMAPve_d_BCM_HazardLamp_Switch"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_ELK_Switch_IMAPve_d_ELK_Switch"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_Lrg_Q_BACK_IMAPve_d_Lrg_Q_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_Lrg_TYPE_BACK_IMAPve_d_Lrg_TYPE_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_Rrg_Q_BACK_IMAPve_d_Rrg_Q_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_Rrg_TYPE_BACK_IMAPve_d_Rrg_TYPE_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_d_obj_Num_IMAPve_d_obj_Num"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Lrg_C0_BACK_IMAPve_g_Lrg_C0_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Lrg_C1_BACK_IMAPve_g_Lrg_C1_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Lrg_C2_BACK_IMAPve_g_Lrg_C2_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Lrg_C3_BACK_IMAPve_g_Lrg_C3_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Lrg_VR_End_BACK_IMAPve_g_Lrg_VR_End_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Lrg_VR_Start_BACK_IMAPve_g_Lrg_VR_Start_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Rrg_C0_BACK_IMAPve_g_Rrg_C0_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Rrg_C1_BACK_IMAPve_g_Rrg_C1_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Rrg_C2_BACK_IMAPve_g_Rrg_C2_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Rrg_C3_BACK_IMAPve_g_Rrg_C3_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Rrg_VR_End_BACK_IMAPve_g_Rrg_VR_End_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_Rrg_VR_Start_BACK_IMAPve_g_Rrg_VR_Start_BACK"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IRead_LKAS_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_ob07H_100_LKASve_g_ob07H_100"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_ob07L_100_LKASve_g_ob07L_100"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_ob08H_100_LKASve_g_ob08H_100"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_ob08L_100_LKASve_g_ob08L_100"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_ob5H_10_LKASve_g_ob5H_10"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_ob5L_10_LKASve_g_ob5L_10"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_ob6H_10_LKASve_g_ob6H_10"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_g_ob6L_10_LKASve_g_ob6L_10"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_ELK_Status_Display_LKASve_y_ELK_Status_Display"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_HMI_ELKPopupMessage_LKASve_y_HMI_ELKPopupMessage"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_HapticAlarmReq_LKASve_y_HapticAlarmReq"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_IWrite_LKAS_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\stub\\Rte_LKAS.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Runnable_LKAS_Init"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Runnable_LKAS_Step"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 3540,
	stackTotal: 3956};
	 this.metricsArray.fcn["cosf"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabsf"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmaxf"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fminf"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["memcpy"] = {file: "D:\\Program\\matlab2018b\\sys\\lcc\\include\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sinf"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sqrtf"] = {file: "C:\\新建文件夹\\SW6\\LKAS_20220421_SW6.2\\LKAS_autosar_rtw\\LKAS.c",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="LKAS_metrics.html">Global Memory: 1434(bytes) Maximum Stack: 3540(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
