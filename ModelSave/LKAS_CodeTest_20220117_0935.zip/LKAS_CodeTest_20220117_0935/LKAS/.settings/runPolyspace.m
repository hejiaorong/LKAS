polyspaceCodeProverNoDesktop('-options-file', 'D:\LKAS\bin\LKAS_CodeTest_20220117_0935\LKAS\.settings\options_command.txt', '-results-dir', 'D:\LKAS\bin\LKAS_CodeTest_20220117_0935\LKAS');
