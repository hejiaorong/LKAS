/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.77
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Wed Nov 11 19:19:39 2020
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S75>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S75>/LKA_State_Machine' */
#define LKAS_IN_Fault_e                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_l      ((uint8)0U)
#define LKAS_IN_Normal_l               ((uint8)2U)
#define LKAS_IN_SysOff_a               ((uint8)2U)
#define LKAS_IN_SysOn_c                ((uint8)3U)
#define LKAS_IN_Unavailable_a          ((uint8)1U)
#define LKAS_IN_Unselected_m           ((uint8)2U)

/* Named constants for Chart: '<S52>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Block signals (default storage) */
B_LKAS_T LKAS_B;

/* Block states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * Output and update for action system:
 *    '<S77>/If Action Subsystem2'
 *    '<S117>/if action 4'
 *    '<S118>/if action 4'
 *    '<S119>/if action 4'
 *    '<S120>/if action 4'
 *    '<S131>/If Action Subsystem3'
 *    '<S139>/If Action Subsystem3'
 *    '<S158>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S81>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S81>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/*
 * System initialize for atomic system:
 *    '<S92>/Moving Standard Deviation2'
 *    '<S104>/Moving Standard Deviation1'
 *    '<S104>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S100>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S92>/Moving Standard Deviation2'
 *    '<S104>/Moving Standard Deviation1'
 *    '<S104>/Moving Standard Deviation2'
 */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S100>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S92>/Moving Standard Deviation2'
 *    '<S104>/Moving Standard Deviation1'
 *    '<S104>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation2(float32 rtu_In1,
  DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_c;
  float32 rtb_Delay1;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S100>/Delay' */
  rtb_Delay_c = localDW->Delay_DSTATE;

  /* Delay: '<S100>/Delay1' */
  rtb_Delay1 = localDW->Delay1_DSTATE;

  /* Delay: '<S100>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S100>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S100>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S100>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S100>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S100>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S100>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S100>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S100>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S100>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S100>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S100>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S100>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S100>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S100>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S100>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S100>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S100>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S100>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S100>/Delay28' incorporates:
   *  Delay: '<S100>/Delay19'
   */
  localDW->Delay19_DSTATE = localDW->Delay28_DSTATE;

  /* Delay: '<S100>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S100>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S100>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S100>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S100>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S100>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S100>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S100>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S100>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S100>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S100>/Delay38' incorporates:
   *  Delay: '<S100>/Delay29'
   */
  localDW->Delay29_DSTATE = localDW->Delay38_DSTATE;

  /* Delay: '<S100>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S100>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S100>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S100>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S100>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S100>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S100>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S100>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S100>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S100>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S100>/Delay48' incorporates:
   *  Delay: '<S100>/Delay39'
   */
  localDW->Delay39_DSTATE = localDW->Delay48_DSTATE;

  /* Delay: '<S100>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S100>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S100>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S100>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S100>/Delay9' incorporates:
   *  Delay: '<S100>/Delay10'
   */
  localDW->Delay10_DSTATE = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S100>/TmpSignal ConversionAtStandard DeviationInport1' incorporates:
   *  Delay: '<S100>/Delay10'
   *  Delay: '<S100>/Delay19'
   *  Delay: '<S100>/Delay29'
   *  Delay: '<S100>/Delay39'
   */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_c;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = localDW->Delay10_DSTATE;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = localDW->Delay19_DSTATE;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = localDW->Delay29_DSTATE;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = localDW->Delay39_DSTATE;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S100>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal /
      50.0F) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S100>/Standard Deviation' */

  /* Update for Delay: '<S100>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S100>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_c;

  /* Update for Delay: '<S100>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S100>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S100>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S100>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S100>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S100>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S100>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S100>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S100>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1;

  /* Update for Delay: '<S100>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S100>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S100>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S100>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S100>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S100>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S100>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S100>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S100>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S100>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S100>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S100>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S100>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S100>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S100>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S100>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S100>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S100>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S100>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S100>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S100>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S100>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S100>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S100>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S100>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S100>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S100>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S100>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S100>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S100>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S100>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S100>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S100>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S100>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S104>/Sum Condition'
 *    '<S104>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S108>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S104>/Sum Condition'
 *    '<S104>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S108>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S104>/Sum Condition'
 *    '<S104>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(uint16 *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S104>/Sum Condition' incorporates:
   *  EnablePort: '<S108>/Enable'
   */
  /* Disable for Outport: '<S108>/Out' */
  *rty_Out = ((uint16)0U);

  /* End of Outputs for SubSystem: '<S104>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S104>/Sum Condition'
 *    '<S104>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_In, float32 rtu_In1, uint16 *rty_Out,
  DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S104>/Sum Condition' incorporates:
   *  EnablePort: '<S108>/Enable'
   */
  if (rtu_In) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Saturate: '<S108>/Saturation' incorporates:
     *  Memory: '<S108>/Memory'
     *  Sum: '<S108>/Add1'
     */
    if (1.0F + localDW->Memory_PreviousInput > 100000.0F) {
      localDW->Memory_PreviousInput = 100000.0F;
    } else if (1.0F + localDW->Memory_PreviousInput < 0.0F) {
      localDW->Memory_PreviousInput = 0.0F;
    } else {
      localDW->Memory_PreviousInput++;
    }

    /* End of Saturate: '<S108>/Saturation' */

    /* DataTypeConversion: '<S108>/Data Type Conversion' incorporates:
     *  RelationalOperator: '<S108>/Relational Operator'
     */
    *rty_Out = (uint16)(localDW->Memory_PreviousInput >= rtu_In1);
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S104>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S117>/if action 3'
 *    '<S118>/if action 3'
 *    '<S119>/if action 3'
 *    '<S120>/if action 3'
 *    '<S131>/If Action Subsystem2'
 *    '<S131>/If Action Subsystem1'
 *    '<S215>/If Action Subsystem2'
 *    '<S215>/If Action Subsystem1'
 *    '<S216>/If Action Subsystem2'
 *    '<S216>/If Action Subsystem1'
 *    ...
 */
void LKAS_ifaction3(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S123>/In1' */
  *rty_Out1 = rtu_In1;
}

/* System initialize for action system: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculati_Init(void)
{
  /* InitializeConditions for Memory: '<S116>/Memory' */
  LKAS_DW.Memory_PreviousInput_lp = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = ((uint16)0U);

  /* InitializeConditions for Memory: '<S117>/Memory' */
  LKAS_DW.Memory_PreviousInput_gf = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_n5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_bj = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_e3 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/* System reset for action system: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculat_Reset(void)
{
  /* InitializeConditions for Memory: '<S116>/Memory' */
  LKAS_DW.Memory_PreviousInput_lp = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = ((uint16)0U);

  /* InitializeConditions for Memory: '<S117>/Memory' */
  LKAS_DW.Memory_PreviousInput_gf = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_n5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_bj = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_e3 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/*
 * Output and update for action system: '<S85>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S85>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  /* local block i/o variables */
  float32 rtb_Memory1;
  float32 rtb_Memory2;
  float32 rtb_Memory3;
  float32 rtb_Memory4;
  float32 rtb_Merge1;
  float32 rtb_Merge1_h;
  float32 rtb_Merge1_g;
  float32 rtb_Merge1_i;
  float32 rtb_K1K2Det_dphi2PhSWAGrad2;
  float32 rtb_K1K2Det_stReplFlag;
  float32 rtb_K1K2Det_dphi1PhHdAgIni;
  float32 DelteSW0;
  float32 u;
  float32 Kw;
  float32 StpLngth;
  float32 K1;
  float32 K2_2;
  float32 T1;
  float32 T2;
  sint32 a;
  float32 Delte_Psi;
  float32 K2;
  float32 c_T1;
  float32 c_T2;
  uint16 rtb_Add_0;

  /* Sum: '<S116>/Add' incorporates:
   *  Constant: '<S116>/Constant'
   *  Memory: '<S116>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_lp = (uint16)((uint32)((uint16)1U) +
    LKAS_DW.Memory_PreviousInput_lp);

  /* Saturate: '<S116>/Saturation1' */
  if (LKAS_DW.Memory_PreviousInput_lp < ((uint16)100U)) {
    rtb_Add_0 = LKAS_DW.Memory_PreviousInput_lp;
  } else {
    rtb_Add_0 = ((uint16)100U);
  }

  /* End of Saturate: '<S116>/Saturation1' */

  /* If: '<S116>/If' incorporates:
   *  Constant: '<S116>/Constant19'
   */
  if (rtb_Add_0 == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S116>/if action 2' incorporates:
     *  ActionPort: '<S122>/Action Port'
     */
    /* SignalConversion: '<S122>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
     *  Constant: '<S122>/Constant'
     */
    LKAS_DW.Memory_PreviousInput_j = ((uint16)0U);

    /* End of Outputs for SubSystem: '<S116>/if action 2' */
  }

  /* End of If: '<S116>/If' */

  /* Sum: '<S117>/Add' incorporates:
   *  Constant: '<S117>/Constant'
   *  Memory: '<S117>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_gf = (uint16)((uint32)((uint16)1U) +
    LKAS_DW.Memory_PreviousInput_gf);

  /* Memory: '<S110>/Memory1' */
  rtb_Memory1 = LKAS_DW.Memory1_PreviousInput;

  /* Saturate: '<S117>/Saturation1' */
  if (LKAS_DW.Memory_PreviousInput_gf < ((uint16)100U)) {
    rtb_Add_0 = LKAS_DW.Memory_PreviousInput_gf;
  } else {
    rtb_Add_0 = ((uint16)100U);
  }

  /* End of Saturate: '<S117>/Saturation1' */

  /* If: '<S117>/If' incorporates:
   *  Constant: '<S117>/Constant19'
   */
  if (rtb_Add_0 == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S117>/if action 4' incorporates:
     *  ActionPort: '<S124>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1);

    /* End of Outputs for SubSystem: '<S117>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S117>/if action 3' incorporates:
     *  ActionPort: '<S123>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory1, &rtb_Merge1);

    /* End of Outputs for SubSystem: '<S117>/if action 3' */
  }

  /* End of If: '<S117>/If' */

  /* Sum: '<S118>/Add' incorporates:
   *  Constant: '<S118>/Constant'
   *  Memory: '<S118>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_n5 = (uint16)((uint32)((uint16)1U) +
    LKAS_DW.Memory_PreviousInput_n5);

  /* Memory: '<S110>/Memory2' */
  rtb_Memory2 = LKAS_DW.Memory2_PreviousInput;

  /* Saturate: '<S118>/Saturation1' */
  if (LKAS_DW.Memory_PreviousInput_n5 < ((uint16)100U)) {
    rtb_Add_0 = LKAS_DW.Memory_PreviousInput_n5;
  } else {
    rtb_Add_0 = ((uint16)100U);
  }

  /* End of Saturate: '<S118>/Saturation1' */

  /* If: '<S118>/If' incorporates:
   *  Constant: '<S118>/Constant19'
   */
  if (rtb_Add_0 == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S118>/if action 4' incorporates:
     *  ActionPort: '<S126>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_h);

    /* End of Outputs for SubSystem: '<S118>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S118>/if action 3' incorporates:
     *  ActionPort: '<S125>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory2, &rtb_Merge1_h);

    /* End of Outputs for SubSystem: '<S118>/if action 3' */
  }

  /* End of If: '<S118>/If' */

  /* Sum: '<S119>/Add' incorporates:
   *  Constant: '<S119>/Constant'
   *  Memory: '<S119>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_bj = (uint16)((uint32)((uint16)1U) +
    LKAS_DW.Memory_PreviousInput_bj);

  /* Memory: '<S110>/Memory3' */
  rtb_Memory3 = LKAS_DW.Memory3_PreviousInput_a;

  /* Saturate: '<S119>/Saturation1' */
  if (LKAS_DW.Memory_PreviousInput_bj < ((uint16)100U)) {
    rtb_Add_0 = LKAS_DW.Memory_PreviousInput_bj;
  } else {
    rtb_Add_0 = ((uint16)100U);
  }

  /* End of Saturate: '<S119>/Saturation1' */

  /* If: '<S119>/If' incorporates:
   *  Constant: '<S119>/Constant19'
   */
  if (rtb_Add_0 == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S119>/if action 4' incorporates:
     *  ActionPort: '<S128>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_g);

    /* End of Outputs for SubSystem: '<S119>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S119>/if action 3' incorporates:
     *  ActionPort: '<S127>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory3, &rtb_Merge1_g);

    /* End of Outputs for SubSystem: '<S119>/if action 3' */
  }

  /* End of If: '<S119>/If' */

  /* Sum: '<S120>/Add' incorporates:
   *  Constant: '<S120>/Constant'
   *  Memory: '<S120>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_e3 = (uint16)((uint32)((uint16)1U) +
    LKAS_DW.Memory_PreviousInput_e3);

  /* Memory: '<S110>/Memory4' */
  rtb_Memory4 = LKAS_DW.Memory4_PreviousInput;

  /* Saturate: '<S120>/Saturation1' */
  if (LKAS_DW.Memory_PreviousInput_e3 < ((uint16)100U)) {
    rtb_Add_0 = LKAS_DW.Memory_PreviousInput_e3;
  } else {
    rtb_Add_0 = ((uint16)100U);
  }

  /* End of Saturate: '<S120>/Saturation1' */

  /* If: '<S120>/If' incorporates:
   *  Constant: '<S120>/Constant19'
   */
  if (rtb_Add_0 == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S120>/if action 4' incorporates:
     *  ActionPort: '<S130>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_i);

    /* End of Outputs for SubSystem: '<S120>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S120>/if action 3' incorporates:
     *  ActionPort: '<S129>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory4, &rtb_Merge1_i);

    /* End of Outputs for SubSystem: '<S120>/if action 3' */
  }

  /* End of If: '<S120>/If' */

  /* MATLAB Function: '<S110>/MATLAB Function' */
  DelteSW0 = LKAS_B.In_d * 0.0174532924F;
  u = LKAS_B.In_f / 3.6F;
  Kw = u / ((LKAS_B.StbFacm_SY * u * u + 1.0F) * LKAS_B.LKA_WhlBaseL_C_e *
            LKAS_B.LKA_StrRatio_C_g);
  rtb_K1K2Det_stReplFlag = 0.0F;
  StpLngth = LKAS_B.LL_lStpLngth_C_j * 0.0174532924F;
  LKAS_DW.Memory1_PreviousInput = rtb_Merge1;
  LKAS_DW.Memory2_PreviousInput = rtb_Merge1_h;
  LKAS_DW.Memory3_PreviousInput_a = rtb_Merge1_g;
  LKAS_DW.Memory4_PreviousInput = rtb_Merge1_i;
  K1 = 0.0F;
  K2 = 0.0F;
  K2_2 = 0.0F;
  if (LKAS_DW.Memory_PreviousInput_j == 0) {
    K1 = -2.0F * LKAS_B.In_p / (Kw * LKAS_B.MPInP_tiTTLCIni *
      LKAS_B.MPInP_tiTTLCIni) - 2.0F * DelteSW0 / LKAS_B.MPInP_tiTTLCIni;
    LKAS_DW.Memory4_PreviousInput = K1 * LKAS_B.MPInP_tiTTLCIni + DelteSW0;
    Delte_Psi = (DelteSW0 + LKAS_DW.Memory4_PreviousInput) * 0.5F *
      LKAS_B.MPInP_tiTTLCIni * Kw + LKAS_B.In_ni;
    K2 = -LKAS_DW.Memory4_PreviousInput * LKAS_DW.Memory4_PreviousInput * Kw /
      ((LKAS_B.In_a - Delte_Psi) * 2.0F);
    c_T1 = (LKAS_DW.Memory4_PreviousInput - DelteSW0) / K1;
    c_T2 = (0.0F - LKAS_DW.Memory4_PreviousInput) / K2;
    K2_2 = K2;
    LKAS_DW.Memory3_PreviousInput_a = ((2.0F * DelteSW0 +
      LKAS_DW.Memory4_PreviousInput) * (0.166666672F * Kw) * c_T1 * c_T1 +
      LKAS_B.In_ni * c_T1) * u + (0.333333343F * Kw * c_T2 * c_T2 *
      LKAS_DW.Memory4_PreviousInput + Delte_Psi * c_T2) * u;
  }

  Delte_Psi = LKAS_DW.Memory3_PreviousInput_a * LKAS_B.Merge;
  if ((0.0F < Delte_Psi) && (Delte_Psi <= LKAS_B.LL_DesDvt_C_m) &&
      (LKAS_DW.Memory_PreviousInput_j == 0)) {
    rtb_K1K2Det_stReplFlag = 0.0F;
  } else {
    if ((Delte_Psi > LKAS_B.LL_DesDvt_C_m) || (LKAS_DW.Memory_PreviousInput_j !=
         0)) {
      rtb_K1K2Det_stReplFlag = 1.0F;
      for (a = 0; a < 8; a++) {
        Delte_Psi = LKAS_DW.Memory3_PreviousInput_a * LKAS_B.Merge;
        if ((Delte_Psi > LKAS_B.LL_DesDvt_C_m) &&
            (LKAS_DW.Memory_PreviousInput_j == 0)) {
          LKAS_DW.Memory_PreviousInput_j = 1U;
        }

        if ((Delte_Psi > LKAS_B.LL_DesDvt_C_m) &&
            (LKAS_DW.Memory_PreviousInput_j == 1)) {
          LKAS_DW.Memory4_PreviousInput += LKAS_B.Merge * StpLngth;
          LKAS_DW.Memory1_PreviousInput++;
        }

        if ((Delte_Psi <= LKAS_B.LL_DesDvt_C_m) &&
            (LKAS_DW.Memory_PreviousInput_j == 1)) {
          LKAS_DW.Memory_PreviousInput_j = 2U;
        }

        if ((Delte_Psi < LKAS_B.LL_DesDvt_C_m) &&
            (LKAS_DW.Memory_PreviousInput_j == 2)) {
          LKAS_DW.Memory4_PreviousInput -= LKAS_B.Merge * StpLngth * powf(0.5F,
            LKAS_DW.Memory2_PreviousInput + 1.0F);
          LKAS_DW.Memory2_PreviousInput++;
        }

        if ((Delte_Psi >= LKAS_B.LL_DesDvt_C_m) &&
            (LKAS_DW.Memory_PreviousInput_j == 2)) {
          LKAS_DW.Memory4_PreviousInput += LKAS_B.Merge * StpLngth * powf(0.5F,
            LKAS_DW.Memory2_PreviousInput + 1.0F);
          LKAS_DW.Memory2_PreviousInput++;
        }

        K2_2 = (LKAS_DW.Memory4_PreviousInput * LKAS_DW.Memory4_PreviousInput -
                DelteSW0 * DelteSW0) * Kw / (-2.0F * LKAS_B.In_p);
        if (LKAS_B.Merge * K2_2 > LKAS_B.SWARmax) {
          K2_2 = LKAS_B.Merge * LKAS_B.SWARmax;
        }

        T1 = (LKAS_DW.Memory4_PreviousInput - DelteSW0) / K2_2;
        K2_2 = (DelteSW0 + LKAS_DW.Memory4_PreviousInput) * 0.5F * T1 * Kw +
          LKAS_B.In_ni;
        T2 = (LKAS_B.In_a - K2_2) * 2.0F / (LKAS_DW.Memory4_PreviousInput * Kw);
        LKAS_DW.Memory3_PreviousInput_a = ((2.0F * DelteSW0 +
          LKAS_DW.Memory4_PreviousInput) * (0.166666672F * Kw) * T1 * T1 +
          LKAS_B.In_ni * T1) * u + (0.333333343F * Kw * T2 * T2 *
          LKAS_DW.Memory4_PreviousInput + K2_2 * T2) * u;
      }

      K1 = (LKAS_DW.Memory4_PreviousInput - DelteSW0) / T1;
      K2 = (0.0F - LKAS_DW.Memory4_PreviousInput) / T2;
      K2_2 = K2;
    }
  }

  LKAS_B.K1K2Det_phi2PhSWAIni = LKAS_DW.Memory4_PreviousInput * 57.2957802F;
  LKAS_B.K1K2Det_dphi1PhSWAGrad = K1 * 57.2957802F;
  LKAS_B.K1K2Det_dphi2PhSWAGrad1 = K2 * 57.2957802F;
  rtb_K1K2Det_dphi2PhSWAGrad2 = K2_2 * 57.2957802F;
  rtb_K1K2Det_dphi1PhHdAgIni = LKAS_B.In_p;

  /* End of MATLAB Function: '<S110>/MATLAB Function' */
}

/*
 * Output and update for action system:
 *    '<S133>/if action '
 *    '<S134>/if action '
 *    '<S135>/if action '
 *    '<S136>/if action '
 *    '<S137>/if action '
 *    '<S138>/if action '
 *    '<S157>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S143>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S158>/If Action Subsystem'
 *    '<S158>/If Action Subsystem4'
 *    '<S114>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S160>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S175>/If Action Subsystem'
 *    '<S175>/If Action Subsystem1'
 *    '<S175>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem_j(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S177>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S196>/if action '
 *    '<S197>/if action '
 *    '<S204>/if action '
 *    '<S205>/if action '
 */
void LKAS_ifaction_c(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S198>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S189>/If Action Subsystem'
 *    '<S190>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_g(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_c_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S189>/If Action Subsystem' incorporates:
   *  EnablePort: '<S194>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S196>/Add' incorporates:
     *  Constant: '<S196>/Constant'
     *  Memory: '<S196>/Memory'
     */
    localDW->Memory_PreviousInput = (uint16)((uint32)((uint16)1U) +
      localDW->Memory_PreviousInput);

    /* Saturate: '<S196>/Saturation1' */
    if (localDW->Memory_PreviousInput >= ((uint16)10000U)) {
      /* Sum: '<S196>/Add' */
      localDW->Memory_PreviousInput = ((uint16)10000U);
    }

    /* End of Saturate: '<S196>/Saturation1' */

    /* If: '<S196>/If' incorporates:
     *  Constant: '<S196>/Constant2'
     */
    if (localDW->Memory_PreviousInput <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S196>/if action ' incorporates:
       *  ActionPort: '<S198>/Action Port'
       */
      LKAS_ifaction_c(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S196>/if action ' */
    }

    /* End of If: '<S196>/If' */

    /* Sum: '<S197>/Add' incorporates:
     *  Constant: '<S197>/Constant'
     *  Memory: '<S197>/Memory'
     */
    localDW->Memory_PreviousInput_m = (uint16)((uint32)((uint16)1U) +
      localDW->Memory_PreviousInput_m);

    /* Saturate: '<S197>/Saturation1' */
    if (localDW->Memory_PreviousInput_m >= ((uint16)10000U)) {
      /* Sum: '<S197>/Add' */
      localDW->Memory_PreviousInput_m = ((uint16)10000U);
    }

    /* End of Saturate: '<S197>/Saturation1' */

    /* If: '<S197>/If' incorporates:
     *  Constant: '<S197>/Constant2'
     */
    if (localDW->Memory_PreviousInput_m == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S197>/if action ' incorporates:
       *  ActionPort: '<S199>/Action Port'
       */
      LKAS_ifaction_c(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S197>/if action ' */
    }

    /* End of If: '<S197>/If' */
  }

  /* End of Outputs for SubSystem: '<S189>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S189>/If Action Subsystem2'
 *    '<S190>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_l(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S195>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S195>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/*
 * Output and update for action system:
 *    '<S215>/If Action Subsystem3'
 *    '<S236>/If Action Subsystem3'
 *    '<S237>/If Action Subsystem3'
 *    '<S254>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(float32 rtu_In1, float32 rtu_In2, float32 *rty_Out1)
{
  /* Gain: '<S227>/Gain' incorporates:
   *  Sum: '<S227>/Add'
   */
  *rty_Out1 = (rtu_In1 + rtu_In2) * 0.5F;
}

/*
 * Output and update for atomic system:
 *    '<S220>/MATLAB Function'
 *    '<S221>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_u1, float32 rtu_u2, float32 *rty_y)
{
  *rty_y = rtu_u1 * cosf(rtu_u2);
}

/* System reset for atomic system: '<S75>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_j = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_i = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c38_LKAS = 0U;
  LKAS_DW.is_c38_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_B.LDWSM_stLDWActvFlg = 0U;
  LKAS_B.LDWSM_stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S75>/LDW_State_Machine'
 * Block description for: '<S75>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S75>/LDW_State_Machine'
   *
   * Block description for '<S75>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  if (LKAS_DW.is_active_c38_LKAS == 0U) {
    LKAS_DW.is_active_c38_LKAS = 1U;
    LKAS_DW.is_c38_LKAS = LKAS_IN_SysOff;
    LKAS_DW.is_SysOff_j = LKAS_IN_Unavailable;
    LKAS_B.LDWSM_stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c38_LKAS) {
     case LKAS_IN_Fault:
      tmp = !LKAS_B.LKA_Fault;
      if (tmp && ((LKAS_B.Divide == 1) || (LKAS_B.Divide == 2))) {
        LKAS_DW.is_c38_LKAS = LKAS_IN_SysOn;
        LKAS_DW.is_SysOn_i = LKAS_IN_LDWSelected;
        LKAS_B.LDWSM_stLDWState = 2U;
      } else if ((LKAS_B.Divide == 0) && tmp) {
        LKAS_DW.is_c38_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_j = LKAS_IN_Unselected;
        LKAS_B.LDWSM_stLDWState = 1U;
      } else {
        LKAS_B.LDWSM_stLDWState = 6U;
      }
      break;

     case LKAS_IN_SysOff:
      if (((LKAS_B.Divide == 1) || (LKAS_B.Divide == 2)) && LKAS_B.LKA_Fault) {
        LKAS_DW.is_SysOff_j = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c38_LKAS = LKAS_IN_Fault;
        LKAS_B.LDWSM_stLDWState = 6U;
      } else if ((LKAS_B.Divide == 1) || (LKAS_B.Divide == 2)) {
        LKAS_DW.is_SysOff_j = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c38_LKAS = LKAS_IN_SysOn;
        LKAS_DW.is_SysOn_i = LKAS_IN_LDWSelected;
        LKAS_B.LDWSM_stLDWState = 2U;
      } else if (LKAS_DW.is_SysOff_j == LKAS_IN_Unavailable) {
        LKAS_B.LDWSM_stLDWState = 0U;
        if (LKAS_B.Divide == 0) {
          LKAS_DW.is_SysOff_j = LKAS_IN_Unselected;
          LKAS_B.LDWSM_stLDWState = 1U;
        }
      } else {
        LKAS_B.LDWSM_stLDWState = 1U;
      }
      break;

     default:
      if (LKAS_B.LKA_Fault) {
        if (LKAS_DW.is_SysOn_i == LKAS_IN_Normal) {
          switch (LKAS_DW.is_Normal_l) {
           case LKAS_IN_LDWLeftActive:
            LKAS_B.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            LKAS_B.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_i = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_i = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c38_LKAS = LKAS_IN_Fault;
        LKAS_B.LDWSM_stLDWState = 6U;
      } else if ((LKAS_B.Divide != 1) && (LKAS_B.Divide != 2)) {
        if (LKAS_DW.is_SysOn_i == LKAS_IN_Normal) {
          switch (LKAS_DW.is_Normal_l) {
           case LKAS_IN_LDWLeftActive:
            LKAS_B.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            LKAS_B.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_i = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_i = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c38_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_j = LKAS_IN_Unselected;
        LKAS_B.LDWSM_stLDWState = 1U;
      } else if (LKAS_DW.is_SysOn_i == LKAS_IN_LDWSelected) {
        LKAS_B.LDWSM_stLDWState = 2U;
        if (LKAS_B.Merge_k && (!LKAS_B.Merge1_j)) {
          LKAS_DW.is_SysOn_i = LKAS_IN_Normal;
          LKAS_DW.is_Normal_l = LKAS_IN_LDWEnable;
          LKAS_B.LDWSM_stLDWState = 3U;
        }
      } else if (LKAS_B.Merge1_j) {
        switch (LKAS_DW.is_Normal_l) {
         case LKAS_IN_LDWLeftActive:
          LKAS_B.LDWSM_stLDWActvFlg = 0U;
          LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
          break;

         case LKAS_IN_LDWRightActive:
          LKAS_B.LDWSM_stLDWActvFlg = 0U;
          LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
          break;

         default:
          LKAS_DW.is_Normal_l = LKAS_IN_NO_ACTIVE_CHILD;
          break;
        }

        LKAS_DW.is_SysOn_i = LKAS_IN_LDWSelected;
        LKAS_B.LDWSM_stLDWState = 2U;
      } else {
        switch (LKAS_DW.is_Normal_l) {
         case LKAS_IN_LDWEnable:
          LKAS_B.LDWSM_stLDWState = 3U;
          if ((LKAS_B.Merge_i == 1) && (!LKAS_B.Merge_f)) {
            LKAS_DW.is_Normal_l = LKAS_IN_LDWLeftActive;
            LKAS_B.LDWSM_stLDWState = 4U;
            LKAS_B.LDWSM_stLDWActvFlg = 1U;
          } else {
            if ((LKAS_B.Merge_i == 2) && (!LKAS_B.Merge_f)) {
              LKAS_DW.is_Normal_l = LKAS_IN_LDWRightActive;
              LKAS_B.LDWSM_stLDWState = 5U;
              LKAS_B.LDWSM_stLDWActvFlg = 2U;
            }
          }
          break;

         case LKAS_IN_LDWLeftActive:
          LKAS_B.LDWSM_stLDWState = 4U;
          if (LKAS_B.Merge_f) {
            LKAS_B.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_l = LKAS_IN_LDWEnable;
            LKAS_B.LDWSM_stLDWState = 3U;
          } else {
            if ((LKAS_B.Merge_i == 2) && (!LKAS_B.Merge_f)) {
              LKAS_DW.is_Normal_l = LKAS_IN_LDWRightActive;
              LKAS_B.LDWSM_stLDWState = 5U;
              LKAS_B.LDWSM_stLDWActvFlg = 2U;
            }
          }
          break;

         default:
          LKAS_B.LDWSM_stLDWState = 5U;
          if (LKAS_B.Merge_f) {
            LKAS_B.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_l = LKAS_IN_LDWEnable;
            LKAS_B.LDWSM_stLDWState = 3U;
          } else {
            if ((LKAS_B.Merge_i == 1) && (!LKAS_B.Merge_f)) {
              LKAS_DW.is_Normal_l = LKAS_IN_LDWLeftActive;
              LKAS_B.LDWSM_stLDWState = 4U;
              LKAS_B.LDWSM_stLDWActvFlg = 1U;
            }
          }
          break;
        }
      }
      break;
    }
  }

  /* End of Chart: '<S75>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S75>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_l;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_l;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
  LKAS_DW.is_active_c39_LKAS = 0U;
  LKAS_DW.is_c39_LKAS = LKAS_IN_NO_ACTIVE_CHILD_l;
  LKAS_B.LKASM_stLKAActvFlg = 0U;
  LKAS_B.LKASM_stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S75>/LKA_State_Machine'
 * Block description for: '<S75>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S75>/LKA_State_Machine'
   *
   * Block description for '<S75>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  if (LKAS_DW.is_active_c39_LKAS == 0U) {
    LKAS_DW.is_active_c39_LKAS = 1U;
    LKAS_DW.is_c39_LKAS = LKAS_IN_SysOff_a;
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_a;
    LKAS_B.LKASM_stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c39_LKAS) {
     case LKAS_IN_Fault_e:
      tmp = !LKAS_B.LKA_Fault;
      if (tmp && (LKAS_B.Divide == 2)) {
        LKAS_DW.is_c39_LKAS = LKAS_IN_SysOn_c;
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;
        LKAS_B.LKASM_stLKAState = 2U;
      } else if (((LKAS_B.Divide == 0) || (LKAS_B.Divide == 1)) && tmp) {
        LKAS_DW.is_c39_LKAS = LKAS_IN_SysOff_a;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_m;
        LKAS_B.LKASM_stLKAState = 1U;
      } else {
        LKAS_B.LKASM_stLKAState = 6U;
      }
      break;

     case LKAS_IN_SysOff_a:
      if ((LKAS_B.Divide == 2) && LKAS_B.LKA_Fault) {
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_l;
        LKAS_DW.is_c39_LKAS = LKAS_IN_Fault_e;
        LKAS_B.LKASM_stLKAState = 6U;
      } else if (LKAS_B.Divide == 2) {
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_l;
        LKAS_DW.is_c39_LKAS = LKAS_IN_SysOn_c;
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;
        LKAS_B.LKASM_stLKAState = 2U;
      } else if (LKAS_DW.is_SysOff == LKAS_IN_Unavailable_a) {
        LKAS_B.LKASM_stLKAState = 0U;
        if ((LKAS_B.Divide == 0) || (LKAS_B.Divide == 1)) {
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_m;
          LKAS_B.LKASM_stLKAState = 1U;
        }
      } else {
        LKAS_B.LKASM_stLKAState = 1U;
      }
      break;

     default:
      if (LKAS_B.LKA_Fault) {
        if (LKAS_DW.is_SysOn == LKAS_IN_Normal_l) {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            LKAS_B.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
            break;

           case LKAS_IN_LKARightActive:
            LKAS_B.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_l;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_l;
        }

        LKAS_DW.is_c39_LKAS = LKAS_IN_Fault_e;
        LKAS_B.LKASM_stLKAState = 6U;
      } else if (LKAS_B.Divide != 2) {
        if (LKAS_DW.is_SysOn == LKAS_IN_Normal_l) {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            LKAS_B.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
            break;

           case LKAS_IN_LKARightActive:
            LKAS_B.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_l;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_l;
        }

        LKAS_DW.is_c39_LKAS = LKAS_IN_SysOff_a;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_m;
        LKAS_B.LKASM_stLKAState = 1U;
      } else if (LKAS_DW.is_SysOn == LKAS_IN_LKASelected) {
        LKAS_B.LKASM_stLKAState = 2U;
        if (LKAS_B.Merge1_g && (!LKAS_B.Merge2_h)) {
          LKAS_DW.is_SysOn = LKAS_IN_Normal_l;
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;
          LKAS_B.LKASM_stLKAState = 3U;
        }
      } else if (LKAS_B.Merge2_h) {
        switch (LKAS_DW.is_Normal) {
         case LKAS_IN_LKALeftActive:
          LKAS_B.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
          break;

         case LKAS_IN_LKARightActive:
          LKAS_B.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
          break;

         default:
          LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_l;
          break;
        }

        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;
        LKAS_B.LKASM_stLKAState = 2U;
      } else {
        switch (LKAS_DW.is_Normal) {
         case LKAS_IN_LKAEnable:
          LKAS_B.LKASM_stLKAState = 3U;
          if ((LKAS_B.Merge2 == 1) && (!LKAS_B.Merge1_b)) {
            LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;
            LKAS_B.LKASM_stLKAState = 4U;
            LKAS_B.LKASM_stLKAActvFlg = 1U;
          } else {
            if ((LKAS_B.Merge2 == 2) && (!LKAS_B.Merge1_b)) {
              LKAS_DW.is_Normal = LKAS_IN_LKARightActive;
              LKAS_B.LKASM_stLKAState = 5U;
              LKAS_B.LKASM_stLKAActvFlg = 2U;
            }
          }
          break;

         case LKAS_IN_LKALeftActive:
          LKAS_B.LKASM_stLKAState = 4U;
          if (LKAS_B.Merge1_b) {
            LKAS_B.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_LKAEnable;
            LKAS_B.LKASM_stLKAState = 3U;
          } else {
            if ((LKAS_B.Merge2 == 2) && (!LKAS_B.Merge1_b)) {
              LKAS_DW.is_Normal = LKAS_IN_LKARightActive;
              LKAS_B.LKASM_stLKAState = 5U;
              LKAS_B.LKASM_stLKAActvFlg = 2U;
            }
          }
          break;

         default:
          LKAS_B.LKASM_stLKAState = 5U;
          if (LKAS_B.Merge1_b) {
            LKAS_B.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_LKAEnable;
            LKAS_B.LKASM_stLKAState = 3U;
          } else {
            if ((LKAS_B.Merge2 == 1) && (!LKAS_B.Merge1_b)) {
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;
              LKAS_B.LKASM_stLKAState = 4U;
              LKAS_B.LKASM_stLKAActvFlg = 1U;
            }
          }
          break;
        }
      }
      break;
    }
  }

  /* End of Chart: '<S75>/LKA_State_Machine' */
}

/*
 * Output and update for action system:
 *    '<S300>/Ph1SWA'
 *    '<S309>/Ph1SWA'
 *    '<S339>/Ph1SWA'
 *    '<S348>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S304>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S304>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S300>/Ph2SWA'
 *    '<S309>/Ph2SWA'
 *    '<S339>/Ph2SWA'
 *    '<S348>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S305>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S305>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S300>/Ph3SWA'
 *    '<S309>/Ph3SWA'
 *    '<S339>/Ph3SWA'
 *    '<S348>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S306>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S306>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S361>/If Action Subsystem3'
 *    '<S399>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3_m(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S366>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S374>/If Action Subsystem4'
 *    '<S374>/If Action Subsystem3'
 *    '<S486>/If Action Subsystem3'
 *    '<S486>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S385>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S385>/Constant'
   */
  *rty_Out = false;
}

/*
 * Output and update for action system:
 *    '<S414>/If Action Subsystem'
 *    '<S414>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_e(boolean *rty_Out)
{
  /* SignalConversion: '<S418>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S418>/Constant'
   */
  *rty_Out = true;
}

/*
 * System initialize for enable system:
 *    '<S282>/Count_5s1'
 *    '<S282>/Count_5s2'
 *    '<S282>/Count_5s3'
 */
void LKAS_Count_5s1_Init(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Sum: '<S559>/Add' incorporates:
   *  Memory: '<S559>/Memory'
   */
  localDW->Memory_PreviousInput = ((uint16)0U);
}

/*
 * System reset for enable system:
 *    '<S282>/Count_5s1'
 *    '<S282>/Count_5s2'
 *    '<S282>/Count_5s3'
 */
void LKAS_Count_5s1_Reset(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Sum: '<S559>/Add' incorporates:
   *  Memory: '<S559>/Memory'
   */
  localDW->Memory_PreviousInput = ((uint16)0U);
}

/*
 * Disable for enable system:
 *    '<S282>/Count_5s1'
 *    '<S282>/Count_5s2'
 *    '<S282>/Count_5s3'
 */
void LKAS_Count_5s1_Disable(boolean *rty_Out, DW_Count_5s1_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S282>/Count_5s1' incorporates:
   *  EnablePort: '<S559>/Enable'
   */
  /* Disable for Outport: '<S559>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S282>/Count_5s1' */
  localDW->Count_5s1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S282>/Count_5s1'
 *    '<S282>/Count_5s2'
 *    '<S282>/Count_5s3'
 */
void LKAS_Count_5s1(boolean rtu_Enable, float32 rtu_LKA_SampleTime, boolean
                    *rty_Out, DW_Count_5s1_LKAS_T *localDW)
{
  float32 tmp;

  /* Outputs for Enabled SubSystem: '<S282>/Count_5s1' incorporates:
   *  EnablePort: '<S559>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Reset(localDW);
      localDW->Count_5s1_MODE = true;
    }

    /* Sum: '<S559>/Add' incorporates:
     *  Constant: '<S559>/Constant'
     *  Memory: '<S559>/Memory'
     */
    localDW->Memory_PreviousInput = (uint16)((uint32)
      localDW->Memory_PreviousInput + ((uint16)1U));

    /* Saturate: '<S559>/Saturation' */
    if (localDW->Memory_PreviousInput >= ((uint16)11000U)) {
      /* Sum: '<S559>/Add' */
      localDW->Memory_PreviousInput = ((uint16)11000U);
    }

    /* End of Saturate: '<S559>/Saturation' */

    /* DataTypeConversion: '<S559>/Cast To Single' incorporates:
     *  Constant: '<S559>/Constant1'
     *  Product: '<S559>/Divide'
     */
    tmp = fmodf(floorf((float32)((uint16)5U) / rtu_LKA_SampleTime), 65536.0F);

    /* RelationalOperator: '<S559>/Relational Operator' incorporates:
     *  DataTypeConversion: '<S559>/Cast To Single'
     */
    *rty_Out = (localDW->Memory_PreviousInput >= (tmp < 0.0F ? (sint32)(uint16)-
      (sint16)(uint16)-tmp : (sint32)(uint16)tmp));
  } else {
    if (localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S282>/Count_5s1' */
}

/*
 * System initialize for enable system:
 *    '<S282>/Count_5s4'
 *    '<S282>/Count_5s5'
 */
void LKAS_Count_5s4_Init(DW_Count_5s4_LKAS_T *localDW)
{
  /* InitializeConditions for Sum: '<S562>/Add' incorporates:
   *  Memory: '<S562>/Memory'
   */
  localDW->Memory_PreviousInput = ((uint16)0U);
}

/*
 * System reset for enable system:
 *    '<S282>/Count_5s4'
 *    '<S282>/Count_5s5'
 */
void LKAS_Count_5s4_Reset(DW_Count_5s4_LKAS_T *localDW)
{
  /* InitializeConditions for Sum: '<S562>/Add' incorporates:
   *  Memory: '<S562>/Memory'
   */
  localDW->Memory_PreviousInput = ((uint16)0U);
}

/*
 * Disable for enable system:
 *    '<S282>/Count_5s4'
 *    '<S282>/Count_5s5'
 */
void LKAS_Count_5s4_Disable(boolean *rty_Out, DW_Count_5s4_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S282>/Count_5s4' incorporates:
   *  EnablePort: '<S562>/Enable'
   */
  /* Disable for Outport: '<S562>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S282>/Count_5s4' */
  localDW->Count_5s4_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S282>/Count_5s4'
 *    '<S282>/Count_5s5'
 */
void LKAS_Count_5s4(boolean rtu_Enable, float32 rtu_LKA_SampleTime, boolean
                    *rty_Out, DW_Count_5s4_LKAS_T *localDW)
{
  float32 tmp;

  /* Outputs for Enabled SubSystem: '<S282>/Count_5s4' incorporates:
   *  EnablePort: '<S562>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->Count_5s4_MODE) {
      LKAS_Count_5s4_Reset(localDW);
      localDW->Count_5s4_MODE = true;
    }

    /* Sum: '<S562>/Add' incorporates:
     *  Constant: '<S562>/Constant'
     *  Memory: '<S562>/Memory'
     */
    localDW->Memory_PreviousInput = (uint16)((uint32)
      localDW->Memory_PreviousInput + ((uint16)1U));

    /* Saturate: '<S562>/Saturation' */
    if (localDW->Memory_PreviousInput >= ((uint16)11000U)) {
      /* Sum: '<S562>/Add' */
      localDW->Memory_PreviousInput = ((uint16)11000U);
    }

    /* End of Saturate: '<S562>/Saturation' */

    /* DataTypeConversion: '<S562>/Cast To Single' incorporates:
     *  Constant: '<S562>/Constant1'
     *  Product: '<S562>/Divide'
     */
    tmp = fmodf(floorf((float32)((uint16)5U) / rtu_LKA_SampleTime), 65536.0F);

    /* RelationalOperator: '<S562>/Relational Operator' incorporates:
     *  DataTypeConversion: '<S562>/Cast To Single'
     */
    *rty_Out = (localDW->Memory_PreviousInput >= (tmp < 0.0F ? (sint32)(uint16)-
      (sint16)(uint16)-tmp : (sint32)(uint16)tmp));
  } else {
    if (localDW->Count_5s4_MODE) {
      LKAS_Count_5s4_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S282>/Count_5s4' */
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_IMAPve_g_ESC_VehSpd;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_L0_C0_a;
  float32 rtb_R0_C0_e;
  float32 rtb_Gain_o;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_Gain_b;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_LFClb_TFC_DiffCtrlRatio;
  float32 rtb_LKA_SampleTime;
  float32 rtb_R0_VR_d;
  float32 rtb_L0_VR_g;
  float32 rtb_R0_W_k;
  float32 rtb_L0_W_c;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L0_C0_m;
  float32 rtb_L0_C1_n;
  float32 rtb_L0_C2_i;
  float32 rtb_L0_C3_d;
  float32 rtb_IMAPve_g_L0_Confidence;
  float32 rtb_L0_TLC_i;
  float32 rtb_L0_VR_n;
  float32 rtb_L0_W_i;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_IMAPve_g_L1_Confidence;
  float32 rtb_L1_TLC;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_L1_C0_k;
  float32 rtb_L1_C1_a;
  float32 rtb_L1_C2_k;
  float32 rtb_L1_C3_j;
  float32 rtb_L1_TLC_m;
  float32 rtb_L1_VR_n;
  float32 rtb_L1_W_e;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_TLC;
  float32 rtb_R1_VR;
  float32 rtb_R1_W;
  float32 rtb_R0_C0_k;
  float32 rtb_R0_C1_i;
  float32 rtb_R0_C2_j;
  float32 rtb_R0_C3_f;
  float32 rtb_IMAPve_g_R0_Confidence;
  float32 rtb_R0_TLC_p;
  float32 rtb_R0_VR_j;
  float32 rtb_R0_W_m;
  float32 rtb_R1_C0_j;
  float32 rtb_R1_C1_i;
  float32 rtb_R1_C2_n;
  float32 rtb_R1_C3_p;
  float32 rtb_IMAPve_g_R1_Confidence;
  float32 rtb_R1_TLC_h;
  float32 rtb_R1_VR_g;
  float32 rtb_R1_W_a;
  float32 rtb_IMAPve_g_SW_Angle_Speed;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_Add_hn;
  float32 rtb_Add_j;
  float32 rtb_Gain1_i;
  float32 rtb_Add5_j;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_Merge_k;
  float32 rtb_Switch;
  float32 rtb_Saturation_e;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_TSamp;
  float32 rtb_Diff;
  float32 rtb_UnaryMinus;
  float32 rtb_Add1_g;
  float32 rtb_Switch_o;
  float32 rtb_Switch2;
  float32 rtb_Switch_j;
  float32 rtb_Saturation_d;
  float32 rtb_Abs1_i;
  float32 rtb_Abs_m;
  float32 rtb_TSamp_n;
  float32 rtb_Diff_j;
  float32 rtb_UnaryMinus_k;
  float32 rtb_Merge1_k;
  float32 rtb_Divide_p;
  float32 rtb_Switch_d;
  float32 rtb_Switch2_m;
  float32 rtb_Divide_k;
  float32 rtb_Switch_on;
  float32 rtb_Switch2_d;
  float32 rtb_Merge1_k5;
  float32 rtb_Divide_kt;
  float32 rtb_Switch_g;
  float32 rtb_Switch2_l;
  float32 rtb_Divide_an;
  float32 rtb_Switch_ov;
  float32 rtb_Switch2_k;
  float32 rtb_Add1_k;
  float32 rtb_Switch_k;
  float32 rtb_Switch2_c;
  float32 rtb_Merge1_d;
  float32 rtb_Divide_f;
  float32 rtb_Switch_ob;
  float32 rtb_Switch2_o;
  float32 rtb_Divide_m;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_g;
  float32 rtb_Merge1_dq;
  float32 rtb_Divide_kz;
  float32 rtb_Switch_p;
  float32 rtb_Switch2_ds;
  float32 rtb_Divide_l1;
  float32 rtb_Switch_pw;
  float32 rtb_Switch2_h;
  float32 rtb_Merge_p;
  float32 rtb_Add_b;
  float32 rtb_Add_g5;
  float32 rtb_Merge_kn;
  float32 rtb_Gain_pe;
  float32 rtb_LKA_ExitFlg_Mon;
  float32 rtb_LKA_SampleTime_Mon;
  float32 rtb_T1_Mon;
  float32 rtb_Add_fj;
  float32 rtb_phiPrdcHdAgLft;
  float32 rtb_phiPrdcHdAgRgt;
  float32 rtb_Merge_ky;
  float32 rtb_Add2_m;
  float32 rtb_Add_eq;
  float32 rtb_Add3;
  float32 rtb_RGTTTLC_Mon;
  float32 rtb_LFTTTLC_Mon;
  float32 rtb_Merge_m;
  float32 rtb_Merge_a;
  float32 rtb_Abs1_l;
  float32 rtb_Abs_i;
  float32 rtb_Add1_kk;
  float32 rtb_Merge_mb;
  float32 rtb_Add_c3;
  float32 rtb_Saturation6_h;
  float32 rtb_Divide2_p;
  float32 rtb_ExNum;
  float32 rtb_Saturation_d3;
  float32 rtb_Saturation_bw;
  float32 rtb_Add1_f;
  float32 rtb_Saturation_n;
  float32 rtb_Switch2_d2;
  float32 rtb_Switch_b;
  float32 rtb_Divide5;
  float32 rtb_Divide2_d;
  float32 rtb_Divide7;
  float32 rtb_Switch_f;
  float32 rtb_Switch2_m5;
  float32 rtb_Saturation_ge;
  float32 rtb_Add_mq;
  float32 rtb_Switch_gc;
  float32 rtb_Switch2_b;
  float32 rtb_UkYk1;
  float32 rtb_Switch_dl;
  float32 rtb_Switch2_lq;
  float32 rtb_Saturation2;
  float32 rtb_Saturation2_g;
  float32 rtb_Saturation2_a;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_o;
  float32 rtb_Saturation_dy;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_T2;
  float32 rtb_phiSWA0;
  float32 rtb_Plan;
  float32 rtb_T1_f;
  float32 rtb_Plan_n;
  float32 rtb_T1_o;
  float32 rtb_y_n;
  float32 rtb_Add2_p;
  float32 rtb_y_a;
  float32 rtb_deltafalllimit_b;
  float32 rtb_Gain2_a;
  float32 rtb_Yk1_eq;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_l;
  uint16 rtb_Saturation1_la;
  uint16 rtb_Saturation1_b;
  uint16 rtb_Add_p2;
  uint16 rtb_Saturation1_f;
  uint16 rtb_Saturation1_b2;
  uint16 rtb_Saturation1_e;
  uint16 rtb_Saturation1_m;
  uint16 rtb_Saturation2_m;
  uint8 rtb_IMAPve_d_LKA_Main_Switch;
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_LKA_Mode_from_Camera;
  uint8 rtb_R0_Type_p;
  uint8 rtb_L0_Type_a;
  uint8 rtb_R0_LC_l;
  uint8 rtb_L0_LC_g;
  uint8 rtb_IMAPve_d_Camera_Signal_Faul;
  uint8 rtb_IMAPve_d_Camera_Status;
  uint8 rtb_IMAPve_d_ConsArea;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L0_LC_l;
  uint8 rtb_L0_Q_l;
  uint8 rtb_L0_Type_m;
  uint8 rtb_L1_LC;
  uint8 rtb_L1_Q_l;
  uint8 rtb_L1_Type;
  uint8 rtb_IMAPve_d_LDW_Warn_Mode;
  uint8 rtb_IMAPve_d_Lane_Valid;
  uint8 rtb_L1_LC_f;
  uint8 rtb_L1_Type_c;
  uint8 rtb_IMAPve_d_ORI_Lane_ConsArea;
  uint8 rtb_IMAPve_d_ORI_Lane_RoadType;
  uint8 rtb_IMAPve_d_ORI_Lane_Valid;
  uint8 rtb_R1_LC;
  uint8 rtb_R1_Type;
  uint8 rtb_R0_LC_b;
  uint8 rtb_R0_Q_d;
  uint8 rtb_R0_Type_l;
  uint8 rtb_R1_LC_f;
  uint8 rtb_R1_Q_d;
  uint8 rtb_R1_Type_g;
  uint8 rtb_IMAPve_d_Road_Type;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_LDW_State;
  uint8 rtb_LKA_State_Mon;
  uint8 rtb_LDW_State_Mon;
  uint8 rtb_DACMode;
  uint8 rtb_Saturation1_ks;
  boolean rtb_Compare_i;
  boolean rtb_Compare_ho;
  boolean rtb_Event_FaulETATDA;
  boolean rtb_Compare_c;
  boolean rtb_Compare_k0;
  boolean rtb_Compare_cj;
  boolean rtb_Compare_ku;
  boolean rtb_Compare_b5;
  boolean rtb_Compare_gr;
  boolean rtb_Compare_pd;
  boolean rtb_Compare_kl;
  boolean rtb_Event_FaulSWS;
  boolean rtb_Compare_ef;
  boolean rtb_UnitDelay_a;
  boolean rtb_Compare_oq;
  boolean rtb_Merge_k2;
  boolean rtb_Merge_i;
  boolean rtb_Compare_cg;
  boolean rtb_UnitDelay_d;
  boolean rtb_Compare_ki;
  boolean rtb_Merge_d;
  boolean rtb_LogicalOperator1_l;
  boolean rtb_Compare_am;
  boolean rtb_Compare_mm;
  boolean rtb_LogicalOperator1_b;
  boolean rtb_Compare_mq;
  boolean rtb_Compare_ox;
  boolean rtb_Compare_hl;
  boolean rtb_Compare_ny;
  boolean rtb_Compare_b0;
  boolean rtb_Compare_dg;
  boolean rtb_Compare_ga;
  boolean rtb_RelationalOperator6_f;
  boolean rtb_RelationalOperator5;
  float32 x10;
  float32 x20;
  float32 x1;
  uint8 rtb_IMAPve_d_BCM_HazardLamp;
  uint8 rtb_IMAPve_d_BCM_Left_Light;
  uint8 rtb_IMAPve_d_BCM_Right_Light;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  uint8 rtb_IMAPve_d_TCU_Actual_Gear;
  UInt8 rtb_EPS_LKA_Control;
  float32 rtb_Abs_h;
  float32 rtb_L0_C0;
  float32 rtb_L0_C2;
  float32 rtb_R0_C2;
  float32 rtb_Saturation;
  float32 rtb_Saturation_ki;
  uint8 rtb_L0_Type;
  uint8 rtb_R0_Type;
  float32 rtb_R0_C1;
  float32 rtb_L0_C3;
  float32 rtb_R0_C3;
  float32 rtb_L0_TLC;
  uint8 rtb_L0_Q;
  uint8 rtb_R0_Q;
  float32 rtb_L0_C2_p;
  float32 rtb_L0_C3_fd;
  float32 rtb_L0_TLC_h;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_LFClb_TFC_vGainLutVehS_j;
  float32 rtb_LL_LFClb_TFC_facmGainLutGai;
  float32 rtb_LL_LKASWASyn_TrqSwaAddSwt;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LL_ThresDet_lDvtThresUprL_g;
  float32 rtb_TTLC_f;
  float32 rtb_Saturation10;
  float32 rtb_TTLC;
  float32 rtb_Divide_a3;
  float32 rtb_Abs_k;
  boolean rtb_LogicalOperator3_n;
  boolean rtb_LogicalOperator2_p;
  float32 rtb_Abs_e;
  boolean rtb_LogicalOperator3_c;
  float32 rtb_Saturation4;
  float32 rtb_LL_ThresDet_lDvtThresLwrL_k;
  sint8 rtPrevAction;
  uint16 rtb_Add1_hb;
  float32 rtb_TLft;
  float32 tmp;
  sint32 rtb_Switch3_0;
  float32 rtb_LL_ThresDet_lDvtThresUprL_h;
  float32 rtb_Abs1_tmp;
  float32 rtb_TSamp_tmp;
  float32 rtb_Add5_j_tmp;
  float32 rtb_Add1_g_tmp;
  float32 rtb_Add_hn_tmp;
  float32 rtb_Add_j_tmp;
  float32 rtb_Divide_it_tmp;

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp'
   */
  rtb_IMAPve_d_BCM_HazardLamp = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_Left_Light'
   */
  rtb_IMAPve_d_BCM_Left_Light = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_Right_Light'
   */
  rtb_IMAPve_d_BCM_Right_Light = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_LKA_State'
   */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LKA_Main_Switch'
   */
  rtb_IMAPve_d_LKA_Main_Switch = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_Actual_Gear'
   */
  rtb_IMAPve_d_TCU_Actual_Gear = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  rtb_IMAPve_g_EPS_SW_Trq =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  rtb_IMAPve_g_ESC_LonAcc =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  rtb_IMAPve_g_ESC_VehSpd =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  rtb_IMAPve_g_SW_Angle =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle();

  /* Product: '<S11>/Divide' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1'
   *  Inport: '<Root>/IMAPve_d_LKA_Mode'
   */
  LKAS_B.Divide = (uint8)((uint32)rtb_IMAPve_d_LKA_Main_Switch * (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode());

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_L0_Q'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L0_Q_IMAPve_d_ORI_L0_Q();

  /* Switch: '<S55>/Switch' incorporates:
   *  Constant: '<S55>/Constant'
   */
  if (rtb_EPS_LKA_Control >= ((uint8)2U)) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S55>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_R0_Q'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R0_Q_IMAPve_d_ORI_R0_Q();

  /* Switch: '<S54>/Switch1' incorporates:
   *  Constant: '<S54>/Constant1'
   */
  if (rtb_EPS_LKA_Control >= ((uint8)2U)) {
    rtb_R0_Q = ((uint8)3U);
  } else {
    rtb_R0_Q = rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S54>/Switch1' */

  /* Chart: '<S52>/LaneReconstructSM' */
  if (LKAS_DW.is_active_c14_LKAS == 0U) {
    LKAS_DW.is_active_c14_LKAS = 1U;
    LKAS_DW.is_c14_LKAS = LKAS_IN_NoLaneLost;
    LKAS_B.LaneRSM_stLftFlg = 1U;
    LKAS_B.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c14_LKAS) {
     case LKAS_IN_DoubleLost:
      if ((rtb_L0_Q == 3) && (rtb_R0_Q == 3)) {
        LKAS_DW.is_c14_LKAS = LKAS_IN_NoLaneLost;
        LKAS_B.LaneRSM_stLftFlg = 1U;
        LKAS_B.LaneRSM_stRgtFlg = 1U;
      } else if ((rtb_L0_Q == 3) && (rtb_R0_Q < 3)) {
        LKAS_DW.is_c14_LKAS = LKAS_IN_RightLost;
        LKAS_B.LaneRSM_stLftFlg = 1U;
        LKAS_B.LaneRSM_stRgtFlg = 0U;
      } else {
        if ((rtb_L0_Q < 3) && (rtb_R0_Q == 3)) {
          LKAS_DW.is_c14_LKAS = LKAS_IN_LeftLost;
          LKAS_B.LaneRSM_stLftFlg = 0U;
          LKAS_B.LaneRSM_stRgtFlg = 1U;
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_B.LaneRSM_stLftFlg = 0U;
      LKAS_B.LaneRSM_stRgtFlg = 1U;
      if ((rtb_L0_Q == 3) && (rtb_R0_Q == 3)) {
        LKAS_DW.is_c14_LKAS = LKAS_IN_NoLaneLost;
        LKAS_B.LaneRSM_stLftFlg = 1U;
        LKAS_B.LaneRSM_stRgtFlg = 1U;
      } else if ((rtb_L0_Q == 3) && (rtb_R0_Q < 3)) {
        LKAS_DW.is_c14_LKAS = LKAS_IN_RightLost;
        LKAS_B.LaneRSM_stLftFlg = 1U;
        LKAS_B.LaneRSM_stRgtFlg = 0U;
      } else {
        if (rtb_R0_Q < 3) {
          LKAS_DW.is_c14_LKAS = LKAS_IN_DoubleLost;
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_B.LaneRSM_stLftFlg = 1U;
      LKAS_B.LaneRSM_stRgtFlg = 1U;
      if ((rtb_L0_Q < 3) && (rtb_R0_Q == 3)) {
        LKAS_DW.is_c14_LKAS = LKAS_IN_LeftLost;
        LKAS_B.LaneRSM_stLftFlg = 0U;
        LKAS_B.LaneRSM_stRgtFlg = 1U;
      } else if ((rtb_L0_Q == 3) && (rtb_R0_Q < 3)) {
        LKAS_DW.is_c14_LKAS = LKAS_IN_RightLost;
        LKAS_B.LaneRSM_stLftFlg = 1U;
        LKAS_B.LaneRSM_stRgtFlg = 0U;
      } else {
        if ((rtb_L0_Q < 3) && (rtb_R0_Q < 3)) {
          LKAS_DW.is_c14_LKAS = LKAS_IN_DoubleLost;
        }
      }
      break;

     default:
      LKAS_B.LaneRSM_stLftFlg = 1U;
      LKAS_B.LaneRSM_stRgtFlg = 0U;
      if ((rtb_L0_Q == 3) && (rtb_R0_Q == 3)) {
        LKAS_DW.is_c14_LKAS = LKAS_IN_NoLaneLost;
        LKAS_B.LaneRSM_stLftFlg = 1U;
        LKAS_B.LaneRSM_stRgtFlg = 1U;
      } else if ((rtb_L0_Q < 3) && (rtb_R0_Q == 3)) {
        LKAS_DW.is_c14_LKAS = LKAS_IN_LeftLost;
        LKAS_B.LaneRSM_stLftFlg = 0U;
        LKAS_B.LaneRSM_stRgtFlg = 1U;
      } else {
        if (rtb_L0_Q < 3) {
          LKAS_DW.is_c14_LKAS = LKAS_IN_DoubleLost;
        }
      }
      break;
    }
  }

  /* End of Chart: '<S52>/LaneReconstructSM' */

  /* DataTypeConversion: '<S51>/Cast To Single30' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C0'
   */
  rtb_L0_C0 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C0_IMAPve_g_ORI_L0_C0
    ();

  /* DataTypeConversion: '<S51>/Cast To Single31' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C2_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C2'
   */
  rtb_L0_C2 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C2_IMAPve_g_ORI_L0_C2
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C2_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C2'
   */
  rtb_Abs_h = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C2_IMAPve_g_ORI_R0_C2
    ();

  /* DataTypeConversion: '<S51>/Cast To Single23' */
  rtb_R0_C2 = rtb_Abs_h;

  /* Sum: '<S62>/Add2' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single23'
   */
  rtb_Abs_h += rtb_L0_C2;

  /* Abs: '<S62>/Abs' */
  rtb_Abs_h = fabsf(rtb_Abs_h);

  /* Saturate: '<S62>/Saturation' */
  if (rtb_Abs_h > 0.004F) {
    rtb_Saturation = 0.004F;
  } else if (rtb_Abs_h < 0.0F) {
    rtb_Saturation = 0.0F;
  } else {
    rtb_Saturation = rtb_Abs_h;
  }

  /* End of Saturate: '<S62>/Saturation' */

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C0_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C0'
   */
  rtb_Abs_h = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C0_IMAPve_g_ORI_R0_C0
    ();

  /* Sum: '<S69>/Add1' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single22'
   *  Gain: '<S67>/Gain'
   *  Memory: '<S69>/Memory'
   *  Product: '<S69>/Divide'
   *  Product: '<S69>/Divide1'
   *  Sum: '<S67>/Add'
   */
  LKAS_DW.Memory_PreviousInput = ((-1.0F) * rtb_L0_C0 + rtb_Abs_h) *
    LKAS_ConstB.Divide2 + LKAS_ConstB.Add2 * LKAS_DW.Memory_PreviousInput;

  /* Saturate: '<S67>/Saturation' */
  if (LKAS_DW.Memory_PreviousInput > 5.5F) {
    rtb_Saturation_ki = 5.5F;
  } else if (LKAS_DW.Memory_PreviousInput < 2.5F) {
    rtb_Saturation_ki = 2.5F;
  } else {
    rtb_Saturation_ki = LKAS_DW.Memory_PreviousInput;
  }

  /* End of Saturate: '<S67>/Saturation' */

  /* MATLAB Function: '<S62>/get_roadside_offset' */
  rtb_Saturation = fminf(0.5F, (fminf(0.004F, rtb_Saturation) / 0.004F + 1.0F) *
    0.2F * (fminf(4.0F, rtb_Saturation_ki) - 2.0F));

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_L0_Type'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L0_Type_IMAPve_d_ORI_L0_Type();

  /* DataTypeConversion: '<S51>/Cast To Single6' */
  rtb_L0_Type = rtb_EPS_LKA_Control;

  /* Switch: '<S62>/Switch' incorporates:
   *  Constant: '<S65>/Constant'
   *  DataTypeConversion: '<S51>/Cast To Single6'
   *  RelationalOperator: '<S65>/Compare'
   *  Sum: '<S62>/Add'
   */
  if (rtb_EPS_LKA_Control == ((uint8)2U)) {
    rtb_L0_C0 += rtb_Saturation;
  }

  /* End of Switch: '<S62>/Switch' */

  /* Sum: '<S63>/Add1' incorporates:
   *  Memory: '<S63>/Memory'
   *  Product: '<S63>/Divide'
   *  Product: '<S63>/Divide1'
   */
  LKAS_DW.Memory_PreviousInput_m = rtb_L0_C0 * LKAS_ConstB.Divide2_l +
    LKAS_ConstB.Add2_a * LKAS_DW.Memory_PreviousInput_m;

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_LT_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_R0_LT'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R0_LT_IMAPve_d_ORI_R0_LT();

  /* DataTypeConversion: '<S51>/Cast To Single16' */
  rtb_R0_Type = rtb_EPS_LKA_Control;

  /* Switch: '<S62>/Switch1' incorporates:
   *  Constant: '<S66>/Constant'
   *  DataTypeConversion: '<S51>/Cast To Single16'
   *  DataTypeConversion: '<S51>/Cast To Single22'
   *  RelationalOperator: '<S66>/Compare'
   *  Sum: '<S62>/Add1'
   */
  if (rtb_EPS_LKA_Control == ((uint8)2U)) {
    rtb_Abs_h -= rtb_Saturation;
  }

  /* End of Switch: '<S62>/Switch1' */

  /* Sum: '<S64>/Add1' incorporates:
   *  Memory: '<S64>/Memory'
   *  Product: '<S64>/Divide'
   *  Product: '<S64>/Divide1'
   */
  LKAS_DW.Memory_PreviousInput_c = rtb_Abs_h * LKAS_ConstB.Divide2_o +
    LKAS_ConstB.Add2_m * LKAS_DW.Memory_PreviousInput_c;

  /* DataTypeConversion: '<S51>/Cast To Single28' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C1_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C1'
   */
  rtb_L0_C0 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C1_IMAPve_g_ORI_L0_C1
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C1_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C1'
   */
  rtb_Abs_h = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C1_IMAPve_g_ORI_R0_C1
    ();

  /* DataTypeConversion: '<S51>/Cast To Single21' */
  rtb_R0_C1 = rtb_Abs_h;

  /* Switch: '<S52>/Switch1' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single21'
   *  DataTypeConversion: '<S59>/Cast To Single2'
   *  Gain: '<S59>/Gain'
   *  Sum: '<S59>/Add'
   */
  if (LKAS_B.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_a = LKAS_DW.Memory_PreviousInput_m;
    rtb_Saturation = rtb_L0_C0;
    rtb_L0_C2_p = rtb_L0_C2;
  } else {
    rtb_L0_C0_a = (rtb_Saturation_ki - LKAS_DW.Memory_PreviousInput_c) * (-1.0F);
    rtb_Saturation = rtb_Abs_h;
    rtb_L0_C2_p = rtb_R0_C2;
  }

  /* DataTypeConversion: '<S51>/Cast To Single33' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C3_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C3'
   */
  rtb_L0_C3 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C3_IMAPve_g_ORI_L0_C3
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C3_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C3'
   */
  rtb_Abs_h = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C3_IMAPve_g_ORI_R0_C3
    ();

  /* DataTypeConversion: '<S51>/Cast To Single27' */
  rtb_R0_C3 = rtb_Abs_h;

  /* Switch: '<S52>/Switch1' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single27'
   */
  if (LKAS_B.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C3_fd = rtb_L0_C3;
  } else {
    rtb_L0_C3_fd = rtb_Abs_h;
  }

  /* DataTypeConversion: '<S51>/Cast To Single34' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_TLC_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_TLC'
   */
  rtb_L0_TLC =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_TLC_IMAPve_g_ORI_L0_TLC();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_TLC_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_TLC'
   */
  rtb_Abs_h =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_TLC_IMAPve_g_ORI_R0_TLC();

  /* Switch: '<S52>/Switch1' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single38'
   */
  if (LKAS_B.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_TLC_h = rtb_L0_TLC;
  } else {
    rtb_L0_TLC_h = rtb_Abs_h;
  }

  /* Switch: '<S52>/Switch' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single38'
   *  Sum: '<S61>/Add'
   */
  if (LKAS_B.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_C0_e = LKAS_DW.Memory_PreviousInput_c;
    rtb_L0_C0 = rtb_R0_C1;
    rtb_L0_C2 = rtb_R0_C2;
    rtb_L0_C3 = rtb_R0_C3;
    rtb_L0_TLC = rtb_Abs_h;
  } else {
    rtb_R0_C0_e = rtb_Saturation_ki + LKAS_DW.Memory_PreviousInput_m;
  }

  /* Switch: '<S567>/Switch2' incorporates:
   *  Constant: '<S567>/LL_MIN_LKAS_SPEED_ENABLE=60'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion24;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S567>/Switch2' */

  /* Gain: '<S570>/Gain' incorporates:
   *  Constant: '<S570>/Constant'
   *  Sum: '<S570>/Add'
   */
  rtb_Gain_o = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S567>/Switch5' incorporates:
   *  Constant: '<S567>/LL_MAX_SYSTEM_CURVATURE_ENABLE=0.004'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S567>/Switch5' */

  /* Switch: '<S567>/Switch6' incorporates:
   *  Constant: '<S567>/LL_MIN_LANE_WIDTH_ENABLE=2.5'
   */
  if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion28;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S567>/Switch6' */

  /* Switch: '<S567>/Switch7' incorporates:
   *  Constant: '<S567>/LL_MAX_LANE_WIDTH_ENABLE=5.4'
   */
  if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion29;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S567>/Switch7' */

  /* Switch: '<S567>/Switch15' incorporates:
   *  Constant: '<S567>/LL_MAX_LONG_ACC_ENABLE=3'
   */
  if (LKAS_ConstB.DataTypeConversion35 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion35;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S567>/Switch15' */

  /* Switch: '<S567>/Switch17' incorporates:
   *  Constant: '<S567>/LL_LKAS_OUT_OF_CONTROL_LAT_VEL=1.5'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S567>/Switch17' */

  /* Switch: '<S567>/Switch12' incorporates:
   *  Constant: '<S567>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion39 != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion39;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S567>/Switch12' */

  /* Switch: '<S567>/Switch13' incorporates:
   *  Constant: '<S567>/LL_LDW_EarliestWarnLine_C=0.3'
   */
  if (LKAS_ConstB.DataTypeConversion40 != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion40;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S567>/Switch13' */

  /* Switch: '<S567>/Switch21' incorporates:
   *  Constant: '<S567>/LL_LDW_LatestWarnLine_C=-0.4'
   */
  if (LKAS_ConstB.DataTypeConversion41 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion41;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S567>/Switch21' */

  /* Switch: '<S567>/Switch19' incorporates:
   *  Constant: '<S567>/LL_LKA_EarliestWarnLine_C=0.3'
   */
  if (LKAS_ConstB.DataTypeConversion42 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion42;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S567>/Switch19' */

  /* Switch: '<S567>/Switch20' incorporates:
   *  Constant: '<S567>/LL_LKA_LatestWarnLine_C=-0.5'
   */
  if (LKAS_ConstB.DataTypeConversion43 != 0.0F) {
    rtb_Abs_h = LKAS_ConstB.DataTypeConversion43;
  } else {
    rtb_Abs_h = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S567>/Switch20' */

  /* Switch: '<S567>/Switch3' incorporates:
   *  Constant: '<S567>/LL_MIN_LKAS_SPEED_DISABLE=55'
   */
  if (LKAS_ConstB.DataTypeConversion51 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion51;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S567>/Switch3' */

  /* Gain: '<S573>/Gain' incorporates:
   *  Constant: '<S573>/Constant'
   *  Sum: '<S573>/Add'
   */
  rtb_Gain_b = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S567>/Switch29' incorporates:
   *  Constant: '<S567>/LL_MAX_SYSTEM_CURVATURE_DISABLE=0.005'
   */
  if (LKAS_ConstB.DataTypeConversion48 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion48;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S567>/Switch29' */

  /* Switch: '<S567>/Switch30' incorporates:
   *  Constant: '<S567>/LL_MIN_LANE_WIDTH_DISABLE=2.4'
   */
  if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion49;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S567>/Switch30' */

  /* Switch: '<S567>/Switch31' incorporates:
   *  Constant: '<S567>/LL_MAX_LANE_WIDTH_DISABLE=5.5'
   */
  if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion50;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S567>/Switch31' */

  /* Switch: '<S567>/Switch33' incorporates:
   *  Constant: '<S567>/LL_MAX_DRIVER_TORQUE_DISABLE=1.6'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S567>/Switch33' */

  /* Switch: '<S567>/Switch23' incorporates:
   *  Constant: '<S567>/LL_MAX_LONG_ACC_DISABLE=3.5'
   */
  if (LKAS_ConstB.DataTypeConversion59 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion59;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S567>/Switch23' */

  /* Switch: '<S567>/Switch27' incorporates:
   *  Constant: '<S567>/LL_TkOvStChk_tiTDelTime=2'
   */
  if (LKAS_ConstB.DataTypeConversion63 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion63;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S567>/Switch27' */

  /* Switch: '<S567>/Switch42' incorporates:
   *  Constant: '<S567>/LL_ThresDet_lDvtThresLwr=0.15'
   */
  if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion3;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S567>/Switch42' */

  /* Switch: '<S567>/Switch43' incorporates:
   *  Constant: '<S567>/LL_ThresDet_lDvtThresUpr=0.3'
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion4;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S567>/Switch43' */

  /* Switch: '<S567>/Switch45' incorporates:
   *  Constant: '<S567>/LL_ThresDet_tiTTLCThres=0.75'
   */
  if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion2;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S567>/Switch45' */

  /* Switch: '<S567>/Switch35' incorporates:
   *  Constant: '<S567>/LL_ThresDet_lDvtThresLwrLKA=0.3'
   */
  if (LKAS_ConstB.DataTypeConversion79 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion79;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S567>/Switch35' */

  /* Switch: '<S567>/Switch36' incorporates:
   *  Constant: '<S567>/LL_ThresDet_lDvtThresUprLKA=0.6'
   */
  if (LKAS_ConstB.DataTypeConversion81 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion81;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S567>/Switch36' */

  /* Switch: '<S567>/Switch37' incorporates:
   *  Constant: '<S567>/LL_ThresDet_tiTTLCThresLKA=1.5'
   */
  if (LKAS_ConstB.DataTypeConversion71 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion71;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S567>/Switch37' */

  /* Switch: '<S567>/Switch39' incorporates:
   *  Constant: '<S567>/LL_DvtSpdDet_vDvtSpdMin_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion73 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion73;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S567>/Switch39' */

  /* Switch: '<S566>/Switch1' incorporates:
   *  Constant: '<S566>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1_h != 0.0F) {
    rtb_R0_C2 = LKAS_ConstB.DataTypeConversion1_h;
  } else {
    rtb_R0_C2 = LL_DvtComp_C;
  }

  /* End of Switch: '<S566>/Switch1' */

  /* Switch: '<S566>/Switch10' incorporates:
   *  Constant: '<S566>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22_a != 0.0F) {
    LKAS_B.LL_DesDvt_C_m = LKAS_ConstB.DataTypeConversion22_a;
  } else {
    LKAS_B.LL_DesDvt_C_m = LL_DesDvt_C;
  }

  /* End of Switch: '<S566>/Switch10' */

  /* Switch: '<S566>/Switch15' incorporates:
   *  Constant: '<S566>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    LKAS_B.LL_lStpLngth_C_j = LKAS_ConstB.DataTypeConversion21;
  } else {
    LKAS_B.LL_lStpLngth_C_j = LL_lStpLngth_C;
  }

  /* End of Switch: '<S566>/Switch15' */

  /* Switch: '<S566>/Switch31' incorporates:
   *  Constant: '<S566>/LL_LFClb_TFC_vGainLutVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
    rtb_R0_C3 = LKAS_ConstB.DataTypeConversion14;
  } else {
    rtb_R0_C3 = LL_LFClb_TFC_vGainLutVehSpdLwr_C;
  }

  /* End of Switch: '<S566>/Switch31' */

  /* Switch: '<S566>/Switch34' incorporates:
   *  Constant: '<S566>/LL_LFClb_TFC_vGainLutVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4_e != 0.0F) {
    rtb_LL_LFClb_TFC_vGainLutVehS_j = LKAS_ConstB.DataTypeConversion4_e;
  } else {
    rtb_LL_LFClb_TFC_vGainLutVehS_j = LL_LFClb_TFC_vGainLutVehSpdUpr_C;
  }

  /* End of Switch: '<S566>/Switch34' */

  /* Switch: '<S566>/Switch33' incorporates:
   *  Constant: '<S566>/LL_LFClb_TFC_facmGainLutGain1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
    rtb_LL_LFClb_TFC_facmGainLutGai = LKAS_ConstB.DataTypeConversion7;
  } else {
    rtb_LL_LFClb_TFC_facmGainLutGai = LL_LFClb_TFC_facmGainLutGain1_C;
  }

  /* End of Switch: '<S566>/Switch33' */

  /* Switch: '<S566>/Switch48' incorporates:
   *  Constant: '<S566>/LL_LFClb_TFC_DiffCtrlRatio=600'
   */
  if (LKAS_ConstB.DataTypeConversion48_h != 0.0F) {
    rtb_LL_LFClb_TFC_DiffCtrlRatio = LKAS_ConstB.DataTypeConversion48_h;
  } else {
    rtb_LL_LFClb_TFC_DiffCtrlRatio = LL_LFClb_TFC_DiffCtrlRatio;
  }

  /* End of Switch: '<S566>/Switch48' */

  /* Switch: '<S566>/Switch47' incorporates:
   *  Constant: '<S566>/LL_LKASWASyn_TrqSwaAddSwt=1'
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LL_LKASWASyn_TrqSwaAddSwt;
  }

  /* End of Switch: '<S566>/Switch47' */

  /* Switch: '<S566>/Switch11' incorporates:
   *  Constant: '<S566>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S566>/Switch11' */

  /* Switch: '<S566>/Switch13' incorporates:
   *  Constant: '<S566>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S566>/Switch13' */

  /* Switch: '<S566>/Switch16' incorporates:
   *  Constant: '<S566>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24_g != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24_g;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S566>/Switch16' */

  /* Switch: '<S566>/Switch55' incorporates:
   *  Constant: '<S566>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55_n != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55_n;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S566>/Switch55' */

  /* Switch: '<S566>/Switch54' incorporates:
   *  Constant: '<S566>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54_a != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54_a;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S566>/Switch54' */

  /* Switch: '<S566>/Switch44' incorporates:
   *  Constant: '<S566>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33_i != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33_i;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S566>/Switch44' */

  /* Switch: '<S564>/Switch19' incorporates:
   *  Constant: '<S564>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_p != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_p;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S564>/Switch19' */

  /* Switch: '<S564>/Switch' incorporates:
   *  Constant: '<S564>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_g != 0.0F) {
    rtb_R0_C1 = LKAS_ConstB.DataTypeConversion13_g;
  } else {
    rtb_R0_C1 = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S564>/Switch' */

  /* Switch: '<S564>/Switch1' incorporates:
   *  Constant: '<S564>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_f != 0.0F) {
    rtb_Saturation_ki = LKAS_ConstB.DataTypeConversion2_f;
  } else {
    rtb_Saturation_ki = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S564>/Switch1' */

  /* Switch: '<S564>/Switch2' incorporates:
   *  Constant: '<S564>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_a != 0.0F) {
    LKAS_B.LKA_WhlBaseL_C_e = LKAS_ConstB.DataTypeConversion4_a;
  } else {
    LKAS_B.LKA_WhlBaseL_C_e = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S564>/Switch2' */

  /* Switch: '<S564>/Switch3' incorporates:
   *  Constant: '<S564>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_h != 0.0F) {
    LKAS_B.LKA_StrRatio_C_g = LKAS_ConstB.DataTypeConversion6_h;
  } else {
    LKAS_B.LKA_StrRatio_C_g = LKA_StrRatio_C;
  }

  /* End of Switch: '<S564>/Switch3' */

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/states'
   */
  if (rtb_IMAPve_d_LKA_Main_Switch > 0) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S74>/Delay' */
      LKAS_DW.Delay_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S531>/Memory' */
      LKAS_DW.Memory_PreviousInput_d = 0.0F;

      /* InitializeConditions for UnitDelay: '<S491>/UD'
       *
       * Block description for '<S491>/UD':
       *
       *  Store in Global RAM
       */
      LKAS_DW.UD_DSTATE = 0.0F;

      /* InitializeConditions for Memory: '<S475>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = 0.0F;

      /* InitializeConditions for UnitDelay: '<S392>/UD'
       *
       * Block description for '<S392>/UD':
       *
       *  Store in Global RAM
       */
      LKAS_DW.UD_DSTATE_c = 0.0F;

      /* InitializeConditions for UnitDelay: '<S401>/Delay Input1'
       *
       * Block description for '<S401>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S399>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_ba = false;

      /* InitializeConditions for UnitDelay: '<S400>/Delay Input1'
       *
       * Block description for '<S400>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_j = false;

      /* InitializeConditions for Delay: '<S75>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for UnitDelay: '<S363>/Delay Input1'
       *
       * Block description for '<S363>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_b = false;

      /* InitializeConditions for UnitDelay: '<S361>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_c = false;

      /* InitializeConditions for UnitDelay: '<S362>/Delay Input1'
       *
       * Block description for '<S362>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_p = false;

      /* InitializeConditions for Memory: '<S326>/Memory' */
      LKAS_DW.Memory_PreviousInput_eb = false;

      /* InitializeConditions for Delay: '<S75>/Delay' */
      LKAS_DW.Delay_DSTATE_e = false;

      /* InitializeConditions for Delay: '<S75>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S376>/Memory' */
      LKAS_DW.Memory_PreviousInput_ms = ((uint8)0U);

      /* InitializeConditions for Delay: '<S75>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S75>/LDW_State_Machine'
       *
       * Block description for '<S75>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S75>/LKA_State_Machine'
       *
       * Block description for '<S75>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Switch: '<S566>/Switch2' incorporates:
     *  Constant: '<S566>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S566>/Switch2' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S73>/states = reset'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S255>/kph to mps' incorporates:
     *  Gain: '<S112>/Gain'
     *  Gain: '<S153>/kph To mps'
     *  Gain: '<S169>/kph to mps'
     *  Gain: '<S170>/kph to mps'
     *  Gain: '<S213>/Gain2'
     *  Gain: '<S224>/kph to mps'
     *  Gain: '<S243>/kph to mps'
     *  Gain: '<S244>/kph to mps'
     *  Gain: '<S251>/kph To mps'
     *  Gain: '<S295>/Gain'
     *  Gain: '<S334>/Gain'
     */
    rtb_LL_ThresDet_lDvtThresUprL_h = 0.277777791F * rtb_IMAPve_g_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S255>/Divide' incorporates:
     *  Gain: '<S255>/kph to mps'
     */
    rtb_LL_ThresDet_lDvtThresUprL_g = rtb_LL_ThresDet_lDvtThresUprL_h * x10;

    /* Gain: '<S252>/Gain' incorporates:
     *  Gain: '<S241>/Gain'
     *  Gain: '<S242>/Gain'
     */
    rtb_Add_hn_tmp = 2.0F * rtb_L0_C2_p;

    /* Sum: '<S252>/Add' incorporates:
     *  Gain: '<S252>/Gain'
     *  Gain: '<S252>/Gain1'
     *  Product: '<S252>/Product'
     */
    rtb_Add_hn = 6.0F * rtb_L0_C3_fd * rtb_LL_ThresDet_lDvtThresUprL_g +
      rtb_Add_hn_tmp;

    /* Gain: '<S253>/Gain' incorporates:
     *  Gain: '<S239>/Gain'
     *  Gain: '<S240>/Gain'
     */
    rtb_Add_j_tmp = 2.0F * rtb_L0_C2;

    /* Sum: '<S253>/Add' incorporates:
     *  Gain: '<S253>/Gain'
     *  Gain: '<S253>/Gain1'
     *  Product: '<S253>/Product'
     */
    rtb_Add_j = 6.0F * rtb_L0_C3 * rtb_LL_ThresDet_lDvtThresUprL_g +
      rtb_Add_j_tmp;

    /* Saturate: '<S213>/Saturation5' */
    if (rtb_L0_TLC_h > 2.0F) {
      rtb_L0_TLC_h = 2.0F;
    } else {
      if (rtb_L0_TLC_h < 0.6F) {
        rtb_L0_TLC_h = 0.6F;
      }
    }

    /* End of Saturate: '<S213>/Saturation5' */

    /* Saturate: '<S213>/Saturation6' */
    if (rtb_L0_TLC > 2.0F) {
      rtb_L0_TLC = 2.0F;
    } else {
      if (rtb_L0_TLC < 0.6F) {
        rtb_L0_TLC = 0.6F;
      }
    }

    /* End of Saturate: '<S213>/Saturation6' */

    /* Sum: '<S217>/Add1' incorporates:
     *  Sum: '<S217>/Add'
     *  Sum: '<S426>/Add1'
     */
    rtb_LL_ThresDet_lDvtThresLwrL_k = (rtb_L0_C0_a - rtb_LL_DvtComp_C) +
      rtb_R0_C1;

    /* Gain: '<S217>/Gain1' incorporates:
     *  Product: '<S217>/Divide'
     *  Product: '<S217>/Divide1'
     *  Sum: '<S217>/Add1'
     *  Sum: '<S217>/Add5'
     *  Trigonometry: '<S217>/Cos2'
     *  Trigonometry: '<S217>/Sin'
     */
    rtb_Gain1_i = (rtb_LL_ThresDet_lDvtThresLwrL_k * cosf(rtb_Saturation) +
                   rtb_Saturation_ki * sinf(rtb_Saturation)) * (-1.0F);

    /* UnaryMinus: '<S213>/Unary Minus' incorporates:
     *  Product: '<S213>/Product'
     */
    rtb_LL_ThresDet_lDvtThresUprL_g = -(rtb_LL_ThresDet_lDvtThresUprL_h *
      rtb_Saturation);

    /* Saturate: '<S213>/Saturation9' */
    if (rtb_LL_ThresDet_lDvtThresUprL_g > 1.0F) {
      rtb_LL_ThresDet_lDvtThresUprL_g = 1.0F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprL_g < (-1.0F)) {
        rtb_LL_ThresDet_lDvtThresUprL_g = (-1.0F);
      }
    }

    /* End of Saturate: '<S213>/Saturation9' */

    /* MATLAB Function: '<S213>/MATLAB Function' */
    if ((rtb_Gain1_i > 0.0F) && (rtb_Gain1_i < 2.0F) &&
        (rtb_LL_ThresDet_lDvtThresUprL_g < 0.0F) &&
        (rtb_LL_ThresDet_lDvtThresUprL_g > -1.5F)) {
      rtb_TTLC_f = -rtb_Gain1_i / rtb_LL_ThresDet_lDvtThresUprL_g;
    } else {
      rtb_TTLC_f = 3.0F;
    }

    /* End of MATLAB Function: '<S213>/MATLAB Function' */

    /* Saturate: '<S213>/Saturation' */
    if (rtb_TTLC_f > 2.0F) {
      rtb_TTLC_f = 2.0F;
    } else {
      if (rtb_TTLC_f < 0.6F) {
        rtb_TTLC_f = 0.6F;
      }
    }

    /* End of Saturate: '<S213>/Saturation' */

    /* Sum: '<S223>/Add1' incorporates:
     *  Sum: '<S223>/Add'
     *  Sum: '<S427>/Add1'
     */
    rtb_Add5_j_tmp = (rtb_R0_C0_e - rtb_LL_DvtComp_C) - rtb_R0_C1;

    /* Sum: '<S223>/Add5' incorporates:
     *  Product: '<S223>/Divide'
     *  Product: '<S223>/Divide1'
     *  Sum: '<S223>/Add1'
     *  Trigonometry: '<S223>/Cos2'
     *  Trigonometry: '<S223>/Sin'
     */
    rtb_Add5_j = rtb_Add5_j_tmp * cosf(rtb_L0_C0) + rtb_Saturation_ki * sinf
      (rtb_L0_C0);

    /* Product: '<S213>/Product3' */
    rtb_Saturation10 = rtb_LL_ThresDet_lDvtThresUprL_h * rtb_L0_C0;

    /* Saturate: '<S213>/Saturation10' */
    if (rtb_Saturation10 > 1.0F) {
      rtb_Saturation10 = 1.0F;
    } else {
      if (rtb_Saturation10 < (-1.0F)) {
        rtb_Saturation10 = (-1.0F);
      }
    }

    /* End of Saturate: '<S213>/Saturation10' */

    /* MATLAB Function: '<S213>/MATLAB Function1' */
    if ((rtb_Add5_j > 0.0F) && (rtb_Add5_j < 2.0F) && (rtb_Saturation10 < 0.0F) &&
        (rtb_Saturation10 > -1.5F)) {
      rtb_TTLC = -rtb_Add5_j / rtb_Saturation10;
    } else {
      rtb_TTLC = 3.0F;
    }

    /* End of MATLAB Function: '<S213>/MATLAB Function1' */

    /* Saturate: '<S213>/Saturation1' */
    if (rtb_TTLC > 2.0F) {
      rtb_TTLC = 2.0F;
    } else {
      if (rtb_TTLC < 0.6F) {
        rtb_TTLC = 0.6F;
      }
    }

    /* End of Saturate: '<S213>/Saturation1' */

    /* Product: '<S213>/Divide1' incorporates:
     *  Constant: '<S213>/Constant'
     *  Constant: '<S213>/Constant3'
     */
    rtb_TLft = 0.09F / rtb_LL_ThresDet_lDvtThresUprL_h / 3.6F;

    /* Saturate: '<S213>/Saturation2' */
    if (rtb_TLft > 0.01F) {
      rtb_TLft = 0.01F;
    } else {
      if (rtb_TLft < 0.0F) {
        rtb_TLft = 0.0F;
      }
    }

    /* End of Saturate: '<S213>/Saturation2' */

    /* Gain: '<S265>/Gain1' incorporates:
     *  Gain: '<S238>/kph To mps'
     */
    rtb_Divide_it_tmp = 0.0174532924F * rtb_IMAPve_g_SW_Angle;

    /* Product: '<S213>/Divide' incorporates:
     *  Constant: '<S213>/Constant1'
     *  Constant: '<S213>/Constant2'
     *  Gain: '<S265>/Gain1'
     *  Math: '<S213>/Math Function'
     *  Product: '<S213>/Product1'
     *  Product: '<S213>/Product2'
     *  Sum: '<S213>/Add'
     *
     * About '<S213>/Math Function':
     *  Operator: magnitude^2
     */
    rtb_Divide_a3 = rtb_Divide_it_tmp / ((rtb_LL_ThresDet_lDvtThresUprL_h *
      rtb_LL_ThresDet_lDvtThresUprL_h * rtb_TLft + 1.0F) *
      LKAS_B.LKA_WhlBaseL_C_e * LKAS_B.LKA_StrRatio_C_g * 2.0F);

    /* MATLAB Function: '<S213>/MATLAB Function3' */
    x10 = rtb_L0_C2_p - rtb_Divide_a3;
    if ((x10 <= 0.001F) && ((rtb_Saturation > 0.0F) || (rtb_Saturation < 0.0F)))
    {
      x10 = (-rtb_L0_C0_a - rtb_R0_C1) / rtb_Saturation;
      if (x10 > 0.0F) {
        rtb_TLft = x10 / rtb_LL_ThresDet_lDvtThresUprL_h;
      } else {
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = rtb_Saturation * rtb_Saturation - x10 * 4.0F * (rtb_L0_C0_a +
        rtb_R0_C1);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        x1 = sqrtf(x20);
        x20 = x10 * 2.0F;
        x10 = (x1 + -rtb_Saturation) / x20;
        x20 = (-rtb_Saturation - x1) / x20;
        x1 = fmaxf(x10, x20);
        x10 = fminf(x10, x20);
        if (x10 > 0.0F) {
          rtb_TLft = x10 / rtb_LL_ThresDet_lDvtThresUprL_h;
        } else if (x1 > 0.0F) {
          rtb_TLft = x1 / rtb_LL_ThresDet_lDvtThresUprL_h;
        } else {
          rtb_TLft = 3.0F;
        }
      } else {
        rtb_TLft = 3.0F;
      }
    }

    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* End of MATLAB Function: '<S213>/MATLAB Function3' */

    /* MATLAB Function: '<S213>/MATLAB Function4' */
    x10 = rtb_L0_C2 - rtb_Divide_a3;
    if ((x10 <= 0.001F) && ((rtb_L0_C0 > 0.0F) || (rtb_L0_C0 < 0.0F))) {
      x10 = (-rtb_R0_C0_e + rtb_R0_C1) / rtb_L0_C0;
      if (x10 > 0.0F) {
        x10 /= rtb_LL_ThresDet_lDvtThresUprL_h;
      } else {
        x10 = 3.0F;
      }
    } else {
      x20 = rtb_L0_C0 * rtb_L0_C0 - x10 * 4.0F * (rtb_R0_C0_e - rtb_R0_C1);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        x1 = sqrtf(x20);
        x20 = x10 * 2.0F;
        x10 = (x1 + -rtb_L0_C0) / x20;
        x20 = (-rtb_L0_C0 - x1) / x20;
        x1 = fmaxf(x10, x20);
        x10 = fminf(x10, x20);
        if (x10 > 0.0F) {
          x10 /= rtb_LL_ThresDet_lDvtThresUprL_h;
        } else if (x1 > 0.0F) {
          x10 = x1 / rtb_LL_ThresDet_lDvtThresUprL_h;
        } else {
          x10 = 3.0F;
        }
      } else {
        x10 = 3.0F;
      }
    }

    x10 = fmaxf(0.6F, fminf(x10, 2.0F));

    /* End of MATLAB Function: '<S213>/MATLAB Function4' */

    /* MATLAB Function: '<S213>/MATLAB Function2' */
    if (fabsf(rtb_TTLC_f - rtb_L0_TLC_h) / rtb_TTLC_f <= 0.2F) {
      rtb_TTLC_f = fminf(rtb_TTLC_f, rtb_L0_TLC_h);
    }

    if (fabsf(rtb_TTLC - rtb_L0_TLC) / rtb_TTLC <= 0.2F) {
      rtb_TTLC = fminf(rtb_TTLC, rtb_L0_TLC);
    }

    if ((fabsf(rtb_Add_hn) > 0.001F) && (fabsf(rtb_TLft - rtb_TTLC_f) /
         rtb_TTLC_f <= 0.7F) && (rtb_TTLC_f <= 1.95F)) {
      rtb_TTLC_f = (rtb_TTLC_f + rtb_TLft) / 2.0F;
    }

    if ((fabsf(rtb_Add_j) > 0.001F) && (fabsf(x10 - rtb_TTLC) / rtb_TTLC <= 0.7F)
        && (rtb_TTLC <= 1.95F)) {
      rtb_TTLC = (rtb_TTLC + x10) / 2.0F;
    }

    /* Saturate: '<S213>/Saturation7' incorporates:
     *  MATLAB Function: '<S213>/MATLAB Function2'
     */
    if (rtb_TTLC_f > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_TTLC_f < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_TTLC_f;
    }

    /* End of Saturate: '<S213>/Saturation7' */

    /* Saturate: '<S213>/Saturation8' incorporates:
     *  MATLAB Function: '<S213>/MATLAB Function2'
     */
    if (rtb_TTLC > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC;
    }

    /* End of Saturate: '<S213>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S73>/states = reset'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S83>/Subsystem' incorporates:
     *  EnablePort: '<S91>/Enable'
     */
    /* Abs: '<S208>/Abs' incorporates:
     *  Abs: '<S103>/Abs2'
     *  Abs: '<S104>/Abs2'
     *  MATLAB Function: '<S91>/DriverSwaTrqAdd'
     */
    rtb_L0_TLC_h = fabsf(rtb_L0_C0_a);

    /* Abs: '<S208>/Abs1' incorporates:
     *  Abs: '<S103>/Abs3'
     *  Abs: '<S104>/Abs3'
     *  MATLAB Function: '<S91>/DriverSwaTrqAdd'
     */
    rtb_TTLC = fabsf(rtb_R0_C0_e);

    /* End of Outputs for SubSystem: '<S83>/Subsystem' */

    /* Sum: '<S208>/Add' incorporates:
     *  Abs: '<S208>/Abs'
     *  Abs: '<S208>/Abs1'
     *  Sum: '<S175>/Add6'
     *  Sum: '<S293>/Add1'
     *  Sum: '<S332>/Add1'
     */
    rtb_L0_TLC = rtb_L0_TLC_h + rtb_TTLC;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Saturate: '<S208>/Saturation' incorporates:
     *  Sum: '<S208>/Add'
     */
    if (rtb_L0_TLC > 6.0F) {
      rtb_Divide_a3 = 6.0F;
    } else if (rtb_L0_TLC < 2.0F) {
      rtb_Divide_a3 = 2.0F;
    } else {
      rtb_Divide_a3 = rtb_L0_TLC;
    }

    /* End of Saturate: '<S208>/Saturation' */

    /* If: '<S254>/If' incorporates:
     *  Delay: '<S74>/Delay'
     */
    if (LKAS_DW.Delay_DSTATE == 1) {
      /* Outputs for IfAction SubSystem: '<S254>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S257>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_hn, &rtb_Merge_k);

      /* End of Outputs for SubSystem: '<S254>/If Action Subsystem2' */
    } else if (LKAS_DW.Delay_DSTATE == 2) {
      /* Outputs for IfAction SubSystem: '<S254>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S256>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_j, &rtb_Merge_k);

      /* End of Outputs for SubSystem: '<S254>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S254>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S258>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_Add_hn, rtb_Add_j, &rtb_Merge_k);

      /* End of Outputs for SubSystem: '<S254>/If Action Subsystem3' */
    }

    /* End of If: '<S254>/If' */

    /* Switch: '<S533>/Switch' incorporates:
     *  Constant: '<S568>/Constant'
     *  Constant: '<S569>/Constant'
     *  Gain: '<S568>/Gain'
     *  Gain: '<S569>/Gain'
     *  Sum: '<S568>/Add'
     *  Sum: '<S569>/Add'
     *  Switch: '<S567>/Switch'
     */
    if (LKAS_B.Divide >= ((uint8)2U)) {
      /* Switch: '<S567>/Switch1' incorporates:
       *  Constant: '<S567>/LL_MAX_LKAS_SPEED_ENABLE=140'
       */
      if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion23;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S567>/Switch1' */
      rtb_Switch = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
        /* Switch: '<S567>/Switch' */
        x10 = LKAS_ConstB.DataTypeConversion22;
      } else {
        /* Switch: '<S567>/Switch' incorporates:
         *  Constant: '<S567>/LL_MAX_LDWS_SPEED_ENABLE=140'
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S533>/Switch' */

    /* Switch: '<S531>/Switch' incorporates:
     *  Constant: '<S531>/Constant'
     *  Constant: '<S531>/Constant1'
     *  Constant: '<S536>/Constant'
     *  Constant: '<S537>/Constant'
     *  Constant: '<S538>/Constant'
     *  Logic: '<S531>/Logical Operator'
     *  RelationalOperator: '<S536>/Compare'
     *  RelationalOperator: '<S537>/Compare'
     *  RelationalOperator: '<S538>/Compare'
     */
    if ((rtb_IMAPve_d_BCM_HazardLamp > ((uint8)0U)) ||
        (rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U)) ||
        (rtb_IMAPve_d_BCM_Right_Light > ((uint8)0U))) {
      rtb_TLft = 3.0F;
    } else {
      rtb_TLft = (-1.0F);
    }

    /* End of Switch: '<S531>/Switch' */

    /* Sum: '<S531>/Add' incorporates:
     *  Memory: '<S531>/Memory'
     */
    rtb_TLft += LKAS_DW.Memory_PreviousInput_d;

    /* Saturate: '<S531>/Saturation' */
    if (rtb_TLft > 200.0F) {
      rtb_Saturation_e = 200.0F;
    } else if (rtb_TLft < (-1.0F)) {
      rtb_Saturation_e = (-1.0F);
    } else {
      rtb_Saturation_e = rtb_TLft;
    }

    /* End of Saturate: '<S531>/Saturation' */

    /* Abs: '<S525>/Abs1' incorporates:
     *  Abs: '<S432>/Abs1'
     */
    rtb_Abs1_tmp = fabsf(rtb_Divide_a3);
    rtb_Abs1 = rtb_Abs1_tmp;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S73>/states = reset'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S523>/Abs' incorporates:
     *  Abs: '<S102>/Abs'
     *  Abs: '<S103>/Abs'
     *  Abs: '<S104>/Abs4'
     *  Abs: '<S389>/Abs1'
     *  Abs: '<S430>/Abs'
     */
    rtb_TTLC_f = fabsf(rtb_Merge_k);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC_f;

    /* SampleTimeMath: '<S491>/TSamp' incorporates:
     *  SampleTimeMath: '<S392>/TSamp'
     *
     * About '<S491>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     *
     * About '<S392>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    rtb_TSamp_tmp = rtb_IMAPve_g_SW_Angle * 100.0F;
    rtb_TSamp = rtb_TSamp_tmp;

    /* Sum: '<S491>/Diff' incorporates:
     *  UnitDelay: '<S491>/UD'
     *
     * Block description for '<S491>/Diff':
     *
     *  Add in CPU
     *
     * Block description for '<S491>/UD':
     *
     *  Store in Global RAM
     */
    rtb_Diff = rtb_TSamp - LKAS_DW.UD_DSTATE;

    /* Switch: '<S567>/Switch14' */
    if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
      /* UnaryMinus: '<S485>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion34;
    } else {
      /* UnaryMinus: '<S485>/Unary Minus' incorporates:
       *  Constant: '<S567>/LL_MAX_LONG_DECEL_ENABLE=2'
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S567>/Switch14' */

    /* Switch: '<S567>/Switch8' incorporates:
     *  Constant: '<S567>/LL_MAX_STEER_ANGLE_ENABLE=60'
     */
    if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion30;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S567>/Switch8' */

    /* Switch: '<S567>/Switch10' incorporates:
     *  Constant: '<S567>/LL_MAX_STEER_SPEED_ENABLE=150'
     */
    if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion32;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S567>/Switch10' */

    /* Switch: '<S567>/Switch9' incorporates:
     *  Constant: '<S567>/LL_MAX_DRIVER_TORQUE_ENABLE=3'
     */
    if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion31;
    } else {
      rtb_TLft = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S567>/Switch9' */

    /* Switch: '<S567>/Switch11' incorporates:
     *  Constant: '<S567>/LL_MAX_LAT_ACC_ENABLE=3'
     */
    if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
      tmp = LKAS_ConstB.DataTypeConversion33;
    } else {
      tmp = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S567>/Switch11' */

    /* Abs: '<S485>/Abs1' incorporates:
     *  Abs: '<S388>/Abs'
     *  Abs: '<S389>/Abs'
     */
    rtb_Saturation4 = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Abs: '<S521>/Abs' incorporates:
     *  Abs: '<S428>/Abs'
     *  Sum: '<S521>/Add'
     */
    rtb_Abs_k = fabsf(rtb_Saturation - rtb_L0_C0);

    /* Abs: '<S485>/Abs2' incorporates:
     *  Abs: '<S260>/Abs2'
     *  Abs: '<S387>/Abs2'
     */
    x1 = fabsf(rtb_IMAPve_g_SW_Angle);

    /* Abs: '<S485>/Abs4' incorporates:
     *  Abs: '<S387>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     *  Inport: '<Root>/IMAPve_g_ESC_LatAcc'
     */
    rtb_Abs_e = fabsf
      (Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc());

    /* Logic: '<S486>/Logical Operator2' incorporates:
     *  Abs: '<S485>/Abs1'
     *  Abs: '<S485>/Abs2'
     *  Abs: '<S485>/Abs3'
     *  Abs: '<S485>/Abs4'
     *  Abs: '<S521>/Abs'
     *  Constant: '<S523>/Constant'
     *  Constant: '<S526>/Constant'
     *  Constant: '<S528>/Constant'
     *  Constant: '<S529>/Constant'
     *  Constant: '<S535>/Constant'
     *  Constant: '<S539>/Constant'
     *  Logic: '<S485>/Logical Operator3'
     *  Logic: '<S492>/FixPt Logical Operator'
     *  Logic: '<S522>/Logical Operator3'
     *  Logic: '<S524>/Logical Operator'
     *  Logic: '<S527>/FixPt Logical Operator'
     *  Logic: '<S530>/FixPt Logical Operator'
     *  Logic: '<S534>/Logical Operator'
     *  Logic: '<S540>/FixPt Logical Operator'
     *  RelationalOperator: '<S485>/Relational Operator'
     *  RelationalOperator: '<S485>/Relational Operator1'
     *  RelationalOperator: '<S485>/Relational Operator2'
     *  RelationalOperator: '<S485>/Relational Operator3'
     *  RelationalOperator: '<S492>/Lower Test'
     *  RelationalOperator: '<S492>/Upper Test'
     *  RelationalOperator: '<S526>/Compare'
     *  RelationalOperator: '<S527>/Lower Test'
     *  RelationalOperator: '<S527>/Upper Test'
     *  RelationalOperator: '<S528>/Compare'
     *  RelationalOperator: '<S529>/Compare'
     *  RelationalOperator: '<S530>/Lower Test'
     *  RelationalOperator: '<S530>/Upper Test'
     *  RelationalOperator: '<S535>/Compare'
     *  RelationalOperator: '<S539>/Compare'
     *  RelationalOperator: '<S540>/Lower Test'
     *  RelationalOperator: '<S540>/Upper Test'
     *  Switch: '<S52>/Switch'
     *  Switch: '<S52>/Switch1'
     */
    rtb_LogicalOperator3_n = ((rtb_Gain_o <= rtb_IMAPve_g_ESC_VehSpd) &&
      (rtb_IMAPve_g_ESC_VehSpd <= rtb_Switch) && (rtb_Saturation_e <= 0.0F) &&
      (rtb_IMAPve_d_TCU_Actual_Gear == ((uint8)3U)) && ((rtb_L0_Q > ((uint8)2U))
      && (rtb_R0_Q > ((uint8)2U)) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1)
      && (rtb_Abs1 <= rtb_LL_MAX_LANE_WIDTH_ENABLE)) && ((0.0F <= rtb_Abs) &&
      (rtb_Abs <= rtb_LL_MAX_SYSTEM_CURVATURE_ENA)) && (rtb_Abs_k <= 0.025F)) &&
      ((x1 < x10) && (fabsf(rtb_Diff) < x20) && (rtb_Saturation4 < rtb_TLft) &&
       (rtb_Abs_e < tmp) && ((rtb_UnaryMinus < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* Sum: '<S519>/Add1' incorporates:
     *  Constant: '<S519>/Constant1'
     *  Gain: '<S519>/Gain'
     *  Sum: '<S501>/Add1'
     */
    rtb_Add1_g_tmp = 0.5F * rtb_Divide_a3 - 1.5F;
    rtb_Add1_g = rtb_Add1_g_tmp;

    /* Switch: '<S520>/Switch' incorporates:
     *  Constant: '<S519>/Constant'
     *  RelationalOperator: '<S520>/UpperRelop'
     */
    if (rtb_Add1_g < 0.0F) {
      rtb_Switch_o = 0.0F;
    } else {
      rtb_Switch_o = rtb_Add1_g;
    }

    /* End of Switch: '<S520>/Switch' */

    /* Switch: '<S520>/Switch2' incorporates:
     *  RelationalOperator: '<S520>/LowerRelop1'
     */
    if (rtb_Add1_g > rtb_LL_LKA_EarliestWarnLine_C) {
      rtb_Switch2 = rtb_LL_LKA_EarliestWarnLine_C;
    } else {
      rtb_Switch2 = rtb_Switch_o;
    }

    /* End of Switch: '<S520>/Switch2' */

    /* Abs: '<S506>/Abs1' incorporates:
     *  Abs: '<S416>/Abs'
     */
    x10 = fabsf(rtb_LL_ThresDet_lDvtThresUprL_g);

    /* Abs: '<S506>/Abs2' incorporates:
     *  Abs: '<S416>/Abs1'
     */
    x20 = fabsf(rtb_Saturation10);

    /* If: '<S486>/If1' incorporates:
     *  Abs: '<S506>/Abs1'
     *  Abs: '<S506>/Abs2'
     *  Constant: '<S494>/Constant'
     *  Constant: '<S508>/Constant'
     *  Constant: '<S509>/Constant'
     *  Constant: '<S514>/Constant'
     *  Constant: '<S515>/Constant'
     *  Constant: '<S516>/Constant'
     *  Constant: '<S517>/Constant'
     *  DataTypeConversion: '<S486>/Cast To Single'
     *  Logic: '<S486>/Logical Operator1'
     *  Logic: '<S503>/Logical Operator'
     *  Logic: '<S505>/Logical Operator'
     *  Logic: '<S506>/Logical Operator'
     *  Logic: '<S507>/Logical Operator'
     *  RelationalOperator: '<S506>/Relational Operator2'
     *  RelationalOperator: '<S506>/Relational Operator3'
     *  RelationalOperator: '<S507>/Relational Operator1'
     *  RelationalOperator: '<S507>/Relational Operator2'
     *  RelationalOperator: '<S508>/Compare'
     *  RelationalOperator: '<S509>/Compare'
     *  RelationalOperator: '<S514>/Compare'
     *  RelationalOperator: '<S515>/Compare'
     *  RelationalOperator: '<S516>/Compare'
     *  RelationalOperator: '<S517>/Compare'
     */
    if ((LKAS_B.Divide == 2) && (rtb_LogicalOperator3_n && ((LKAS_B.Divide ==
           ((uint8)2U)) && (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
            (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) == (sint32)true) &&
          (((x10 <= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
             rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) == (sint32)true) &&
          (((rtb_Gain1_i >= rtb_Switch2) && (rtb_Add5_j >= rtb_Switch2)) ==
           (sint32)true)))) {
      /* Outputs for IfAction SubSystem: '<S486>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S494>/Action Port'
       */
      LKAS_B.Merge1_g = true;

      /* End of Outputs for SubSystem: '<S486>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S486>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S496>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_B.Merge1_g);

      /* End of Outputs for SubSystem: '<S486>/If Action Subsystem4' */
    }

    /* End of If: '<S486>/If1' */

    /* Switch: '<S477>/Switch' incorporates:
     *  Constant: '<S571>/Constant'
     *  Constant: '<S572>/Constant'
     *  Gain: '<S571>/Gain'
     *  Gain: '<S572>/Gain'
     *  Sum: '<S571>/Add'
     *  Sum: '<S572>/Add'
     *  Switch: '<S567>/Switch28'
     */
    if (LKAS_B.Divide >= ((uint8)2U)) {
      /* Switch: '<S567>/Switch41' incorporates:
       *  Constant: '<S567>/LL_MAX_LKAS_SPEED_DISABLE=150'
       */
      if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
        rtb_TLft = LKAS_ConstB.DataTypeConversion1;
      } else {
        rtb_TLft = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S567>/Switch41' */
      rtb_Switch_j = (rtb_TLft - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
        /* Switch: '<S567>/Switch28' */
        rtb_TLft = LKAS_ConstB.DataTypeConversion53;
      } else {
        /* Switch: '<S567>/Switch28' incorporates:
         *  Constant: '<S567>/LL_MAX_LDWS_SPEED_DISABLE=150'
         */
        rtb_TLft = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_j = (rtb_TLft - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S477>/Switch' */

    /* Switch: '<S475>/Switch' incorporates:
     *  Constant: '<S475>/Constant'
     *  Constant: '<S475>/Constant1'
     *  Constant: '<S480>/Constant'
     *  Constant: '<S481>/Constant'
     *  Constant: '<S482>/Constant'
     *  Logic: '<S475>/Logical Operator'
     *  RelationalOperator: '<S480>/Compare'
     *  RelationalOperator: '<S481>/Compare'
     *  RelationalOperator: '<S482>/Compare'
     */
    if ((rtb_IMAPve_d_BCM_HazardLamp > ((uint8)0U)) ||
        (rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U)) ||
        (rtb_IMAPve_d_BCM_Right_Light > ((uint8)0U))) {
      rtb_TLft = 3.0F;
    } else {
      rtb_TLft = (-1.0F);
    }

    /* End of Switch: '<S475>/Switch' */

    /* Sum: '<S475>/Add' incorporates:
     *  Memory: '<S475>/Memory'
     */
    rtb_TLft += LKAS_DW.Memory_PreviousInput_p;

    /* Saturate: '<S475>/Saturation' */
    if (rtb_TLft > 200.0F) {
      rtb_Saturation_d = 200.0F;
    } else if (rtb_TLft < (-1.0F)) {
      rtb_Saturation_d = (-1.0F);
    } else {
      rtb_Saturation_d = rtb_TLft;
    }

    /* End of Saturate: '<S475>/Saturation' */

    /* Abs: '<S432>/Abs1' */
    rtb_Abs1_i = rtb_Abs1_tmp;

    /* Abs: '<S430>/Abs' */
    rtb_Abs_m = rtb_TTLC_f;

    /* SampleTimeMath: '<S392>/TSamp'
     *
     * About '<S392>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    rtb_TSamp_n = rtb_TSamp_tmp;

    /* Sum: '<S392>/Diff' incorporates:
     *  UnitDelay: '<S392>/UD'
     *
     * Block description for '<S392>/Diff':
     *
     *  Add in CPU
     *
     * Block description for '<S392>/UD':
     *
     *  Store in Global RAM
     */
    rtb_Diff_j = rtb_TSamp_n - LKAS_DW.UD_DSTATE_c;

    /* Switch: '<S567>/Switch22' */
    if (LKAS_ConstB.DataTypeConversion57 != 0.0F) {
      /* UnaryMinus: '<S387>/Unary Minus' */
      rtb_UnaryMinus_k = -LKAS_ConstB.DataTypeConversion57;
    } else {
      /* UnaryMinus: '<S387>/Unary Minus' incorporates:
       *  Constant: '<S567>/LL_MAX_LONG_DECEL_DISABLE=2.5'
       */
      rtb_UnaryMinus_k = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S567>/Switch22' */

    /* Switch: '<S388>/Switch' incorporates:
     *  Constant: '<S388>/Constant'
     *  Constant: '<S388>/Constant1'
     *  Constant: '<S394>/Constant'
     *  RelationalOperator: '<S394>/Compare'
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      rtb_TLft = 0.5F;
    } else {
      rtb_TLft = 0.25F;
    }

    /* End of Switch: '<S388>/Switch' */

    /* Outputs for Enabled SubSystem: '<S388>/Count 20s' incorporates:
     *  EnablePort: '<S397>/Enable'
     */
    /* RelationalOperator: '<S388>/Relational Operator' */
    if (rtb_Saturation4 <= rtb_TLft) {
      if (!LKAS_DW.Count20s_MODE) {
        /* InitializeConditions for Sum: '<S397>/Add' incorporates:
         *  Memory: '<S397>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_i3 = ((uint16)0U);
        LKAS_DW.Count20s_MODE = true;
      }

      /* Sum: '<S397>/Add' incorporates:
       *  Constant: '<S395>/Constant'
       *  Constant: '<S396>/Constant'
       *  Logic: '<S388>/Logical Operator2'
       *  Memory: '<S397>/Memory'
       *  RelationalOperator: '<S395>/Compare'
       *  RelationalOperator: '<S396>/Compare'
       */
      LKAS_DW.Memory_PreviousInput_i3 = (uint16)((uint32)
        ((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
         (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) +
        LKAS_DW.Memory_PreviousInput_i3);

      /* Saturate: '<S397>/Saturation' */
      if (LKAS_DW.Memory_PreviousInput_i3 >= ((uint16)50000U)) {
        /* Sum: '<S397>/Add' */
        LKAS_DW.Memory_PreviousInput_i3 = ((uint16)50000U);
      }

      /* End of Saturate: '<S397>/Saturation' */

      /* DataTypeConversion: '<S388>/Cast To Single1' incorporates:
       *  Constant: '<S388>/Constant2'
       *  Product: '<S388>/Divide'
       */
      rtb_TLft = fmodf(floorf(20.0F / rtb_LKA_SampleTime), 65536.0F);

      /* RelationalOperator: '<S397>/Relational Operator' incorporates:
       *  DataTypeConversion: '<S388>/Cast To Single1'
       */
      LKAS_B.RelationalOperator_gm = (LKAS_DW.Memory_PreviousInput_i3 >=
        (rtb_TLft < 0.0F ? (sint32)(uint16)-(sint16)(uint16)-rtb_TLft : (sint32)
         (uint16)rtb_TLft));
    } else {
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S397>/Out' */
        LKAS_B.RelationalOperator_gm = false;
        LKAS_DW.Count20s_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S388>/Relational Operator' */
    /* End of Outputs for SubSystem: '<S388>/Count 20s' */

    /* Saturate: '<S389>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 80.0F) {
      rtb_TLft = 80.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      rtb_TLft = 60.0F;
    } else {
      rtb_TLft = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S389>/Saturation' */

    /* Sum: '<S389>/Add' incorporates:
     *  Constant: '<S389>/Constant'
     *  Fcn: '<S389>/Fcn'
     *  Product: '<S389>/Divide2'
     */
    rtb_LL_ThresDet_lDvtThresUprL_g = (1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL -
      rtb_TLft / 180.0F * rtb_LL_MAX_DRIVER_TORQUE_DISABL) + rtb_TTLC_f / 0.005F;

    /* Saturate: '<S389>/Saturation1' */
    if (rtb_LL_ThresDet_lDvtThresUprL_g > 2.75F) {
      rtb_LL_ThresDet_lDvtThresUprL_g = 2.75F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprL_g < 1.5F) {
        rtb_LL_ThresDet_lDvtThresUprL_g = 1.5F;
      }
    }

    /* End of Saturate: '<S389>/Saturation1' */

    /* Outputs for Enabled SubSystem: '<S389>/Sum Condition2' incorporates:
     *  EnablePort: '<S398>/state = reset'
     */
    /* RelationalOperator: '<S389>/Relational Operator' */
    if (rtb_Saturation4 >= rtb_LL_ThresDet_lDvtThresUprL_g) {
      if (!LKAS_DW.SumCondition2_MODE) {
        /* InitializeConditions for Sum: '<S398>/Add1' incorporates:
         *  Memory: '<S398>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_p0 = ((uint16)0U);
        LKAS_DW.SumCondition2_MODE = true;
      }

      /* Sum: '<S398>/Add1' incorporates:
       *  Memory: '<S398>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_p0 = (uint16)fmodf(1.0F + (float32)
        LKAS_DW.Memory_PreviousInput_p0, 65536.0F);

      /* Saturate: '<S398>/Saturation' */
      if (LKAS_DW.Memory_PreviousInput_p0 >= ((uint16)5000U)) {
        /* Sum: '<S398>/Add1' */
        LKAS_DW.Memory_PreviousInput_p0 = ((uint16)5000U);
      }

      /* End of Saturate: '<S398>/Saturation' */

      /* Switch: '<S567>/Switch26' incorporates:
       *  Constant: '<S567>/LL_TkOvStChk_tiTrqChkT_C=0.1'
       */
      if (LKAS_ConstB.DataTypeConversion62 != 0.0F) {
        rtb_TLft = LKAS_ConstB.DataTypeConversion62;
      } else {
        rtb_TLft = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S567>/Switch26' */

      /* DataTypeConversion: '<S389>/Cast To Single1' incorporates:
       *  Product: '<S389>/Divide'
       */
      rtb_TLft = fmodf(floorf(rtb_TLft / rtb_LKA_SampleTime), 65536.0F);

      /* RelationalOperator: '<S398>/Relational Operator' incorporates:
       *  DataTypeConversion: '<S389>/Cast To Single1'
       */
      LKAS_B.RelationalOperator_j = (LKAS_DW.Memory_PreviousInput_p0 >=
        (rtb_TLft < 0.0F ? (sint32)(uint16)-(sint16)(uint16)-rtb_TLft : (sint32)
         (uint16)rtb_TLft));
    } else {
      if (LKAS_DW.SumCondition2_MODE) {
        /* Disable for Outport: '<S398>/Out' */
        LKAS_B.RelationalOperator_j = false;
        LKAS_DW.SumCondition2_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S389>/Relational Operator' */
    /* End of Outputs for SubSystem: '<S389>/Sum Condition2' */

    /* RelationalOperator: '<S407>/Compare' incorporates:
     *  Constant: '<S407>/Constant'
     */
    rtb_Compare_ef = ((sint32)LKAS_B.RelationalOperator_j > (sint32)false);

    /* UnitDelay: '<S399>/Unit Delay' */
    rtb_UnitDelay_a = LKAS_DW.UnitDelay_DSTATE_ba;

    /* RelationalOperator: '<S406>/Compare' incorporates:
     *  Constant: '<S406>/Constant'
     */
    rtb_Compare_oq = ((sint32)rtb_UnitDelay_a <= (sint32)false);

    /* If: '<S399>/If' incorporates:
     *  Constant: '<S402>/Constant'
     *  Constant: '<S403>/Constant'
     *  RelationalOperator: '<S400>/FixPt Relational Operator'
     *  RelationalOperator: '<S401>/FixPt Relational Operator'
     *  UnitDelay: '<S400>/Delay Input1'
     *  UnitDelay: '<S401>/Delay Input1'
     *
     * Block description for '<S400>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S401>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if (LKAS_B.RelationalOperator_j && ((sint32)rtb_Compare_ef > (sint32)
         LKAS_DW.DelayInput1_DSTATE)) {
      /* Outputs for IfAction SubSystem: '<S399>/If Action Subsystem' incorporates:
       *  ActionPort: '<S402>/Action Port'
       */
      rtb_Merge_k2 = true;

      /* End of Outputs for SubSystem: '<S399>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_a) && ((sint32)rtb_Compare_oq > (sint32)
                LKAS_DW.DelayInput1_DSTATE_j)) {
      /* Outputs for IfAction SubSystem: '<S399>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S403>/Action Port'
       */
      rtb_Merge_k2 = false;

      /* End of Outputs for SubSystem: '<S399>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S399>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S404>/Action Port'
       */
      LKAS_IfActionSubsystem3_m(rtb_UnitDelay_a, &rtb_Merge_k2);

      /* End of Outputs for SubSystem: '<S399>/If Action Subsystem3' */
    }

    /* End of If: '<S399>/If' */

    /* Outputs for Enabled SubSystem: '<S399>/Sum Condition1' incorporates:
     *  EnablePort: '<S405>/state = reset'
     */
    if (rtb_Merge_k2) {
      if (!LKAS_DW.SumCondition1_MODE_c) {
        /* InitializeConditions for Sum: '<S405>/Add1' incorporates:
         *  Memory: '<S405>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_h = ((uint16)0U);
        LKAS_DW.SumCondition1_MODE_c = true;
      }

      /* Sum: '<S405>/Add1' incorporates:
       *  Memory: '<S405>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_h = (uint16)((uint32)rtb_Merge_k2 +
        LKAS_DW.Memory_PreviousInput_h);

      /* Saturate: '<S405>/Saturation' */
      if (LKAS_DW.Memory_PreviousInput_h >= ((uint16)10000U)) {
        /* Sum: '<S405>/Add1' */
        LKAS_DW.Memory_PreviousInput_h = ((uint16)10000U);
      }

      /* End of Saturate: '<S405>/Saturation' */

      /* DataTypeConversion: '<S389>/Cast To Single2' incorporates:
       *  Product: '<S389>/Divide1'
       */
      rtb_TLft = fmodf(floorf(rtb_LL_TkOvStChk_tiTDelTime / rtb_LKA_SampleTime),
                       65536.0F);

      /* RelationalOperator: '<S405>/Relational Operator' incorporates:
       *  DataTypeConversion: '<S389>/Cast To Single2'
       */
      LKAS_B.RelationalOperator_e = (LKAS_DW.Memory_PreviousInput_h <= (rtb_TLft
        < 0.0F ? (sint32)(uint16)-(sint16)(uint16)-rtb_TLft : (sint32)(uint16)
        rtb_TLft));
    } else {
      if (LKAS_DW.SumCondition1_MODE_c) {
        /* Disable for Outport: '<S405>/Out' */
        LKAS_B.RelationalOperator_e = false;
        LKAS_DW.SumCondition1_MODE_c = false;
      }
    }

    /* End of Outputs for SubSystem: '<S399>/Sum Condition1' */

    /* Switch: '<S567>/Switch32' incorporates:
     *  Constant: '<S567>/LL_MAX_STEER_ANGLE_DISABLE=70'
     */
    if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion52;
    } else {
      rtb_TLft = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S567>/Switch32' */

    /* Switch: '<S567>/Switch34' incorporates:
     *  Constant: '<S567>/LL_MAX_STEER_SPEED_DISABLE=200'
     */
    if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
      tmp = LKAS_ConstB.DataTypeConversion55;
    } else {
      tmp = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S567>/Switch34' */

    /* Switch: '<S567>/Switch4' incorporates:
     *  Constant: '<S567>/LL_MAX_LAT_ACC_DISABLE=3.5'
     */
    if (LKAS_ConstB.DataTypeConversion56 != 0.0F) {
      rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion56;
    } else {
      rtb_LL_LKA_EarliestWarnLine_C = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S567>/Switch4' */

    /* Logic: '<S374>/Logical Operator2' incorporates:
     *  Abs: '<S387>/Abs3'
     *  Constant: '<S390>/Constant'
     *  Constant: '<S391>/Constant'
     *  Constant: '<S430>/Constant'
     *  Constant: '<S433>/Constant'
     *  Constant: '<S435>/Constant'
     *  Constant: '<S436>/Constant'
     *  Constant: '<S437>/Constant'
     *  Constant: '<S479>/Constant'
     *  Constant: '<S483>/Constant'
     *  Logic: '<S386>/Logical Operator1'
     *  Logic: '<S387>/Logical Operator'
     *  Logic: '<S387>/Logical Operator1'
     *  Logic: '<S393>/FixPt Logical Operator'
     *  Logic: '<S429>/Logical Operator3'
     *  Logic: '<S430>/Logical Operator'
     *  Logic: '<S431>/Logical Operator'
     *  Logic: '<S434>/FixPt Logical Operator'
     *  Logic: '<S438>/FixPt Logical Operator'
     *  Logic: '<S477>/Logical Operator'
     *  Logic: '<S478>/Logical Operator3'
     *  Logic: '<S484>/FixPt Logical Operator'
     *  RelationalOperator: '<S387>/Relational Operator1'
     *  RelationalOperator: '<S387>/Relational Operator2'
     *  RelationalOperator: '<S387>/Relational Operator3'
     *  RelationalOperator: '<S390>/Compare'
     *  RelationalOperator: '<S391>/Compare'
     *  RelationalOperator: '<S393>/Lower Test'
     *  RelationalOperator: '<S393>/Upper Test'
     *  RelationalOperator: '<S433>/Compare'
     *  RelationalOperator: '<S434>/Lower Test'
     *  RelationalOperator: '<S434>/Upper Test'
     *  RelationalOperator: '<S435>/Compare'
     *  RelationalOperator: '<S436>/Compare'
     *  RelationalOperator: '<S437>/Compare'
     *  RelationalOperator: '<S438>/Lower Test'
     *  RelationalOperator: '<S438>/Upper Test'
     *  RelationalOperator: '<S479>/Compare'
     *  RelationalOperator: '<S483>/Compare'
     *  RelationalOperator: '<S484>/Lower Test'
     *  RelationalOperator: '<S484>/Upper Test'
     *  Switch: '<S52>/Switch'
     *  Switch: '<S52>/Switch1'
     */
    rtb_LogicalOperator2_p = ((rtb_Gain_b >= rtb_IMAPve_g_ESC_VehSpd) ||
      (rtb_IMAPve_g_ESC_VehSpd >= rtb_Switch_j) || (rtb_Saturation_d > 0.0F) ||
      (rtb_IMAPve_d_TCU_Actual_Gear != ((uint8)3U)) || (((rtb_L0_Q < ((uint8)3U))
      && (rtb_R0_Q < ((uint8)3U))) || (((rtb_LL_MIN_LANE_WIDTH_DISABLE <=
      rtb_Abs1_i) && (rtb_Abs1_i <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) == (sint32)
      false) || ((0.0F > rtb_Abs_m) || (rtb_Abs_m >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS)) || (rtb_Abs_k > 0.04F)) || ((x1 >=
      rtb_TLft) || (fabsf(rtb_Diff_j) >= tmp) || ((rtb_Abs_e >=
      rtb_LL_LKA_EarliestWarnLine_C) && (rtb_IMAPve_d_EPS_LKA_State != ((uint8)
      3U))) || (((rtb_UnaryMinus_k < rtb_IMAPve_g_ESC_LonAcc) &&
                 (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ==
                (sint32)false) || LKAS_B.RelationalOperator_gm ||
      LKAS_B.RelationalOperator_e));

    /* If: '<S414>/If' incorporates:
     *  Constant: '<S420>/Constant'
     *  Delay: '<S75>/Delay1'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == 3) && (rtb_IMAPve_d_EPS_LKA_State != 1)) {
      /* Outputs for IfAction SubSystem: '<S414>/If Action Subsystem' incorporates:
       *  ActionPort: '<S418>/Action Port'
       */
      LKAS_IfActionSubsystem_e(&rtb_Merge_i);

      /* End of Outputs for SubSystem: '<S414>/If Action Subsystem' */
    } else if (((LKAS_DW.Delay1_3_DSTATE == 4) || (LKAS_DW.Delay1_3_DSTATE == 5))
               && (rtb_IMAPve_d_EPS_LKA_State != 3)) {
      /* Outputs for IfAction SubSystem: '<S414>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S419>/Action Port'
       */
      LKAS_IfActionSubsystem_e(&rtb_Merge_i);

      /* End of Outputs for SubSystem: '<S414>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S414>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S420>/Action Port'
       */
      rtb_Merge_i = false;

      /* End of Outputs for SubSystem: '<S414>/If Action Subsystem3' */
    }

    /* End of If: '<S414>/If' */

    /* Outputs for Enabled SubSystem: '<S414>/Sum Condition1' incorporates:
     *  EnablePort: '<S421>/state = reset'
     */
    if (rtb_Merge_i) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Sum: '<S421>/Add1' incorporates:
         *  Memory: '<S421>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_cz = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S421>/Add1' incorporates:
       *  DataTypeConversion: '<S421>/Cast To Single'
       *  Memory: '<S421>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_cz += (float32)rtb_Merge_i;

      /* Saturate: '<S421>/Saturation' */
      if (LKAS_DW.Memory_PreviousInput_cz > 60000.0F) {
        /* Sum: '<S421>/Add1' */
        LKAS_DW.Memory_PreviousInput_cz = 60000.0F;
      } else {
        if (LKAS_DW.Memory_PreviousInput_cz < 0.0F) {
          /* Sum: '<S421>/Add1' */
          LKAS_DW.Memory_PreviousInput_cz = 0.0F;
        }
      }

      /* End of Saturate: '<S421>/Saturation' */

      /* Switch: '<S567>/Switch24' incorporates:
       *  Constant: '<S567>/LL_MAX_DELAY_EPSSTAR_TIME=0.5'
       */
      if (LKAS_ConstB.DataTypeConversion60 != 0.0F) {
        rtb_TLft = LKAS_ConstB.DataTypeConversion60;
      } else {
        rtb_TLft = LL_MAX_DELAY_EPSSTAR_TIME;
      }

      /* End of Switch: '<S567>/Switch24' */

      /* DataTypeConversion: '<S414>/Cast To Single1' incorporates:
       *  Product: '<S414>/Divide'
       */
      rtb_TLft = fmodf(floorf(rtb_TLft / rtb_LKA_SampleTime), 65536.0F);

      /* RelationalOperator: '<S421>/Relational Operator' incorporates:
       *  DataTypeConversion: '<S414>/Cast To Single1'
       */
      LKAS_B.RelationalOperator_g = (LKAS_DW.Memory_PreviousInput_cz >=
        (rtb_TLft < 0.0F ? (sint32)(uint16)-(sint16)(uint16)-rtb_TLft : (sint32)
         (uint16)rtb_TLft));
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S421>/Out' */
        LKAS_B.RelationalOperator_g = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S414>/Sum Condition1' */

    /* If: '<S374>/If2' incorporates:
     *  Constant: '<S382>/Constant'
     *  Constant: '<S422>/Constant'
     *  Constant: '<S423>/Constant'
     *  Constant: '<S424>/Constant'
     *  Constant: '<S425>/Constant'
     *  DataTypeConversion: '<S374>/Cast To Single'
     *  Gain: '<S426>/Gain'
     *  Logic: '<S374>/Logical Operator1'
     *  Logic: '<S415>/Logical Operator'
     *  Logic: '<S415>/Logical Operator1'
     *  Logic: '<S416>/Logical Operator'
     *  Logic: '<S417>/Logical Operator'
     *  RelationalOperator: '<S416>/Relational Operator1'
     *  RelationalOperator: '<S416>/Relational Operator2'
     *  RelationalOperator: '<S417>/Relational Operator1'
     *  RelationalOperator: '<S417>/Relational Operator2'
     *  RelationalOperator: '<S422>/Compare'
     *  RelationalOperator: '<S423>/Compare'
     *  RelationalOperator: '<S424>/Compare'
     *  RelationalOperator: '<S425>/Compare'
     */
    if ((LKAS_B.Divide == 2) && (rtb_LogicalOperator2_p || ((LKAS_B.Divide ==
           ((uint8)2U)) && ((((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
              rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) == (sint32)true) ||
                            (((rtb_LL_ThresDet_lDvtThresLwrL_k * (-1.0F) <=
              rtb_Abs_h) || (rtb_Add5_j_tmp <= rtb_Abs_h)) == (sint32)true) ||
                            (LKAS_B.RelationalOperator_g == true))))) {
      /* Outputs for IfAction SubSystem: '<S374>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S382>/Action Port'
       */
      LKAS_B.Merge2_h = true;

      /* End of Outputs for SubSystem: '<S374>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S374>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S384>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_B.Merge2_h);

      /* End of Outputs for SubSystem: '<S374>/If Action Subsystem3' */
    }

    /* End of If: '<S374>/If2' */

    /* Product: '<S295>/Divide' */
    rtb_Abs_k = rtb_Saturation * rtb_LL_ThresDet_lDvtThresUprL_h;

    /* Product: '<S295>/Divide1' */
    rtb_Abs_e = rtb_LL_ThresDet_lDvtThresUprL_h * rtb_L0_C0;

    /* If: '<S309>/If' */
    if ((rtb_Abs_k >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_e >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S309>/Ph1SWA' incorporates:
       *  ActionPort: '<S313>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_k);

      /* End of Outputs for SubSystem: '<S309>/Ph1SWA' */
    } else if ((rtb_Abs_k <= -rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_e <=
                -rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S309>/Ph2SWA' incorporates:
       *  ActionPort: '<S314>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_k);

      /* End of Outputs for SubSystem: '<S309>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S309>/Ph3SWA' incorporates:
       *  ActionPort: '<S315>/Action Port'
       */
      LKAS_Ph3SWA(&rtb_Merge1_k);

      /* End of Outputs for SubSystem: '<S309>/Ph3SWA' */
    }

    /* End of If: '<S309>/If' */

    /* Saturate: '<S294>/Saturation4' */
    if (rtb_LL_DvtComp_C > 0.1F) {
      rtb_Saturation4 = 0.1F;
    } else if (rtb_LL_DvtComp_C < (-0.1F)) {
      rtb_Saturation4 = (-0.1F);
    } else {
      rtb_Saturation4 = rtb_LL_DvtComp_C;
    }

    /* End of Saturate: '<S294>/Saturation4' */

    /* Saturate: '<S294>/Saturation1' */
    if (rtb_Saturation > 0.2F) {
      rtb_LL_ThresDet_lDvtThresUprL_g = 0.2F;
    } else if (rtb_Saturation < (-0.2F)) {
      rtb_LL_ThresDet_lDvtThresUprL_g = (-0.2F);
    } else {
      rtb_LL_ThresDet_lDvtThresUprL_g = rtb_Saturation;
    }

    /* End of Saturate: '<S294>/Saturation1' */

    /* Saturate: '<S294>/Saturation' */
    if (rtb_L0_C0_a > 2.0F) {
      x10 = 2.0F;
    } else if (rtb_L0_C0_a < (-4.0F)) {
      x10 = (-4.0F);
    } else {
      x10 = rtb_L0_C0_a;
    }

    /* End of Saturate: '<S294>/Saturation' */

    /* Gain: '<S298>/Gain' incorporates:
     *  Product: '<S298>/Divide'
     *  Product: '<S298>/Divide1'
     *  Sum: '<S298>/Add'
     *  Sum: '<S298>/Add1'
     *  Sum: '<S298>/Add2'
     *  Trigonometry: '<S298>/Cos'
     *  Trigonometry: '<S298>/Sin'
     */
    rtb_LL_LKA_EarliestWarnLine_C = (((x10 - rtb_Saturation4) + rtb_R0_C1) *
      cosf(rtb_LL_ThresDet_lDvtThresUprL_g) + rtb_Saturation_ki * sinf
      (rtb_LL_ThresDet_lDvtThresUprL_g)) * (-1.0F);

    /* Saturate: '<S284>/Saturation5' */
    if (rtb_LL_LKA_EarliestWarnLine_C > 2.0F) {
      rtb_LL_LKA_EarliestWarnLine_C = 2.0F;
    } else {
      if (rtb_LL_LKA_EarliestWarnLine_C < (-2.0F)) {
        rtb_LL_LKA_EarliestWarnLine_C = (-2.0F);
      }
    }

    /* End of Saturate: '<S284>/Saturation5' */

    /* Saturate: '<S293>/Saturation1' */
    if (rtb_L0_TLC > 5.5F) {
      rtb_TLft = 5.5F;
    } else if (rtb_L0_TLC < 2.4F) {
      rtb_TLft = 2.4F;
    } else {
      rtb_TLft = rtb_L0_TLC;
    }

    /* End of Saturate: '<S293>/Saturation1' */

    /* Sum: '<S293>/Add2' incorporates:
     *  Constant: '<S293>/Constant1'
     *  Gain: '<S293>/Gain'
     */
    rtb_TLft = 0.25F * rtb_TLft - 0.6F;

    /* Saturate: '<S293>/Saturation2' */
    if (rtb_TLft > 0.3F) {
      rtb_TLft = 0.3F;
    } else {
      if (rtb_TLft < 0.0F) {
        rtb_TLft = 0.0F;
      }
    }

    /* End of Saturate: '<S293>/Saturation2' */

    /* Product: '<S293>/Divide' incorporates:
     *  Constant: '<S293>/Constant2'
     */
    rtb_LL_ThresDet_lDvtThresLwrL_k = rtb_TLft / 0.3F;

    /* Product: '<S293>/Divide5' */
    rtb_LL_ThresDet_lDvtThresUprL_g = rtb_LL_ThresDet_lDvtThresLwrL_k *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S293>/Divide6' */
    rtb_TLft = rtb_LL_ThresDet_lDvtThresLwrL_k * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S311>/Abs' incorporates:
     *  Abs: '<S302>/Abs'
     */
    rtb_Saturation10 = fabsf(rtb_Abs_k);
    rtb_y_n = rtb_Saturation10;

    /* Product: '<S311>/Divide' */
    rtb_Divide_p = rtb_TLft * rtb_y_n;

    /* Product: '<S293>/Divide4' */
    rtb_y_n = rtb_LL_ThresDet_lDvtThresLwrL_k * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S316>/Switch' incorporates:
     *  RelationalOperator: '<S316>/UpperRelop'
     */
    if (rtb_Divide_p < rtb_y_n) {
      rtb_Switch_d = rtb_y_n;
    } else {
      rtb_Switch_d = rtb_Divide_p;
    }

    /* End of Switch: '<S316>/Switch' */

    /* Switch: '<S316>/Switch2' incorporates:
     *  RelationalOperator: '<S316>/LowerRelop1'
     */
    if (rtb_Divide_p > rtb_LL_ThresDet_lDvtThresUprL_g) {
      rtb_Switch2_m = rtb_LL_ThresDet_lDvtThresUprL_g;
    } else {
      rtb_Switch2_m = rtb_Switch_d;
    }

    /* End of Switch: '<S316>/Switch2' */

    /* Saturate: '<S294>/Saturation3' */
    if (rtb_L0_C0 > 0.2F) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 0.2F;
    } else if (rtb_L0_C0 < (-0.2F)) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = (-0.2F);
    } else {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_L0_C0;
    }

    /* End of Saturate: '<S294>/Saturation3' */

    /* Saturate: '<S294>/Saturation2' */
    if (rtb_R0_C0_e > 4.0F) {
      x10 = 4.0F;
    } else if (rtb_R0_C0_e < (-2.0F)) {
      x10 = (-2.0F);
    } else {
      x10 = rtb_R0_C0_e;
    }

    /* End of Saturate: '<S294>/Saturation2' */

    /* Sum: '<S299>/Add2' incorporates:
     *  Product: '<S299>/Divide'
     *  Product: '<S299>/Divide1'
     *  Sum: '<S299>/Add'
     *  Sum: '<S299>/Add1'
     *  Trigonometry: '<S299>/Cos'
     *  Trigonometry: '<S299>/Sin'
     */
    x20 = ((x10 - rtb_Saturation4) - rtb_R0_C1) * cosf
      (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) + rtb_Saturation_ki * sinf
      (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Saturate: '<S284>/Saturation1' */
    if (x20 > 2.0F) {
      x20 = 2.0F;
    } else {
      if (x20 < (-2.0F)) {
        x20 = (-2.0F);
      }
    }

    /* End of Saturate: '<S284>/Saturation1' */

    /* Abs: '<S312>/Abs' incorporates:
     *  Abs: '<S303>/Abs'
     */
    rtb_Add5_j_tmp = fabsf(rtb_Abs_e);

    /* Product: '<S312>/Divide' incorporates:
     *  Abs: '<S312>/Abs'
     */
    rtb_Divide_k = rtb_TLft * rtb_Add5_j_tmp;

    /* Switch: '<S317>/Switch' incorporates:
     *  RelationalOperator: '<S317>/UpperRelop'
     */
    if (rtb_Divide_k < rtb_y_n) {
      rtb_Switch_on = rtb_y_n;
    } else {
      rtb_Switch_on = rtb_Divide_k;
    }

    /* End of Switch: '<S317>/Switch' */

    /* Switch: '<S317>/Switch2' incorporates:
     *  RelationalOperator: '<S317>/LowerRelop1'
     */
    if (rtb_Divide_k > rtb_LL_ThresDet_lDvtThresUprL_g) {
      rtb_Switch2_d = rtb_LL_ThresDet_lDvtThresUprL_g;
    } else {
      rtb_Switch2_d = rtb_Switch_on;
    }

    /* End of Switch: '<S317>/Switch2' */

    /* Switch: '<S310>/Switch3' incorporates:
     *  Constant: '<S312>/Constant'
     *  Gain: '<S310>/Gain1'
     *  Logic: '<S312>/Logical Operator'
     *  RelationalOperator: '<S312>/Relational Operator1'
     *  RelationalOperator: '<S312>/Relational Operator2'
     */
    if (rtb_Merge1_k >= 0.0F) {
      /* Switch: '<S310>/Switch2' incorporates:
       *  Constant: '<S310>/Constant2'
       *  Constant: '<S311>/Constant'
       *  DataTypeConversion: '<S310>/Cast To Single'
       *  Logic: '<S311>/Logical Operator'
       *  RelationalOperator: '<S311>/Relational Operator1'
       *  RelationalOperator: '<S311>/Relational Operator3'
       */
      if (rtb_Merge1_k > 0.0F) {
        rtb_EPS_LKA_Control = (uint8)((0.0F < rtb_LL_LKA_EarliestWarnLine_C) &&
          (rtb_LL_LKA_EarliestWarnLine_C <= rtb_Switch2_m));
      } else {
        rtb_EPS_LKA_Control = ((uint8)0U);
      }

      /* End of Switch: '<S310>/Switch2' */
    } else {
      rtb_EPS_LKA_Control = (uint8)(((uint32)((0.0F < x20) && (x20 <=
        rtb_Switch2_d)) * ((uint8)128U)) >> 6);
    }

    /* End of Switch: '<S310>/Switch3' */

    /* DataTypeConversion: '<S286>/Data Type Conversion' incorporates:
     *  Constant: '<S320>/Constant'
     *  Constant: '<S321>/Constant'
     *  Constant: '<S322>/Constant'
     *  Constant: '<S323>/Constant'
     *  Logic: '<S286>/Logical Operator'
     *  Logic: '<S286>/Logical Operator1'
     *  Logic: '<S286>/Logical Operator2'
     *  RelationalOperator: '<S320>/Compare'
     *  RelationalOperator: '<S321>/Compare'
     *  RelationalOperator: '<S322>/Compare'
     *  RelationalOperator: '<S323>/Compare'
     *  Switch: '<S52>/Switch'
     *  Switch: '<S52>/Switch1'
     */
    rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((rtb_R0_Q > ((uint8)2U)) &&
      (rtb_EPS_LKA_Control == ((uint8)2U))) || ((rtb_EPS_LKA_Control == ((uint8)
      1U)) && (rtb_L0_Q > ((uint8)2U))));

    /* DataTypeConversion: '<S285>/Cast To Single' incorporates:
     *  Constant: '<S318>/Constant'
     *  Constant: '<S319>/Constant'
     *  Logic: '<S285>/Logical Operator'
     *  RelationalOperator: '<S318>/Compare'
     *  RelationalOperator: '<S319>/Compare'
     */
    rtb_IMAPve_d_BCM_Left_Light = (uint8)((rtb_IMAPve_d_EPS_LKA_State == ((uint8)
      1U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)));

    /* If: '<S283>/If1' incorporates:
     *  Constant: '<S288>/Constant'
     *  Constant: '<S291>/Constant'
     *  Constant: '<S292>/Constant'
     */
    if ((LKAS_B.Divide == 2) && (rtb_EPS_LKA_Control == 1) &&
        (rtb_IMAPve_d_BCM_Left_Light == 1) && (rtb_IMAPve_d_BCM_HazardLamp == 1))
    {
      /* Outputs for IfAction SubSystem: '<S283>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S291>/Action Port'
       */
      LKAS_B.Merge2 = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S283>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((LKAS_B.Divide == 2) && (rtb_EPS_LKA_Control == 2) &&
               (rtb_IMAPve_d_BCM_Left_Light == 1) &&
               (rtb_IMAPve_d_BCM_HazardLamp == 1)) {
      /* Outputs for IfAction SubSystem: '<S283>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S292>/Action Port'
       */
      LKAS_B.Merge2 = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S283>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S283>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S288>/Action Port'
       */
      LKAS_B.Merge2 = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S283>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S283>/If1' */

    /* Product: '<S334>/Divide' */
    rtb_y_n = rtb_Saturation * rtb_LL_ThresDet_lDvtThresUprL_h;

    /* Product: '<S334>/Divide1' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_LL_ThresDet_lDvtThresUprL_h *
      rtb_L0_C0;

    /* If: '<S348>/If' */
    if ((rtb_y_n >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) ||
        (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S348>/Ph1SWA' incorporates:
       *  ActionPort: '<S352>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_k5);

      /* End of Outputs for SubSystem: '<S348>/Ph1SWA' */
    } else if ((rtb_y_n <= -rtb_LL_DvtSpdDet_vDvtSpdMin_C) ||
               (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                -rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S348>/Ph2SWA' incorporates:
       *  ActionPort: '<S353>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_k5);

      /* End of Outputs for SubSystem: '<S348>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S348>/Ph3SWA' incorporates:
       *  ActionPort: '<S354>/Action Port'
       */
      LKAS_Ph3SWA(&rtb_Merge1_k5);

      /* End of Outputs for SubSystem: '<S348>/Ph3SWA' */
    }

    /* End of If: '<S348>/If' */

    /* Saturate: '<S333>/Saturation4' */
    if (rtb_LL_DvtComp_C > 0.1F) {
      rtb_Saturation4 = 0.1F;
    } else if (rtb_LL_DvtComp_C < (-0.1F)) {
      rtb_Saturation4 = (-0.1F);
    } else {
      rtb_Saturation4 = rtb_LL_DvtComp_C;
    }

    /* End of Saturate: '<S333>/Saturation4' */

    /* Saturate: '<S333>/Saturation1' */
    if (rtb_Saturation > 0.2F) {
      rtb_TLft = 0.2F;
    } else if (rtb_Saturation < (-0.2F)) {
      rtb_TLft = (-0.2F);
    } else {
      rtb_TLft = rtb_Saturation;
    }

    /* End of Saturate: '<S333>/Saturation1' */

    /* Saturate: '<S333>/Saturation' */
    if (rtb_L0_C0_a > 3.0F) {
      x10 = 3.0F;
    } else if (rtb_L0_C0_a < (-3.0F)) {
      x10 = (-3.0F);
    } else {
      x10 = rtb_L0_C0_a;
    }

    /* End of Saturate: '<S333>/Saturation' */

    /* Gain: '<S337>/Gain' incorporates:
     *  Product: '<S337>/Divide'
     *  Product: '<S337>/Divide1'
     *  Sum: '<S337>/Add'
     *  Sum: '<S337>/Add1'
     *  Sum: '<S337>/Add2'
     *  Trigonometry: '<S337>/Cos'
     *  Trigonometry: '<S337>/Sin'
     */
    rtb_LL_DvtComp_C = (((x10 - rtb_Saturation4) + rtb_R0_C1) * cosf(rtb_TLft) +
                        rtb_Saturation_ki * sinf(rtb_TLft)) * (-1.0F);

    /* Saturate: '<S325>/Saturation5' */
    if (rtb_LL_DvtComp_C > 1.0F) {
      rtb_LL_DvtComp_C = 1.0F;
    } else {
      if (rtb_LL_DvtComp_C < (-1.0F)) {
        rtb_LL_DvtComp_C = (-1.0F);
      }
    }

    /* End of Saturate: '<S325>/Saturation5' */

    /* Saturate: '<S332>/Saturation1' */
    if (rtb_L0_TLC > 5.5F) {
      rtb_TLft = 5.5F;
    } else if (rtb_L0_TLC < 2.4F) {
      rtb_TLft = 2.4F;
    } else {
      rtb_TLft = rtb_L0_TLC;
    }

    /* End of Saturate: '<S332>/Saturation1' */

    /* Sum: '<S332>/Add2' incorporates:
     *  Constant: '<S332>/Constant1'
     *  Gain: '<S332>/Gain'
     */
    rtb_TLft = 0.25F * rtb_TLft - 0.6F;

    /* Saturate: '<S332>/Saturation2' */
    if (rtb_TLft > 0.3F) {
      rtb_TLft = 0.3F;
    } else {
      if (rtb_TLft < 0.0F) {
        rtb_TLft = 0.0F;
      }
    }

    /* End of Saturate: '<S332>/Saturation2' */

    /* Product: '<S332>/Divide' incorporates:
     *  Constant: '<S332>/Constant2'
     */
    rtb_TLft /= 0.3F;

    /* Product: '<S332>/Divide5' */
    rtb_LL_ThresDet_lDvtThresUprL_g = rtb_TLft * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S332>/Divide6' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_TLft * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S350>/Abs' */
    rtb_y_a = fabsf(rtb_y_n);

    /* Product: '<S350>/Divide' */
    rtb_Divide_kt = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_y_a;

    /* Product: '<S332>/Divide4' */
    rtb_y_a = rtb_TLft * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S355>/Switch' incorporates:
     *  RelationalOperator: '<S355>/UpperRelop'
     */
    if (rtb_Divide_kt < rtb_y_a) {
      rtb_Switch_g = rtb_y_a;
    } else {
      rtb_Switch_g = rtb_Divide_kt;
    }

    /* End of Switch: '<S355>/Switch' */

    /* Switch: '<S355>/Switch2' incorporates:
     *  RelationalOperator: '<S355>/LowerRelop1'
     */
    if (rtb_Divide_kt > rtb_LL_ThresDet_lDvtThresUprL_g) {
      rtb_Switch2_l = rtb_LL_ThresDet_lDvtThresUprL_g;
    } else {
      rtb_Switch2_l = rtb_Switch_g;
    }

    /* End of Switch: '<S355>/Switch2' */

    /* Saturate: '<S333>/Saturation3' */
    if (rtb_L0_C0 > 0.2F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 0.2F;
    } else if (rtb_L0_C0 < (-0.2F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-0.2F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_L0_C0;
    }

    /* End of Saturate: '<S333>/Saturation3' */

    /* Saturate: '<S333>/Saturation2' */
    if (rtb_R0_C0_e > 3.0F) {
      x10 = 3.0F;
    } else if (rtb_R0_C0_e < (-3.0F)) {
      x10 = (-3.0F);
    } else {
      x10 = rtb_R0_C0_e;
    }

    /* End of Saturate: '<S333>/Saturation2' */

    /* Sum: '<S338>/Add2' incorporates:
     *  Product: '<S338>/Divide'
     *  Product: '<S338>/Divide1'
     *  Sum: '<S338>/Add'
     *  Sum: '<S338>/Add1'
     *  Trigonometry: '<S338>/Cos'
     *  Trigonometry: '<S338>/Sin'
     */
    rtb_LL_ThresDet_tiTTLCThresLKA = ((x10 - rtb_Saturation4) - rtb_R0_C1) *
      cosf(rtb_LL_ThresDet_lDvtThresLwrLKA) + rtb_Saturation_ki * sinf
      (rtb_LL_ThresDet_lDvtThresLwrLKA);

    /* Saturate: '<S325>/Saturation1' */
    if (rtb_LL_ThresDet_tiTTLCThresLKA > 1.0F) {
      rtb_LL_ThresDet_tiTTLCThresLKA = 1.0F;
    } else {
      if (rtb_LL_ThresDet_tiTTLCThresLKA < (-1.0F)) {
        rtb_LL_ThresDet_tiTTLCThresLKA = (-1.0F);
      }
    }

    /* End of Saturate: '<S325>/Saturation1' */

    /* Product: '<S351>/Divide' incorporates:
     *  Abs: '<S351>/Abs'
     */
    rtb_Divide_an = rtb_LL_ThresDet_lDvtThresUprLKA * fabsf
      (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Switch: '<S356>/Switch' incorporates:
     *  RelationalOperator: '<S356>/UpperRelop'
     */
    if (rtb_Divide_an < rtb_y_a) {
      rtb_Switch_ov = rtb_y_a;
    } else {
      rtb_Switch_ov = rtb_Divide_an;
    }

    /* End of Switch: '<S356>/Switch' */

    /* Switch: '<S356>/Switch2' incorporates:
     *  RelationalOperator: '<S356>/LowerRelop1'
     */
    if (rtb_Divide_an > rtb_LL_ThresDet_lDvtThresUprL_g) {
      rtb_Switch2_k = rtb_LL_ThresDet_lDvtThresUprL_g;
    } else {
      rtb_Switch2_k = rtb_Switch_ov;
    }

    /* End of Switch: '<S356>/Switch2' */

    /* Switch: '<S349>/Switch3' incorporates:
     *  Constant: '<S351>/Constant'
     *  Gain: '<S349>/Gain1'
     *  Logic: '<S351>/Logical Operator'
     *  RelationalOperator: '<S351>/Relational Operator1'
     *  RelationalOperator: '<S351>/Relational Operator2'
     */
    if (rtb_Merge1_k5 >= 0.0F) {
      /* Switch: '<S349>/Switch2' incorporates:
       *  Constant: '<S349>/Constant2'
       *  Constant: '<S350>/Constant'
       *  DataTypeConversion: '<S349>/Cast To Single'
       *  Logic: '<S350>/Logical Operator'
       *  RelationalOperator: '<S350>/Relational Operator1'
       *  RelationalOperator: '<S350>/Relational Operator2'
       */
      if (rtb_Merge1_k5 > 0.0F) {
        rtb_IMAPve_d_BCM_Left_Light = (uint8)((0.0F < rtb_LL_DvtComp_C) &&
          (rtb_LL_DvtComp_C <= rtb_Switch2_l));
      } else {
        rtb_IMAPve_d_BCM_Left_Light = ((uint8)0U);
      }

      /* End of Switch: '<S349>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Left_Light = (uint8)(((uint32)((0.0F <
        rtb_LL_ThresDet_tiTTLCThresLKA) && (rtb_LL_ThresDet_tiTTLCThresLKA <=
        rtb_Switch2_k)) * ((uint8)128U)) >> 6);
    }

    /* End of Switch: '<S349>/Switch3' */

    /* Saturate: '<S326>/Saturation' */
    if (rtb_Merge_k > 0.005F) {
      x10 = 0.005F;
    } else if (rtb_Merge_k < (-0.005F)) {
      x10 = (-0.005F);
    } else {
      x10 = rtb_Merge_k;
    }

    /* End of Saturate: '<S326>/Saturation' */

    /* MATLAB Function: '<S326>/MATLAB Function' incorporates:
     *  Abs: '<S326>/Abs1'
     *  Constant: '<S326>/Constant'
     *  Product: '<S326>/Divide2'
     */
    x10 = (1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL - fminf(fmaxf(60.0F,
             rtb_IMAPve_g_ESC_VehSpd), 80.0F) / 120.0F *
           rtb_LL_MAX_DRIVER_TORQUE_DISABL) * 0.8F + fabsf(x10) / 0.005F;
    if ((rtb_IMAPve_d_BCM_Left_Light == 2) && (rtb_IMAPve_g_EPS_SW_Trq > x10)) {
      rtb_Switch3_0 = 1;
    } else {
      rtb_Switch3_0 = ((rtb_IMAPve_d_BCM_Left_Light == 1) &&
                       (rtb_IMAPve_g_EPS_SW_Trq < -x10));
    }

    /* End of MATLAB Function: '<S326>/MATLAB Function' */

    /* Outputs for Enabled SubSystem: '<S326>/Count 0.2s' incorporates:
     *  EnablePort: '<S359>/Enable'
     */
    if (rtb_Switch3_0 > 0) {
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Sum: '<S359>/Add' incorporates:
         *  Memory: '<S359>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_n = ((uint16)0U);
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S359>/Add' incorporates:
       *  DataTypeConversion: '<S359>/Cast To Single'
       *  Memory: '<S359>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_n++;

      /* Saturate: '<S359>/Saturation' */
      if (LKAS_DW.Memory_PreviousInput_n >= ((uint16)50000U)) {
        /* Sum: '<S359>/Add' */
        LKAS_DW.Memory_PreviousInput_n = ((uint16)50000U);
      }

      /* End of Saturate: '<S359>/Saturation' */

      /* DataTypeConversion: '<S326>/Cast To Single' incorporates:
       *  Constant: '<S326>/Constant2'
       *  Product: '<S326>/Divide'
       */
      x10 = fmodf(floorf(0.2F / rtb_LKA_SampleTime), 65536.0F);

      /* RelationalOperator: '<S359>/Relational Operator' incorporates:
       *  DataTypeConversion: '<S326>/Cast To Single'
       */
      LKAS_B.RelationalOperator_fi = (LKAS_DW.Memory_PreviousInput_n >= (x10 <
        0.0F ? (sint32)(uint16)-(sint16)(uint16)-x10 : (sint32)(uint16)x10));
    } else {
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S359>/Out' */
        LKAS_B.RelationalOperator_fi = false;
        LKAS_DW.Count02s_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S326>/Count 0.2s' */

    /* RelationalOperator: '<S369>/Compare' incorporates:
     *  Constant: '<S369>/Constant'
     */
    rtb_Compare_cg = ((sint32)LKAS_B.RelationalOperator_fi > (sint32)false);

    /* UnitDelay: '<S361>/Unit Delay' */
    rtb_UnitDelay_d = LKAS_DW.UnitDelay_DSTATE_c;

    /* RelationalOperator: '<S368>/Compare' incorporates:
     *  Constant: '<S368>/Constant'
     */
    rtb_Compare_ki = ((sint32)rtb_UnitDelay_d <= (sint32)false);

    /* If: '<S361>/If' incorporates:
     *  Constant: '<S364>/Constant'
     *  Constant: '<S365>/Constant'
     *  RelationalOperator: '<S362>/FixPt Relational Operator'
     *  RelationalOperator: '<S363>/FixPt Relational Operator'
     *  UnitDelay: '<S362>/Delay Input1'
     *  UnitDelay: '<S363>/Delay Input1'
     *
     * Block description for '<S362>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S363>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if (LKAS_B.RelationalOperator_fi && ((sint32)rtb_Compare_cg > (sint32)
         LKAS_DW.DelayInput1_DSTATE_b)) {
      /* Outputs for IfAction SubSystem: '<S361>/If Action Subsystem' incorporates:
       *  ActionPort: '<S364>/Action Port'
       */
      rtb_Merge_d = true;

      /* End of Outputs for SubSystem: '<S361>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_d) && ((sint32)rtb_Compare_ki > (sint32)
                LKAS_DW.DelayInput1_DSTATE_p)) {
      /* Outputs for IfAction SubSystem: '<S361>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S365>/Action Port'
       */
      rtb_Merge_d = false;

      /* End of Outputs for SubSystem: '<S361>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S361>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S366>/Action Port'
       */
      LKAS_IfActionSubsystem3_m(rtb_UnitDelay_d, &rtb_Merge_d);

      /* End of Outputs for SubSystem: '<S361>/If Action Subsystem3' */
    }

    /* End of If: '<S361>/If' */

    /* Outputs for Enabled SubSystem: '<S326>/Count' incorporates:
     *  EnablePort: '<S358>/Enable'
     */
    /* Logic: '<S326>/Logical Operator' incorporates:
     *  Constant: '<S357>/Constant'
     *  Memory: '<S326>/Memory'
     *  RelationalOperator: '<S357>/Compare'
     */
    if ((rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U)) &&
        LKAS_DW.Memory_PreviousInput_eb) {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S358>/Memory' */
        LKAS_DW.Memory_PreviousInput_e0 = ((uint16)0U);
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S358>/Add' incorporates:
       *  Memory: '<S358>/Memory'
       */
      LKAS_B.Saturation_l = (uint16)(1U + LKAS_DW.Memory_PreviousInput_e0);

      /* Saturate: '<S358>/Saturation' */
      if (LKAS_B.Saturation_l >= ((uint16)50000U)) {
        /* Sum: '<S358>/Add' */
        LKAS_B.Saturation_l = ((uint16)50000U);
      }

      /* End of Saturate: '<S358>/Saturation' */

      /* Update for Memory: '<S358>/Memory' */
      LKAS_DW.Memory_PreviousInput_e0 = LKAS_B.Saturation_l;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Sum: '<S358>/Add' incorporates:
         *  Outport: '<S358>/Out'
         */
        LKAS_B.Saturation_l = ((uint16)0U);
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S326>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S326>/Count' */

    /* Outputs for Enabled SubSystem: '<S361>/Sum Condition1' incorporates:
     *  EnablePort: '<S367>/state = reset'
     */
    if (rtb_Merge_d) {
      if (!LKAS_DW.SumCondition1_MODE_d) {
        /* InitializeConditions for Sum: '<S367>/Add1' incorporates:
         *  Memory: '<S367>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_ps = ((uint16)0U);
        LKAS_DW.SumCondition1_MODE_d = true;
      }

      /* Sum: '<S367>/Add1' incorporates:
       *  Memory: '<S367>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_ps = (uint16)((uint32)rtb_Merge_d +
        LKAS_DW.Memory_PreviousInput_ps);

      /* Saturate: '<S367>/Saturation' */
      if (LKAS_DW.Memory_PreviousInput_ps >= ((uint16)1000U)) {
        /* Sum: '<S367>/Add1' */
        LKAS_DW.Memory_PreviousInput_ps = ((uint16)1000U);
      }

      /* End of Saturate: '<S367>/Saturation' */

      /* DataTypeConversion: '<S326>/Cast To Single1' incorporates:
       *  Constant: '<S326>/Constant1'
       *  Product: '<S326>/Divide1'
       */
      x10 = fmodf(floorf(1.0F / rtb_LKA_SampleTime), 65536.0F);

      /* RelationalOperator: '<S367>/Relational Operator' incorporates:
       *  DataTypeConversion: '<S326>/Cast To Single1'
       *  Sum: '<S326>/Add'
       */
      LKAS_B.RelationalOperator_mu = (LKAS_DW.Memory_PreviousInput_ps <= (uint16)
        ((uint32)(x10 < 0.0F ? (sint32)(uint16)-(sint16)(uint16)-x10 : (sint32)
                  (uint16)x10) + LKAS_B.Saturation_l));
    } else {
      if (LKAS_DW.SumCondition1_MODE_d) {
        /* Disable for Outport: '<S367>/Out' */
        LKAS_B.RelationalOperator_mu = false;
        LKAS_DW.SumCondition1_MODE_d = false;
      }
    }

    /* End of Outputs for SubSystem: '<S361>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S327>/Sum Condition1' incorporates:
     *  EnablePort: '<S373>/state = reset'
     */
    /* Logic: '<S327>/Logical Operator' incorporates:
     *  Constant: '<S371>/Constant'
     *  Constant: '<S372>/Constant'
     *  Delay: '<S75>/Delay1'
     *  RelationalOperator: '<S371>/Compare'
     *  RelationalOperator: '<S372>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_o) {
        /* InitializeConditions for Sum: '<S373>/Add1' incorporates:
         *  Memory: '<S373>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_a1 = ((uint16)0U);
        LKAS_DW.SumCondition1_MODE_o = true;
      }

      /* Sum: '<S373>/Add1' incorporates:
       *  Memory: '<S373>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_a1++;

      /* Saturate: '<S373>/Saturation' */
      if (LKAS_DW.Memory_PreviousInput_a1 >= ((uint16)100U)) {
        /* Sum: '<S373>/Add1' */
        LKAS_DW.Memory_PreviousInput_a1 = ((uint16)100U);
      }

      /* End of Saturate: '<S373>/Saturation' */

      /* DataTypeConversion: '<S327>/Cast To Single1' incorporates:
       *  Product: '<S327>/Divide'
       */
      x10 = fmodf(floorf(rtb_LL_TkOvStChk_tiTDelTime / rtb_LKA_SampleTime),
                  65536.0F);

      /* DataTypeConversion: '<S373>/Data Type Conversion' incorporates:
       *  DataTypeConversion: '<S327>/Cast To Single1'
       *  RelationalOperator: '<S373>/Relational Operator'
       */
      LKAS_B.DataTypeConversion_c = (LKAS_DW.Memory_PreviousInput_a1 >= (x10 <
        0.0F ? (sint32)(uint16)-(sint16)(uint16)-x10 : (sint32)(uint16)x10));
    } else {
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S373>/Out' */
        LKAS_B.DataTypeConversion_c = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }
    }

    /* End of Logic: '<S327>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S327>/Sum Condition1' */

    /* Delay: '<S75>/Delay' */
    rtb_LogicalOperator3_c = LKAS_DW.Delay_DSTATE_e;

    /* If: '<S324>/If1' incorporates:
     *  Constant: '<S329>/Constant'
     *  Constant: '<S331>/Constant'
     *  Constant: '<S370>/Constant'
     *  Delay: '<S75>/Delay'
     *  Logic: '<S324>/Logical Operator'
     *  Logic: '<S327>/Logical Operator1'
     *  RelationalOperator: '<S370>/Compare'
     */
    if ((LKAS_B.Divide == 2) && (LKAS_B.RelationalOperator_mu ||
         ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
          LKAS_B.DataTypeConversion_c) || LKAS_DW.Delay_DSTATE_e)) {
      /* Outputs for IfAction SubSystem: '<S324>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S331>/Action Port'
       */
      LKAS_B.Merge1_b = true;

      /* End of Outputs for SubSystem: '<S324>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S324>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S329>/Action Port'
       */
      LKAS_B.Merge1_b = false;

      /* End of Outputs for SubSystem: '<S324>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S324>/If1' */

    /* Sum: '<S501>/Add1' */
    rtb_Add1_k = rtb_Add1_g_tmp;

    /* Switch: '<S502>/Switch' incorporates:
     *  Constant: '<S501>/Constant'
     *  RelationalOperator: '<S502>/UpperRelop'
     */
    if (rtb_Add1_k < 0.0F) {
      rtb_Switch_k = 0.0F;
    } else {
      rtb_Switch_k = rtb_Add1_k;
    }

    /* End of Switch: '<S502>/Switch' */

    /* Switch: '<S502>/Switch2' incorporates:
     *  RelationalOperator: '<S502>/LowerRelop1'
     */
    if (rtb_Add1_k > rtb_LL_LDW_EarliestWarnLine_C) {
      rtb_Switch2_c = rtb_LL_LDW_EarliestWarnLine_C;
    } else {
      rtb_Switch2_c = rtb_Switch_k;
    }

    /* End of Switch: '<S502>/Switch2' */

    /* Logic: '<S486>/Logical Operator3' incorporates:
     *  Constant: '<S499>/Constant'
     *  Constant: '<S500>/Constant'
     *  Logic: '<S497>/Logical Operator'
     *  Logic: '<S498>/Logical Operator'
     *  RelationalOperator: '<S498>/Relational Operator1'
     *  RelationalOperator: '<S498>/Relational Operator2'
     *  RelationalOperator: '<S499>/Compare'
     *  RelationalOperator: '<S500>/Compare'
     */
    rtb_LogicalOperator3_n = ((LKAS_B.Divide >= ((uint8)1U)) && (((rtb_Gain1_i >=
      rtb_Switch2_c) && (rtb_Add5_j >= rtb_Switch2_c)) == (sint32)true) &&
      rtb_LogicalOperator3_n);

    /* If: '<S486>/If' incorporates:
     *  Constant: '<S493>/Constant'
     *  DataTypeConversion: '<S486>/Cast To Single'
     *  DataTypeConversion: '<S486>/Cast To Single1'
     */
    if (((LKAS_B.Divide == 1) || (LKAS_B.Divide == 2)) && rtb_LogicalOperator3_n)
    {
      /* Outputs for IfAction SubSystem: '<S486>/If Action Subsystem' incorporates:
       *  ActionPort: '<S493>/Action Port'
       */
      LKAS_B.Merge_k = true;

      /* End of Outputs for SubSystem: '<S486>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S486>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S495>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_B.Merge_k);

      /* End of Outputs for SubSystem: '<S486>/If Action Subsystem3' */
    }

    /* End of If: '<S486>/If' */

    /* Delay: '<S75>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S376>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S376>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    LKAS_DW.u13u11u2u3_ActiveSubsystem = (sint8)((rtb_LDW_State != 4) &&
      ((rtb_LDW_State != 5) || (LKAS_DW.Memory_PreviousInput_ms != rtb_LDW_State)));
    switch (LKAS_DW.u13u11u2u3_ActiveSubsystem) {
     case 0:
      if (LKAS_DW.u13u11u2u3_ActiveSubsystem != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S376>/If Action Subsystem' incorporates:
         *  ActionPort: '<S408>/Action Port'
         */
        /* InitializeConditions for If: '<S376>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S408>/Memory'
         *  Sum: '<S408>/Add1'
         */
        LKAS_DW.Memory_PreviousInput_pu = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S376>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S376>/If Action Subsystem' incorporates:
       *  ActionPort: '<S408>/Action Port'
       */
      /* Sum: '<S408>/Add1' incorporates:
       *  Constant: '<S408>/Constant1'
       *  Memory: '<S408>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_pu += (float32)((uint16)1U);

      /* Saturate: '<S408>/Saturation' */
      if (LKAS_DW.Memory_PreviousInput_pu > 10000.0F) {
        /* Sum: '<S408>/Add1' */
        LKAS_DW.Memory_PreviousInput_pu = 10000.0F;
      } else {
        if (LKAS_DW.Memory_PreviousInput_pu < 0.0F) {
          /* Sum: '<S408>/Add1' */
          LKAS_DW.Memory_PreviousInput_pu = 0.0F;
        }
      }

      /* End of Saturate: '<S408>/Saturation' */
      /* End of Outputs for SubSystem: '<S376>/If Action Subsystem' */

      /* Switch: '<S567>/Switch25' incorporates:
       *  Constant: '<S567>/LL_Max_LDWS_Warning_Time=5'
       */
      if (LKAS_ConstB.DataTypeConversion61 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion61;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S567>/Switch25' */

      /* DataTypeConversion: '<S376>/Cast To Single1' incorporates:
       *  Product: '<S376>/Divide'
       */
      x10 = fmodf(floorf(x10 / rtb_LKA_SampleTime), 65536.0F);

      /* Outputs for IfAction SubSystem: '<S376>/If Action Subsystem' incorporates:
       *  ActionPort: '<S408>/Action Port'
       */
      /* DataTypeConversion: '<S408>/Data Type Conversion' incorporates:
       *  DataTypeConversion: '<S376>/Cast To Single1'
       *  RelationalOperator: '<S408>/Relational Operator'
       */
      rtb_LogicalOperator3_c = (LKAS_DW.Memory_PreviousInput_pu >= (x10 < 0.0F ?
        (sint32)(uint16)-(sint16)(uint16)-x10 : (sint32)(uint16)x10));

      /* End of Outputs for SubSystem: '<S376>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S376>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S409>/Action Port'
       */
      /* SignalConversion: '<S409>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S409>/Constant'
       */
      rtb_LogicalOperator3_c = false;

      /* End of Outputs for SubSystem: '<S376>/If Action Subsystem1' */
      break;
    }

    /* End of If: '<S376>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S374>/Logical Operator3' incorporates:
     *  Constant: '<S412>/Constant'
     *  Constant: '<S413>/Constant'
     *  Logic: '<S410>/Logical Operator'
     *  Logic: '<S411>/Logical Operator'
     *  RelationalOperator: '<S411>/Relational Operator1'
     *  RelationalOperator: '<S411>/Relational Operator2'
     *  RelationalOperator: '<S412>/Compare'
     *  RelationalOperator: '<S413>/Compare'
     */
    rtb_LogicalOperator3_c = (((LKAS_B.Divide >= ((uint8)1U)) && (((rtb_Gain1_i <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_j <= rtb_LL_LDW_LatestWarnLine_C))
      == (sint32)true)) || rtb_LogicalOperator3_c || rtb_LogicalOperator2_p);

    /* If: '<S374>/If1' incorporates:
     *  Constant: '<S383>/Constant'
     *  DataTypeConversion: '<S374>/Cast To Single'
     *  DataTypeConversion: '<S374>/Cast To Single1'
     */
    if (((LKAS_B.Divide == 1) || (LKAS_B.Divide == 2)) && rtb_LogicalOperator3_c)
    {
      /* Outputs for IfAction SubSystem: '<S374>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S383>/Action Port'
       */
      LKAS_B.Merge1_j = true;

      /* End of Outputs for SubSystem: '<S374>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S374>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S385>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_B.Merge1_j);

      /* End of Outputs for SubSystem: '<S374>/If Action Subsystem4' */
    }

    /* End of If: '<S374>/If1' */

    /* If: '<S300>/If' */
    if ((rtb_Abs_k >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_e >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S300>/Ph1SWA' incorporates:
       *  ActionPort: '<S304>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S300>/Ph1SWA' */
    } else if ((rtb_Abs_k <= -rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_e <=
                -rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S300>/Ph2SWA' incorporates:
       *  ActionPort: '<S305>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S300>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S300>/Ph3SWA' incorporates:
       *  ActionPort: '<S306>/Action Port'
       */
      LKAS_Ph3SWA(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S300>/Ph3SWA' */
    }

    /* End of If: '<S300>/If' */

    /* Product: '<S293>/Divide2' */
    rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_LL_ThresDet_lDvtThresLwrL_k *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S293>/Divide3' */
    rtb_y_a = rtb_LL_ThresDet_lDvtThresLwrL_k * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S302>/Divide' */
    rtb_Divide_f = rtb_y_a * rtb_Saturation10;

    /* Product: '<S293>/Divide1' */
    rtb_LL_ThresDet_lDvtThresLwrL_k *= rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S307>/Switch' incorporates:
     *  RelationalOperator: '<S307>/UpperRelop'
     */
    if (rtb_Divide_f < rtb_LL_ThresDet_lDvtThresLwrL_k) {
      rtb_Switch_ob = rtb_LL_ThresDet_lDvtThresLwrL_k;
    } else {
      rtb_Switch_ob = rtb_Divide_f;
    }

    /* End of Switch: '<S307>/Switch' */

    /* Switch: '<S307>/Switch2' incorporates:
     *  RelationalOperator: '<S307>/LowerRelop1'
     */
    if (rtb_Divide_f > rtb_LL_ThresDet_lDvtThresLwrLKA) {
      rtb_Switch2_o = rtb_LL_ThresDet_lDvtThresLwrLKA;
    } else {
      rtb_Switch2_o = rtb_Switch_ob;
    }

    /* End of Switch: '<S307>/Switch2' */

    /* Product: '<S303>/Divide' */
    rtb_Divide_m = rtb_y_a * rtb_Add5_j_tmp;

    /* Switch: '<S308>/Switch' incorporates:
     *  RelationalOperator: '<S308>/UpperRelop'
     */
    if (rtb_Divide_m < rtb_LL_ThresDet_lDvtThresLwrL_k) {
      rtb_Switch_i = rtb_LL_ThresDet_lDvtThresLwrL_k;
    } else {
      rtb_Switch_i = rtb_Divide_m;
    }

    /* End of Switch: '<S308>/Switch' */

    /* Switch: '<S308>/Switch2' incorporates:
     *  RelationalOperator: '<S308>/LowerRelop1'
     */
    if (rtb_Divide_m > rtb_LL_ThresDet_lDvtThresLwrLKA) {
      rtb_Switch2_g = rtb_LL_ThresDet_lDvtThresLwrLKA;
    } else {
      rtb_Switch2_g = rtb_Switch_i;
    }

    /* End of Switch: '<S308>/Switch2' */

    /* Switch: '<S301>/Switch3' incorporates:
     *  Gain: '<S301>/Gain1'
     *  RelationalOperator: '<S303>/Relational Operator2'
     */
    if (rtb_Merge1_d >= 0.0F) {
      /* Switch: '<S301>/Switch2' incorporates:
       *  Constant: '<S301>/Constant2'
       *  DataTypeConversion: '<S301>/Cast To Single'
       *  RelationalOperator: '<S302>/Relational Operator2'
       */
      if (rtb_Merge1_d > 0.0F) {
        rtb_IMAPve_d_BCM_Left_Light = (uint8)(rtb_LL_LKA_EarliestWarnLine_C <=
          rtb_Switch2_o);
      } else {
        rtb_IMAPve_d_BCM_Left_Light = ((uint8)0U);
      }

      /* End of Switch: '<S301>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Left_Light = (uint8)(((uint32)(x20 <= rtb_Switch2_g) *
        ((uint8)128U)) >> 6);
    }

    /* End of Switch: '<S301>/Switch3' */

    /* If: '<S283>/If' incorporates:
     *  Constant: '<S287>/Constant'
     *  Constant: '<S289>/Constant'
     *  Constant: '<S290>/Constant'
     */
    if (((LKAS_B.Divide == 1) || (LKAS_B.Divide == 2)) &&
        (rtb_IMAPve_d_BCM_Left_Light == 1) && (rtb_IMAPve_d_BCM_HazardLamp == 1))
    {
      /* Outputs for IfAction SubSystem: '<S283>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S289>/Action Port'
       */
      LKAS_B.Merge_i = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S283>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if (((LKAS_B.Divide == 1) || (LKAS_B.Divide == 2)) &&
               (rtb_IMAPve_d_BCM_Left_Light == 2) &&
               (rtb_IMAPve_d_BCM_HazardLamp == 1)) {
      /* Outputs for IfAction SubSystem: '<S283>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S290>/Action Port'
       */
      LKAS_B.Merge_i = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S283>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S283>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S287>/Action Port'
       */
      LKAS_B.Merge_i = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S283>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S283>/If' */

    /* If: '<S339>/If' */
    if ((rtb_y_n >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) ||
        (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S339>/Ph1SWA' incorporates:
       *  ActionPort: '<S343>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_dq);

      /* End of Outputs for SubSystem: '<S339>/Ph1SWA' */
    } else if ((rtb_y_n <= -rtb_LL_DvtSpdDet_vDvtSpdMin_C) ||
               (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                -rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S339>/Ph2SWA' incorporates:
       *  ActionPort: '<S344>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_dq);

      /* End of Outputs for SubSystem: '<S339>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S339>/Ph3SWA' incorporates:
       *  ActionPort: '<S345>/Action Port'
       */
      LKAS_Ph3SWA(&rtb_Merge1_dq);

      /* End of Outputs for SubSystem: '<S339>/Ph3SWA' */
    }

    /* End of If: '<S339>/If' */

    /* Product: '<S332>/Divide2' */
    rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_TLft * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S332>/Divide3' */
    rtb_y_a = rtb_TLft * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Abs: '<S341>/Abs' */
    rtb_y_n = fabsf(rtb_y_n);

    /* Product: '<S341>/Divide' */
    rtb_Divide_kz = rtb_y_a * rtb_y_n;

    /* Product: '<S332>/Divide1' */
    rtb_TLft *= rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S346>/Switch' incorporates:
     *  RelationalOperator: '<S346>/UpperRelop'
     */
    if (rtb_Divide_kz < rtb_TLft) {
      rtb_Switch_p = rtb_TLft;
    } else {
      rtb_Switch_p = rtb_Divide_kz;
    }

    /* End of Switch: '<S346>/Switch' */

    /* Switch: '<S346>/Switch2' incorporates:
     *  RelationalOperator: '<S346>/LowerRelop1'
     */
    if (rtb_Divide_kz > rtb_LL_ThresDet_lDvtThresLwrLKA) {
      rtb_Switch2_ds = rtb_LL_ThresDet_lDvtThresLwrLKA;
    } else {
      rtb_Switch2_ds = rtb_Switch_p;
    }

    /* End of Switch: '<S346>/Switch2' */

    /* Abs: '<S342>/Abs' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = fabsf(rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Product: '<S342>/Divide' */
    rtb_Divide_l1 = rtb_y_a * rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;

    /* Switch: '<S347>/Switch' incorporates:
     *  RelationalOperator: '<S347>/UpperRelop'
     */
    if (rtb_Divide_l1 < rtb_TLft) {
      rtb_Switch_pw = rtb_TLft;
    } else {
      rtb_Switch_pw = rtb_Divide_l1;
    }

    /* End of Switch: '<S347>/Switch' */

    /* Switch: '<S347>/Switch2' incorporates:
     *  RelationalOperator: '<S347>/LowerRelop1'
     */
    if (rtb_Divide_l1 > rtb_LL_ThresDet_lDvtThresLwrLKA) {
      rtb_Switch2_h = rtb_LL_ThresDet_lDvtThresLwrLKA;
    } else {
      rtb_Switch2_h = rtb_Switch_pw;
    }

    /* End of Switch: '<S347>/Switch2' */

    /* Switch: '<S340>/Switch3' incorporates:
     *  Gain: '<S340>/Gain1'
     *  RelationalOperator: '<S342>/Relational Operator2'
     */
    if (rtb_Merge1_dq >= 0.0F) {
      /* Switch: '<S340>/Switch2' incorporates:
       *  Constant: '<S340>/Constant2'
       *  DataTypeConversion: '<S340>/Cast To Single'
       *  RelationalOperator: '<S341>/Relational Operator2'
       */
      if (rtb_Merge1_dq > 0.0F) {
        rtb_IMAPve_d_BCM_Left_Light = (uint8)(rtb_LL_DvtComp_C <= rtb_Switch2_ds);
      } else {
        rtb_IMAPve_d_BCM_Left_Light = ((uint8)0U);
      }

      /* End of Switch: '<S340>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Left_Light = (uint8)(((uint32)
        (rtb_LL_ThresDet_tiTTLCThresLKA <= rtb_Switch2_h) * ((uint8)128U)) >> 6);
    }

    /* End of Switch: '<S340>/Switch3' */

    /* If: '<S324>/If' incorporates:
     *  Constant: '<S328>/Constant'
     *  Constant: '<S330>/Constant'
     */
    if (((LKAS_B.Divide == 1) || (LKAS_B.Divide == 2)) &&
        (rtb_IMAPve_d_BCM_Left_Light == 0)) {
      /* Outputs for IfAction SubSystem: '<S324>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S330>/Action Port'
       */
      LKAS_B.Merge_f = true;

      /* End of Outputs for SubSystem: '<S324>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S324>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S328>/Action Port'
       */
      LKAS_B.Merge_f = false;

      /* End of Outputs for SubSystem: '<S324>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S324>/If' */

    /* Logic: '<S282>/Logical Operator1' incorporates:
     *  Constant: '<S541>/Constant'
     *  Constant: '<S574>/Constant'
     *  RelationalOperator: '<S541>/Compare'
     */
    rtb_LogicalOperator1_l = (((uint8)0U) == ((uint8)1U));

    /* Outputs for Enabled SubSystem: '<S282>/Count_5s3' */
    LKAS_Count_5s1(rtb_LogicalOperator1_l, rtb_LKA_SampleTime,
                   &LKAS_B.RelationalOperator_h, &LKAS_DW.Count_5s3);

    /* End of Outputs for SubSystem: '<S282>/Count_5s3' */

    /* RelationalOperator: '<S551>/Compare' incorporates:
     *  Constant: '<S551>/Constant'
     *  Constant: '<S575>/Constant'
     */
    rtb_Compare_am = (((uint8)0U) == ((uint8)3U));

    /* Outputs for Enabled SubSystem: '<S282>/Count_5s2' */
    LKAS_Count_5s1(rtb_Compare_am, rtb_LKA_SampleTime,
                   &LKAS_B.RelationalOperator_m, &LKAS_DW.Count_5s2);

    /* End of Outputs for SubSystem: '<S282>/Count_5s2' */

    /* Outputs for Enabled SubSystem: '<S282>/Count_5s4' */
    LKAS_Count_5s4(LKAS_ConstB.LogicalOperator2, rtb_LKA_SampleTime,
                   &LKAS_B.RelationalOperator_l, &LKAS_DW.Count_5s4);

    /* End of Outputs for SubSystem: '<S282>/Count_5s4' */

    /* Logic: '<S282>/Logical Operator10' incorporates:
     *  Logic: '<S282>/Logical Operator8'
     */
    rtb_LogicalOperator2_p = (LKAS_B.RelationalOperator_h ||
      LKAS_B.RelationalOperator_m);
    LKAS_B.LKA_Fault = (rtb_LogicalOperator2_p || LKAS_B.RelationalOperator_l);

    /* Chart: '<S75>/LDW_State_Machine'
     *
     * Block description for '<S75>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* RelationalOperator: '<S546>/Compare' incorporates:
     *  Constant: '<S546>/Constant'
     */
    rtb_Compare_mm = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

    /* Outputs for Enabled SubSystem: '<S282>/Count_5s1' */
    LKAS_Count_5s1(rtb_Compare_mm, rtb_LKA_SampleTime,
                   &LKAS_B.RelationalOperator_f, &LKAS_DW.Count_5s1);

    /* End of Outputs for SubSystem: '<S282>/Count_5s1' */

    /* Outputs for Enabled SubSystem: '<S282>/Count_5s5' */
    LKAS_Count_5s4(LKAS_ConstB.LogicalOperator3, rtb_LKA_SampleTime,
                   &LKAS_B.RelationalOperator, &LKAS_DW.Count_5s5);

    /* End of Outputs for SubSystem: '<S282>/Count_5s5' */

    /* Logic: '<S282>/Logical Operator8' */
    LKAS_B.LKA_Fault = (rtb_LogicalOperator2_p || LKAS_B.RelationalOperator_f ||
                        LKAS_B.RelationalOperator);

    /* Chart: '<S75>/LKA_State_Machine'
     *
     * Block description for '<S75>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Switch: '<S566>/Switch8' incorporates:
     *  Constant: '<S566>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S566>/Switch8' */

    /* Product: '<S224>/Divide' */
    rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_LL_ThresDet_lDvtThresUprL_h * x10;

    /* Product: '<S219>/Z*Z' */
    rtb_y_a = rtb_LL_ThresDet_lDvtThresLwrLKA * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Sum: '<S219>/Add' incorporates:
     *  Product: '<S219>/Product'
     *  Product: '<S219>/Product3'
     *  Product: '<S219>/Product4'
     *  Product: '<S219>/Z*Z*Z'
     */
    rtb_LL_LDW_EarliestWarnLine_C = ((rtb_Saturation *
      rtb_LL_ThresDet_lDvtThresLwrLKA + rtb_L0_C0_a) + rtb_L0_C2_p * rtb_y_a) +
      rtb_LL_ThresDet_lDvtThresLwrLKA * rtb_y_a * rtb_L0_C3_fd;

    /* Sum: '<S222>/Add' incorporates:
     *  Product: '<S222>/Product'
     *  Product: '<S222>/Product3'
     *  Product: '<S222>/Product4'
     *  Product: '<S222>/Z*Z*Z'
     */
    rtb_LL_LDW_LatestWarnLine_C = ((rtb_L0_C0 * rtb_LL_ThresDet_lDvtThresLwrLKA
      + rtb_R0_C0_e) + rtb_L0_C2 * rtb_y_a) + rtb_LL_ThresDet_lDvtThresLwrLKA *
      rtb_y_a * rtb_L0_C3;

    /* If: '<S216>/If' incorporates:
     *  Delay: '<S74>/Delay'
     */
    if (LKAS_DW.Delay_DSTATE == 1) {
      /* Outputs for IfAction SubSystem: '<S216>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S229>/Action Port'
       */
      LKAS_ifaction3(rtb_Gain1_i, &rtb_Merge_p);

      /* End of Outputs for SubSystem: '<S216>/If Action Subsystem2' */
    } else if (LKAS_DW.Delay_DSTATE == 2) {
      /* Outputs for IfAction SubSystem: '<S216>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S228>/Action Port'
       */
      LKAS_ifaction3(rtb_Add5_j, &rtb_Merge_p);

      /* End of Outputs for SubSystem: '<S216>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S216>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S230>/Action Port'
       */
      /* MinMax: '<S230>/Min' */
      rtb_Merge_p = fminf(rtb_Gain1_i, rtb_Add5_j);

      /* End of Outputs for SubSystem: '<S216>/If Action Subsystem3' */
    }

    /* End of If: '<S216>/If' */

    /* MinMax: '<S210>/Min' */
    rtb_y_a = fminf(rtb_LFTTTLC, rtb_RGTTTLC);

    /* Saturate: '<S210>/Saturation' */
    if (rtb_y_a > 2.0F) {
      rtb_y_a = 2.0F;
    } else {
      if (rtb_y_a < 0.5F) {
        rtb_y_a = 0.5F;
      }
    }

    /* End of Saturate: '<S210>/Saturation' */

    /* Product: '<S243>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LL_ThresDet_lDvtThresUprL_h * rtb_y_a;

    /* Product: '<S241>/Z*Z' incorporates:
     *  Product: '<S239>/Z*Z'
     */
    x10 = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Gain: '<S241>/Gain1' incorporates:
     *  Gain: '<S242>/Gain1'
     */
    rtb_L0_C3_fd *= 3.0F;

    /* Sum: '<S241>/Add' incorporates:
     *  Gain: '<S241>/Gain1'
     *  Product: '<S241>/Product3'
     *  Product: '<S241>/Product4'
     *  Product: '<S241>/Z*Z'
     */
    rtb_Add_b = (rtb_Add_hn_tmp * rtb_LL_ThresDet_lDvtThresUprLKA +
                 rtb_Saturation) + rtb_L0_C3_fd * x10;

    /* Gain: '<S239>/Gain1' incorporates:
     *  Gain: '<S240>/Gain1'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = 3.0F * rtb_L0_C3;

    /* Sum: '<S239>/Add' incorporates:
     *  Gain: '<S239>/Gain1'
     *  Product: '<S239>/Product3'
     *  Product: '<S239>/Product4'
     */
    rtb_Add_g5 = (rtb_Add_j_tmp * rtb_LL_ThresDet_lDvtThresUprLKA + rtb_L0_C0) +
      rtb_LL_ThresDet_lDvtThresLwrLDW * x10;

    /* If: '<S237>/If' incorporates:
     *  Delay: '<S74>/Delay'
     */
    if (LKAS_DW.Delay_DSTATE == 1) {
      /* Outputs for IfAction SubSystem: '<S237>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S249>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_b, &rtb_Merge_kn);

      /* End of Outputs for SubSystem: '<S237>/If Action Subsystem2' */
    } else if (LKAS_DW.Delay_DSTATE == 2) {
      /* Outputs for IfAction SubSystem: '<S237>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S248>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_g5, &rtb_Merge_kn);

      /* End of Outputs for SubSystem: '<S237>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S237>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S250>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_Add_b, rtb_Add_g5, &rtb_Merge_kn);

      /* End of Outputs for SubSystem: '<S237>/If Action Subsystem3' */
    }

    /* End of If: '<S237>/If' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S73>/states = reset'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Sum: '<S235>/Add' incorporates:
     *  Sum: '<S169>/Add1'
     */
    rtb_L0_C3 = rtb_Saturation + rtb_L0_C0;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Gain: '<S235>/Gain' incorporates:
     *  Sum: '<S235>/Add'
     */
    rtb_Gain_pe = rtb_L0_C3 * 0.5F;

    /* Switch: '<S566>/Switch3' incorporates:
     *  Constant: '<S566>/LL_HdAgPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion3_e != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion3_e;
    } else {
      x10 = LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S566>/Switch3' */

    /* Product: '<S244>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LL_ThresDet_lDvtThresUprL_h * x10;

    /* Product: '<S242>/Z*Z' incorporates:
     *  Product: '<S240>/Z*Z'
     */
    x10 = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Sum: '<S242>/Add' incorporates:
     *  Product: '<S242>/Product3'
     *  Product: '<S242>/Product4'
     *  Product: '<S242>/Z*Z'
     */
    rtb_LL_TkOvStChk_tiTDelTime = (rtb_Add_hn_tmp *
      rtb_LL_ThresDet_lDvtThresUprLKA + rtb_Saturation) + rtb_L0_C3_fd * x10;

    /* Sum: '<S240>/Add' incorporates:
     *  Product: '<S240>/Product3'
     *  Product: '<S240>/Product4'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = (rtb_Add_j_tmp *
      rtb_LL_ThresDet_lDvtThresUprLKA + rtb_L0_C0) +
      rtb_LL_ThresDet_lDvtThresLwrLDW * x10;

    /* Saturate: '<S214>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 0.001F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.001F;
    } else {
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S214>/Saturation' */

    /* Gain: '<S271>/kph To mps' incorporates:
     *  Gain: '<S272>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresUprLDW = 0.277777791F *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S271>/Saturation3' */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      x10 = 150.0F;
    } else if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
      x10 = 60.0F;
    } else {
      x10 = rtb_LL_ThresDet_lDvtThresUprLKA;
    }

    /* End of Saturate: '<S271>/Saturation3' */

    /* Product: '<S271>/Divide1' incorporates:
     *  Constant: '<S271>/Constant'
     */
    rtb_TLft = 0.09F / x10;

    /* Saturate: '<S271>/Saturation1' */
    if (rtb_TLft > 0.0117F) {
      rtb_TLft = 0.0117F;
    } else {
      if (rtb_TLft < 0.00237F) {
        rtb_TLft = 0.00237F;
      }
    }

    /* End of Saturate: '<S271>/Saturation1' */

    /* Switch: '<S566>/Switch7' incorporates:
     *  Constant: '<S566>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S566>/Switch7' */

    /* MATLAB Function: '<S271>/MATLAB Function' incorporates:
     *  Gain: '<S271>/kph To mps'
     */
    rtb_L0_C3_fd = (rtb_TLft * rtb_LL_ThresDet_lDvtThresUprLDW *
                    rtb_LL_ThresDet_lDvtThresUprLDW + 1.0F) * x10 *
      LKAS_B.LKA_StrRatio_C_g * LKAS_B.LKA_WhlBaseL_C_e /
      (rtb_LL_ThresDet_lDvtThresUprLDW * rtb_LL_ThresDet_lDvtThresUprLDW) *
      180.0F / 3.14F;

    /* Saturate: '<S272>/Saturation3' */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 60.0F;
      }
    }

    /* End of Saturate: '<S272>/Saturation3' */

    /* Product: '<S272>/Divide1' incorporates:
     *  Constant: '<S272>/Constant'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = 0.09F / rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S272>/Saturation1' */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 0.0117F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.0117F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 0.00237F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 0.00237F;
      }
    }

    /* End of Saturate: '<S272>/Saturation1' */

    /* Switch: '<S566>/Switch4' incorporates:
     *  Constant: '<S566>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S566>/Switch4' */

    /* MATLAB Function: '<S272>/MATLAB Function' */
    LKAS_B.SWARmax = (rtb_LL_ThresDet_lDvtThresUprLKA *
                      rtb_LL_ThresDet_lDvtThresUprLDW *
                      rtb_LL_ThresDet_lDvtThresUprLDW + 1.0F) * x10 *
      LKAS_B.LKA_StrRatio_C_g * LKAS_B.LKA_WhlBaseL_C_e /
      (rtb_LL_ThresDet_lDvtThresUprLDW * rtb_LL_ThresDet_lDvtThresUprLDW) *
      180.0F / 3.14F;

    /* Outputs for Enabled SubSystem: '<S260>/Subsystem' incorporates:
     *  EnablePort: '<S264>/Enable'
     */
    /* Logic: '<S260>/Logical Operator3' incorporates:
     *  Abs: '<S260>/Abs4'
     *  Abs: '<S260>/Abs5'
     *  Abs: '<S260>/Abs6'
     *  Abs: '<S260>/Abs7'
     *  Constant: '<S260>/Constant'
     *  Constant: '<S260>/Constant1'
     *  Constant: '<S260>/Constant4'
     *  Constant: '<S260>/Constant5'
     *  Constant: '<S262>/Constant'
     *  Constant: '<S263>/Constant'
     *  Logic: '<S260>/Logical Operator'
     *  Logic: '<S260>/Logical Operator1'
     *  Logic: '<S260>/Logical Operator4'
     *  RelationalOperator: '<S260>/Relational Operator'
     *  RelationalOperator: '<S260>/Relational Operator1'
     *  RelationalOperator: '<S260>/Relational Operator2'
     *  RelationalOperator: '<S260>/Relational Operator3'
     *  RelationalOperator: '<S260>/Relational Operator6'
     *  RelationalOperator: '<S260>/Relational Operator7'
     *  RelationalOperator: '<S262>/Compare'
     *  RelationalOperator: '<S263>/Compare'
     *  Switch: '<S52>/Switch'
     *  Switch: '<S52>/Switch1'
     */
    if ((fabsf(rtb_Saturation) <= 0.005F) && (fabsf(rtb_L0_C0) <= 0.005F) &&
        ((fabsf(rtb_L0_C2_p) <= 0.0001F) && (fabsf(rtb_L0_C2) <= 0.0001F)) &&
        ((rtb_L0_Q == ((uint8)3U)) && (rtb_R0_Q == ((uint8)3U))) &&
        (rtb_IMAPve_g_ESC_VehSpd >= 50.0F) && (x1 <= 1.0F)) {
      if (!LKAS_DW.Subsystem_MODE) {
        /* InitializeConditions for Sum: '<S264>/Add1' incorporates:
         *  Memory: '<S264>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_mo = ((uint16)0U);
        LKAS_DW.Subsystem_MODE = true;
      }

      /* Sum: '<S264>/Add1' incorporates:
       *  Memory: '<S264>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_mo++;

      /* Saturate: '<S264>/Saturation' */
      if (LKAS_DW.Memory_PreviousInput_mo >= ((uint16)3000U)) {
        /* Sum: '<S264>/Add1' */
        LKAS_DW.Memory_PreviousInput_mo = ((uint16)3000U);
      }

      /* End of Saturate: '<S264>/Saturation' */

      /* DataTypeConversion: '<S264>/Cast To Single1' incorporates:
       *  Constant: '<S260>/Constant3'
       *  Product: '<S260>/Divide'
       */
      x10 = fmodf(floorf(2.0F / rtb_LKA_SampleTime), 65536.0F);

      /* RelationalOperator: '<S264>/Relational Operator' incorporates:
       *  DataTypeConversion: '<S264>/Cast To Single1'
       */
      LKAS_B.RelationalOperator_hy = (LKAS_DW.Memory_PreviousInput_mo >= (x10 <
        0.0F ? (sint32)(uint16)-(sint16)(uint16)-x10 : (sint32)(uint16)x10));
    } else {
      if (LKAS_DW.Subsystem_MODE) {
        /* Disable for Outport: '<S264>/Out' */
        LKAS_B.RelationalOperator_hy = false;
        LKAS_DW.Subsystem_MODE = false;
      }
    }

    /* End of Logic: '<S260>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S260>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S212>/Subsystem' incorporates:
     *  EnablePort: '<S259>/Enable'
     */
    if (LKAS_B.RelationalOperator_hy) {
      /* Sum: '<S261>/Add2' incorporates:
       *  Constant: '<S261>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S261>/Memory3'
       */
      LKAS_DW.Memory3_PreviousInput += 1.0F;

      /* Saturate: '<S261>/Saturation' */
      if (LKAS_DW.Memory3_PreviousInput > 50.0F) {
        /* Sum: '<S261>/Add2' */
        LKAS_DW.Memory3_PreviousInput = 50.0F;
      } else {
        if (LKAS_DW.Memory3_PreviousInput < 0.0F) {
          /* Sum: '<S261>/Add2' */
          LKAS_DW.Memory3_PreviousInput = 0.0F;
        }
      }

      /* End of Saturate: '<S261>/Saturation' */

      /* Switch: '<S261>/Switch' incorporates:
       *  Constant: '<S259>/Constant'
       *  Product: '<S261>/Divide'
       *  Product: '<S261>/Divide1'
       *  Sum: '<S261>/Add'
       *  Sum: '<S261>/Add1'
       *  UnitDelay: '<S261>/Unit Delay'
       */
      if (LKAS_DW.Memory3_PreviousInput > 1.0F) {
        LKAS_DW.UnitDelay_DSTATE += rtb_LKA_SampleTime / 10.0F *
          (rtb_IMAPve_g_SW_Angle - LKAS_DW.UnitDelay_DSTATE);
      } else {
        LKAS_DW.UnitDelay_DSTATE = rtb_IMAPve_g_SW_Angle;
      }

      /* End of Switch: '<S261>/Switch' */

      /* Saturate: '<S259>/Saturation' incorporates:
       *  UnitDelay: '<S261>/Unit Delay'
       */
      if (LKAS_DW.UnitDelay_DSTATE > 3.0F) {
        LKAS_B.Saturation = 3.0F;
      } else if (LKAS_DW.UnitDelay_DSTATE < (-3.0F)) {
        LKAS_B.Saturation = (-3.0F);
      } else {
        LKAS_B.Saturation = LKAS_DW.UnitDelay_DSTATE;
      }

      /* End of Saturate: '<S259>/Saturation' */
    }

    /* End of Outputs for SubSystem: '<S212>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S73>/states = reset'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_B.LKASM_stLKAActvFlg > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S102>/Memory' */
        LKAS_DW.Memory_PreviousInput_a = 0.0F;

        /* InitializeConditions for Memory: '<S137>/Memory' */
        LKAS_DW.Memory_PreviousInput_l = ((uint16)0U);

        /* InitializeConditions for Memory: '<S85>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_k = ((uint8)0U);

        /* InitializeConditions for Memory: '<S136>/Memory' */
        LKAS_DW.Memory_PreviousInput_lx = ((uint16)0U);

        /* InitializeConditions for Memory: '<S138>/Memory' */
        LKAS_DW.Memory_PreviousInput_k = ((uint16)0U);

        /* InitializeConditions for Memory: '<S157>/Memory' */
        LKAS_DW.Memory_PreviousInput_h3 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S135>/Memory' */
        LKAS_DW.Memory_PreviousInput_d2 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S134>/Memory' */
        LKAS_DW.Memory_PreviousInput_ko = ((uint16)0U);

        /* InitializeConditions for Memory: '<S133>/Memory' */
        LKAS_DW.Memory_PreviousInput_mm = ((uint16)0U);

        /* InitializeConditions for Memory: '<S112>/Memory' */
        LKAS_DW.Memory_PreviousInput_i = 0.0F;

        /* InitializeConditions for Memory: '<S103>/Memory' */
        LKAS_DW.Memory_PreviousInput_g = 0.0F;

        /* InitializeConditions for Memory: '<S104>/Memory' */
        LKAS_DW.Memory_PreviousInput_aw = 0.0F;

        /* InitializeConditions for Memory: '<S101>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_i = 0.0F;

        /* InitializeConditions for Memory: '<S185>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_c = 0.0F;

        /* InitializeConditions for Memory: '<S171>/Memory' */
        LKAS_DW.Memory_PreviousInput_av = 0.0F;

        /* InitializeConditions for UnitDelay: '<S169>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

        /* InitializeConditions for Memory: '<S176>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_h = 0.0F;

        /* InitializeConditions for Memory: '<S180>/Memory' */
        LKAS_DW.Memory_PreviousInput_e4 = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S184>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_h = 0.0F;

        /* InitializeConditions for Memory: '<S184>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_j = 0.0F;

        /* InitializeConditions for UnitDelay: '<S164>/Delay Input2'
         *
         * Block description for '<S164>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE = 0.0F;

        /* InitializeConditions for Memory: '<S164>/Memory' */
        LKAS_DW.Memory_PreviousInput_bh = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S92>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S92>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S104>/Moving Standard Deviation1' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S104>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S104>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2_e);

        /* End of SystemReset for SubSystem: '<S104>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Sum: '<S102>/Add2' incorporates:
       *  Memory: '<S102>/Memory'
       */
      rtb_L0_C2 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_a;

      /* Saturate: '<S102>/Saturation' */
      if (rtb_TTLC_f > 0.004F) {
        rtb_TLft = 0.004F;
      } else if (rtb_TTLC_f < 0.0F) {
        rtb_TLft = 0.0F;
      } else {
        rtb_TLft = rtb_TTLC_f;
      }

      /* End of Saturate: '<S102>/Saturation' */

      /* RelationalOperator: '<S102>/Relational Operator4' incorporates:
       *  Constant: '<S102>/Constant'
       *  Constant: '<S102>/Constant1'
       *  Product: '<S102>/Divide'
       *  Sum: '<S102>/Add'
       */
      rtb_LogicalOperator2_p = (rtb_L0_C2 >= rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F
        * rtb_TLft / 0.004F + rtb_LL_LKAExPrcs_tiExitTime1);

      /* Sum: '<S137>/Add' incorporates:
       *  Constant: '<S137>/Constant'
       *  Memory: '<S137>/Memory'
       */
      rtb_Add1_hb = (uint16)((uint32)((uint16)1U) +
        LKAS_DW.Memory_PreviousInput_l);

      /* Saturate: '<S137>/Saturation1' */
      if (rtb_Add1_hb < ((uint16)10000U)) {
        rtb_Saturation1_l = rtb_Add1_hb;
      } else {
        rtb_Saturation1_l = ((uint16)10000U);
      }

      /* End of Saturate: '<S137>/Saturation1' */

      /* If: '<S137>/If' incorporates:
       *  Constant: '<S137>/Constant2'
       */
      if (rtb_Saturation1_l == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S137>/if action ' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_SW_Angle, &LKAS_B.In_d);

        /* End of Outputs for SubSystem: '<S137>/if action ' */
      }

      /* End of If: '<S137>/If' */

      /* Sum: '<S85>/Add' incorporates:
       *  Constant: '<S85>/Constant'
       *  Memory: '<S85>/Memory1'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((uint32)((uint8)1U) +
        LKAS_DW.Memory1_PreviousInput_k);

      /* Saturate: '<S85>/Saturation1' */
      if (rtb_IMAPve_d_BCM_HazardLamp < ((uint8)5U)) {
        rtb_Saturation1_ks = rtb_IMAPve_d_BCM_HazardLamp;
      } else {
        rtb_Saturation1_ks = ((uint8)5U);
      }

      /* End of Saturate: '<S85>/Saturation1' */

      /* Saturate: '<S111>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S111>/Saturation3' */

      /* Product: '<S111>/Divide1' incorporates:
       *  Constant: '<S111>/Constant'
       */
      rtb_TLft = 0.09F / x10;

      /* Saturate: '<S111>/Saturation1' */
      if (rtb_TLft > 0.0117F) {
        LKAS_B.StbFacm_SY = 0.0117F;
      } else if (rtb_TLft < 0.00237F) {
        LKAS_B.StbFacm_SY = 0.00237F;
      } else {
        LKAS_B.StbFacm_SY = rtb_TLft;
      }

      /* End of Saturate: '<S111>/Saturation1' */

      /* Sum: '<S136>/Add' incorporates:
       *  Constant: '<S136>/Constant'
       *  Memory: '<S136>/Memory'
       */
      rtb_Add1_hb = (uint16)((uint32)((uint16)1U) +
        LKAS_DW.Memory_PreviousInput_lx);

      /* Saturate: '<S136>/Saturation1' */
      if (rtb_Add1_hb < ((uint16)10000U)) {
        rtb_Saturation1_la = rtb_Add1_hb;
      } else {
        rtb_Saturation1_la = ((uint16)10000U);
      }

      /* End of Saturate: '<S136>/Saturation1' */

      /* If: '<S131>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if (LKAS_B.LKASM_stLKAActvFlg == 1) {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S141>/Action Port'
         */
        LKAS_ifaction3(rtb_LFTTTLC, &rtb_Merge_a);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem2' */
      } else if (LKAS_B.LKASM_stLKAActvFlg == 2) {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S140>/Action Port'
         */
        LKAS_ifaction3(rtb_RGTTTLC, &rtb_Merge_a);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S142>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_a);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem3' */
      }

      /* End of If: '<S131>/If' */

      /* If: '<S136>/If' incorporates:
       *  Constant: '<S136>/Constant2'
       */
      if (rtb_Saturation1_la == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S136>/if action ' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_a, &LKAS_B.In_nn);

        /* End of Outputs for SubSystem: '<S136>/if action ' */
      }

      /* End of If: '<S136>/If' */

      /* Saturate: '<S111>/Saturation2' */
      if (LKAS_B.In_nn > 2.0F) {
        LKAS_B.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_B.In_nn < 0.6F) {
        LKAS_B.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_B.MPInP_tiTTLCIni = LKAS_B.In_nn;
      }

      /* End of Saturate: '<S111>/Saturation2' */

      /* Sum: '<S138>/Add' incorporates:
       *  Constant: '<S138>/Constant'
       *  Memory: '<S138>/Memory'
       */
      rtb_Add1_hb = (uint16)((uint32)((uint16)1U) +
        LKAS_DW.Memory_PreviousInput_k);

      /* Saturate: '<S138>/Saturation1' */
      if (rtb_Add1_hb < ((uint16)10000U)) {
        rtb_Saturation1_b = rtb_Add1_hb;
      } else {
        rtb_Saturation1_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S138>/Saturation1' */

      /* If: '<S138>/If' incorporates:
       *  Constant: '<S138>/Constant2'
       */
      if (rtb_Saturation1_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S138>/if action ' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_ESC_VehSpd, &LKAS_B.In_f);

        /* End of Outputs for SubSystem: '<S138>/if action ' */
      }

      /* End of If: '<S138>/If' */

      /* Sum: '<S157>/Add' incorporates:
       *  Constant: '<S157>/Constant'
       *  Memory: '<S157>/Memory'
       */
      rtb_Add_p2 = (uint16)((uint32)((uint16)1U) +
                            LKAS_DW.Memory_PreviousInput_h3);

      /* DataTypeConversion: '<S158>/Data Type Conversion' incorporates:
       *  Constant: '<S159>/Constant'
       *  RelationalOperator: '<S159>/Compare'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(rtb_Merge_k <= 0.0F);

      /* Switch: '<S566>/Switch5' incorporates:
       *  Constant: '<S566>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S566>/Switch5' */

      /* Product: '<S158>/Divide' */
      rtb_Add2_p = rtb_Merge_k * rtb_LL_ThresDet_lDvtThresUprL_h * x10;

      /* Abs: '<S158>/Abs1' incorporates:
       *  Abs: '<S158>/Abs'
       */
      rtb_L0_C2_p = fabsf(rtb_Add2_p);
      rtb_Abs1_l = rtb_L0_C2_p;

      /* Abs: '<S158>/Abs' */
      rtb_Abs_i = rtb_L0_C2_p;

      /* If: '<S158>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if ((LKAS_B.LKASM_stLKAActvFlg == 1) && (rtb_IMAPve_d_BCM_HazardLamp == 0))
      {
        /* Outputs for IfAction SubSystem: '<S158>/If Action Subsystem' incorporates:
         *  ActionPort: '<S160>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_i, &rtb_Add2_p);

        /* End of Outputs for SubSystem: '<S158>/If Action Subsystem' */
      } else if ((LKAS_B.LKASM_stLKAActvFlg == 2) &&
                 (rtb_IMAPve_d_BCM_HazardLamp == 1)) {
        /* Outputs for IfAction SubSystem: '<S158>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S162>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_l, &rtb_Add2_p);

        /* End of Outputs for SubSystem: '<S158>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S158>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S161>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Add2_p);

        /* End of Outputs for SubSystem: '<S158>/If Action Subsystem2' */
      }

      /* End of If: '<S158>/If' */

      /* Switch: '<S566>/Switch6' incorporates:
       *  Constant: '<S566>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_l != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_l;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S566>/Switch6' */

      /* Switch: '<S564>/Switch11' incorporates:
       *  Constant: '<S564>/LKA_CarWidth=1.8'
       */
      if (LKAS_ConstB.DataTypeConversion22_h != 0.0F) {
        x20 = LKAS_ConstB.DataTypeConversion22_h;
      } else {
        x20 = LKA_CarWidth;
      }

      /* End of Switch: '<S564>/Switch11' */

      /* Sum: '<S153>/Add1' incorporates:
       *  Product: '<S153>/Divide'
       *  Product: '<S153>/Divide1'
       *  Sum: '<S153>/Add'
       */
      rtb_Add1_kk = 1.0F / x10 * (rtb_Divide_a3 - x20) /
        rtb_LL_ThresDet_lDvtThresUprL_h + rtb_Add2_p;

      /* If: '<S114>/If' incorporates:
       *  Constant: '<S156>/Constant2'
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if (LKAS_B.LKASM_stLKAActvFlg == 1) {
        /* Outputs for IfAction SubSystem: '<S114>/If Action Subsystem' incorporates:
         *  ActionPort: '<S154>/Action Port'
         */
        /* Gain: '<S154>/Gain2' */
        rtb_Merge_mb = (-1.0F) * rtb_Add1_kk;

        /* End of Outputs for SubSystem: '<S114>/If Action Subsystem' */
      } else if (LKAS_B.LKASM_stLKAActvFlg == 2) {
        /* Outputs for IfAction SubSystem: '<S114>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S155>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_kk, &rtb_Merge_mb);

        /* End of Outputs for SubSystem: '<S114>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S114>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S156>/Action Port'
         */
        rtb_Merge_mb = 0.0F;

        /* End of Outputs for SubSystem: '<S114>/If Action Subsystem2' */
      }

      /* End of If: '<S114>/If' */

      /* Saturate: '<S157>/Saturation1' */
      if (rtb_Add_p2 < ((uint16)10000U)) {
        rtb_Add1_hb = rtb_Add_p2;
      } else {
        rtb_Add1_hb = ((uint16)10000U);
      }

      /* End of Saturate: '<S157>/Saturation1' */

      /* If: '<S157>/If' incorporates:
       *  Constant: '<S157>/Constant2'
       */
      if (rtb_Add1_hb == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S157>/if action ' incorporates:
         *  ActionPort: '<S163>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_mb, &LKAS_B.In_a);

        /* End of Outputs for SubSystem: '<S157>/if action ' */
      }

      /* End of If: '<S157>/If' */

      /* Sum: '<S135>/Add' incorporates:
       *  Constant: '<S135>/Constant'
       *  Memory: '<S135>/Memory'
       */
      rtb_Add1_hb = (uint16)((uint32)((uint16)1U) +
        LKAS_DW.Memory_PreviousInput_d2);

      /* Saturate: '<S135>/Saturation1' */
      if (rtb_Add1_hb < ((uint16)10000U)) {
        rtb_Saturation1_f = rtb_Add1_hb;
      } else {
        rtb_Saturation1_f = ((uint16)10000U);
      }

      /* End of Saturate: '<S135>/Saturation1' */

      /* If: '<S135>/If' incorporates:
       *  Constant: '<S135>/Constant2'
       */
      if (rtb_Saturation1_f == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S135>/if action ' incorporates:
         *  ActionPort: '<S145>/Action Port'
         */
        LKAS_ifaction(rtb_Gain_pe, &LKAS_B.In_ni);

        /* End of Outputs for SubSystem: '<S135>/if action ' */
      }

      /* End of If: '<S135>/If' */

      /* Sum: '<S134>/Add' incorporates:
       *  Constant: '<S134>/Constant'
       *  Memory: '<S134>/Memory'
       */
      rtb_Add1_hb = (uint16)((uint32)((uint16)1U) +
        LKAS_DW.Memory_PreviousInput_ko);

      /* Saturate: '<S134>/Saturation1' */
      if (rtb_Add1_hb < ((uint16)10000U)) {
        rtb_Saturation1_b2 = rtb_Add1_hb;
      } else {
        rtb_Saturation1_b2 = ((uint16)10000U);
      }

      /* End of Saturate: '<S134>/Saturation1' */

      /* If: '<S134>/If' incorporates:
       *  Constant: '<S134>/Constant2'
       */
      if (rtb_Saturation1_b2 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S134>/if action ' incorporates:
         *  ActionPort: '<S144>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_p, &LKAS_B.In_b);

        /* End of Outputs for SubSystem: '<S134>/if action ' */
      }

      /* End of If: '<S134>/If' */

      /* Sum: '<S133>/Add' incorporates:
       *  Constant: '<S133>/Constant'
       *  Memory: '<S133>/Memory'
       */
      rtb_Add1_hb = (uint16)((uint32)((uint16)1U) +
        LKAS_DW.Memory_PreviousInput_mm);

      /* Saturate: '<S133>/Saturation1' */
      if (rtb_Add1_hb < ((uint16)10000U)) {
        rtb_Saturation1_e = rtb_Add1_hb;
      } else {
        rtb_Saturation1_e = ((uint16)10000U);
      }

      /* End of Saturate: '<S133>/Saturation1' */

      /* If: '<S133>/If' incorporates:
       *  Constant: '<S133>/Constant2'
       */
      if (rtb_Saturation1_e == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S133>/if action ' incorporates:
         *  ActionPort: '<S143>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_kn, &LKAS_B.In_p);

        /* End of Outputs for SubSystem: '<S133>/if action ' */
      }

      /* End of If: '<S133>/If' */

      /* If: '<S139>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if (LKAS_B.LKASM_stLKAActvFlg == 1) {
        /* Outputs for IfAction SubSystem: '<S139>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S150>/Action Port'
         */
        /* SignalConversion: '<S150>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S150>/Constant'
         */
        LKAS_B.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S139>/If Action Subsystem2' */
      } else if (LKAS_B.LKASM_stLKAActvFlg == 2) {
        /* Outputs for IfAction SubSystem: '<S139>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S149>/Action Port'
         */
        /* SignalConversion: '<S149>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S149>/Constant'
         */
        LKAS_B.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S139>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S139>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S151>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_B.Merge);

        /* End of Outputs for SubSystem: '<S139>/If Action Subsystem3' */
      }

      /* End of If: '<S139>/If' */

      /* If: '<S85>/If' incorporates:
       *  Constant: '<S85>/Constant19'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem;
      LKAS_DW.If_ActiveSubsystem = -1;
      if (rtb_Saturation1_ks == ((uint8)1U)) {
        LKAS_DW.If_ActiveSubsystem = 0;
      }

      if (LKAS_DW.If_ActiveSubsystem == 0) {
        if (0 != rtPrevAction) {
          /* SystemReset for IfAction SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
           *  ActionPort: '<S110>/Action Port'
           *
           * Block description for '<S85>/LKA Motion Planning Calculation (LKAMPCal)':
           *  Block Name: LKA Motion Planning Calculation
           *  Ab.: LKAMPCal
           *  No.: 1.2.3.2
           *  Rev: 0.0.1
           *  Update Date: 19-3-26
           */
          /* SystemReset for If: '<S85>/If' */
          LKAMotionPlanningCalculat_Reset();

          /* End of SystemReset for SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */
        }

        /* Outputs for IfAction SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S110>/Action Port'
         *
         * Block description for '<S85>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S85>/If' */

      /* Memory: '<S112>/Memory' */
      rtb_Add2_p = LKAS_DW.Memory_PreviousInput_i;

      /* Sum: '<S112>/Add' incorporates:
       *  Gain: '<S112>/Gain1'
       *  Product: '<S112>/Divide'
       *  Product: '<S112>/Product'
       */
      rtb_Add_c3 = rtb_LL_ThresDet_lDvtThresUprL_h * rtb_LKA_SampleTime /
        (0.277777791F * LKAS_B.In_f) + rtb_Add2_p;

      /* MATLAB Function: '<S113>/SWACmd' */
      rtb_SWACmd_phiSWACmd = 0.0F;
      rtb_L0_C2_p = (LKAS_B.K1K2Det_phi2PhSWAIni - LKAS_B.In_d) /
        LKAS_B.K1K2Det_dphi1PhSWAGrad;
      x10 = (0.0F - LKAS_B.K1K2Det_phi2PhSWAIni) /
        LKAS_B.K1K2Det_dphi2PhSWAGrad1 + rtb_L0_C2_p;
      if ((rtb_Add_c3 < rtb_L0_C2_p) && (rtb_Add_c3 >= 0.0F)) {
        rtb_SWACmd_phiSWACmd = LKAS_B.K1K2Det_dphi1PhSWAGrad * rtb_Add_c3 +
          LKAS_B.In_d;
      } else if ((rtb_Add_c3 <= x10) && (rtb_Add_c3 >= rtb_L0_C2_p)) {
        rtb_SWACmd_phiSWACmd = LKAS_B.K1K2Det_dphi1PhSWAGrad * rtb_L0_C2_p +
          LKAS_B.In_d;
      } else {
        if (rtb_Add_c3 >= x10) {
          rtb_SWACmd_phiSWACmd = LKAS_B.K1K2Det_dphi1PhSWAGrad * rtb_L0_C2_p +
            LKAS_B.In_d;
        }
      }

      rtb_T2 = x10;

      /* Saturate: '<S85>/Saturation6' incorporates:
       *  MATLAB Function: '<S113>/SWACmd'
       */
      if (rtb_L0_C2_p > 2.0F) {
        rtb_Saturation6_h = 2.0F;
      } else if (rtb_L0_C2_p < 0.2F) {
        rtb_Saturation6_h = 0.2F;
      } else {
        rtb_Saturation6_h = rtb_L0_C2_p;
      }

      /* End of Saturate: '<S85>/Saturation6' */

      /* Memory: '<S103>/Memory' */
      rtb_Add2_p = LKAS_DW.Memory_PreviousInput_g;

      /* Sum: '<S103>/Add2' */
      rtb_Add2_p += rtb_LKA_SampleTime;

      /* Sum: '<S103>/Add' incorporates:
       *  Constant: '<S103>/Constant3'
       */
      rtb_L0_C2_p = 0.3F + rtb_R0_C1;

      /* Outputs for Enabled SubSystem: '<S103>/Sum Condition1' incorporates:
       *  EnablePort: '<S105>/Enable'
       */
      /* Logic: '<S103>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S103>/Relational Operator2'
       *  RelationalOperator: '<S103>/Relational Operator3'
       *  RelationalOperator: '<S103>/Relational Operator4'
       */
      if ((rtb_Add2_p >= rtb_Saturation6_h) && (rtb_L0_TLC_h >= rtb_L0_C2_p) &&
          (rtb_TTLC >= rtb_L0_C2_p)) {
        if (!LKAS_DW.SumCondition1_MODE_b) {
          /* InitializeConditions for Sum: '<S105>/Add1' incorporates:
           *  Memory: '<S105>/Memory'
           */
          LKAS_DW.Memory_PreviousInput_gg = 0.0F;
          LKAS_DW.SumCondition1_MODE_b = true;
        }

        /* Sum: '<S105>/Add1' incorporates:
         *  Memory: '<S105>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_gg += rtb_LKA_SampleTime;

        /* Saturate: '<S105>/Saturation' */
        if (LKAS_DW.Memory_PreviousInput_gg > 10.0F) {
          /* Sum: '<S105>/Add1' */
          LKAS_DW.Memory_PreviousInput_gg = 10.0F;
        } else {
          if (LKAS_DW.Memory_PreviousInput_gg < 0.0F) {
            /* Sum: '<S105>/Add1' */
            LKAS_DW.Memory_PreviousInput_gg = 0.0F;
          }
        }

        /* End of Saturate: '<S105>/Saturation' */

        /* Saturate: '<S103>/Saturation' */
        if (rtb_TTLC_f > 0.004F) {
          rtb_TLft = 0.004F;
        } else if (rtb_TTLC_f < 0.0F) {
          rtb_TLft = 0.0F;
        } else {
          rtb_TLft = rtb_TTLC_f;
        }

        /* End of Saturate: '<S103>/Saturation' */

        /* RelationalOperator: '<S105>/Relational Operator' incorporates:
         *  Constant: '<S103>/Constant'
         *  Constant: '<S103>/Constant1'
         *  Product: '<S103>/Divide'
         *  Sum: '<S103>/Add1'
         */
        LKAS_B.RelationalOperator_k = (LKAS_DW.Memory_PreviousInput_gg >=
          rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F * rtb_TLft / 0.004F +
          rtb_LL_LKAExPrcs_tiExitTime2);
      } else {
        if (LKAS_DW.SumCondition1_MODE_b) {
          /* Disable for Outport: '<S105>/Out' */
          LKAS_B.RelationalOperator_k = false;
          LKAS_DW.SumCondition1_MODE_b = false;
        }
      }

      /* End of Logic: '<S103>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S103>/Sum Condition1' */

      /* Sum: '<S104>/Add2' incorporates:
       *  Memory: '<S104>/Memory'
       */
      rtb_L0_C2_p = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_aw;

      /* Sum: '<S104>/Add4' */
      rtb_TLft = rtb_L0_TLC_h + rtb_TTLC;

      /* Saturate: '<S104>/Saturation1' */
      if (rtb_TLft > 5.5F) {
        rtb_TLft = 5.5F;
      } else {
        if (rtb_TLft < 2.4F) {
          rtb_TLft = 2.4F;
        }
      }

      /* End of Saturate: '<S104>/Saturation1' */

      /* Sum: '<S104>/Add' incorporates:
       *  Constant: '<S104>/Constant4'
       *  Gain: '<S104>/Gain'
       *  Sum: '<S104>/Add5'
       */
      rtb_LL_LKAExPrcs_tiExitTime2 = (0.25F * rtb_TLft - 0.3F) + rtb_R0_C1;

      /* Outputs for Enabled SubSystem: '<S83>/Subsystem' incorporates:
       *  EnablePort: '<S91>/Enable'
       */
      /* RelationalOperator: '<S90>/Compare' incorporates:
       *  Constant: '<S90>/Constant'
       */
      if (rtb_LL_LKASWASyn_TrqSwaAddSwt > 0.0F) {
        if (!LKAS_DW.Subsystem_MODE_l) {
          LKAS_DW.Subsystem_MODE_l = true;
        }

        /* MATLAB Function: '<S91>/DriverSwaTrqAdd' incorporates:
         *  Switch: '<S566>/Switch42'
         */
        x10 = fmaxf(fminf(rtb_L0_TLC_h + rtb_TTLC, 5.4F), 2.5F);
        if ((x10 > 2.5F) && (x10 < 5.4F)) {
          rtb_LL_LKAExPrcs_tiExitTime1 = rtb_L0_TLC_h / x10;
          rtb_LL_ThresDet_lDvtThresUprLDW = rtb_TTLC / x10;
        } else {
          rtb_LL_LKAExPrcs_tiExitTime1 = 0.5F;
          rtb_LL_ThresDet_lDvtThresUprLDW = 0.5F;
        }

        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S566>/Switch42' incorporates:
           *  Constant: '<S566>/LL_LKASWASyn_TrqMax=1.5'
           */
          if (LKAS_ConstB.DataTypeConversion31_j != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31_j;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S566>/Switch43' incorporates:
           *  Constant: '<S566>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32_c != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32_c;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKAExPrcs_tiExitTime1 = (180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F * x20 * 2.0F *
            rtb_LL_LKAExPrcs_tiExitTime1 * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          if (LKAS_ConstB.DataTypeConversion31_j != 0.0F) {
            /* Switch: '<S566>/Switch42' */
            x10 = LKAS_ConstB.DataTypeConversion31_j;
          } else {
            /* Switch: '<S566>/Switch42' incorporates:
             *  Constant: '<S566>/LL_LKASWASyn_TrqMax=1.5'
             */
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S566>/Switch43' incorporates:
           *  Constant: '<S566>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32_c != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32_c;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKAExPrcs_tiExitTime1 = (180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F * x20 * 2.0F *
            rtb_LL_ThresDet_lDvtThresUprLDW * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S94>/Add2' incorporates:
         *  Constant: '<S94>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S94>/Memory3'
         */
        LKAS_DW.Memory3_PreviousInput_d += 1.0F;

        /* Saturate: '<S94>/Saturation' */
        if (LKAS_DW.Memory3_PreviousInput_d > 50.0F) {
          /* Sum: '<S94>/Add2' */
          LKAS_DW.Memory3_PreviousInput_d = 50.0F;
        } else {
          if (LKAS_DW.Memory3_PreviousInput_d < 0.0F) {
            /* Sum: '<S94>/Add2' */
            LKAS_DW.Memory3_PreviousInput_d = 0.0F;
          }
        }

        /* End of Saturate: '<S94>/Saturation' */

        /* Switch: '<S94>/Switch' incorporates:
         *  Product: '<S94>/Divide'
         *  Product: '<S94>/Divide1'
         *  Sum: '<S94>/Add'
         *  Sum: '<S94>/Add1'
         *  UnitDelay: '<S94>/Unit Delay'
         */
        if (LKAS_DW.Memory3_PreviousInput_d > 1.0F) {
          /* Switch: '<S566>/Switch50' incorporates:
           *  Constant: '<S566>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50_f != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50_f;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S566>/Switch50' */
          LKAS_DW.UnitDelay_DSTATE_b += rtb_LKA_SampleTime / x10 *
            (rtb_LL_LKAExPrcs_tiExitTime1 - LKAS_DW.UnitDelay_DSTATE_b);
        } else {
          LKAS_DW.UnitDelay_DSTATE_b = rtb_LL_LKAExPrcs_tiExitTime1;
        }

        /* End of Switch: '<S94>/Switch' */

        /* SampleTimeMath: '<S97>/TSamp' incorporates:
         *  UnitDelay: '<S94>/Unit Delay'
         *
         * About '<S97>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_DW.UnitDelay_DSTATE_b * 100.0F;

        /* Sum: '<S95>/Add2' incorporates:
         *  Constant: '<S95>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S95>/Memory3'
         */
        LKAS_DW.Memory3_PreviousInput_hw += 1.0F;

        /* Saturate: '<S95>/Saturation' */
        if (LKAS_DW.Memory3_PreviousInput_hw > 50.0F) {
          /* Sum: '<S95>/Add2' */
          LKAS_DW.Memory3_PreviousInput_hw = 50.0F;
        } else {
          if (LKAS_DW.Memory3_PreviousInput_hw < 0.0F) {
            /* Sum: '<S95>/Add2' */
            LKAS_DW.Memory3_PreviousInput_hw = 0.0F;
          }
        }

        /* End of Saturate: '<S95>/Saturation' */

        /* Switch: '<S95>/Switch' incorporates:
         *  Product: '<S95>/Divide'
         *  Product: '<S95>/Divide1'
         *  Sum: '<S95>/Add'
         *  Sum: '<S95>/Add1'
         *  Sum: '<S97>/Diff'
         *  UnitDelay: '<S95>/Unit Delay'
         *  UnitDelay: '<S97>/UD'
         *
         * Block description for '<S97>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S97>/UD':
         *
         *  Store in Global RAM
         */
        if (LKAS_DW.Memory3_PreviousInput_hw > 2.0F) {
          /* Switch: '<S566>/Switch52' incorporates:
           *  Constant: '<S566>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52_c != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52_c;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S566>/Switch52' */
          LKAS_DW.UnitDelay_DSTATE_m += ((rtb_LL_LKAExPrcs_tiExitTime1 -
            LKAS_DW.UD_DSTATE_o) - LKAS_DW.UnitDelay_DSTATE_m) *
            (rtb_LKA_SampleTime / x10);
        } else {
          LKAS_DW.UnitDelay_DSTATE_m = rtb_LL_LKAExPrcs_tiExitTime1 -
            LKAS_DW.UD_DSTATE_o;
        }

        /* End of Switch: '<S95>/Switch' */

        /* Saturate: '<S91>/Saturation' incorporates:
         *  UnitDelay: '<S95>/Unit Delay'
         */
        if (LKAS_DW.UnitDelay_DSTATE_m > 30.0F) {
          x10 = 30.0F;
        } else if (LKAS_DW.UnitDelay_DSTATE_m < (-30.0F)) {
          x10 = (-30.0F);
        } else {
          x10 = LKAS_DW.UnitDelay_DSTATE_m;
        }

        /* End of Saturate: '<S91>/Saturation' */

        /* Switch: '<S566>/Switch53' incorporates:
         *  Constant: '<S566>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53_c != 0.0F) {
          x20 = LKAS_ConstB.DataTypeConversion53_c;
        } else {
          x20 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S566>/Switch53' */

        /* Sum: '<S96>/Difference Inputs1' incorporates:
         *  Product: '<S91>/Divide1'
         *  Product: '<S91>/Divide3'
         *  Sum: '<S91>/Add'
         *  UnitDelay: '<S94>/Unit Delay'
         *  UnitDelay: '<S96>/Delay Input2'
         *
         * Block description for '<S96>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S96>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_LKASWASyn_TrqSwaAddSwt = (rtb_LL_LKASWASyn_TrqSwaAddSwt * x10 *
          x20 + rtb_LL_LKASWASyn_TrqSwaAddSwt * LKAS_DW.UnitDelay_DSTATE_b) -
          LKAS_DW.DelayInput2_DSTATE_j;

        /* Product: '<S96>/delta rise limit' incorporates:
         *  Constant: '<S91>/Constant1'
         *  SampleTimeMath: '<S96>/sample time'
         *
         * About '<S96>/sample time':
         *  y = K where K = ( w * Ts )
         */
        x10 = 5.0F * 0.01F;

        /* Product: '<S96>/delta fall limit' incorporates:
         *  Constant: '<S91>/Constant2'
         *  SampleTimeMath: '<S96>/sample time'
         *
         * About '<S96>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_ThresDet_lDvtThresUprLDW = (-5.0F) * 0.01F;

        /* Switch: '<S98>/Switch2' incorporates:
         *  RelationalOperator: '<S98>/LowerRelop1'
         *  RelationalOperator: '<S98>/UpperRelop'
         *  Switch: '<S98>/Switch'
         */
        if (rtb_LL_LKASWASyn_TrqSwaAddSwt > x10) {
          rtb_LL_LKASWASyn_TrqSwaAddSwt = x10;
        } else {
          if (rtb_LL_LKASWASyn_TrqSwaAddSwt < rtb_LL_ThresDet_lDvtThresUprLDW) {
            /* Switch: '<S98>/Switch' */
            rtb_LL_LKASWASyn_TrqSwaAddSwt = rtb_LL_ThresDet_lDvtThresUprLDW;
          }
        }

        /* End of Switch: '<S98>/Switch2' */

        /* Sum: '<S96>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S96>/Delay Input2'
         *
         * Block description for '<S96>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S96>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_B.DifferenceInputs2_m = rtb_LL_LKASWASyn_TrqSwaAddSwt +
          LKAS_DW.DelayInput2_DSTATE_j;

        /* Update for UnitDelay: '<S97>/UD'
         *
         * Block description for '<S97>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE_o = rtb_LL_LKAExPrcs_tiExitTime1;

        /* Update for UnitDelay: '<S96>/Delay Input2'
         *
         * Block description for '<S96>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_j = LKAS_B.DifferenceInputs2_m;
      } else {
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S91>/Out1' */
          LKAS_B.DifferenceInputs2_m = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }
      }

      /* End of RelationalOperator: '<S90>/Compare' */
      /* End of Outputs for SubSystem: '<S83>/Subsystem' */

      /* Outputs for Atomic SubSystem: '<S92>/Moving Standard Deviation2' */
      rtb_Yk1_eq = LKAS_MovingStandardDeviation2(rtb_IMAPve_g_EPS_SW_Trq,
        &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S92>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S104>/Moving Standard Deviation1' */
      rtb_Gain2_a = LKAS_MovingStandardDeviation2(rtb_R0_C0_e,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S104>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S104>/Relational Operator6' */
      rtb_RelationalOperator6_f = (rtb_Gain2_a <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Switch: '<S566>/Switch45' incorporates:
       *  Constant: '<S566>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34_p != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34_p;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S566>/Switch45' */

      /* Saturate: '<S104>/Saturation' */
      if (rtb_TTLC_f > 0.004F) {
        rtb_TTLC_f = 0.004F;
      } else {
        if (rtb_TTLC_f < 0.0F) {
          rtb_TTLC_f = 0.0F;
        }
      }

      /* End of Saturate: '<S104>/Saturation' */

      /* Product: '<S104>/Divide2' incorporates:
       *  Constant: '<S104>/Constant'
       *  Constant: '<S104>/Constant7'
       *  Product: '<S104>/Divide1'
       *  Sum: '<S104>/Add6'
       */
      rtb_Divide2_p = (2.0F * rtb_TTLC_f / 0.004F + x10) / rtb_LKA_SampleTime;

      /* Outputs for Enabled SubSystem: '<S104>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_f, rtb_Divide2_p,
                        &LKAS_B.DataTypeConversion, &LKAS_DW.SumCondition1_f);

      /* End of Outputs for SubSystem: '<S104>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S104>/Moving Standard Deviation2' */
      rtb_Gain2_a = LKAS_MovingStandardDeviation2(rtb_L0_C0_a,
        &LKAS_DW.MovingStandardDeviation2_e);

      /* End of Outputs for SubSystem: '<S104>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S104>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain2_a <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S104>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_Divide2_p,
                        &LKAS_B.DataTypeConversion_i, &LKAS_DW.SumCondition_h);

      /* End of Outputs for SubSystem: '<S104>/Sum Condition' */

      /* Switch: '<S566>/Switch46' incorporates:
       *  Constant: '<S566>/LL_LKAExPrcs_ExitC0Swt=1'
       */
      if (LKAS_ConstB.DataTypeConversion35_o != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion35_o;
      } else {
        x10 = LL_LKAExPrcs_ExitC0Swt;
      }

      /* End of Switch: '<S566>/Switch46' */

      /* Logic: '<S104>/Logical Operator2' incorporates:
       *  Logic: '<S104>/Logical Operator1'
       *  RelationalOperator: '<S104>/Relational Operator2'
       *  RelationalOperator: '<S104>/Relational Operator3'
       *  RelationalOperator: '<S104>/Relational Operator4'
       */
      rtb_LogicalOperator3_c = ((rtb_L0_C2_p >= rtb_Saturation6_h) &&
        (rtb_L0_TLC_h >= rtb_LL_LKAExPrcs_tiExitTime2) && (rtb_TTLC >=
        rtb_LL_LKAExPrcs_tiExitTime2) && (LKAS_B.DataTypeConversion != 0) &&
        (LKAS_B.DataTypeConversion_i != 0) && (x10 != 0.0F));

      /* Fcn: '<S84>/Fcn' incorporates:
       *  DataTypeConversion: '<S84>/Cast To Single'
       */
      rtb_ExNum = (float32)((rtb_LogicalOperator3_c * rtb_LogicalOperator3_c *
        (sint32)3.0F + !rtb_LogicalOperator3_c * LKAS_B.RelationalOperator_k *
        (sint32)2.0F) + ((!LKAS_B.RelationalOperator_k) &&
                         (!rtb_LogicalOperator3_c)) * rtb_LogicalOperator2_p);

      /* Logic: '<S84>/Logical Operator3' */
      LKAS_B.LogicalOperator3 = (rtb_LogicalOperator2_p ||
        LKAS_B.RelationalOperator_k || rtb_LogicalOperator3_c);

      /* DataTypeConversion: '<S87>/CastLKA1' */
      LKAS_B.LKA_ExitFlg_Mon = LKAS_B.LogicalOperator3;

      /* Sum: '<S101>/Add2' incorporates:
       *  Memory: '<S101>/Memory3'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_i;

      /* Saturate: '<S101>/Saturation' */
      if (rtb_TLft > 50.0F) {
        rtb_Saturation_d3 = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation_d3 = 0.0F;
      } else {
        rtb_Saturation_d3 = rtb_TLft;
      }

      /* End of Saturate: '<S101>/Saturation' */

      /* MATLAB Function: '<S92>/MATLAB Function' incorporates:
       *  Constant: '<S566>/LL_LKASWASyn_M2=0.3'
       *  Switch: '<S566>/Switch14'
       */
      if (rtb_Saturation_d3 < rtb_Saturation6_h) {
        rtb_LL_LKASWASyn_M0 += (rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6_h * rtb_Saturation_d3;
      } else if ((rtb_Saturation_d3 >= rtb_Saturation6_h) && (rtb_Saturation_d3 <=
                  rtb_Saturation6_h + rtb_LL_LKASWASyn_T2)) {
        /* Switch: '<S566>/Switch14' incorporates:
         *  Constant: '<S566>/LL_LKASWASyn_M2=0.3'
         */
        if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (x10 - rtb_LL_LKASWASyn_M1) / rtb_LL_LKASWASyn_T2 *
          (rtb_Saturation_d3 - rtb_Saturation6_h) + rtb_LL_LKASWASyn_M1;
      } else if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
        /* Switch: '<S566>/Switch14' */
        rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20;
      } else {
        rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
      }

      /* End of MATLAB Function: '<S92>/MATLAB Function' */

      /* Switch: '<S566>/Switch18' incorporates:
       *  Constant: '<S566>/LL_LKASWASyn_M3K=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion25;
      } else {
        x10 = LL_LKASWASyn_M3K;
      }

      /* End of Switch: '<S566>/Switch18' */

      /* Product: '<S92>/Divide' */
      rtb_TLft = rtb_Yk1_eq * x10;

      /* Saturate: '<S92>/Saturation1' */
      if (rtb_TLft > 0.2F) {
        rtb_TLft = 0.2F;
      } else {
        if (rtb_TLft < 0.0F) {
          rtb_TLft = 0.0F;
        }
      }

      /* End of Saturate: '<S92>/Saturation1' */

      /* Sum: '<S92>/Add1' */
      LKAS_B.Saturation2 = rtb_LL_LKASWASyn_M0 - rtb_TLft;

      /* Saturate: '<S92>/Saturation2' */
      if (LKAS_B.Saturation2 > 1.0F) {
        /* Sum: '<S92>/Add1' */
        LKAS_B.Saturation2 = 1.0F;
      } else {
        if (LKAS_B.Saturation2 < 0.0F) {
          /* Sum: '<S92>/Add1' */
          LKAS_B.Saturation2 = 0.0F;
        }
      }

      /* End of Saturate: '<S92>/Saturation2' */

      /* Sum: '<S185>/Add2' incorporates:
       *  Memory: '<S185>/Memory3'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_c;

      /* Saturate: '<S185>/Saturation' */
      if (rtb_TLft > 50.0F) {
        rtb_Saturation_bw = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation_bw = 0.0F;
      } else {
        rtb_Saturation_bw = rtb_TLft;
      }

      /* End of Saturate: '<S185>/Saturation' */

      /* If: '<S183>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       *  Inport: '<S191>/Plan'
       *  Inport: '<S191>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_j;
      if (LKAS_B.LKASM_stLKAActvFlg == 1) {
        LKAS_DW.If_ActiveSubsystem_j = 0;
      } else if (LKAS_B.LKASM_stLKAActvFlg == 2) {
        LKAS_DW.If_ActiveSubsystem_j = 1;
      } else {
        LKAS_DW.If_ActiveSubsystem_j = 2;
      }

      switch (LKAS_DW.If_ActiveSubsystem_j) {
       case 0:
        if (LKAS_DW.If_ActiveSubsystem_j != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S183>/If Action Subsystem' incorporates:
           *  ActionPort: '<S189>/Action Port'
           */
          /* InitializeConditions for If: '<S183>/If' incorporates:
           *  Memory: '<S189>/Memory'
           *  UnitDelay: '<S193>/Delay Input1'
           *
           * Block description for '<S193>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_jd = false;
          LKAS_DW.Memory_PreviousInput_b = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S183>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S183>/If Action Subsystem' incorporates:
         *  ActionPort: '<S189>/Action Port'
         */
        /* RelationalOperator: '<S192>/Compare' incorporates:
         *  Constant: '<S192>/Constant'
         */
        rtb_LogicalOperator2_p = (rtb_Saturation >= 0.0F);

        /* Logic: '<S189>/Logical Operator' incorporates:
         *  RelationalOperator: '<S189>/Relational Operator'
         *  RelationalOperator: '<S193>/FixPt Relational Operator'
         *  UnitDelay: '<S193>/Delay Input1'
         *
         * Block description for '<S193>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_jd = (((sint32)rtb_LogicalOperator2_p <
          (sint32)LKAS_DW.DelayInput1_DSTATE_jd) && (rtb_Saturation6_h >=
          rtb_Saturation_bw));

        /* Memory: '<S189>/Memory' */
        rtb_Plan_n = LKAS_DW.Memory_PreviousInput_b;

        /* Sum: '<S189>/Add' incorporates:
         *  DataTypeConversion: '<S189>/Cast To Single'
         *  UnitDelay: '<S193>/Delay Input1'
         *
         * Block description for '<S193>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_o = (float32)LKAS_DW.DelayInput1_DSTATE_jd + rtb_Plan_n;

        /* Saturate: '<S189>/Saturation' */
        if (rtb_T1_o > 5.0F) {
          rtb_Saturation_dy = 5.0F;
        } else if (rtb_T1_o < 0.0F) {
          rtb_Saturation_dy = 0.0F;
        } else {
          rtb_Saturation_dy = rtb_T1_o;
        }

        /* End of Saturate: '<S189>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S189>/If Action Subsystem' */
        LKAS_IfActionSubsystem_g(rtb_Saturation_dy, rtb_Saturation_bw,
          rtb_SWACmd_phiSWACmd, &LKAS_B.In_o, &LKAS_B.In_n,
          &LKAS_DW.IfActionSubsystem_g);

        /* End of Outputs for SubSystem: '<S189>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S189>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_l(rtb_Saturation6_h, rtb_SWACmd_phiSWACmd,
          &rtb_T1_o, &rtb_Plan_n);

        /* End of Outputs for SubSystem: '<S189>/If Action Subsystem2' */

        /* Switch: '<S189>/Switch' incorporates:
         *  Switch: '<S189>/Switch1'
         */
        if (rtb_Saturation_dy > 0.0F) {
          LKAS_B.Merge_p = LKAS_B.In_o;
          LKAS_B.Merge1 = LKAS_B.In_n;
        } else {
          LKAS_B.Merge_p = rtb_T1_o;
          LKAS_B.Merge1 = rtb_Plan_n;
        }

        /* End of Switch: '<S189>/Switch' */

        /* Update for UnitDelay: '<S193>/Delay Input1'
         *
         * Block description for '<S193>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_jd = rtb_LogicalOperator2_p;

        /* Update for Memory: '<S189>/Memory' */
        LKAS_DW.Memory_PreviousInput_b = rtb_Saturation_dy;

        /* End of Outputs for SubSystem: '<S183>/If Action Subsystem' */
        break;

       case 1:
        if (LKAS_DW.If_ActiveSubsystem_j != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S183>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S190>/Action Port'
           */
          /* InitializeConditions for If: '<S183>/If' incorporates:
           *  Memory: '<S190>/Memory'
           *  UnitDelay: '<S201>/Delay Input1'
           *
           * Block description for '<S201>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_n = false;
          LKAS_DW.Memory_PreviousInput_m2 = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S183>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S183>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S190>/Action Port'
         */
        /* RelationalOperator: '<S200>/Compare' incorporates:
         *  Constant: '<S200>/Constant'
         */
        rtb_LogicalOperator2_p = (rtb_L0_C0 <= 0.0F);

        /* Logic: '<S190>/Logical Operator' incorporates:
         *  RelationalOperator: '<S190>/Relational Operator'
         *  RelationalOperator: '<S201>/FixPt Relational Operator'
         *  UnitDelay: '<S201>/Delay Input1'
         *
         * Block description for '<S201>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_n = (((sint32)rtb_LogicalOperator2_p <
          (sint32)LKAS_DW.DelayInput1_DSTATE_n) && (rtb_Saturation6_h >=
          rtb_Saturation_bw));

        /* Memory: '<S190>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_m2;

        /* Sum: '<S190>/Add' incorporates:
         *  DataTypeConversion: '<S190>/Cast To Single'
         *  UnitDelay: '<S201>/Delay Input1'
         *
         * Block description for '<S201>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_f = (float32)LKAS_DW.DelayInput1_DSTATE_n + rtb_Plan;

        /* Saturate: '<S190>/Saturation' */
        if (rtb_T1_f > 5.0F) {
          rtb_Saturation_o = 5.0F;
        } else if (rtb_T1_f < 0.0F) {
          rtb_Saturation_o = 0.0F;
        } else {
          rtb_Saturation_o = rtb_T1_f;
        }

        /* End of Saturate: '<S190>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S190>/If Action Subsystem' */
        LKAS_IfActionSubsystem_g(rtb_Saturation_o, rtb_Saturation_bw,
          rtb_SWACmd_phiSWACmd, &LKAS_B.In_i, &LKAS_B.In,
          &LKAS_DW.IfActionSubsystem_ap);

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S190>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_l(rtb_Saturation6_h, rtb_SWACmd_phiSWACmd,
          &rtb_T1_f, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem2' */

        /* Switch: '<S190>/Switch' incorporates:
         *  Switch: '<S190>/Switch1'
         */
        if (rtb_Saturation_o > 0.0F) {
          LKAS_B.Merge_p = LKAS_B.In_i;
          LKAS_B.Merge1 = LKAS_B.In;
        } else {
          LKAS_B.Merge_p = rtb_T1_f;
          LKAS_B.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S190>/Switch' */

        /* Update for UnitDelay: '<S201>/Delay Input1'
         *
         * Block description for '<S201>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_n = rtb_LogicalOperator2_p;

        /* Update for Memory: '<S190>/Memory' */
        LKAS_DW.Memory_PreviousInput_m2 = rtb_Saturation_o;

        /* End of Outputs for SubSystem: '<S183>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S183>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S191>/Action Port'
         */
        LKAS_B.Merge_p = rtb_Saturation6_h;
        LKAS_B.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S183>/If Action Subsystem2' */
        break;
      }

      /* End of If: '<S183>/If' */

      /* Saturate: '<S89>/Saturation6' */
      if (LKAS_B.Merge_p > 0.5F) {
        rtb_LL_LKAExPrcs_tiExitTime2 = 0.5F;
      } else if (LKAS_B.Merge_p < 0.2F) {
        rtb_LL_LKAExPrcs_tiExitTime2 = 0.2F;
      } else {
        rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_B.Merge_p;
      }

      /* End of Saturate: '<S89>/Saturation6' */

      /* Product: '<S89>/Divide' incorporates:
       *  Product: '<S186>/Divide'
       *  Product: '<S89>/Divide4'
       *  Sum: '<S89>/Add2'
       */
      rtb_LL_LKAExPrcs_tiExitTime2 = (rtb_Saturation_bw - LKAS_B.Merge_p) /
        rtb_LL_LKAExPrcs_tiExitTime2;

      /* Saturate: '<S89>/Saturation2' incorporates:
       *  Product: '<S89>/Divide'
       */
      if (rtb_LL_LKAExPrcs_tiExitTime2 > 1.0F) {
        rtb_LL_LKASWASyn_M0 = 1.0F;
      } else if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
        rtb_LL_LKASWASyn_M0 = 0.0F;
      } else {
        rtb_LL_LKASWASyn_M0 = rtb_LL_LKAExPrcs_tiExitTime2;
      }

      /* End of Saturate: '<S89>/Saturation2' */

      /* Sum: '<S171>/Add1' incorporates:
       *  Gain: '<S167>/Gain'
       *  Memory: '<S171>/Memory'
       *  Product: '<S171>/Divide'
       *  Product: '<S171>/Divide1'
       *  Sum: '<S167>/Add'
       */
      rtb_Add1_f = (rtb_LL_TkOvStChk_tiTDelTime +
                    rtb_LL_ThresDet_lDvtThresLwrLDW) * 0.5F *
        LKAS_ConstB.Divide2_f + LKAS_ConstB.Add2_o *
        LKAS_DW.Memory_PreviousInput_av;

      /* MATLAB Function: '<S169>/Saturable Gain Lut (SatGainLut)' incorporates:
       *  Switch: '<S566>/Switch35'
       */
      if (rtb_IMAPve_g_ESC_VehSpd > rtb_R0_C3) {
        if (rtb_IMAPve_g_ESC_VehSpd >= rtb_LL_LFClb_TFC_vGainLutVehS_j) {
          /* Switch: '<S566>/Switch35' incorporates:
           *  Constant: '<S566>/LL_LFClb_TFC_facmGainLutGain2_C=40'
           */
          if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
            rtb_LL_LFClb_TFC_facmGainLutGai = LKAS_ConstB.DataTypeConversion17;
          } else {
            rtb_LL_LFClb_TFC_facmGainLutGai = LL_LFClb_TFC_facmGainLutGain2_C;
          }
        } else {
          if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
            /* Switch: '<S566>/Switch35' */
            x10 = LKAS_ConstB.DataTypeConversion17;
          } else {
            /* Switch: '<S566>/Switch35' incorporates:
             *  Constant: '<S566>/LL_LFClb_TFC_facmGainLutGain2_C=40'
             */
            x10 = LL_LFClb_TFC_facmGainLutGain2_C;
          }

          rtb_LL_LFClb_TFC_facmGainLutGai += (rtb_IMAPve_g_ESC_VehSpd -
            rtb_R0_C3) / (rtb_LL_LFClb_TFC_vGainLutVehS_j - rtb_R0_C3) * (x10 -
            rtb_LL_LFClb_TFC_facmGainLutGai);
        }
      }

      /* End of MATLAB Function: '<S169>/Saturable Gain Lut (SatGainLut)' */

      /* Switch: '<S566>/Switch32' incorporates:
       *  Constant: '<S566>/LL_LFClb_TFC_tiKlatPrvwT_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15;
      } else {
        x10 = LL_LFClb_TFC_tiKlatPrvwT_C;
      }

      /* End of Switch: '<S566>/Switch32' */

      /* Product: '<S169>/Divide1' */
      rtb_TLft = x10 * rtb_LL_ThresDet_lDvtThresUprL_h;

      /* Switch: '<S566>/Switch30' incorporates:
       *  Constant: '<S566>/LL_LFClb_TFC_facmKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11;
      } else {
        x10 = LL_LFClb_TFC_facmKlat_C;
      }

      /* End of Switch: '<S566>/Switch30' */

      /* Saturate: '<S169>/Saturation' */
      if (rtb_TLft > 40.0F) {
        rtb_TLft = 40.0F;
      } else {
        if (rtb_TLft < 5.0F) {
          rtb_TLft = 5.0F;
        }
      }

      /* End of Saturate: '<S169>/Saturation' */

      /* Product: '<S169>/Product4' incorporates:
       *  Gain: '<S167>/Gain2'
       *  Product: '<S169>/Divide'
       *  Product: '<S169>/Product1'
       *  Sum: '<S167>/Add1'
       *  Sum: '<S169>/Subtract1'
       */
      rtb_R0_C3 = ((rtb_LL_LDW_EarliestWarnLine_C + rtb_LL_LDW_LatestWarnLine_C)
                   * 0.5F / rtb_TLft * x10 - rtb_Add1_f) *
        rtb_LL_LFClb_TFC_facmGainLutGai;

      /* Saturate: '<S169>/Saturation2' */
      if (rtb_R0_C3 > 360.0F) {
        rtb_deltafalllimit_b = 360.0F;
      } else if (rtb_R0_C3 < (-360.0F)) {
        rtb_deltafalllimit_b = (-360.0F);
      } else {
        rtb_deltafalllimit_b = rtb_R0_C3;
      }

      /* End of Saturate: '<S169>/Saturation2' */

      /* Gain: '<S167>/Gain1' incorporates:
       *  Sum: '<S167>/Add2'
       */
      rtb_Yk1_eq = (rtb_Add_hn + rtb_Add_j) * 0.5F;

      /* Abs: '<S169>/Abs' */
      rtb_Gain2_a = fabsf(rtb_Yk1_eq);

      /* Saturate: '<S169>/Saturation1' */
      rtb_TLft = rtb_Gain2_a;
      if (rtb_TLft > 0.004F) {
        rtb_Gain2_a = 0.004F;
      } else if (rtb_TLft < 1.0E-5F) {
        rtb_Gain2_a = 1.0E-5F;
      } else {
        rtb_Gain2_a = rtb_TLft;
      }

      /* End of Saturate: '<S169>/Saturation1' */

      /* Switch: '<S566>/Switch39' incorporates:
       *  Constant: '<S566>/LL_LFClb_TFC_phiIntegCtlMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28_l != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28_l;
      } else {
        x10 = LL_LFClb_TFC_phiIntegCtlMaxSWA_C;
      }

      /* End of Switch: '<S566>/Switch39' */

      /* Sum: '<S169>/Add3' incorporates:
       *  Constant: '<S169>/Constant3'
       *  Constant: '<S169>/Constant4'
       *  Product: '<S169>/Divide4'
       *  Sum: '<S169>/Add5'
       */
      rtb_Gain2_a = (x10 - 1.0F) * rtb_Gain2_a / 0.004F + 1.0F;

      /* Sum: '<S176>/Add2' incorporates:
       *  Memory: '<S176>/Memory3'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_h;

      /* Saturate: '<S176>/Saturation' */
      if (rtb_TLft > 50.0F) {
        rtb_Saturation_n = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation_n = 0.0F;
      } else {
        rtb_Saturation_n = rtb_TLft;
      }

      /* End of Saturate: '<S176>/Saturation' */

      /* Switch: '<S169>/Switch2' incorporates:
       *  Product: '<S169>/Divide2'
       *  Sum: '<S169>/Add'
       *  Sum: '<S169>/Add2'
       *  Switch: '<S566>/Switch40'
       *  UnitDelay: '<S169>/Unit Delay'
       */
      if (rtb_Saturation_n - rtb_Saturation6_h >= 0.0F) {
        /* Switch: '<S566>/Switch40' incorporates:
         *  Constant: '<S566>/LL_LFClb_TFC_facmIntegRatio=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29_f != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29_f;
        } else {
          x10 = LL_LFClb_TFC_facmIntegRatio;
        }

        rtb_Switch2_d2 = rtb_R0_C3 * x10 + LKAS_DW.UnitDelay_DSTATE_g;
      } else {
        if (LKAS_ConstB.DataTypeConversion29_f != 0.0F) {
          /* Switch: '<S566>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29_f;
        } else {
          /* Switch: '<S566>/Switch40' incorporates:
           *  Constant: '<S566>/LL_LFClb_TFC_facmIntegRatio=0.01'
           */
          x10 = LL_LFClb_TFC_facmIntegRatio;
        }

        rtb_Switch2_d2 = rtb_R0_C3 * x10;
      }

      /* End of Switch: '<S169>/Switch2' */

      /* Gain: '<S169>/Gain' */
      rtb_R0_C3 = (-1.0F) * rtb_Gain2_a;

      /* Switch: '<S173>/Switch' incorporates:
       *  RelationalOperator: '<S173>/UpperRelop'
       */
      if (rtb_Switch2_d2 < rtb_R0_C3) {
        rtb_Switch_b = rtb_R0_C3;
      } else {
        rtb_Switch_b = rtb_Switch2_d2;
      }

      /* End of Switch: '<S173>/Switch' */

      /* Switch: '<S173>/Switch2' incorporates:
       *  RelationalOperator: '<S173>/LowerRelop1'
       *  UnitDelay: '<S169>/Unit Delay'
       */
      if (rtb_Switch2_d2 > rtb_Gain2_a) {
        LKAS_DW.UnitDelay_DSTATE_g = rtb_Gain2_a;
      } else {
        LKAS_DW.UnitDelay_DSTATE_g = rtb_Switch_b;
      }

      /* End of Switch: '<S173>/Switch2' */

      /* Product: '<S89>/Divide1' incorporates:
       *  Sum: '<S89>/Add3'
       *  UnitDelay: '<S169>/Unit Delay'
       */
      rtb_LL_LFClb_TFC_vGainLutVehS_j = (rtb_deltafalllimit_b +
        LKAS_DW.UnitDelay_DSTATE_g) * rtb_LL_LKASWASyn_M0;

      /* Switch: '<S566>/Switch49' incorporates:
       *  Constant: '<S566>/LL_LFClb_TFC_DiffCtrlMaxSWA=20'
       */
      if (LKAS_ConstB.DataTypeConversion49_c != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49_c;
      } else {
        x10 = LL_LFClb_TFC_DiffCtrlMaxSWA;
      }

      /* End of Switch: '<S566>/Switch49' */

      /* Product: '<S169>/Divide8' incorporates:
       *  Constant: '<S169>/Constant7'
       *  Constant: '<S169>/Constant8'
       *  Sum: '<S169>/Add4'
       */
      rtb_Gain2_a = (180.0F - rtb_LL_ThresDet_lDvtThresUprL_h) * x10 / 120.0F;

      /* Sum: '<S175>/Add2' */
      rtb_deltafalllimit_b = rtb_L0_C0_a + rtb_R0_C0_e;

      /* Saturate: '<S175>/Saturation' */
      if (rtb_deltafalllimit_b > 2.0F) {
        rtb_deltafalllimit_b = 2.0F;
      } else {
        if (rtb_deltafalllimit_b < (-2.0F)) {
          rtb_deltafalllimit_b = (-2.0F);
        }
      }

      /* End of Saturate: '<S175>/Saturation' */

      /* Switch: '<S566>/Switch9' incorporates:
       *  Constant: '<S566>/LL_LFClb_TFC_DiffCtlBalance=1.2'
       */
      if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion9;
      } else {
        x10 = LL_LFClb_TFC_DiffCtlBalance;
      }

      /* End of Switch: '<S566>/Switch9' */

      /* Sum: '<S175>/Add6' */
      rtb_R0_C3 = rtb_L0_TLC - x10;

      /* Product: '<S175>/Divide5' incorporates:
       *  Constant: '<S175>/Constant3'
       *  Product: '<S175>/Divide4'
       *  Sum: '<S175>/Add5'
       */
      rtb_Divide5 = (rtb_deltafalllimit_b / rtb_R0_C3 + 1.0F) *
        rtb_LL_LFClb_TFC_DiffCtrlRatio;

      /* Product: '<S175>/Divide2' incorporates:
       *  Constant: '<S175>/Constant2'
       *  Product: '<S175>/Divide1'
       *  Sum: '<S175>/Add1'
       *  UnaryMinus: '<S175>/Unary Minus'
       */
      rtb_Divide2_d = (-rtb_deltafalllimit_b / rtb_R0_C3 + 1.0F) *
        rtb_LL_LFClb_TFC_DiffCtrlRatio;

      /* Sum: '<S180>/Add' incorporates:
       *  Constant: '<S180>/Constant'
       *  Memory: '<S180>/Memory'
       */
      rtb_Add1_hb = (uint16)((uint32)((uint16)1U) +
        LKAS_DW.Memory_PreviousInput_e4);

      /* Saturate: '<S180>/Saturation1' */
      if (rtb_Add1_hb < ((uint16)10000U)) {
        rtb_Saturation1_m = rtb_Add1_hb;
      } else {
        rtb_Saturation1_m = ((uint16)10000U);
      }

      /* End of Saturate: '<S180>/Saturation1' */

      /* If: '<S180>/If' incorporates:
       *  Constant: '<S180>/Constant2'
       *  DataTypeConversion: '<S73>/Cast To Single'
       *  Inport: '<S181>/In'
       */
      if (rtb_Saturation1_m == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S180>/if action ' incorporates:
         *  ActionPort: '<S181>/Action Port'
         */
        LKAS_B.In_al = LKAS_B.LKASM_stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S180>/if action ' */
      }

      /* End of If: '<S180>/If' */

      /* If: '<S175>/If' */
      if (LKAS_B.In_al == 1) {
        /* Outputs for IfAction SubSystem: '<S175>/If Action Subsystem' incorporates:
         *  ActionPort: '<S177>/Action Port'
         */
        LKAS_IfActionSubsystem_j(rtb_Divide2_d, &rtb_deltafalllimit_b);

        /* End of Outputs for SubSystem: '<S175>/If Action Subsystem' */
      } else if (LKAS_B.In_al == 2) {
        /* Outputs for IfAction SubSystem: '<S175>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S178>/Action Port'
         */
        LKAS_IfActionSubsystem_j(rtb_Divide5, &rtb_deltafalllimit_b);

        /* End of Outputs for SubSystem: '<S175>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S175>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S179>/Action Port'
         */
        LKAS_IfActionSubsystem_j(rtb_LL_LFClb_TFC_DiffCtrlRatio,
          &rtb_deltafalllimit_b);

        /* End of Outputs for SubSystem: '<S175>/If Action Subsystem2' */
      }

      /* End of If: '<S175>/If' */

      /* Saturate: '<S175>/Saturation1' */
      if (rtb_deltafalllimit_b > 1000.0F) {
        rtb_deltafalllimit_b = 1000.0F;
      } else {
        if (rtb_deltafalllimit_b < 0.0F) {
          rtb_deltafalllimit_b = 0.0F;
        }
      }

      /* End of Saturate: '<S175>/Saturation1' */

      /* Product: '<S169>/Divide7' incorporates:
       *  Gain: '<S169>/Gain2'
       */
      rtb_Divide7 = rtb_L0_C3 * (-0.5F) * rtb_deltafalllimit_b;

      /* Gain: '<S169>/Gain3' */
      rtb_deltafalllimit_b = (-1.0F) * rtb_Gain2_a;

      /* Switch: '<S174>/Switch' incorporates:
       *  RelationalOperator: '<S174>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_deltafalllimit_b) {
        rtb_Switch_f = rtb_deltafalllimit_b;
      } else {
        rtb_Switch_f = rtb_Divide7;
      }

      /* End of Switch: '<S174>/Switch' */

      /* Switch: '<S174>/Switch2' incorporates:
       *  RelationalOperator: '<S174>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_Gain2_a) {
        rtb_Switch2_m5 = rtb_Gain2_a;
      } else {
        rtb_Switch2_m5 = rtb_Switch_f;
      }

      /* End of Switch: '<S174>/Switch2' */

      /* Product: '<S89>/Divide4' */
      rtb_Gain2_a = rtb_LL_LKAExPrcs_tiExitTime2;

      /* Saturate: '<S89>/Saturation1' */
      rtb_TLft = rtb_Gain2_a;
      if (rtb_TLft > 1.0F) {
        rtb_Gain2_a = 1.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Gain2_a = 0.0F;
      } else {
        rtb_Gain2_a = rtb_TLft;
      }

      /* End of Saturate: '<S89>/Saturation1' */

      /* Product: '<S89>/Divide2' */
      rtb_R0_C3 = rtb_Switch2_m5 * rtb_Gain2_a;

      /* Gain: '<S170>/kph to mps' */
      rtb_Gain2_a = rtb_LL_ThresDet_lDvtThresUprL_h;

      /* Product: '<S170>/Product' */
      rtb_LL_LFClb_TFC_facmGainLutGai = rtb_Gain2_a * rtb_Yk1_eq;

      /* Saturate: '<S170>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        rtb_Yk1_eq = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        rtb_Yk1_eq = 60.0F;
      } else {
        rtb_Yk1_eq = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S170>/Saturation3' */

      /* Product: '<S170>/Divide2' incorporates:
       *  Constant: '<S170>/Constant'
       */
      rtb_Yk1_eq = 0.09F / rtb_Yk1_eq;

      /* Saturate: '<S170>/Saturation1' */
      rtb_TLft = rtb_Yk1_eq;
      if (rtb_TLft > 0.01F) {
        rtb_Yk1_eq = 0.01F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Yk1_eq = 0.0F;
      } else {
        rtb_Yk1_eq = rtb_TLft;
      }

      /* End of Saturate: '<S170>/Saturation1' */

      /* Switch: '<S566>/Switch36' incorporates:
       *  Constant: '<S566>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S566>/Switch36' */

      /* Gain: '<S170>/Gain2' incorporates:
       *  Constant: '<S170>/Constant1'
       *  Gain: '<S170>/rad to deg'
       *  Math: '<S170>/Math Function'
       *  Product: '<S170>/Divide'
       *  Product: '<S170>/Divide1'
       *  Product: '<S170>/Product1'
       *  Product: '<S170>/Product2'
       *  Product: '<S170>/Product3'
       *  Sum: '<S170>/Add'
       *
       * About '<S170>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_Gain2_a = (rtb_Gain2_a * rtb_Gain2_a * rtb_Yk1_eq + 1.0F) /
        (rtb_Gain2_a / LKAS_B.LKA_WhlBaseL_C_e) * (57.2957802F *
        rtb_LL_LFClb_TFC_facmGainLutGai) * x10 * LKAS_B.LKA_StrRatio_C_g *
        (-1.0F);

      /* Saturate: '<S186>/Saturation4' */
      if (rtb_LL_LKAExPrcs_tiExitTime2 > 1.0F) {
        rtb_LL_LKAExPrcs_tiExitTime2 = 1.0F;
      } else {
        if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
        }
      }

      /* End of Saturate: '<S186>/Saturation4' */

      /* Product: '<S89>/Divide5' incorporates:
       *  Constant: '<S186>/Constant1'
       *  Product: '<S186>/Divide8'
       *  Sum: '<S186>/Add1'
       */
      rtb_Yk1_eq = (LKAS_ConstB.Add3 * rtb_LL_LKAExPrcs_tiExitTime2 + 0.0F) *
        rtb_Gain2_a;

      /* Saturate: '<S89>/Saturation3' */
      if (rtb_Merge_k > 0.004F) {
        rtb_deltafalllimit_b = 0.004F;
      } else if (rtb_Merge_k < (-0.004F)) {
        rtb_deltafalllimit_b = (-0.004F);
      } else {
        rtb_deltafalllimit_b = rtb_Merge_k;
      }

      /* End of Saturate: '<S89>/Saturation3' */

      /* Product: '<S89>/Divide3' */
      rtb_TLft = rtb_Saturation_bw / LKAS_B.Merge_p;

      /* Saturate: '<S89>/Saturation' */
      if (rtb_TLft > 1.0F) {
        rtb_TLft = 1.0F;
      } else {
        if (rtb_TLft < 0.0F) {
          rtb_TLft = 0.0F;
        }
      }

      /* End of Saturate: '<S89>/Saturation' */

      /* Sum: '<S89>/Add4' incorporates:
       *  Constant: '<S89>/Constant2'
       *  Product: '<S89>/Divide6'
       *  Product: '<S89>/Divide7'
       *  Sum: '<S89>/Add5'
       */
      rtb_R0_C3 = ((((1.0F - rtb_LL_LKASWASyn_M0) * LKAS_B.Merge1 +
                     rtb_LL_LFClb_TFC_vGainLutVehS_j) + rtb_R0_C3) + rtb_Yk1_eq)
        + LKAS_B.DifferenceInputs2_m * rtb_TLft;

      /* Memory: '<S184>/Memory3' */
      rtb_Yk1_eq = LKAS_DW.Memory3_PreviousInput_j;

      /* Sum: '<S184>/Add2' incorporates:
       *  Constant: '<S184>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_Yk1_eq += 1.0F;

      /* Saturate: '<S184>/Saturation' */
      rtb_TLft = rtb_Yk1_eq;
      if (rtb_TLft > 50.0F) {
        rtb_Saturation_ge = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation_ge = 0.0F;
      } else {
        rtb_Saturation_ge = rtb_TLft;
      }

      /* End of Saturate: '<S184>/Saturation' */

      /* Switch: '<S184>/Switch' incorporates:
       *  Constant: '<S89>/Constant1'
       *  Product: '<S184>/Divide'
       *  Product: '<S184>/Divide1'
       *  Sum: '<S184>/Add'
       *  Sum: '<S184>/Add1'
       *  UnitDelay: '<S184>/Unit Delay'
       */
      if (rtb_Saturation_ge > 30.0F) {
        LKAS_DW.UnitDelay_DSTATE_h += rtb_LKA_SampleTime / 0.1F * (rtb_R0_C3 -
          LKAS_DW.UnitDelay_DSTATE_h);
      } else {
        LKAS_DW.UnitDelay_DSTATE_h = rtb_R0_C3;
      }

      /* End of Switch: '<S184>/Switch' */

      /* Switch: '<S566>/Switch17' incorporates:
       *  Constant: '<S566>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2_n != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2_n;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S566>/Switch17' */

      /* Sum: '<S86>/Add' incorporates:
       *  UnitDelay: '<S184>/Unit Delay'
       */
      rtb_Add_mq = (LKAS_DW.UnitDelay_DSTATE_h - x10) + LKAS_B.Saturation;

      /* Sum: '<S86>/Add1' */
      rtb_Yk1_eq = rtb_Gain2_a + rtb_L0_C3_fd;

      /* Sum: '<S86>/Add2' incorporates:
       *  Gain: '<S86>/Gain2'
       */
      rtb_deltafalllimit_b = (-1.0F) * rtb_L0_C3_fd + rtb_Gain2_a;

      /* Switch: '<S165>/Switch' incorporates:
       *  RelationalOperator: '<S165>/UpperRelop'
       */
      if (rtb_Add_mq < rtb_deltafalllimit_b) {
        rtb_Switch_gc = rtb_deltafalllimit_b;
      } else {
        rtb_Switch_gc = rtb_Add_mq;
      }

      /* End of Switch: '<S165>/Switch' */

      /* Switch: '<S165>/Switch2' incorporates:
       *  RelationalOperator: '<S165>/LowerRelop1'
       */
      if (rtb_Add_mq > rtb_Yk1_eq) {
        rtb_Switch2_b = rtb_Yk1_eq;
      } else {
        rtb_Switch2_b = rtb_Switch_gc;
      }

      /* End of Switch: '<S165>/Switch2' */

      /* Sum: '<S164>/Add1' incorporates:
       *  Constant: '<S164>/Constant'
       *  Memory: '<S164>/Memory'
       */
      rtb_Add1_hb = (uint16)((uint32)((uint16)1U) +
        LKAS_DW.Memory_PreviousInput_bh);

      /* Switch: '<S164>/Switch' incorporates:
       *  Constant: '<S164>/LatchTime_SY'
       *  RelationalOperator: '<S164>/Relational Operator'
       *  UnitDelay: '<S164>/Delay Input2'
       *
       * Block description for '<S164>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Add1_hb <= ((uint16)1U)) {
        rtb_Yk1_eq = rtb_Switch2_b;
      } else {
        rtb_Yk1_eq = LKAS_DW.DelayInput2_DSTATE;
      }

      /* End of Switch: '<S164>/Switch' */

      /* Sum: '<S164>/Difference Inputs1'
       *
       * Block description for '<S164>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1 = rtb_Switch2_b - rtb_Yk1_eq;

      /* SampleTimeMath: '<S164>/sample time'
       *
       * About '<S164>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_deltafalllimit_b = 0.01F;

      /* Product: '<S164>/delta rise limit' incorporates:
       *  Gain: '<S86>/Gain3'
       */
      rtb_R0_C3 = 1.4F * LKAS_B.SWARmax * rtb_deltafalllimit_b;

      /* Product: '<S164>/delta fall limit' incorporates:
       *  Gain: '<S86>/Gain1'
       */
      rtb_deltafalllimit_b *= (-1.4F) * LKAS_B.SWARmax;

      /* Switch: '<S166>/Switch' incorporates:
       *  RelationalOperator: '<S166>/UpperRelop'
       */
      if (rtb_UkYk1 < rtb_deltafalllimit_b) {
        rtb_Switch_dl = rtb_deltafalllimit_b;
      } else {
        rtb_Switch_dl = rtb_UkYk1;
      }

      /* End of Switch: '<S166>/Switch' */

      /* Switch: '<S166>/Switch2' incorporates:
       *  RelationalOperator: '<S166>/LowerRelop1'
       */
      if (rtb_UkYk1 > rtb_R0_C3) {
        rtb_Switch2_lq = rtb_R0_C3;
      } else {
        rtb_Switch2_lq = rtb_Switch_dl;
      }

      /* End of Switch: '<S166>/Switch2' */

      /* Sum: '<S164>/Difference Inputs2'
       *
       * Block description for '<S164>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_B.DifferenceInputs2 = rtb_Switch2_lq + rtb_Yk1_eq;

      /* Saturate: '<S164>/Saturation2' */
      if (rtb_Add1_hb < ((uint16)10000U)) {
        rtb_Saturation2_m = rtb_Add1_hb;
      } else {
        rtb_Saturation2_m = ((uint16)10000U);
      }

      /* End of Saturate: '<S164>/Saturation2' */

      /* MATLAB Function: '<S111>/MATLAB Function' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      switch (LKAS_B.LKASM_stLKAActvFlg) {
       case 1:
        /* Saturate: '<S111>/Saturation' */
        rtb_TLft = rtb_Gain2_a;
        if (rtb_TLft > 20.0F) {
          rtb_TLft = 20.0F;
        } else {
          if (rtb_TLft < (-20.0F)) {
            rtb_TLft = (-20.0F);
          }
        }

        rtb_phiSWA0 = fminf(rtb_IMAPve_g_SW_Angle, rtb_TLft);
        break;

       case 2:
        /* Saturate: '<S111>/Saturation' */
        rtb_TLft = rtb_Gain2_a;
        if (rtb_TLft > 20.0F) {
          rtb_TLft = 20.0F;
        } else {
          if (rtb_TLft < (-20.0F)) {
            rtb_TLft = (-20.0F);
          }
        }

        rtb_phiSWA0 = fmaxf(rtb_IMAPve_g_SW_Angle, rtb_TLft);
        break;

       default:
        rtb_phiSWA0 = rtb_IMAPve_g_SW_Angle;
        break;
      }

      /* End of MATLAB Function: '<S111>/MATLAB Function' */

      /* DataTypeConversion: '<S87>/CastLKA3' */
      LKAS_B.T1_Mon = LKAS_B.Merge_p;

      /* Saturate: '<S104>/Saturation2' */
      if (rtb_L0_C2_p > 10.0F) {
        rtb_Saturation2 = 10.0F;
      } else if (rtb_L0_C2_p < 0.0F) {
        rtb_Saturation2 = 0.0F;
      } else {
        rtb_Saturation2 = rtb_L0_C2_p;
      }

      /* End of Saturate: '<S104>/Saturation2' */

      /* Saturate: '<S103>/Saturation2' */
      if (rtb_Add2_p > 10.0F) {
        rtb_Saturation2_g = 10.0F;
      } else if (rtb_Add2_p < 0.0F) {
        rtb_Saturation2_g = 0.0F;
      } else {
        rtb_Saturation2_g = rtb_Add2_p;
      }

      /* End of Saturate: '<S103>/Saturation2' */

      /* Saturate: '<S102>/Saturation2' */
      if (rtb_L0_C2 > 10.0F) {
        rtb_Saturation2_a = 10.0F;
      } else if (rtb_L0_C2 < 0.0F) {
        rtb_Saturation2_a = 0.0F;
      } else {
        rtb_Saturation2_a = rtb_L0_C2;
      }

      /* End of Saturate: '<S102>/Saturation2' */

      /* DataTypeConversion: '<S111>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_IMAPve_g_ESC_VehSpd;

      /* DataTypeConversion: '<S87>/CastLKA2' */
      LKAS_B.LKA_SampleTime_Mon = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S85>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S103>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_b) {
          /* Disable for Outport: '<S105>/Out' */
          LKAS_B.RelationalOperator_k = false;
          LKAS_DW.SumCondition1_MODE_b = false;
        }

        /* End of Disable for SubSystem: '<S103>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S83>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S91>/Out1' */
          LKAS_B.DifferenceInputs2_m = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S83>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S104>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_f.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_B.DataTypeConversion,
            &LKAS_DW.SumCondition1_f);
        }

        /* End of Disable for SubSystem: '<S104>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S104>/Sum Condition' */
        if (LKAS_DW.SumCondition_h.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_B.DataTypeConversion_i,
            &LKAS_DW.SumCondition_h);
        }

        /* End of Disable for SubSystem: '<S104>/Sum Condition' */

        /* Disable for If: '<S183>/If' */
        LKAS_DW.If_ActiveSubsystem_j = -1;

        /* Disable for Outport: '<S73>/LKA_ExitFlg' */
        LKAS_B.LogicalOperator3 = false;

        /* Disable for Outport: '<S73>/LKA_phiSWACmd' */
        LKAS_B.DifferenceInputs2 = 0.0F;

        /* Disable for Sum: '<S92>/Add1' incorporates:
         *  Outport: '<S73>/LKA_M'
         */
        LKAS_B.Saturation2 = 0.0F;

        /* Disable for Outport: '<S73>/LKAMon' */
        LKAS_B.LKA_ExitFlg_Mon = 0.0F;
        LKAS_B.LKA_SampleTime_Mon = 0.0F;
        LKAS_B.T1_Mon = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_ExitFlg_Mon = LKAS_B.LKA_ExitFlg_Mon;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_SampleTime_Mon = LKAS_B.LKA_SampleTime_Mon;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_T1_Mon = LKAS_B.T1_Mon;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_B.OutputM = LKAS_B.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_B.OutputSWACmd = LKAS_B.DifferenceInputs2;

    /* Sum: '<S221>/Add' */
    rtb_Add_fj = rtb_LL_LDW_LatestWarnLine_C - rtb_R0_C2;

    /* MATLAB Function: '<S221>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_Add_fj, rtb_Add_g5, &rtb_y_n);

    /* Saturate: '<S251>/Saturation3' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      x10 = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      x10 = 60.0F;
    } else {
      x10 = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S251>/Saturation3' */

    /* Product: '<S251>/Divide1' incorporates:
     *  Constant: '<S251>/Constant'
     */
    rtb_TLft = 0.09F / x10;

    /* Saturate: '<S251>/Saturation1' */
    if (rtb_TLft > 0.012141F) {
      rtb_TLft = 0.012141F;
    } else {
      if (rtb_TLft < 0.000982F) {
        rtb_TLft = 0.000982F;
      }
    }

    /* End of Saturate: '<S251>/Saturation1' */

    /* Product: '<S238>/Divide2' incorporates:
     *  Constant: '<S251>/constant '
     *  Product: '<S238>/Divide1'
     *  Product: '<S251>/Divide2'
     *  Product: '<S251>/Divide3'
     *  Product: '<S251>/Product1'
     *  Sum: '<S251>/Add'
     */
    rtb_y_a = rtb_LL_ThresDet_lDvtThresUprL_h / LKAS_B.LKA_WhlBaseL_C_e /
      (rtb_LL_ThresDet_lDvtThresUprL_h * rtb_LL_ThresDet_lDvtThresUprL_h *
       rtb_TLft + 1.0F) * rtb_Divide_it_tmp * rtb_y_a / LKAS_B.LKA_StrRatio_C_g;

    /* Sum: '<S210>/Add' */
    rtb_phiPrdcHdAgLft = rtb_Add_b + rtb_y_a;

    /* Sum: '<S210>/Add1' */
    rtb_phiPrdcHdAgRgt = rtb_Add_g5 + rtb_y_a;

    /* If: '<S236>/If' incorporates:
     *  Delay: '<S74>/Delay'
     */
    if (LKAS_DW.Delay_DSTATE == 1) {
      /* Outputs for IfAction SubSystem: '<S236>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S246>/Action Port'
       */
      LKAS_ifaction3(rtb_phiPrdcHdAgLft, &rtb_Merge_ky);

      /* End of Outputs for SubSystem: '<S236>/If Action Subsystem2' */
    } else if (LKAS_DW.Delay_DSTATE == 2) {
      /* Outputs for IfAction SubSystem: '<S236>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S245>/Action Port'
       */
      LKAS_ifaction3(rtb_phiPrdcHdAgRgt, &rtb_Merge_ky);

      /* End of Outputs for SubSystem: '<S236>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S236>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S247>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_phiPrdcHdAgLft, rtb_phiPrdcHdAgRgt,
        &rtb_Merge_ky);

      /* End of Outputs for SubSystem: '<S236>/If Action Subsystem3' */
    }

    /* End of If: '<S236>/If' */

    /* Product: '<S218>/Divide2' */
    rtb_LL_ThresDet_lDvtThresLwrLKA *= rtb_y_a;

    /* MATLAB Function: '<S221>/ ' incorporates:
     *  MATLAB Function: '<S220>/ '
     */
    rtb_R0_C1 *= cosf(rtb_Merge_ky);
    rtb_Saturation_ki *= sinf(rtb_Merge_ky);

    /* Sum: '<S221>/Add2' incorporates:
     *  MATLAB Function: '<S221>/ '
     *  Sum: '<S221>/Add4'
     */
    rtb_Add2_m = (rtb_y_n - (rtb_R0_C1 - rtb_Saturation_ki)) +
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Sum: '<S220>/Add' */
    rtb_Add_eq = rtb_LL_LDW_EarliestWarnLine_C - rtb_R0_C2;

    /* MATLAB Function: '<S220>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_Add_eq, rtb_Add_b, &rtb_y_a);

    /* Sum: '<S220>/Add3' incorporates:
     *  MATLAB Function: '<S220>/ '
     *  Sum: '<S220>/Add1'
     */
    rtb_Add3 = ((rtb_R0_C1 + rtb_Saturation_ki) + rtb_y_a) +
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* If: '<S215>/If' incorporates:
     *  Delay: '<S74>/Delay'
     */
    if (LKAS_DW.Delay_DSTATE == 1) {
      /* Outputs for IfAction SubSystem: '<S215>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S226>/Action Port'
       */
      LKAS_ifaction3(rtb_Add3, &rtb_Merge_m);

      /* End of Outputs for SubSystem: '<S215>/If Action Subsystem2' */
    } else if (LKAS_DW.Delay_DSTATE == 2) {
      /* Outputs for IfAction SubSystem: '<S215>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S225>/Action Port'
       */
      LKAS_ifaction3(rtb_Add2_m, &rtb_Merge_m);

      /* End of Outputs for SubSystem: '<S215>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S215>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S227>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_Add3, rtb_Add2_m, &rtb_Merge_m);

      /* End of Outputs for SubSystem: '<S215>/If Action Subsystem3' */
    }

    /* End of If: '<S215>/If' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_State_Mon = LKAS_B.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_B.LKA_State = LKAS_B.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LDW_State_Mon = LKAS_B.LDWSM_stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_B.LDW_State = LKAS_B.LDWSM_stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S72>/states'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (LKAS_B.LDWSM_stLDWActvFlg > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S77>/If' */
      if (LKAS_B.LDWSM_stLDWActvFlg == 1) {
        /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem' incorporates:
         *  ActionPort: '<S79>/Action Port'
         */
        /* Gain: '<S79>/rad to deg' incorporates:
         *  Gain: '<S79>/Gain'
         */
        LKAS_B.Merge_j = (-1.0F) * rtb_Saturation * 57.2957802F;

        /* End of Outputs for SubSystem: '<S77>/If Action Subsystem' */
      } else if (LKAS_B.LDWSM_stLDWActvFlg == 2) {
        /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S80>/Action Port'
         */
        /* Gain: '<S80>/rad to deg' */
        LKAS_B.Merge_j = 57.2957802F * rtb_L0_C0;

        /* End of Outputs for SubSystem: '<S77>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S81>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_B.Merge_j);

        /* End of Outputs for SubSystem: '<S77>/If Action Subsystem2' */
      }

      /* End of If: '<S77>/If' */

      /* Switch: '<S565>/Switch2' incorporates:
       *  Constant: '<S565>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S565>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S77>/Sum Condition' incorporates:
       *  EnablePort: '<S82>/state = reset'
       */
      /* RelationalOperator: '<S77>/Relational Operator' */
      if (LKAS_B.Merge_j >= x10) {
        if (!LKAS_DW.SumCondition_MODE) {
          /* InitializeConditions for Memory: '<S82>/Memory' */
          LKAS_DW.Memory_PreviousInput_e = 0.0F;
          LKAS_DW.SumCondition_MODE = true;
        }

        /* Saturate: '<S82>/Saturation' incorporates:
         *  Memory: '<S82>/Memory'
         *  Sum: '<S82>/Add1'
         */
        if (1.0F + LKAS_DW.Memory_PreviousInput_e > 600.0F) {
          LKAS_DW.Memory_PreviousInput_e = 600.0F;
        } else if (1.0F + LKAS_DW.Memory_PreviousInput_e < 0.0F) {
          LKAS_DW.Memory_PreviousInput_e = 0.0F;
        } else {
          LKAS_DW.Memory_PreviousInput_e++;
        }

        /* End of Saturate: '<S82>/Saturation' */

        /* DataTypeConversion: '<S82>/Data Type Conversion' incorporates:
         *  Constant: '<S77>/Constant'
         *  RelationalOperator: '<S82>/Relational Operator'
         */
        LKAS_B.DataTypeConversion_i2 = (uint8)(LKAS_DW.Memory_PreviousInput_e >=
          5.0F);
      } else {
        if (LKAS_DW.SumCondition_MODE) {
          /* Disable for Outport: '<S82>/Out' */
          LKAS_B.DataTypeConversion_i2 = ((uint8)0U);
          LKAS_DW.SumCondition_MODE = false;
        }
      }

      /* End of RelationalOperator: '<S77>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S77>/Sum Condition' */

      /* MATLAB Function: '<S72>/LDWWarnInfo' */
      if ((LKAS_B.LDWSM_stLDWActvFlg == 1) && (LKAS_B.DataTypeConversion_i2 == 0))
      {
        LKAS_B.LDWWarnInfo = 1U;
      } else if ((LKAS_B.LDWSM_stLDWActvFlg == 2) &&
                 (LKAS_B.DataTypeConversion_i2 == 0)) {
        LKAS_B.LDWWarnInfo = 2U;
      } else {
        LKAS_B.LDWWarnInfo = 0U;
      }

      /* End of MATLAB Function: '<S72>/LDWWarnInfo' */
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S77>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE) {
          /* Disable for Outport: '<S82>/Out' */
          LKAS_B.DataTypeConversion_i2 = ((uint8)0U);
          LKAS_DW.SumCondition_MODE = false;
        }

        /* End of Disable for SubSystem: '<S77>/Sum Condition' */

        /* Disable for Outport: '<S72>/LDW_Flag' */
        LKAS_B.LDWWarnInfo = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LFTTTLC_Mon = rtb_LFTTTLC;

    /* Logic: '<S507>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S507>/Relational Operator3'
     *  RelationalOperator: '<S507>/Relational Operator4'
     */
    rtb_LogicalOperator1_b = ((rtb_Gain1_i <= rtb_Abs_h) || (rtb_Add5_j <=
      rtb_Abs_h));

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_B.DACMode = LKAS_B.Divide;

    /* Delay: '<S75>/Delay1' */
    rtb_DACMode = LKAS_DW.Delay1_2_DSTATE;

    /* RelationalOperator: '<S542>/Compare' incorporates:
     *  Constant: '<S542>/Constant'
     *  Constant: '<S574>/Constant9'
     */
    rtb_Compare_mq = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S545>/Compare' incorporates:
     *  Constant: '<S545>/Constant'
     *  Constant: '<S574>/Constant12'
     */
    rtb_Compare_ox = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S547>/Compare' incorporates:
     *  Constant: '<S547>/Constant'
     *  Constant: '<S574>/Constant13'
     */
    rtb_Compare_hl = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S548>/Compare' incorporates:
     *  Constant: '<S548>/Constant'
     *  Constant: '<S574>/Constant14'
     */
    rtb_Compare_ny = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S549>/Compare' incorporates:
     *  Constant: '<S549>/Constant'
     *  Constant: '<S574>/Constant15'
     */
    rtb_Compare_b0 = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S550>/Compare' incorporates:
     *  Constant: '<S550>/Constant'
     *  Constant: '<S574>/Constant16'
     */
    rtb_Compare_dg = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S556>/Compare' incorporates:
     *  Constant: '<S556>/Constant'
     *  Constant: '<S574>/Constant6'
     */
    rtb_Compare_ga = (((uint8)0U) == ((uint8)1U));
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S388>/Count 20s' */
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S397>/Out' */
        LKAS_B.RelationalOperator_gm = false;
        LKAS_DW.Count20s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S388>/Count 20s' */

      /* Disable for Enabled SubSystem: '<S389>/Sum Condition2' */
      if (LKAS_DW.SumCondition2_MODE) {
        /* Disable for Outport: '<S398>/Out' */
        LKAS_B.RelationalOperator_j = false;
        LKAS_DW.SumCondition2_MODE = false;
      }

      /* End of Disable for SubSystem: '<S389>/Sum Condition2' */

      /* Disable for Enabled SubSystem: '<S399>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_c) {
        /* Disable for Outport: '<S405>/Out' */
        LKAS_B.RelationalOperator_e = false;
        LKAS_DW.SumCondition1_MODE_c = false;
      }

      /* End of Disable for SubSystem: '<S399>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S414>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S421>/Out' */
        LKAS_B.RelationalOperator_g = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S414>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S326>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S359>/Out' */
        LKAS_B.RelationalOperator_fi = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S326>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S326>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Sum: '<S358>/Add' incorporates:
         *  Outport: '<S358>/Out'
         */
        LKAS_B.Saturation_l = ((uint16)0U);
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S326>/Count' */

      /* Disable for Enabled SubSystem: '<S361>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_d) {
        /* Disable for Outport: '<S367>/Out' */
        LKAS_B.RelationalOperator_mu = false;
        LKAS_DW.SumCondition1_MODE_d = false;
      }

      /* End of Disable for SubSystem: '<S361>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S327>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S373>/Out' */
        LKAS_B.DataTypeConversion_c = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }

      /* End of Disable for SubSystem: '<S327>/Sum Condition1' */

      /* Disable for If: '<S376>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S282>/Count_5s3' */
      if (LKAS_DW.Count_5s3.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_B.RelationalOperator_h, &LKAS_DW.Count_5s3);
      }

      /* End of Disable for SubSystem: '<S282>/Count_5s3' */

      /* Disable for Enabled SubSystem: '<S282>/Count_5s2' */
      if (LKAS_DW.Count_5s2.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_B.RelationalOperator_m, &LKAS_DW.Count_5s2);
      }

      /* End of Disable for SubSystem: '<S282>/Count_5s2' */

      /* Disable for Enabled SubSystem: '<S282>/Count_5s4' */
      if (LKAS_DW.Count_5s4.Count_5s4_MODE) {
        LKAS_Count_5s4_Disable(&LKAS_B.RelationalOperator_l, &LKAS_DW.Count_5s4);
      }

      /* End of Disable for SubSystem: '<S282>/Count_5s4' */

      /* Disable for Enabled SubSystem: '<S282>/Count_5s1' */
      if (LKAS_DW.Count_5s1.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_B.RelationalOperator_f, &LKAS_DW.Count_5s1);
      }

      /* End of Disable for SubSystem: '<S282>/Count_5s1' */

      /* Disable for Enabled SubSystem: '<S282>/Count_5s5' */
      if (LKAS_DW.Count_5s5.Count_5s4_MODE) {
        LKAS_Count_5s4_Disable(&LKAS_B.RelationalOperator, &LKAS_DW.Count_5s5);
      }

      /* End of Disable for SubSystem: '<S282>/Count_5s5' */

      /* Disable for Enabled SubSystem: '<S260>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE) {
        /* Disable for Outport: '<S264>/Out' */
        LKAS_B.RelationalOperator_hy = false;
        LKAS_DW.Subsystem_MODE = false;
      }

      /* End of Disable for SubSystem: '<S260>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S85>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S103>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_b) {
          /* Disable for Outport: '<S105>/Out' */
          LKAS_B.RelationalOperator_k = false;
          LKAS_DW.SumCondition1_MODE_b = false;
        }

        /* End of Disable for SubSystem: '<S103>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S83>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S91>/Out1' */
          LKAS_B.DifferenceInputs2_m = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S83>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S104>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_f.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_B.DataTypeConversion,
            &LKAS_DW.SumCondition1_f);
        }

        /* End of Disable for SubSystem: '<S104>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S104>/Sum Condition' */
        if (LKAS_DW.SumCondition_h.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_B.DataTypeConversion_i,
            &LKAS_DW.SumCondition_h);
        }

        /* End of Disable for SubSystem: '<S104>/Sum Condition' */

        /* Disable for If: '<S183>/If' */
        LKAS_DW.If_ActiveSubsystem_j = -1;

        /* Disable for Outport: '<S73>/LKA_ExitFlg' */
        LKAS_B.LogicalOperator3 = false;

        /* Disable for Outport: '<S73>/LKA_phiSWACmd' */
        LKAS_B.DifferenceInputs2 = 0.0F;

        /* Disable for Sum: '<S92>/Add1' incorporates:
         *  Outport: '<S73>/LKA_M'
         */
        LKAS_B.Saturation2 = 0.0F;

        /* Disable for Outport: '<S73>/LKAMon' */
        LKAS_B.LKA_ExitFlg_Mon = 0.0F;
        LKAS_B.LKA_SampleTime_Mon = 0.0F;
        LKAS_B.T1_Mon = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S77>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE) {
          /* Disable for Outport: '<S82>/Out' */
          LKAS_B.DataTypeConversion_i2 = ((uint8)0U);
          LKAS_DW.SumCondition_MODE = false;
        }

        /* End of Disable for SubSystem: '<S77>/Sum Condition' */

        /* Disable for Outport: '<S72>/LDW_Flag' */
        LKAS_B.LDWWarnInfo = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_B.LDW_State = ((uint8)0U);
      LKAS_B.DACMode = ((uint8)0U);
      LKAS_B.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_B.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_B.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MultiPortSwitch: '<S9>/Multiport Switch' incorporates:
   *  Constant: '<S9>/Constant'
   *  Constant: '<S9>/Constant1'
   *  Constant: '<S9>/Constant2'
   *  Constant: '<S9>/Constant3'
   *  Constant: '<S9>/Constant4'
   *  Constant: '<S9>/Constant5'
   *  Constant: '<S9>/Constant6'
   */
  switch (LKAS_B.LKA_State) {
   case 0:
    rtb_EPS_LKA_Control = ((uint8)0U);
    break;

   case 1:
    rtb_EPS_LKA_Control = ((uint8)1U);
    break;

   case 2:
    rtb_EPS_LKA_Control = ((uint8)2U);
    break;

   case 3:
    rtb_EPS_LKA_Control = ((uint8)3U);
    break;

   case 4:
    rtb_EPS_LKA_Control = ((uint8)4U);
    break;

   case 5:
    rtb_EPS_LKA_Control = ((uint8)4U);
    break;

   default:
    rtb_EPS_LKA_Control = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S9>/Multiport Switch' */

  /* RelationalOperator: '<S70>/Compare' incorporates:
   *  Constant: '<S70>/Constant'
   */
  rtb_LogicalOperator2_p = (rtb_EPS_LKA_Control == ((uint8)4U));

  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_EPS_State_Control_1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control
    (rtb_EPS_LKA_Control);

  /* Switch: '<S32>/Switch' incorporates:
   *  Constant: '<S32>/Constant'
   *  Constant: '<S32>/Constant1'
   *  Constant: '<S34>/Constant'
   *  RelationalOperator: '<S34>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_TLft = 0.5F;
  } else {
    rtb_TLft = 0.25F;
  }

  /* End of Switch: '<S32>/Switch' */

  /* Outputs for Enabled SubSystem: '<S32>/Count 15s' incorporates:
   *  EnablePort: '<S41>/Enable'
   */
  /* Outputs for Enabled SubSystem: '<S32>/Count 10s' incorporates:
   *  EnablePort: '<S40>/Enable'
   */
  /* Logic: '<S32>/Logical Operator2' incorporates:
   *  Abs: '<S32>/Abs'
   *  Constant: '<S35>/Constant'
   *  Constant: '<S36>/Constant'
   *  Constant: '<S37>/Constant'
   *  Constant: '<S38>/Constant'
   *  Constant: '<S39>/Constant'
   *  Logic: '<S32>/Logical Operator3'
   *  RelationalOperator: '<S32>/Relational Operator'
   *  RelationalOperator: '<S35>/Compare'
   *  RelationalOperator: '<S36>/Compare'
   *  RelationalOperator: '<S37>/Compare'
   *  RelationalOperator: '<S38>/Compare'
   *  RelationalOperator: '<S39>/Compare'
   */
  if (((LKAS_B.LDW_State == ((uint8)5U)) || (LKAS_B.LDW_State == ((uint8)4U)) ||
       (LKAS_B.LDW_State == ((uint8)3U)) || (rtb_IMAPve_d_EPS_LKA_State ==
        ((uint8)3U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) && (fabsf
       (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_TLft)) {
    if (!LKAS_DW.Count10s_MODE) {
      /* InitializeConditions for Sum: '<S40>/Add' incorporates:
       *  Memory: '<S40>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_f = ((uint16)0U);
      LKAS_DW.Count10s_MODE = true;
    }

    /* Sum: '<S40>/Add' incorporates:
     *  Constant: '<S40>/Constant'
     *  Memory: '<S40>/Memory'
     */
    LKAS_DW.Memory_PreviousInput_f = (uint16)((uint32)((uint16)1U) +
      LKAS_DW.Memory_PreviousInput_f);

    /* Saturate: '<S40>/Saturation' */
    if (LKAS_DW.Memory_PreviousInput_f >= ((uint16)2100U)) {
      /* Sum: '<S40>/Add' */
      LKAS_DW.Memory_PreviousInput_f = ((uint16)2100U);
    }

    /* End of Saturate: '<S40>/Saturation' */

    /* RelationalOperator: '<S42>/Compare' incorporates:
     *  Constant: '<S42>/Constant'
     */
    LKAS_B.Compare_d = (LKAS_DW.Memory_PreviousInput_f >= ((uint16)1000U));
    if (!LKAS_DW.Count15s_MODE) {
      /* InitializeConditions for Sum: '<S41>/Add' incorporates:
       *  Memory: '<S41>/Memory'
       */
      LKAS_DW.Memory_PreviousInput_bz = ((uint16)0U);
      LKAS_DW.Count15s_MODE = true;
    }

    /* Sum: '<S41>/Add' incorporates:
     *  Constant: '<S41>/Constant'
     *  Memory: '<S41>/Memory'
     */
    LKAS_DW.Memory_PreviousInput_bz = (uint16)((uint32)((uint16)1U) +
      LKAS_DW.Memory_PreviousInput_bz);

    /* Saturate: '<S41>/Saturation' */
    if (LKAS_DW.Memory_PreviousInput_bz >= ((uint16)2100U)) {
      /* Sum: '<S41>/Add' */
      LKAS_DW.Memory_PreviousInput_bz = ((uint16)2100U);
    }

    /* End of Saturate: '<S41>/Saturation' */

    /* RelationalOperator: '<S43>/Compare' incorporates:
     *  Constant: '<S43>/Constant'
     */
    LKAS_B.Compare = (LKAS_DW.Memory_PreviousInput_bz >= ((uint16)1500U));
  } else {
    if (LKAS_DW.Count10s_MODE) {
      /* Disable for Outport: '<S40>/Out' */
      LKAS_B.Compare_d = false;
      LKAS_DW.Count10s_MODE = false;
    }

    if (LKAS_DW.Count15s_MODE) {
      /* Disable for Outport: '<S41>/Out' */
      LKAS_B.Compare = false;
      LKAS_DW.Count15s_MODE = false;
    }
  }

  /* End of Logic: '<S32>/Logical Operator2' */
  /* End of Outputs for SubSystem: '<S32>/Count 10s' */
  /* End of Outputs for SubSystem: '<S32>/Count 15s' */

  /* MATLAB Function: '<S7>/LDW_Flag' */
  switch (LKAS_B.Divide) {
   case 1:
    switch (LKAS_B.LDWWarnInfo) {
     case 1:
      rtb_IMAPve_d_BCM_HazardLamp = 1U;
      break;

     case 2:
      rtb_IMAPve_d_BCM_HazardLamp = 2U;
      break;

     default:
      rtb_IMAPve_d_BCM_HazardLamp = 0U;
      break;
    }
    break;

   case 2:
    if ((LKAS_B.LDWWarnInfo == 1) && (LKAS_B.LKA_State == 4)) {
      rtb_IMAPve_d_BCM_HazardLamp = 1U;
    } else if ((LKAS_B.LDWWarnInfo == 2) && (LKAS_B.LKA_State == 5)) {
      rtb_IMAPve_d_BCM_HazardLamp = 2U;
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = 0U;
    }
    break;

   default:
    rtb_IMAPve_d_BCM_HazardLamp = 0U;
    break;
  }

  /* End of MATLAB Function: '<S7>/LDW_Flag' */

  /* MATLAB Function: '<S7>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S52>/Switch'
   *  Switch: '<S52>/Switch1'
   */
  switch (LKAS_B.Divide) {
   case 1:
    if ((LKAS_B.LDW_State == 3) && (rtb_L0_Q == 3) && (rtb_R0_Q != 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 3U;
    } else if ((LKAS_B.LDW_State == 3) && (rtb_L0_Q != 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 4U;
    } else if ((LKAS_B.LDW_State == 3) && (rtb_L0_Q == 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 5U;
    } else if ((LKAS_B.LDW_State == 4) && (rtb_L0_Q == 3) && (rtb_R0_Q != 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 6U;
    } else if ((LKAS_B.LDW_State == 5) && (rtb_L0_Q != 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 7U;
    } else if ((LKAS_B.LDW_State == 4) && (rtb_L0_Q == 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 8U;
    } else if ((LKAS_B.LDW_State == 5) && (rtb_L0_Q == 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 9U;
    } else {
      rtb_IMAPve_d_BCM_Left_Light = 1U;
    }
    break;

   case 2:
    if ((LKAS_B.LKA_State == 3) && (rtb_L0_Q == 3) && (rtb_R0_Q != 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 3U;
    } else if ((LKAS_B.LKA_State == 3) && (rtb_L0_Q != 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 4U;
    } else if ((LKAS_B.LKA_State == 3) && (rtb_L0_Q == 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 5U;
    } else if ((LKAS_B.LKA_State == 4) && (rtb_L0_Q == 3) && (rtb_R0_Q != 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 6U;
    } else if ((LKAS_B.LKA_State == 5) && (rtb_L0_Q != 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 7U;
    } else if ((LKAS_B.LKA_State == 4) && (rtb_L0_Q == 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 8U;
    } else if ((LKAS_B.LKA_State == 5) && (rtb_L0_Q == 3) && (rtb_R0_Q == 3)) {
      rtb_IMAPve_d_BCM_Left_Light = 9U;
    } else {
      rtb_IMAPve_d_BCM_Left_Light = 1U;
    }
    break;

   default:
    rtb_IMAPve_d_BCM_Left_Light = 0U;
    break;
  }

  /* End of MATLAB Function: '<S7>/Vehicle_Lane_Display' */

  /* DataTypeConversion: '<S9>/Cast To Single10' incorporates:
   *  Constant: '<S71>/Constant'
   *  RelationalOperator: '<S71>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)(LKAS_B.DACMode > ((uint8)0U));

  /* DataTypeConversion: '<S9>/Cast To Single13' */
  rtb_LKA_Mode_from_Camera = LKAS_B.DACMode;

  /* Switch: '<S52>/Switch' incorporates:
   *  DataTypeConversion: '<S61>/Cast To Single5'
   */
  if (LKAS_B.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_p = rtb_R0_Type;
  } else {
    rtb_R0_Type_p = rtb_L0_Type;
  }

  /* Switch: '<S52>/Switch1' incorporates:
   *  Constant: '<S58>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_Q_1'
   *  DataTypeConversion: '<S59>/Cast To Single5'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_Q'
   *  Switch: '<S58>/Switch3'
   */
  if (LKAS_B.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_a = rtb_L0_Type;
    rtb_L1_Q = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L1_Q_IMAPve_d_ORI_L1_Q();
  } else {
    rtb_L0_Type_a = rtb_R0_Type;
    rtb_L1_Q = ((uint16)0U);
  }

  /* DataTypeConversion: '<S51>/Cast To Single19' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_LC_1'
   *  Inport: '<Root>/IMAPve_d_ORI_R0_LC'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R0_LC_IMAPve_d_ORI_R0_LC();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_LC_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_L0_LC'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L0_LC_IMAPve_d_ORI_L0_LC();

  /* Switch: '<S60>/Switch3' incorporates:
   *  Constant: '<S60>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_Q_1'
   *  DataTypeConversion: '<S51>/Cast To Single9'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_Q'
   *  Switch: '<S52>/Switch'
   */
  if (LKAS_B.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R1_Q = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R1_Q_IMAPve_d_ORI_R1_Q();
    rtb_R0_LC_l = rtb_L0_Type;
  } else {
    rtb_R1_Q = ((uint16)0U);
    rtb_R0_LC_l = rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S60>/Switch3' */

  /* Switch: '<S52>/Switch1' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single9'
   *  DataTypeConversion: '<S59>/Cast To Single8'
   */
  if (LKAS_B.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_LC_g = rtb_EPS_LKA_Control;
  } else {
    rtb_L0_LC_g = rtb_L0_Type;
  }

  /* DataTypeConversion: '<S51>/Cast To Single24' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_VR_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_VR'
   */
  rtb_Saturation =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_VR_IMAPve_g_ORI_R0_VR();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_VR_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_L0_VR'
   */
  rtb_L0_C0 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_VR_IMAPve_g_ORI_L0_VR
    ();

  /* Switch: '<S52>/Switch' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single32'
   */
  if (LKAS_B.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_VR_d = rtb_Saturation;
  } else {
    rtb_R0_VR_d = rtb_L0_C0;
  }

  /* Switch: '<S52>/Switch1' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single32'
   *  DataTypeConversion: '<S59>/Cast To Single4'
   */
  if (LKAS_B.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_g = rtb_L0_C0;
  } else {
    rtb_L0_VR_g = rtb_Saturation;
  }

  /* DataTypeConversion: '<S51>/Cast To Single40' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_W'
   */
  rtb_Saturation =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_W_IMAPve_g_ORI_R0_W();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_W_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_L0_W'
   */
  rtb_L0_C0 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_W_IMAPve_g_ORI_L0_W();

  /* Switch: '<S52>/Switch' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single37'
   */
  if (LKAS_B.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_k = rtb_Saturation;
  } else {
    rtb_R0_W_k = rtb_L0_C0;
  }

  /* Switch: '<S52>/Switch1' incorporates:
   *  DataTypeConversion: '<S51>/Cast To Single37'
   *  DataTypeConversion: '<S59>/Cast To Single6'
   */
  if (LKAS_B.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_c = rtb_L0_C0;
  } else {
    rtb_L0_W_c = rtb_Saturation;
  }

  /* RelationalOperator: '<S20>/Compare' incorporates:
   *  Constant: '<S20>/Constant'
   */
  rtb_Compare_i = (rtb_IMAPve_d_TCU_Actual_Gear > ((uint8)3U));

  /* RelationalOperator: '<S13>/Compare' incorporates:
   *  Constant: '<S13>/Constant'
   */
  rtb_Compare_ho = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Signal_Fault_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Camera_Signal_Fault'
   */
  rtb_IMAPve_d_Camera_Signal_Faul = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Signal_Fault_IMAPve_d_Camera_Signal_Fault
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Camera_Status'
   */
  rtb_IMAPve_d_Camera_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_ConsArea_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ConsArea'
   */
  rtb_IMAPve_d_ConsArea = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ConsArea_IMAPve_d_ConsArea();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Error_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Error_State'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Error_State_IMAPve_d_EPS_Error_State
    ();

  /* Logic: '<S6>/Logical Operator5' incorporates:
   *  Constant: '<S14>/Constant'
   *  Constant: '<S17>/Constant'
   *  RelationalOperator: '<S14>/Compare'
   *  RelationalOperator: '<S17>/Compare'
   */
  rtb_Event_FaulETATDA = ((rtb_EPS_LKA_Control == ((uint8)1U)) ||
    (rtb_EPS_LKA_Control == ((uint8)2U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State'
   */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    ();

  /* RelationalOperator: '<S21>/Compare' incorporates:
   *  Constant: '<S21>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_TrqLim_State'
   */
  rtb_Compare_c = ((uint8)
                   Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State
                   () == ((uint8)0U));

  /* RelationalOperator: '<S22>/Compare' incorporates:
   *  Constant: '<S22>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_Trq_State'
   */
  rtb_Compare_k0 = ((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State
                    () == ((uint8)1U));

  /* RelationalOperator: '<S23>/Compare' incorporates:
   *  Constant: '<S23>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid'
   */
  rtb_Compare_cj = ((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid
                    () == ((uint8)1U));

  /* RelationalOperator: '<S25>/Compare' incorporates:
   *  Constant: '<S25>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid'
   */
  rtb_Compare_ku = ((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid
                    () == ((uint8)1U));

  /* RelationalOperator: '<S12>/Compare' incorporates:
   *  Constant: '<S12>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid'
   */
  rtb_Compare_b5 = ((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid
                    () != ((uint8)1U));

  /* RelationalOperator: '<S24>/Compare' incorporates:
   *  Constant: '<S24>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid'
   */
  rtb_Compare_gr = ((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid
                    () == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Fusion_Status'
   */
  rtb_IMAPve_d_Fusion_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status();

  /* DataTypeConversion: '<S51>/Cast To Single80' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_LC_1'
   *  Inport: '<Root>/IMAPve_d_L0_LC'
   */
  rtb_L0_LC_l = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_LC_IMAPve_d_L0_LC();

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Q'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q();

  /* Switch: '<S56>/Switch' incorporates:
   *  Constant: '<S56>/Constant'
   */
  if (rtb_EPS_LKA_Control >= ((uint8)2U)) {
    rtb_L0_Q_l = ((uint8)3U);
  } else {
    rtb_L0_Q_l = rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S56>/Switch' */

  /* DataTypeConversion: '<S51>/Cast To Single77' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1'
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   */
  rtb_L0_Type_m = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type();

  /* DataTypeConversion: '<S51>/Cast To Single62' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_LC_1'
   *  Inport: '<Root>/IMAPve_d_L1_LC'
   */
  rtb_L1_LC = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_LC_IMAPve_d_L1_LC();

  /* DataTypeConversion: '<S51>/Cast To Single58' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1'
   *  Inport: '<Root>/IMAPve_d_L1_Q'
   */
  rtb_L1_Q_l = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q();

  /* DataTypeConversion: '<S51>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   */
  rtb_L1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LDW_Warn_Mode'
   */
  rtb_IMAPve_d_LDW_Warn_Mode = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode();

  /* DataTypeConversion: '<S1>/IMAPve_d_Lane_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Lane_Valid'
   */
  rtb_IMAPve_d_Lane_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Lane_Valid_IMAPve_d_Lane_Valid();

  /* DataTypeConversion: '<S51>/Cast To Single29' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_LC_1'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_LC'
   */
  rtb_L1_LC_f = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L1_LC_IMAPve_d_ORI_L1_LC();

  /* DataTypeConversion: '<S51>/Cast To Single26' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_Type'
   */
  rtb_L1_Type_c = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L1_Type_IMAPve_d_ORI_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_ConsArea_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_Lane_ConsArea'
   */
  rtb_IMAPve_d_ORI_Lane_ConsArea = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_Lane_ConsArea_IMAPve_d_ORI_Lane_ConsArea
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_RoadType_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_Lane_RoadType'
   */
  rtb_IMAPve_d_ORI_Lane_RoadType = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_Lane_RoadType_IMAPve_d_ORI_Lane_RoadType
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_Lane_Valid'
   */
  rtb_IMAPve_d_ORI_Lane_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_Lane_Valid_IMAPve_d_ORI_Lane_Valid
    ();

  /* DataTypeConversion: '<S51>/Cast To Single39' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_LC_1'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_LC'
   */
  rtb_R1_LC = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R1_LC_IMAPve_d_ORI_R1_LC();

  /* DataTypeConversion: '<S51>/Cast To Single36' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_LT_1'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_LT'
   */
  rtb_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R1_LT_IMAPve_d_ORI_R1_LT();

  /* DataTypeConversion: '<S51>/Cast To Single51' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_LC_1'
   *  Inport: '<Root>/IMAPve_d_R0_LC'
   */
  rtb_R0_LC_b = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_LC_IMAPve_d_R0_LC();

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Q'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q();

  /* Switch: '<S53>/Switch1' incorporates:
   *  Constant: '<S53>/Constant1'
   */
  if (rtb_EPS_LKA_Control >= ((uint8)2U)) {
    rtb_R0_Q_d = ((uint8)3U);
  } else {
    rtb_R0_Q_d = rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S53>/Switch1' */

  /* DataTypeConversion: '<S51>/Cast To Single48' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1'
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   */
  rtb_R0_Type_l = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type();

  /* DataTypeConversion: '<S51>/Cast To Single73' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_LC_1'
   *  Inport: '<Root>/IMAPve_d_R1_LC'
   */
  rtb_R1_LC_f = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_LC_IMAPve_d_R1_LC();

  /* DataTypeConversion: '<S51>/Cast To Single69' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1'
   *  Inport: '<Root>/IMAPve_d_R1_Q'
   */
  rtb_R1_Q_d = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q();

  /* DataTypeConversion: '<S51>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   */
  rtb_R1_Type_g = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_Road_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Road_Type'
   */
  rtb_IMAPve_d_Road_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Road_Type_IMAPve_d_Road_Type();

  /* RelationalOperator: '<S15>/Compare' incorporates:
   *  Constant: '<S15>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Clb_State'
   */
  rtb_Compare_pd = ((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State
                    () == ((uint8)0U));

  /* RelationalOperator: '<S16>/Compare' incorporates:
   *  Constant: '<S16>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Trim_State'
   */
  rtb_Compare_kl = ((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State
                    () == ((uint8)1U));

  /* Logic: '<S6>/Logical Operator6' incorporates:
   *  Constant: '<S18>/Constant'
   *  Constant: '<S19>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_SWS_Fault_Code_1'
   *  Inport: '<Root>/IMAPve_d_SWS_Failure_Status'
   *  Inport: '<Root>/IMAPve_d_SWS_Fault_Code'
   *  RelationalOperator: '<S18>/Compare'
   *  RelationalOperator: '<S19>/Compare'
   */
  rtb_Event_FaulSWS = (((uint8)
                        Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Fault_Code_IMAPve_d_SWS_Fault_Code
                        () != ((uint8)0U)) || ((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status
    () != ((uint8)1U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Sensor_Status'
   */
  rtb_IMAPve_d_Sensor_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status();

  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  rtb_IMAPve_g_EMS_RealPedal =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  rtb_IMAPve_g_EPS_LKA_Current =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  rtb_IMAPve_g_ESC_Brake_Press =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  rtb_IMAPve_g_ESC_UnYawRate =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  rtb_IMAPve_g_ESC_YawRate =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate();

  /* DataTypeConversion: '<S51>/Cast To Single64' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   */
  rtb_L0_C0_m = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0();

  /* DataTypeConversion: '<S51>/Cast To Single61' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
   *  Inport: '<Root>/IMAPve_g_L0_C1'
   */
  rtb_L0_C1_n = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1();

  /* DataTypeConversion: '<S51>/Cast To Single65' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   */
  rtb_L0_C2_i = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2();

  /* DataTypeConversion: '<S51>/Cast To Single67' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   */
  rtb_L0_C3_d = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_Confidence'
   */
  rtb_IMAPve_g_L0_Confidence =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_Confidence_IMAPve_g_L0_Confidence();

  /* DataTypeConversion: '<S51>/Cast To Single68' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_TLC_1'
   *  Inport: '<Root>/IMAPve_g_L0_TLC'
   */
  rtb_L0_TLC_i = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_TLC_IMAPve_g_L0_TLC();

  /* DataTypeConversion: '<S51>/Cast To Single66' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1'
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   */
  rtb_L0_VR_n = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR();

  /* DataTypeConversion: '<S51>/Cast To Single71' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_W_1'
   *  Inport: '<Root>/IMAPve_g_L0_W'
   */
  rtb_L0_W_i = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W();

  /* DataTypeConversion: '<S51>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   */
  rtb_L1_C0 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0();

  /* DataTypeConversion: '<S51>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   */
  rtb_L1_C1 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1();

  /* DataTypeConversion: '<S51>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   */
  rtb_L1_C2 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2();

  /* DataTypeConversion: '<S51>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   */
  rtb_L1_C3 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3();

  /* DataTypeConversion: '<S1>/IMAPve_g_L1_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L1_Confidence'
   */
  rtb_IMAPve_g_L1_Confidence =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_Confidence_IMAPve_g_L1_Confidence();

  /* DataTypeConversion: '<S51>/Cast To Single63' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_TLC_1'
   *  Inport: '<Root>/IMAPve_g_L1_TLC'
   */
  rtb_L1_TLC = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_TLC_IMAPve_g_L1_TLC();

  /* DataTypeConversion: '<S51>/Cast To Single78' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  rtb_L1_VR = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR();

  /* DataTypeConversion: '<S51>/Cast To Single74' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  rtb_L1_W = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W();

  /* DataTypeConversion: '<S51>/Cast To Single11' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C0'
   */
  rtb_L1_C0_k =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C0_IMAPve_g_ORI_L1_C0();

  /* DataTypeConversion: '<S51>/Cast To Single10' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C1'
   */
  rtb_L1_C1_a =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C1_IMAPve_g_ORI_L1_C1();

  /* DataTypeConversion: '<S51>/Cast To Single12' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C2'
   */
  rtb_L1_C2_k =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C2_IMAPve_g_ORI_L1_C2();

  /* DataTypeConversion: '<S51>/Cast To Single8' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C3'
   */
  rtb_L1_C3_j =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C3_IMAPve_g_ORI_L1_C3();

  /* DataTypeConversion: '<S51>/Cast To Single3' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_TLC_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_TLC'
   */
  rtb_L1_TLC_m =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_TLC_IMAPve_g_ORI_L1_TLC();

  /* DataTypeConversion: '<S51>/Cast To Single7' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_VR'
   */
  rtb_L1_VR_n =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_VR_IMAPve_g_ORI_L1_VR();

  /* DataTypeConversion: '<S51>/Cast To Single4' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_W'
   */
  rtb_L1_W_e = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_W_IMAPve_g_ORI_L1_W();

  /* DataTypeConversion: '<S51>/Cast To Single14' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C0'
   */
  rtb_R1_C0 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C0_IMAPve_g_ORI_R1_C0
    ();

  /* DataTypeConversion: '<S51>/Cast To Single13' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C1'
   */
  rtb_R1_C1 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C1_IMAPve_g_ORI_R1_C1
    ();

  /* DataTypeConversion: '<S51>/Cast To Single17' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C2'
   */
  rtb_R1_C2 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C2_IMAPve_g_ORI_R1_C2
    ();

  /* DataTypeConversion: '<S51>/Cast To Single20' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C3'
   */
  rtb_R1_C3 = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C3_IMAPve_g_ORI_R1_C3
    ();

  /* DataTypeConversion: '<S51>/Cast To Single1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_TLC_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_TLC'
   */
  rtb_R1_TLC =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_TLC_IMAPve_g_ORI_R1_TLC();

  /* DataTypeConversion: '<S51>/Cast To Single18' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_VR'
   */
  rtb_R1_VR = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_VR_IMAPve_g_ORI_R1_VR
    ();

  /* DataTypeConversion: '<S51>/Cast To Single2' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_W'
   */
  rtb_R1_W = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_W_IMAPve_g_ORI_R1_W();

  /* DataTypeConversion: '<S51>/Cast To Single55' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   */
  rtb_R0_C0_k = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0();

  /* DataTypeConversion: '<S51>/Cast To Single54' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
   *  Inport: '<Root>/IMAPve_g_R0_C1'
   */
  rtb_R0_C1_i = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1();

  /* DataTypeConversion: '<S51>/Cast To Single56' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   */
  rtb_R0_C2_j = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2();

  /* DataTypeConversion: '<S51>/Cast To Single60' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   */
  rtb_R0_C3_f = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3();

  /* DataTypeConversion: '<S1>/IMAPve_g_R0_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_R0_Confidence'
   */
  rtb_IMAPve_g_R0_Confidence =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_Confidence_IMAPve_g_R0_Confidence();

  /* DataTypeConversion: '<S51>/Cast To Single72' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_TLC_1'
   *  Inport: '<Root>/IMAPve_g_R0_TLC'
   */
  rtb_R0_TLC_p = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_TLC_IMAPve_g_R0_TLC();

  /* DataTypeConversion: '<S51>/Cast To Single57' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   */
  rtb_R0_VR_j = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR();

  /* DataTypeConversion: '<S51>/Cast To Single75' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  rtb_R0_W_m = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W();

  /* DataTypeConversion: '<S51>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   */
  rtb_R1_C0_j = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0();

  /* DataTypeConversion: '<S51>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   */
  rtb_R1_C1_i = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1();

  /* DataTypeConversion: '<S51>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   */
  rtb_R1_C2_n = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2();

  /* DataTypeConversion: '<S51>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   */
  rtb_R1_C3_p = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3();

  /* DataTypeConversion: '<S1>/IMAPve_g_R1_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_R1_Confidence'
   */
  rtb_IMAPve_g_R1_Confidence =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_Confidence_IMAPve_g_R1_Confidence();

  /* DataTypeConversion: '<S51>/Cast To Single41' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_TLC_1'
   *  Inport: '<Root>/IMAPve_g_R1_TLC'
   */
  rtb_R1_TLC_h = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_TLC_IMAPve_g_R1_TLC();

  /* DataTypeConversion: '<S51>/Cast To Single50' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  rtb_R1_VR_g = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR();

  /* DataTypeConversion: '<S51>/Cast To Single52' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  rtb_R1_W_a = Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle_Speed'
   */
  rtb_IMAPve_g_SW_Angle_Speed =
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
    ();

  /* Switch: '<S566>/Switch12' incorporates:
   *  Constant: '<S566>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23_o != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23_o;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S566>/Switch12' */

  /* Switch: '<S567>/Switch18' incorporates:
   *  Constant: '<S567>/LL_LKAS_OUT_OF_CONTROL_TTLC=0.3'
   */
  if (LKAS_ConstB.DataTypeConversion38 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion38;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S567>/Switch18' */

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/states'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S74>/Delay' */
    LKAS_DW.Delay_DSTATE = LKAS_B.LKASM_stLKAActvFlg;

    /* Update for Memory: '<S531>/Memory' */
    LKAS_DW.Memory_PreviousInput_d = rtb_Saturation_e;

    /* Update for UnitDelay: '<S491>/UD'
     *
     * Block description for '<S491>/UD':
     *
     *  Store in Global RAM
     */
    LKAS_DW.UD_DSTATE = rtb_TSamp;

    /* Update for Memory: '<S475>/Memory' */
    LKAS_DW.Memory_PreviousInput_p = rtb_Saturation_d;

    /* Update for UnitDelay: '<S392>/UD'
     *
     * Block description for '<S392>/UD':
     *
     *  Store in Global RAM
     */
    LKAS_DW.UD_DSTATE_c = rtb_TSamp_n;

    /* Update for UnitDelay: '<S401>/Delay Input1'
     *
     * Block description for '<S401>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_ef;

    /* Update for UnitDelay: '<S399>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_ba = LKAS_B.RelationalOperator_e;

    /* Update for UnitDelay: '<S400>/Delay Input1'
     *
     * Block description for '<S400>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_j = rtb_Compare_oq;

    /* Update for Delay: '<S75>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_B.LKASM_stLKAState;

    /* Update for UnitDelay: '<S363>/Delay Input1'
     *
     * Block description for '<S363>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_b = rtb_Compare_cg;

    /* Update for UnitDelay: '<S361>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_c = LKAS_B.RelationalOperator_mu;

    /* Update for UnitDelay: '<S362>/Delay Input1'
     *
     * Block description for '<S362>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_p = rtb_Compare_ki;

    /* Update for Memory: '<S326>/Memory' */
    LKAS_DW.Memory_PreviousInput_eb = LKAS_B.RelationalOperator_mu;

    /* Update for Delay: '<S75>/Delay' */
    LKAS_DW.Delay_DSTATE_e = LKAS_B.LogicalOperator3;

    /* Update for Delay: '<S75>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_B.LDWSM_stLDWState;

    /* Update for Memory: '<S376>/Memory' */
    LKAS_DW.Memory_PreviousInput_ms = rtb_LDW_State;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S73>/states = reset'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S102>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = rtb_Saturation2_a;

      /* Update for Memory: '<S137>/Memory' */
      LKAS_DW.Memory_PreviousInput_l = rtb_Saturation1_l;

      /* Update for Memory: '<S85>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_k = rtb_Saturation1_ks;

      /* Update for Memory: '<S136>/Memory' */
      LKAS_DW.Memory_PreviousInput_lx = rtb_Saturation1_la;

      /* Update for Memory: '<S138>/Memory' */
      LKAS_DW.Memory_PreviousInput_k = rtb_Saturation1_b;

      /* Update for Memory: '<S157>/Memory' */
      LKAS_DW.Memory_PreviousInput_h3 = rtb_Add_p2;

      /* Update for Memory: '<S135>/Memory' */
      LKAS_DW.Memory_PreviousInput_d2 = rtb_Saturation1_f;

      /* Update for Memory: '<S134>/Memory' */
      LKAS_DW.Memory_PreviousInput_ko = rtb_Saturation1_b2;

      /* Update for Memory: '<S133>/Memory' */
      LKAS_DW.Memory_PreviousInput_mm = rtb_Saturation1_e;

      /* Update for Memory: '<S112>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = rtb_Add_c3;

      /* Update for Memory: '<S103>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = rtb_Saturation2_g;

      /* Update for Memory: '<S104>/Memory' */
      LKAS_DW.Memory_PreviousInput_aw = rtb_Saturation2;

      /* Update for Memory: '<S101>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_i = rtb_Saturation_d3;

      /* Update for Memory: '<S185>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_c = rtb_Saturation_bw;

      /* Update for Memory: '<S171>/Memory' */
      LKAS_DW.Memory_PreviousInput_av = rtb_Add1_f;

      /* Update for Memory: '<S176>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_h = rtb_Saturation_n;

      /* Update for Memory: '<S180>/Memory' */
      LKAS_DW.Memory_PreviousInput_e4 = rtb_Saturation1_m;

      /* Update for Memory: '<S184>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_j = rtb_Saturation_ge;

      /* Update for UnitDelay: '<S164>/Delay Input2'
       *
       * Block description for '<S164>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE = LKAS_B.DifferenceInputs2;

      /* Update for Memory: '<S164>/Memory' */
      LKAS_DW.Memory_PreviousInput_bh = rtb_Saturation2_m;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S75>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_B.Divide;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    (rtb_IMAPve_d_BCM_Left_Light);

  /* MATLAB Function: '<S7>/LDW_Status_Display' */
  if ((LKAS_B.Divide == 1) && (LKAS_B.LDW_State != 6)) {
    rtb_IMAPve_d_BCM_Left_Light = 1U;
  } else if ((LKAS_B.Divide == 1) && (LKAS_B.LDW_State == 6)) {
    rtb_IMAPve_d_BCM_Left_Light = 2U;
  } else {
    rtb_IMAPve_d_BCM_Left_Light = 0U;
  }

  /* End of MATLAB Function: '<S7>/LDW_Status_Display' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    (rtb_IMAPve_d_BCM_Left_Light);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* MATLAB Function: '<S7>/LKA_Status_Display' */
  if ((LKAS_B.Divide == 2) && (LKAS_B.LKA_State != 6)) {
    rtb_Switch3_0 = 1;
  } else if ((LKAS_B.Divide == 2) && (LKAS_B.LKA_State == 6)) {
    rtb_Switch3_0 = 2;
  } else {
    rtb_Switch3_0 = 0;
  }

  /* End of MATLAB Function: '<S7>/LKA_Status_Display' */

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single2'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((uint8)(sint32)fmodf((float32)rtb_Switch3_0, 256.0F));

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single3'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag
    (rtb_IMAPve_d_BCM_HazardLamp);

  /* MATLAB Function: '<S7>/Hands_off_warning' */
  if (!LKAS_B.Compare) {
    rtb_IMAPve_d_BCM_Left_Light = 0U;
  } else {
    rtb_IMAPve_d_BCM_Left_Light = LKAS_B.Compare;
  }

  /* End of MATLAB Function: '<S7>/Hands_off_warning' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning
    (rtb_IMAPve_d_BCM_Left_Light);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* MATLAB Function: '<S7>/LKA_action_indication' */
  if ((LKAS_B.Divide == 2) && (LKAS_B.LKA_State == 2)) {
    rtb_IMAPve_d_BCM_Left_Light = 1U;
  } else if ((LKAS_B.Divide == 2) && (LKAS_B.LKA_State == 3)) {
    rtb_IMAPve_d_BCM_Left_Light = 2U;
  } else if ((LKAS_B.Divide == 2) && ((LKAS_B.LKA_State == 4) ||
              (LKAS_B.LKA_State == 5))) {
    rtb_IMAPve_d_BCM_Left_Light = 3U;
  } else {
    rtb_IMAPve_d_BCM_Left_Light = 0U;
  }

  /* End of MATLAB Function: '<S7>/LKA_action_indication' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    (rtb_IMAPve_d_BCM_Left_Light);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* MATLAB Function: '<S7>/HMI_Popup_Status' incorporates:
   *  Constant: '<S575>/Constant'
   */
  if ((LKAS_B.Divide == 2) && (LKAS_B.LKA_State == 6)) {
    rtb_IMAPve_d_BCM_Left_Light = 6U;
  } else if (((LKAS_B.Divide == 2) || (LKAS_B.Divide == 1)) && (((uint8)0U) == 5))
  {
    rtb_IMAPve_d_BCM_Left_Light = 4U;
  } else if (((LKAS_B.Divide == 2) || (LKAS_B.Divide == 1)) && LKAS_B.Compare_d)
  {
    rtb_IMAPve_d_BCM_Left_Light = 2U;
  } else if ((LKAS_B.Divide == 2) && (LKAS_B.LKA_State == 2)) {
    rtb_IMAPve_d_BCM_Left_Light = 1U;
  } else if (LKAS_B.Divide != 2) {
    rtb_IMAPve_d_BCM_Left_Light = 8U;
  } else {
    rtb_IMAPve_d_BCM_Left_Light = 7U;
  }

  /* End of MATLAB Function: '<S7>/HMI_Popup_Status' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status
    (rtb_IMAPve_d_BCM_Left_Light);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S9>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    (LKAS_B.OutputSWACmd);

  /* Switch: '<S9>/Switch' incorporates:
   *  Constant: '<S9>/Constant7'
   */
  if (rtb_LogicalOperator2_p) {
    rtb_L0_C0 = LKAS_B.OutputM;
  } else {
    rtb_L0_C0 = 0.0F;
  }

  /* End of Switch: '<S9>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    (rtb_L0_C0);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single9'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    (LKAS_ConstB.Permit_to_know_if_LKA_or_LP);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S376>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S85>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S183>/If' */
  LKAS_DW.If_ActiveSubsystem_j = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S69>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* InitializeConditions for Memory: '<S63>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = (-1.75F);

  /* InitializeConditions for Memory: '<S64>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 1.75F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S74>/Delay' */
  LKAS_DW.Delay_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S531>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* InitializeConditions for UnitDelay: '<S491>/UD'
   *
   * Block description for '<S491>/UD':
   *
   *  Store in Global RAM
   */
  LKAS_DW.UD_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S475>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = 0.0F;

  /* InitializeConditions for UnitDelay: '<S392>/UD'
   *
   * Block description for '<S392>/UD':
   *
   *  Store in Global RAM
   */
  LKAS_DW.UD_DSTATE_c = 0.0F;

  /* InitializeConditions for UnitDelay: '<S401>/Delay Input1'
   *
   * Block description for '<S401>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S399>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_ba = false;

  /* InitializeConditions for UnitDelay: '<S400>/Delay Input1'
   *
   * Block description for '<S400>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_j = false;

  /* InitializeConditions for Delay: '<S75>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for UnitDelay: '<S363>/Delay Input1'
   *
   * Block description for '<S363>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_b = false;

  /* InitializeConditions for UnitDelay: '<S361>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_c = false;

  /* InitializeConditions for UnitDelay: '<S362>/Delay Input1'
   *
   * Block description for '<S362>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_p = false;

  /* InitializeConditions for Memory: '<S326>/Memory' */
  LKAS_DW.Memory_PreviousInput_eb = false;

  /* InitializeConditions for Delay: '<S75>/Delay' */
  LKAS_DW.Delay_DSTATE_e = false;

  /* InitializeConditions for Delay: '<S75>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S376>/Memory' */
  LKAS_DW.Memory_PreviousInput_ms = ((uint8)0U);

  /* InitializeConditions for Delay: '<S75>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S388>/Count 20s' */
  /* InitializeConditions for Sum: '<S397>/Add' incorporates:
   *  Memory: '<S397>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_i3 = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S388>/Count 20s' */

  /* SystemInitialize for Enabled SubSystem: '<S389>/Sum Condition2' */
  /* InitializeConditions for Sum: '<S398>/Add1' incorporates:
   *  Memory: '<S398>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_p0 = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S389>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S399>/Sum Condition1' */
  /* InitializeConditions for Sum: '<S405>/Add1' incorporates:
   *  Memory: '<S405>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_h = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S399>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S414>/Sum Condition1' */
  /* InitializeConditions for Sum: '<S421>/Add1' incorporates:
   *  Memory: '<S421>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_cz = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S414>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S326>/Count 0.2s' */
  /* InitializeConditions for Sum: '<S359>/Add' incorporates:
   *  Memory: '<S359>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_n = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S326>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S326>/Count' */
  /* InitializeConditions for Memory: '<S358>/Memory' */
  LKAS_DW.Memory_PreviousInput_e0 = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S326>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S361>/Sum Condition1' */
  /* InitializeConditions for Sum: '<S367>/Add1' incorporates:
   *  Memory: '<S367>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_ps = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S361>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S327>/Sum Condition1' */
  /* InitializeConditions for Sum: '<S373>/Add1' incorporates:
   *  Memory: '<S373>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_a1 = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S327>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S376>/If Action Subsystem' */
  /* InitializeConditions for Sum: '<S408>/Add1' incorporates:
   *  Memory: '<S408>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_pu = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S376>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S282>/Count_5s3' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s3);

  /* End of SystemInitialize for SubSystem: '<S282>/Count_5s3' */

  /* SystemInitialize for Enabled SubSystem: '<S282>/Count_5s2' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s2);

  /* End of SystemInitialize for SubSystem: '<S282>/Count_5s2' */

  /* SystemInitialize for Enabled SubSystem: '<S282>/Count_5s4' */
  LKAS_Count_5s4_Init(&LKAS_DW.Count_5s4);

  /* End of SystemInitialize for SubSystem: '<S282>/Count_5s4' */

  /* SystemInitialize for Enabled SubSystem: '<S282>/Count_5s1' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s1);

  /* End of SystemInitialize for SubSystem: '<S282>/Count_5s1' */

  /* SystemInitialize for Enabled SubSystem: '<S282>/Count_5s5' */
  LKAS_Count_5s4_Init(&LKAS_DW.Count_5s5);

  /* End of SystemInitialize for SubSystem: '<S282>/Count_5s5' */

  /* SystemInitialize for Enabled SubSystem: '<S260>/Subsystem' */
  /* InitializeConditions for Sum: '<S264>/Add1' incorporates:
   *  Memory: '<S264>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_mo = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S260>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S102>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S137>/Memory' */
  LKAS_DW.Memory_PreviousInput_l = ((uint16)0U);

  /* InitializeConditions for Memory: '<S85>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_k = ((uint8)0U);

  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput_lx = ((uint16)0U);

  /* InitializeConditions for Memory: '<S138>/Memory' */
  LKAS_DW.Memory_PreviousInput_k = ((uint16)0U);

  /* InitializeConditions for Memory: '<S157>/Memory' */
  LKAS_DW.Memory_PreviousInput_h3 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S135>/Memory' */
  LKAS_DW.Memory_PreviousInput_d2 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S134>/Memory' */
  LKAS_DW.Memory_PreviousInput_ko = ((uint16)0U);

  /* InitializeConditions for Memory: '<S133>/Memory' */
  LKAS_DW.Memory_PreviousInput_mm = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = 0.0F;

  /* InitializeConditions for Memory: '<S103>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 0.0F;

  /* InitializeConditions for Memory: '<S104>/Memory' */
  LKAS_DW.Memory_PreviousInput_aw = 0.0F;

  /* InitializeConditions for Memory: '<S101>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_i = 0.0F;

  /* InitializeConditions for Memory: '<S185>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_c = 0.0F;

  /* InitializeConditions for Memory: '<S171>/Memory' */
  LKAS_DW.Memory_PreviousInput_av = 0.0F;

  /* InitializeConditions for UnitDelay: '<S169>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

  /* InitializeConditions for Memory: '<S176>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_h = 0.0F;

  /* InitializeConditions for Memory: '<S180>/Memory' */
  LKAS_DW.Memory_PreviousInput_e4 = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S184>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_h = 0.0F;

  /* InitializeConditions for Memory: '<S184>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_j = 0.0F;

  /* InitializeConditions for UnitDelay: '<S164>/Delay Input2'
   *
   * Block description for '<S164>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S164>/Memory' */
  LKAS_DW.Memory_PreviousInput_bh = ((uint16)0U);

  /* SystemInitialize for IfAction SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)'
   *
   * Block description for '<S85>/LKA Motion Planning Calculation (LKAMPCal)':
   *  Block Name: LKA Motion Planning Calculation
   *  Ab.: LKAMPCal
   *  No.: 1.2.3.2
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  LKAMotionPlanningCalculati_Init();

  /* End of SystemInitialize for SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */

  /* SystemInitialize for Enabled SubSystem: '<S103>/Sum Condition1' */
  /* InitializeConditions for Sum: '<S105>/Add1' incorporates:
   *  Memory: '<S105>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_gg = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S103>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S92>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S92>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S104>/Moving Standard Deviation1' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S104>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S104>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_f);

  /* End of SystemInitialize for SubSystem: '<S104>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S104>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2_e);

  /* End of SystemInitialize for SubSystem: '<S104>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S104>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_h);

  /* End of SystemInitialize for SubSystem: '<S104>/Sum Condition' */

  /* SystemInitialize for IfAction SubSystem: '<S183>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S193>/Delay Input1'
   *
   * Block description for '<S193>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_jd = false;

  /* InitializeConditions for Memory: '<S189>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S183>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S183>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S201>/Delay Input1'
   *
   * Block description for '<S201>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_n = false;

  /* InitializeConditions for Memory: '<S190>/Memory' */
  LKAS_DW.Memory_PreviousInput_m2 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S183>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S183>/Merge' */
  LKAS_B.Merge_p = 1.0F;

  /* SystemInitialize for Merge: '<S183>/Merge1' */
  LKAS_B.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S77>/Merge' */
  LKAS_B.Merge_j = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S77>/Sum Condition' */
  /* InitializeConditions for Memory: '<S82>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S77>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S32>/Count 10s' */
  /* InitializeConditions for Sum: '<S40>/Add' incorporates:
   *  Memory: '<S40>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_f = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S32>/Count 10s' */

  /* SystemInitialize for Enabled SubSystem: '<S32>/Count 15s' */
  /* InitializeConditions for Sum: '<S41>/Add' incorporates:
   *  Memory: '<S41>/Memory'
   */
  LKAS_DW.Memory_PreviousInput_bz = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S32>/Count 15s' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
