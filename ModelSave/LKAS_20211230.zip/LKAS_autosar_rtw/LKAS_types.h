/*
 * File: LKAS_types.h
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.30
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Dec 30 16:56:36 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#ifndef RTW_HEADER_LKAS_types_h_
#define RTW_HEADER_LKAS_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_CAN_MESSAGE_BUS_
#define DEFINED_TYPEDEF_FOR_CAN_MESSAGE_BUS_

typedef struct {
  uint8 Extended;
  uint8 Length;
  uint8 Remote;
  uint8 Error;
  uint32 ID;
  float64 Timestamp;
  uint8 Data[8];
} CAN_MESSAGE_BUS;

#endif
#endif                                 /* RTW_HEADER_LKAS_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
