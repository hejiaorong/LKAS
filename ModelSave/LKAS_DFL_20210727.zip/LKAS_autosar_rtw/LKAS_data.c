/*
 * File: LKAS_data.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.59
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Jul 27 17:53:37 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Invariant block signals (default storage) */
const ConstB_LKAS_T LKAS_ConstB = {
  0.1F,                                /* '<S70>/Divide2' */
  0.9F,                                /* '<S70>/Add2' */
  0.1F,                                /* '<S62>/Divide2' */
  0.9F,                                /* '<S62>/Add2' */
  0.1F,                                /* '<S63>/Divide2' */
  0.9F,                                /* '<S63>/Add2' */
  0.0F,                                /* '<S543>/Data Type Conversion74' */
  0.0F,                                /* '<S543>/Data Type Conversion84' */
  0.0F,                                /* '<S543>/Data Type Conversion89' */
  0.0F,                                /* '<S543>/Data Type Conversion10' */
  0.0F,                                /* '<S543>/Data Type Conversion11' */
  0.0F,                                /* '<S543>/Data Type Conversion12' */
  0.0F,                                /* '<S543>/Data Type Conversion14' */
  0.0F,                                /* '<S543>/Data Type Conversion15' */
  0.0F,                                /* '<S543>/Data Type Conversion16' */
  0.0F,                                /* '<S543>/Data Type Conversion17' */
  0.0F,                                /* '<S543>/Data Type Conversion18' */
  0.0F,                                /* '<S543>/Data Type Conversion19' */
  0.0F,                                /* '<S543>/Data Type Conversion20' */
  0.0F,                                /* '<S543>/Data Type Conversion36' */
  0.0F,                                /* '<S543>/Data Type Conversion44' */
  0.0F,                                /* '<S543>/Data Type Conversion45' */
  0.0F,                                /* '<S543>/Data Type Conversion46' */
  0.0F,                                /* '<S543>/Data Type Conversion69' */
  0.0F,                                /* '<S543>/Data Type Conversion58' */
  0.0F,                                /* '<S543>/Data Type Conversion67' */
  0.0F,                                /* '<S543>/Data Type Conversion47' */
  0.0F,                                /* '<S543>/Data Type Conversion64' */
  0.0F,                                /* '<S543>/Data Type Conversion66' */
  0.0F,                                /* '<S543>/Data Type Conversion68' */
  0.0F,                                /* '<S543>/Data Type Conversion70' */
  0.0F,                                /* '<S543>/Data Type Conversion72' */
  0.0F,                                /* '<S543>/Data Type Conversion75' */
  0.0F,                                /* '<S543>/Data Type Conversion76' */
  0.0F,                                /* '<S543>/Data Type Conversion77' */
  0.0F,                                /* '<S543>/Data Type Conversion78' */
  0.0F,                                /* '<S543>/Data Type Conversion80' */
  0.0F,                                /* '<S543>/Data Type Conversion82' */
  0.0F,                                /* '<S543>/Data Type Conversion83' */
  0.0F,                                /* '<S543>/Data Type Conversion5' */
  0.0F,                                /* '<S543>/Data Type Conversion7' */
  0.0F,                                /* '<S543>/Data Type Conversion6' */
  0.0F,                                /* '<S543>/Data Type Conversion8' */
  0.0F,                                /* '<S543>/Data Type Conversion13' */
  0.0F,                                /* '<S543>/Data Type Conversion26' */
  0.0F,                                /* '<S543>/Data Type Conversion65' */
  0.0F,                                /* '<S543>/Data Type Conversion87' */
  0.0F,                                /* '<S543>/Data Type Conversion88' */
  0.0F,                                /* '<S543>/Data Type Conversion85' */
  0.0F,                                /* '<S543>/Data Type Conversion86' */
  0.0F,                                /* '<S541>/Data Type Conversion6' */
  0.0F,                                /* '<S542>/Data Type Conversion8' */
  0.0F,                                /* '<S542>/Data Type Conversion3' */
  0.0F,                                /* '<S542>/Data Type Conversion16' */
  0.0F,                                /* '<S542>/Data Type Conversion5' */
  0.0F,                                /* '<S542>/Data Type Conversion10' */
  0.0F,                                /* '<S542>/Data Type Conversion6' */
  0.0F,                                /* '<S542>/Data Type Conversion13' */
  0.0F,                                /* '<S542>/Data Type Conversion22' */
  0.0F,                                /* '<S542>/Data Type Conversion21' */
  0.0F,                                /* '<S542>/Data Type Conversion2' */
  0.0F,                                /* '<S542>/Data Type Conversion11' */
  0.0F,                                /* '<S542>/Data Type Conversion15' */
  0.0F,                                /* '<S542>/Data Type Conversion14' */
  0.0F,                                /* '<S542>/Data Type Conversion4' */
  0.0F,                                /* '<S542>/Data Type Conversion7' */
  0.0F,                                /* '<S542>/Data Type Conversion17' */
  0.0F,                                /* '<S542>/Data Type Conversion18' */
  0.0F,                                /* '<S542>/Data Type Conversion28' */
  0.0F,                                /* '<S542>/Data Type Conversion29' */
  0.0F,                                /* '<S542>/Data Type Conversion49' */
  0.0F,                                /* '<S542>/Data Type Conversion48' */
  0.0F,                                /* '<S542>/Data Type Conversion9' */
  0.0F,                                /* '<S542>/Data Type Conversion32' */
  0.0F,                                /* '<S542>/Data Type Conversion31' */
  0.0F,                                /* '<S542>/Data Type Conversion50' */
  0.0F,                                /* '<S542>/Data Type Conversion52' */
  0.0F,                                /* '<S542>/Data Type Conversion53' */
  0.0F,                                /* '<S542>/Data Type Conversion12' */
  0.0F,                                /* '<S542>/Data Type Conversion19' */
  0.0F,                                /* '<S542>/Data Type Conversion20' */
  0.0F,                                /* '<S542>/Data Type Conversion24' */
  0.0F,                                /* '<S542>/Data Type Conversion25' */
  0.0F,                                /* '<S542>/Data Type Conversion55' */
  0.0F,                                /* '<S542>/Data Type Conversion54' */
  0.0F,                                /* '<S542>/Data Type Conversion34' */
  0.0F,                                /* '<S542>/Data Type Conversion33' */
  0.0F,                                /* '<S540>/Data Type Conversion3' */
  0.0F,                                /* '<S540>/Data Type Conversion13' */
  0.0F,                                /* '<S540>/Data Type Conversion2' */
  0.0F,                                /* '<S540>/Data Type Conversion4' */
  0.0F,                                /* '<S540>/Data Type Conversion6' */
  0.0F,                                /* '<S540>/Data Type Conversion22' */
  0.0F,                                /* '<S542>/Data Type Conversion1' */
  0.0F,                                /* '<S542>/Data Type Conversion23' */
  0.0F,                                /* '<S543>/Data Type Conversion21' */
  0.0F,                                /* '<S543>/Data Type Conversion25' */
  0.0F,                                /* '<S543>/Data Type Conversion9' */
  0.1F,                                /* '<S177>/Divide2' */
  0.9F,                                /* '<S177>/Add2' */
  1.0F,                                /* '<S189>/Add3' */
  0U,                                  /* '<S10>/Cast To Single4' */
  0,                                   /* '<S542>/Data Type Conversion47' */
  0                                    /* '<S542>/Data Type Conversion35' */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
