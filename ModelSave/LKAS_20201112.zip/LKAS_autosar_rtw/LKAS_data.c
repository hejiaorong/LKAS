/*
 * File: LKAS_data.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.77
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Nov 12 10:11:14 2020
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Invariant block signals (default storage) */
const ConstB_LKAS_T LKAS_ConstB = {
  10.0F,                               /* '<S69>/Saturation' */
  0.1F,                                /* '<S69>/Divide2' */
  0.9F,                                /* '<S69>/Add2' */
  10.0F,                               /* '<S63>/Saturation' */
  0.1F,                                /* '<S63>/Divide2' */
  0.9F,                                /* '<S63>/Add2' */
  10.0F,                               /* '<S64>/Saturation' */
  0.1F,                                /* '<S64>/Divide2' */
  0.9F,                                /* '<S64>/Add2' */
  0.0F,                                /* '<S567>/Data Type Conversion22' */
  0.0F,                                /* '<S567>/Data Type Conversion23' */
  0.0F,                                /* '<S567>/Data Type Conversion24' */
  0.0F,                                /* '<S567>/Data Type Conversion27' */
  0.0F,                                /* '<S567>/Data Type Conversion28' */
  0.0F,                                /* '<S567>/Data Type Conversion29' */
  0.0F,                                /* '<S567>/Data Type Conversion30' */
  0.0F,                                /* '<S567>/Data Type Conversion31' */
  0.0F,                                /* '<S567>/Data Type Conversion32' */
  0.0F,                                /* '<S567>/Data Type Conversion33' */
  0.0F,                                /* '<S567>/Data Type Conversion34' */
  0.0F,                                /* '<S567>/Data Type Conversion35' */
  0.0F,                                /* '<S567>/Data Type Conversion37' */
  0.0F,                                /* '<S567>/Data Type Conversion39' */
  0.0F,                                /* '<S567>/Data Type Conversion40' */
  0.0F,                                /* '<S567>/Data Type Conversion41' */
  0.0F,                                /* '<S567>/Data Type Conversion42' */
  0.0F,                                /* '<S567>/Data Type Conversion43' */
  0.0F,                                /* '<S567>/Data Type Conversion53' */
  0.0F,                                /* '<S567>/Data Type Conversion1' */
  0.0F,                                /* '<S567>/Data Type Conversion51' */
  0.0F,                                /* '<S567>/Data Type Conversion48' */
  0.0F,                                /* '<S567>/Data Type Conversion49' */
  0.0F,                                /* '<S567>/Data Type Conversion50' */
  0.0F,                                /* '<S567>/Data Type Conversion52' */
  0.0F,                                /* '<S567>/Data Type Conversion54' */
  0.0F,                                /* '<S567>/Data Type Conversion55' */
  0.0F,                                /* '<S567>/Data Type Conversion56' */
  0.0F,                                /* '<S567>/Data Type Conversion57' */
  0.0F,                                /* '<S567>/Data Type Conversion59' */
  0.0F,                                /* '<S567>/Data Type Conversion60' */
  0.0F,                                /* '<S567>/Data Type Conversion61' */
  0.0F,                                /* '<S567>/Data Type Conversion62' */
  0.0F,                                /* '<S567>/Data Type Conversion63' */
  0.0F,                                /* '<S567>/Data Type Conversion3' */
  0.0F,                                /* '<S567>/Data Type Conversion4' */
  0.0F,                                /* '<S567>/Data Type Conversion2' */
  0.0F,                                /* '<S567>/Data Type Conversion79' */
  0.0F,                                /* '<S567>/Data Type Conversion81' */
  0.0F,                                /* '<S567>/Data Type Conversion71' */
  0.0F,                                /* '<S567>/Data Type Conversion73' */
  0.0F,                                /* '<S565>/Data Type Conversion6' */
  0.0F,                                /* '<S566>/Data Type Conversion8' */
  0.0F,                                /* '<S566>/Data Type Conversion1' */
  0.0F,                                /* '<S566>/Data Type Conversion3' */
  0.0F,                                /* '<S566>/Data Type Conversion16' */
  0.0F,                                /* '<S566>/Data Type Conversion5' */
  0.0F,                                /* '<S566>/Data Type Conversion10' */
  0.0F,                                /* '<S566>/Data Type Conversion6' */
  0.0F,                                /* '<S566>/Data Type Conversion13' */
  0.0F,                                /* '<S566>/Data Type Conversion22' */
  0.0F,                                /* '<S566>/Data Type Conversion21' */
  0.0F,                                /* '<S566>/Data Type Conversion2' */
  0.0F,                                /* '<S566>/Data Type Conversion11' */
  0.0F,                                /* '<S566>/Data Type Conversion15' */
  0.0F,                                /* '<S566>/Data Type Conversion14' */
  0.0F,                                /* '<S566>/Data Type Conversion4' */
  0.0F,                                /* '<S566>/Data Type Conversion7' */
  0.0F,                                /* '<S566>/Data Type Conversion17' */
  0.0F,                                /* '<S566>/Data Type Conversion18' */
  0.0F,                                /* '<S566>/Data Type Conversion28' */
  0.0F,                                /* '<S566>/Data Type Conversion29' */
  0.0F,                                /* '<S566>/Data Type Conversion49' */
  0.0F,                                /* '<S566>/Data Type Conversion48' */
  0.0F,                                /* '<S566>/Data Type Conversion9' */
  0.0F,                                /* '<S566>/Data Type Conversion32' */
  0.0F,                                /* '<S566>/Data Type Conversion31' */
  0.0F,                                /* '<S566>/Data Type Conversion47' */
  0.0F,                                /* '<S566>/Data Type Conversion50' */
  0.0F,                                /* '<S566>/Data Type Conversion52' */
  0.0F,                                /* '<S566>/Data Type Conversion53' */
  0.0F,                                /* '<S566>/Data Type Conversion12' */
  0.0F,                                /* '<S566>/Data Type Conversion19' */
  0.0F,                                /* '<S566>/Data Type Conversion20' */
  0.0F,                                /* '<S566>/Data Type Conversion24' */
  0.0F,                                /* '<S566>/Data Type Conversion25' */
  0.0F,                                /* '<S566>/Data Type Conversion55' */
  0.0F,                                /* '<S566>/Data Type Conversion54' */
  0.0F,                                /* '<S566>/Data Type Conversion34' */
  0.0F,                                /* '<S566>/Data Type Conversion33' */
  0.0F,                                /* '<S566>/Data Type Conversion35' */
  0.0F,                                /* '<S564>/Data Type Conversion3' */
  0.0F,                                /* '<S564>/Data Type Conversion13' */
  0.0F,                                /* '<S564>/Data Type Conversion2' */
  0.0F,                                /* '<S564>/Data Type Conversion4' */
  0.0F,                                /* '<S564>/Data Type Conversion6' */
  0.0F,                                /* '<S564>/Data Type Conversion22' */
  200918.0F,                           /* '<S2>/Version' */
  0.0F,                                /* '<S566>/Data Type Conversion23' */
  0.0F,                                /* '<S567>/Data Type Conversion38' */
  10.0F,                               /* '<S171>/Saturation' */
  0.1F,                                /* '<S171>/Divide2' */
  0.9F,                                /* '<S171>/Add2' */
  1.0F,                                /* '<S186>/Add3' */
  0U,                                  /* '<S9>/Cast To Single4' */
  0U,                                  /* '<S51>/Constant' */
  0U,                                  /* '<S9>/Cast To Single14' */
  0U,                                  /* '<S9>/Cast To Single15' */
  0U,                                  /* '<S574>/Constant17' */
  0U,                                  /* '<S574>/Constant18' */
  0U,                                  /* '<S574>/Constant19' */
  0U,                                  /* '<S574>/Constant20' */
  0U,                                  /* '<S574>/Constant21' */
  0U,                                  /* '<S575>/Constant1' */
  0U,                                  /* '<S575>/Constant2' */
  0U,                                  /* '<S575>/Constant3' */
  0U,                                  /* '<S575>/Constant4' */
  0U,                                  /* '<S575>/Constant5' */
  0U,                                  /* '<S575>/Constant6' */
  0U,                                  /* '<S575>/Constant7' */
  0U,                                  /* '<S575>/Constant8' */
  0U,                                  /* '<S575>/Constant9' */
  0,                                   /* '<S282>/Logical Operator2' */
  0,                                   /* '<S282>/Logical Operator3' */
  0                                    /* '<S518>/Compare' */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
