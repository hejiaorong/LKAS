/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.51
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Jan 25 08:43:07 2022
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S82>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S82>/LKA_State_Machine' */
#define LKAS_IN_Fault_i                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_j      ((uint8)0U)
#define LKAS_IN_Normal_p               ((uint8)2U)
#define LKAS_IN_SysOff_i               ((uint8)2U)
#define LKAS_IN_SysOn_h                ((uint8)3U)
#define LKAS_IN_Unavailable_h          ((uint8)1U)
#define LKAS_IN_Unselected_l           ((uint8)2U)

/* Named constants for Chart: '<S51>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Exported data definition */

/* Definition for custom storage class: Default */
float32 ob_LKA_Disable_Reason;
float32 ob_LKA_LKADeactvCSyn;
float32 ob_LKA_Version;

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * System initialize for enable system:
 *    '<S28>/Sum Condition1'
 *    '<S28>/Sum Condition2'
 *    '<S400>/Sum Condition1'
 */
void LKAS_SumCondition1_Init(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S39>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S28>/Sum Condition1'
 *    '<S28>/Sum Condition2'
 *    '<S400>/Sum Condition1'
 */
void LKAS_SumCondition1_Reset(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S39>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S28>/Sum Condition1'
 *    '<S28>/Sum Condition2'
 *    '<S400>/Sum Condition1'
 */
void LKAS_SumCondition1_Disable(boolean *rty_Out, DW_SumCondition1_LKAS_T
  *localDW)
{
  /* Outputs for Enabled SubSystem: '<S28>/Sum Condition1' incorporates:
   *  EnablePort: '<S39>/state = reset'
   */
  /* Disable for Outport: '<S39>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S28>/Sum Condition1' */
  localDW->SumCondition1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S28>/Sum Condition1'
 *    '<S28>/Sum Condition2'
 *    '<S400>/Sum Condition1'
 */
void LKAS_SumCondition1(boolean rtu_statereset, float32 rtu_SampleTime, float32
  rtu_Sum, boolean *rty_Out, DW_SumCondition1_LKAS_T *localDW)
{
  float32 rtb_Saturation_e;

  /* Outputs for Enabled SubSystem: '<S28>/Sum Condition1' incorporates:
   *  EnablePort: '<S39>/state = reset'
   */
  if (rtu_statereset) {
    if (!localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Reset(localDW);
      localDW->SumCondition1_MODE = true;
    }

    /* Sum: '<S39>/Add1' incorporates:
     *  Memory: '<S39>/Memory'
     */
    rtb_Saturation_e = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S39>/Saturation' */
    if (rtb_Saturation_e > 60.0F) {
      rtb_Saturation_e = 60.0F;
    } else {
      if (rtb_Saturation_e < 0.0F) {
        rtb_Saturation_e = 0.0F;
      }
    }

    /* End of Saturate: '<S39>/Saturation' */

    /* RelationalOperator: '<S39>/Relational Operator' */
    *rty_Out = (rtb_Saturation_e >= rtu_Sum);

    /* Update for Memory: '<S39>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_e;
  } else {
    if (localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S28>/Sum Condition1' */
}

/*
 * Output and update for action system:
 *    '<S84>/If Action Subsystem2'
 *    '<S123>/if action 4'
 *    '<S124>/if action 4'
 *    '<S125>/if action 4'
 *    '<S126>/if action 4'
 *    '<S137>/If Action Subsystem3'
 *    '<S138>/If Action Subsystem3'
 *    '<S139>/If Action Subsystem3'
 *    '<S147>/If Action Subsystem3'
 *    '<S172>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S87>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S87>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/* System initialize for atomic system: '<S98>/Moving Standard Deviation2' */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S106>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S106>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* System reset for atomic system: '<S98>/Moving Standard Deviation2' */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S106>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S106>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* Output and update for atomic system: '<S98>/Moving Standard Deviation2' */
void LKAS_MovingStandardDeviation2(float32 rtu_In1, float32 *rty_Out2, float32
  *rty_Out1, DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_ka;
  float32 rtb_Delay1_n;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_SumofElements;
  float32 rtb_TmpSignalConversionAtStanda[50];
  sint32 tmp;
  sint32 i;
  float32 rtb_Saturation_ao;

  /* Delay: '<S106>/Delay' */
  rtb_Delay_ka = localDW->Delay_DSTATE;

  /* Delay: '<S106>/Delay1' */
  rtb_Delay1_n = localDW->Delay1_DSTATE;

  /* Delay: '<S106>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S106>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S106>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S106>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S106>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S106>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S106>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S106>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S106>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S106>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S106>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S106>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S106>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S106>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S106>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S106>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S106>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S106>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S106>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S106>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S106>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S106>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S106>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S106>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S106>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S106>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S106>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S106>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S106>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S106>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S106>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S106>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S106>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S106>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S106>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S106>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S106>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S106>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S106>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S106>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S106>/Delay47' */
  rtb_SumofElements = localDW->Delay47_DSTATE;

  /* Delay: '<S106>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S106>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S106>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S106>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S106>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S106>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S106>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_ka;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_n;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_SumofElements;

  /* Sum: '<S106>/Sum of Elements' */
  tmp = 0;
  rtb_Saturation_ao = -0.0F;
  for (i = 0; i < 50; i++) {
    rtb_Saturation_ao += rtb_TmpSignalConversionAtStanda[i];
  }

  rtb_SumofElements = rtb_Saturation_ao;

  /* End of Sum: '<S106>/Sum of Elements' */

  /* Sum: '<S106>/Add2' incorporates:
   *  Constant: '<S106>/Constant'
   *  Memory: '<S106>/Memory3'
   */
  rtb_Saturation_ao = (float32)((uint8)(((uint32)((uint8)1U)) + ((uint32)((uint8)
    localDW->Memory3_PreviousInput))));

  /* Saturate: '<S106>/Saturation' */
  if (rtb_Saturation_ao > 50.0F) {
    rtb_Saturation_ao = 50.0F;
  } else {
    if (rtb_Saturation_ao < 1.0F) {
      rtb_Saturation_ao = 1.0F;
    }
  }

  /* End of Saturate: '<S106>/Saturation' */

  /* Product: '<S106>/Divide' */
  *rty_Out2 = rtb_SumofElements / rtb_Saturation_ao;

  /* S-Function (sdspstatfcns): '<S106>/Standard Deviation' incorporates:
   *  SignalConversion: '<S106>/TmpSignal ConversionAtStandard DeviationInport1'
   */
  while (tmp < 1) {
    localDW->StandardDeviation_AccVal = rtu_In1;
    localDW->StandardDeviation_SqData = rtu_In1 * rtu_In1;
    tmp = 1;
    for (i = 48; i >= 0; i--) {
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[tmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[tmp] *
        rtb_TmpSignalConversionAtStanda[tmp];
      tmp++;
    }

    *rty_Out1 = (localDW->StandardDeviation_SqData -
                 ((localDW->StandardDeviation_AccVal *
                   localDW->StandardDeviation_AccVal) / 50.0F)) / 49.0F;
    *rty_Out1 = sqrtf(fabsf(*rty_Out1));
    tmp = 1;
  }

  /* End of S-Function (sdspstatfcns): '<S106>/Standard Deviation' */

  /* Update for Delay: '<S106>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S106>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_ka;

  /* Update for Delay: '<S106>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S106>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S106>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S106>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S106>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S106>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S106>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S106>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S106>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S106>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S106>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_n;

  /* Update for Delay: '<S106>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S106>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S106>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S106>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S106>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S106>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S106>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S106>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S106>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S106>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S106>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S106>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S106>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S106>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S106>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S106>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S106>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S106>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S106>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S106>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S106>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S106>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S106>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S106>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S106>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S106>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S106>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S106>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S106>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S106>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S106>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S106>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S106>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S106>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S106>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S106>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;

  /* Update for Memory: '<S106>/Memory3' */
  localDW->Memory3_PreviousInput = rtb_Saturation_ao;
}

/*
 * System initialize for atomic system:
 *    '<S110>/Moving Standard Deviation1'
 *    '<S110>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation1_Init(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S112>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S110>/Moving Standard Deviation1'
 *    '<S110>/Moving Standard Deviation2'
 */
void MovingStandardDeviation1_Reset(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S112>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S112>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S110>/Moving Standard Deviation1'
 *    '<S110>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation1(float32 rtu_In1,
  DW_MovingStandardDeviation1_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_a;
  float32 rtb_Delay1_b;
  float32 rtb_Delay10_p;
  float32 rtb_Delay11_k;
  float32 rtb_Delay12_m;
  float32 rtb_Delay13_m;
  float32 rtb_Delay14_n;
  float32 rtb_Delay15_f;
  float32 rtb_Delay16_g;
  float32 rtb_Delay17_b;
  float32 rtb_Delay18_p;
  float32 rtb_Delay19_e;
  float32 rtb_Delay2_e;
  float32 rtb_Delay20_h;
  float32 rtb_Delay21_b;
  float32 rtb_Delay22_g;
  float32 rtb_Delay23_a;
  float32 rtb_Delay24_n;
  float32 rtb_Delay25_k;
  float32 rtb_Delay26_n;
  float32 rtb_Delay27_d;
  float32 rtb_Delay28_m;
  float32 rtb_Delay29_g;
  float32 rtb_Delay3_o;
  float32 rtb_Delay30_g;
  float32 rtb_Delay31_i;
  float32 rtb_Delay32_k;
  float32 rtb_Delay33_c;
  float32 rtb_Delay34_n;
  float32 rtb_Delay35_f;
  float32 rtb_Delay36_m;
  float32 rtb_Delay37_i;
  float32 rtb_Delay38_k;
  float32 rtb_Delay39_g;
  float32 rtb_Delay4_c;
  float32 rtb_Delay40_e;
  float32 rtb_Delay41_h;
  float32 rtb_Delay42_m;
  float32 rtb_Delay43_c;
  float32 rtb_Delay44_k;
  float32 rtb_Delay45_i;
  float32 rtb_Delay46_l;
  float32 rtb_Delay48_p;
  float32 rtb_Delay5_h;
  float32 rtb_Delay6_l;
  float32 rtb_Delay7_e;
  float32 rtb_Delay8_e;
  float32 rtb_Delay9_e;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S112>/Delay' */
  rtb_Delay_a = localDW->Delay_DSTATE;

  /* Delay: '<S112>/Delay1' */
  rtb_Delay1_b = localDW->Delay1_DSTATE;

  /* Delay: '<S112>/Delay10' */
  rtb_Delay10_p = localDW->Delay10_DSTATE;

  /* Delay: '<S112>/Delay11' */
  rtb_Delay11_k = localDW->Delay11_DSTATE;

  /* Delay: '<S112>/Delay12' */
  rtb_Delay12_m = localDW->Delay12_DSTATE;

  /* Delay: '<S112>/Delay13' */
  rtb_Delay13_m = localDW->Delay13_DSTATE;

  /* Delay: '<S112>/Delay14' */
  rtb_Delay14_n = localDW->Delay14_DSTATE;

  /* Delay: '<S112>/Delay15' */
  rtb_Delay15_f = localDW->Delay15_DSTATE;

  /* Delay: '<S112>/Delay16' */
  rtb_Delay16_g = localDW->Delay16_DSTATE;

  /* Delay: '<S112>/Delay17' */
  rtb_Delay17_b = localDW->Delay17_DSTATE;

  /* Delay: '<S112>/Delay18' */
  rtb_Delay18_p = localDW->Delay18_DSTATE;

  /* Delay: '<S112>/Delay19' */
  rtb_Delay19_e = localDW->Delay19_DSTATE;

  /* Delay: '<S112>/Delay2' */
  rtb_Delay2_e = localDW->Delay2_DSTATE;

  /* Delay: '<S112>/Delay20' */
  rtb_Delay20_h = localDW->Delay20_DSTATE;

  /* Delay: '<S112>/Delay21' */
  rtb_Delay21_b = localDW->Delay21_DSTATE;

  /* Delay: '<S112>/Delay22' */
  rtb_Delay22_g = localDW->Delay22_DSTATE;

  /* Delay: '<S112>/Delay23' */
  rtb_Delay23_a = localDW->Delay23_DSTATE;

  /* Delay: '<S112>/Delay24' */
  rtb_Delay24_n = localDW->Delay24_DSTATE;

  /* Delay: '<S112>/Delay25' */
  rtb_Delay25_k = localDW->Delay25_DSTATE;

  /* Delay: '<S112>/Delay26' */
  rtb_Delay26_n = localDW->Delay26_DSTATE;

  /* Delay: '<S112>/Delay27' */
  rtb_Delay27_d = localDW->Delay27_DSTATE;

  /* Delay: '<S112>/Delay28' */
  rtb_Delay28_m = localDW->Delay28_DSTATE;

  /* Delay: '<S112>/Delay29' */
  rtb_Delay29_g = localDW->Delay29_DSTATE;

  /* Delay: '<S112>/Delay3' */
  rtb_Delay3_o = localDW->Delay3_DSTATE;

  /* Delay: '<S112>/Delay30' */
  rtb_Delay30_g = localDW->Delay30_DSTATE;

  /* Delay: '<S112>/Delay31' */
  rtb_Delay31_i = localDW->Delay31_DSTATE;

  /* Delay: '<S112>/Delay32' */
  rtb_Delay32_k = localDW->Delay32_DSTATE;

  /* Delay: '<S112>/Delay33' */
  rtb_Delay33_c = localDW->Delay33_DSTATE;

  /* Delay: '<S112>/Delay34' */
  rtb_Delay34_n = localDW->Delay34_DSTATE;

  /* Delay: '<S112>/Delay35' */
  rtb_Delay35_f = localDW->Delay35_DSTATE;

  /* Delay: '<S112>/Delay36' */
  rtb_Delay36_m = localDW->Delay36_DSTATE;

  /* Delay: '<S112>/Delay37' */
  rtb_Delay37_i = localDW->Delay37_DSTATE;

  /* Delay: '<S112>/Delay38' */
  rtb_Delay38_k = localDW->Delay38_DSTATE;

  /* Delay: '<S112>/Delay39' */
  rtb_Delay39_g = localDW->Delay39_DSTATE;

  /* Delay: '<S112>/Delay4' */
  rtb_Delay4_c = localDW->Delay4_DSTATE;

  /* Delay: '<S112>/Delay40' */
  rtb_Delay40_e = localDW->Delay40_DSTATE;

  /* Delay: '<S112>/Delay41' */
  rtb_Delay41_h = localDW->Delay41_DSTATE;

  /* Delay: '<S112>/Delay42' */
  rtb_Delay42_m = localDW->Delay42_DSTATE;

  /* Delay: '<S112>/Delay43' */
  rtb_Delay43_c = localDW->Delay43_DSTATE;

  /* Delay: '<S112>/Delay44' */
  rtb_Delay44_k = localDW->Delay44_DSTATE;

  /* Delay: '<S112>/Delay45' */
  rtb_Delay45_i = localDW->Delay45_DSTATE;

  /* Delay: '<S112>/Delay46' */
  rtb_Delay46_l = localDW->Delay46_DSTATE;

  /* Delay: '<S112>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S112>/Delay48' */
  rtb_Delay48_p = localDW->Delay48_DSTATE;

  /* Delay: '<S112>/Delay5' */
  rtb_Delay5_h = localDW->Delay5_DSTATE;

  /* Delay: '<S112>/Delay6' */
  rtb_Delay6_l = localDW->Delay6_DSTATE;

  /* Delay: '<S112>/Delay7' */
  rtb_Delay7_e = localDW->Delay7_DSTATE;

  /* Delay: '<S112>/Delay8' */
  rtb_Delay8_e = localDW->Delay8_DSTATE;

  /* Delay: '<S112>/Delay9' */
  rtb_Delay9_e = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S112>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_a;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_b;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2_e;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3_o;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4_c;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5_h;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6_l;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7_e;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8_e;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9_e;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10_p;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11_k;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12_m;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13_m;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14_n;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15_f;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16_g;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17_b;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18_p;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28_m;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19_e;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20_h;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21_b;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22_g;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23_a;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24_n;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25_k;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26_n;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27_d;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38_k;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29_g;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30_g;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31_i;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32_k;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33_c;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34_n;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35_f;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36_m;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37_i;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48_p;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39_g;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40_e;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41_h;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42_m;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43_c;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44_k;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45_i;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46_l;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S112>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S112>/Standard Deviation' */

  /* Update for Delay: '<S112>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S112>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_a;

  /* Update for Delay: '<S112>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9_e;

  /* Update for Delay: '<S112>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10_p;

  /* Update for Delay: '<S112>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11_k;

  /* Update for Delay: '<S112>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12_m;

  /* Update for Delay: '<S112>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13_m;

  /* Update for Delay: '<S112>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14_n;

  /* Update for Delay: '<S112>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15_f;

  /* Update for Delay: '<S112>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16_g;

  /* Update for Delay: '<S112>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17_b;

  /* Update for Delay: '<S112>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28_m;

  /* Update for Delay: '<S112>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_b;

  /* Update for Delay: '<S112>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19_e;

  /* Update for Delay: '<S112>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20_h;

  /* Update for Delay: '<S112>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21_b;

  /* Update for Delay: '<S112>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22_g;

  /* Update for Delay: '<S112>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23_a;

  /* Update for Delay: '<S112>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24_n;

  /* Update for Delay: '<S112>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25_k;

  /* Update for Delay: '<S112>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26_n;

  /* Update for Delay: '<S112>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18_p;

  /* Update for Delay: '<S112>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38_k;

  /* Update for Delay: '<S112>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2_e;

  /* Update for Delay: '<S112>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29_g;

  /* Update for Delay: '<S112>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30_g;

  /* Update for Delay: '<S112>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31_i;

  /* Update for Delay: '<S112>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32_k;

  /* Update for Delay: '<S112>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33_c;

  /* Update for Delay: '<S112>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34_n;

  /* Update for Delay: '<S112>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35_f;

  /* Update for Delay: '<S112>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36_m;

  /* Update for Delay: '<S112>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27_d;

  /* Update for Delay: '<S112>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48_p;

  /* Update for Delay: '<S112>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3_o;

  /* Update for Delay: '<S112>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39_g;

  /* Update for Delay: '<S112>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40_e;

  /* Update for Delay: '<S112>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41_h;

  /* Update for Delay: '<S112>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42_m;

  /* Update for Delay: '<S112>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43_c;

  /* Update for Delay: '<S112>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44_k;

  /* Update for Delay: '<S112>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45_i;

  /* Update for Delay: '<S112>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46_l;

  /* Update for Delay: '<S112>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37_i;

  /* Update for Delay: '<S112>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4_c;

  /* Update for Delay: '<S112>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5_h;

  /* Update for Delay: '<S112>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6_l;

  /* Update for Delay: '<S112>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7_e;

  /* Update for Delay: '<S112>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8_e;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S110>/Sum Condition'
 *    '<S110>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S114>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S110>/Sum Condition'
 *    '<S110>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S114>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S110>/Sum Condition'
 *    '<S110>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S110>/Sum Condition' incorporates:
   *  EnablePort: '<S114>/Enable'
   */
  /* Disable for Outport: '<S114>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S110>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S110>/Sum Condition'
 *    '<S110>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_p;

  /* Outputs for Enabled SubSystem: '<S110>/Sum Condition' incorporates:
   *  EnablePort: '<S114>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S114>/Add1' incorporates:
     *  Memory: '<S114>/Memory'
     */
    rtb_Saturation_p = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S114>/Saturation' */
    if (rtb_Saturation_p > 100.0F) {
      rtb_Saturation_p = 100.0F;
    } else {
      if (rtb_Saturation_p < 0.0F) {
        rtb_Saturation_p = 0.0F;
      }
    }

    /* End of Saturate: '<S114>/Saturation' */

    /* RelationalOperator: '<S114>/Relational Operator' */
    *rty_Out = (rtb_Saturation_p >= rtu_In1);

    /* Update for Memory: '<S114>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_p;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S110>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S123>/if action 3'
 *    '<S124>/if action 3'
 *    '<S125>/if action 3'
 *    '<S126>/if action 3'
 *    '<S137>/If Action Subsystem2'
 *    '<S137>/If Action Subsystem1'
 *    '<S138>/If Action Subsystem2'
 *    '<S138>/If Action Subsystem1'
 *    '<S139>/If Action Subsystem2'
 *    '<S139>/If Action Subsystem1'
 *    ...
 */
void LKAS_ifaction3(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S129>/In1' */
  *rty_Out1 = rtu_In1;
}

/* System initialize for action system: '<S91>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculati_Init(void)
{
  /* InitializeConditions for Memory: '<S122>/Memory' */
  LKAS_DW.Memory_PreviousInput_gy = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory' */
  LKAS_DW.Memory_PreviousInput_n5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S123>/Memory' */
  LKAS_DW.Memory_PreviousInput_jz = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_l = 0.0F;

  /* InitializeConditions for Memory: '<S124>/Memory' */
  LKAS_DW.Memory_PreviousInput_ao = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S125>/Memory' */
  LKAS_DW.Memory_PreviousInput_ba = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_c = 0.0F;

  /* InitializeConditions for Memory: '<S126>/Memory' */
  LKAS_DW.Memory_PreviousInput_gz = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/* System reset for action system: '<S91>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculat_Reset(void)
{
  /* InitializeConditions for Memory: '<S122>/Memory' */
  LKAS_DW.Memory_PreviousInput_gy = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory' */
  LKAS_DW.Memory_PreviousInput_n5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S123>/Memory' */
  LKAS_DW.Memory_PreviousInput_jz = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_l = 0.0F;

  /* InitializeConditions for Memory: '<S124>/Memory' */
  LKAS_DW.Memory_PreviousInput_ao = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S125>/Memory' */
  LKAS_DW.Memory_PreviousInput_ba = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_c = 0.0F;

  /* InitializeConditions for Memory: '<S126>/Memory' */
  LKAS_DW.Memory_PreviousInput_gz = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/*
 * Output and update for action system: '<S91>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S91>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  /* local block i/o variables */
  float32 rtb_Memory1;
  float32 rtb_Memory2;
  float32 rtb_Memory3;
  float32 rtb_Memory4;
  float32 rtb_Merge1;
  float32 rtb_Merge1_o;
  float32 rtb_Merge1_c;
  float32 rtb_Merge1_d;
  float32 rtb_K1K2Det_dphi2PhSWAGrad2;
  float32 rtb_K1K2Det_stReplFlag;
  float32 rtb_K1K2Det_dphi1PhHdAgIni;
  float32 DelteSW0;
  float32 u;
  float32 Kw;
  float32 StpLngth;
  float32 Mode1Num;
  float32 Mode2Num;
  float32 D2_End;
  float32 DelteSW1;
  float32 K1;
  float32 K2_2;
  float32 T2;
  sint32 a;
  float32 K2;
  float32 c_T1;
  float32 c_T2;
  float32 K1_0;
  uint16 rtb_Add;
  uint16 rtb_Add_cc;
  uint16 rtb_Add_ea;
  uint16 rtb_Add_m;
  uint16 rtb_Add_h3;
  uint16 rtb_Merge;
  uint16 rtb_Add_n;

  /* Sum: '<S122>/Add' incorporates:
   *  Constant: '<S122>/Constant'
   *  Memory: '<S122>/Memory'
   */
  rtb_Add = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_gy));

  /* Saturate: '<S122>/Saturation1' */
  if (rtb_Add < ((uint16)100U)) {
    rtb_Merge = rtb_Add;
  } else {
    rtb_Merge = ((uint16)100U);
  }

  /* End of Saturate: '<S122>/Saturation1' */

  /* If: '<S122>/If' incorporates:
   *  Constant: '<S122>/Constant19'
   *  Inport: '<S127>/In1'
   *  Memory: '<S116>/Memory'
   */
  if (rtb_Merge == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S122>/if action 2' incorporates:
     *  ActionPort: '<S128>/Action Port'
     */
    /* SignalConversion: '<S128>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
     *  Constant: '<S128>/Constant'
     */
    rtb_Merge = ((uint16)0U);

    /* End of Outputs for SubSystem: '<S122>/if action 2' */
  } else {
    /* Outputs for IfAction SubSystem: '<S122>/if action 1' incorporates:
     *  ActionPort: '<S127>/Action Port'
     */
    rtb_Merge = LKAS_DW.Memory_PreviousInput_n5;

    /* End of Outputs for SubSystem: '<S122>/if action 1' */
  }

  /* End of If: '<S122>/If' */

  /* Sum: '<S123>/Add' incorporates:
   *  Constant: '<S123>/Constant'
   *  Memory: '<S123>/Memory'
   */
  rtb_Add_cc = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_jz));

  /* Memory: '<S116>/Memory1' */
  rtb_Memory1 = LKAS_DW.Memory1_PreviousInput_l;

  /* Saturate: '<S123>/Saturation1' */
  if (rtb_Add_cc < ((uint16)100U)) {
    rtb_Add_ea = rtb_Add_cc;
  } else {
    rtb_Add_ea = ((uint16)100U);
  }

  /* End of Saturate: '<S123>/Saturation1' */

  /* If: '<S123>/If' incorporates:
   *  Constant: '<S123>/Constant19'
   */
  if (rtb_Add_ea == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S123>/if action 4' incorporates:
     *  ActionPort: '<S130>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1);

    /* End of Outputs for SubSystem: '<S123>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S123>/if action 3' incorporates:
     *  ActionPort: '<S129>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory1, &rtb_Merge1);

    /* End of Outputs for SubSystem: '<S123>/if action 3' */
  }

  /* End of If: '<S123>/If' */

  /* Sum: '<S124>/Add' incorporates:
   *  Constant: '<S124>/Constant'
   *  Memory: '<S124>/Memory'
   */
  rtb_Add_ea = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_ao));

  /* Memory: '<S116>/Memory2' */
  rtb_Memory2 = LKAS_DW.Memory2_PreviousInput;

  /* Saturate: '<S124>/Saturation1' */
  if (rtb_Add_ea < ((uint16)100U)) {
    rtb_Add_m = rtb_Add_ea;
  } else {
    rtb_Add_m = ((uint16)100U);
  }

  /* End of Saturate: '<S124>/Saturation1' */

  /* If: '<S124>/If' incorporates:
   *  Constant: '<S124>/Constant19'
   */
  if (rtb_Add_m == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S124>/if action 4' incorporates:
     *  ActionPort: '<S132>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_o);

    /* End of Outputs for SubSystem: '<S124>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S124>/if action 3' incorporates:
     *  ActionPort: '<S131>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory2, &rtb_Merge1_o);

    /* End of Outputs for SubSystem: '<S124>/if action 3' */
  }

  /* End of If: '<S124>/If' */

  /* Sum: '<S125>/Add' incorporates:
   *  Constant: '<S125>/Constant'
   *  Memory: '<S125>/Memory'
   */
  rtb_Add_m = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_ba));

  /* Memory: '<S116>/Memory3' */
  rtb_Memory3 = LKAS_DW.Memory3_PreviousInput_c;

  /* Saturate: '<S125>/Saturation1' */
  if (rtb_Add_m < ((uint16)100U)) {
    rtb_Add_h3 = rtb_Add_m;
  } else {
    rtb_Add_h3 = ((uint16)100U);
  }

  /* End of Saturate: '<S125>/Saturation1' */

  /* If: '<S125>/If' incorporates:
   *  Constant: '<S125>/Constant19'
   */
  if (rtb_Add_h3 == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S125>/if action 4' incorporates:
     *  ActionPort: '<S134>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_c);

    /* End of Outputs for SubSystem: '<S125>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S125>/if action 3' incorporates:
     *  ActionPort: '<S133>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory3, &rtb_Merge1_c);

    /* End of Outputs for SubSystem: '<S125>/if action 3' */
  }

  /* End of If: '<S125>/If' */

  /* Sum: '<S126>/Add' incorporates:
   *  Constant: '<S126>/Constant'
   *  Memory: '<S126>/Memory'
   */
  rtb_Add_h3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_gz));

  /* Memory: '<S116>/Memory4' */
  rtb_Memory4 = LKAS_DW.Memory4_PreviousInput;

  /* Saturate: '<S126>/Saturation1' */
  if (rtb_Add_h3 < ((uint16)100U)) {
    rtb_Add_n = rtb_Add_h3;
  } else {
    rtb_Add_n = ((uint16)100U);
  }

  /* End of Saturate: '<S126>/Saturation1' */

  /* If: '<S126>/If' incorporates:
   *  Constant: '<S126>/Constant19'
   */
  if (rtb_Add_n == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S126>/if action 4' incorporates:
     *  ActionPort: '<S136>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_d);

    /* End of Outputs for SubSystem: '<S126>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S126>/if action 3' incorporates:
     *  ActionPort: '<S135>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory4, &rtb_Merge1_d);

    /* End of Outputs for SubSystem: '<S126>/if action 3' */
  }

  /* End of If: '<S126>/If' */

  /* MATLAB Function: '<S116>/MATLAB Function' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLAB Function': '<S121>:1' */
  /* '<S121>:1:55' LDDir = K1K2Det_stLDDir; */
  /* '<S121>:1:56' D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S121>:1:57' D2_des = K1K2Det_lDesDvt; */
  /* '<S121>:1:58' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_fp * 0.0174532924F;

  /* '<S121>:1:59' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S121>:1:60' TTLCHdAg = K1K2Det_phiTTLCHdAgIni; */
  /* '<S121>:1:61' Delte_Psi2 = K1K2Det_phi2PhDesHdAg; */
  /* '<S121>:1:62' Delte_Psi1Ini = K1K2Det_phi1PhDesHdAgIni; */
  /* '<S121>:1:63' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S121>:1:64' TTLCCrvt = K1K2Det_crPrvwTTLCCrvt; */
  /* '<S121>:1:65' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S121>:1:66' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S121>:1:67' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S121>:1:68' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_i / 3.6F;

  /* '<S121>:1:69' Kw=u/(L*(1+K*u*u)*i); */
  Kw = u / (((((LKAS_DW.StbFacm_SY * u) * u) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_m)
            * LKAS_DW.LKA_StrRatio_C_d);

  /*      DelteSW1 = single(0); */
  /* '<S121>:1:71' K1K2Det_stReplFlag = single(0); */
  rtb_K1K2Det_stReplFlag = 0.0F;

  /* '<S121>:1:72' StpLngth = K1K2Det_lStpLngth*(pi/180); */
  StpLngth = LKAS_DW.LL_lStpLngth_C_i * 0.0174532924F;

  /* '<S121>:1:73' ModeFlg = K1K2Det_bsTDivInfo_ModeFlg; */
  /* '<S121>:1:74' Mode1Num = K1K2Det_bsTDivInfo_Mode1Num; */
  Mode1Num = rtb_Merge1;

  /* '<S121>:1:75' Mode2Num = K1K2Det_bsTDivInfo_Mode2Num; */
  Mode2Num = rtb_Merge1_o;

  /* '<S121>:1:76' D2_End =  K1K2Det_bsTDivInfo_Ph2DvtEnd; */
  D2_End = rtb_Merge1_c;

  /* '<S121>:1:77' DelteSW1 = K1K2Det_bsTDivInfo_Ph2SWAIni; */
  DelteSW1 = rtb_Merge1_d;

  /* '<S121>:1:78' K1 = single(0); */
  K1 = 0.0F;

  /* '<S121>:1:79' K2_1 = single(0); */
  K2 = 0.0F;

  /* '<S121>:1:80' K2_2 = single(0); */
  K2_2 = 0.0F;

  /* '<S121>:1:81' KMax = K1K2Det_dphiSWARMax; */
  /* ************************************************************************** */
  /*  */
  /*  if (LDDir*PrvwHdAg < LDDir*TTLCHdAg) */
  /*      Delte_Psi1 = PrvwHdAg; */
  /*  else */
  /*      Delte_Psi1 = TTLCHdAg; */
  /*  end */
  /* '<S121>:1:89' Delte_Psi1 = PrvwHdAg; */
  /* '<S121>:1:90' if (ModeFlg == 0) */
  if (((sint32)rtb_Merge) == 0) {
    /* '<S121>:1:91' [K1,K2_1,K2_2,D2_End,DelteSW1]= func1(Delte_Psi1,TTLC,Kw,DelteSW0,Delte_Psi2,u,D1_Ini,Delte_Psi1Ini); */
    /*     ���ܣ� */
    /*     ��֪����ʼת����ת�ǣ�TTLC��һ����������Ǳ������뿪����ʱ����������� */
    /*     Լ����1��һ������ʱ����TTLCʱ��ʵ�������ĺ���Ǳ仯�� */
    /*           2����������ʱ��ת����ת��Ϊ�㣻 */
    /*           3����������ʱ��ʵ�������ĺ���ǵĺ���ǡ� */
    /*      */
    /*     ����� һ��ת����ת�Ǳ仯��K1������ת����ת�Ǳ仯��K2_1��K2_2����������ʱ��ƫ��������ֵD2 */
    /* ************************************************************************** */
    /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
    /*  end of function K1K2Det */
    /*  */
    /* ***************************************** */
    /*  1������func1�������������ʱ��ƫ��������ֵƫ����D2_0; */
    /*      */
    /*  2����D2_0<=D2_des������ú���func2�����������k1��k2_1��k2_2��ͬ���ڶ�������ʱ�� */
    /*     Ӧ��ͬʱʵ����������Ǻ�����ƫ������ */
    /*  3����D2_0>D2_des_max������ú���F,2�����������k1��k2_1��k2_2������k2_1 = k2_2�� */
    /*     �ڶ�������ʱ��Ӧ��ͬʱʵ����������Ǻ�����ƫ������ */
    /*  */
    /* '<S121>:1:168' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
    K1 = ((-2.0F * LKAS_DW.In_ko) / ((Kw * LKAS_DW.MPInP_tiTTLCIni) *
           LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F * DelteSW0) /
      LKAS_DW.MPInP_tiTTLCIni);

    /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
    /* '<S121>:1:171' DelteSW1 = DelteSW0+K1*TTLC; */
    DelteSW1 = (K1 * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

    /* '<S121>:1:172' Delte_Psi = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1)*TTLC*Kw; */
    D2_End = ((((DelteSW0 + DelteSW1) * 0.5F) * LKAS_DW.MPInP_tiTTLCIni) * Kw) +
      LKAS_DW.In_k;

    /* ����Լ��2��3���������K2�� */
    /* '<S121>:1:174' K2 = -DelteSW1*DelteSW1*Kw/(2*(Delte_Psi2-Delte_Psi)); */
    K2 = (((-DelteSW1) * DelteSW1) * Kw) / ((LKAS_DW.In_b - D2_End) * 2.0F);

    /* ����K2��DelteSW1�ͳ��٣����Լ��������������ƫ�����ı仯��D2�Ͷ�������ʱ��T2�� */
    /* '<S121>:1:176' T1 = (DelteSW1-DelteSW0)/K1; */
    c_T1 = (DelteSW1 - DelteSW0) / K1;

    /* '<S121>:1:177' T2 = (0-DelteSW1)/K2; */
    c_T2 = (0.0F - DelteSW1) / K2;

    /*      D1 = u*((1/6)*Kw*(2*DelteSW0+DelteSW1)*T1^2+Delte_Psi1*T1); */
    /*      D2 = u*((1/3)*Kw*T2^2*DelteSW1); */
    /* '<S121>:1:180' D1 = u*((1/6)*Kw*(DelteSW1+2*DelteSW0)*T1*T1+Delte_Psi1Ini*T1); */
    /* '<S121>:1:181' D2 = u*((1/3)*Kw*T2*T2*DelteSW1+Delte_Psi*T2); */
    /* '<S121>:1:182' D2_End = D1+D2; */
    /*  */
    /* ************************************************************************** */
    /* ����� */
    /*    K1 = K1; */
    /* '<S121>:1:187' K2_1 = K2; */
    /* '<S121>:1:188' K2_2 = K2; */
    K2_2 = K2;
    D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) * c_T1) *
                c_T1) + (LKAS_DW.In_k * c_T1)) * u) + ((((((0.333333343F * Kw) *
      c_T2) * c_T2) * DelteSW1) + (D2_End * c_T2)) * u);
  }

  /* '<S121>:1:93' if(0< D2_End*LDDir && D2_End*LDDir <= D2_des && ModeFlg == 0) */
  c_T1 = D2_End * LKAS_DW.Merge;
  if (((0.0F < c_T1) && (c_T1 <= LKAS_DW.LL_DesDvt_C_b)) && (((sint32)rtb_Merge)
       == 0)) {
    /* '<S121>:1:95' K1K2Det_stReplFlag = single(0); */
    rtb_K1K2Det_stReplFlag = 0.0F;
  } else {
    if ((c_T1 > LKAS_DW.LL_DesDvt_C_b) || (((sint32)rtb_Merge) != 0)) {
      /* '<S121>:1:97' elseif(D2_End*LDDir > D2_des || ModeFlg ~= 0 ) */
      /* '<S121>:1:99' K1K2Det_stReplFlag = single(1); */
      rtb_K1K2Det_stReplFlag = 1.0F;

      /* '<S121>:1:101' for a = 1:8 */
      for (a = 0; a < 8; a++) {
        /* '<S121>:1:103' if (D2_End*LDDir>D2_des && ModeFlg==0) */
        c_T1 = D2_End * LKAS_DW.Merge;
        if ((c_T1 > LKAS_DW.LL_DesDvt_C_b) && (((sint32)rtb_Merge) == 0)) {
          /* '<S121>:1:104' ModeFlg = uint16(1); */
          rtb_Merge = 1U;
        }

        /* '<S121>:1:106' if (D2_End*LDDir>D2_des && ModeFlg==1) */
        if ((c_T1 > LKAS_DW.LL_DesDvt_C_b) && (((sint32)rtb_Merge) == 1)) {
          /* '<S121>:1:107' DelteSW1 =  LDDir*StpLngth+DelteSW1; */
          DelteSW1 += LKAS_DW.Merge * StpLngth;

          /* '<S121>:1:108' Mode1Num = Mode1Num+1; */
          Mode1Num++;
        }

        /* '<S121>:1:110' if (D2_End*LDDir <= D2_des && ModeFlg==1) */
        if ((c_T1 <= LKAS_DW.LL_DesDvt_C_b) && (((sint32)rtb_Merge) == 1)) {
          /* '<S121>:1:111' ModeFlg = uint16(2); */
          rtb_Merge = 2U;
        }

        /* '<S121>:1:113' if (D2_End*LDDir<D2_des && ModeFlg==2) */
        if ((c_T1 < LKAS_DW.LL_DesDvt_C_b) && (((sint32)rtb_Merge) == 2)) {
          /* '<S121>:1:114' DelteSW1 =  DelteSW1-LDDir*StpLngth*((1/2)^(Mode2Num+1)); */
          DelteSW1 -= (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);

          /* '<S121>:1:115' Mode2Num = Mode2Num+1; */
          Mode2Num++;
        }

        /* '<S121>:1:117' if (D2_End*LDDir>=D2_des && ModeFlg==2) */
        if ((c_T1 >= LKAS_DW.LL_DesDvt_C_b) && (((sint32)rtb_Merge) == 2)) {
          /* '<S121>:1:118' DelteSW1 =  DelteSW1+LDDir*StpLngth*((1/2)^(Mode2Num+1)); */
          DelteSW1 += (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);

          /* '<S121>:1:119' Mode2Num = Mode2Num+1; */
          Mode2Num++;
        }

        /* '<S121>:1:121' [T1,T2,D2_End] = func3(Delte_Psi1Ini,Delte_Psi2,DelteSW1,KMax,Delte_Psi1,... */
        /* '<S121>:1:122'                                 DelteSW0,u,Kw,LDDir); */
        /*     ���ܣ� */
        /*     ��֪������һ��ʱ��ʼ����ǣ��뿪����ʱ����������ǣ�����һ��ʱ��ƫ�����ĳ�ʼֵ */
        /*           �������ʱ��ת����ת�ǳ�ʼֵ����ʼת����ת�ǣ����١� */
        /*     ���裺1������һ������ʱ��ת����ת�ǣ�ʵ��һ���������ĺ���Ǳ仯�� */
        /*           2������һ������ʱ��ת����ת�ǣ�ʵ�ֶ����������ĺ���Ǳ仯�� */
        /*           3������ʵ��һ���������ĺ���Ǳ仯����������һ��ƫ�����仯��D1�� */
        /*           4������ʵ�ֶ����������ĺ���Ǳ仯���������Ķ���ƫ�����仯��D2�� */
        /*           5) ���ݽ���һ��ʱ��ƫ�����ĳ�ʼֵ��D1��D2���õ���������ʱ��ƫ����D2_End */
        /*      */
        /*     ����� һ��ʹ��ʱ��T1������ʹ��ʱ��T2����������ʱ��ƫ����D2_End */
        /* ************************************************************************** */
        /*  end of function func1 */
        /*  function [K1,K2_1,K2_2,DelteSW1]= func2(Delte_Psi1,Delte_Psi2,D1_Ini,T1,... */
        /*                                          D2_des,LDDir,DelteSW0,u,Kw) */
        /*  %    ���ܣ� */
        /*  %    ��֪��һ����������Ǳ仯�����뿪����ʱ����������ǣ���������ʱ������ƫ�����ľ���ֵ */
        /*  %          �����ĳ���ƫ��ķ��򣬳�ʼת����ת�ǣ����١� */
        /*  %    Լ����1������һ������ʱ��ת����ת�ǣ�ʵ�������ĺ���Ǳ仯�� */
        /*  %          2����������ʱ��ƫ����ʵ������ƫ������ */
        /*  %          3����������ʱ��ʵ�������ĺ���ǵĺ���ǣ� */
        /*  %          4����������ʱ��ת����ת��Ϊ�㡣 */
        /*  %     */
        /*  %    ����� һ��ת����ת�Ǳ仯��K1������ת����ת�Ǳ仯��K2_1��K2_2�� */
        /*  %           �������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
        /*  %************************************************************************** */
        /*  %   ����Լ��2��3��4���������DelteSW1�Ͷ���ת����ת�Ǳ仯�ʡ� */
        /*  Delte_D = LDDir*D2_des-D1_Ini; */
        /*  Delte_Psi = Delte_Psi2-Delte_Psi1; */
        /*  DelteSW1 = ((4/3)*(Delte_Psi/Kw)*(Delte_Psi/Kw)-(1/3)*(Delte_Psi/Kw)*DelteSW0*T1-(1/6)*DelteSW0*DelteSW0*T1*T1... */
        /*              +2*(Delte_Psi/Kw)*Delte_Psi1-Delte_Psi1*DelteSW0*T1)/(Delte_D/(Kw*u)+(1/3)*(Delte_Psi/Kw)*T1); */
        /*  T2 = (2*(Delte_Psi/Kw)-(DelteSW1+DelteSW0)*T1)/DelteSW1; */
        /*  K2 = -DelteSW1/T2; */
        /*  %   ����Լ��1�ͽ������ʱ��ת����ת�ǳ�ʼֵDelteSW1���������һ��ת����ת�Ǳ仯�ʡ� */
        /*  K1 = (DelteSW1-DelteSW0)/T1; */
        /*  % */
        /*  %************************************************************************** */
        /*  %   ����� */
        /*  K2_1 = K2; */
        /*  K2_2 = K2; */
        /*   */
        /*  end % end of function func1 */
        /* '<S121>:1:233' K1_0 = (DelteSW1*DelteSW1-DelteSW0*DelteSW0)*Kw/(-2*Delte_Psi1); */
        K1_0 = (((DelteSW1 * DelteSW1) - (DelteSW0 * DelteSW0)) * Kw) / (-2.0F *
          LKAS_DW.In_ko);

        /* '<S121>:1:234' if (LDDir*K1_0 > KMax) */
        if ((LKAS_DW.Merge * K1_0) > LKAS_DW.SWARmax) {
          /* '<S121>:1:235' K1_1 = single(LDDir*KMax); */
          K1_0 = LKAS_DW.Merge * LKAS_DW.SWARmax;
        } else {
          /* '<S121>:1:236' else */
          /* '<S121>:1:237' K1_1 = K1_0; */
        }

        /*  */
        /* '<S121>:1:240' T1 = (DelteSW1-DelteSW0)/K1_1; */
        K1_0 = (DelteSW1 - DelteSW0) / K1_0;

        /* '<S121>:1:243' Delte_Psi = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1)*T1*Kw; */
        K1 = ((((DelteSW0 + DelteSW1) * 0.5F) * K1_0) * Kw) + LKAS_DW.In_k;

        /*  DelteSW1_0 = 2*(Delte_Psi2-Delte_Psi1Ini)/(T1*Kw)-DelteSW0; */
        /*  if (-1*Delte_Psi >= -1*Delte_Psi2) */
        /*     DelteSW1_1 = DelteSW1_0; */
        /*  else */
        /*     DelteSW1_1 = DelteSW1; */
        /*  end */
        /*  Delte_Psi_1 = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1_1)*T1*Kw; */
        /* '<S121>:1:251' T2 = 2*(Delte_Psi2-Delte_Psi)/(DelteSW1*Kw); */
        T2 = ((LKAS_DW.In_b - K1) * 2.0F) / (DelteSW1 * Kw);

        /*      T1 = 2*(Delte_Psi-Delte_Psi1)/((DelteSW0+DelteSW1)*Kw); */
        /*      T1 = TTLC; */
        /*      T2 = 2*(Delte_Psi2-Delte_Psi)/(DelteSW1*Kw); */
        /* '<S121>:1:256' D1 = u*((1/6)*Kw*(DelteSW1+2*DelteSW0)*T1*T1+Delte_Psi1Ini*T1); */
        /* '<S121>:1:257' D2 = u*((1/3)*Kw*T2*T2*DelteSW1+Delte_Psi*T2); */
        /* '<S121>:1:258' D2_End = D2+D1; */
        D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) *
                     K1_0) * K1_0) + (LKAS_DW.In_k * K1_0)) * u) +
          ((((((0.333333343F * Kw) * T2) * T2) * DelteSW1) + (K1 * T2)) * u);
      }

      /* '<S121>:1:124' K1 = (DelteSW1-DelteSW0)/T1; */
      K1 = (DelteSW1 - DelteSW0) / K1_0;

      /* '<S121>:1:125' K2_1 = (0-DelteSW1)/T2; */
      K2 = (0.0F - DelteSW1) / T2;

      /* '<S121>:1:126' K2_2 = K2_1; */
      K2_2 = K2;
    }
  }

  /*  */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S121>:1:130' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S121>:1:132' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = K1 * 57.2957802F;

  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /* '<S121>:1:134' K1K2Det_dphi2PhSWAGrad1 = K2_1*(180/pi); */
  LKAS_DW.K1K2Det_dphi2PhSWAGrad1 = K2 * 57.2957802F;

  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /* '<S121>:1:136' K1K2Det_dphi2PhSWAGrad2 = K2_2*(180/pi); */
  rtb_K1K2Det_dphi2PhSWAGrad2 = K2_2 * 57.2957802F;

  /*  */
  /* '<S121>:1:138' K1K2Det_dphi1PhHdAgIni = Delte_Psi1; */
  rtb_K1K2Det_dphi1PhHdAgIni = LKAS_DW.In_ko;

  /* Update for Memory: '<S122>/Memory' */
  /*  */
  /* '<S121>:1:140' K1K2Det_bsTDivInfoOut_ModeFlg = ModeFlg; */
  /* '<S121>:1:141' K1K2Det_bsTDivInfoOut_Mode1Num = Mode1Num; */
  /* '<S121>:1:142' K1K2Det_bsTDivInfoOut_Mode2Num = Mode2Num; */
  /* '<S121>:1:143' K1K2Det_bsTDivInfoOut_Ph2DvtEnd = D2_End; */
  /* '<S121>:1:144' K1K2Det_bsTDivInfoOut_Ph2SWAIni = DelteSW1; */
  LKAS_DW.Memory_PreviousInput_gy = rtb_Add;

  /* Update for Memory: '<S116>/Memory' incorporates:
   *  MATLAB Function: '<S116>/MATLAB Function'
   */
  LKAS_DW.Memory_PreviousInput_n5 = rtb_Merge;

  /* Update for Memory: '<S123>/Memory' */
  LKAS_DW.Memory_PreviousInput_jz = rtb_Add_cc;

  /* Update for Memory: '<S116>/Memory1' incorporates:
   *  MATLAB Function: '<S116>/MATLAB Function'
   */
  LKAS_DW.Memory1_PreviousInput_l = Mode1Num;

  /* Update for Memory: '<S124>/Memory' */
  LKAS_DW.Memory_PreviousInput_ao = rtb_Add_ea;

  /* Update for Memory: '<S116>/Memory2' incorporates:
   *  MATLAB Function: '<S116>/MATLAB Function'
   */
  LKAS_DW.Memory2_PreviousInput = Mode2Num;

  /* Update for Memory: '<S125>/Memory' */
  LKAS_DW.Memory_PreviousInput_ba = rtb_Add_m;

  /* Update for Memory: '<S116>/Memory3' incorporates:
   *  MATLAB Function: '<S116>/MATLAB Function'
   */
  LKAS_DW.Memory3_PreviousInput_c = D2_End;

  /* Update for Memory: '<S126>/Memory' */
  LKAS_DW.Memory_PreviousInput_gz = rtb_Add_h3;

  /* Update for Memory: '<S116>/Memory4' incorporates:
   *  MATLAB Function: '<S116>/MATLAB Function'
   */
  LKAS_DW.Memory4_PreviousInput = DelteSW1;
}

/*
 * Output and update for action system:
 *    '<S140>/if action '
 *    '<S141>/if action '
 *    '<S142>/if action '
 *    '<S143>/if action '
 *    '<S144>/if action '
 *    '<S145>/if action '
 *    '<S146>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S157>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S172>/If Action Subsystem'
 *    '<S172>/If Action Subsystem4'
 *    '<S120>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S174>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for atomic system:
 *    '<S182>/Saturable Gain Lut (SatGainLut)'
 *    '<S182>/Saturable Gain Lut (SatGainLut)1'
 */
void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32 rtu_InputLimLwr,
  float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32 rtu_GainLimUpr,
  float32 *rty_Gain)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S185>:1' */
  /*  Function Name: Saturable Gain Lut */
  /*  */
  /*  Description:  */
  /*    Saturable Gain Lookup Table. */
  /*  */
  /*  Assumptions and Limitation: */
  /*    The data type of all inputs and output is single. */
  /*  */
  /*  Inputs: */
  /*    Input: */
  /*    InputLimLwr: */
  /*    InputLimUpr: */
  /*    GainLimLwr: */
  /*    GainLimUpr: */
  /*  */
  /*  Outputs: */
  /*    Gain: The result of Looking up table. */
  /*  $Revision: 1.0$ */
  /*  $Author: Zhang Jianwei$ */
  /*  $Date: January 27, 2019$ */
  /*  ________________________________________ */
  /* '<S185>:1:25' if Input <= InputLimLwr */
  if (rtu_Input <= rtu_InputLimLwr) {
    /* '<S185>:1:26' Gain = GainLimLwr; */
    *rty_Gain = rtu_GainLimLwr;
  } else if (rtu_Input >= rtu_InputLimUpr) {
    /* '<S185>:1:27' elseif Input >= InputLimUpr */
    /* '<S185>:1:28' Gain = GainLimUpr; */
    *rty_Gain = rtu_GainLimUpr;
  } else {
    /* '<S185>:1:29' else */
    /* '<S185>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
    /* '<S185>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
    *rty_Gain = (((rtu_Input - rtu_InputLimLwr) / (rtu_InputLimUpr -
      rtu_InputLimLwr)) * (rtu_GainLimUpr - rtu_GainLimLwr)) + rtu_GainLimLwr;
  }
}

/*
 * Output and update for action system:
 *    '<S189>/If Action Subsystem'
 *    '<S189>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_a(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S191>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S212>/if action '
 *    '<S213>/if action '
 *    '<S220>/if action '
 *    '<S221>/if action '
 */
void LKAS_ifaction_i(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S214>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S205>/If Action Subsystem'
 *    '<S206>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_f(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_h_T *localDW)
{
  uint16 rtb_Saturation1_i;
  uint16 rtb_Saturation1_j;

  /* Outputs for Enabled SubSystem: '<S205>/If Action Subsystem' incorporates:
   *  EnablePort: '<S210>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S212>/Add' incorporates:
     *  Constant: '<S212>/Constant'
     *  Memory: '<S212>/Memory'
     */
    rtb_Saturation1_i = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S212>/Saturation1' */
    if (rtb_Saturation1_i >= ((uint16)10000U)) {
      rtb_Saturation1_i = ((uint16)10000U);
    }

    /* End of Saturate: '<S212>/Saturation1' */

    /* If: '<S212>/If' incorporates:
     *  Constant: '<S212>/Constant2'
     */
    if (rtb_Saturation1_i <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S212>/if action ' incorporates:
       *  ActionPort: '<S214>/Action Port'
       */
      LKAS_ifaction_i(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S212>/if action ' */
    }

    /* End of If: '<S212>/If' */

    /* Sum: '<S213>/Add' incorporates:
     *  Constant: '<S213>/Constant'
     *  Memory: '<S213>/Memory'
     */
    rtb_Saturation1_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_p));

    /* Saturate: '<S213>/Saturation1' */
    if (rtb_Saturation1_j >= ((uint16)10000U)) {
      rtb_Saturation1_j = ((uint16)10000U);
    }

    /* End of Saturate: '<S213>/Saturation1' */

    /* If: '<S213>/If' incorporates:
     *  Constant: '<S213>/Constant2'
     */
    if (rtb_Saturation1_j == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S213>/if action ' incorporates:
       *  ActionPort: '<S215>/Action Port'
       */
      LKAS_ifaction_i(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S213>/if action ' */
    }

    /* End of If: '<S213>/If' */

    /* Update for Memory: '<S212>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_i;

    /* Update for Memory: '<S213>/Memory' */
    localDW->Memory_PreviousInput_p = rtb_Saturation1_j;
  }

  /* End of Outputs for SubSystem: '<S205>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S205>/If Action Subsystem2'
 *    '<S206>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_e(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S211>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S211>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S82>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_c = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c31_LKAS = 0U;
  LKAS_DW.is_c31_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.LDWSM_stLDWActvFlg = 0U;
  LKAS_DW.LDWSM_stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S82>/LDW_State_Machine'
 * Block description for: '<S82>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S82>/LDW_State_Machine'
   *
   * Block description for '<S82>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c31_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c31_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S271>:2' */
    LKAS_DW.is_c31_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S271>:1' */
    /* Transition: '<S271>:31' */
    LKAS_DW.is_SysOff_c = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S271>:30' */
    LKAS_DW.LDWSM_stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c31_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S271>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)
             LKAS_DW.LKA_Mode) == 2))) {
        /* Transition: '<S271>:38' */
        /* Exit Internal 'Fault': '<S271>:36' */
        LKAS_DW.is_c31_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S271>:3' */
        /* Transition: '<S271>:77' */
        LKAS_DW.is_SysOn_a = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S271>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 0) && tmp) {
        /* Transition: '<S271>:40' */
        /* Exit Internal 'Fault': '<S271>:36' */
        LKAS_DW.is_c31_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_c = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S271>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else {
        LKAS_DW.LDWSM_stLDWState = 6U;

        /* During 'LDWFault': '<S271>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S271>:1' */
      if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
          && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S271>:39' */
        /* Exit Internal 'SysOff': '<S271>:1' */
        LKAS_DW.is_SysOff_c = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c31_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S271>:36' */
        /* Transition: '<S271>:75' */
        /* Entry 'LDWFault': '<S271>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
                  == 2)) {
        /* Transition: '<S271>:41' */
        /* Exit Internal 'SysOff': '<S271>:1' */
        LKAS_DW.is_SysOff_c = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c31_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S271>:3' */
        /* Transition: '<S271>:77' */
        LKAS_DW.is_SysOn_a = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S271>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_c) == LKAS_IN_Unavailable) {
        LKAS_DW.LDWSM_stLDWState = 0U;

        /* During 'Unavailable': '<S271>:30' */
        if (((sint32)LKAS_DW.LKA_Mode) == 0) {
          /* Transition: '<S271>:35' */
          LKAS_DW.is_SysOff_c = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S271>:32' */
          LKAS_DW.LDWSM_stLDWState = 1U;
        }
      } else {
        LKAS_DW.LDWSM_stLDWState = 1U;

        /* During 'Unselected': '<S271>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S271>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S271>:37' */
        /* Exit Internal 'SysOn': '<S271>:3' */
        if (((uint32)LKAS_DW.is_SysOn_a) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S271>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S271>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S271>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c31_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S271>:36' */
        /* Transition: '<S271>:75' */
        /* Entry 'LDWFault': '<S271>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) != 1) && (((sint32)LKAS_DW.LKA_Mode)
                  != 2)) {
        /* Transition: '<S271>:42' */
        /* Exit Internal 'SysOn': '<S271>:3' */
        if (((uint32)LKAS_DW.is_SysOn_a) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S271>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S271>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S271>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c31_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_c = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S271>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_a) == LKAS_IN_LDWSelected) {
        LKAS_DW.LDWSM_stLDWState = 2U;

        /* During 'LDWSelected': '<S271>:47' */
        if ((LKAS_DW.Merge_e) && (!LKAS_DW.Merge1_i)) {
          /* Transition: '<S271>:50' */
          LKAS_DW.is_SysOn_a = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S271>:102' */
          /* Transition: '<S271>:113' */
          LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S271>:112' */
          LKAS_DW.LDWSM_stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S271>:102' */
        if (LKAS_DW.Merge1_i) {
          /* Transition: '<S271>:44' */
          /* Exit Internal 'Normal': '<S271>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S271>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S271>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_a = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S271>:47' */
          LKAS_DW.LDWSM_stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.LDWSM_stLDWState = 3U;

            /* During 'LDWEnable': '<S271>:112' */
            if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_a)) {
              /* Transition: '<S271>:118' */
              LKAS_DW.is_Normal_i = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S271>:114' */
              LKAS_DW.LDWSM_stLDWState = 4U;
              LKAS_DW.LDWSM_stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_a))
              {
                /* Transition: '<S271>:119' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S271>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.LDWSM_stLDWState = 4U;

            /* During 'LDWLeftActive': '<S271>:114' */
            if (LKAS_DW.Merge_a) {
              /* Transition: '<S271>:116' */
              /* Exit 'LDWLeftActive': '<S271>:114' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S271>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_a))
              {
                /* Transition: '<S271>:120' */
                /* Exit 'LDWLeftActive': '<S271>:114' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S271>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LDWSM_stLDWState = 5U;

            /* During 'LDWRightActive': '<S271>:115' */
            if (LKAS_DW.Merge_a) {
              /* Transition: '<S271>:117' */
              /* Exit 'LDWRightActive': '<S271>:115' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S271>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_a))
              {
                /* Transition: '<S271>:121' */
                /* Exit 'LDWRightActive': '<S271>:115' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S271>:114' */
                LKAS_DW.LDWSM_stLDWState = 4U;
                LKAS_DW.LDWSM_stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S82>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S82>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_active_c32_LKAS = 0U;
  LKAS_DW.is_c32_LKAS = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.LKASM_stLKAActvFlg = 0U;
  LKAS_DW.LKASM_stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S82>/LKA_State_Machine'
 * Block description for: '<S82>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S82>/LKA_State_Machine'
   *
   * Block description for '<S82>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  if (((uint32)LKAS_DW.is_active_c32_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    LKAS_DW.is_active_c32_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    /* Transition: '<S272>:2' */
    LKAS_DW.is_c32_LKAS = LKAS_IN_SysOff_i;

    /* Entry Internal 'SysOff': '<S272>:1' */
    /* Transition: '<S272>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_h;

    /* Entry 'Unavailable': '<S272>:30' */
    LKAS_DW.LKASM_stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c32_LKAS) {
     case LKAS_IN_Fault_i:
      /* During 'Fault': '<S272>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.LKA_Mode) == 2)) {
        /* Transition: '<S272>:38' */
        /* Exit Internal 'Fault': '<S272>:36' */
        LKAS_DW.is_c32_LKAS = LKAS_IN_SysOn_h;

        /* Entry Internal 'SysOn': '<S272>:3' */
        /* Transition: '<S272>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S272>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)
                    LKAS_DW.LKA_Mode) == 1)) && tmp) {
        /* Transition: '<S272>:40' */
        /* Exit Internal 'Fault': '<S272>:36' */
        LKAS_DW.is_c32_LKAS = LKAS_IN_SysOff_i;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_l;

        /* Entry 'Unselected': '<S272>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else {
        LKAS_DW.LKASM_stLKAState = 6U;

        /* During 'LKAFault': '<S272>:72' */
      }
      break;

     case LKAS_IN_SysOff_i:
      /* During 'SysOff': '<S272>:1' */
      if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S272>:39' */
        /* Exit Internal 'SysOff': '<S272>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
        LKAS_DW.is_c32_LKAS = LKAS_IN_Fault_i;

        /* Entry Internal 'Fault': '<S272>:36' */
        /* Transition: '<S272>:74' */
        /* Entry 'LKAFault': '<S272>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode) == 2) {
        /* Transition: '<S272>:41' */
        /* Exit Internal 'SysOff': '<S272>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
        LKAS_DW.is_c32_LKAS = LKAS_IN_SysOn_h;

        /* Entry Internal 'SysOn': '<S272>:3' */
        /* Transition: '<S272>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S272>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_h) {
        LKAS_DW.LKASM_stLKAState = 0U;

        /* During 'Unavailable': '<S272>:30' */
        if ((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)LKAS_DW.LKA_Mode) ==
             1)) {
          /* Transition: '<S272>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_l;

          /* Entry 'Unselected': '<S272>:32' */
          LKAS_DW.LKASM_stLKAState = 1U;
        }
      } else {
        LKAS_DW.LKASM_stLKAState = 1U;

        /* During 'Unselected': '<S272>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S272>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S272>:37' */
        /* Exit Internal 'SysOn': '<S272>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_p) {
          /* Exit Internal 'Normal': '<S272>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S272>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S272>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        }

        LKAS_DW.is_c32_LKAS = LKAS_IN_Fault_i;

        /* Entry Internal 'Fault': '<S272>:36' */
        /* Transition: '<S272>:74' */
        /* Entry 'LKAFault': '<S272>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode) != 2) {
        /* Transition: '<S272>:42' */
        /* Exit Internal 'SysOn': '<S272>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_p) {
          /* Exit Internal 'Normal': '<S272>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S272>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S272>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        }

        LKAS_DW.is_c32_LKAS = LKAS_IN_SysOff_i;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_l;

        /* Entry 'Unselected': '<S272>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.LKASM_stLKAState = 2U;

        /* During 'LKASelected': '<S272>:19' */
        if ((LKAS_DW.Merge1_a) && (!LKAS_DW.Merge2)) {
          /* Transition: '<S272>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_p;

          /* Entry Internal 'Normal': '<S272>:102' */
          /* Transition: '<S272>:103' */
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S272>:108' */
          LKAS_DW.LKASM_stLKAState = 3U;
        }
      } else {
        /* During 'Normal': '<S272>:102' */
        if (LKAS_DW.Merge2) {
          /* Transition: '<S272>:25' */
          /* Exit Internal 'Normal': '<S272>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S272>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S272>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

          /* Entry 'LKASelected': '<S272>:19' */
          LKAS_DW.LKASM_stLKAState = 2U;
        } else {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKAEnable:
            LKAS_DW.LKASM_stLKAState = 3U;

            /* During 'LKAEnable': '<S272>:108' */
            if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_c)) {
              /* Transition: '<S272>:105' */
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

              /* Entry 'LKALeftActive': '<S272>:109' */
              LKAS_DW.LKASM_stLKAState = 4U;
              LKAS_DW.LKASM_stLKAActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S272>:104' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S272>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LKALeftActive:
            LKAS_DW.LKASM_stLKAState = 4U;

            /* During 'LKALeftActive': '<S272>:109' */
            if (LKAS_DW.Merge1_c) {
              /* Transition: '<S272>:106' */
              /* Exit 'LKALeftActive': '<S272>:109' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S272>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S272>:111' */
                /* Exit 'LKALeftActive': '<S272>:109' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S272>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LKASM_stLKAState = 5U;

            /* During 'LKARightActive': '<S272>:110' */
            if (LKAS_DW.Merge1_c) {
              /* Transition: '<S272>:107' */
              /* Exit 'LKARightActive': '<S272>:110' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S272>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S272>:112' */
                /* Exit 'LKARightActive': '<S272>:110' */
                LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

                /* Entry 'LKALeftActive': '<S272>:109' */
                LKAS_DW.LKASM_stLKAState = 4U;
                LKAS_DW.LKASM_stLKAActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S82>/LKA_State_Machine' */
}

/*
 * Output and update for action system:
 *    '<S293>/Ph1SWA'
 *    '<S302>/Ph1SWA'
 *    '<S329>/Ph1SWA'
 *    '<S339>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S297>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S297>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S293>/Ph2SWA'
 *    '<S302>/Ph2SWA'
 *    '<S329>/Ph2SWA'
 *    '<S339>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S298>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S298>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S293>/Ph3SWA'
 *    '<S329>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S299>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S302>/Ph3SWA'
 *    '<S339>/Ph3SWA'
 */
void LKAS_Ph3SWA_f(float32 *rty_Out)
{
  /* SignalConversion: '<S308>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S308>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S352>/If Action Subsystem3'
 *    '<S391>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S357>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S365>/If Action Subsystem4'
 *    '<S365>/If Action Subsystem3'
 *    '<S469>/If Action Subsystem3'
 *    '<S469>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S377>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S377>/Constant'
   */
  *rty_Out = false;
}

/*
 * Output and update for action system:
 *    '<S400>/If Action Subsystem'
 *    '<S400>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_n(boolean *rty_Out)
{
  /* SignalConversion: '<S404>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S404>/Constant'
   */
  *rty_Out = true;
}

/*
 * Output and update for atomic system:
 *    '<S483>/MATLAB Function'
 *    '<S502>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_DvtThresUprLDW, float32 rtu_LaneWidth,
  float32 rtu_LKA_CarWidth, float32 *rty_ThresDet_coefficient)
{
  float32 tmp;

  /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Enable Condition  (EnaC)/LDW Own Condition (LDWOwnC)/Vehicle Position Check (VehPosChk)/Subsystem/MATLAB Function': '<S484>:1' */
  /* '<S484>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
  /* '<S484>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
  /* '<S484>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
  /* '<S484>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
  /* '<S484>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
  tmp = (2.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth;
  *rty_ThresDet_coefficient = fminf(fmaxf(0.0F, (fminf(fmaxf(tmp, rtu_LaneWidth),
    (6.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth) - tmp) / (4.0F *
    rtu_DvtThresUprLDW)), 1.0F);
}

/*
 * System initialize for enable system:
 *    '<S278>/Count_5s1'
 *    '<S278>/Count_5s2'
 */
void LKAS_Count_5s1_Init(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S538>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S278>/Count_5s1'
 *    '<S278>/Count_5s2'
 */
void LKAS_Count_5s1_Reset(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S538>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S278>/Count_5s1'
 *    '<S278>/Count_5s2'
 */
void LKAS_Count_5s1_Disable(boolean *rty_Out, DW_Count_5s1_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S278>/Count_5s1' incorporates:
   *  EnablePort: '<S538>/Enable'
   */
  /* Disable for Outport: '<S538>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S278>/Count_5s1' */
  localDW->Count_5s1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S278>/Count_5s1'
 *    '<S278>/Count_5s2'
 */
void LKAS_Count_5s1(boolean rtu_Enable, float32 rtu_SampleTime, boolean *rty_Out,
                    DW_Count_5s1_LKAS_T *localDW)
{
  float32 rtb_Saturation_cd;

  /* Outputs for Enabled SubSystem: '<S278>/Count_5s1' incorporates:
   *  EnablePort: '<S538>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Reset(localDW);
      localDW->Count_5s1_MODE = true;
    }

    /* Sum: '<S538>/Add' incorporates:
     *  Memory: '<S538>/Memory'
     */
    rtb_Saturation_cd = localDW->Memory_PreviousInput + rtu_SampleTime;

    /* Saturate: '<S538>/Saturation' */
    if (rtb_Saturation_cd > 11.0F) {
      rtb_Saturation_cd = 11.0F;
    } else {
      if (rtb_Saturation_cd < 0.0F) {
        rtb_Saturation_cd = 0.0F;
      }
    }

    /* End of Saturate: '<S538>/Saturation' */

    /* RelationalOperator: '<S538>/Relational Operator' incorporates:
     *  Constant: '<S538>/Constant1'
     */
    *rty_Out = (rtb_Saturation_cd >= ((float32)((uint16)5U)));

    /* Update for Memory: '<S538>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_cd;
  } else {
    if (localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S278>/Count_5s1' */
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  uint64 rtb_Gain;
  uint64 rtb_Gain1;
  uint32 rtb_Gain2;
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_VehSpd;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_Gain_j;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_Gain_g;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_MAX_DELAY_EPSSTAR_TIME;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_LFClb_TFC_KpVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KpVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KpV1_C;
  float32 rtb_LL_LFClb_TFC_KpV2_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KdV1_C;
  float32 rtb_LL_LFClb_TFC_KdV2_C;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_LL_HandsOff_WarnTime;
  float32 rtb_LL_HandsOff_TextTime;
  float32 rtb_R0_VR_e;
  float32 rtb_L0_VR_e;
  float32 rtb_R0_W_d;
  float32 rtb_L0_W_f;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_EPS_SteeringAngle;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_VR;
  float32 rtb_R1_W;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_i;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1_j;
  float32 rtb_Add5_n;
  float32 rtb_Add_p;
  float32 rtb_Add_o;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge_o;
  float32 rtb_Switch_d;
  float32 rtb_Saturation_c;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Multiply;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_f;
  float32 rtb_Switch_h;
  float32 rtb_Saturation_f;
  float32 rtb_Abs1_m;
  float32 rtb_Abs_i;
  float32 rtb_UnaryMinus_n;
  float32 rtb_Merge1_k;
  float32 rtb_Divide_b;
  float32 rtb_Switch_c;
  float32 rtb_Switch2_o;
  float32 rtb_Divide_ba;
  float32 rtb_Switch_n;
  float32 rtb_Switch2_n;
  float32 rtb_Merge1_f;
  float32 rtb_Divide_d;
  float32 rtb_Switch_gw;
  float32 rtb_Switch2_d;
  float32 rtb_Divide_f;
  float32 rtb_Switch_gi;
  float32 rtb_Switch2_fg;
  float32 rtb_Multiply_d;
  float32 rtb_Switch_p;
  float32 rtb_Switch2_c;
  float32 rtb_Memory_e;
  float32 rtb_Merge1_n;
  float32 rtb_Divide_k;
  float32 rtb_Switch_a;
  float32 rtb_Switch2_j;
  float32 rtb_Divide_kp;
  float32 rtb_Switch_o;
  float32 rtb_Switch2_jh;
  float32 rtb_Memory_p;
  float32 rtb_Merge1_j;
  float32 rtb_Divide_bk;
  float32 rtb_Switch_gl;
  float32 rtb_Switch2_nc;
  float32 rtb_Divide_h;
  float32 rtb_Switch_e;
  float32 rtb_Switch2_g;
  float32 rtb_phiHdAg;
  float32 rtb_Add_pp;
  float32 rtb_Add_n2;
  float32 rtb_Add_am;
  float32 rtb_Add_e1;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_ThresDet_coefficient;
  float32 rtb_Saturation2;
  float32 rtb_Merge_g;
  float32 rtb_Abs1_g;
  float32 rtb_Abs_h;
  float32 rtb_Add1_kd;
  float32 rtb_Merge_f;
  float32 rtb_Merge_ot;
  float32 rtb_Merge_k;
  float32 rtb_Add_lo;
  float32 rtb_Saturation6;
  float32 rtb_Saturation2_l;
  float32 rtb_Saturation2_n;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_gi;
  float32 rtb_Saturation_mf;
  float32 rtb_Add1_h;
  float32 rtb_kphtomps_l;
  float32 rtb_Saturation_j;
  float32 rtb_Switch2_i;
  float32 rtb_Switch_k;
  float32 rtb_Switch2_at;
  float32 rtb_Gain1_i5;
  float32 rtb_Switch_fy;
  float32 rtb_Switch2_g1;
  float32 rtb_Divide5;
  float32 rtb_Divide2_b;
  float32 rtb_Merge_d;
  float32 rtb_Switch_fl;
  float32 rtb_Switch2_k;
  float32 rtb_Divide7;
  float32 rtb_Switch_pi;
  float32 rtb_Switch2_p;
  float32 rtb_Saturation_nv;
  float32 rtb_Switch_dj;
  float32 rtb_Add_of;
  float32 rtb_Switch_og;
  float32 rtb_Switch2_m;
  float32 rtb_UkYk1_o;
  float32 rtb_Switch_dr;
  float32 rtb_Switch2_co;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_ly;
  float32 rtb_Saturation_ja;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_T2;
  float32 rtb_Plan;
  float32 rtb_T1_m;
  float32 rtb_Plan_o;
  float32 rtb_T1_j;
  float32 rtb_ThresDet_coefficient_a;
  float32 rtb_Gain_m;
  float32 rtb_Yk1_mo;
  float32 rtb_deltafalllimit_k;
  float32 rtb_Gain2_bi;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_f;
  uint16 rtb_Saturation1_d;
  uint16 rtb_Saturation1_b;
  uint16 rtb_Add_pn;
  uint16 rtb_Saturation1_k;
  uint16 rtb_Saturation1_en;
  uint16 rtb_Saturation1_b1;
  uint16 rtb_Saturation1_mm;
  uint16 rtb_Saturation2_b;
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_g;
  uint8 rtb_L0_Type_e;
  uint8 rtb_LDW_Warn_Mode;
  uint8 rtb_IMAPve_d_APA_AutoPark_WorkS;
  uint8 rtb_IMAPve_d_BCM_HazardLamp_g;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L1_Type;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_R1_Type;
  uint8 rtb_IMAPve_d_SWS_Failure_Status;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_LDW_State;
  uint8 rtb_DACMode;
  uint8 rtb_Saturation1_cv;
  boolean rtb_LogicalOperator2;
  boolean rtb_Compare_ku;
  boolean rtb_Compare_p;
  boolean rtb_Compare_pi;
  boolean rtb_Compare_ct;
  boolean rtb_Compare_ic;
  boolean rtb_Compare_nc;
  boolean rtb_Compare_pp;
  boolean rtb_Compare_a;
  boolean rtb_Compare_d2;
  boolean rtb_Compare_bw;
  boolean rtb_Compare_iz;
  boolean rtb_UnitDelay_m;
  boolean rtb_Merge_i;
  boolean rtb_Compare_km;
  boolean rtb_UnitDelay_h;
  boolean rtb_Compare_cj;
  boolean rtb_Merge_c;
  boolean rtb_Compare_gt;
  boolean rtb_Compare_oz;
  boolean rtb_Merge_n;
  boolean rtb_Compare_bi;
  boolean rtb_LogicalOperator1_f;
  boolean rtb_Compare_mx;
  boolean rtb_Compare_hr;
  boolean rtb_RelationalOperator6_i;
  boolean rtb_RelationalOperator5;
  float32 x10;
  float32 x20;
  float32 x1;
  sint32 i;
  uint8 rtb_Mod1;
  uint8 rtb_IMAPve_d_SAS_Trim_State;
  boolean rtb_LKA_Main_Switch;
  float32 rtb_Abs_k;
  float32 rtb_L0_C0;
  float32 rtb_L0_C2;
  float32 rtb_R0_C2;
  float32 rtb_Saturation;
  float32 rtb_R0_C0;
  uint8 rtb_L0_Q;
  uint8 rtb_R0_Q;
  float32 rtb_Add1;
  float32 rtb_Saturation1_m;
  uint8 rtb_L0_Type;
  uint8 rtb_R0_Type;
  float32 rtb_L0_C3;
  uint8 rtb_IMAPve_d_Camera_Status;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  float32 rtb_IMAPve_g_ESC_LatAcc;
  boolean rtb_BCM_Left_Light;
  boolean rtb_BCM_Right_Light;
  uint8 rtb_IMAPve_d_TCU_Actual_Gear;
  uint8 rtb_TCU_ActualGear;
  uint8 rtb_Hands_Off_Warning_c;
  uint8 rtb_LKA_Action_Indication_d;
  float32 rtb_L0_C0_o;
  float32 rtb_LL_CompHdAg_C;
  float32 rtb_L0_C1_i;
  float32 rtb_R0_C1_e;
  float32 rtb_L0_C1_m;
  float32 rtb_L0_C3_dc;
  float32 rtb_R0_C0_n;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  boolean rtb_LL_SingleLane_Disable_Swt;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_TTLC_d;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_n;
  boolean rtb_LogicalOperator3_b5;
  boolean rtb_LogicalOperator3_pm;
  boolean rtb_Compare_mw;
  boolean rtb_Compare_ho;
  boolean rtb_LogicalOperator_iv;
  boolean rtb_Compare_bp;
  boolean rtb_LogicalOperator_ix;
  boolean rtb_Compare_ab;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_cwd;
  boolean rtb_RelationalOperator_b;
  boolean rtb_LogicalOperator_ol;
  boolean rtb_LogicalOperator_m;
  uint8 rtb_CastToSingle3;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge;
  float32 rtb_offset;
  uint16 rtb_Saturation_h5;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  float32 rtb_TTLC;
  float32 rtb_TLft;
  float32 rtb_LKA_Veh2CamL_C_tmp;
  float32 rtb_Add5_n_tmp;
  float32 rtb_LogicalOperator3_c_tmp;
  float32 rtb_LogicalOperator3_c_tmp_0;
  float32 rtb_Gain2_b_0;
  float32 rtb_Add_p_tmp;
  float32 rtb_Add_o_tmp;
  boolean exitg1;

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/FDMMve_d_LkaFcnConf_1' incorporates:
   *  Inport: '<Root>/FDMMve_d_LkaFcnConf'
   */
  rtb_Mod1 = (uint8)
    Rte_IRead_Runnable_LKAS_Step_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf();

  /* Switch: '<S44>/Switch' incorporates:
   *  Constant: '<S44>/Constant3'
   *  Constant: '<S44>/Constant4'
   */
  if (rtb_Mod1 > ((uint8)0U)) {
    rtb_L0_Q = ((uint8)1U);
  } else {
    rtb_L0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S44>/Switch' */

  /* Saturate: '<S44>/Saturation1' */
  if (rtb_Mod1 > ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  } else {
    if (rtb_Mod1 < ((uint8)1U)) {
      rtb_Mod1 = ((uint8)1U);
    }
  }

  /* End of Saturate: '<S44>/Saturation1' */

  /* Sum: '<S44>/Add1' incorporates:
   *  Constant: '<S44>/Constant1'
   */
  rtb_Mod1 -= ((uint8)1U);

  /* Saturate: '<S44>/Saturation' */
  if (rtb_Mod1 >= ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  }

  /* End of Saturate: '<S44>/Saturation' */

  /* Math: '<S44>/Mod' incorporates:
   *  Constant: '<S44>/Constant2'
   */
  if (((sint32)((uint8)6U)) == 0) {
    rtb_R0_Q = rtb_Mod1;
  } else {
    rtb_R0_Q = (uint8)(rtb_Mod1 % ((uint8)6U));
  }

  /* End of Math: '<S44>/Mod' */

  /* Product: '<S44>/Divide1' incorporates:
   *  Constant: '<S44>/Constant5'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)(((uint32)rtb_R0_Q) / ((uint32)((uint8)3U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LKA_Mode'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode();

  /* MinMax: '<S44>/Max' */
  if (rtb_IMAPve_d_SAS_Trim_State > rtb_L0_Type) {
    rtb_L0_Type = rtb_IMAPve_d_SAS_Trim_State;
  }

  /* End of MinMax: '<S44>/Max' */

  /* Product: '<S44>/Divide' incorporates:
   *  Constant: '<S44>/Constant6'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  Inport: '<Root>/IMAPve_d_LKA_Main_Switch'
   *  Logic: '<S44>/Logical Operator'
   *  Sum: '<S44>/Add'
   */
  LKAS_DW.LKA_Mode = (uint8)((sint32)(((((sint32)rtb_L0_Q) != 0) || (((sint32)
    ((uint8)
     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch
     ())) != 0)) ? ((sint32)((uint8)(((uint32)rtb_L0_Type) + ((uint32)((uint8)1U)))))
    : 0));

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Q'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q();

  /* Switch: '<S55>/Switch' incorporates:
   *  Constant: '<S55>/Constant'
   */
  if (rtb_IMAPve_d_SAS_Trim_State >= ((uint8)2U)) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = rtb_IMAPve_d_SAS_Trim_State;
  }

  /* End of Switch: '<S55>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Q'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q();

  /* Switch: '<S52>/Switch1' incorporates:
   *  Constant: '<S52>/Constant1'
   */
  if (rtb_IMAPve_d_SAS_Trim_State >= ((uint8)2U)) {
    rtb_R0_Q = ((uint8)3U);
  } else {
    rtb_R0_Q = rtb_IMAPve_d_SAS_Trim_State;
  }

  /* End of Switch: '<S52>/Switch1' */

  /* Chart: '<S51>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c8_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c8_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S56>:4' */
    LKAS_DW.is_c8_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S56>:3' */
    /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c8_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S56>:9' */
      /* '<S56>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:13' */
        LKAS_DW.is_c8_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S56>:3' */
        /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S56>:14' */
          LKAS_DW.is_c8_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S56>:7' */
          /* '<S56>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S56>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S56>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
            /* Transition: '<S56>:23' */
            LKAS_DW.is_c8_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S56>:5' */
            /* '<S56>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S56>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S56>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S56>:5' */
      /* '<S56>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:16' */
        LKAS_DW.is_c8_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S56>:3' */
        /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S56>:18' */
          LKAS_DW.is_c8_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S56>:7' */
          /* '<S56>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S56>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S56>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_R0_Q) < 3) {
            /* Transition: '<S56>:11' */
            LKAS_DW.is_c8_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S56>:3' */
      /* '<S56>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:6' */
        LKAS_DW.is_c8_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S56>:5' */
        /* '<S56>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S56>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S56>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S56>:8' */
          LKAS_DW.is_c8_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S56>:7' */
          /* '<S56>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S56>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S56>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) < 3)) {
            /* Transition: '<S56>:10' */
            /* '<S56>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c8_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S56>:7' */
      /* '<S56>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:17' */
        LKAS_DW.is_c8_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S56>:3' */
        /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
          /* Transition: '<S56>:19' */
          LKAS_DW.is_c8_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S56>:5' */
          /* '<S56>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S56>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S56>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_L0_Q) < 3) {
            /* Transition: '<S56>:12' */
            LKAS_DW.is_c8_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S51>/LaneReconstructSM' */

  /* DataTypeConversion: '<S50>/Cast To Single64' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   *  UnaryMinus: '<S50>/Unary Minus'
   */
  rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single65' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  UnaryMinus: '<S50>/Unary Minus2'
   */
  rtb_L0_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2
    ()));

  /* UnaryMinus: '<S50>/Unary Minus6' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   */
  rtb_Abs_k = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single56' */
  rtb_R0_C2 = rtb_Abs_k;

  /* Sum: '<S61>/Add2' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single56'
   */
  rtb_Abs_k += rtb_L0_C2;

  /* Abs: '<S61>/Abs' */
  rtb_Abs_k = fabsf(rtb_Abs_k);

  /* Saturate: '<S61>/Saturation' */
  if (rtb_Abs_k > 0.004F) {
    rtb_Saturation = 0.004F;
  } else if (rtb_Abs_k < 0.0F) {
    rtb_Saturation = 0.0F;
  } else {
    rtb_Saturation = rtb_Abs_k;
  }

  /* End of Saturate: '<S61>/Saturation' */

  /* UnaryMinus: '<S50>/Unary Minus4' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   */
  rtb_Abs_k = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single55' */
  rtb_R0_C0 = rtb_Abs_k;

  /* Switch: '<S65>/Switch' incorporates:
   *  Constant: '<S74>/Constant'
   *  Constant: '<S75>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single55'
   *  Delay: '<S65>/Delay'
   *  Gain: '<S65>/Gain'
   *  Logic: '<S65>/Logical Operator'
   *  RelationalOperator: '<S74>/Compare'
   *  RelationalOperator: '<S75>/Compare'
   *  Sum: '<S65>/Add'
   */
  if ((rtb_L0_Q >= ((uint8)2U)) && (rtb_R0_Q >= ((uint8)2U))) {
    rtb_Abs_k += (-1.0F) * rtb_L0_C0;
  } else {
    rtb_Abs_k = LKAS_DW.Delay_DSTATE;
  }

  /* End of Switch: '<S65>/Switch' */

  /* Sum: '<S73>/Add1' incorporates:
   *  Memory: '<S73>/Memory'
   *  Product: '<S73>/Divide'
   *  Product: '<S73>/Divide1'
   */
  rtb_Add1 = (rtb_Abs_k * LKAS_ConstB.Divide2) + (LKAS_ConstB.Add2 *
    LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S65>/Saturation1' */
  if (rtb_Add1 > 5.5F) {
    rtb_Saturation1_m = 5.5F;
  } else if (rtb_Add1 < 2.5F) {
    rtb_Saturation1_m = 2.5F;
  } else {
    rtb_Saturation1_m = rtb_Add1;
  }

  /* End of Saturate: '<S65>/Saturation1' */

  /* MATLAB Function: '<S61>/get_roadside_offset' */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S67>:1' */
  /* '<S67>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S67>:1:3' cur=min(single(0.004),cur); */
  /* '<S67>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S67>:1:5' offset=min(single(0.5),offset); */
  rtb_offset = fminf(0.5F, (((fminf(0.004F, rtb_Saturation) / 0.004F) + 1.0F) *
    0.2F) * (fminf(4.0F, rtb_Saturation1_m) - 2.0F));

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type();

  /* DataTypeConversion: '<S50>/Cast To Single77' */
  rtb_L0_Type = rtb_IMAPve_d_SAS_Trim_State;

  /* Switch: '<S66>/Switch' incorporates:
   *  Constant: '<S77>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single77'
   *  RelationalOperator: '<S77>/Compare'
   *  Sum: '<S66>/Add'
   */
  if (rtb_IMAPve_d_SAS_Trim_State == ((uint8)10U)) {
    rtb_L0_C0 += rtb_offset;
  }

  /* End of Switch: '<S66>/Switch' */

  /* Switch: '<S76>/Switch' incorporates:
   *  Abs: '<S76>/Abs'
   *  Constant: '<S78>/Constant'
   *  Memory: '<S76>/Memory'
   *  Memory: '<S76>/Memory1'
   *  Product: '<S76>/Divide'
   *  Product: '<S76>/Divide1'
   *  RelationalOperator: '<S78>/Compare'
   *  Sum: '<S76>/Add1'
   *  Sum: '<S76>/Add3'
   */
  if (fabsf(rtb_L0_C0 - LKAS_DW.Memory1_PreviousInput) > 0.5F) {
    rtb_Saturation = rtb_L0_C0;
  } else {
    rtb_Saturation = (rtb_L0_C0 * LKAS_ConstB.Divide2_l) + (LKAS_ConstB.Add2_b *
      LKAS_DW.Memory_PreviousInput_m);
  }

  /* End of Switch: '<S76>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type();

  /* DataTypeConversion: '<S50>/Cast To Single48' */
  rtb_R0_Type = rtb_IMAPve_d_SAS_Trim_State;

  /* Switch: '<S62>/Switch1' incorporates:
   *  Constant: '<S69>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single48'
   *  RelationalOperator: '<S69>/Compare'
   *  Sum: '<S62>/Add1'
   */
  if (rtb_IMAPve_d_SAS_Trim_State == ((uint8)10U)) {
    rtb_R0_C0 -= rtb_offset;
  }

  /* End of Switch: '<S62>/Switch1' */

  /* Switch: '<S68>/Switch' incorporates:
   *  Abs: '<S68>/Abs'
   *  Constant: '<S70>/Constant'
   *  Memory: '<S68>/Memory'
   *  Memory: '<S68>/Memory1'
   *  Product: '<S68>/Divide'
   *  Product: '<S68>/Divide1'
   *  RelationalOperator: '<S70>/Compare'
   *  Sum: '<S68>/Add1'
   *  Sum: '<S68>/Add3'
   */
  if (fabsf(rtb_R0_C0 - LKAS_DW.Memory1_PreviousInput_h) > 0.5F) {
    rtb_offset = rtb_R0_C0;
  } else {
    rtb_offset = (rtb_R0_C0 * LKAS_ConstB.Divide2_lw) + (LKAS_ConstB.Add2_j *
      LKAS_DW.Memory_PreviousInput_f);
  }

  /* End of Switch: '<S68>/Switch' */

  /* Switch: '<S51>/Switch1' incorporates:
   *  Gain: '<S58>/Gain'
   *  Sum: '<S58>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_o = rtb_Saturation;
  } else {
    rtb_L0_C0_o = (rtb_Saturation1_m - rtb_offset) * (-1.0F);
  }

  /* Switch: '<S552>/Switch24' incorporates:
   *  Constant: '<S552>/LL_CompHdAg_C=0.005'
   */
  if (LKAS_ConstB.DataTypeConversion38 != 0.0F) {
    rtb_LL_CompHdAg_C = LKAS_ConstB.DataTypeConversion38;
  } else {
    rtb_LL_CompHdAg_C = LL_CompHdAg_C;
  }

  /* End of Switch: '<S552>/Switch24' */

  /* Switch: '<S63>/Switch1' incorporates:
   *  Constant: '<S71>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
   *  Inport: '<Root>/IMAPve_g_L0_C1'
   *  RelationalOperator: '<S71>/Compare'
   *  Sum: '<S63>/Add'
   *  UnaryMinus: '<S50>/Unary Minus1'
   */
  if (rtb_L0_Q == ((uint8)3U)) {
    rtb_L0_C1_i = rtb_LL_CompHdAg_C + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1())));
  } else {
    rtb_L0_C1_i = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1()));
  }

  /* End of Switch: '<S63>/Switch1' */

  /* Switch: '<S64>/Switch1' incorporates:
   *  Constant: '<S72>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
   *  Inport: '<Root>/IMAPve_g_R0_C1'
   *  RelationalOperator: '<S72>/Compare'
   *  Sum: '<S64>/Add'
   *  UnaryMinus: '<S50>/Unary Minus5'
   */
  if (rtb_R0_Q == ((uint8)3U)) {
    rtb_R0_C1_e = rtb_LL_CompHdAg_C + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1())));
  } else {
    rtb_R0_C1_e = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1()));
  }

  /* End of Switch: '<S64>/Switch1' */

  /* DataTypeConversion: '<S50>/Cast To Single67' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  UnaryMinus: '<S50>/Unary Minus3'
   */
  rtb_L0_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3
    ()));

  /* UnaryMinus: '<S50>/Unary Minus7' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   */
  rtb_Abs_k = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3
    ()));

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single60'
   *  DataTypeConversion: '<S58>/Cast To Single1'
   *  DataTypeConversion: '<S58>/Cast To Single2'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C1_m = rtb_L0_C1_i;
    rtb_LL_CompHdAg_C = rtb_L0_C2;
    rtb_L0_C3_dc = rtb_L0_C3;
  } else {
    rtb_L0_C1_m = rtb_R0_C1_e;
    rtb_LL_CompHdAg_C = rtb_R0_C2;
    rtb_L0_C3_dc = rtb_Abs_k;
  }

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single60'
   *  Sum: '<S60>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_C0_n = rtb_offset;
    rtb_L0_C1_i = rtb_R0_C1_e;
    rtb_L0_C2 = rtb_R0_C2;
    rtb_L0_C3 = rtb_Abs_k;
  } else {
    rtb_R0_C0_n = rtb_Saturation1_m + rtb_Saturation;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Camera_Status'
   */
  rtb_IMAPve_d_Camera_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_LKA_State'
   */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  rtb_IMAPve_g_EPS_SW_Trq = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  rtb_IMAPve_g_ESC_VehSpd = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  rtb_IMAPve_g_ESC_LonAcc = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  rtb_IMAPve_g_SW_Angle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp
    ();

  /* Logic: '<S41>/Logical Operator' incorporates:
   *  Constant: '<S48>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Left_Light'
   *  RelationalOperator: '<S48>/Compare'
   */
  rtb_BCM_Left_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch
                    ()) == ((uint8)1U)));

  /* Logic: '<S41>/Logical Operator1' incorporates:
   *  Constant: '<S49>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Right_Light'
   *  RelationalOperator: '<S49>/Compare'
   */
  rtb_BCM_Right_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
                    ()) == ((uint8)1U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_Actual_Gear'
   */
  rtb_IMAPve_d_TCU_Actual_Gear = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear
    ();

  /* MultiPortSwitch: '<S45>/Multiport Switch' incorporates:
   *  Constant: '<S45>/Constant1'
   *  Constant: '<S45>/Constant3'
   */
  switch (rtb_IMAPve_d_TCU_Actual_Gear) {
   case 0:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 1:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 2:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 3:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 4:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 5:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 6:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 7:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 8:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 9:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   default:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;
  }

  /* End of MultiPortSwitch: '<S45>/Multiport Switch' */

  /* Switch: '<S553>/Switch58' incorporates:
   *  Constant: '<S553>/LLSMConClb4'
   *
   * Block description for '<S553>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S553>/Switch58' */

  /* Gain: '<S558>/Gain' incorporates:
   *  Constant: '<S558>/Constant'
   *  Sum: '<S558>/Add'
   */
  rtb_Gain_j = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S553>/Switch84' incorporates:
   *  Constant: '<S553>/LLSMConClb5'
   *
   * Block description for '<S553>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S553>/Switch84' */

  /* Switch: '<S553>/Switch85' incorporates:
   *  Constant: '<S553>/LLSMConClb6'
   *
   * Block description for '<S553>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S553>/Switch85' */

  /* Switch: '<S553>/Switch86' incorporates:
   *  Constant: '<S553>/LLSMConClb7'
   *
   * Block description for '<S553>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S553>/Switch86' */

  /* Switch: '<S553>/Switch54' incorporates:
   *  Constant: '<S553>/LLSMConClb12'
   *
   * Block description for '<S553>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S553>/Switch54' */

  /* Switch: '<S553>/Switch55' incorporates:
   *  Constant: '<S553>/LLSMConClb13'
   *
   * Block description for '<S553>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S553>/Switch55' */

  /* Switch: '<S553>/Switch60' incorporates:
   *  Constant: '<S553>/LLSMConClb17'
   *
   * Block description for '<S553>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S553>/Switch60' */

  /* Switch: '<S553>/Switch57' incorporates:
   *  Constant: '<S553>/LLSMConClb18'
   *
   * Block description for '<S553>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S553>/Switch57' */

  /* Switch: '<S553>/Switch59' incorporates:
   *  Constant: '<S553>/LLSMConClb19'
   *
   * Block description for '<S553>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_R0_C2 = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_R0_C2 = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S553>/Switch59' */

  /* Switch: '<S553>/Switch69' incorporates:
   *  Constant: '<S553>/LLSMConClb22'
   *
   * Block description for '<S553>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S553>/Switch69' */

  /* Gain: '<S555>/Gain' incorporates:
   *  Constant: '<S555>/Constant'
   *  Sum: '<S555>/Add'
   */
  rtb_Gain_g = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S553>/Switch68' incorporates:
   *  Constant: '<S553>/LLSMConClb23'
   *
   * Block description for '<S553>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S553>/Switch68' */

  /* Switch: '<S553>/Switch70' incorporates:
   *  Constant: '<S553>/LLSMConClb24'
   *
   * Block description for '<S553>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S553>/Switch70' */

  /* Switch: '<S553>/Switch71' incorporates:
   *  Constant: '<S553>/LLSMConClb25'
   *
   * Block description for '<S553>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S553>/Switch71' */

  /* Switch: '<S553>/Switch73' incorporates:
   *  Constant: '<S553>/LLSMConClb27'
   *
   * Block description for '<S553>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S553>/Switch73' */

  /* Switch: '<S553>/Switch62' incorporates:
   *  Constant: '<S553>/LLSMConClb31'
   *
   * Block description for '<S553>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S553>/Switch62' */

  /* Switch: '<S553>/Switch63' incorporates:
   *  Constant: '<S553>/LLSMConClb32'
   *
   * Block description for '<S553>/LLSMConClb32':
   *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
   */
  if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LKAS_ConstB.DataTypeConversion78;
  } else {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LL_MAX_DELAY_EPSSTAR_TIME;
  }

  /* End of Switch: '<S553>/Switch63' */

  /* Switch: '<S553>/Switch66' incorporates:
   *  Constant: '<S553>/LLSMConClb35'
   *
   * Block description for '<S553>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S553>/Switch66' */

  /* Switch: '<S553>/Switch4' incorporates:
   *  Constant: '<S553>/LL_RlsDet_tiTDelTime_DISABLE=4'
   *
   * Block description for '<S553>/LL_RlsDet_tiTDelTime_DISABLE=4':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_SingleLane_Disable_Swt = (LKAS_ConstB.DataTypeConversion4 != 0.0F);
  } else {
    rtb_LL_SingleLane_Disable_Swt = LL_SingleLane_Disable_Swt;
  }

  /* End of Switch: '<S553>/Switch4' */

  /* Switch: '<S553>/Switch81' incorporates:
   *  Constant: '<S553>/LLSMConClb36'
   *
   * Block description for '<S553>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S553>/Switch81' */

  /* Switch: '<S553>/Switch82' incorporates:
   *  Constant: '<S553>/LLSMConClb37'
   *
   * Block description for '<S553>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S553>/Switch82' */

  /* Switch: '<S553>/Switch83' incorporates:
   *  Constant: '<S553>/LLSMConClb38'
   *
   * Block description for '<S553>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S553>/Switch83' */

  /* Switch: '<S553>/Switch75' incorporates:
   *  Constant: '<S553>/LLSMConClb39'
   *
   * Block description for '<S553>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S553>/Switch75' */

  /* Switch: '<S553>/Switch76' incorporates:
   *  Constant: '<S553>/LLSMConClb40'
   *
   * Block description for '<S553>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S553>/Switch76' */

  /* Switch: '<S553>/Switch77' incorporates:
   *  Constant: '<S553>/LLSMConClb41'
   *
   * Block description for '<S553>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S553>/Switch77' */

  /* Switch: '<S553>/Switch78' incorporates:
   *  Constant: '<S553>/LLSMConClb42'
   *
   * Block description for '<S553>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S553>/Switch78' */

  /* Switch: '<S552>/Switch3' incorporates:
   *  Constant: '<S552>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3_b != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3_b;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S552>/Switch3' */

  /* Switch: '<S552>/Switch10' incorporates:
   *  Constant: '<S552>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    LKAS_DW.LL_DesDvt_C_b = LKAS_ConstB.DataTypeConversion22;
  } else {
    LKAS_DW.LL_DesDvt_C_b = LL_DesDvt_C;
  }

  /* End of Switch: '<S552>/Switch10' */

  /* Switch: '<S552>/Switch15' incorporates:
   *  Constant: '<S552>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    LKAS_DW.LL_lStpLngth_C_i = LKAS_ConstB.DataTypeConversion21;
  } else {
    LKAS_DW.LL_lStpLngth_C_i = LL_lStpLngth_C;
  }

  /* End of Switch: '<S552>/Switch15' */

  /* Switch: '<S552>/Switch31' incorporates:
   *  Constant: '<S552>/LL_LFClb_TFC_KpVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_j != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LKAS_ConstB.DataTypeConversion14_j;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S552>/Switch31' */

  /* Switch: '<S552>/Switch34' incorporates:
   *  Constant: '<S552>/LL_LFClb_TFC_KpVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4_o != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LKAS_ConstB.DataTypeConversion4_o;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S552>/Switch34' */

  /* Switch: '<S552>/Switch33' incorporates:
   *  Constant: '<S552>/LL_LFClb_TFC_KpV1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_l != 0.0F) {
    rtb_LL_LFClb_TFC_KpV1_C = LKAS_ConstB.DataTypeConversion7_l;
  } else {
    rtb_LL_LFClb_TFC_KpV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S552>/Switch33' */

  /* Switch: '<S552>/Switch35' incorporates:
   *  Constant: '<S552>/LL_LFClb_TFC_KpV2_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion17_i != 0.0F) {
    rtb_LL_LFClb_TFC_KpV2_C = LKAS_ConstB.DataTypeConversion17_i;
  } else {
    rtb_LL_LFClb_TFC_KpV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S552>/Switch35' */

  /* Switch: '<S552>/Switch20' incorporates:
   *  Constant: '<S552>/LL_LFClb_TFC_KdVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LL_LFClb_TFC_KdVehSpdLwr_C;
  }

  /* End of Switch: '<S552>/Switch20' */

  /* Switch: '<S552>/Switch22' incorporates:
   *  Constant: '<S552>/LL_LFClb_TFC_KdVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LL_LFClb_TFC_KdVehSpdUpr_C;
  }

  /* End of Switch: '<S552>/Switch22' */

  /* Switch: '<S552>/Switch21' incorporates:
   *  Constant: '<S552>/LL_LFClb_TFC_KdV1_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV1_C = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LFClb_TFC_KdV1_C = LL_LFClb_TFC_KdV1_C;
  }

  /* End of Switch: '<S552>/Switch21' */

  /* Switch: '<S552>/Switch23' incorporates:
   *  Constant: '<S552>/LL_LFClb_TFC_KdV2_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV2_C = LKAS_ConstB.DataTypeConversion30;
  } else {
    rtb_LL_LFClb_TFC_KdV2_C = LL_LFClb_TFC_KdV2_C;
  }

  /* End of Switch: '<S552>/Switch23' */

  /* Switch: '<S552>/Switch9' incorporates:
   *  Constant: '<S552>/LL_LFClb_TFC_KdBalance_C=1.2'
   */
  if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
    rtb_Abs_k = LKAS_ConstB.DataTypeConversion9;
  } else {
    rtb_Abs_k = LL_LFClb_TFC_KdBalance_C;
  }

  /* End of Switch: '<S552>/Switch9' */

  /* Switch: '<S552>/Switch11' incorporates:
   *  Constant: '<S552>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_b != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12_b;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S552>/Switch11' */

  /* Switch: '<S552>/Switch13' incorporates:
   *  Constant: '<S552>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_m != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_m;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S552>/Switch13' */

  /* Switch: '<S552>/Switch16' incorporates:
   *  Constant: '<S552>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S552>/Switch16' */

  /* Switch: '<S552>/Switch18' incorporates:
   *  Constant: '<S552>/LL_LKASWASyn_M3K=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
    rtb_R0_C1_e = LKAS_ConstB.DataTypeConversion25;
  } else {
    rtb_R0_C1_e = LL_LKASWASyn_M3K;
  }

  /* End of Switch: '<S552>/Switch18' */

  /* Switch: '<S552>/Switch55' incorporates:
   *  Constant: '<S552>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S552>/Switch55' */

  /* Switch: '<S552>/Switch54' incorporates:
   *  Constant: '<S552>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S552>/Switch54' */

  /* Switch: '<S552>/Switch44' incorporates:
   *  Constant: '<S552>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S552>/Switch44' */

  /* Switch: '<S550>/Switch19' incorporates:
   *  Constant: '<S550>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_a != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_a;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S550>/Switch19' */

  /* Switch: '<S550>/Switch' incorporates:
   *  Constant: '<S550>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_f != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_f;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S550>/Switch' */

  /* Switch: '<S550>/Switch1' incorporates:
   *  Constant: '<S550>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_c != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_c;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S550>/Switch1' */

  /* Switch: '<S550>/Switch2' incorporates:
   *  Constant: '<S550>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_m != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_m = LKAS_ConstB.DataTypeConversion4_m;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_m = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S550>/Switch2' */

  /* Switch: '<S550>/Switch3' incorporates:
   *  Constant: '<S550>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_h != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_d = LKAS_ConstB.DataTypeConversion6_h;
  } else {
    LKAS_DW.LKA_StrRatio_C_d = LKA_StrRatio_C;
  }

  /* End of Switch: '<S550>/Switch3' */

  /* Switch: '<S550>/Switch11' incorporates:
   *  Constant: '<S550>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22_p != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22_p;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S550>/Switch11' */

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (((sint32)LKAS_DW.LKA_Mode) > 0) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S81>/Delay' */
      LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

      /* InitializeConditions for Memory: '<S515>/Memory' */
      LKAS_DW.Memory_PreviousInput_j = 0.0F;

      /* InitializeConditions for Memory: '<S460>/Memory' */
      LKAS_DW.Memory_PreviousInput_c = 0.0F;

      /* InitializeConditions for UnitDelay: '<S392>/Delay Input1'
       *
       * Block description for '<S392>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S391>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_i = false;

      /* InitializeConditions for UnitDelay: '<S354>/Delay Input1'
       *
       * Block description for '<S354>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_c = false;

      /* InitializeConditions for UnitDelay: '<S352>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_gu = false;

      /* InitializeConditions for UnitDelay: '<S353>/Delay Input1'
       *
       * Block description for '<S353>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_p = false;

      /* InitializeConditions for Memory: '<S319>/Memory' */
      LKAS_DW.Memory_PreviousInput_eq = false;

      /* InitializeConditions for Delay: '<S82>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for Delay: '<S82>/Delay' */
      LKAS_DW.Delay_DSTATE_j = false;

      /* InitializeConditions for Delay: '<S82>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S367>/Memory' */
      LKAS_DW.Memory_PreviousInput_id = ((uint8)0U);

      /* InitializeConditions for Memory: '<S293>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = 0.0F;

      /* InitializeConditions for Memory: '<S329>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = 0.0F;

      /* InitializeConditions for Delay: '<S82>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S82>/LDW_State_Machine'
       *
       * Block description for '<S82>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S82>/LKA_State_Machine'
       *
       * Block description for '<S82>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S234>/Add1' incorporates:
     *  MATLAB Function: '<S232>/MATLAB Function3'
     */
    x20 = rtb_L0_C0_o + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S234>/Gain1' incorporates:
     *  Product: '<S234>/Divide'
     *  Product: '<S234>/Divide1'
     *  Sum: '<S234>/Add1'
     *  Sum: '<S234>/Add5'
     *  Trigonometry: '<S234>/Cos2'
     *  Trigonometry: '<S234>/Sin'
     */
    rtb_Gain1_j = ((x20 * cosf(rtb_L0_C1_m)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_m))) * (-1.0F);

    /* Sum: '<S235>/Add1' incorporates:
     *  MATLAB Function: '<S232>/MATLAB Function4'
     */
    rtb_Add5_n_tmp = rtb_R0_C0_n - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S235>/Add5' incorporates:
     *  Product: '<S235>/Divide'
     *  Product: '<S235>/Divide1'
     *  Sum: '<S235>/Add1'
     *  Trigonometry: '<S235>/Cos2'
     *  Trigonometry: '<S235>/Sin'
     */
    rtb_Add5_n = (rtb_Add5_n_tmp * cosf(rtb_L0_C1_i)) + (rtb_LKA_Veh2CamL_C *
      sinf(rtb_L0_C1_i));

    /* Switch: '<S552>/Switch2' incorporates:
     *  Constant: '<S552>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_i != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_i;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S552>/Switch2' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S239>/kph to mps' incorporates:
     *  Gain: '<S118>/Gain'
     *  Gain: '<S168>/kph To mps'
     *  Gain: '<S182>/kph to mps'
     *  Gain: '<S183>/kph to mps'
     *  Gain: '<S232>/Gain2'
     *  Gain: '<S245>/kph to mps'
     *  Gain: '<S252>/kph to mps'
     *  Gain: '<S253>/kph to mps'
     *  Gain: '<S280>/Gain'
     *  Gain: '<S318>/Gain'
     */
    rtb_LKA_Veh2CamL_C_tmp = 0.277777791F * rtb_IMAPve_g_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S239>/Divide' incorporates:
     *  Gain: '<S239>/kph to mps'
     */
    rtb_LKA_Veh2CamL_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Gain: '<S236>/Gain' incorporates:
     *  Gain: '<S250>/Gain'
     *  Gain: '<S251>/Gain'
     */
    rtb_Add_p_tmp = 2.0F * rtb_LL_CompHdAg_C;

    /* Sum: '<S236>/Add' incorporates:
     *  Gain: '<S236>/Gain'
     *  Gain: '<S236>/Gain1'
     *  Product: '<S236>/Product'
     */
    rtb_Add_p = ((6.0F * rtb_L0_C3_dc) * rtb_LKA_Veh2CamL_C) + rtb_Add_p_tmp;

    /* Gain: '<S237>/Gain' incorporates:
     *  Gain: '<S248>/Gain'
     *  Gain: '<S249>/Gain'
     */
    rtb_Add_o_tmp = 2.0F * rtb_L0_C2;

    /* Sum: '<S237>/Add' incorporates:
     *  Gain: '<S237>/Gain'
     *  Gain: '<S237>/Gain1'
     *  Product: '<S237>/Product'
     */
    rtb_Add_o = ((6.0F * rtb_L0_C3) * rtb_LKA_Veh2CamL_C) + rtb_Add_o_tmp;

    /* UnaryMinus: '<S232>/Unary Minus' incorporates:
     *  Product: '<S232>/Product'
     */
    rtb_LKA_Veh2CamL_C = -(rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1_m);

    /* Saturate: '<S232>/Saturation9' */
    if (rtb_LKA_Veh2CamL_C > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else {
      if (rtb_LKA_Veh2CamL_C < (-2.0F)) {
        rtb_LKA_Veh2CamL_C = (-2.0F);
      }
    }

    /* End of Saturate: '<S232>/Saturation9' */

    /* MATLAB Function: '<S232>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function': '<S261>:1' */
    /* '<S261>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1_j > 0.0F) && (rtb_Gain1_j < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S261>:1:3' TTLC = -dvt/vy; */
      rtb_TTLC_d = (-rtb_Gain1_j) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S261>:1:4' else */
      /* '<S261>:1:5' TTLC = single(3); */
      rtb_TTLC_d = 3.0F;
    }

    /* End of MATLAB Function: '<S232>/MATLAB Function' */

    /* Saturate: '<S232>/Saturation' */
    if (rtb_TTLC_d > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_TTLC_d < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_TTLC_d;
    }

    /* End of Saturate: '<S232>/Saturation' */

    /* Product: '<S232>/Product3' */
    rtb_TTLC_d = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1_i;

    /* Saturate: '<S232>/Saturation10' incorporates:
     *  Product: '<S232>/Product3'
     */
    if (rtb_TTLC_d > 2.0F) {
      rtb_TTLC_d = 2.0F;
    } else {
      if (rtb_TTLC_d < (-2.0F)) {
        rtb_TTLC_d = (-2.0F);
      }
    }

    /* End of Saturate: '<S232>/Saturation10' */

    /* MATLAB Function: '<S232>/MATLAB Function1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function1': '<S262>:1' */
    /* '<S262>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_n > 0.0F) && (rtb_Add5_n < 2.0F)) && (rtb_TTLC_d < 0.0F)) &&
        (rtb_TTLC_d > -1.5F)) {
      /* '<S262>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_n = (-rtb_Add5_n) / rtb_TTLC_d;
    } else {
      /* '<S262>:1:4' else */
      /* '<S262>:1:5' TTLC = single(3); */
      rtb_TTLC_n = 3.0F;
    }

    /* End of MATLAB Function: '<S232>/MATLAB Function1' */

    /* Saturate: '<S232>/Saturation1' */
    if (rtb_TTLC_n > 2.0F) {
      rtb_TTLC_n = 2.0F;
    } else {
      if (rtb_TTLC_n < 0.6F) {
        rtb_TTLC_n = 0.6F;
      }
    }

    /* End of Saturate: '<S232>/Saturation1' */

    /* MATLAB Function: '<S232>/MATLAB Function5' incorporates:
     *  Gain: '<S260>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function5': '<S266>:1' */
    /* '<S266>:1:2' K = 0.09/vx; */
    /* '<S266>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_IMAPve_g_SW_Angle) / (((((((0.09F /
      rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp)
      + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_m) * LKAS_DW.LKA_StrRatio_C_d) * 2.0F);

    /* MATLAB Function: '<S232>/MATLAB Function3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function3': '<S264>:1' */
    /* '<S264>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_LL_CompHdAg_C - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_m > 0.0F) || (rtb_L0_C1_m < 0.0F))) {
      /* '<S264>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_o) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_m;
      if (x10 > 0.0F) {
        /* '<S264>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        /* '<S264>:1:9' else */
        /* '<S264>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_m * rtb_L0_C1_m) - ((x10 * 4.0F) * x20);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S264>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S264>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_m)) / x1;

        /* '<S264>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_m) - x20) / x1;

        /* '<S264>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S264>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S264>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S264>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          /* '<S264>:1:19' elseif x1>0 */
          /* '<S264>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          /* '<S264>:1:21' else */
          /* '<S264>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S264>:1:24' else */
        /* '<S264>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S264>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S232>/MATLAB Function4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function4': '<S265>:1' */
    /* '<S265>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2 - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_i > 0.0F) || (rtb_L0_C1_i < 0.0F))) {
      /* '<S265>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_R0_C0_n) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1_i;
      if (x10 > 0.0F) {
        /* '<S265>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        /* '<S265>:1:9' else */
        /* '<S265>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_i * rtb_L0_C1_i) - ((x10 * 4.0F) * rtb_Add5_n_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S265>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S265>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_i)) / x1;

        /* '<S265>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_i) - x20) / x1;

        /* '<S265>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S265>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S265>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S265>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          /* '<S265>:1:19' elseif x1>0 */
          /* '<S265>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          /* '<S265>:1:21' else */
          /* '<S265>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S265>:1:24' else */
        /* '<S265>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S265>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S232>/MATLAB Function2' incorporates:
     *  Constant: '<S232>/Constant'
     *  Constant: '<S232>/Constant1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function2': '<S263>:1' */
    /* '<S263>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - 2.0F) / rtb_LftTTLC) <= 0.2F) {
      /* '<S263>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, 2.0F);
    } else {
      /* '<S263>:1:4' else */
      /* '<S263>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S263>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_n - 2.0F) / rtb_TTLC_n) <= 0.2F) {
      /* '<S263>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_n = fminf(rtb_TTLC_n, 2.0F);
    } else {
      /* '<S263>:1:10' else */
      /* '<S263>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S263>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_p) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S263>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S263>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_o) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_n)
           / rtb_TTLC_n) <= 0.7F)) && (rtb_TTLC_n <= 1.95F)) {
      /* '<S263>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_n = (rtb_TTLC_n + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S232>/Saturation7' incorporates:
     *  MATLAB Function: '<S232>/MATLAB Function2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S232>/Saturation7' */

    /* Saturate: '<S232>/Saturation8' incorporates:
     *  MATLAB Function: '<S232>/MATLAB Function2'
     */
    if (rtb_TTLC_n > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_n < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_n;
    }

    /* End of Saturate: '<S232>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S89>/Subsystem' incorporates:
     *  EnablePort: '<S97>/Enable'
     */
    /* Abs: '<S227>/Abs' incorporates:
     *  MATLAB Function: '<S97>/DriverSwaTrqAdd'
     */
    rtb_Add5_n_tmp = fabsf(rtb_L0_C0_o);

    /* Abs: '<S227>/Abs1' incorporates:
     *  MATLAB Function: '<S97>/DriverSwaTrqAdd'
     */
    rtb_TTLC_n = fabsf(rtb_R0_C0_n);

    /* End of Outputs for SubSystem: '<S89>/Subsystem' */
    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Sum: '<S227>/Add' incorporates:
     *  Abs: '<S227>/Abs'
     *  Abs: '<S227>/Abs1'
     */
    rtb_TLft = rtb_Add5_n_tmp + rtb_TTLC_n;

    /* Saturate: '<S227>/Saturation' */
    if (rtb_TLft > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_TLft < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_TLft;
    }

    /* End of Saturate: '<S227>/Saturation' */

    /* If: '<S238>/If' incorporates:
     *  Delay: '<S81>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE_o) == 1) {
      /* Outputs for IfAction SubSystem: '<S238>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S241>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_p, &rtb_Merge_o);

      /* End of Outputs for SubSystem: '<S238>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE_o) == 2) {
      /* Outputs for IfAction SubSystem: '<S238>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S240>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_o, &rtb_Merge_o);

      /* End of Outputs for SubSystem: '<S238>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S238>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S242>/Action Port'
       */
      /* Gain: '<S242>/Gain' incorporates:
       *  Sum: '<S242>/Add'
       */
      rtb_Merge_o = (rtb_Add_p + rtb_Add_o) * 0.5F;

      /* End of Outputs for SubSystem: '<S238>/If Action Subsystem3' */
    }

    /* End of If: '<S238>/If' */

    /* Switch: '<S517>/Switch' incorporates:
     *  Constant: '<S556>/Constant'
     *  Constant: '<S557>/Constant'
     *  Gain: '<S556>/Gain'
     *  Gain: '<S557>/Gain'
     *  Sum: '<S556>/Add'
     *  Sum: '<S557>/Add'
     *  Switch: '<S553>/Switch47'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S553>/Switch48' incorporates:
       *  Constant: '<S553>/LLSMConClb3'
       *
       * Block description for '<S553>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S553>/Switch48' */
      rtb_Switch_d = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S553>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S553>/Switch47' incorporates:
         *  Constant: '<S553>/LLSMConClb2'
         *
         * Block description for '<S553>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_d = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S517>/Switch' */

    /* Switch: '<S515>/Switch' incorporates:
     *  Constant: '<S515>/Constant'
     *  Constant: '<S515>/Constant1'
     *  Constant: '<S520>/Constant'
     *  Constant: '<S521>/Constant'
     *  Constant: '<S522>/Constant'
     *  Logic: '<S515>/Logical Operator'
     *  RelationalOperator: '<S520>/Compare'
     *  RelationalOperator: '<S521>/Compare'
     *  RelationalOperator: '<S522>/Compare'
     */
    if (((rtb_IMAPve_d_SAS_Trim_State >= ((uint8)3U)) || (((sint32)
           (rtb_BCM_Left_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) ||
        (((sint32)(rtb_BCM_Right_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) {
      rtb_TLft = 3.0F;
    } else {
      rtb_TLft = (-1.0F);
    }

    /* End of Switch: '<S515>/Switch' */

    /* Sum: '<S515>/Add' incorporates:
     *  Memory: '<S515>/Memory'
     */
    rtb_TLft += LKAS_DW.Memory_PreviousInput_j;

    /* Saturate: '<S515>/Saturation' */
    if (rtb_TLft > 200.0F) {
      rtb_Saturation_c = 200.0F;
    } else if (rtb_TLft < (-1.0F)) {
      rtb_Saturation_c = (-1.0F);
    } else {
      rtb_Saturation_c = rtb_TLft;
    }

    /* End of Saturate: '<S515>/Saturation' */

    /* Abs: '<S509>/Abs1' incorporates:
     *  Abs: '<S416>/Abs1'
     */
    rtb_LftTTLC = fabsf(rtb_LaneWidth);
    rtb_Abs1 = rtb_LftTTLC;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S507>/Abs' incorporates:
     *  Abs: '<S108>/Abs'
     *  Abs: '<S109>/Abs'
     *  Abs: '<S110>/Abs4'
     *  Abs: '<S414>/Abs'
     *  MATLAB Function: '<S381>/MATLAB Function'
     */
    rtb_TTLC = fabsf(rtb_Merge_o);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC;

    /* Switch: '<S553>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S468>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S468>/Unary Minus' incorporates:
       *  Constant: '<S553>/LLSMConClb11'
       *
       * Block description for '<S553>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S553>/Switch53' */

    /* Switch: '<S553>/Switch87' incorporates:
     *  Constant: '<S553>/LLSMConClb8'
     *
     * Block description for '<S553>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S553>/Switch87' */

    /* Switch: '<S553>/Switch49' incorporates:
     *  Constant: '<S553>/LLSMConClb43'
     *
     * Block description for '<S553>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S553>/Switch49' */

    /* Switch: '<S553>/Switch88' incorporates:
     *  Constant: '<S553>/LLSMConClb9'
     *
     * Block description for '<S553>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_TLft = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S553>/Switch88' */

    /* Switch: '<S553>/Switch50' incorporates:
     *  Constant: '<S553>/LLSMConClb10'
     *
     * Block description for '<S553>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      rtb_Gain2_b_0 = LKAS_ConstB.DataTypeConversion17;
    } else {
      rtb_Gain2_b_0 = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S553>/Switch50' */

    /* Abs: '<S505>/Abs' incorporates:
     *  Abs: '<S412>/Abs'
     *  Sum: '<S505>/Add'
     */
    rtb_IMAPve_g_ESC_LatAcc = fabsf(rtb_L0_C1_m - rtb_L0_C1_i);

    /* Abs: '<S468>/Abs2' incorporates:
     *  Abs: '<S255>/Abs2'
     *  Abs: '<S379>/Abs2'
     */
    x1 = fabsf(rtb_IMAPve_g_SW_Angle);

    /* Abs: '<S468>/Abs3' incorporates:
     *  Abs: '<S379>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     *  Inport: '<Root>/IMAPve_g_SW_Angle_Speed'
     */
    rtb_LogicalOperator3_c_tmp = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
      ());

    /* Abs: '<S468>/Abs4' incorporates:
     *  Abs: '<S379>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     *  Inport: '<Root>/IMAPve_g_ESC_LatAcc'
     */
    rtb_LogicalOperator3_c_tmp_0 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc());

    /* Abs: '<S468>/Abs1' incorporates:
     *  Abs: '<S380>/Abs'
     *  Abs: '<S381>/Abs'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S469>/Logical Operator2' incorporates:
     *  Abs: '<S468>/Abs1'
     *  Abs: '<S468>/Abs2'
     *  Abs: '<S468>/Abs3'
     *  Abs: '<S468>/Abs4'
     *  Abs: '<S505>/Abs'
     *  Constant: '<S507>/Constant'
     *  Constant: '<S510>/Constant'
     *  Constant: '<S512>/Constant'
     *  Constant: '<S513>/Constant'
     *  Constant: '<S519>/Constant'
     *  Constant: '<S523>/Constant'
     *  Logic: '<S468>/Logical Operator3'
     *  Logic: '<S474>/FixPt Logical Operator'
     *  Logic: '<S506>/Logical Operator3'
     *  Logic: '<S508>/Logical Operator'
     *  Logic: '<S511>/FixPt Logical Operator'
     *  Logic: '<S514>/FixPt Logical Operator'
     *  Logic: '<S518>/Logical Operator'
     *  Logic: '<S524>/FixPt Logical Operator'
     *  RelationalOperator: '<S468>/Relational Operator'
     *  RelationalOperator: '<S468>/Relational Operator1'
     *  RelationalOperator: '<S468>/Relational Operator2'
     *  RelationalOperator: '<S468>/Relational Operator3'
     *  RelationalOperator: '<S474>/Lower Test'
     *  RelationalOperator: '<S474>/Upper Test'
     *  RelationalOperator: '<S510>/Compare'
     *  RelationalOperator: '<S511>/Lower Test'
     *  RelationalOperator: '<S511>/Upper Test'
     *  RelationalOperator: '<S512>/Compare'
     *  RelationalOperator: '<S513>/Compare'
     *  RelationalOperator: '<S514>/Lower Test'
     *  RelationalOperator: '<S514>/Upper Test'
     *  RelationalOperator: '<S519>/Compare'
     *  RelationalOperator: '<S523>/Compare'
     *  RelationalOperator: '<S524>/Lower Test'
     *  RelationalOperator: '<S524>/Upper Test'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_LogicalOperator3_b5 = ((((((rtb_Gain_j <= rtb_IMAPve_g_ESC_VehSpd) &&
      (rtb_IMAPve_g_ESC_VehSpd <= rtb_Switch_d)) && (rtb_Saturation_c <= 0.0F)) &&
      (rtb_TCU_ActualGear == ((uint8)3U))) && (((((rtb_L0_Q > ((uint8)2U)) &&
      (rtb_R0_Q > ((uint8)2U))) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) &&
      (rtb_Abs1 <= rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) &&
      (rtb_Abs <= rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) && (rtb_IMAPve_g_ESC_LatAcc
      <= 0.025F))) && (((((x1 < x10) && (rtb_LogicalOperator3_c_tmp < x20)) &&
                         (rtb_LKA_Veh2CamW_C < rtb_TLft)) &&
                        (rtb_LogicalOperator3_c_tmp_0 < rtb_Gain2_b_0)) &&
                       ((rtb_UnaryMinus < rtb_IMAPve_g_ESC_LonAcc) &&
                        (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* MATLAB Function: '<S502>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_LKA_EarliestWarnLine_C, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient);

    /* Product: '<S502>/Multiply' */
    rtb_Multiply = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_ThresDet_coefficient;

    /* Switch: '<S504>/Switch' incorporates:
     *  Constant: '<S502>/Constant'
     *  RelationalOperator: '<S504>/UpperRelop'
     */
    if (rtb_Multiply < 0.0F) {
      rtb_Switch_i = 0.0F;
    } else {
      rtb_Switch_i = rtb_Multiply;
    }

    /* End of Switch: '<S504>/Switch' */

    /* Switch: '<S504>/Switch2' incorporates:
     *  RelationalOperator: '<S504>/LowerRelop1'
     */
    if (rtb_Multiply > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_f = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_f = rtb_Switch_i;
    }

    /* End of Switch: '<S504>/Switch2' */

    /* Abs: '<S489>/Abs1' incorporates:
     *  Abs: '<S402>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S489>/Abs2' incorporates:
     *  Abs: '<S402>/Abs1'
     */
    x20 = fabsf(rtb_TTLC_d);

    /* If: '<S469>/If1' incorporates:
     *  Abs: '<S489>/Abs1'
     *  Abs: '<S489>/Abs2'
     *  Constant: '<S476>/Constant'
     *  Constant: '<S491>/Constant'
     *  Constant: '<S492>/Constant'
     *  Constant: '<S497>/Constant'
     *  Constant: '<S498>/Constant'
     *  Constant: '<S499>/Constant'
     *  Constant: '<S500>/Constant'
     *  DataTypeConversion: '<S469>/Cast To Single'
     *  Logic: '<S469>/Logical Operator1'
     *  Logic: '<S486>/Logical Operator'
     *  Logic: '<S488>/Logical Operator'
     *  Logic: '<S489>/Logical Operator'
     *  Logic: '<S490>/Logical Operator'
     *  RelationalOperator: '<S489>/Relational Operator2'
     *  RelationalOperator: '<S489>/Relational Operator3'
     *  RelationalOperator: '<S490>/Relational Operator1'
     *  RelationalOperator: '<S490>/Relational Operator2'
     *  RelationalOperator: '<S491>/Compare'
     *  RelationalOperator: '<S492>/Compare'
     *  RelationalOperator: '<S497>/Compare'
     *  RelationalOperator: '<S498>/Compare'
     *  RelationalOperator: '<S499>/Compare'
     *  RelationalOperator: '<S500>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_LogicalOperator3_b5 &&
         ((((LKAS_DW.LKA_Mode == ((uint8)2U)) && (((sint32)
              (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
                (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) ? 1 : 0)) ==
             ((sint32)(true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1_j >= rtb_Switch2_f) &&
              (rtb_Add5_n >= rtb_Switch2_f)) ? 1 : 0)) == ((sint32)(true ? 1 : 0))))))
    {
      /* Outputs for IfAction SubSystem: '<S469>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S476>/Action Port'
       */
      LKAS_DW.Merge1_a = true;

      /* End of Outputs for SubSystem: '<S469>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S469>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S478>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_a);

      /* End of Outputs for SubSystem: '<S469>/If Action Subsystem4' */
    }

    /* End of If: '<S469>/If1' */

    /* Switch: '<S462>/Switch' incorporates:
     *  Constant: '<S554>/Constant'
     *  Constant: '<S559>/Constant'
     *  Gain: '<S554>/Gain'
     *  Gain: '<S559>/Gain'
     *  Sum: '<S554>/Add'
     *  Sum: '<S559>/Add'
     *  Switch: '<S553>/Switch67'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S553>/Switch80' incorporates:
       *  Constant: '<S553>/LLSMConClb21'
       *
       * Block description for '<S553>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_TLft = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_TLft = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S553>/Switch80' */
      rtb_Switch_h = (rtb_TLft - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S553>/Switch67' */
        rtb_TLft = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S553>/Switch67' incorporates:
         *  Constant: '<S553>/LLSMConClb20'
         *
         * Block description for '<S553>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_TLft = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_h = (rtb_TLft - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S462>/Switch' */

    /* Logic: '<S462>/Logical Operator' incorporates:
     *  Logic: '<S467>/FixPt Logical Operator'
     *  RelationalOperator: '<S467>/Lower Test'
     *  RelationalOperator: '<S467>/Upper Test'
     */
    rtb_LKA_Main_Switch = ((rtb_Gain_g >= rtb_IMAPve_g_ESC_VehSpd) ||
      (rtb_IMAPve_g_ESC_VehSpd >= rtb_Switch_h));

    /* Logic: '<S460>/Logical Operator' incorporates:
     *  Logic: '<S282>/Logical Operator6'
     */
    rtb_LL_SingleLane_Disable_Swt = !rtb_LL_SingleLane_Disable_Swt;

    /* Switch: '<S460>/Switch' incorporates:
     *  Constant: '<S460>/Constant'
     *  Constant: '<S460>/Constant1'
     *  Constant: '<S465>/Constant'
     *  Logic: '<S460>/Logical Operator'
     *  Logic: '<S460>/Logical Operator1'
     *  Logic: '<S460>/Logical Operator2'
     *  Logic: '<S460>/Logical Operator3'
     *  RelationalOperator: '<S465>/Compare'
     */
    if (((rtb_IMAPve_d_SAS_Trim_State >= ((uint8)3U)) || (rtb_BCM_Left_Light &&
          rtb_LL_SingleLane_Disable_Swt)) || (rtb_BCM_Right_Light &&
         rtb_LL_SingleLane_Disable_Swt)) {
      rtb_TLft = 3.0F;
    } else {
      rtb_TLft = (-1.0F);
    }

    /* End of Switch: '<S460>/Switch' */

    /* Sum: '<S460>/Add' incorporates:
     *  Memory: '<S460>/Memory'
     */
    rtb_TLft += LKAS_DW.Memory_PreviousInput_c;

    /* Saturate: '<S460>/Saturation' */
    if (rtb_TLft > 200.0F) {
      rtb_Saturation_f = 200.0F;
    } else if (rtb_TLft < (-1.0F)) {
      rtb_Saturation_f = (-1.0F);
    } else {
      rtb_Saturation_f = rtb_TLft;
    }

    /* End of Saturate: '<S460>/Saturation' */

    /* RelationalOperator: '<S464>/Compare' incorporates:
     *  Constant: '<S464>/Constant'
     */
    rtb_Compare_mw = (rtb_Saturation_f > 1.0F);

    /* RelationalOperator: '<S466>/Compare' incorporates:
     *  Constant: '<S466>/Constant'
     */
    rtb_Compare_ho = (rtb_TCU_ActualGear != ((uint8)3U));

    /* Logic: '<S415>/Logical Operator' incorporates:
     *  Constant: '<S419>/Constant'
     *  Constant: '<S420>/Constant'
     *  RelationalOperator: '<S419>/Compare'
     *  RelationalOperator: '<S420>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_LogicalOperator_iv = ((rtb_L0_Q < ((uint8)3U)) && (rtb_R0_Q < ((uint8)3U)));

    /* Abs: '<S416>/Abs1' */
    rtb_Abs1_m = rtb_LftTTLC;

    /* RelationalOperator: '<S421>/Compare' incorporates:
     *  Constant: '<S421>/Constant'
     *  Logic: '<S422>/FixPt Logical Operator'
     *  RelationalOperator: '<S422>/Lower Test'
     *  RelationalOperator: '<S422>/Upper Test'
     */
    rtb_Compare_bp = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_m) &&
      (rtb_Abs1_m <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S414>/Abs' */
    rtb_Abs_i = rtb_TTLC;

    /* Logic: '<S414>/Logical Operator' incorporates:
     *  Constant: '<S414>/Constant'
     *  Logic: '<S418>/FixPt Logical Operator'
     *  RelationalOperator: '<S418>/Lower Test'
     *  RelationalOperator: '<S418>/Upper Test'
     */
    rtb_LogicalOperator_ix = ((0.0F > rtb_Abs_i) || (rtb_Abs_i >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S417>/Compare' incorporates:
     *  Constant: '<S417>/Constant'
     */
    rtb_Compare_ab = (rtb_IMAPve_g_ESC_LatAcc > 0.04F);

    /* Switch: '<S553>/Switch72' incorporates:
     *  Constant: '<S553>/LLSMConClb26'
     *
     * Block description for '<S553>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_TLft = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S553>/Switch72' */

    /* RelationalOperator: '<S379>/Relational Operator1' */
    rtb_phiSWA_Thres = (x1 >= rtb_TLft);

    /* Switch: '<S553>/Switch74' incorporates:
     *  Constant: '<S553>/LLSMConClb28'
     *
     * Block description for '<S553>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_TLft = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S553>/Switch74' */

    /* RelationalOperator: '<S379>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_LogicalOperator3_c_tmp >= rtb_TLft);

    /* Switch: '<S553>/Switch79' incorporates:
     *  Constant: '<S553>/LLSMConClb29'
     *
     * Block description for '<S553>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_TLft = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S553>/Switch79' */

    /* Logic: '<S379>/Logical Operator1' incorporates:
     *  Constant: '<S382>/Constant'
     *  RelationalOperator: '<S379>/Relational Operator3'
     *  RelationalOperator: '<S382>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_c_tmp_0 >= rtb_TLft) &&
                       (rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)));

    /* Switch: '<S553>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S379>/Unary Minus' */
      rtb_UnaryMinus_n = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S379>/Unary Minus' incorporates:
       *  Constant: '<S553>/LLSMConClb30'
       *
       * Block description for '<S553>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_n = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S553>/Switch61' */

    /* RelationalOperator: '<S383>/Compare' incorporates:
     *  Constant: '<S383>/Constant'
     *  Logic: '<S384>/FixPt Logical Operator'
     *  RelationalOperator: '<S384>/Lower Test'
     *  RelationalOperator: '<S384>/Upper Test'
     */
    rtb_Compare_cwd = (((sint32)(((rtb_UnaryMinus_n < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                       ((sint32)(false ? 1 : 0)));

    /* Switch: '<S380>/Switch' incorporates:
     *  Constant: '<S385>/Constant'
     *  Constant: '<S553>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
     *  RelationalOperator: '<S385>/Compare'
     *  Switch: '<S553>/Switch38'
     *
     * Block description for '<S553>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
     *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      /* Switch: '<S553>/Switch44' incorporates:
       *  Constant: '<S553>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
       *
       * Block description for '<S553>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
       *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
       */
      if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
        rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion8;
      } else {
        rtb_LKA_Veh2CamL_C = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
      }

      /* End of Switch: '<S553>/Switch44' */
    } else if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
      /* Switch: '<S553>/Switch38' */
      rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion6;
    } else {
      rtb_LKA_Veh2CamL_C = LL_RlsDet_tiTrqChkT_DISABLE;
    }

    /* End of Switch: '<S380>/Switch' */

    /* Outputs for Enabled SubSystem: '<S380>/ExitCount' incorporates:
     *  EnablePort: '<S388>/Enable'
     */
    /* RelationalOperator: '<S380>/Relational Operator' */
    if (rtb_LKA_Veh2CamW_C <= rtb_LKA_Veh2CamL_C) {
      if (!LKAS_DW.ExitCount_MODE) {
        /* InitializeConditions for Memory: '<S388>/Memory' */
        LKAS_DW.Memory_PreviousInput_no = 0.0F;
        LKAS_DW.ExitCount_MODE = true;
      }

      /* Sum: '<S388>/Add' incorporates:
       *  Constant: '<S386>/Constant'
       *  Constant: '<S387>/Constant'
       *  Logic: '<S380>/Logical Operator2'
       *  Memory: '<S388>/Memory'
       *  Product: '<S380>/Divide'
       *  RelationalOperator: '<S386>/Compare'
       *  RelationalOperator: '<S387>/Compare'
       */
      rtb_IMAPve_g_ESC_LatAcc = (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
        (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? rtb_LKA_SampleTime : 0.0F)
        + LKAS_DW.Memory_PreviousInput_no;

      /* Saturate: '<S388>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 60.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 60.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S388>/Saturation' */

      /* Switch: '<S553>/Switch3' incorporates:
       *  Constant: '<S553>/LL_RlsDet_tiTDelTime_DISABLE=3'
       *
       * Block description for '<S553>/LL_RlsDet_tiTDelTime_DISABLE=3':
       *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
       */
      if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
        rtb_TLft = LKAS_ConstB.DataTypeConversion3;
      } else {
        rtb_TLft = LL_HandsOff_ExitTime;
      }

      /* End of Switch: '<S553>/Switch3' */

      /* RelationalOperator: '<S388>/Relational Operator' */
      LKAS_DW.RelationalOperator_f = (rtb_IMAPve_g_ESC_LatAcc >= rtb_TLft);

      /* Update for Memory: '<S388>/Memory' */
      LKAS_DW.Memory_PreviousInput_no = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.ExitCount_MODE) {
        /* Disable for Outport: '<S388>/Out' */
        LKAS_DW.RelationalOperator_f = false;
        LKAS_DW.ExitCount_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S380>/Relational Operator' */
    /* End of Outputs for SubSystem: '<S380>/ExitCount' */

    /* Saturate: '<S381>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S389>:1' */
    /* '<S389>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S389>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S389>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S389>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_IMAPve_g_ESC_VehSpd > 80.0F) {
      rtb_TLft = 80.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      rtb_TLft = 60.0F;
    } else {
      rtb_TLft = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S381>/Saturation' */

    /* MATLAB Function: '<S381>/MATLAB Function' */
    if (rtb_LKA_Veh2CamW_C >= fminf(fmaxf(1.5F, ((1.5F *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL) - ((rtb_TLft / 180.0F) *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL)) + (rtb_TTLC / 0.005F)), 2.75F)) {
      /* Outputs for Enabled SubSystem: '<S381>/Sum Condition1' incorporates:
       *  EnablePort: '<S390>/state = reset'
       */
      /* '<S389>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_i) {
        /* InitializeConditions for Memory: '<S390>/Memory' */
        LKAS_DW.Memory_PreviousInput_k = 0.0F;
        LKAS_DW.SumCondition1_MODE_i = true;
      }

      /* Sum: '<S390>/Add1' incorporates:
       *  Memory: '<S390>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_k;

      /* Saturate: '<S390>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 5000.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 5000.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S390>/Saturation' */
      /* End of Outputs for SubSystem: '<S381>/Sum Condition1' */

      /* Switch: '<S553>/Switch65' incorporates:
       *  Constant: '<S553>/LLSMConClb34'
       *
       * Block description for '<S553>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_TLft = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_TLft = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S553>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S381>/Sum Condition1' incorporates:
       *  EnablePort: '<S390>/state = reset'
       */
      /* RelationalOperator: '<S390>/Relational Operator' */
      LKAS_DW.RelationalOperator_n2 = (rtb_IMAPve_g_ESC_LatAcc >= rtb_TLft);

      /* Update for Memory: '<S390>/Memory' */
      LKAS_DW.Memory_PreviousInput_k = rtb_IMAPve_g_ESC_LatAcc;

      /* End of Outputs for SubSystem: '<S381>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S381>/Sum Condition1' incorporates:
       *  EnablePort: '<S390>/state = reset'
       */
      /* '<S389>:1:7' else */
      /* '<S389>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S390>/Out' */
        LKAS_DW.RelationalOperator_n2 = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Outputs for SubSystem: '<S381>/Sum Condition1' */
    }

    /* RelationalOperator: '<S396>/Compare' incorporates:
     *  Constant: '<S396>/Constant'
     */
    rtb_Compare_iz = (((sint32)(LKAS_DW.RelationalOperator_n2 ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S391>/Unit Delay' */
    rtb_UnitDelay_m = LKAS_DW.UnitDelay_DSTATE_i;

    /* If: '<S391>/If' incorporates:
     *  Constant: '<S393>/Constant'
     *  RelationalOperator: '<S392>/FixPt Relational Operator'
     *  UnitDelay: '<S392>/Delay Input1'
     *
     * Block description for '<S392>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if (((sint32)(rtb_Compare_iz ? 1 : 0)) > ((sint32)
         (LKAS_DW.DelayInput1_DSTATE ? 1 : 0))) {
      /* Outputs for IfAction SubSystem: '<S391>/If Action Subsystem' incorporates:
       *  ActionPort: '<S393>/Action Port'
       */
      rtb_Merge_i = true;

      /* End of Outputs for SubSystem: '<S391>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S391>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S394>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_m, &rtb_Merge_i);

      /* End of Outputs for SubSystem: '<S391>/If Action Subsystem3' */
    }

    /* End of If: '<S391>/If' */

    /* Outputs for Enabled SubSystem: '<S391>/Sum Condition1' incorporates:
     *  EnablePort: '<S395>/state = reset'
     */
    if (rtb_Merge_i) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S395>/Memory' */
        LKAS_DW.Memory_PreviousInput_p = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S395>/Add1' incorporates:
       *  Memory: '<S395>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_p;

      /* Saturate: '<S395>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 10.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 10.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S395>/Saturation' */

      /* RelationalOperator: '<S395>/Relational Operator' */
      LKAS_DW.RelationalOperator_a = (rtb_IMAPve_g_ESC_LatAcc <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S395>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S395>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S391>/Sum Condition1' */

    /* Logic: '<S391>/Logical Operator' */
    rtb_RelationalOperator_b = ((LKAS_DW.RelationalOperator_n2) ||
      (LKAS_DW.RelationalOperator_a));

    /* Logic: '<S365>/Logical Operator2' incorporates:
     *  Logic: '<S378>/Logical Operator1'
     *  Logic: '<S379>/Logical Operator'
     *  Logic: '<S413>/Logical Operator3'
     *  Logic: '<S463>/Logical Operator3'
     */
    rtb_LogicalOperator3_pm = ((((rtb_LKA_Main_Switch || rtb_Compare_mw) ||
      rtb_Compare_ho) || (((rtb_LogicalOperator_iv || rtb_Compare_bp) ||
      rtb_LogicalOperator_ix) || rtb_Compare_ab)) || (((((rtb_phiSWA_Thres ||
      rtb_dphiSWARate_Thres) || rtb_aLAcc_Thres) || rtb_Compare_cwd) ||
      (LKAS_DW.RelationalOperator_f)) || rtb_RelationalOperator_b));

    /* Logic: '<S402>/Logical Operator' incorporates:
     *  RelationalOperator: '<S402>/Relational Operator1'
     *  RelationalOperator: '<S402>/Relational Operator2'
     */
    rtb_LogicalOperator_ol = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S403>/Logical Operator' incorporates:
     *  RelationalOperator: '<S403>/Relational Operator1'
     *  RelationalOperator: '<S403>/Relational Operator2'
     */
    rtb_LogicalOperator_m = ((rtb_Gain1_j <= rtb_R0_C2) || (rtb_Add5_n <=
      rtb_R0_C2));

    /* If: '<S365>/If2' incorporates:
     *  Constant: '<S374>/Constant'
     *  Constant: '<S408>/Constant'
     *  Constant: '<S409>/Constant'
     *  Constant: '<S411>/Constant'
     *  DataTypeConversion: '<S365>/Cast To Single'
     *  Logic: '<S365>/Logical Operator1'
     *  Logic: '<S401>/Logical Operator'
     *  Logic: '<S401>/Logical Operator1'
     *  RelationalOperator: '<S408>/Compare'
     *  RelationalOperator: '<S409>/Compare'
     *  RelationalOperator: '<S411>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_LogicalOperator3_pm ||
         ((LKAS_DW.LKA_Mode == ((uint8)2U)) && ((rtb_LogicalOperator_ol == true)
           || (rtb_LogicalOperator_m == true))))) {
      /* Outputs for IfAction SubSystem: '<S365>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S374>/Action Port'
       */
      LKAS_DW.Merge2 = true;

      /* End of Outputs for SubSystem: '<S365>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S365>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S376>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2);

      /* End of Outputs for SubSystem: '<S365>/If Action Subsystem3' */
    }

    /* End of If: '<S365>/If2' */

    /* Product: '<S280>/Divide' */
    rtb_LKA_Veh2CamL_C = rtb_L0_C1_m * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S280>/Divide1' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1_i;

    /* If: '<S302>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S302>/Ph1SWA' incorporates:
       *  ActionPort: '<S306>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_k);

      /* End of Outputs for SubSystem: '<S302>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S302>/Ph2SWA' incorporates:
       *  ActionPort: '<S307>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_k);

      /* End of Outputs for SubSystem: '<S302>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S302>/Ph3SWA' incorporates:
       *  ActionPort: '<S308>/Action Port'
       */
      LKAS_Ph3SWA_f(&rtb_Merge1_k);

      /* End of Outputs for SubSystem: '<S302>/Ph3SWA' */
    }

    /* End of If: '<S302>/If' */

    /* Saturate: '<S280>/Saturation5' */
    if (rtb_Gain1_j > 2.0F) {
      rtb_IMAPve_g_ESC_LatAcc = 2.0F;
    } else if (rtb_Gain1_j < (-2.0F)) {
      rtb_IMAPve_g_ESC_LatAcc = (-2.0F);
    } else {
      rtb_IMAPve_g_ESC_LatAcc = rtb_Gain1_j;
    }

    /* End of Saturate: '<S280>/Saturation5' */

    /* MATLAB Function: '<S289>/MATLAB Function' incorporates:
     *  MATLAB Function: '<S325>/MATLAB Function'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S292>:1' */
    /* '<S292>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S292>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S292>:1:5' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S292>:1:6' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S292>:1:7' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    x20 = (2.0F * rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth;
    x20 = fminf(fmaxf(0.0F, (fminf(fmaxf(x20, rtb_LaneWidth), (6.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth) - x20) / (4.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW)), 1.0F);

    /* Product: '<S289>/Divide5' incorporates:
     *  MATLAB Function: '<S289>/MATLAB Function'
     */
    rtb_ThresDet_coefficient_a = x20 * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S289>/Divide6' incorporates:
     *  MATLAB Function: '<S289>/MATLAB Function'
     */
    rtb_TLft = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S304>/Abs' incorporates:
     *  Abs: '<S295>/Abs'
     */
    rtb_LogicalOperator3_c_tmp = fabsf(rtb_LKA_Veh2CamL_C);

    /* Product: '<S304>/Divide' incorporates:
     *  Abs: '<S304>/Abs'
     */
    rtb_Divide_b = rtb_TLft * rtb_LogicalOperator3_c_tmp;

    /* Product: '<S289>/Divide4' incorporates:
     *  MATLAB Function: '<S289>/MATLAB Function'
     */
    rtb_TTLC_d = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S309>/Switch' incorporates:
     *  RelationalOperator: '<S309>/UpperRelop'
     */
    if (rtb_Divide_b < rtb_TTLC_d) {
      rtb_Switch_c = rtb_TTLC_d;
    } else {
      rtb_Switch_c = rtb_Divide_b;
    }

    /* End of Switch: '<S309>/Switch' */

    /* Switch: '<S309>/Switch2' incorporates:
     *  RelationalOperator: '<S309>/LowerRelop1'
     */
    if (rtb_Divide_b > rtb_ThresDet_coefficient_a) {
      rtb_Switch2_o = rtb_ThresDet_coefficient_a;
    } else {
      rtb_Switch2_o = rtb_Switch_c;
    }

    /* End of Switch: '<S309>/Switch2' */

    /* Saturate: '<S280>/Saturation1' */
    if (rtb_Add5_n > 2.0F) {
      rtb_LKA_Veh2CamW_C = 2.0F;
    } else if (rtb_Add5_n < (-2.0F)) {
      rtb_LKA_Veh2CamW_C = (-2.0F);
    } else {
      rtb_LKA_Veh2CamW_C = rtb_Add5_n;
    }

    /* End of Saturate: '<S280>/Saturation1' */

    /* Abs: '<S305>/Abs' incorporates:
     *  Abs: '<S296>/Abs'
     */
    rtb_LogicalOperator3_c_tmp_0 = fabsf(rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Product: '<S305>/Divide' incorporates:
     *  Abs: '<S305>/Abs'
     */
    rtb_Divide_ba = rtb_TLft * rtb_LogicalOperator3_c_tmp_0;

    /* Switch: '<S310>/Switch' incorporates:
     *  RelationalOperator: '<S310>/UpperRelop'
     */
    if (rtb_Divide_ba < rtb_TTLC_d) {
      rtb_Switch_n = rtb_TTLC_d;
    } else {
      rtb_Switch_n = rtb_Divide_ba;
    }

    /* End of Switch: '<S310>/Switch' */

    /* Switch: '<S310>/Switch2' incorporates:
     *  RelationalOperator: '<S310>/LowerRelop1'
     */
    if (rtb_Divide_ba > rtb_ThresDet_coefficient_a) {
      rtb_Switch2_n = rtb_ThresDet_coefficient_a;
    } else {
      rtb_Switch2_n = rtb_Switch_n;
    }

    /* End of Switch: '<S310>/Switch2' */

    /* Switch: '<S303>/Switch3' incorporates:
     *  Constant: '<S305>/Constant'
     *  Gain: '<S303>/Gain1'
     *  Logic: '<S305>/Logical Operator'
     *  RelationalOperator: '<S305>/Relational Operator1'
     *  RelationalOperator: '<S305>/Relational Operator2'
     */
    if (rtb_Merge1_k >= 0.0F) {
      /* Switch: '<S303>/Switch2' incorporates:
       *  Constant: '<S303>/Constant2'
       *  Constant: '<S304>/Constant'
       *  DataTypeConversion: '<S303>/Cast To Single'
       *  Logic: '<S304>/Logical Operator'
       *  RelationalOperator: '<S304>/Relational Operator1'
       *  RelationalOperator: '<S304>/Relational Operator3'
       */
      if (rtb_Merge1_k > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_IMAPve_g_ESC_LatAcc) &&
          (rtb_IMAPve_g_ESC_LatAcc <= rtb_Switch2_o)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S303>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F < rtb_LKA_Veh2CamW_C) &&
        (rtb_LKA_Veh2CamW_C <= rtb_Switch2_n)) ? 1 : 0)) * ((uint32)((uint8)128U)))
        >> 6);
    }

    /* End of Switch: '<S303>/Switch3' */

    /* DataTypeConversion: '<S282>/Data Type Conversion' incorporates:
     *  Constant: '<S313>/Constant'
     *  Constant: '<S314>/Constant'
     *  Constant: '<S315>/Constant'
     *  Constant: '<S316>/Constant'
     *  Logic: '<S282>/Logical Operator'
     *  Logic: '<S282>/Logical Operator1'
     *  Logic: '<S282>/Logical Operator2'
     *  Logic: '<S282>/Logical Operator3'
     *  Logic: '<S282>/Logical Operator4'
     *  Logic: '<S282>/Logical Operator5'
     *  Logic: '<S282>/Logical Operator7'
     *  RelationalOperator: '<S313>/Compare'
     *  RelationalOperator: '<S314>/Compare'
     *  RelationalOperator: '<S315>/Compare'
     *  RelationalOperator: '<S316>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_IMAPve_d_SAS_Trim_State = (uint8)(((((rtb_LL_SingleLane_Disable_Swt || (
      !rtb_BCM_Right_Light)) && (rtb_R0_Q > ((uint8)2U))) && (rtb_TCU_ActualGear
      == ((uint8)2U))) || (((rtb_LL_SingleLane_Disable_Swt ||
      (!rtb_BCM_Left_Light)) && (rtb_TCU_ActualGear == ((uint8)1U))) &&
      (rtb_L0_Q > ((uint8)2U)))) ? 1 : 0);

    /* DataTypeConversion: '<S281>/Data Type Conversion' incorporates:
     *  Constant: '<S311>/Constant'
     *  Constant: '<S312>/Constant'
     *  Logic: '<S281>/Logical Operator'
     *  RelationalOperator: '<S311>/Compare'
     *  RelationalOperator: '<S312>/Compare'
     */
    rtb_CastToSingle3 = (uint8)(((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
      (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? 1 : 0);

    /* If: '<S279>/If1' incorporates:
     *  Constant: '<S284>/Constant'
     *  Constant: '<S287>/Constant'
     *  Constant: '<S288>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)rtb_TCU_ActualGear) ==
           1)) && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S279>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S287>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S279>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)
        rtb_TCU_ActualGear) == 2)) && (((sint32)rtb_CastToSingle3) == 1)) &&
               (((sint32)rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S279>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S288>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S279>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S279>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S284>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S279>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S279>/If1' */

    /* Product: '<S318>/Divide' */
    rtb_TTLC_d = rtb_L0_C1_m * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S318>/Divide1' */
    rtb_Gain2_b_0 = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1_i;

    /* If: '<S339>/If' incorporates:
     *  Product: '<S318>/Divide1'
     */
    if ((rtb_TTLC_d >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Gain2_b_0 >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S339>/Ph1SWA' incorporates:
       *  ActionPort: '<S343>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_f);

      /* End of Outputs for SubSystem: '<S339>/Ph1SWA' */
    } else if ((rtb_TTLC_d <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) ||
               (rtb_Gain2_b_0 <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S339>/Ph2SWA' incorporates:
       *  ActionPort: '<S344>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_f);

      /* End of Outputs for SubSystem: '<S339>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S339>/Ph3SWA' incorporates:
       *  ActionPort: '<S345>/Action Port'
       */
      LKAS_Ph3SWA_f(&rtb_Merge1_f);

      /* End of Outputs for SubSystem: '<S339>/Ph3SWA' */
    }

    /* End of If: '<S339>/If' */

    /* Saturate: '<S318>/Saturation5' */
    if (rtb_Gain1_j > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_Gain1_j < (-2.0F)) {
      rtb_LftTTLC = (-2.0F);
    } else {
      rtb_LftTTLC = rtb_Gain1_j;
    }

    /* End of Saturate: '<S318>/Saturation5' */

    /* Product: '<S325>/Divide5' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S328>:1' */
    /* '<S328>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S328>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S328>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S328>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S328>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_TLft = x20 * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S325>/Divide6' */
    rtb_ThresDet_coefficient_a = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S341>/Divide' incorporates:
     *  Abs: '<S341>/Abs'
     */
    rtb_Divide_d = rtb_ThresDet_coefficient_a * fabsf(rtb_TTLC_d);

    /* Product: '<S325>/Divide4' */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S346>/Switch' incorporates:
     *  RelationalOperator: '<S346>/UpperRelop'
     */
    if (rtb_Divide_d < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_gw = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_gw = rtb_Divide_d;
    }

    /* End of Switch: '<S346>/Switch' */

    /* Switch: '<S346>/Switch2' incorporates:
     *  RelationalOperator: '<S346>/LowerRelop1'
     */
    if (rtb_Divide_d > rtb_TLft) {
      rtb_Switch2_d = rtb_TLft;
    } else {
      rtb_Switch2_d = rtb_Switch_gw;
    }

    /* End of Switch: '<S346>/Switch2' */

    /* Saturate: '<S318>/Saturation1' */
    if (rtb_Add5_n > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_n < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_n;
    }

    /* End of Saturate: '<S318>/Saturation1' */

    /* Product: '<S342>/Divide' incorporates:
     *  Abs: '<S342>/Abs'
     *  Product: '<S318>/Divide1'
     */
    rtb_Divide_f = rtb_ThresDet_coefficient_a * fabsf(rtb_Gain2_b_0);

    /* Switch: '<S347>/Switch' incorporates:
     *  RelationalOperator: '<S347>/UpperRelop'
     */
    if (rtb_Divide_f < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_gi = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_gi = rtb_Divide_f;
    }

    /* End of Switch: '<S347>/Switch' */

    /* Switch: '<S347>/Switch2' incorporates:
     *  RelationalOperator: '<S347>/LowerRelop1'
     */
    if (rtb_Divide_f > rtb_TLft) {
      rtb_Switch2_fg = rtb_TLft;
    } else {
      rtb_Switch2_fg = rtb_Switch_gi;
    }

    /* End of Switch: '<S347>/Switch2' */

    /* Switch: '<S340>/Switch3' incorporates:
     *  Constant: '<S342>/Constant'
     *  Gain: '<S340>/Gain1'
     *  Logic: '<S342>/Logical Operator'
     *  RelationalOperator: '<S342>/Relational Operator1'
     *  RelationalOperator: '<S342>/Relational Operator2'
     */
    if (rtb_Merge1_f >= 0.0F) {
      /* Switch: '<S340>/Switch2' incorporates:
       *  Constant: '<S340>/Constant2'
       *  Constant: '<S341>/Constant'
       *  DataTypeConversion: '<S340>/Cast To Single'
       *  Logic: '<S341>/Logical Operator'
       *  RelationalOperator: '<S341>/Relational Operator1'
       *  RelationalOperator: '<S341>/Relational Operator3'
       */
      if (rtb_Merge1_f > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_LftTTLC) && (rtb_LftTTLC <=
          rtb_Switch2_d)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S340>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F <
        rtb_LL_ThresDet_lDvtThresLwrLKA) && (rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_fg)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S340>/Switch3' */

    /* MATLAB Function: '<S319>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S351>:1' */
    /* '<S351>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S351>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S351>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S351>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_IMAPve_g_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge_o), 0.005F)) / 0.005F);

    /* '<S351>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_TCU_ActualGear) == 2) && (rtb_IMAPve_g_EPS_SW_Trq >
          rtb_LL_MAX_DRIVER_TORQUE_DISABL)) || ((((sint32)rtb_TCU_ActualGear) ==
          1) && (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL))))
    {
      /* Outputs for Enabled SubSystem: '<S319>/Count 0.2s' incorporates:
       *  EnablePort: '<S350>/Enable'
       */
      /* '<S351>:1:7' stDvrTkConFlg=1; */
      /* '<S351>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S351>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S350>/Memory' */
        LKAS_DW.Memory_PreviousInput_m5 = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S350>/Add' incorporates:
       *  Memory: '<S350>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_m5;

      /* Saturate: '<S350>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S350>/Saturation' */
      /* End of Outputs for SubSystem: '<S319>/Count 0.2s' */

      /* Switch: '<S553>/Switch16' incorporates:
       *  Constant: '<S553>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S553>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S553>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S319>/Count 0.2s' incorporates:
       *  EnablePort: '<S350>/Enable'
       */
      /* RelationalOperator: '<S350>/Relational Operator' */
      LKAS_DW.RelationalOperator_l1 = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S350>/Memory' */
      LKAS_DW.Memory_PreviousInput_m5 = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S319>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S319>/Count 0.2s' incorporates:
       *  EnablePort: '<S350>/Enable'
       */
      /* '<S351>:1:10' else */
      /* '<S351>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S350>/Out' */
        LKAS_DW.RelationalOperator_l1 = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S319>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S319>/MATLAB Function' */

    /* RelationalOperator: '<S360>/Compare' incorporates:
     *  Constant: '<S360>/Constant'
     */
    rtb_Compare_km = (((sint32)(LKAS_DW.RelationalOperator_l1 ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S352>/Unit Delay' */
    rtb_UnitDelay_h = LKAS_DW.UnitDelay_DSTATE_gu;

    /* RelationalOperator: '<S359>/Compare' incorporates:
     *  Constant: '<S359>/Constant'
     */
    rtb_Compare_cj = (((sint32)(rtb_UnitDelay_h ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S352>/If' incorporates:
     *  Constant: '<S355>/Constant'
     *  Constant: '<S356>/Constant'
     *  RelationalOperator: '<S353>/FixPt Relational Operator'
     *  RelationalOperator: '<S354>/FixPt Relational Operator'
     *  UnitDelay: '<S353>/Delay Input1'
     *  UnitDelay: '<S354>/Delay Input1'
     *
     * Block description for '<S353>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S354>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_l1) && (((sint32)(rtb_Compare_km ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_c ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S352>/If Action Subsystem' incorporates:
       *  ActionPort: '<S355>/Action Port'
       */
      rtb_Merge_c = true;

      /* End of Outputs for SubSystem: '<S352>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_h) && (((sint32)(rtb_Compare_cj ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_p ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S352>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S356>/Action Port'
       */
      rtb_Merge_c = false;

      /* End of Outputs for SubSystem: '<S352>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S352>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S357>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_h, &rtb_Merge_c);

      /* End of Outputs for SubSystem: '<S352>/If Action Subsystem3' */
    }

    /* End of If: '<S352>/If' */

    /* Outputs for Enabled SubSystem: '<S319>/Count' incorporates:
     *  EnablePort: '<S349>/Enable'
     */
    /* Logic: '<S319>/Logical Operator' incorporates:
     *  Constant: '<S348>/Constant'
     *  Memory: '<S319>/Memory'
     *  RelationalOperator: '<S348>/Compare'
     */
    if ((rtb_TCU_ActualGear > ((uint8)0U)) && (LKAS_DW.Memory_PreviousInput_eq))
    {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S349>/Memory' */
        LKAS_DW.Memory_PreviousInput_o = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S349>/Add' incorporates:
       *  Memory: '<S349>/Memory'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_o;

      /* Saturate: '<S349>/Saturation' */
      if (rtb_TLft > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_TLft;
      }

      /* End of Saturate: '<S349>/Saturation' */

      /* Update for Memory: '<S349>/Memory' */
      LKAS_DW.Memory_PreviousInput_o = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S349>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S319>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S319>/Count' */

    /* Outputs for Enabled SubSystem: '<S352>/Sum Condition1' incorporates:
     *  EnablePort: '<S358>/state = reset'
     */
    if (rtb_Merge_c) {
      if (!LKAS_DW.SumCondition1_MODE_f) {
        /* InitializeConditions for Memory: '<S358>/Memory' */
        LKAS_DW.Memory_PreviousInput_n2 = 0.0F;
        LKAS_DW.SumCondition1_MODE_f = true;
      }

      /* Sum: '<S358>/Add1' incorporates:
       *  Memory: '<S358>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_n2;

      /* Saturate: '<S358>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 5.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 5.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S358>/Saturation' */

      /* Switch: '<S553>/Switch40' incorporates:
       *  Constant: '<S553>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S553>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S553>/Switch40' */

      /* RelationalOperator: '<S358>/Relational Operator' incorporates:
       *  Sum: '<S319>/Add'
       */
      LKAS_DW.RelationalOperator_c = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S358>/Memory' */
      LKAS_DW.Memory_PreviousInput_n2 = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_f) {
        /* Disable for Outport: '<S358>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_f = false;
      }
    }

    /* End of Outputs for SubSystem: '<S352>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S320>/Sum Condition1' incorporates:
     *  EnablePort: '<S364>/state = reset'
     */
    /* Logic: '<S320>/Logical Operator' incorporates:
     *  Constant: '<S362>/Constant'
     *  Constant: '<S363>/Constant'
     *  Delay: '<S82>/Delay1'
     *  RelationalOperator: '<S362>/Compare'
     *  RelationalOperator: '<S363>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_b) {
        /* InitializeConditions for Memory: '<S364>/Memory' */
        LKAS_DW.Memory_PreviousInput_cp = 0.0F;
        LKAS_DW.SumCondition1_MODE_b = true;
      }

      /* Sum: '<S364>/Add1' incorporates:
       *  Memory: '<S364>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_cp;

      /* Saturate: '<S364>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S364>/Saturation' */

      /* RelationalOperator: '<S364>/Relational Operator' */
      LKAS_DW.RelationalOperator_l = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S364>/Memory' */
      LKAS_DW.Memory_PreviousInput_cp = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S364>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }
    }

    /* End of Logic: '<S320>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S320>/Sum Condition1' */

    /* If: '<S317>/If1' incorporates:
     *  Constant: '<S322>/Constant'
     *  Constant: '<S324>/Constant'
     *  Constant: '<S361>/Constant'
     *  Delay: '<S82>/Delay'
     *  Logic: '<S317>/Logical Operator'
     *  Logic: '<S320>/Logical Operator1'
     *  RelationalOperator: '<S361>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((LKAS_DW.RelationalOperator_c) ||
          ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_l))) || (LKAS_DW.Delay_DSTATE_j))) {
      /* Outputs for IfAction SubSystem: '<S317>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S324>/Action Port'
       */
      LKAS_DW.Merge1_c = true;

      /* End of Outputs for SubSystem: '<S317>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S317>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S322>/Action Port'
       */
      LKAS_DW.Merge1_c = false;

      /* End of Outputs for SubSystem: '<S317>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S317>/If1' */

    /* MATLAB Function: '<S483>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_ThresDet_lDvtThresUprLDW, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient_a);

    /* Product: '<S483>/Multiply' */
    rtb_Multiply_d = rtb_LL_ThresDet_lDvtThresUprLDW *
      rtb_ThresDet_coefficient_a;

    /* Switch: '<S485>/Switch' incorporates:
     *  Constant: '<S483>/Constant'
     *  RelationalOperator: '<S485>/UpperRelop'
     */
    if (rtb_Multiply_d < 0.0F) {
      rtb_Switch_p = 0.0F;
    } else {
      rtb_Switch_p = rtb_Multiply_d;
    }

    /* End of Switch: '<S485>/Switch' */

    /* Switch: '<S485>/Switch2' incorporates:
     *  RelationalOperator: '<S485>/LowerRelop1'
     */
    if (rtb_Multiply_d > rtb_LL_ThresDet_lDvtThresUprLDW) {
      rtb_Switch2_c = rtb_LL_ThresDet_lDvtThresUprLDW;
    } else {
      rtb_Switch2_c = rtb_Switch_p;
    }

    /* End of Switch: '<S485>/Switch2' */

    /* Logic: '<S469>/Logical Operator3' incorporates:
     *  Constant: '<S481>/Constant'
     *  Constant: '<S482>/Constant'
     *  Logic: '<S479>/Logical Operator'
     *  Logic: '<S480>/Logical Operator'
     *  RelationalOperator: '<S480>/Relational Operator1'
     *  RelationalOperator: '<S480>/Relational Operator2'
     *  RelationalOperator: '<S481>/Compare'
     *  RelationalOperator: '<S482>/Compare'
     */
    rtb_LogicalOperator3_b5 = (((LKAS_DW.LKA_Mode >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1_j >= rtb_Switch2_c) && (rtb_Add5_n >= rtb_Switch2_c)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_b5);

    /* If: '<S469>/If' incorporates:
     *  Constant: '<S475>/Constant'
     *  DataTypeConversion: '<S469>/Cast To Single'
     *  DataTypeConversion: '<S469>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_LogicalOperator3_b5) {
      /* Outputs for IfAction SubSystem: '<S469>/If Action Subsystem' incorporates:
       *  ActionPort: '<S475>/Action Port'
       */
      LKAS_DW.Merge_e = true;

      /* End of Outputs for SubSystem: '<S469>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S469>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S477>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_e);

      /* End of Outputs for SubSystem: '<S469>/If Action Subsystem3' */
    }

    /* End of If: '<S469>/If' */

    /* Delay: '<S82>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S367>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S367>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_id != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S367>/If Action Subsystem' incorporates:
         *  ActionPort: '<S397>/Action Port'
         */
        /* InitializeConditions for If: '<S367>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S397>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_n = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S367>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S367>/If Action Subsystem' incorporates:
       *  ActionPort: '<S397>/Action Port'
       */
      /* Sum: '<S397>/Add1' incorporates:
       *  Memory: '<S397>/Memory'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_n;

      /* Saturate: '<S397>/Saturation' */
      if (rtb_LL_TkOvStChk_tiTDelTime > 10.0F) {
        rtb_LL_TkOvStChk_tiTDelTime = 10.0F;
      } else {
        if (rtb_LL_TkOvStChk_tiTDelTime < 0.0F) {
          rtb_LL_TkOvStChk_tiTDelTime = 0.0F;
        }
      }

      /* End of Saturate: '<S397>/Saturation' */
      /* End of Outputs for SubSystem: '<S367>/If Action Subsystem' */

      /* Switch: '<S553>/Switch64' incorporates:
       *  Constant: '<S553>/LLSMConClb33'
       *
       * Block description for '<S553>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S553>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S367>/If Action Subsystem' incorporates:
       *  ActionPort: '<S397>/Action Port'
       */
      /* RelationalOperator: '<S397>/Relational Operator' */
      rtb_Merge = (rtb_LL_TkOvStChk_tiTDelTime >= x10);

      /* Update for Memory: '<S397>/Memory' */
      LKAS_DW.Memory_PreviousInput_n = rtb_LL_TkOvStChk_tiTDelTime;

      /* End of Outputs for SubSystem: '<S367>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S367>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S398>/Action Port'
       */
      /* SignalConversion: '<S398>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S398>/Constant'
       */
      rtb_Merge = false;

      /* End of Outputs for SubSystem: '<S367>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S367>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S368>/Logical Operator1' incorporates:
     *  Constant: '<S399>/Constant'
     *  Logic: '<S368>/Logical Operator'
     *  RelationalOperator: '<S368>/Relational Operator1'
     *  RelationalOperator: '<S368>/Relational Operator2'
     *  RelationalOperator: '<S399>/Compare'
     */
    rtb_BCM_Left_Light = ((LKAS_DW.LKA_Mode >= ((uint8)1U)) && ((rtb_Gain1_j <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_n <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S365>/Logical Operator3' */
    rtb_LogicalOperator3_pm = ((rtb_BCM_Left_Light || rtb_Merge) ||
      rtb_LogicalOperator3_pm);

    /* If: '<S365>/If1' incorporates:
     *  Constant: '<S375>/Constant'
     *  DataTypeConversion: '<S365>/Cast To Single'
     *  DataTypeConversion: '<S365>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_LogicalOperator3_pm) {
      /* Outputs for IfAction SubSystem: '<S365>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S375>/Action Port'
       */
      LKAS_DW.Merge1_i = true;

      /* End of Outputs for SubSystem: '<S365>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S365>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S377>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_i);

      /* End of Outputs for SubSystem: '<S365>/If Action Subsystem4' */
    }

    /* End of If: '<S365>/If1' */

    /* Memory: '<S293>/Memory' */
    rtb_Memory_e = LKAS_DW.Memory_PreviousInput_i;

    /* If: '<S293>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S293>/Ph1SWA' incorporates:
       *  ActionPort: '<S297>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S293>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S293>/Ph2SWA' incorporates:
       *  ActionPort: '<S298>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S293>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S293>/Ph3SWA' incorporates:
       *  ActionPort: '<S299>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_e, &rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S293>/Ph3SWA' */
    }

    /* End of If: '<S293>/If' */

    /* Product: '<S289>/Divide2' incorporates:
     *  MATLAB Function: '<S289>/MATLAB Function'
     */
    rtb_LL_LDW_LatestWarnLine_C = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S289>/Divide3' incorporates:
     *  MATLAB Function: '<S289>/MATLAB Function'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S295>/Divide' */
    rtb_Divide_k = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LogicalOperator3_c_tmp;

    /* Product: '<S289>/Divide1' incorporates:
     *  MATLAB Function: '<S289>/MATLAB Function'
     */
    rtb_TLft = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S300>/Switch' incorporates:
     *  RelationalOperator: '<S300>/UpperRelop'
     */
    if (rtb_Divide_k < rtb_TLft) {
      rtb_Switch_a = rtb_TLft;
    } else {
      rtb_Switch_a = rtb_Divide_k;
    }

    /* End of Switch: '<S300>/Switch' */

    /* Switch: '<S300>/Switch2' incorporates:
     *  RelationalOperator: '<S300>/LowerRelop1'
     */
    if (rtb_Divide_k > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_j = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_j = rtb_Switch_a;
    }

    /* End of Switch: '<S300>/Switch2' */

    /* Product: '<S296>/Divide' */
    rtb_Divide_kp = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LogicalOperator3_c_tmp_0;

    /* Switch: '<S301>/Switch' incorporates:
     *  RelationalOperator: '<S301>/UpperRelop'
     */
    if (rtb_Divide_kp < rtb_TLft) {
      rtb_Switch_o = rtb_TLft;
    } else {
      rtb_Switch_o = rtb_Divide_kp;
    }

    /* End of Switch: '<S301>/Switch' */

    /* Switch: '<S301>/Switch2' incorporates:
     *  RelationalOperator: '<S301>/LowerRelop1'
     */
    if (rtb_Divide_kp > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_jh = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_jh = rtb_Switch_o;
    }

    /* End of Switch: '<S301>/Switch2' */

    /* Switch: '<S294>/Switch3' incorporates:
     *  Gain: '<S294>/Gain1'
     *  RelationalOperator: '<S296>/Relational Operator2'
     */
    if (rtb_Merge1_n >= 0.0F) {
      /* Switch: '<S294>/Switch2' incorporates:
       *  Constant: '<S294>/Constant2'
       *  DataTypeConversion: '<S294>/Cast To Single'
       *  RelationalOperator: '<S295>/Relational Operator2'
       */
      if (rtb_Merge1_n > 0.0F) {
        rtb_CastToSingle3 = (uint8)((rtb_IMAPve_g_ESC_LatAcc <= rtb_Switch2_j) ?
          1 : 0);
      } else {
        rtb_CastToSingle3 = ((uint8)0U);
      }

      /* End of Switch: '<S294>/Switch2' */
    } else {
      rtb_CastToSingle3 = (uint8)((((uint32)((rtb_LKA_Veh2CamW_C <=
        rtb_Switch2_jh) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S294>/Switch3' */

    /* If: '<S279>/If' incorporates:
     *  Constant: '<S283>/Constant'
     *  Constant: '<S285>/Constant'
     *  Constant: '<S286>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
         && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S279>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S285>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S279>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
      == 2)) && (((sint32)rtb_CastToSingle3) == 2)) && (((sint32)
                 rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S279>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S286>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S279>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S279>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S283>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S279>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S279>/If' */

    /* Memory: '<S329>/Memory' */
    rtb_Memory_p = LKAS_DW.Memory_PreviousInput_a;

    /* If: '<S329>/If' incorporates:
     *  Product: '<S318>/Divide1'
     */
    if ((rtb_TTLC_d >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Gain2_b_0 >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S329>/Ph1SWA' incorporates:
       *  ActionPort: '<S333>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S329>/Ph1SWA' */
    } else if ((rtb_TTLC_d <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_Gain2_b_0 <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S329>/Ph2SWA' incorporates:
       *  ActionPort: '<S334>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S329>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S329>/Ph3SWA' incorporates:
       *  ActionPort: '<S335>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_p, &rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S329>/Ph3SWA' */
    }

    /* End of If: '<S329>/If' */

    /* Product: '<S325>/Divide2' */
    rtb_LL_LDW_LatestWarnLine_C = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S325>/Divide3' */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Abs: '<S331>/Abs' */
    rtb_TTLC_d = fabsf(rtb_TTLC_d);

    /* Product: '<S331>/Divide' */
    rtb_Divide_bk = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_TTLC_d;

    /* Product: '<S325>/Divide1' */
    rtb_TTLC_d = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S337>/Switch' incorporates:
     *  RelationalOperator: '<S337>/UpperRelop'
     */
    if (rtb_Divide_bk < rtb_TTLC_d) {
      rtb_Switch_gl = rtb_TTLC_d;
    } else {
      rtb_Switch_gl = rtb_Divide_bk;
    }

    /* End of Switch: '<S337>/Switch' */

    /* Switch: '<S337>/Switch2' incorporates:
     *  RelationalOperator: '<S337>/LowerRelop1'
     */
    if (rtb_Divide_bk > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_nc = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_nc = rtb_Switch_gl;
    }

    /* End of Switch: '<S337>/Switch2' */

    /* Product: '<S332>/Divide' incorporates:
     *  Abs: '<S332>/Abs'
     *  Product: '<S318>/Divide1'
     */
    rtb_Divide_h = rtb_LL_ThresDet_lDvtThresUprLKA * fabsf(rtb_Gain2_b_0);

    /* Switch: '<S338>/Switch' incorporates:
     *  RelationalOperator: '<S338>/UpperRelop'
     */
    if (rtb_Divide_h < rtb_TTLC_d) {
      rtb_Switch_e = rtb_TTLC_d;
    } else {
      rtb_Switch_e = rtb_Divide_h;
    }

    /* End of Switch: '<S338>/Switch' */

    /* Switch: '<S338>/Switch2' incorporates:
     *  RelationalOperator: '<S338>/LowerRelop1'
     */
    if (rtb_Divide_h > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_g = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_g = rtb_Switch_e;
    }

    /* End of Switch: '<S338>/Switch2' */

    /* Switch: '<S330>/Switch3' incorporates:
     *  Gain: '<S330>/Gain1'
     *  RelationalOperator: '<S332>/Relational Operator2'
     */
    if (rtb_Merge1_j >= 0.0F) {
      /* Switch: '<S330>/Switch2' incorporates:
       *  Constant: '<S330>/Constant2'
       *  DataTypeConversion: '<S330>/Cast To Single'
       *  RelationalOperator: '<S331>/Relational Operator2'
       */
      if (rtb_Merge1_j > 0.0F) {
        rtb_IMAPve_d_SAS_Trim_State = (uint8)((rtb_LftTTLC <= rtb_Switch2_nc) ?
          1 : 0);
      } else {
        rtb_IMAPve_d_SAS_Trim_State = ((uint8)0U);
      }

      /* End of Switch: '<S330>/Switch2' */
    } else {
      rtb_IMAPve_d_SAS_Trim_State = (uint8)((((uint32)
        ((rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_g) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S330>/Switch3' */

    /* Outputs for Enabled SubSystem: '<S330>/Sum Condition' incorporates:
     *  EnablePort: '<S336>/Enable'
     */
    if (((sint32)rtb_IMAPve_d_SAS_Trim_State) > 0) {
      if (!LKAS_DW.SumCondition_MODE) {
        /* InitializeConditions for Memory: '<S336>/Memory' */
        LKAS_DW.Memory_PreviousInput_d = 0.0F;
        LKAS_DW.SumCondition_MODE = true;
      }

      /* Sum: '<S336>/Add1' incorporates:
       *  Memory: '<S336>/Memory'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_d;

      /* Saturate: '<S336>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 5.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 5.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S336>/Saturation' */

      /* RelationalOperator: '<S336>/Relational Operator' incorporates:
       *  Constant: '<S330>/Constant'
       */
      LKAS_DW.RelationalOperator_na = (rtb_LL_ThresDet_lDvtThresLwrLDW <= 2.0F);

      /* Update for Memory: '<S336>/Memory' */
      LKAS_DW.Memory_PreviousInput_d = rtb_LL_ThresDet_lDvtThresLwrLDW;
    } else {
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S336>/Out' */
        LKAS_DW.RelationalOperator_na = false;
        LKAS_DW.SumCondition_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S330>/Sum Condition' */

    /* If: '<S317>/If' incorporates:
     *  Constant: '<S321>/Constant'
     *  Constant: '<S323>/Constant'
     *  DataTypeConversion: '<S330>/Cast To Single3'
     *  DataTypeConversion: '<S330>/Cast To Single4'
     *  Product: '<S330>/Divide'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && (((sint32)((uint32)(((uint32)rtb_IMAPve_d_SAS_Trim_State) *
            (LKAS_DW.RelationalOperator_na ? 1U : 0U)))) == 0)) {
      /* Outputs for IfAction SubSystem: '<S317>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S323>/Action Port'
       */
      LKAS_DW.Merge_a = true;

      /* End of Outputs for SubSystem: '<S317>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S317>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S321>/Action Port'
       */
      LKAS_DW.Merge_a = false;

      /* End of Outputs for SubSystem: '<S317>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S317>/If' */

    /* Outputs for Enabled SubSystem: '<S278>/Count_5s3' incorporates:
     *  EnablePort: '<S540>/Enable'
     */
    /* RelationalOperator: '<S525>/Compare' incorporates:
     *  Constant: '<S525>/Constant'
     *  Constant: '<S560>/Constant'
     */
    if (((uint8)0U) == ((uint8)1U)) {
      if (!LKAS_DW.Count_5s3_MODE) {
        /* InitializeConditions for Memory: '<S540>/Memory' */
        LKAS_DW.Memory_PreviousInput_i3 = 0.0F;
        LKAS_DW.Count_5s3_MODE = true;
      }

      /* Sum: '<S540>/Add' incorporates:
       *  Memory: '<S540>/Memory'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_DW.Memory_PreviousInput_i3 +
        rtb_LKA_SampleTime;

      /* Saturate: '<S540>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 11.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 11.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S540>/Saturation' */

      /* RelationalOperator: '<S540>/Relational Operator' incorporates:
       *  Constant: '<S540>/Constant1'
       */
      LKAS_DW.RelationalOperator = (rtb_LL_ThresDet_lDvtThresLwrLDW >= ((float32)
        ((uint16)5U)));

      /* Update for Memory: '<S540>/Memory' */
      LKAS_DW.Memory_PreviousInput_i3 = rtb_LL_ThresDet_lDvtThresLwrLDW;
    } else {
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S540>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S525>/Compare' */
    /* End of Outputs for SubSystem: '<S278>/Count_5s3' */

    /* RelationalOperator: '<S530>/Compare' incorporates:
     *  Constant: '<S530>/Constant'
     */
    rtb_Compare_gt = (rtb_IMAPve_d_Camera_Status == ((uint8)3U));

    /* Outputs for Enabled SubSystem: '<S278>/Count_5s2' */
    LKAS_Count_5s1(rtb_Compare_gt, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_o, &LKAS_DW.Count_5s2);

    /* End of Outputs for SubSystem: '<S278>/Count_5s2' */

    /* Logic: '<S278>/Logical Operator10' */
    LKAS_DW.LKA_Fault = ((LKAS_DW.RelationalOperator) ||
                         (LKAS_DW.RelationalOperator_o));

    /* Chart: '<S82>/LDW_State_Machine'
     *
     * Block description for '<S82>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* RelationalOperator: '<S529>/Compare' incorporates:
     *  Constant: '<S529>/Constant'
     */
    rtb_Compare_oz = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

    /* Outputs for Enabled SubSystem: '<S278>/Count_5s1' */
    LKAS_Count_5s1(rtb_Compare_oz, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_g, &LKAS_DW.Count_5s1);

    /* End of Outputs for SubSystem: '<S278>/Count_5s1' */

    /* Logic: '<S278>/Logical Operator8' */
    LKAS_DW.LKA_Fault = (((LKAS_DW.RelationalOperator) ||
                          (LKAS_DW.RelationalOperator_o)) ||
                         (LKAS_DW.RelationalOperator_g));

    /* Chart: '<S82>/LKA_State_Machine'
     *
     * Block description for '<S82>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S255>/Subsystem' incorporates:
     *  EnablePort: '<S259>/Enable'
     */
    /* Logic: '<S255>/Logical Operator3' incorporates:
     *  Abs: '<S255>/Abs4'
     *  Abs: '<S255>/Abs5'
     *  Abs: '<S255>/Abs6'
     *  Abs: '<S255>/Abs7'
     *  Constant: '<S255>/Constant'
     *  Constant: '<S255>/Constant1'
     *  Constant: '<S255>/Constant4'
     *  Constant: '<S255>/Constant5'
     *  Constant: '<S257>/Constant'
     *  Constant: '<S258>/Constant'
     *  Logic: '<S255>/Logical Operator'
     *  Logic: '<S255>/Logical Operator1'
     *  Logic: '<S255>/Logical Operator4'
     *  RelationalOperator: '<S255>/Relational Operator'
     *  RelationalOperator: '<S255>/Relational Operator1'
     *  RelationalOperator: '<S255>/Relational Operator2'
     *  RelationalOperator: '<S255>/Relational Operator3'
     *  RelationalOperator: '<S255>/Relational Operator6'
     *  RelationalOperator: '<S255>/Relational Operator7'
     *  RelationalOperator: '<S257>/Compare'
     *  RelationalOperator: '<S258>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_m) <= 0.005F) && (fabsf(rtb_L0_C1_i) <= 0.005F)) &&
           ((fabsf(rtb_LL_CompHdAg_C) <= 0.0001F) && (fabsf(rtb_L0_C2) <=
             0.0001F))) && ((rtb_L0_Q == ((uint8)3U)) && (rtb_R0_Q == ((uint8)3U))))
         && (rtb_IMAPve_g_ESC_VehSpd >= 50.0F)) && (x1 <= 1.0F)) {
      if (!LKAS_DW.Subsystem_MODE_p) {
        /* InitializeConditions for Memory: '<S259>/Memory' */
        LKAS_DW.Memory_PreviousInput_hb = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_p = true;
      }

      /* Sum: '<S259>/Add1' incorporates:
       *  Memory: '<S259>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(1U + ((uint32)LKAS_DW.Memory_PreviousInput_hb));

      /* Saturate: '<S259>/Saturation' */
      if (rtb_Saturation_h5 >= ((uint16)3000U)) {
        rtb_Saturation_h5 = ((uint16)3000U);
      }

      /* End of Saturate: '<S259>/Saturation' */

      /* RelationalOperator: '<S259>/Relational Operator' incorporates:
       *  Constant: '<S255>/Constant3'
       *  DataTypeConversion: '<S259>/Cast To Single1'
       *  Product: '<S255>/Divide'
       */
      LKAS_DW.RelationalOperator_k = (rtb_Saturation_h5 >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S259>/Memory' */
      LKAS_DW.Memory_PreviousInput_hb = rtb_Saturation_h5;
    } else {
      if (LKAS_DW.Subsystem_MODE_p) {
        /* Disable for Outport: '<S259>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Subsystem_MODE_p = false;
      }
    }

    /* End of Logic: '<S255>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S255>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S231>/Subsystem' incorporates:
     *  EnablePort: '<S254>/Enable'
     */
    if (LKAS_DW.RelationalOperator_k) {
      /* Sum: '<S256>/Add2' incorporates:
       *  Constant: '<S256>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S256>/Memory3'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S256>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 50.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 50.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S256>/Saturation' */

      /* Switch: '<S256>/Switch' incorporates:
       *  Constant: '<S254>/Constant'
       *  Product: '<S256>/Divide'
       *  Product: '<S256>/Divide1'
       *  Sum: '<S256>/Add'
       *  Sum: '<S256>/Add1'
       *  UnitDelay: '<S256>/Unit Delay'
       */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 1.0F) {
        rtb_LL_ThresDet_tiTTLCThresLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_IMAPve_g_SW_Angle - LKAS_DW.UnitDelay_DSTATE)) +
          LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_tiTTLCThresLDW = rtb_IMAPve_g_SW_Angle;
      }

      /* End of Switch: '<S256>/Switch' */

      /* Saturate: '<S254>/Saturation' */
      if (rtb_LL_ThresDet_tiTTLCThresLDW > 3.0F) {
        LKAS_DW.Saturation_h = 3.0F;
      } else if (rtb_LL_ThresDet_tiTTLCThresLDW < (-3.0F)) {
        LKAS_DW.Saturation_h = (-3.0F);
      } else {
        LKAS_DW.Saturation_h = rtb_LL_ThresDet_tiTTLCThresLDW;
      }

      /* End of Saturate: '<S254>/Saturation' */

      /* Update for UnitDelay: '<S256>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_tiTTLCThresLDW;

      /* Update for Memory: '<S256>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_ThresDet_lDvtThresLwrLDW;
    }

    /* End of Outputs for SubSystem: '<S231>/Subsystem' */

    /* Saturate: '<S233>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 0.001F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.001F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S233>/Saturation' */

    /* Gain: '<S267>/kph To mps' incorporates:
     *  Gain: '<S268>/kph To mps'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = 0.277777791F * rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S267>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S269>:1' */
    /* '<S269>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 150.0F;
    } else if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 60.0F;
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Saturate: '<S267>/Saturation3' */

    /* Product: '<S267>/Divide1' incorporates:
     *  Constant: '<S267>/Constant'
     */
    rtb_TLft = 0.09F / rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Saturate: '<S267>/Saturation1' */
    if (rtb_TLft > 0.0117F) {
      rtb_TLft = 0.0117F;
    } else {
      if (rtb_TLft < 0.00237F) {
        rtb_TLft = 0.00237F;
      }
    }

    /* End of Saturate: '<S267>/Saturation1' */

    /* Switch: '<S552>/Switch7' incorporates:
     *  Constant: '<S552>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_k != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_k;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S552>/Switch7' */

    /* MATLAB Function: '<S267>/MATLAB Function' incorporates:
     *  Gain: '<S267>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_TLft *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_d) * LKAS_DW.LKA_WhlBaseL_C_m) /
      (rtb_LL_ThresDet_tiTTLCThresLDW * rtb_LL_ThresDet_tiTTLCThresLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S268>/Saturation3' */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 60.0F;
      }
    }

    /* End of Saturate: '<S268>/Saturation3' */

    /* Product: '<S268>/Divide1' incorporates:
     *  Constant: '<S268>/Constant'
     */
    rtb_LL_LDW_LatestWarnLine_C = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S268>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S270>:1' */
    /* '<S270>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_LDW_LatestWarnLine_C > 0.0117F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.0117F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 0.00237F) {
        rtb_LL_LDW_LatestWarnLine_C = 0.00237F;
      }
    }

    /* End of Saturate: '<S268>/Saturation1' */

    /* Switch: '<S552>/Switch4' incorporates:
     *  Constant: '<S552>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_j != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_j;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S552>/Switch4' */

    /* MATLAB Function: '<S268>/MATLAB Function' */
    LKAS_DW.SWARmax = ((((((((rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_d) * LKAS_DW.LKA_WhlBaseL_C_m) /
                        (rtb_LL_ThresDet_tiTTLCThresLDW *
                         rtb_LL_ThresDet_tiTTLCThresLDW)) * 180.0F) / 3.14F;

    /* Gain: '<S226>/Gain' incorporates:
     *  Sum: '<S226>/Add'
     */
    rtb_phiHdAg = (rtb_L0_C1_m + rtb_L0_C1_i) * 0.5F;

    /* Gain: '<S228>/Gain1' incorporates:
     *  Sum: '<S228>/Add1'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = (rtb_Add_p + rtb_Add_o) * 0.5F;

    /* Switch: '<S230>/Switch' incorporates:
     *  Constant: '<S246>/Constant'
     *  RelationalOperator: '<S246>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_TLft = rtb_LFTTTLC;
    } else {
      rtb_TLft = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S230>/Switch' */

    /* Saturate: '<S230>/Saturation' */
    if (rtb_TLft > 2.0F) {
      rtb_TLft = 2.0F;
    } else {
      if (rtb_TLft < 0.5F) {
        rtb_TLft = 0.5F;
      }
    }

    /* End of Saturate: '<S230>/Saturation' */

    /* Product: '<S252>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * rtb_TLft;

    /* Gain: '<S250>/Gain1' incorporates:
     *  Gain: '<S251>/Gain1'
     */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 3.0F * rtb_L0_C3_dc;

    /* Sum: '<S250>/Add' incorporates:
     *  Gain: '<S250>/Gain1'
     *  Product: '<S250>/Product3'
     *  Product: '<S250>/Product4'
     *  Product: '<S250>/Z*Z'
     */
    rtb_Add_pp = ((rtb_Add_p_tmp * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C1_m) +
      (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * (rtb_LL_LDW_LatestWarnLine_C *
        rtb_LL_LDW_LatestWarnLine_C));

    /* Switch: '<S230>/Switch1' incorporates:
     *  Constant: '<S247>/Constant'
     *  RelationalOperator: '<S247>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S230>/Switch1' */

    /* Saturate: '<S230>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S230>/Saturation1' */

    /* Product: '<S253>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LKA_Veh2CamL_C_tmp *
      rtb_LL_HdAgPrvwT_C;

    /* Gain: '<S248>/Gain1' incorporates:
     *  Gain: '<S249>/Gain1'
     */
    rtb_LL_ThresDet_lDvtThresLwrLKA = 3.0F * rtb_L0_C3;

    /* Sum: '<S248>/Add' incorporates:
     *  Gain: '<S248>/Gain1'
     *  Product: '<S248>/Product3'
     *  Product: '<S248>/Product4'
     *  Product: '<S248>/Z*Z'
     */
    rtb_Add_n2 = ((rtb_Add_o_tmp * rtb_LL_ThresDet_lDvtThresUprLKA) +
                  rtb_L0_C1_i) + (rtb_LL_ThresDet_lDvtThresLwrLKA *
      (rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_ThresDet_lDvtThresUprLKA));

    /* Gain: '<S230>/Gain1' incorporates:
     *  Sum: '<S230>/Add1'
     */
    rtb_LL_HdAgPrvwT_C = (rtb_LL_LDW_LatestWarnLine_C +
                          rtb_LL_ThresDet_lDvtThresUprLKA) * 0.5F;

    /* Switch: '<S552>/Switch8' incorporates:
     *  Constant: '<S552>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_i != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_i;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S552>/Switch8' */

    /* Product: '<S245>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Product: '<S243>/Z*Z' incorporates:
     *  Product: '<S244>/Z*Z'
     */
    x10 = rtb_LL_LDW_LatestWarnLine_C * rtb_LL_LDW_LatestWarnLine_C;

    /* Sum: '<S243>/Add' incorporates:
     *  Product: '<S243>/Product'
     *  Product: '<S243>/Product3'
     *  Product: '<S243>/Product4'
     *  Product: '<S243>/Z*Z'
     *  Product: '<S243>/Z*Z*Z'
     */
    rtb_Add_am = (((rtb_L0_C1_m * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C0_o) +
                  (rtb_LL_CompHdAg_C * x10)) + ((rtb_LL_LDW_LatestWarnLine_C *
      x10) * rtb_L0_C3_dc);

    /* Sum: '<S244>/Add' incorporates:
     *  Product: '<S244>/Product'
     *  Product: '<S244>/Product3'
     *  Product: '<S244>/Product4'
     *  Product: '<S244>/Z*Z*Z'
     */
    rtb_Add_e1 = (((rtb_L0_C1_i * rtb_LL_LDW_LatestWarnLine_C) + rtb_R0_C0_n) +
                  (rtb_L0_C2 * x10)) + ((rtb_LL_LDW_LatestWarnLine_C * x10) *
      rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S108>/Memory' */
        LKAS_DW.Memory_PreviousInput_ok = 0.0F;

        /* InitializeConditions for Memory: '<S145>/Memory' */
        LKAS_DW.Memory_PreviousInput_moq = ((uint16)0U);

        /* InitializeConditions for Memory: '<S91>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_lx = ((uint8)0U);

        /* InitializeConditions for Memory: '<S144>/Memory' */
        LKAS_DW.Memory_PreviousInput_k0 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S146>/Memory' */
        LKAS_DW.Memory_PreviousInput_n3 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S140>/Memory' */
        LKAS_DW.Memory_PreviousInput_ix = ((uint16)0U);

        /* InitializeConditions for Memory: '<S143>/Memory' */
        LKAS_DW.Memory_PreviousInput_pr = ((uint16)0U);

        /* InitializeConditions for Memory: '<S142>/Memory' */
        LKAS_DW.Memory_PreviousInput_pj = ((uint16)0U);

        /* InitializeConditions for Memory: '<S141>/Memory' */
        LKAS_DW.Memory_PreviousInput_e = ((uint16)0U);

        /* InitializeConditions for Memory: '<S118>/Memory' */
        LKAS_DW.Memory_PreviousInput_i3d = 0.0F;

        /* InitializeConditions for Memory: '<S109>/Memory' */
        LKAS_DW.Memory_PreviousInput_kz = 0.0F;

        /* InitializeConditions for Memory: '<S110>/Memory' */
        LKAS_DW.Memory_PreviousInput_mo = 0.0F;

        /* InitializeConditions for Memory: '<S107>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e = 0.0F;

        /* InitializeConditions for Memory: '<S201>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_f = 0.0F;

        /* InitializeConditions for Memory: '<S184>/Memory' */
        LKAS_DW.Memory_PreviousInput_g = 0.0F;

        /* InitializeConditions for UnitDelay: '<S182>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_a = 0.0F;

        /* InitializeConditions for Memory: '<S190>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_m = 0.0F;

        /* InitializeConditions for Memory: '<S196>/Memory' */
        LKAS_DW.Memory_PreviousInput_f4 = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S200>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

        /* InitializeConditions for Memory: '<S200>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_n = 0.0F;

        /* InitializeConditions for UnitDelay: '<S177>/Delay Input2'
         *
         * Block description for '<S177>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_b = 0.0F;

        /* InitializeConditions for Memory: '<S177>/Memory' */
        LKAS_DW.Memory_PreviousInput_e1 = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S98>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S98>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S110>/Moving Standard Deviation1' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S110>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S110>/Moving Standard Deviation2' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation2_d);

        /* End of SystemReset for SubSystem: '<S110>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Sum: '<S108>/Add2' incorporates:
       *  Memory: '<S108>/Memory'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_ok;

      /* Saturate: '<S108>/Saturation2' */
      if (rtb_TLft > 20.0F) {
        rtb_Saturation2 = 20.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation2 = 0.0F;
      } else {
        rtb_Saturation2 = rtb_TLft;
      }

      /* End of Saturate: '<S108>/Saturation2' */

      /* Saturate: '<S108>/Saturation' */
      if (rtb_TTLC > 0.004F) {
        rtb_TLft = 0.004F;
      } else if (rtb_TTLC < 0.0F) {
        rtb_TLft = 0.0F;
      } else {
        rtb_TLft = rtb_TTLC;
      }

      /* End of Saturate: '<S108>/Saturation' */

      /* RelationalOperator: '<S108>/Relational Operator4' incorporates:
       *  Constant: '<S108>/Constant'
       *  Constant: '<S108>/Constant1'
       *  Product: '<S108>/Divide'
       *  Sum: '<S108>/Add'
       */
      rtb_BCM_Right_Light = (rtb_Saturation2 >= ((((rtb_LL_LKAExPrcs_tiExitTime1
        * 0.5F) * rtb_TLft) / 0.004F) + rtb_LL_LKAExPrcs_tiExitTime1));

      /* Sum: '<S145>/Add' incorporates:
       *  Constant: '<S145>/Constant'
       *  Memory: '<S145>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_moq));

      /* Saturate: '<S145>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_f = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_f = ((uint16)10000U);
      }

      /* End of Saturate: '<S145>/Saturation1' */

      /* If: '<S145>/If' incorporates:
       *  Constant: '<S145>/Constant2'
       */
      if (rtb_Saturation1_f == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S145>/if action ' incorporates:
         *  ActionPort: '<S162>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_SW_Angle, &LKAS_DW.In_fp);

        /* End of Outputs for SubSystem: '<S145>/if action ' */
      }

      /* End of If: '<S145>/If' */

      /* Sum: '<S91>/Add' incorporates:
       *  Constant: '<S91>/Constant'
       *  Memory: '<S91>/Memory1'
       */
      rtb_IMAPve_d_SAS_Trim_State = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_lx));

      /* Saturate: '<S91>/Saturation1' */
      if (rtb_IMAPve_d_SAS_Trim_State < ((uint8)5U)) {
        rtb_Saturation1_cv = rtb_IMAPve_d_SAS_Trim_State;
      } else {
        rtb_Saturation1_cv = ((uint8)5U);
      }

      /* End of Saturate: '<S91>/Saturation1' */

      /* Saturate: '<S117>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S117>/Saturation3' */

      /* Product: '<S117>/Divide1' incorporates:
       *  Constant: '<S117>/Constant'
       */
      rtb_TLft = 0.09F / x10;

      /* Saturate: '<S117>/Saturation1' */
      if (rtb_TLft > 0.0117F) {
        LKAS_DW.StbFacm_SY = 0.0117F;
      } else if (rtb_TLft < 0.00237F) {
        LKAS_DW.StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.StbFacm_SY = rtb_TLft;
      }

      /* End of Saturate: '<S117>/Saturation1' */

      /* Sum: '<S144>/Add' incorporates:
       *  Constant: '<S144>/Constant'
       *  Memory: '<S144>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_k0));

      /* Saturate: '<S144>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_d = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_d = ((uint16)10000U);
      }

      /* End of Saturate: '<S144>/Saturation1' */

      /* If: '<S137>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S137>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S149>/Action Port'
         */
        LKAS_ifaction3(rtb_LFTTTLC, &rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S137>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S137>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_ifaction3(rtb_RGTTTLC, &rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S137>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S137>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S150>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_g);

        /* End of Outputs for SubSystem: '<S137>/If Action Subsystem3' */
      }

      /* End of If: '<S137>/If' */

      /* If: '<S144>/If' incorporates:
       *  Constant: '<S144>/Constant2'
       */
      if (rtb_Saturation1_d == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S144>/if action ' incorporates:
         *  ActionPort: '<S161>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_g, &LKAS_DW.In_io);

        /* End of Outputs for SubSystem: '<S144>/if action ' */
      }

      /* End of If: '<S144>/If' */

      /* Saturate: '<S117>/Saturation2' */
      if (LKAS_DW.In_io > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_io < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_io;
      }

      /* End of Saturate: '<S117>/Saturation2' */

      /* Sum: '<S146>/Add' incorporates:
       *  Constant: '<S146>/Constant'
       *  Memory: '<S146>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_n3));

      /* Saturate: '<S146>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_b = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S146>/Saturation1' */

      /* If: '<S146>/If' incorporates:
       *  Constant: '<S146>/Constant2'
       */
      if (rtb_Saturation1_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S146>/if action ' incorporates:
         *  ActionPort: '<S163>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_ESC_VehSpd, &LKAS_DW.In_i);

        /* End of Outputs for SubSystem: '<S146>/if action ' */
      }

      /* End of If: '<S146>/If' */

      /* Sum: '<S140>/Add' incorporates:
       *  Constant: '<S140>/Constant'
       *  Memory: '<S140>/Memory'
       */
      rtb_Add_pn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ix));

      /* DataTypeConversion: '<S172>/Data Type Conversion' incorporates:
       *  Constant: '<S173>/Constant'
       *  RelationalOperator: '<S173>/Compare'
       */
      rtb_IMAPve_d_SAS_Trim_State = (uint8)((rtb_Merge_o <= 0.0F) ? 1 : 0);

      /* Switch: '<S552>/Switch5' incorporates:
       *  Constant: '<S552>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_p != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_p;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S552>/Switch5' */

      /* Product: '<S172>/Divide' */
      rtb_Gain2_bi = (rtb_Merge_o * rtb_LKA_Veh2CamL_C_tmp) * x10;

      /* Abs: '<S172>/Abs1' incorporates:
       *  Abs: '<S172>/Abs'
       */
      rtb_LL_LDW_LatestWarnLine_C = fabsf(rtb_Gain2_bi);
      rtb_Abs1_g = rtb_LL_LDW_LatestWarnLine_C;

      /* Abs: '<S172>/Abs' */
      rtb_Abs_h = rtb_LL_LDW_LatestWarnLine_C;

      /* If: '<S172>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) && (((sint32)
            rtb_IMAPve_d_SAS_Trim_State) == 0)) {
        /* Outputs for IfAction SubSystem: '<S172>/If Action Subsystem' incorporates:
         *  ActionPort: '<S174>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_h, &rtb_Gain2_bi);

        /* End of Outputs for SubSystem: '<S172>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) && (((sint32)
                   rtb_IMAPve_d_SAS_Trim_State) == 1)) {
        /* Outputs for IfAction SubSystem: '<S172>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S176>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_g, &rtb_Gain2_bi);

        /* End of Outputs for SubSystem: '<S172>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S172>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S175>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Gain2_bi);

        /* End of Outputs for SubSystem: '<S172>/If Action Subsystem2' */
      }

      /* End of If: '<S172>/If' */

      /* Switch: '<S552>/Switch6' incorporates:
       *  Constant: '<S552>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_g != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_g;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S552>/Switch6' */

      /* Sum: '<S168>/Add' incorporates:
       *  Sum: '<S109>/Add3'
       *  Sum: '<S110>/Add'
       *  Sum: '<S189>/Add6'
       */
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Sum: '<S168>/Add1' incorporates:
       *  Product: '<S168>/Divide'
       *  Product: '<S168>/Divide1'
       *  Sum: '<S168>/Add'
       */
      rtb_Add1_kd = (((1.0F / x10) * rtb_LL_ThresDet_lDvtThresUprLKA) /
                     rtb_LKA_Veh2CamL_C_tmp) + rtb_Gain2_bi;

      /* If: '<S120>/If' incorporates:
       *  Constant: '<S171>/Constant2'
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S120>/If Action Subsystem' incorporates:
         *  ActionPort: '<S169>/Action Port'
         */
        /* Gain: '<S169>/Gain2' */
        rtb_Merge_f = (-1.0F) * rtb_Add1_kd;

        /* End of Outputs for SubSystem: '<S120>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S120>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S170>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_kd, &rtb_Merge_f);

        /* End of Outputs for SubSystem: '<S120>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S120>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S171>/Action Port'
         */
        rtb_Merge_f = 0.0F;

        /* End of Outputs for SubSystem: '<S120>/If Action Subsystem2' */
      }

      /* End of If: '<S120>/If' */

      /* Saturate: '<S140>/Saturation1' */
      if (rtb_Add_pn < ((uint16)10000U)) {
        rtb_Saturation_h5 = rtb_Add_pn;
      } else {
        rtb_Saturation_h5 = ((uint16)10000U);
      }

      /* End of Saturate: '<S140>/Saturation1' */

      /* If: '<S140>/If' incorporates:
       *  Constant: '<S140>/Constant2'
       */
      if (rtb_Saturation_h5 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S140>/if action ' incorporates:
         *  ActionPort: '<S157>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_f, &LKAS_DW.In_b);

        /* End of Outputs for SubSystem: '<S140>/if action ' */
      }

      /* End of If: '<S140>/If' */

      /* Sum: '<S143>/Add' incorporates:
       *  Constant: '<S143>/Constant'
       *  Memory: '<S143>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_pr));

      /* Saturate: '<S143>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_k = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_k = ((uint16)10000U);
      }

      /* End of Saturate: '<S143>/Saturation1' */

      /* If: '<S143>/If' incorporates:
       *  Constant: '<S143>/Constant2'
       */
      if (rtb_Saturation1_k == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S143>/if action ' incorporates:
         *  ActionPort: '<S160>/Action Port'
         */
        LKAS_ifaction(rtb_phiHdAg, &LKAS_DW.In_k);

        /* End of Outputs for SubSystem: '<S143>/if action ' */
      }

      /* End of If: '<S143>/If' */

      /* Sum: '<S142>/Add' incorporates:
       *  Constant: '<S142>/Constant'
       *  Memory: '<S142>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_pj));

      /* Saturate: '<S142>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_en = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_en = ((uint16)10000U);
      }

      /* End of Saturate: '<S142>/Saturation1' */

      /* If: '<S139>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S139>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S155>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_am, &rtb_Merge_ot);

        /* End of Outputs for SubSystem: '<S139>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S139>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S154>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_e1, &rtb_Merge_ot);

        /* End of Outputs for SubSystem: '<S139>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S139>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S156>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_ot);

        /* End of Outputs for SubSystem: '<S139>/If Action Subsystem3' */
      }

      /* End of If: '<S139>/If' */

      /* If: '<S142>/If' incorporates:
       *  Constant: '<S142>/Constant2'
       */
      if (rtb_Saturation1_en == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S142>/if action ' incorporates:
         *  ActionPort: '<S159>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_ot, &LKAS_DW.In_e);

        /* End of Outputs for SubSystem: '<S142>/if action ' */
      }

      /* End of If: '<S142>/If' */

      /* Sum: '<S141>/Add' incorporates:
       *  Constant: '<S141>/Constant'
       *  Memory: '<S141>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_e));

      /* Saturate: '<S141>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_b1 = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_b1 = ((uint16)10000U);
      }

      /* End of Saturate: '<S141>/Saturation1' */

      /* If: '<S138>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S138>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S152>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_pp, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S138>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S138>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S151>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_n2, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S138>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S138>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S153>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S138>/If Action Subsystem3' */
      }

      /* End of If: '<S138>/If' */

      /* If: '<S141>/If' incorporates:
       *  Constant: '<S141>/Constant2'
       */
      if (rtb_Saturation1_b1 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S141>/if action ' incorporates:
         *  ActionPort: '<S158>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_k, &LKAS_DW.In_ko);

        /* End of Outputs for SubSystem: '<S141>/if action ' */
      }

      /* End of If: '<S141>/If' */

      /* If: '<S147>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S147>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S165>/Action Port'
         */
        /* SignalConversion: '<S165>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S165>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S147>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S147>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S164>/Action Port'
         */
        /* SignalConversion: '<S164>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S164>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S147>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S147>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S166>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S147>/If Action Subsystem3' */
      }

      /* End of If: '<S147>/If' */

      /* If: '<S91>/If' incorporates:
       *  Constant: '<S91>/Constant19'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem;
      rtAction = -1;
      if (rtb_Saturation1_cv == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        if (0 != rtPrevAction) {
          /* SystemReset for IfAction SubSystem: '<S91>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
           *  ActionPort: '<S116>/Action Port'
           *
           * Block description for '<S91>/LKA Motion Planning Calculation (LKAMPCal)':
           *  Block Name: LKA Motion Planning Calculation
           *  Ab.: LKAMPCal
           *  No.: 1.2.3.2
           *  Rev: 0.0.1
           *  Update Date: 19-3-26
           */
          /* SystemReset for If: '<S91>/If' */
          LKAMotionPlanningCalculat_Reset();

          /* End of SystemReset for SubSystem: '<S91>/LKA Motion Planning Calculation (LKAMPCal)' */
        }

        /* Outputs for IfAction SubSystem: '<S91>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S116>/Action Port'
         *
         * Block description for '<S91>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S91>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S91>/If' */

      /* Memory: '<S118>/Memory' */
      rtb_Gain2_bi = LKAS_DW.Memory_PreviousInput_i3d;

      /* Sum: '<S118>/Add' incorporates:
       *  Gain: '<S118>/Gain1'
       *  Product: '<S118>/Divide'
       *  Product: '<S118>/Product'
       */
      rtb_Add_lo = ((rtb_LKA_Veh2CamL_C_tmp * rtb_LKA_SampleTime) /
                    (0.277777791F * LKAS_DW.In_i)) + rtb_Gain2_bi;

      /* MATLAB Function: '<S119>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S167>:1' */
      /* '<S167>:1:20' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S167>:1:21' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S167>:1:22' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S167>:1:23' Delte2PhSWGrad = SWACmd_dphi2PhSWAGrad; */
      /* '<S167>:1:24' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S167>:1:25' NomT = SWACmd_tiNomT; */
      /* '<S167>:1:26' T1 = (DelteSW1-DelteSW0)/Delte1PhSWGrad; */
      rtb_LL_LKAExPrcs_tiExitTime1 = (LKAS_DW.K1K2Det_phi2PhSWAIni -
        LKAS_DW.In_fp) / LKAS_DW.K1K2Det_dphi1PhSWAGrad;

      /* '<S167>:1:27' T2 = (0-DelteSW1)/Delte2PhSWGrad+T1; */
      rtb_LL_DvtSpdDet_vDvtSpdMin_C = ((0.0F - LKAS_DW.K1K2Det_phi2PhSWAIni) /
        LKAS_DW.K1K2Det_dphi2PhSWAGrad1) + rtb_LL_LKAExPrcs_tiExitTime1;

      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S167>:1:35' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_lo < rtb_LL_LKAExPrcs_tiExitTime1) && (rtb_Add_lo >= 0.0F)) {
        /* '<S167>:1:36' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_lo) +
          LKAS_DW.In_fp;
      } else if ((rtb_Add_lo <= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Add_lo >=
                  rtb_LL_LKAExPrcs_tiExitTime1)) {
        /* '<S167>:1:37' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S167>:1:39' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
          rtb_LL_LKAExPrcs_tiExitTime1) + LKAS_DW.In_fp;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_lo >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) {
          /* '<S167>:1:41' elseif(NomT >= T2) */
          /* '<S167>:1:42' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
            rtb_LL_LKAExPrcs_tiExitTime1) + LKAS_DW.In_fp;

          /*    DelteSWCmd = single(0); */
        }
      }

      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S167>:1:48' SWACmd_phiSWACmd = DelteSWCmd; */
      rtb_T2 = rtb_LL_DvtSpdDet_vDvtSpdMin_C;

      /* Saturate: '<S91>/Saturation6' incorporates:
       *  MATLAB Function: '<S119>/SWACmd'
       */
      if (rtb_LL_LKAExPrcs_tiExitTime1 > 2.0F) {
        rtb_Saturation6 = 2.0F;
      } else if (rtb_LL_LKAExPrcs_tiExitTime1 < 0.2F) {
        rtb_Saturation6 = 0.2F;
      } else {
        rtb_Saturation6 = rtb_LL_LKAExPrcs_tiExitTime1;
      }

      /* End of Saturate: '<S91>/Saturation6' */

      /* Memory: '<S109>/Memory' */
      rtb_Gain2_bi = LKAS_DW.Memory_PreviousInput_kz;

      /* Sum: '<S109>/Add2' */
      rtb_Gain2_bi += rtb_LKA_SampleTime;

      /* Saturate: '<S109>/Saturation2' */
      if (rtb_Gain2_bi > 12.0F) {
        rtb_Saturation2_l = 12.0F;
      } else if (rtb_Gain2_bi < 0.0F) {
        rtb_Saturation2_l = 0.0F;
      } else {
        rtb_Saturation2_l = rtb_Gain2_bi;
      }

      /* End of Saturate: '<S109>/Saturation2' */

      /* Abs: '<S109>/Abs2' */
      rtb_Gain2_bi = fabsf(rtb_Gain1_j);

      /* Gain: '<S109>/Gain' */
      rtb_LL_LKAExPrcs_tiExitTime1 = rtb_LL_ThresDet_lDvtThresUprLKA *
        0.166666672F;

      /* RelationalOperator: '<S109>/Relational Operator2' */
      rtb_LogicalOperator3_b5 = (rtb_Gain2_bi >= rtb_LL_LKAExPrcs_tiExitTime1);

      /* Abs: '<S109>/Abs3' */
      rtb_Gain2_bi = fabsf(rtb_Add5_n);

      /* Outputs for Enabled SubSystem: '<S109>/Sum Condition1' incorporates:
       *  EnablePort: '<S111>/Enable'
       */
      /* Logic: '<S109>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S109>/Relational Operator3'
       *  RelationalOperator: '<S109>/Relational Operator4'
       */
      if (((rtb_Saturation2_l >= rtb_Saturation6) && rtb_LogicalOperator3_b5) &&
          (rtb_Gain2_bi >= rtb_LL_LKAExPrcs_tiExitTime1)) {
        if (!LKAS_DW.SumCondition1_MODE_h) {
          /* InitializeConditions for Memory: '<S111>/Memory' */
          LKAS_DW.Memory_PreviousInput_n0 = 0.0F;
          LKAS_DW.SumCondition1_MODE_h = true;
        }

        /* Sum: '<S111>/Add1' incorporates:
         *  Memory: '<S111>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime1 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_n0;

        /* Saturate: '<S111>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime1 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime1 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime1 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime1 = 0.0F;
          }
        }

        /* End of Saturate: '<S111>/Saturation' */

        /* Saturate: '<S109>/Saturation' */
        if (rtb_TTLC > 0.004F) {
          rtb_TLft = 0.004F;
        } else if (rtb_TTLC < 0.0F) {
          rtb_TLft = 0.0F;
        } else {
          rtb_TLft = rtb_TTLC;
        }

        /* End of Saturate: '<S109>/Saturation' */

        /* RelationalOperator: '<S111>/Relational Operator' incorporates:
         *  Constant: '<S109>/Constant'
         *  Constant: '<S109>/Constant1'
         *  Product: '<S109>/Divide'
         *  Sum: '<S109>/Add1'
         */
        LKAS_DW.RelationalOperator_ew = (rtb_LL_LKAExPrcs_tiExitTime1 >=
          ((((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) * rtb_TLft) / 0.004F) +
           rtb_LL_LKAExPrcs_tiExitTime2));

        /* Update for Memory: '<S111>/Memory' */
        LKAS_DW.Memory_PreviousInput_n0 = rtb_LL_LKAExPrcs_tiExitTime1;
      } else {
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S111>/Out' */
          LKAS_DW.RelationalOperator_ew = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }
      }

      /* End of Logic: '<S109>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S109>/Sum Condition1' */

      /* Memory: '<S110>/Memory' */
      rtb_Gain2_bi = LKAS_DW.Memory_PreviousInput_mo;

      /* Sum: '<S110>/Add2' */
      rtb_Gain2_bi += rtb_LKA_SampleTime;

      /* Saturate: '<S110>/Saturation2' */
      if (rtb_Gain2_bi > 10.0F) {
        rtb_Saturation2_n = 10.0F;
      } else if (rtb_Gain2_bi < 0.0F) {
        rtb_Saturation2_n = 0.0F;
      } else {
        rtb_Saturation2_n = rtb_Gain2_bi;
      }

      /* End of Saturate: '<S110>/Saturation2' */

      /* Gain: '<S110>/Gain' */
      rtb_Gain2_bi = rtb_LL_ThresDet_lDvtThresUprLKA * 0.333333343F;

      /* RelationalOperator: '<S110>/Relational Operator2' */
      rtb_LogicalOperator3_b5 = (rtb_Gain1_j >= rtb_Gain2_bi);

      /* RelationalOperator: '<S110>/Relational Operator3' */
      rtb_LL_SingleLane_Disable_Swt = (rtb_Add5_n >= rtb_Gain2_bi);

      /* Abs: '<S110>/Abs4' */
      rtb_Gain2_bi = rtb_TTLC;

      /* Saturate: '<S110>/Saturation' */
      if (rtb_Gain2_bi > 0.004F) {
        rtb_Gain2_bi = 0.004F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S110>/Saturation' */

      /* Switch: '<S552>/Switch45' incorporates:
       *  Constant: '<S552>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S552>/Switch45' */

      /* Sum: '<S110>/Add6' incorporates:
       *  Constant: '<S110>/Constant'
       *  Constant: '<S110>/Constant7'
       *  Product: '<S110>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Gain2_bi) / 0.004F) + x10;

      /* Outputs for Enabled SubSystem: '<S89>/Subsystem' incorporates:
       *  EnablePort: '<S97>/Enable'
       */
      /* RelationalOperator: '<S96>/Compare' incorporates:
       *  Constant: '<S552>/LL_LKASWASyn_TrqSwaAddSwt=1'
       *  Constant: '<S96>/Constant'
       *  Switch: '<S552>/Switch47'
       */
      if (((sint32)(((LKAS_ConstB.DataTypeConversion47_j) ||
                     (LL_LKASWASyn_TrqSwaAddSwt)) ? 1 : 0)) > ((sint32)(false ?
            1 : 0))) {
        if (!LKAS_DW.Subsystem_MODE_l) {
          LKAS_DW.Subsystem_MODE_l = true;
        }

        /* MATLAB Function: '<S97>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S99>:1' */
        /* '<S99>:1:2' Swaadd=single(0); */
        /* '<S99>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S99>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S99>:1:5' l0c0=abs(l0c0); */
        /* '<S99>:1:6' r0c0=abs(r0c0); */
        /* '<S99>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_LL_LKAExPrcs_tiExitTime1 = fmaxf(fminf(rtb_Add5_n_tmp + rtb_TTLC_n,
          5.4F), 2.5F);

        /* '<S99>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_LL_LKAExPrcs_tiExitTime1 > 2.5F) &&
            (rtb_LL_LKAExPrcs_tiExitTime1 < 5.4F)) {
          /* '<S99>:1:9' leftlane=l0c0/lanewidth; */
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_Add5_n_tmp /
            rtb_LL_LKAExPrcs_tiExitTime1;

          /* '<S99>:1:10' rightlane=r0c0/lanewidth; */
          rtb_LL_LKAExPrcs_tiExitTime2 = rtb_TTLC_n /
            rtb_LL_LKAExPrcs_tiExitTime1;
        } else {
          /* '<S99>:1:11' else */
          /* '<S99>:1:12' leftlane=single(0.5); */
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = 0.5F;

          /* '<S99>:1:13' rightlane=single(0.5); */
          rtb_LL_LKAExPrcs_tiExitTime2 = 0.5F;
        }

        /* '<S99>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S99>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S99>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S552>/Switch42' incorporates:
           *  Constant: '<S552>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S99>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S552>/Switch43' incorporates:
           *  Constant: '<S552>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKAExPrcs_tiExitTime2 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_LL_DvtSpdDet_vDvtSpdMin_C) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S552>/Switch42' incorporates:
           *  Constant: '<S552>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S99>:1:19' else */
          /* '<S99>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S552>/Switch43' incorporates:
           *  Constant: '<S552>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKAExPrcs_tiExitTime2 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_LL_LKAExPrcs_tiExitTime2) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S100>/Add2' incorporates:
         *  Constant: '<S100>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S100>/Memory3'
         */
        rtb_LL_LKAExPrcs_tiExitTime1 = 1.0F + LKAS_DW.Memory3_PreviousInput_a;

        /* Saturate: '<S100>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime1 > 50.0F) {
          rtb_LL_LKAExPrcs_tiExitTime1 = 50.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime1 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime1 = 0.0F;
          }
        }

        /* End of Saturate: '<S100>/Saturation' */

        /* Switch: '<S100>/Switch' incorporates:
         *  Product: '<S100>/Divide'
         *  Product: '<S100>/Divide1'
         *  Sum: '<S100>/Add'
         *  Sum: '<S100>/Add1'
         *  UnitDelay: '<S100>/Unit Delay'
         */
        if (rtb_LL_LKAExPrcs_tiExitTime1 > 1.0F) {
          /* Switch: '<S552>/Switch50' incorporates:
           *  Constant: '<S552>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S552>/Switch50' */
          rtb_LL_LKAExPrcs_tiExitTime2 = ((rtb_LKA_SampleTime / x10) *
            (rtb_LL_LKAExPrcs_tiExitTime2 - LKAS_DW.UnitDelay_DSTATE_n)) +
            LKAS_DW.UnitDelay_DSTATE_n;
        }

        /* End of Switch: '<S100>/Switch' */

        /* SampleTimeMath: '<S103>/TSamp'
         *
         * About '<S103>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_LL_LKAExPrcs_tiExitTime2 * 100.0F;

        /* Sum: '<S101>/Add2' incorporates:
         *  Constant: '<S101>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S101>/Memory3'
         */
        rtb_LL_LDW_LatestWarnLine_C = 1.0F + LKAS_DW.Memory3_PreviousInput_e4;

        /* Saturate: '<S101>/Saturation' */
        if (rtb_LL_LDW_LatestWarnLine_C > 50.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 50.0F;
        } else {
          if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
            rtb_LL_LDW_LatestWarnLine_C = 0.0F;
          }
        }

        /* End of Saturate: '<S101>/Saturation' */

        /* Switch: '<S101>/Switch' incorporates:
         *  Product: '<S101>/Divide'
         *  Product: '<S101>/Divide1'
         *  Sum: '<S101>/Add'
         *  Sum: '<S101>/Add1'
         *  Sum: '<S103>/Diff'
         *  UnitDelay: '<S101>/Unit Delay'
         *  UnitDelay: '<S103>/UD'
         *
         * Block description for '<S103>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S103>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_LDW_LatestWarnLine_C > 2.0F) {
          /* Switch: '<S552>/Switch52' incorporates:
           *  Constant: '<S552>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S552>/Switch52' */
          rtb_LL_TkOvStChk_tiTDelTime = (((rtb_LL_DvtSpdDet_vDvtSpdMin_C -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_nl) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_nl;
        } else {
          rtb_LL_TkOvStChk_tiTDelTime = rtb_LL_DvtSpdDet_vDvtSpdMin_C -
            LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S101>/Switch' */

        /* Saturate: '<S97>/Saturation' */
        if (rtb_LL_TkOvStChk_tiTDelTime > 30.0F) {
          rtb_L0_C3 = 30.0F;
        } else if (rtb_LL_TkOvStChk_tiTDelTime < (-30.0F)) {
          rtb_L0_C3 = (-30.0F);
        } else {
          rtb_L0_C3 = rtb_LL_TkOvStChk_tiTDelTime;
        }

        /* End of Saturate: '<S97>/Saturation' */

        /* Switch: '<S552>/Switch53' incorporates:
         *  Constant: '<S552>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S552>/Switch53' */

        /* Sum: '<S102>/Difference Inputs1' incorporates:
         *  Product: '<S97>/Divide1'
         *  Product: '<S97>/Divide3'
         *  Sum: '<S97>/Add'
         *  UnitDelay: '<S102>/Delay Input2'
         *
         * Block description for '<S102>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S102>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = ((rtb_L0_C3 * x10) +
          rtb_LL_LKAExPrcs_tiExitTime2) - LKAS_DW.DelayInput2_DSTATE_o;

        /* Product: '<S102>/delta rise limit' incorporates:
         *  Constant: '<S97>/Constant1'
         *  SampleTimeMath: '<S102>/sample time'
         *
         * About '<S102>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_L0_C3 = 5.0F * 0.01F;

        /* Product: '<S102>/delta fall limit' incorporates:
         *  Constant: '<S97>/Constant2'
         *  SampleTimeMath: '<S102>/sample time'
         *
         * About '<S102>/sample time':
         *  y = K where K = ( w * Ts )
         */
        x10 = (-5.0F) * 0.01F;

        /* Switch: '<S104>/Switch2' incorporates:
         *  Product: '<S102>/delta fall limit'
         *  Product: '<S102>/delta rise limit'
         *  RelationalOperator: '<S104>/LowerRelop1'
         *  RelationalOperator: '<S104>/UpperRelop'
         *  Switch: '<S104>/Switch'
         */
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > rtb_L0_C3) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_L0_C3;
        } else {
          if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < x10) {
            /* Switch: '<S104>/Switch' incorporates:
             *  Product: '<S102>/delta fall limit'
             */
            rtb_LL_MAX_DRIVER_TORQUE_DISABL = x10;
          }
        }

        /* End of Switch: '<S104>/Switch2' */

        /* Sum: '<S102>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S102>/Delay Input2'
         *
         * Block description for '<S102>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S102>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_g = rtb_LL_MAX_DRIVER_TORQUE_DISABL +
          LKAS_DW.DelayInput2_DSTATE_o;

        /* Update for UnitDelay: '<S100>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_n = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for Memory: '<S100>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_a = rtb_LL_LKAExPrcs_tiExitTime1;

        /* Update for UnitDelay: '<S103>/UD'
         *
         * Block description for '<S103>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_DvtSpdDet_vDvtSpdMin_C;

        /* Update for UnitDelay: '<S101>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_nl = rtb_LL_TkOvStChk_tiTDelTime;

        /* Update for Memory: '<S101>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e4 = rtb_LL_LDW_LatestWarnLine_C;

        /* Update for UnitDelay: '<S102>/Delay Input2'
         *
         * Block description for '<S102>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_o = LKAS_DW.DifferenceInputs2_g;
      } else {
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S97>/Out1' */
          LKAS_DW.DifferenceInputs2_g = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }
      }

      /* End of RelationalOperator: '<S96>/Compare' */
      /* End of Outputs for SubSystem: '<S89>/Subsystem' */

      /* Outputs for Atomic SubSystem: '<S98>/Moving Standard Deviation2' */
      LKAS_MovingStandardDeviation2(rtb_IMAPve_g_EPS_SW_Trq, &rtb_Yk1_mo,
        &rtb_deltafalllimit_k, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S98>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S110>/Moving Standard Deviation1' */
      rtb_Gain_m = (float32) LKAS_MovingStandardDeviation1(rtb_Add5_n,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S110>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S110>/Relational Operator6' */
      rtb_RelationalOperator6_i = (rtb_Gain_m <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S110>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_i, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_k3, &LKAS_DW.SumCondition1_j);

      /* End of Outputs for SubSystem: '<S110>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S110>/Moving Standard Deviation2' */
      rtb_Gain_m = (float32) LKAS_MovingStandardDeviation1(rtb_Gain1_j,
        &LKAS_DW.MovingStandardDeviation2_d);

      /* End of Outputs for SubSystem: '<S110>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S110>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain_m <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S110>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_e, &LKAS_DW.SumCondition_c);

      /* End of Outputs for SubSystem: '<S110>/Sum Condition' */

      /* Logic: '<S110>/Logical Operator2' incorporates:
       *  Constant: '<S552>/LL_LKAExPrcs_ExitC0Swt=1'
       *  Logic: '<S110>/Logical Operator1'
       *  RelationalOperator: '<S110>/Relational Operator4'
       *  Switch: '<S552>/Switch46'
       */
      rtb_LogicalOperator3_b5 = ((((((rtb_Saturation2_n >= rtb_Saturation6) &&
        rtb_LogicalOperator3_b5) && rtb_LL_SingleLane_Disable_Swt) &&
        (LKAS_DW.RelationalOperator_k3)) && (LKAS_DW.RelationalOperator_e)) &&
        ((LKAS_ConstB.DataTypeConversion35) || (LL_LKAExPrcs_ExitC0Swt)));

      /* Fcn: '<S90>/Fcn' incorporates:
       *  DataTypeConversion: '<S90>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((rtb_LogicalOperator3_b5 ? 1 : 0) *
        (rtb_LogicalOperator3_b5 ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!rtb_LogicalOperator3_b5) ? 1 : 0)) * (LKAS_DW.RelationalOperator_ew ?
        1 : 0)) * ((sint32)2.0F))) + (((sint32)(((!LKAS_DW.RelationalOperator_ew)
        && (!rtb_LogicalOperator3_b5)) ? 1 : 0)) * (rtb_BCM_Right_Light ? 1 : 0))));

      /* Logic: '<S90>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_BCM_Right_Light ||
        (LKAS_DW.RelationalOperator_ew)) || rtb_LogicalOperator3_b5);

      /* DataTypeConversion: '<S93>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon_l = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Sum: '<S98>/Add' */
      rtb_Gain2_bi = rtb_IMAPve_g_EPS_SW_Trq - rtb_Yk1_mo;

      /* Abs: '<S98>/Abs' */
      rtb_Gain2_bi = fabsf(rtb_Gain2_bi);

      /* Saturate: '<S98>/Saturation4' */
      if (rtb_Gain2_bi > 1.0F) {
        rtb_Gain2_bi = 1.0F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S98>/Saturation4' */

      /* Product: '<S98>/Divide2' incorporates:
       *  Constant: '<S98>/Constant'
       */
      rtb_Gain2_bi /= 0.5F;

      /* Saturate: '<S98>/Saturation5' */
      if (rtb_Gain2_bi > 1.0F) {
        rtb_Gain2_bi = 1.0F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S98>/Saturation5' */

      /* Product: '<S98>/Divide1' */
      rtb_Gain2_bi *= rtb_R0_C1_e;

      /* Saturate: '<S98>/Saturation3' */
      if (rtb_Gain2_bi > 0.2F) {
        rtb_Gain2_bi = 0.2F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S98>/Saturation3' */

      /* Sum: '<S107>/Add2' incorporates:
       *  Memory: '<S107>/Memory3'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_e;

      /* Saturate: '<S107>/Saturation' */
      if (rtb_TLft > 50.0F) {
        rtb_Saturation_gi = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation_gi = 0.0F;
      } else {
        rtb_Saturation_gi = rtb_TLft;
      }

      /* End of Saturate: '<S107>/Saturation' */

      /* MATLAB Function: '<S98>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem1/MATLAB Function': '<S105>:1' */
      /* '<S105>:1:2' if T<T1 */
      if (rtb_Saturation_gi < rtb_Saturation6) {
        /* '<S105>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_LL_LKASWASyn_M0 += ((rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6) * rtb_Saturation_gi;
      } else if ((rtb_Saturation_gi >= rtb_Saturation6) && (rtb_Saturation_gi <=
                  (rtb_Saturation6 + rtb_LL_LKASWASyn_T2))) {
        /* Switch: '<S552>/Switch14' incorporates:
         *  Constant: '<S552>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S105>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S105>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_i != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_i;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (((x10 - rtb_LL_LKASWASyn_M1) /
          rtb_LL_LKASWASyn_T2) * (rtb_Saturation_gi - rtb_Saturation6)) +
          rtb_LL_LKASWASyn_M1;
      } else {
        /* Switch: '<S552>/Switch14' incorporates:
         *  Constant: '<S552>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S105>:1:6' else */
        /* '<S105>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_i != 0.0F) {
          rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20_i;
        } else {
          rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S98>/MATLAB Function' */

      /* Product: '<S98>/Divide' */
      rtb_TLft = rtb_deltafalllimit_k * rtb_R0_C1_e;

      /* Saturate: '<S98>/Saturation1' */
      if (rtb_TLft > 0.2F) {
        rtb_TLft = 0.2F;
      } else {
        if (rtb_TLft < 0.0F) {
          rtb_TLft = 0.0F;
        }
      }

      /* End of Saturate: '<S98>/Saturation1' */

      /* Sum: '<S98>/Add1' */
      rtb_Gain2_bi = (rtb_LL_LKASWASyn_M0 - rtb_Gain2_bi) - rtb_TLft;

      /* Saturate: '<S98>/Saturation2' */
      if (rtb_Gain2_bi > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Gain2_bi < 0.01F) {
        LKAS_DW.Saturation2 = 0.01F;
      } else {
        LKAS_DW.Saturation2 = rtb_Gain2_bi;
      }

      /* End of Saturate: '<S98>/Saturation2' */

      /* Sum: '<S201>/Add2' incorporates:
       *  Memory: '<S201>/Memory3'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_f;

      /* Saturate: '<S201>/Saturation' */
      if (rtb_TLft > 50.0F) {
        rtb_Saturation_mf = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation_mf = 0.0F;
      } else {
        rtb_Saturation_mf = rtb_TLft;
      }

      /* End of Saturate: '<S201>/Saturation' */

      /* If: '<S199>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       *  Inport: '<S207>/Plan'
       *  Inport: '<S207>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_m;
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_m = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S199>/If Action Subsystem' incorporates:
           *  ActionPort: '<S205>/Action Port'
           */
          /* InitializeConditions for If: '<S199>/If' incorporates:
           *  Memory: '<S205>/Memory'
           *  UnitDelay: '<S209>/Delay Input1'
           *
           * Block description for '<S209>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_pv = false;
          LKAS_DW.Memory_PreviousInput_h = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S199>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S199>/If Action Subsystem' incorporates:
         *  ActionPort: '<S205>/Action Port'
         */
        /* RelationalOperator: '<S208>/Compare' incorporates:
         *  Constant: '<S208>/Constant'
         */
        rtb_LogicalOperator3_b5 = (rtb_L0_C1_m >= 0.0F);

        /* Memory: '<S205>/Memory' */
        rtb_Plan_o = LKAS_DW.Memory_PreviousInput_h;

        /* Sum: '<S205>/Add' incorporates:
         *  Logic: '<S205>/Logical Operator'
         *  RelationalOperator: '<S205>/Relational Operator'
         *  RelationalOperator: '<S209>/FixPt Relational Operator'
         *  UnitDelay: '<S209>/Delay Input1'
         *
         * Block description for '<S209>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_j = ((float32)(((((sint32)(rtb_LogicalOperator3_b5 ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_pv ? 1 : 0))) && (rtb_Saturation6
          >= rtb_Saturation_mf)) ? 1 : 0)) + rtb_Plan_o;

        /* Saturate: '<S205>/Saturation' */
        if (rtb_T1_j > 5.0F) {
          rtb_Saturation_ja = 5.0F;
        } else if (rtb_T1_j < 0.0F) {
          rtb_Saturation_ja = 0.0F;
        } else {
          rtb_Saturation_ja = rtb_T1_j;
        }

        /* End of Saturate: '<S205>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S205>/If Action Subsystem' */
        LKAS_IfActionSubsystem_f(rtb_Saturation_ja, rtb_Saturation_mf,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_f, &LKAS_DW.In_g,
          &LKAS_DW.IfActionSubsystem_fz);

        /* End of Outputs for SubSystem: '<S205>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S205>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_e(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_j, &rtb_Plan_o);

        /* End of Outputs for SubSystem: '<S205>/If Action Subsystem2' */

        /* Switch: '<S205>/Switch' incorporates:
         *  Switch: '<S205>/Switch1'
         */
        if (rtb_Saturation_ja > 0.0F) {
          LKAS_DW.Merge_j = LKAS_DW.In_f;
          LKAS_DW.Merge1 = LKAS_DW.In_g;
        } else {
          LKAS_DW.Merge_j = rtb_T1_j;
          LKAS_DW.Merge1 = rtb_Plan_o;
        }

        /* End of Switch: '<S205>/Switch' */

        /* Update for UnitDelay: '<S209>/Delay Input1'
         *
         * Block description for '<S209>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_pv = rtb_LogicalOperator3_b5;

        /* Update for Memory: '<S205>/Memory' */
        LKAS_DW.Memory_PreviousInput_h = rtb_Saturation_ja;

        /* End of Outputs for SubSystem: '<S199>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S199>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S206>/Action Port'
           */
          /* InitializeConditions for If: '<S199>/If' incorporates:
           *  Memory: '<S206>/Memory'
           *  UnitDelay: '<S217>/Delay Input1'
           *
           * Block description for '<S217>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_pp = false;
          LKAS_DW.Memory_PreviousInput_b = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S199>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S199>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S206>/Action Port'
         */
        /* RelationalOperator: '<S216>/Compare' incorporates:
         *  Constant: '<S216>/Constant'
         */
        rtb_LogicalOperator3_b5 = (rtb_L0_C1_i <= 0.0F);

        /* Memory: '<S206>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_b;

        /* Sum: '<S206>/Add' incorporates:
         *  Logic: '<S206>/Logical Operator'
         *  RelationalOperator: '<S206>/Relational Operator'
         *  RelationalOperator: '<S217>/FixPt Relational Operator'
         *  UnitDelay: '<S217>/Delay Input1'
         *
         * Block description for '<S217>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_m = ((float32)(((((sint32)(rtb_LogicalOperator3_b5 ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_pp ? 1 : 0))) && (rtb_Saturation6
          >= rtb_Saturation_mf)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S206>/Saturation' */
        if (rtb_T1_m > 5.0F) {
          rtb_Saturation_ly = 5.0F;
        } else if (rtb_T1_m < 0.0F) {
          rtb_Saturation_ly = 0.0F;
        } else {
          rtb_Saturation_ly = rtb_T1_m;
        }

        /* End of Saturate: '<S206>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S206>/If Action Subsystem' */
        LKAS_IfActionSubsystem_f(rtb_Saturation_ly, rtb_Saturation_mf,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_c, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_l);

        /* End of Outputs for SubSystem: '<S206>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S206>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_e(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_m, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S206>/If Action Subsystem2' */

        /* Switch: '<S206>/Switch' incorporates:
         *  Switch: '<S206>/Switch1'
         */
        if (rtb_Saturation_ly > 0.0F) {
          LKAS_DW.Merge_j = LKAS_DW.In_c;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_j = rtb_T1_m;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S206>/Switch' */

        /* Update for UnitDelay: '<S217>/Delay Input1'
         *
         * Block description for '<S217>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_pp = rtb_LogicalOperator3_b5;

        /* Update for Memory: '<S206>/Memory' */
        LKAS_DW.Memory_PreviousInput_b = rtb_Saturation_ly;

        /* End of Outputs for SubSystem: '<S199>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S199>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S207>/Action Port'
         */
        LKAS_DW.Merge_j = rtb_Saturation6;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S199>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S199>/If' */

      /* Saturate: '<S95>/Saturation6' */
      if (LKAS_DW.Merge_j > 0.5F) {
        rtb_R0_C1_e = 0.5F;
      } else if (LKAS_DW.Merge_j < 0.2F) {
        rtb_R0_C1_e = 0.2F;
      } else {
        rtb_R0_C1_e = LKAS_DW.Merge_j;
      }

      /* End of Saturate: '<S95>/Saturation6' */

      /* Product: '<S95>/Divide' incorporates:
       *  Product: '<S202>/Divide'
       *  Product: '<S95>/Divide4'
       *  Sum: '<S95>/Add2'
       */
      rtb_R0_C1_e = (rtb_Saturation_mf - LKAS_DW.Merge_j) / rtb_R0_C1_e;
      rtb_Gain2_bi = rtb_R0_C1_e;

      /* Saturate: '<S95>/Saturation2' */
      if (rtb_Gain2_bi > 1.0F) {
        rtb_Gain2_bi = 1.0F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S95>/Saturation2' */

      /* Sum: '<S95>/Add5' incorporates:
       *  Constant: '<S95>/Constant2'
       */
      rtb_LL_LKASWASyn_M0 = 1.0F - rtb_Gain2_bi;

      /* Product: '<S251>/Z*Z' incorporates:
       *  Product: '<S249>/Z*Z'
       */
      rtb_LL_LKASWASyn_M1 = rtb_LL_HdAgPrvwT_C * rtb_LL_HdAgPrvwT_C;

      /* Sum: '<S184>/Add1' incorporates:
       *  Gain: '<S230>/Gain2'
       *  Memory: '<S184>/Memory'
       *  Product: '<S184>/Divide'
       *  Product: '<S184>/Divide1'
       *  Product: '<S249>/Product3'
       *  Product: '<S249>/Product4'
       *  Product: '<S251>/Product3'
       *  Product: '<S251>/Product4'
       *  Product: '<S251>/Z*Z'
       *  Sum: '<S230>/Add2'
       *  Sum: '<S249>/Add'
       *  Sum: '<S251>/Add'
       */
      rtb_Add1_h = ((((((rtb_Add_p_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_m) +
                       (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * rtb_LL_LKASWASyn_M1))
                      + (((rtb_Add_o_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_i) +
                         (rtb_LL_ThresDet_lDvtThresLwrLKA * rtb_LL_LKASWASyn_M1)))
                     * 0.5F) * LKAS_ConstB.Divide2_k) + (LKAS_ConstB.Add2_o *
        LKAS_DW.Memory_PreviousInput_g);

      /* Gain: '<S182>/kph to mps' */
      rtb_kphtomps_l = rtb_LKA_Veh2CamL_C_tmp;

      /* MATLAB Function: '<S182>/Saturable Gain Lut (SatGainLut)' */
      LKAS_SaturableGainLutSatGainLut(rtb_IMAPve_g_ESC_VehSpd,
        rtb_LL_LFClb_TFC_KpVehSpdLwr_C, rtb_LL_LFClb_TFC_KpVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KpV1_C, rtb_LL_LFClb_TFC_KpV2_C, &rtb_Gain_m);

      /* Switch: '<S552>/Switch32' incorporates:
       *  Constant: '<S552>/LL_LFClb_TFC_PrvwT_C=2'
       */
      if (LKAS_ConstB.DataTypeConversion15_f != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_f;
      } else {
        x10 = LL_LFClb_TFC_PrvwT_C;
      }

      /* End of Switch: '<S552>/Switch32' */

      /* Product: '<S182>/Divide1' */
      rtb_TLft = x10 * rtb_kphtomps_l;

      /* Switch: '<S552>/Switch30' incorporates:
       *  Constant: '<S552>/LL_LFClb_TFC_KpKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_g != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_g;
      } else {
        x10 = LL_LFClb_TFC_KpKlat_C;
      }

      /* End of Switch: '<S552>/Switch30' */

      /* Saturate: '<S182>/Saturation' */
      if (rtb_TLft > 40.0F) {
        rtb_TLft = 40.0F;
      } else {
        if (rtb_TLft < 5.0F) {
          rtb_TLft = 5.0F;
        }
      }

      /* End of Saturate: '<S182>/Saturation' */

      /* Sum: '<S182>/Subtract2' incorporates:
       *  Gain: '<S228>/Gain1'
       *  Product: '<S182>/Divide3'
       *  Sum: '<S182>/Add1'
       */
      rtb_LL_HdAgPrvwT_C = rtb_Add1_h - (rtb_LL_HdAgPrvwT_C *
        rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Product: '<S182>/Product4' incorporates:
       *  Gain: '<S229>/Gain1'
       *  Product: '<S182>/Divide'
       *  Product: '<S182>/Product1'
       *  Sum: '<S182>/Subtract1'
       *  Sum: '<S182>/Subtract2'
       *  Sum: '<S229>/Add1'
       */
      rtb_L0_C3_dc = (((((rtb_Add_am + rtb_Add_e1) * 0.5F) / rtb_TLft) * x10) -
                      rtb_LL_HdAgPrvwT_C) * rtb_Gain_m;

      /* Switch: '<S552>/Switch19' incorporates:
       *  Constant: '<S552>/LL_LFClb_TFC_Kp_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion26_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion26_h;
      } else {
        x10 = LL_LFClb_TFC_Kp_C;
      }

      /* End of Switch: '<S552>/Switch19' */

      /* Product: '<S182>/Product2' */
      rtb_deltafalllimit_k = rtb_L0_C3_dc * x10;

      /* Saturate: '<S182>/Saturation2' */
      if (rtb_deltafalllimit_k > 360.0F) {
        rtb_deltafalllimit_k = 360.0F;
      } else {
        if (rtb_deltafalllimit_k < (-360.0F)) {
          rtb_deltafalllimit_k = (-360.0F);
        }
      }

      /* End of Saturate: '<S182>/Saturation2' */

      /* Abs: '<S182>/Abs' incorporates:
       *  Gain: '<S228>/Gain1'
       */
      rtb_Yk1_mo = fabsf(rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Saturate: '<S182>/Saturation1' */
      if (rtb_Yk1_mo > 0.004F) {
        rtb_Yk1_mo = 0.004F;
      } else {
        if (rtb_Yk1_mo < 1.0E-5F) {
          rtb_Yk1_mo = 1.0E-5F;
        }
      }

      /* End of Saturate: '<S182>/Saturation1' */

      /* Switch: '<S552>/Switch39' incorporates:
       *  Constant: '<S552>/LL_LFClb_TFC_KiMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_KiMaxSWA_C;
      }

      /* End of Switch: '<S552>/Switch39' */

      /* Sum: '<S182>/Add3' incorporates:
       *  Constant: '<S182>/Constant3'
       *  Constant: '<S182>/Constant4'
       *  Product: '<S182>/Divide4'
       *  Sum: '<S182>/Add5'
       */
      rtb_Yk1_mo = (((x10 - 1.0F) * rtb_Yk1_mo) / 0.004F) + 1.0F;

      /* Sum: '<S190>/Add2' incorporates:
       *  Memory: '<S190>/Memory3'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_m;

      /* Saturate: '<S190>/Saturation' */
      if (rtb_TLft > 50.0F) {
        rtb_Saturation_j = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation_j = 0.0F;
      } else {
        rtb_Saturation_j = rtb_TLft;
      }

      /* End of Saturate: '<S190>/Saturation' */

      /* Switch: '<S182>/Switch2' incorporates:
       *  Product: '<S182>/Divide2'
       *  Sum: '<S182>/Add'
       *  Sum: '<S182>/Add2'
       *  Switch: '<S552>/Switch40'
       *  UnitDelay: '<S182>/Unit Delay'
       */
      if ((rtb_Saturation_j - rtb_Saturation6) >= 0.0F) {
        /* Switch: '<S552>/Switch40' incorporates:
         *  Constant: '<S552>/LL_LFClb_TFC_Ki_C=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_i = (rtb_L0_C3_dc * x10) + LKAS_DW.UnitDelay_DSTATE_a;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S552>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S552>/Switch40' incorporates:
           *  Constant: '<S552>/LL_LFClb_TFC_Ki_C=0.01'
           */
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_i = rtb_L0_C3_dc * x10;
      }

      /* End of Switch: '<S182>/Switch2' */

      /* Gain: '<S182>/Gain' */
      rtb_L0_C3_dc = (-1.0F) * rtb_Yk1_mo;

      /* Switch: '<S187>/Switch' incorporates:
       *  RelationalOperator: '<S187>/UpperRelop'
       */
      if (rtb_Switch2_i < rtb_L0_C3_dc) {
        rtb_Switch_k = rtb_L0_C3_dc;
      } else {
        rtb_Switch_k = rtb_Switch2_i;
      }

      /* End of Switch: '<S187>/Switch' */

      /* Switch: '<S187>/Switch2' incorporates:
       *  RelationalOperator: '<S187>/LowerRelop1'
       */
      if (rtb_Switch2_i > rtb_Yk1_mo) {
        rtb_Switch2_at = rtb_Yk1_mo;
      } else {
        rtb_Switch2_at = rtb_Switch_k;
      }

      /* End of Switch: '<S187>/Switch2' */

      /* Product: '<S95>/Divide1' incorporates:
       *  Sum: '<S95>/Add3'
       */
      rtb_L0_C3 = (rtb_deltafalllimit_k + rtb_Switch2_at) * rtb_Gain2_bi;

      /* Switch: '<S552>/Switch49' incorporates:
       *  Constant: '<S552>/LL_LFClb_TFC_KdMaxSWA_C=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_KdMaxSWA_C;
      }

      /* End of Switch: '<S552>/Switch49' */

      /* Product: '<S182>/Divide8' incorporates:
       *  Constant: '<S182>/Constant7'
       *  Constant: '<S182>/Constant8'
       *  Sum: '<S182>/Add4'
       */
      rtb_Yk1_mo = ((180.0F - rtb_kphtomps_l) * x10) / 120.0F;

      /* MATLAB Function: '<S182>/Saturable Gain Lut (SatGainLut)1' */
      LKAS_SaturableGainLutSatGainLut(rtb_kphtomps_l,
        rtb_LL_LFClb_TFC_KdVehSpdLwr_C, rtb_LL_LFClb_TFC_KdVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KdV1_C, rtb_LL_LFClb_TFC_KdV2_C, &rtb_Gain_m);

      /* Product: '<S189>/Divide1' incorporates:
       *  Constant: '<S189>/Constant3'
       *  Sum: '<S189>/Add4'
       */
      rtb_deltafalllimit_k = (1.0F + rtb_Abs_k) * rtb_Gain_m;

      /* Gain: '<S189>/Gain' incorporates:
       *  Abs: '<S189>/Abs'
       */
      rtb_L0_C3_dc = fabsf(rtb_LL_ThresDet_lDvtThresUprLKA) * 0.5F;

      /* Gain: '<S189>/Gain1' incorporates:
       *  Sum: '<S189>/Add2'
       */
      rtb_Gain1_i5 = (rtb_L0_C0_o + rtb_R0_C0_n) * 0.5F;

      /* Gain: '<S189>/Gain2' */
      rtb_Gain2_bi = (-1.0F) * rtb_L0_C3_dc;

      /* Switch: '<S194>/Switch' incorporates:
       *  RelationalOperator: '<S194>/UpperRelop'
       */
      if (rtb_Gain1_i5 < rtb_Gain2_bi) {
        rtb_Switch_fy = rtb_Gain2_bi;
      } else {
        rtb_Switch_fy = rtb_Gain1_i5;
      }

      /* End of Switch: '<S194>/Switch' */

      /* Switch: '<S194>/Switch2' incorporates:
       *  RelationalOperator: '<S194>/LowerRelop1'
       */
      if (rtb_Gain1_i5 > rtb_L0_C3_dc) {
        rtb_Switch2_g1 = rtb_L0_C3_dc;
      } else {
        rtb_Switch2_g1 = rtb_Switch_fy;
      }

      /* End of Switch: '<S194>/Switch2' */

      /* Product: '<S189>/Divide4' */
      rtb_L0_C3_dc = (rtb_Switch2_g1 / rtb_L0_C3_dc) * rtb_Abs_k;

      /* Product: '<S189>/Divide5' incorporates:
       *  Constant: '<S189>/Constant2'
       *  Sum: '<S189>/Add5'
       */
      rtb_Divide5 = (1.0F + rtb_L0_C3_dc) * rtb_Gain_m;

      /* Product: '<S189>/Divide2' incorporates:
       *  Constant: '<S189>/Constant2'
       *  Sum: '<S189>/Add1'
       */
      rtb_Divide2_b = (1.0F - rtb_L0_C3_dc) * rtb_Gain_m;

      /* Sum: '<S196>/Add' incorporates:
       *  Constant: '<S196>/Constant'
       *  Memory: '<S196>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_f4));

      /* Saturate: '<S196>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_mm = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_mm = ((uint16)10000U);
      }

      /* End of Saturate: '<S196>/Saturation1' */

      /* If: '<S196>/If' incorporates:
       *  Constant: '<S196>/Constant2'
       *  DataTypeConversion: '<S80>/Cast To Single'
       *  Inport: '<S197>/In'
       */
      if (rtb_Saturation1_mm == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S196>/if action ' incorporates:
         *  ActionPort: '<S197>/Action Port'
         */
        LKAS_DW.In_h = LKAS_DW.LKASM_stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S196>/if action ' */
      }

      /* End of If: '<S196>/If' */

      /* If: '<S189>/If' incorporates:
       *  Inport: '<S193>/In1'
       */
      if (((sint32)LKAS_DW.In_h) == 1) {
        /* Outputs for IfAction SubSystem: '<S189>/If Action Subsystem' incorporates:
         *  ActionPort: '<S191>/Action Port'
         */
        LKAS_IfActionSubsystem_a(rtb_Divide2_b, &rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S189>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_h) == 2) {
        /* Outputs for IfAction SubSystem: '<S189>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S192>/Action Port'
         */
        LKAS_IfActionSubsystem_a(rtb_Divide5, &rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S189>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S189>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S193>/Action Port'
         */
        rtb_Merge_d = rtb_Gain_m;

        /* End of Outputs for SubSystem: '<S189>/If Action Subsystem2' */
      }

      /* End of If: '<S189>/If' */

      /* Product: '<S189>/Divide3' incorporates:
       *  Constant: '<S189>/Constant1'
       *  Sum: '<S189>/Add3'
       */
      rtb_L0_C3_dc = (1.0F - rtb_Abs_k) * rtb_Gain_m;

      /* Switch: '<S195>/Switch' incorporates:
       *  RelationalOperator: '<S195>/UpperRelop'
       */
      if (rtb_Merge_d < rtb_L0_C3_dc) {
        rtb_Switch_fl = rtb_L0_C3_dc;
      } else {
        rtb_Switch_fl = rtb_Merge_d;
      }

      /* End of Switch: '<S195>/Switch' */

      /* Switch: '<S195>/Switch2' incorporates:
       *  RelationalOperator: '<S195>/LowerRelop1'
       */
      if (rtb_Merge_d > rtb_deltafalllimit_k) {
        rtb_Switch2_k = rtb_deltafalllimit_k;
      } else {
        rtb_Switch2_k = rtb_Switch_fl;
      }

      /* End of Switch: '<S195>/Switch2' */

      /* Product: '<S182>/Divide7' incorporates:
       *  Gain: '<S182>/Gain1'
       */
      rtb_Divide7 = (rtb_LL_HdAgPrvwT_C * (-1.0F)) * rtb_Switch2_k;

      /* Gain: '<S182>/Gain3' */
      rtb_deltafalllimit_k = (-1.0F) * rtb_Yk1_mo;

      /* Switch: '<S188>/Switch' incorporates:
       *  RelationalOperator: '<S188>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_deltafalllimit_k) {
        rtb_Switch_pi = rtb_deltafalllimit_k;
      } else {
        rtb_Switch_pi = rtb_Divide7;
      }

      /* End of Switch: '<S188>/Switch' */

      /* Switch: '<S188>/Switch2' incorporates:
       *  RelationalOperator: '<S188>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_Yk1_mo) {
        rtb_Switch2_p = rtb_Yk1_mo;
      } else {
        rtb_Switch2_p = rtb_Switch_pi;
      }

      /* End of Switch: '<S188>/Switch2' */

      /* Product: '<S95>/Divide4' */
      rtb_Yk1_mo = rtb_R0_C1_e;

      /* Saturate: '<S95>/Saturation1' */
      if (rtb_Yk1_mo > 1.0F) {
        rtb_Yk1_mo = 1.0F;
      } else {
        if (rtb_Yk1_mo < 0.0F) {
          rtb_Yk1_mo = 0.0F;
        }
      }

      /* End of Saturate: '<S95>/Saturation1' */

      /* Product: '<S95>/Divide2' */
      rtb_L0_C0_o = rtb_Switch2_p * rtb_Yk1_mo;

      /* Saturate: '<S202>/Saturation4' */
      if (rtb_R0_C1_e > 1.0F) {
        rtb_R0_C1_e = 1.0F;
      } else {
        if (rtb_R0_C1_e < 0.0F) {
          rtb_R0_C1_e = 0.0F;
        }
      }

      /* End of Saturate: '<S202>/Saturation4' */

      /* Gain: '<S183>/kph to mps' */
      rtb_Yk1_mo = rtb_LKA_Veh2CamL_C_tmp;

      /* Saturate: '<S183>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        rtb_deltafalllimit_k = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        rtb_deltafalllimit_k = 60.0F;
      } else {
        rtb_deltafalllimit_k = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S183>/Saturation3' */

      /* Product: '<S183>/Divide2' incorporates:
       *  Constant: '<S183>/Constant'
       */
      rtb_deltafalllimit_k = 0.09F / rtb_deltafalllimit_k;

      /* Saturate: '<S183>/Saturation1' */
      if (rtb_deltafalllimit_k > 0.01F) {
        rtb_deltafalllimit_k = 0.01F;
      } else {
        if (rtb_deltafalllimit_k < 0.0F) {
          rtb_deltafalllimit_k = 0.0F;
        }
      }

      /* End of Saturate: '<S183>/Saturation1' */

      /* Switch: '<S552>/Switch36' incorporates:
       *  Constant: '<S552>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_p != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_p;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S552>/Switch36' */

      /* Gain: '<S183>/Gain2' incorporates:
       *  Constant: '<S183>/Constant1'
       *  Gain: '<S183>/rad to deg'
       *  Gain: '<S228>/Gain1'
       *  Math: '<S183>/Math Function'
       *  Product: '<S183>/Divide'
       *  Product: '<S183>/Divide1'
       *  Product: '<S183>/Product'
       *  Product: '<S183>/Product1'
       *  Product: '<S183>/Product2'
       *  Product: '<S183>/Product3'
       *  Sum: '<S183>/Add'
       *
       * About '<S183>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_Yk1_mo = (((((((rtb_Yk1_mo * rtb_Yk1_mo) * rtb_deltafalllimit_k) +
                        1.0F) / (rtb_Yk1_mo / LKAS_DW.LKA_WhlBaseL_C_m)) *
                      ((rtb_Yk1_mo * rtb_LL_ThresDet_tiTTLCThresLDW) *
                       57.2957802F)) * x10) * LKAS_DW.LKA_StrRatio_C_d) * (-1.0F);

      /* Product: '<S95>/Divide5' incorporates:
       *  Constant: '<S202>/Constant1'
       *  Product: '<S202>/Divide8'
       *  Sum: '<S202>/Add1'
       */
      rtb_deltafalllimit_k = ((LKAS_ConstB.Add3 * rtb_R0_C1_e) + 0.0F) *
        rtb_Yk1_mo;

      /* Product: '<S95>/Divide3' */
      rtb_TLft = rtb_Saturation_mf / LKAS_DW.Merge_j;

      /* Saturate: '<S95>/Saturation' */
      if (rtb_TLft > 1.0F) {
        rtb_TLft = 1.0F;
      } else {
        if (rtb_TLft < 0.0F) {
          rtb_TLft = 0.0F;
        }
      }

      /* End of Saturate: '<S95>/Saturation' */

      /* Sum: '<S95>/Add4' incorporates:
       *  Product: '<S95>/Divide6'
       *  Product: '<S95>/Divide7'
       */
      rtb_L0_C0_o = ((((LKAS_DW.Merge1 * rtb_LL_LKASWASyn_M0) + rtb_L0_C3) +
                      rtb_L0_C0_o) + rtb_deltafalllimit_k) +
        (LKAS_DW.DifferenceInputs2_g * rtb_TLft);

      /* Memory: '<S200>/Memory3' */
      rtb_deltafalllimit_k = LKAS_DW.Memory3_PreviousInput_n;

      /* Sum: '<S200>/Add2' incorporates:
       *  Constant: '<S200>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_deltafalllimit_k += 1.0F;

      /* Saturate: '<S200>/Saturation' */
      if (rtb_deltafalllimit_k > 50.0F) {
        rtb_Saturation_nv = 50.0F;
      } else if (rtb_deltafalllimit_k < 0.0F) {
        rtb_Saturation_nv = 0.0F;
      } else {
        rtb_Saturation_nv = rtb_deltafalllimit_k;
      }

      /* End of Saturate: '<S200>/Saturation' */

      /* Switch: '<S200>/Switch' incorporates:
       *  Constant: '<S95>/Constant1'
       *  Product: '<S200>/Divide'
       *  Product: '<S200>/Divide1'
       *  Sum: '<S200>/Add'
       *  Sum: '<S200>/Add1'
       *  UnitDelay: '<S200>/Unit Delay'
       */
      if (rtb_Saturation_nv > 30.0F) {
        rtb_Switch_dj = ((rtb_LKA_SampleTime / 0.1F) * (rtb_L0_C0_o -
          LKAS_DW.UnitDelay_DSTATE_g)) + LKAS_DW.UnitDelay_DSTATE_g;
      } else {
        rtb_Switch_dj = rtb_L0_C0_o;
      }

      /* End of Switch: '<S200>/Switch' */

      /* Switch: '<S552>/Switch17' incorporates:
       *  Constant: '<S552>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S552>/Switch17' */

      /* Sum: '<S92>/Add' */
      rtb_Add_of = (rtb_Switch_dj - x10) + LKAS_DW.Saturation_h;

      /* Sum: '<S92>/Add1' */
      rtb_deltafalllimit_k = rtb_Yk1_mo + rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S92>/Add2' incorporates:
       *  Gain: '<S92>/Gain2'
       */
      rtb_Yk1_mo += (-1.0F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S178>/Switch' incorporates:
       *  RelationalOperator: '<S178>/UpperRelop'
       */
      if (rtb_Add_of < rtb_Yk1_mo) {
        rtb_Switch_og = rtb_Yk1_mo;
      } else {
        rtb_Switch_og = rtb_Add_of;
      }

      /* End of Switch: '<S178>/Switch' */

      /* Switch: '<S178>/Switch2' incorporates:
       *  RelationalOperator: '<S178>/LowerRelop1'
       */
      if (rtb_Add_of > rtb_deltafalllimit_k) {
        rtb_Switch2_m = rtb_deltafalllimit_k;
      } else {
        rtb_Switch2_m = rtb_Switch_og;
      }

      /* End of Switch: '<S178>/Switch2' */

      /* Sum: '<S177>/Add1' incorporates:
       *  Constant: '<S177>/Constant'
       *  Memory: '<S177>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_e1));

      /* Switch: '<S177>/Switch' incorporates:
       *  Constant: '<S177>/LatchTime_SY'
       *  RelationalOperator: '<S177>/Relational Operator'
       *  UnitDelay: '<S177>/Delay Input2'
       *
       * Block description for '<S177>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_h5 <= ((uint16)1U)) {
        rtb_Yk1_mo = rtb_Switch2_m;
      } else {
        rtb_Yk1_mo = LKAS_DW.DelayInput2_DSTATE_b;
      }

      /* End of Switch: '<S177>/Switch' */

      /* Sum: '<S177>/Difference Inputs1'
       *
       * Block description for '<S177>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_o = rtb_Switch2_m - rtb_Yk1_mo;

      /* SampleTimeMath: '<S177>/sample time'
       *
       * About '<S177>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_deltafalllimit_k = 0.01F;

      /* Product: '<S177>/delta rise limit' incorporates:
       *  Gain: '<S92>/Gain3'
       */
      rtb_L0_C3_dc = (1.4F * LKAS_DW.SWARmax) * rtb_deltafalllimit_k;

      /* Product: '<S177>/delta fall limit' incorporates:
       *  Gain: '<S92>/Gain1'
       */
      rtb_deltafalllimit_k *= (-1.4F) * LKAS_DW.SWARmax;

      /* Switch: '<S179>/Switch' incorporates:
       *  RelationalOperator: '<S179>/UpperRelop'
       */
      if (rtb_UkYk1_o < rtb_deltafalllimit_k) {
        rtb_Switch_dr = rtb_deltafalllimit_k;
      } else {
        rtb_Switch_dr = rtb_UkYk1_o;
      }

      /* End of Switch: '<S179>/Switch' */

      /* Switch: '<S179>/Switch2' incorporates:
       *  RelationalOperator: '<S179>/LowerRelop1'
       */
      if (rtb_UkYk1_o > rtb_L0_C3_dc) {
        rtb_Switch2_co = rtb_L0_C3_dc;
      } else {
        rtb_Switch2_co = rtb_Switch_dr;
      }

      /* End of Switch: '<S179>/Switch2' */

      /* Sum: '<S177>/Difference Inputs2'
       *
       * Block description for '<S177>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_co + rtb_Yk1_mo;

      /* Saturate: '<S177>/Saturation2' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation2_b = rtb_Saturation_h5;
      } else {
        rtb_Saturation2_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S177>/Saturation2' */

      /* DataTypeConversion: '<S93>/CastLKA3' */
      LKAS_DW.T1_Mon_g = LKAS_DW.Merge_j;

      /* DataTypeConversion: '<S117>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_IMAPve_g_ESC_VehSpd;

      /* DataTypeConversion: '<S93>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon_p = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S91>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S109>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S111>/Out' */
          LKAS_DW.RelationalOperator_ew = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S109>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S89>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S97>/Out1' */
          LKAS_DW.DifferenceInputs2_g = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S89>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_j.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_k3,
            &LKAS_DW.SumCondition1_j);
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition' */
        if (LKAS_DW.SumCondition_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_e,
            &LKAS_DW.SumCondition_c);
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition' */

        /* Disable for If: '<S199>/If' */
        LKAS_DW.If_ActiveSubsystem_m = -1;

        /* Disable for Outport: '<S80>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S80>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S80>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S80>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_l = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_p = 0.0F;
        LKAS_DW.T1_Mon_g = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon_l;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon_p;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.T1_Mon = LKAS_DW.T1_Mon_g;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_State_Mon = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LDW_State_Mon = LKAS_DW.LDWSM_stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.LDWSM_stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S79>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S84>/If' */
      if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S84>/If Action Subsystem' incorporates:
         *  ActionPort: '<S85>/Action Port'
         */
        /* Gain: '<S85>/rad to deg' incorporates:
         *  Gain: '<S85>/Gain'
         */
        LKAS_DW.Merge_l = ((-1.0F) * rtb_L0_C1_m) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S84>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S84>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S86>/Action Port'
         */
        /* Gain: '<S86>/rad to deg' */
        LKAS_DW.Merge_l = 57.2957802F * rtb_L0_C1_i;

        /* End of Outputs for SubSystem: '<S84>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S84>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S87>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_l);

        /* End of Outputs for SubSystem: '<S84>/If Action Subsystem2' */
      }

      /* End of If: '<S84>/If' */

      /* Switch: '<S551>/Switch2' incorporates:
       *  Constant: '<S551>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_j != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_j;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S551>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S84>/Sum Condition' incorporates:
       *  EnablePort: '<S88>/Enable'
       */
      /* RelationalOperator: '<S84>/Relational Operator' */
      if (LKAS_DW.Merge_l >= x10) {
        if (!LKAS_DW.SumCondition_MODE_o) {
          /* InitializeConditions for Memory: '<S88>/Memory' */
          LKAS_DW.Memory_PreviousInput_o2 = 0.0F;
          LKAS_DW.SumCondition_MODE_o = true;
        }

        /* Sum: '<S88>/Add1' incorporates:
         *  Memory: '<S88>/Memory'
         */
        rtb_L0_C1_i = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_o2;

        /* Saturate: '<S88>/Saturation' */
        if (rtb_L0_C1_i > 0.6F) {
          rtb_L0_C1_i = 0.6F;
        } else {
          if (rtb_L0_C1_i < 0.0F) {
            rtb_L0_C1_i = 0.0F;
          }
        }

        /* End of Saturate: '<S88>/Saturation' */

        /* RelationalOperator: '<S88>/Relational Operator' incorporates:
         *  Constant: '<S84>/Constant'
         */
        LKAS_DW.RelationalOperator_oh = (rtb_L0_C1_i >= 0.05F);

        /* Update for Memory: '<S88>/Memory' */
        LKAS_DW.Memory_PreviousInput_o2 = rtb_L0_C1_i;
      } else {
        if (LKAS_DW.SumCondition_MODE_o) {
          /* Disable for Outport: '<S88>/Out' */
          LKAS_DW.RelationalOperator_oh = false;
          LKAS_DW.SumCondition_MODE_o = false;
        }
      }

      /* End of RelationalOperator: '<S84>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S84>/Sum Condition' */

      /* Product: '<S79>/Product' incorporates:
       *  Logic: '<S79>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.LDWSM_stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_oh) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S84>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_o) {
          /* Disable for Outport: '<S88>/Out' */
          LKAS_DW.RelationalOperator_oh = false;
          LKAS_DW.SumCondition_MODE_o = false;
        }

        /* End of Disable for SubSystem: '<S84>/Sum Condition' */

        /* Disable for Outport: '<S79>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* If: '<S400>/If' incorporates:
     *  Constant: '<S406>/Constant'
     *  Delay: '<S82>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_IMAPve_d_EPS_LKA_State) != 1)) {
      /* Outputs for IfAction SubSystem: '<S400>/If Action Subsystem' incorporates:
       *  ActionPort: '<S404>/Action Port'
       */
      LKAS_IfActionSubsystem_n(&rtb_Merge_n);

      /* End of Outputs for SubSystem: '<S400>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_IMAPve_d_EPS_LKA_State) != 3)) {
      /* Outputs for IfAction SubSystem: '<S400>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S405>/Action Port'
       */
      LKAS_IfActionSubsystem_n(&rtb_Merge_n);

      /* End of Outputs for SubSystem: '<S400>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S400>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S406>/Action Port'
       */
      rtb_Merge_n = false;

      /* End of Outputs for SubSystem: '<S400>/If Action Subsystem3' */
    }

    /* End of If: '<S400>/If' */

    /* Outputs for Enabled SubSystem: '<S400>/Sum Condition1' */
    LKAS_SumCondition1(rtb_Merge_n, rtb_LKA_SampleTime,
                       rtb_LL_MAX_DELAY_EPSSTAR_TIME,
                       &LKAS_DW.RelationalOperator_n, &LKAS_DW.SumCondition1_l);

    /* End of Outputs for SubSystem: '<S400>/Sum Condition1' */

    /* SignalConversion: '<S459>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S372>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LKA_Main_Switch;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_Compare_mw;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_Compare_ho;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_iv;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_bp;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_ix;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_ab;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_cwd;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_f;
    rtb_TmpSignalConversionAtSFunct[12] = rtb_RelationalOperator_b;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_LogicalOperator_ol;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_m;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator_n;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_BCM_Left_Light;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge;

    /* MATLAB Function: '<S372>/Disable Reason' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S459>:1' */
    /* '<S459>:1:2' y = single(0); */
    rtb_L0_C1_i = 0.0F;

    /* '<S459>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S459>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S459>:1:5' y = single(i); */
        rtb_L0_C1_i = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Disable_Reason = rtb_L0_C1_i;

    /* DataTypeConversion: '<S273>/Cast' */
    ob_LKA_Disable_Reason = rtb_L0_C1_i;

    /* RelationalOperator: '<S410>/Compare' incorporates:
     *  Constant: '<S410>/Constant'
     */
    rtb_Compare_bi = (LKAS_DW.RelationalOperator_n == true);

    /* DataTypeConversion: '<S273>/Cast1' */
    ob_LKA_LKADeactvCSyn = (float32)(LKAS_DW.Merge1_c ? 1.0F : 0.0F);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LFTTTLC_Mon = rtb_LFTTTLC;

    /* Logic: '<S490>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S490>/Relational Operator3'
     *  RelationalOperator: '<S490>/Relational Operator4'
     */
    rtb_LogicalOperator1_f = ((rtb_Gain1_j <= rtb_R0_C2) || (rtb_Add5_n <=
      rtb_R0_C2));

    /* Gain: '<S225>/Gain' incorporates:
     *  Sum: '<S225>/Add'
     */
    rtb_lDvt = (rtb_Gain1_j + rtb_Add5_n) * 0.5F;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.DACMode = LKAS_DW.LKA_Mode;

    /* Gain: '<S224>/Gain' incorporates:
     *  Sum: '<S224>/Add'
     */
    rtb_crCrvt = (rtb_LL_CompHdAg_C + rtb_L0_C2) * 0.5F;

    /* Delay: '<S82>/Delay1' */
    rtb_DACMode = LKAS_DW.Delay1_2_DSTATE;

    /* RelationalOperator: '<S526>/Compare' incorporates:
     *  Constant: '<S526>/Constant'
     *  Constant: '<S560>/Constant14'
     */
    rtb_Compare_mx = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S535>/Compare' incorporates:
     *  Constant: '<S535>/Constant'
     *  Constant: '<S560>/Constant11'
     */
    rtb_Compare_hr = (((uint8)0U) == ((uint8)1U));
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S380>/ExitCount' */
      if (LKAS_DW.ExitCount_MODE) {
        /* Disable for Outport: '<S388>/Out' */
        LKAS_DW.RelationalOperator_f = false;
        LKAS_DW.ExitCount_MODE = false;
      }

      /* End of Disable for SubSystem: '<S380>/ExitCount' */

      /* Disable for Enabled SubSystem: '<S381>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S390>/Out' */
        LKAS_DW.RelationalOperator_n2 = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Disable for SubSystem: '<S381>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S391>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S395>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S391>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S319>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S350>/Out' */
        LKAS_DW.RelationalOperator_l1 = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S319>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S319>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S349>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S319>/Count' */

      /* Disable for Enabled SubSystem: '<S352>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_f) {
        /* Disable for Outport: '<S358>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_f = false;
      }

      /* End of Disable for SubSystem: '<S352>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S320>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S364>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }

      /* End of Disable for SubSystem: '<S320>/Sum Condition1' */

      /* Disable for If: '<S367>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S330>/Sum Condition' */
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S336>/Out' */
        LKAS_DW.RelationalOperator_na = false;
        LKAS_DW.SumCondition_MODE = false;
      }

      /* End of Disable for SubSystem: '<S330>/Sum Condition' */

      /* Disable for Enabled SubSystem: '<S278>/Count_5s3' */
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S540>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }

      /* End of Disable for SubSystem: '<S278>/Count_5s3' */

      /* Disable for Enabled SubSystem: '<S278>/Count_5s2' */
      if (LKAS_DW.Count_5s2.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_o, &LKAS_DW.Count_5s2);
      }

      /* End of Disable for SubSystem: '<S278>/Count_5s2' */

      /* Disable for Enabled SubSystem: '<S278>/Count_5s1' */
      if (LKAS_DW.Count_5s1.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_g, &LKAS_DW.Count_5s1);
      }

      /* End of Disable for SubSystem: '<S278>/Count_5s1' */

      /* Disable for Enabled SubSystem: '<S255>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_p) {
        /* Disable for Outport: '<S259>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Subsystem_MODE_p = false;
      }

      /* End of Disable for SubSystem: '<S255>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S91>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S109>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S111>/Out' */
          LKAS_DW.RelationalOperator_ew = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S109>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S89>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S97>/Out1' */
          LKAS_DW.DifferenceInputs2_g = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S89>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_j.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_k3,
            &LKAS_DW.SumCondition1_j);
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition' */
        if (LKAS_DW.SumCondition_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_e,
            &LKAS_DW.SumCondition_c);
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition' */

        /* Disable for If: '<S199>/If' */
        LKAS_DW.If_ActiveSubsystem_m = -1;

        /* Disable for Outport: '<S80>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S80>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S80>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S80>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_l = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_p = 0.0F;
        LKAS_DW.T1_Mon_g = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S84>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_o) {
          /* Disable for Outport: '<S88>/Out' */
          LKAS_DW.RelationalOperator_oh = false;
          LKAS_DW.SumCondition_MODE_o = false;
        }

        /* End of Disable for SubSystem: '<S84>/Sum Condition' */

        /* Disable for Outport: '<S79>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Enabled SubSystem: '<S400>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_l.SumCondition1_MODE) {
        LKAS_SumCondition1_Disable(&LKAS_DW.RelationalOperator_n,
          &LKAS_DW.SumCondition1_l);
      }

      /* End of Disable for SubSystem: '<S400>/Sum Condition1' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.DACMode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MATLAB Function: '<S8>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S51>/Switch'
   *  Switch: '<S51>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S29>:1' */
  /* '<S29>:1:2' if stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S29>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:6' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:8' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S29>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S29>:1:10' Vehicle_Lane_Display=uint8(10); */
        rtb_L0_Q = 10U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:12' Vehicle_Lane_Display=uint8(11); */
        rtb_L0_Q = 11U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:14' Vehicle_Lane_Display=uint8(12); */
        rtb_L0_Q = 12U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:16' Vehicle_Lane_Display=uint8(13); */
        rtb_L0_Q = 13U;
      } else {
        /* '<S29>:1:17' else */
        /* '<S29>:1:18' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S29>:1:4' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   case 2:
    /* '<S29>:1:20' elseif stDACmode==2 */
    /* '<S29>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:24' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:26' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S29>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S29>:1:28' Vehicle_Lane_Display=uint8(6); */
        rtb_L0_Q = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:30' Vehicle_Lane_Display=uint8(7); */
        rtb_L0_Q = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:32' Vehicle_Lane_Display=uint8(8); */
        rtb_L0_Q = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:34' Vehicle_Lane_Display=uint8(9); */
        rtb_L0_Q = 9U;
      } else {
        /* '<S29>:1:35' else */
        /* '<S29>:1:36' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S29>:1:22' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   default:
    /* '<S29>:1:38' else */
    /* '<S29>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_L0_Q = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/Vehicle_Lane_Display' */

  /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S11>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)1U);
    break;

   case 1:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)1U);
    break;

   case 2:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)2U);
    break;

   case 3:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)3U);
    break;

   case 4:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)4U);
    break;

   case 5:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)4U);
    break;

   default:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S11>/Multiport Switch' */

  /* RelationalOperator: '<S542>/Compare' incorporates:
   *  Constant: '<S542>/Constant'
   */
  rtb_Merge = (rtb_IMAPve_d_SAS_Trim_State == ((uint8)4U));

  /* Switch: '<S11>/Switch1' incorporates:
   *  Constant: '<S11>/1'
   *  Constant: '<S11>/x0'
   */
  if (rtb_Merge) {
    rtb_R0_Q = ((uint8)1U);
  } else {
    rtb_R0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S541>/Subsystem' incorporates:
   *  EnablePort: '<S548>/Enable'
   */
  if (((sint32)rtb_R0_Q) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S548>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S548>/Add' */
    rtb_L0_C2 = LKAS_DW.OutputSWACmd - rtb_IMAPve_g_SW_Angle;

    /* Sum: '<S548>/Add1' incorporates:
     *  Constant: '<S548>/Ki'
     *  Delay: '<S548>/Delay1'
     *  Product: '<S548>/Product2'
     */
    rtb_LL_CompHdAg_C = (rtb_L0_C2 * 0.0005F) + LKAS_DW.Delay1_DSTATE;

    /* Saturate: '<S548>/Saturation' */
    if (rtb_LL_CompHdAg_C > 0.5F) {
      rtb_LL_CompHdAg_C = 0.5F;
    } else {
      if (rtb_LL_CompHdAg_C < (-0.5F)) {
        rtb_LL_CompHdAg_C = (-0.5F);
      }
    }

    /* End of Saturate: '<S548>/Saturation' */

    /* Fcn: '<S548>/Fcn' */
    rtb_Abs_k = LKAS_DW.OutputSWACmd * LKAS_DW.OutputSWACmd;

    /* Sum: '<S548>/Add2' incorporates:
     *  Constant: '<S548>/Kp'
     *  Fcn: '<S548>/Fcn'
     *  Product: '<S548>/Product1'
     */
    LKAS_DW.in_trq = (((((rtb_Abs_k * LKAS_DW.OutputSWACmd) * 2.0e-6F) +
                        (rtb_Abs_k * -0.0005F)) + (LKAS_DW.OutputSWACmd *
      0.0505F)) + (rtb_L0_C2 * 0.02F)) + rtb_LL_CompHdAg_C;

    /* Update for Delay: '<S548>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_LL_CompHdAg_C;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S548>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S541>/Subsystem' */

  /* Sum: '<S546>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S546>/Delay Input2'
   *
   * Block description for '<S546>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S546>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S546>/delta rise limit' incorporates:
   *  Constant: '<S541>/Constant'
   *  SampleTimeMath: '<S546>/sample time'
   *
   * About '<S546>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_LL_CompHdAg_C = 5.0F * 0.01F;

  /* Product: '<S546>/delta fall limit' incorporates:
   *  Constant: '<S541>/Constant1'
   *  SampleTimeMath: '<S546>/sample time'
   *
   * About '<S546>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C1_i = (-5.0F) * 0.01F;

  /* Switch: '<S549>/Switch2' incorporates:
   *  Product: '<S546>/delta fall limit'
   *  Product: '<S546>/delta rise limit'
   *  RelationalOperator: '<S549>/LowerRelop1'
   *  RelationalOperator: '<S549>/UpperRelop'
   *  Switch: '<S549>/Switch'
   */
  if (rtb_L0_C2 > rtb_LL_CompHdAg_C) {
    rtb_L0_C2 = rtb_LL_CompHdAg_C;
  } else {
    if (rtb_L0_C2 < rtb_L0_C1_i) {
      /* Switch: '<S549>/Switch' incorporates:
       *  Product: '<S546>/delta fall limit'
       */
      rtb_L0_C2 = rtb_L0_C1_i;
    }
  }

  /* End of Switch: '<S549>/Switch2' */

  /* Sum: '<S546>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S546>/Delay Input2'
   *
   * Block description for '<S546>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S546>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 += LKAS_DW.DelayInput2_DSTATE;

  /* MATLAB Function: '<S8>/LDW_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Status_Display': '<S25>:1' */
  /* '<S25>:1:2' if (stDACmode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S25>:1:3' LDW_Status_Display=uint8(1); */
    rtb_TCU_ActualGear = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S25>:1:4' elseif (stDACmode==1)&&LDW_STATE==6 */
    /* '<S25>:1:5' LDW_Status_Display=uint8(2); */
    rtb_TCU_ActualGear = 2U;
  } else {
    /* '<S25>:1:6' else */
    /* '<S25>:1:7' LDW_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;
  }

  /* End of MATLAB Function: '<S8>/LDW_Status_Display' */

  /* MATLAB Function: '<S8>/LKA_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_Status_Display': '<S26>:1' */
  /* '<S26>:1:3' if stDACmode==2&&LKA_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) != 6)) {
    /* '<S26>:1:4' LKA_Status_Display=single(1); */
    rtb_LL_CompHdAg_C = 1.0F;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S26>:1:5' elseif stDACmode==2&&LKA_STATE==6 */
    /* '<S26>:1:6' LKA_Status_Display=single(2); */
    rtb_LL_CompHdAg_C = 2.0F;
  } else {
    /* '<S26>:1:7' else */
    /* '<S26>:1:8' LKA_Status_Display=single(0); */
    rtb_LL_CompHdAg_C = 0.0F;
  }

  /* End of MATLAB Function: '<S8>/LKA_Status_Display' */

  /* MATLAB Function: '<S8>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S24>:1' */
  /* '<S24>:1:2' if HMI_stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S24>:1:3' if HMI_LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S24>:1:4' LDW_Flag=uint8(1); */
      rtb_CastToSingle3 = 1U;
      break;

     case 2:
      /* '<S24>:1:5' elseif HMI_LDWWarnInfo==2 */
      /* '<S24>:1:6' LDW_Flag=uint8(2); */
      rtb_CastToSingle3 = 2U;
      break;

     default:
      /* '<S24>:1:7' else */
      /* '<S24>:1:8' LDW_Flag=uint8(0); */
      rtb_CastToSingle3 = 0U;
      break;
    }
    break;

   case 2:
    /* '<S24>:1:10' elseif HMI_stDACmode==2 */
    /* '<S24>:1:11' if HMI_LDWWarnInfo==1 && HMI_LKA_STATE==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S24>:1:12' LDW_Flag=uint8(1); */
      rtb_CastToSingle3 = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S24>:1:13' elseif HMI_LDWWarnInfo==2 && HMI_LKA_STATE==5 */
      /* '<S24>:1:14' LDW_Flag=uint8(2); */
      rtb_CastToSingle3 = 2U;
    } else {
      /* '<S24>:1:15' else */
      /* '<S24>:1:16' LDW_Flag=uint8(0); */
      rtb_CastToSingle3 = 0U;
    }
    break;

   default:
    /* '<S24>:1:18' else */
    /* '<S24>:1:19' LDW_Flag=uint8(0); */
    rtb_CastToSingle3 = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/LDW_Flag' */

  /* Switch: '<S28>/Switch' incorporates:
   *  Constant: '<S28>/Constant'
   *  Constant: '<S28>/Constant1'
   *  Constant: '<S30>/Constant'
   *  RelationalOperator: '<S30>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_LKA_Veh2CamL_C = 0.5F;
  } else {
    rtb_LKA_Veh2CamL_C = 0.25F;
  }

  /* End of Switch: '<S28>/Switch' */

  /* Logic: '<S28>/Logical Operator2' incorporates:
   *  Abs: '<S28>/Abs'
   *  Constant: '<S31>/Constant'
   *  Constant: '<S32>/Constant'
   *  Constant: '<S33>/Constant'
   *  Constant: '<S34>/Constant'
   *  Constant: '<S35>/Constant'
   *  Constant: '<S36>/Constant'
   *  Constant: '<S37>/Constant'
   *  Constant: '<S38>/Constant'
   *  Logic: '<S28>/Logical Operator1'
   *  Logic: '<S28>/Logical Operator3'
   *  RelationalOperator: '<S28>/Relational Operator'
   *  RelationalOperator: '<S31>/Compare'
   *  RelationalOperator: '<S32>/Compare'
   *  RelationalOperator: '<S33>/Compare'
   *  RelationalOperator: '<S34>/Compare'
   *  RelationalOperator: '<S35>/Compare'
   *  RelationalOperator: '<S36>/Compare'
   *  RelationalOperator: '<S37>/Compare'
   *  RelationalOperator: '<S38>/Compare'
   */
  rtb_LogicalOperator2 = ((((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (LKAS_DW.LKA_State == ((uint8)5U))) || (LKAS_DW.LKA_State == ((uint8)4U))) ||
    (LKAS_DW.LKA_State == ((uint8)3U))) && ((rtb_IMAPve_d_EPS_LKA_State ==
    ((uint8)3U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)))) && (fabsf
    (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_LKA_Veh2CamL_C));

  /* Switch: '<S553>/Switch2' incorporates:
   *  Constant: '<S553>/LL_RlsDet_tiTDelTime_DISABLE=2'
   *
   * Block description for '<S553>/LL_RlsDet_tiTDelTime_DISABLE=2':
   *  ��ʻԱ���ֿ�ʼ����������������ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion2_a != 0.0F) {
    rtb_LL_HandsOff_WarnTime = LKAS_ConstB.DataTypeConversion2_a;
  } else {
    rtb_LL_HandsOff_WarnTime = LL_HandsOff_WarnTime;
  }

  /* End of Switch: '<S553>/Switch2' */

  /* Outputs for Enabled SubSystem: '<S28>/Sum Condition2' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_WarnTime, &LKAS_DW.RelationalOperator_cf,
                     &LKAS_DW.SumCondition2);

  /* End of Outputs for SubSystem: '<S28>/Sum Condition2' */

  /* MATLAB Function: '<S8>/Hands_Off_Warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_Off_Warning': '<S23>:1' */
  /* '<S23>:1:2' if HandsOff==0 */
  if (!LKAS_DW.RelationalOperator_cf) {
    /* '<S23>:1:3' Hands_Off_Warning= uint8(0); */
    rtb_Hands_Off_Warning_c = 0U;
  } else {
    /* '<S23>:1:4' elseif HandsOff==1 */
    /* '<S23>:1:5' Hands_Off_Warning= uint8(1); */
    rtb_Hands_Off_Warning_c = 1U;
  }

  /* End of MATLAB Function: '<S8>/Hands_Off_Warning' */

  /* Switch: '<S553>/Switch1' incorporates:
   *  Constant: '<S553>/LL_RlsDet_tiTDelTime_DISABLE=1'
   *
   * Block description for '<S553>/LL_RlsDet_tiTDelTime_DISABLE=1':
   *  ��ʻԱ���ֿ�ʼ�����ܷ����������ѵ�ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_HandsOff_TextTime = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_HandsOff_TextTime = LL_HandsOff_TextTime;
  }

  /* End of Switch: '<S553>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S28>/Sum Condition1' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_TextTime, &LKAS_DW.RelationalOperator_e2,
                     &LKAS_DW.SumCondition1);

  /* End of Outputs for SubSystem: '<S28>/Sum Condition1' */

  /* MATLAB Function: '<S8>/HMI_Popup_Status' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S22>:1' */
  /* '<S22>:1:2' if stDACmode==2&&LKA_STATE==6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 6)) {
    /* �������ָ������� */
    /* '<S22>:1:3' HMI_Popup_Status=uint8(6); */
    rtb_IMAPve_d_Camera_Status = 6U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (((sint32)rtb_IMAPve_d_Camera_Status) == 5)) {
    /* '<S22>:1:6' elseif (stDACmode==2||stDACmode==1)&&(Front_Camera_Blocked==5) */
    /* ����ͷ���ڵ� */
    /* '<S22>:1:7' HMI_Popup_Status=uint8(4); */
    rtb_IMAPve_d_Camera_Status = 4U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (LKAS_DW.RelationalOperator_e2)) {
    /* '<S22>:1:8' elseif (stDACmode==2||stDACmode==1)&&HandsOff==1 */
    /* ���շ����� */
    /* '<S22>:1:9' HMI_Popup_Status=uint8(2); */
    rtb_IMAPve_d_Camera_Status = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              2)) {
    /* '<S22>:1:10' elseif stDACmode==2&&(LKA_STATE==2) */
    /* '<S22>:1:11' HMI_Popup_Status=uint8(1); */
    rtb_IMAPve_d_Camera_Status = 1U;
  } else if (((sint32)LKAS_DW.LKA_Mode) != 2) {
    /* '<S22>:1:12' elseif stDACmode~=2&&stFaultCSyn==0 */
    /* '<S22>:1:13' HMI_Popup_Status=uint8(8); */
    rtb_IMAPve_d_Camera_Status = 8U;
  } else {
    /* '<S22>:1:14' elseif stFaultCSyn==0 */
    /* '<S22>:1:15' HMI_Popup_Status=uint8(7); */
    rtb_IMAPve_d_Camera_Status = 7U;
  }

  /* End of MATLAB Function: '<S8>/HMI_Popup_Status' */

  /* MATLAB Function: '<S8>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S27>:1' */
  /* '<S27>:1:2' if stDACmode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S27>:1:3' LKA_Action_Indication=uint8(1); */
    rtb_LKA_Action_Indication_d = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S27>:1:4' elseif stDACmode==2&&LKA_STATE==3 */
    /* '<S27>:1:5' LKA_Action_Indication=uint8(2); */
    rtb_LKA_Action_Indication_d = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S27>:1:6' elseif stDACmode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S27>:1:7' LKA_Action_Indication=uint8(3); */
    rtb_LKA_Action_Indication_d = 3U;
  } else {
    /* '<S27>:1:8' else */
    /* '<S27>:1:9' LKA_Action_Indication=uint8(0); */
    rtb_LKA_Action_Indication_d = 0U;
  }

  /* End of MATLAB Function: '<S8>/LKA_action_indication' */

  /* DataTypeConversion: '<S11>/Cast To Single10' incorporates:
   *  Constant: '<S543>/Constant'
   *  RelationalOperator: '<S543>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.DACMode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S4>/Cast To Single1' */
  LKAS_DW.CastToSingle1 = LKAS_DW.LFTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single2' */
  LKAS_DW.CastToSingle2 = LKAS_DW.RGTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single3' */
  LKAS_DW.CastToSingle3 = (float32)LKAS_DW.LDW_State_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single4' */
  LKAS_DW.CastToSingle4 = (float32)LKAS_DW.LKA_State_Mon;

  /* S-Function (scanpack): '<S4>/CAN Pack' */
  /* S-Function (scanpack): '<S4>/CAN Pack' */
  LKAS_DW.CANPack.ID = 1U;
  LKAS_DW.CANPack.Length = 8U;
  LKAS_DW.CANPack.Extended = 0U;
  LKAS_DW.CANPack.Remote = 0;
  LKAS_DW.CANPack.Data[0] = 0;
  LKAS_DW.CANPack.Data[1] = 0;
  LKAS_DW.CANPack.Data[2] = 0;
  LKAS_DW.CANPack.Data[3] = 0;
  LKAS_DW.CANPack.Data[4] = 0;
  LKAS_DW.CANPack.Data[5] = 0;
  LKAS_DW.CANPack.Data[6] = 0;
  LKAS_DW.CANPack.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle1;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[1] = LKAS_DW.CANPack.Data[1] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[0] = LKAS_DW.CANPack.Data[0] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle2;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[3] = LKAS_DW.CANPack.Data[3] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[2] = LKAS_DW.CANPack.Data[2] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle3;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[5] = LKAS_DW.CANPack.Data[5] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[4] = LKAS_DW.CANPack.Data[4] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle4;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[7] = LKAS_DW.CANPack.Data[7] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[6] = LKAS_DW.CANPack.Data[6] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single5' */
  LKAS_DW.CastToSingle5 = LKAS_DW.LKA_ExitFlg_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single6' */
  LKAS_DW.CastToSingle6 = LKAS_DW.LKA_SampleTime_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single7' */
  LKAS_DW.CastToSingle7 = LKAS_DW.T1_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single8' */
  LKAS_DW.CastToSingle8 = LKAS_DW.Disable_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  LKAS_DW.CANPack1.ID = 2U;
  LKAS_DW.CANPack1.Length = 8U;
  LKAS_DW.CANPack1.Extended = 0U;
  LKAS_DW.CANPack1.Remote = 0;
  LKAS_DW.CANPack1.Data[0] = 0;
  LKAS_DW.CANPack1.Data[1] = 0;
  LKAS_DW.CANPack1.Data[2] = 0;
  LKAS_DW.CANPack1.Data[3] = 0;
  LKAS_DW.CANPack1.Data[4] = 0;
  LKAS_DW.CANPack1.Data[5] = 0;
  LKAS_DW.CANPack1.Data[6] = 0;
  LKAS_DW.CANPack1.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle5;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[1] = LKAS_DW.CANPack1.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[0] = LKAS_DW.CANPack1.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle6;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[3] = LKAS_DW.CANPack1.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[2] = LKAS_DW.CANPack1.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle7;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[5] = LKAS_DW.CANPack1.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[4] = LKAS_DW.CANPack1.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle8;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[7] = LKAS_DW.CANPack1.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[6] = LKAS_DW.CANPack1.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack' */
    if ((8 == LKAS_DW.CANPack.Length) && (LKAS_DW.CANPack.ID != INVALID_CAN_ID) )
    {
      if ((1 == LKAS_DW.CANPack.ID) && (0U == LKAS_DW.CANPack.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
    if ((8 == LKAS_DW.CANPack1.Length) && (LKAS_DW.CANPack1.ID != INVALID_CAN_ID)
        ) {
      if ((2 == LKAS_DW.CANPack1.ID) && (0U == LKAS_DW.CANPack1.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
    if ((8 == LKAS_ConstB.CANPack2.Length) && (LKAS_ConstB.CANPack2.ID !=
         INVALID_CAN_ID) ) {
      if ((3 == LKAS_ConstB.CANPack2.ID) && (0U == LKAS_ConstB.CANPack2.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack2.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack2.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07L_100 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
    if ((8 == LKAS_ConstB.CANPack3.Length) && (LKAS_ConstB.CANPack3.ID !=
         INVALID_CAN_ID) ) {
      if ((4 == LKAS_ConstB.CANPack3.ID) && (0U == LKAS_ConstB.CANPack3.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08L_100 = result;
            }
          }
        }
      }
    }
  }

  /* RelationalOperator: '<S16>/Compare' incorporates:
   *  Constant: '<S16>/Constant'
   */
  rtb_Compare_ku = (rtb_IMAPve_d_TCU_Actual_Gear > ((uint8)3U));

  /* RelationalOperator: '<S13>/Compare' incorporates:
   *  Constant: '<S13>/Constant'
   */
  rtb_Compare_p = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S60>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_g = rtb_R0_Type;
  } else {
    rtb_R0_Type_g = rtb_L0_Type;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  Constant: '<S57>/Constant'
   *  DataTypeConversion: '<S58>/Cast To Single5'
   *  Switch: '<S57>/Switch3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_e = rtb_L0_Type;

    /* DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     */
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q();

    /* Switch: '<S53>/Switch1' incorporates:
     *  Constant: '<S53>/Constant1'
     */
    if (rtb_L0_Type >= ((uint8)2U)) {
      rtb_L1_Q = (uint16)((uint8)3U);
    } else {
      rtb_L1_Q = (uint16)rtb_L0_Type;
    }

    /* End of Switch: '<S53>/Switch1' */
  } else {
    rtb_L0_Type_e = rtb_R0_Type;
    rtb_L1_Q = ((uint16)0U);
  }

  /* DataTypeConversion: '<S50>/Cast To Single57' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   */
  rtb_L0_C1_m = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   */
  rtb_L0_C1_i = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR();

  /* Switch: '<S59>/Switch3' incorporates:
   *  Constant: '<S59>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single66'
   *  Switch: '<S51>/Switch'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    /* DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q();

    /* Switch: '<S54>/Switch1' incorporates:
     *  Constant: '<S54>/Constant1'
     */
    if (rtb_L0_Type >= ((uint8)2U)) {
      rtb_R1_Q = (uint16)((uint8)3U);
    } else {
      rtb_R1_Q = (uint16)rtb_L0_Type;
    }

    /* End of Switch: '<S54>/Switch1' */
    rtb_R0_VR_e = rtb_L0_C1_m;
  } else {
    rtb_R1_Q = ((uint16)0U);
    rtb_R0_VR_e = rtb_L0_C1_i;
  }

  /* End of Switch: '<S59>/Switch3' */

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single66'
   *  DataTypeConversion: '<S58>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_e = rtb_L0_C1_i;
  } else {
    rtb_L0_VR_e = rtb_L0_C1_m;
  }

  /* DataTypeConversion: '<S50>/Cast To Single75' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  rtb_L0_C1_m = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_W_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_W'
   */
  rtb_L0_C1_i = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W();

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single71'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_d = rtb_L0_C1_m;
  } else {
    rtb_R0_W_d = rtb_L0_C1_i;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single71'
   *  DataTypeConversion: '<S58>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_f = rtb_L0_C1_i;
  } else {
    rtb_L0_W_f = rtb_L0_C1_m;
  }

  /* Math: '<S44>/Mod1' incorporates:
   *  Constant: '<S44>/Constant7'
   */
  if (((sint32)((uint8)3U)) != 0) {
    rtb_Mod1 %= ((uint8)3U);
  }

  /* End of Math: '<S44>/Mod1' */

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LDW_Warn_Mode'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode();

  /* MinMax: '<S44>/Max1' */
  if (rtb_Mod1 > rtb_L0_Type) {
    rtb_LDW_Warn_Mode = rtb_Mod1;
  } else {
    rtb_LDW_Warn_Mode = rtb_L0_Type;
  }

  /* End of MinMax: '<S44>/Max1' */

  /* Gain: '<S6>/Gain2' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_d_FuncFaultStatus_1'
   *  Inport: '<Root>/ADIAve_d_FuncFaultStatus'
   */
  rtb_Gain2 = ((uint32)((uint16)32768U)) * ((uint32)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_d_FuncFaultStatus_ADIAve_d_FuncFaultStatus
    ());

  /* Gain: '<S6>/Gain' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   *  Inport: '<Root>/ADIAve_g_ASWFaultStatus'
   */
  rtb_Gain = ((uint64)2147483648U) * ((uint64)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_ASWFaultStatus_ADIAve_g_ASWFaultStatus
    ());

  /* Gain: '<S6>/Gain1' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   *  Inport: '<Root>/ADIAve_g_BSWFaultStatus'
   */
  rtb_Gain1 = ((uint64)2147483648U) * ((uint64)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_BSWFaultStatus_ADIAve_g_BSWFaultStatus
    ());

  /* DataTypeConversion: '<S1>/IMAPve_d_APA_AutoPark_WorkSt_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_APA_AutoPark_WorkSt'
   */
  rtb_IMAPve_d_APA_AutoPark_WorkS = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp_Switch'
   */
  rtb_IMAPve_d_BCM_HazardLamp_g = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_Switch_IMAPve_d_BCM_HazardLamp_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Override'
   */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_ESA_State'
   */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State'
   */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag'
   */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    ();

  /* RelationalOperator: '<S17>/Compare' incorporates:
   *  Constant: '<S17>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_TrqLim_State'
   */
  rtb_Compare_pi = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State
                     ()) == ((uint8)0U));

  /* RelationalOperator: '<S18>/Compare' incorporates:
   *  Constant: '<S18>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_Trq_State'
   */
  rtb_Compare_ct = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S19>/Compare' incorporates:
   *  Constant: '<S19>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid'
   */
  rtb_Compare_ic = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S21>/Compare' incorporates:
   *  Constant: '<S21>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid'
   */
  rtb_Compare_nc = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S12>/Compare' incorporates:
   *  Constant: '<S12>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid'
   */
  rtb_Compare_pp = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid
                     ()) != ((uint8)1U));

  /* RelationalOperator: '<S20>/Compare' incorporates:
   *  Constant: '<S20>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid'
   */
  rtb_Compare_a = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid
                    ()) == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Fusion_Status'
   */
  rtb_IMAPve_d_Fusion_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status();

  /* DataTypeConversion: '<S50>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   */
  rtb_L1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_Work_State'
   */
  rtb_IMAPve_d_MP5_Work_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State
    ();

  /* DataTypeConversion: '<S50>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   */
  rtb_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type();

  /* RelationalOperator: '<S14>/Compare' incorporates:
   *  Constant: '<S14>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Clb_State'
   */
  rtb_Compare_d2 = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State
                     ()) == ((uint8)0U));

  /* RelationalOperator: '<S15>/Compare' incorporates:
   *  Constant: '<S15>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Trim_State'
   */
  rtb_Compare_bw = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State
                     ()) == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SWS_Failure_Status'
   */
  rtb_IMAPve_d_SWS_Failure_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Sensor_Status'
   */
  rtb_IMAPve_d_Sensor_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_TCU_Available'
   */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  rtb_IMAPve_g_EMS_RealPedal = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  rtb_IMAPve_g_EPS_LKA_Current = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SteeringAngle'
   */
  rtb_IMAPve_g_EPS_SteeringAngle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  rtb_IMAPve_g_ESC_Brake_Press = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  rtb_IMAPve_g_ESC_UnYawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  rtb_IMAPve_g_ESC_YawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate();

  /* DataTypeConversion: '<S50>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   *  UnaryMinus: '<S50>/Unary Minus8'
   */
  rtb_L1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   *  UnaryMinus: '<S50>/Unary Minus9'
   */
  rtb_L1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   *  UnaryMinus: '<S50>/Unary Minus10'
   */
  rtb_L1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   *  UnaryMinus: '<S50>/Unary Minus11'
   */
  rtb_L1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single78' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  rtb_L1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR();

  /* DataTypeConversion: '<S50>/Cast To Single74' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  rtb_L1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W();

  /* DataTypeConversion: '<S50>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   *  UnaryMinus: '<S50>/Unary Minus14'
   */
  rtb_R1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   *  UnaryMinus: '<S50>/Unary Minus15'
   */
  rtb_R1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   *  UnaryMinus: '<S50>/Unary Minus12'
   */
  rtb_R1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   *  UnaryMinus: '<S50>/Unary Minus13'
   */
  rtb_R1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single50' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  rtb_R1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR();

  /* DataTypeConversion: '<S50>/Cast To Single52' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  rtb_R1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W();

  /* Switch: '<S552>/Switch1' incorporates:
   *  Constant: '<S552>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1_l != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1_l;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S552>/Switch1' */

  /* Switch: '<S552>/Switch12' incorporates:
   *  Constant: '<S552>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S552>/Switch12' */

  /* Switch: '<S553>/Switch56' incorporates:
   *  Constant: '<S553>/LLSMConClb14'
   *
   * Block description for '<S553>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_k != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_k;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S553>/Switch56' */

  /* Switch: '<S553>/Switch51' incorporates:
   *  Constant: '<S553>/LLSMConClb15'
   *
   * Block description for '<S553>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_o != 0.0F) {
    rtb_LL_DvtComp_C_i = LKAS_ConstB.DataTypeConversion25_o;
  } else {
    rtb_LL_DvtComp_C_i = LL_DvtComp_C;
  }

  /* End of Switch: '<S553>/Switch51' */

  /* Switch: '<S553>/Switch52' incorporates:
   *  Constant: '<S553>/LLSMConClb16'
   *
   * Block description for '<S553>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36_b != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36_b;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S553>/Switch52' */

  /* Switch: '<S553>/Switch46' incorporates:
   *  Constant: '<S553>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S553>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_e != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_e;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S553>/Switch46' */

  /* Update for Delay: '<S65>/Delay' */
  LKAS_DW.Delay_DSTATE = rtb_Saturation1_m;

  /* Update for Memory: '<S73>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Add1;

  /* Update for Memory: '<S76>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = rtb_L0_C0;

  /* Update for Memory: '<S76>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = rtb_Saturation;

  /* Update for Memory: '<S68>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_h = rtb_R0_C0;

  /* Update for Memory: '<S68>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = rtb_offset;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S81>/Delay' */
    LKAS_DW.Delay_DSTATE_o = LKAS_DW.LKASM_stLKAActvFlg;

    /* Update for Memory: '<S515>/Memory' */
    LKAS_DW.Memory_PreviousInput_j = rtb_Saturation_c;

    /* Update for Memory: '<S460>/Memory' */
    LKAS_DW.Memory_PreviousInput_c = rtb_Saturation_f;

    /* Update for UnitDelay: '<S392>/Delay Input1'
     *
     * Block description for '<S392>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_iz;

    /* Update for UnitDelay: '<S391>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_i = LKAS_DW.RelationalOperator_a;

    /* Update for UnitDelay: '<S354>/Delay Input1'
     *
     * Block description for '<S354>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_c = rtb_Compare_km;

    /* Update for UnitDelay: '<S352>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_gu = LKAS_DW.RelationalOperator_c;

    /* Update for UnitDelay: '<S353>/Delay Input1'
     *
     * Block description for '<S353>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_p = rtb_Compare_cj;

    /* Update for Memory: '<S319>/Memory' */
    LKAS_DW.Memory_PreviousInput_eq = LKAS_DW.RelationalOperator_c;

    /* Update for Delay: '<S82>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.LKASM_stLKAState;

    /* Update for Delay: '<S82>/Delay' */
    LKAS_DW.Delay_DSTATE_j = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S82>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.LDWSM_stLDWState;

    /* Update for Memory: '<S367>/Memory' */
    LKAS_DW.Memory_PreviousInput_id = rtb_LDW_State;

    /* Update for Memory: '<S293>/Memory' */
    LKAS_DW.Memory_PreviousInput_i = rtb_Merge1_n;

    /* Update for Memory: '<S329>/Memory' */
    LKAS_DW.Memory_PreviousInput_a = rtb_Merge1_j;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S108>/Memory' */
      LKAS_DW.Memory_PreviousInput_ok = rtb_Saturation2;

      /* Update for Memory: '<S145>/Memory' */
      LKAS_DW.Memory_PreviousInput_moq = rtb_Saturation1_f;

      /* Update for Memory: '<S91>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_lx = rtb_Saturation1_cv;

      /* Update for Memory: '<S144>/Memory' */
      LKAS_DW.Memory_PreviousInput_k0 = rtb_Saturation1_d;

      /* Update for Memory: '<S146>/Memory' */
      LKAS_DW.Memory_PreviousInput_n3 = rtb_Saturation1_b;

      /* Update for Memory: '<S140>/Memory' */
      LKAS_DW.Memory_PreviousInput_ix = rtb_Add_pn;

      /* Update for Memory: '<S143>/Memory' */
      LKAS_DW.Memory_PreviousInput_pr = rtb_Saturation1_k;

      /* Update for Memory: '<S142>/Memory' */
      LKAS_DW.Memory_PreviousInput_pj = rtb_Saturation1_en;

      /* Update for Memory: '<S141>/Memory' */
      LKAS_DW.Memory_PreviousInput_e = rtb_Saturation1_b1;

      /* Update for Memory: '<S118>/Memory' */
      LKAS_DW.Memory_PreviousInput_i3d = rtb_Add_lo;

      /* Update for Memory: '<S109>/Memory' */
      LKAS_DW.Memory_PreviousInput_kz = rtb_Saturation2_l;

      /* Update for Memory: '<S110>/Memory' */
      LKAS_DW.Memory_PreviousInput_mo = rtb_Saturation2_n;

      /* Update for Memory: '<S107>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_e = rtb_Saturation_gi;

      /* Update for Memory: '<S201>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_f = rtb_Saturation_mf;

      /* Update for Memory: '<S184>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = rtb_Add1_h;

      /* Update for UnitDelay: '<S182>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_a = rtb_Switch2_at;

      /* Update for Memory: '<S190>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_m = rtb_Saturation_j;

      /* Update for Memory: '<S196>/Memory' */
      LKAS_DW.Memory_PreviousInput_f4 = rtb_Saturation1_mm;

      /* Update for UnitDelay: '<S200>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_g = rtb_Switch_dj;

      /* Update for Memory: '<S200>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_n = rtb_Saturation_nv;

      /* Update for UnitDelay: '<S177>/Delay Input2'
       *
       * Block description for '<S177>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_b = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S177>/Memory' */
      LKAS_DW.Memory_PreviousInput_e1 = rtb_Saturation2_b;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S82>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.LKA_Mode;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S546>/Delay Input2'
   *
   * Block description for '<S546>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_L0_C2;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_L0_Q);

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_TCU_ActualGear);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single2'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)((uint8)rtb_LL_CompHdAg_C));

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single3'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    rtb_CastToSingle3);

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single4'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning
    ((UInt8)rtb_Hands_Off_Warning_c);

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single5'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_LKA_Action_Indication_d);

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single6'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status
    ((UInt8)rtb_IMAPve_d_Camera_Status);

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq
    ((UInt8)rtb_R0_Q);

  /* Switch: '<S547>/Switch2' incorporates:
   *  Constant: '<S541>/Constant3'
   *  Constant: '<S541>/Constant4'
   *  RelationalOperator: '<S547>/LowerRelop1'
   *  RelationalOperator: '<S547>/UpperRelop'
   *  Switch: '<S547>/Switch'
   */
  if (rtb_L0_C2 > 5.0F) {
    rtb_L0_C2 = 5.0F;
  } else {
    if (rtb_L0_C2 < (-5.0F)) {
      /* Switch: '<S547>/Switch' incorporates:
       *  Constant: '<S541>/Constant4'
       */
      rtb_L0_C2 = (-5.0F);
    }
  }

  /* End of Switch: '<S547>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_L0_C2);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single8'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control
    ((UInt8)rtb_IMAPve_d_SAS_Trim_State);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/x1'
   */
  if (rtb_Merge) {
    rtb_L0_C0 = LKAS_DW.OutputM;
  } else {
    rtb_L0_C0 = (float32)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_L0_C0);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S11>/Switch2' incorporates:
   *  Constant: '<S11>/2'
   *  Constant: '<S11>/x2'
   *  Constant: '<S544>/Constant'
   *  Constant: '<S545>/Constant'
   *  Logic: '<S11>/Logical Operator'
   *  RelationalOperator: '<S544>/Compare'
   *  RelationalOperator: '<S545>/Compare'
   */
  if ((rtb_IMAPve_d_SAS_Trim_State == ((uint8)4U)) ||
      (rtb_IMAPve_d_SAS_Trim_State == ((uint8)3U))) {
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)1U);
  } else {
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    ((UInt8)rtb_IMAPve_d_SAS_Trim_State);

  /* Outport: '<Root>/LKASve_g_ob5H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5H_10_LKASve_g_ob5H_10
    (LKAS_DW.LKASve_g_ob5H_10);

  /* Outport: '<Root>/LKASve_g_ob5L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5L_10_LKASve_g_ob5L_10
    (LKAS_DW.LKASve_g_ob5L_10);

  /* Outport: '<Root>/LKASve_g_ob6H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6H_10_LKASve_g_ob6H_10
    (LKAS_DW.LKASve_g_ob6H_10);

  /* Outport: '<Root>/LKASve_g_ob6L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6L_10_LKASve_g_ob6L_10
    (LKAS_DW.LKASve_g_ob6L_10);

  /* Outport: '<Root>/LKASve_g_ob07H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07H_100_LKASve_g_ob07H_100
    (LKAS_DW.LKASve_g_ob07H_100);

  /* Outport: '<Root>/LKASve_g_ob07L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07L_100_LKASve_g_ob07L_100
    (LKAS_DW.LKASve_g_ob07L_100);

  /* Outport: '<Root>/LKASve_g_ob08H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08H_100_LKASve_g_ob08H_100
    (LKAS_DW.LKASve_g_ob08H_100);

  /* Outport: '<Root>/LKASve_g_ob08L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08L_100_LKASve_g_ob08L_100
    (LKAS_DW.LKASve_g_ob08L_100);
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S367>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S91>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S199>/If' */
  LKAS_DW.If_ActiveSubsystem_m = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack' */

  /*-----------S-Function Block: <S4>/CAN Unpack -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack1' */

  /*-----------S-Function Block: <S4>/CAN Unpack1 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack2' */

  /*-----------S-Function Block: <S4>/CAN Unpack2 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack3' */

  /*-----------S-Function Block: <S4>/CAN Unpack3 -----------------*/

  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* ConstCode for Constant: '<S2>/Version' */
  ob_LKA_Version = 220125.0F;

  /* End of ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S73>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* InitializeConditions for Memory: '<S76>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = (-1.75F);

  /* InitializeConditions for Memory: '<S76>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = (-1.75F);

  /* InitializeConditions for Memory: '<S68>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_h = 1.75F;

  /* InitializeConditions for Memory: '<S68>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = 1.75F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S81>/Delay' */
  LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

  /* InitializeConditions for Memory: '<S515>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = 0.0F;

  /* InitializeConditions for Memory: '<S460>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 0.0F;

  /* InitializeConditions for UnitDelay: '<S392>/Delay Input1'
   *
   * Block description for '<S392>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S391>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_i = false;

  /* InitializeConditions for UnitDelay: '<S354>/Delay Input1'
   *
   * Block description for '<S354>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_c = false;

  /* InitializeConditions for UnitDelay: '<S352>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_gu = false;

  /* InitializeConditions for UnitDelay: '<S353>/Delay Input1'
   *
   * Block description for '<S353>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_p = false;

  /* InitializeConditions for Memory: '<S319>/Memory' */
  LKAS_DW.Memory_PreviousInput_eq = false;

  /* InitializeConditions for Delay: '<S82>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for Delay: '<S82>/Delay' */
  LKAS_DW.Delay_DSTATE_j = false;

  /* InitializeConditions for Delay: '<S82>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S367>/Memory' */
  LKAS_DW.Memory_PreviousInput_id = ((uint8)0U);

  /* InitializeConditions for Memory: '<S293>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = 0.0F;

  /* InitializeConditions for Memory: '<S329>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = 0.0F;

  /* InitializeConditions for Delay: '<S82>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S380>/ExitCount' */
  /* InitializeConditions for Memory: '<S388>/Memory' */
  LKAS_DW.Memory_PreviousInput_no = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S380>/ExitCount' */

  /* SystemInitialize for Enabled SubSystem: '<S381>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S390>/Memory' */
  LKAS_DW.Memory_PreviousInput_k = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S381>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S391>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S395>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S391>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S319>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S350>/Memory' */
  LKAS_DW.Memory_PreviousInput_m5 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S319>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S319>/Count' */
  /* InitializeConditions for Memory: '<S349>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S319>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S352>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S358>/Memory' */
  LKAS_DW.Memory_PreviousInput_n2 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S352>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S320>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S364>/Memory' */
  LKAS_DW.Memory_PreviousInput_cp = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S320>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S367>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S397>/Memory' */
  LKAS_DW.Memory_PreviousInput_n = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S367>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S330>/Sum Condition' */
  /* InitializeConditions for Memory: '<S336>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S330>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S278>/Count_5s3' */
  /* InitializeConditions for Memory: '<S540>/Memory' */
  LKAS_DW.Memory_PreviousInput_i3 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S278>/Count_5s3' */

  /* SystemInitialize for Enabled SubSystem: '<S278>/Count_5s2' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s2);

  /* End of SystemInitialize for SubSystem: '<S278>/Count_5s2' */

  /* SystemInitialize for Enabled SubSystem: '<S278>/Count_5s1' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s1);

  /* End of SystemInitialize for SubSystem: '<S278>/Count_5s1' */

  /* SystemInitialize for Enabled SubSystem: '<S255>/Subsystem' */
  /* InitializeConditions for Memory: '<S259>/Memory' */
  LKAS_DW.Memory_PreviousInput_hb = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S255>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S108>/Memory' */
  LKAS_DW.Memory_PreviousInput_ok = 0.0F;

  /* InitializeConditions for Memory: '<S145>/Memory' */
  LKAS_DW.Memory_PreviousInput_moq = ((uint16)0U);

  /* InitializeConditions for Memory: '<S91>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_lx = ((uint8)0U);

  /* InitializeConditions for Memory: '<S144>/Memory' */
  LKAS_DW.Memory_PreviousInput_k0 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S146>/Memory' */
  LKAS_DW.Memory_PreviousInput_n3 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S140>/Memory' */
  LKAS_DW.Memory_PreviousInput_ix = ((uint16)0U);

  /* InitializeConditions for Memory: '<S143>/Memory' */
  LKAS_DW.Memory_PreviousInput_pr = ((uint16)0U);

  /* InitializeConditions for Memory: '<S142>/Memory' */
  LKAS_DW.Memory_PreviousInput_pj = ((uint16)0U);

  /* InitializeConditions for Memory: '<S141>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = ((uint16)0U);

  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_i3d = 0.0F;

  /* InitializeConditions for Memory: '<S109>/Memory' */
  LKAS_DW.Memory_PreviousInput_kz = 0.0F;

  /* InitializeConditions for Memory: '<S110>/Memory' */
  LKAS_DW.Memory_PreviousInput_mo = 0.0F;

  /* InitializeConditions for Memory: '<S107>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_e = 0.0F;

  /* InitializeConditions for Memory: '<S201>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_f = 0.0F;

  /* InitializeConditions for Memory: '<S184>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 0.0F;

  /* InitializeConditions for UnitDelay: '<S182>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_a = 0.0F;

  /* InitializeConditions for Memory: '<S190>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_m = 0.0F;

  /* InitializeConditions for Memory: '<S196>/Memory' */
  LKAS_DW.Memory_PreviousInput_f4 = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S200>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

  /* InitializeConditions for Memory: '<S200>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_n = 0.0F;

  /* InitializeConditions for UnitDelay: '<S177>/Delay Input2'
   *
   * Block description for '<S177>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_b = 0.0F;

  /* InitializeConditions for Memory: '<S177>/Memory' */
  LKAS_DW.Memory_PreviousInput_e1 = ((uint16)0U);

  /* SystemInitialize for IfAction SubSystem: '<S91>/LKA Motion Planning Calculation (LKAMPCal)'
   *
   * Block description for '<S91>/LKA Motion Planning Calculation (LKAMPCal)':
   *  Block Name: LKA Motion Planning Calculation
   *  Ab.: LKAMPCal
   *  No.: 1.2.3.2
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  LKAMotionPlanningCalculati_Init();

  /* End of SystemInitialize for SubSystem: '<S91>/LKA Motion Planning Calculation (LKAMPCal)' */

  /* SystemInitialize for Enabled SubSystem: '<S109>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S111>/Memory' */
  LKAS_DW.Memory_PreviousInput_n0 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S109>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S98>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S98>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S110>/Moving Standard Deviation1' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S110>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S110>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_j);

  /* End of SystemInitialize for SubSystem: '<S110>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S110>/Moving Standard Deviation2' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation2_d);

  /* End of SystemInitialize for SubSystem: '<S110>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S110>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_c);

  /* End of SystemInitialize for SubSystem: '<S110>/Sum Condition' */

  /* SystemInitialize for IfAction SubSystem: '<S199>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S209>/Delay Input1'
   *
   * Block description for '<S209>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_pv = false;

  /* InitializeConditions for Memory: '<S205>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S199>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S199>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S217>/Delay Input1'
   *
   * Block description for '<S217>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_pp = false;

  /* InitializeConditions for Memory: '<S206>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S199>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S199>/Merge' */
  LKAS_DW.Merge_j = 1.0F;

  /* SystemInitialize for Merge: '<S199>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S84>/Merge' */
  LKAS_DW.Merge_l = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S84>/Sum Condition' */
  /* InitializeConditions for Memory: '<S88>/Memory' */
  LKAS_DW.Memory_PreviousInput_o2 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S84>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */

  /* SystemInitialize for Enabled SubSystem: '<S400>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1_l);

  /* End of SystemInitialize for SubSystem: '<S400>/Sum Condition1' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S541>/Subsystem' */
  /* InitializeConditions for Delay: '<S548>/Delay1' */
  LKAS_DW.Delay1_DSTATE = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S541>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S28>/Sum Condition2' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition2);

  /* End of SystemInitialize for SubSystem: '<S28>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S28>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1);

  /* End of SystemInitialize for SubSystem: '<S28>/Sum Condition1' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
