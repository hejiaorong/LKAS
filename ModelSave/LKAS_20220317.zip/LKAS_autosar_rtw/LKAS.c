/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.84
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Mar 17 13:32:03 2022
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S142>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S142>/LKA_State_Machine' */
#define LKAS_IN_Fault_i                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_j      ((uint8)0U)
#define LKAS_IN_Normal_p               ((uint8)2U)
#define LKAS_IN_SysOff_i               ((uint8)2U)
#define LKAS_IN_SysOn_h                ((uint8)3U)
#define LKAS_IN_Unavailable_h          ((uint8)1U)
#define LKAS_IN_Unselected_l           ((uint8)2U)

/* Named constants for Chart: '<S111>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Exported data definition */

/* Definition for custom storage class: Default */
float32 ob_LKA_Disable_Reason;
uint32 ob_LKA_Fault_Reason;
float32 ob_LKA_LKADeactvCSyn;
float32 ob_LKA_Version;

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * System initialize for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S464>/Sum Condition1'
 */
void LKAS_SumCondition1_Init(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S99>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S464>/Sum Condition1'
 */
void LKAS_SumCondition1_Reset(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S99>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S464>/Sum Condition1'
 */
void LKAS_SumCondition1_Disable(boolean *rty_Out, DW_SumCondition1_LKAS_T
  *localDW)
{
  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' incorporates:
   *  EnablePort: '<S99>/state = reset'
   */
  /* Disable for Outport: '<S99>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */
  localDW->SumCondition1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S88>/Sum Condition1'
 *    '<S88>/Sum Condition2'
 *    '<S464>/Sum Condition1'
 */
void LKAS_SumCondition1(boolean rtu_statereset, float32 rtu_SampleTime, float32
  rtu_Sum, boolean *rty_Out, DW_SumCondition1_LKAS_T *localDW)
{
  float32 rtb_Saturation_ao;

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' incorporates:
   *  EnablePort: '<S99>/state = reset'
   */
  if (rtu_statereset) {
    if (!localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Reset(localDW);
      localDW->SumCondition1_MODE = true;
    }

    /* Sum: '<S99>/Add1' incorporates:
     *  Memory: '<S99>/Memory'
     */
    rtb_Saturation_ao = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S99>/Saturation' */
    if (rtb_Saturation_ao > 60.0F) {
      rtb_Saturation_ao = 60.0F;
    } else {
      if (rtb_Saturation_ao < 0.0F) {
        rtb_Saturation_ao = 0.0F;
      }
    }

    /* End of Saturate: '<S99>/Saturation' */

    /* RelationalOperator: '<S99>/Relational Operator' */
    *rty_Out = (rtb_Saturation_ao >= rtu_Sum);

    /* Update for Memory: '<S99>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_ao;
  } else {
    if (localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */
}

/*
 * Output and update for action system:
 *    '<S144>/If Action Subsystem2'
 *    '<S190>/If Action Subsystem3'
 *    '<S191>/If Action Subsystem3'
 *    '<S192>/If Action Subsystem3'
 *    '<S193>/If Action Subsystem3'
 *    '<S194>/If Action Subsystem3'
 *    '<S202>/If Action Subsystem3'
 *    '<S234>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S147>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S147>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/* System initialize for atomic system: '<S157>/Moving Standard Deviation2' */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S160>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S160>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* System reset for atomic system: '<S157>/Moving Standard Deviation2' */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S160>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S160>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S160>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* Output and update for atomic system: '<S157>/Moving Standard Deviation2' */
void LKAS_MovingStandardDeviation2(float32 rtu_In1, float32 *rty_Out2, float32
  *rty_Out1, DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_ka;
  float32 rtb_Delay1_n;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_SumofElements;
  float32 rtb_TmpSignalConversionAtStanda[50];
  sint32 tmp;
  sint32 i;
  float32 rtb_Saturation_ek;

  /* Delay: '<S160>/Delay' */
  rtb_Delay_ka = localDW->Delay_DSTATE;

  /* Delay: '<S160>/Delay1' */
  rtb_Delay1_n = localDW->Delay1_DSTATE;

  /* Delay: '<S160>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S160>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S160>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S160>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S160>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S160>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S160>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S160>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S160>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S160>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S160>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S160>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S160>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S160>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S160>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S160>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S160>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S160>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S160>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S160>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S160>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S160>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S160>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S160>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S160>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S160>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S160>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S160>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S160>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S160>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S160>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S160>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S160>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S160>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S160>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S160>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S160>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S160>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S160>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S160>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S160>/Delay47' */
  rtb_SumofElements = localDW->Delay47_DSTATE;

  /* Delay: '<S160>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S160>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S160>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S160>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S160>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S160>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S160>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_ka;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_n;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_SumofElements;

  /* Sum: '<S160>/Sum of Elements' */
  tmp = 0;
  rtb_Saturation_ek = -0.0F;
  for (i = 0; i < 50; i++) {
    rtb_Saturation_ek += rtb_TmpSignalConversionAtStanda[i];
  }

  rtb_SumofElements = rtb_Saturation_ek;

  /* End of Sum: '<S160>/Sum of Elements' */

  /* Sum: '<S160>/Add2' incorporates:
   *  Constant: '<S160>/Constant'
   *  Memory: '<S160>/Memory3'
   */
  rtb_Saturation_ek = (float32)((uint8)(((uint32)((uint8)1U)) + ((uint32)((uint8)
    localDW->Memory3_PreviousInput))));

  /* Saturate: '<S160>/Saturation' */
  if (rtb_Saturation_ek > 50.0F) {
    rtb_Saturation_ek = 50.0F;
  } else {
    if (rtb_Saturation_ek < 1.0F) {
      rtb_Saturation_ek = 1.0F;
    }
  }

  /* End of Saturate: '<S160>/Saturation' */

  /* Product: '<S160>/Divide' */
  *rty_Out2 = rtb_SumofElements / rtb_Saturation_ek;

  /* S-Function (sdspstatfcns): '<S160>/Standard Deviation' incorporates:
   *  SignalConversion: '<S160>/TmpSignal ConversionAtStandard DeviationInport1'
   */
  while (tmp < 1) {
    localDW->StandardDeviation_AccVal = rtu_In1;
    localDW->StandardDeviation_SqData = rtu_In1 * rtu_In1;
    tmp = 1;
    for (i = 48; i >= 0; i--) {
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[tmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[tmp] *
        rtb_TmpSignalConversionAtStanda[tmp];
      tmp++;
    }

    *rty_Out1 = (localDW->StandardDeviation_SqData -
                 ((localDW->StandardDeviation_AccVal *
                   localDW->StandardDeviation_AccVal) / 50.0F)) / 49.0F;
    *rty_Out1 = sqrtf(fabsf(*rty_Out1));
    tmp = 1;
  }

  /* End of S-Function (sdspstatfcns): '<S160>/Standard Deviation' */

  /* Update for Delay: '<S160>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S160>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_ka;

  /* Update for Delay: '<S160>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S160>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S160>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S160>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S160>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S160>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S160>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S160>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S160>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S160>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S160>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_n;

  /* Update for Delay: '<S160>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S160>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S160>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S160>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S160>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S160>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S160>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S160>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S160>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S160>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S160>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S160>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S160>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S160>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S160>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S160>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S160>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S160>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S160>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S160>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S160>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S160>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S160>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S160>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S160>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S160>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S160>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S160>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S160>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S160>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S160>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S160>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S160>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S160>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S160>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S160>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;

  /* Update for Memory: '<S160>/Memory3' */
  localDW->Memory3_PreviousInput = rtb_Saturation_ek;
}

/*
 * Output and update for action system:
 *    '<S171>/If Action Subsystem3'
 *    '<S416>/If Action Subsystem3'
 *    '<S455>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S175>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * System initialize for atomic system:
 *    '<S171>/Moving Standard Deviation1'
 *    '<S171>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation1_Init(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S176>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S171>/Moving Standard Deviation1'
 *    '<S171>/Moving Standard Deviation2'
 */
void MovingStandardDeviation1_Reset(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S176>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S176>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S171>/Moving Standard Deviation1'
 *    '<S171>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation1(float32 rtu_In1,
  DW_MovingStandardDeviation1_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_a;
  float32 rtb_Delay1_b;
  float32 rtb_Delay10_p;
  float32 rtb_Delay11_k;
  float32 rtb_Delay12_m;
  float32 rtb_Delay13_m;
  float32 rtb_Delay14_n;
  float32 rtb_Delay15_f;
  float32 rtb_Delay16_g;
  float32 rtb_Delay17_b;
  float32 rtb_Delay18_p;
  float32 rtb_Delay19_e;
  float32 rtb_Delay2_e;
  float32 rtb_Delay20_h;
  float32 rtb_Delay21_b;
  float32 rtb_Delay22_g;
  float32 rtb_Delay23_a;
  float32 rtb_Delay24_n;
  float32 rtb_Delay25_k;
  float32 rtb_Delay26_n;
  float32 rtb_Delay27_d;
  float32 rtb_Delay28_m;
  float32 rtb_Delay29_g;
  float32 rtb_Delay3_o;
  float32 rtb_Delay30_g;
  float32 rtb_Delay31_i;
  float32 rtb_Delay32_k;
  float32 rtb_Delay33_c;
  float32 rtb_Delay34_n;
  float32 rtb_Delay35_f;
  float32 rtb_Delay36_m;
  float32 rtb_Delay37_i;
  float32 rtb_Delay38_k;
  float32 rtb_Delay39_g;
  float32 rtb_Delay4_c;
  float32 rtb_Delay40_e;
  float32 rtb_Delay41_h;
  float32 rtb_Delay42_m;
  float32 rtb_Delay43_c;
  float32 rtb_Delay44_k;
  float32 rtb_Delay45_i;
  float32 rtb_Delay46_l;
  float32 rtb_Delay48_p;
  float32 rtb_Delay5_h;
  float32 rtb_Delay6_l;
  float32 rtb_Delay7_e;
  float32 rtb_Delay8_e;
  float32 rtb_Delay9_e;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S176>/Delay' */
  rtb_Delay_a = localDW->Delay_DSTATE;

  /* Delay: '<S176>/Delay1' */
  rtb_Delay1_b = localDW->Delay1_DSTATE;

  /* Delay: '<S176>/Delay10' */
  rtb_Delay10_p = localDW->Delay10_DSTATE;

  /* Delay: '<S176>/Delay11' */
  rtb_Delay11_k = localDW->Delay11_DSTATE;

  /* Delay: '<S176>/Delay12' */
  rtb_Delay12_m = localDW->Delay12_DSTATE;

  /* Delay: '<S176>/Delay13' */
  rtb_Delay13_m = localDW->Delay13_DSTATE;

  /* Delay: '<S176>/Delay14' */
  rtb_Delay14_n = localDW->Delay14_DSTATE;

  /* Delay: '<S176>/Delay15' */
  rtb_Delay15_f = localDW->Delay15_DSTATE;

  /* Delay: '<S176>/Delay16' */
  rtb_Delay16_g = localDW->Delay16_DSTATE;

  /* Delay: '<S176>/Delay17' */
  rtb_Delay17_b = localDW->Delay17_DSTATE;

  /* Delay: '<S176>/Delay18' */
  rtb_Delay18_p = localDW->Delay18_DSTATE;

  /* Delay: '<S176>/Delay19' */
  rtb_Delay19_e = localDW->Delay19_DSTATE;

  /* Delay: '<S176>/Delay2' */
  rtb_Delay2_e = localDW->Delay2_DSTATE;

  /* Delay: '<S176>/Delay20' */
  rtb_Delay20_h = localDW->Delay20_DSTATE;

  /* Delay: '<S176>/Delay21' */
  rtb_Delay21_b = localDW->Delay21_DSTATE;

  /* Delay: '<S176>/Delay22' */
  rtb_Delay22_g = localDW->Delay22_DSTATE;

  /* Delay: '<S176>/Delay23' */
  rtb_Delay23_a = localDW->Delay23_DSTATE;

  /* Delay: '<S176>/Delay24' */
  rtb_Delay24_n = localDW->Delay24_DSTATE;

  /* Delay: '<S176>/Delay25' */
  rtb_Delay25_k = localDW->Delay25_DSTATE;

  /* Delay: '<S176>/Delay26' */
  rtb_Delay26_n = localDW->Delay26_DSTATE;

  /* Delay: '<S176>/Delay27' */
  rtb_Delay27_d = localDW->Delay27_DSTATE;

  /* Delay: '<S176>/Delay28' */
  rtb_Delay28_m = localDW->Delay28_DSTATE;

  /* Delay: '<S176>/Delay29' */
  rtb_Delay29_g = localDW->Delay29_DSTATE;

  /* Delay: '<S176>/Delay3' */
  rtb_Delay3_o = localDW->Delay3_DSTATE;

  /* Delay: '<S176>/Delay30' */
  rtb_Delay30_g = localDW->Delay30_DSTATE;

  /* Delay: '<S176>/Delay31' */
  rtb_Delay31_i = localDW->Delay31_DSTATE;

  /* Delay: '<S176>/Delay32' */
  rtb_Delay32_k = localDW->Delay32_DSTATE;

  /* Delay: '<S176>/Delay33' */
  rtb_Delay33_c = localDW->Delay33_DSTATE;

  /* Delay: '<S176>/Delay34' */
  rtb_Delay34_n = localDW->Delay34_DSTATE;

  /* Delay: '<S176>/Delay35' */
  rtb_Delay35_f = localDW->Delay35_DSTATE;

  /* Delay: '<S176>/Delay36' */
  rtb_Delay36_m = localDW->Delay36_DSTATE;

  /* Delay: '<S176>/Delay37' */
  rtb_Delay37_i = localDW->Delay37_DSTATE;

  /* Delay: '<S176>/Delay38' */
  rtb_Delay38_k = localDW->Delay38_DSTATE;

  /* Delay: '<S176>/Delay39' */
  rtb_Delay39_g = localDW->Delay39_DSTATE;

  /* Delay: '<S176>/Delay4' */
  rtb_Delay4_c = localDW->Delay4_DSTATE;

  /* Delay: '<S176>/Delay40' */
  rtb_Delay40_e = localDW->Delay40_DSTATE;

  /* Delay: '<S176>/Delay41' */
  rtb_Delay41_h = localDW->Delay41_DSTATE;

  /* Delay: '<S176>/Delay42' */
  rtb_Delay42_m = localDW->Delay42_DSTATE;

  /* Delay: '<S176>/Delay43' */
  rtb_Delay43_c = localDW->Delay43_DSTATE;

  /* Delay: '<S176>/Delay44' */
  rtb_Delay44_k = localDW->Delay44_DSTATE;

  /* Delay: '<S176>/Delay45' */
  rtb_Delay45_i = localDW->Delay45_DSTATE;

  /* Delay: '<S176>/Delay46' */
  rtb_Delay46_l = localDW->Delay46_DSTATE;

  /* Delay: '<S176>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S176>/Delay48' */
  rtb_Delay48_p = localDW->Delay48_DSTATE;

  /* Delay: '<S176>/Delay5' */
  rtb_Delay5_h = localDW->Delay5_DSTATE;

  /* Delay: '<S176>/Delay6' */
  rtb_Delay6_l = localDW->Delay6_DSTATE;

  /* Delay: '<S176>/Delay7' */
  rtb_Delay7_e = localDW->Delay7_DSTATE;

  /* Delay: '<S176>/Delay8' */
  rtb_Delay8_e = localDW->Delay8_DSTATE;

  /* Delay: '<S176>/Delay9' */
  rtb_Delay9_e = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S176>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_a;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_b;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2_e;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3_o;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4_c;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5_h;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6_l;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7_e;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8_e;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9_e;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10_p;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11_k;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12_m;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13_m;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14_n;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15_f;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16_g;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17_b;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18_p;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28_m;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19_e;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20_h;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21_b;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22_g;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23_a;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24_n;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25_k;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26_n;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27_d;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38_k;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29_g;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30_g;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31_i;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32_k;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33_c;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34_n;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35_f;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36_m;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37_i;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48_p;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39_g;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40_e;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41_h;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42_m;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43_c;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44_k;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45_i;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46_l;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S176>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S176>/Standard Deviation' */

  /* Update for Delay: '<S176>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S176>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_a;

  /* Update for Delay: '<S176>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9_e;

  /* Update for Delay: '<S176>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10_p;

  /* Update for Delay: '<S176>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11_k;

  /* Update for Delay: '<S176>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12_m;

  /* Update for Delay: '<S176>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13_m;

  /* Update for Delay: '<S176>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14_n;

  /* Update for Delay: '<S176>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15_f;

  /* Update for Delay: '<S176>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16_g;

  /* Update for Delay: '<S176>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17_b;

  /* Update for Delay: '<S176>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28_m;

  /* Update for Delay: '<S176>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_b;

  /* Update for Delay: '<S176>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19_e;

  /* Update for Delay: '<S176>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20_h;

  /* Update for Delay: '<S176>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21_b;

  /* Update for Delay: '<S176>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22_g;

  /* Update for Delay: '<S176>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23_a;

  /* Update for Delay: '<S176>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24_n;

  /* Update for Delay: '<S176>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25_k;

  /* Update for Delay: '<S176>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26_n;

  /* Update for Delay: '<S176>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18_p;

  /* Update for Delay: '<S176>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38_k;

  /* Update for Delay: '<S176>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2_e;

  /* Update for Delay: '<S176>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29_g;

  /* Update for Delay: '<S176>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30_g;

  /* Update for Delay: '<S176>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31_i;

  /* Update for Delay: '<S176>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32_k;

  /* Update for Delay: '<S176>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33_c;

  /* Update for Delay: '<S176>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34_n;

  /* Update for Delay: '<S176>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35_f;

  /* Update for Delay: '<S176>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36_m;

  /* Update for Delay: '<S176>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27_d;

  /* Update for Delay: '<S176>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48_p;

  /* Update for Delay: '<S176>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3_o;

  /* Update for Delay: '<S176>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39_g;

  /* Update for Delay: '<S176>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40_e;

  /* Update for Delay: '<S176>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41_h;

  /* Update for Delay: '<S176>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42_m;

  /* Update for Delay: '<S176>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43_c;

  /* Update for Delay: '<S176>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44_k;

  /* Update for Delay: '<S176>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45_i;

  /* Update for Delay: '<S176>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46_l;

  /* Update for Delay: '<S176>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37_i;

  /* Update for Delay: '<S176>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4_c;

  /* Update for Delay: '<S176>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5_h;

  /* Update for Delay: '<S176>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6_l;

  /* Update for Delay: '<S176>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7_e;

  /* Update for Delay: '<S176>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8_e;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S171>/Sum Condition'
 *    '<S171>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S178>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S171>/Sum Condition'
 *    '<S171>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S178>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S171>/Sum Condition'
 *    '<S171>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S171>/Sum Condition' incorporates:
   *  EnablePort: '<S178>/Enable'
   */
  /* Disable for Outport: '<S178>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S171>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S171>/Sum Condition'
 *    '<S171>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_ee;

  /* Outputs for Enabled SubSystem: '<S171>/Sum Condition' incorporates:
   *  EnablePort: '<S178>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S178>/Add1' incorporates:
     *  Memory: '<S178>/Memory'
     */
    rtb_Saturation_ee = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S178>/Saturation' */
    if (rtb_Saturation_ee > 100.0F) {
      rtb_Saturation_ee = 100.0F;
    } else {
      if (rtb_Saturation_ee < 0.0F) {
        rtb_Saturation_ee = 0.0F;
      }
    }

    /* End of Saturate: '<S178>/Saturation' */

    /* RelationalOperator: '<S178>/Relational Operator' */
    *rty_Out = (rtb_Saturation_ee >= rtu_In1);

    /* Update for Memory: '<S178>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_ee;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S171>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S190>/If Action Subsystem2'
 *    '<S190>/If Action Subsystem1'
 *    '<S191>/If Action Subsystem2'
 *    '<S191>/If Action Subsystem1'
 *    '<S192>/If Action Subsystem2'
 *    '<S192>/If Action Subsystem1'
 *    '<S193>/If Action Subsystem2'
 *    '<S193>/If Action Subsystem1'
 *    '<S194>/If Action Subsystem2'
 *    '<S194>/If Action Subsystem1'
 *    ...
 */
void LKAS_IfActionSubsystem2_k(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S204>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S195>/if action '
 *    '<S196>/if action '
 *    '<S197>/if action '
 *    '<S198>/if action '
 *    '<S199>/if action '
 *    '<S200>/if action '
 *    '<S201>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S218>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S234>/If Action Subsystem'
 *    '<S234>/If Action Subsystem4'
 *    '<S186>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S236>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system: '<S151>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S151>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  float32 K1K2Det_T1;
  float32 DelteSW0;
  float32 u;
  float32 KMax;
  float32 DelteSW1;
  float32 tmp;

  /* MATLAB Function: '<S182>/MATLABFunction1' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLABFunction1': '<S189>:1' */
  /* '<S189>:1:34' LDDir = K1K2Det_stLDDir; */
  /*     D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S189>:1:36' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_n * 0.0174532924F;

  /* '<S189>:1:37' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S189>:1:38' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S189>:1:39' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S189>:1:40' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S189>:1:41' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S189>:1:42' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_c / 3.6F;

  /* '<S189>:1:43' Kw= u/(L*(1+K*u*u)*i); */
  /* '<S189>:1:44' KMax = K1K2Det_dphiSWARMax/180*pi; */
  KMax = (LKAS_DW.MPInP_dphiSWARMax / 180.0F) * 3.14159274F;

  /* '<S189>:1:45' Delte_Psi1 = PrvwHdAg; */
  /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
  /* '<S189>:1:47' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
  u = ((-2.0F * LKAS_DW.In_ir) / (((u / (((((LKAS_DW.MPInP_StbFacm_SY * u) * u)
             + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_m) * LKAS_DW.LKA_StrRatio_C_d)) *
         LKAS_DW.MPInP_tiTTLCIni) * LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F *
    DelteSW0) / LKAS_DW.MPInP_tiTTLCIni);

  /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
  /* '<S189>:1:49' DelteSW1 = DelteSW0+K1*TTLC; */
  DelteSW1 = (u * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

  /* '<S189>:1:50' K1K2Det_T1 = TTLC; */
  K1K2Det_T1 = LKAS_DW.MPInP_tiTTLCIni;

  /* '<S189>:1:51' if ~(K1<abs(KMax) && K1>-abs(KMax)) */
  tmp = fabsf(KMax);
  if ((u >= tmp) || (u <= (-tmp))) {
    /*  ������ת������ */
    /* '<S189>:1:52' K1 = LDDir*KMax; */
    u = LKAS_DW.Merge * KMax;

    /* '<S189>:1:53' K1K2Det_T1 = max((-DelteSW0+sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1,(-DelteSW0-sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1); */
    KMax = sqrtf((DelteSW0 * DelteSW0) - ((2.0F * u) * LKAS_DW.In_ir));
    K1K2Det_T1 = fmaxf((KMax + (-DelteSW0)) / u, ((-DelteSW0) - KMax) / u);

    /* '<S189>:1:54' DelteSW1 = (K1*K1K2Det_T1+DelteSW0); */
    DelteSW1 = (u * K1K2Det_T1) + DelteSW0;
  }

  /* '<S189>:1:56' if LDDir>0 && K1<0 && DelteSW0>0 && Delte_Psi1<0 */
  if ((((LKAS_DW.Merge > 0.0F) && (u < 0.0F)) && (DelteSW0 > 0.0F)) &&
      (LKAS_DW.In_ir < 0.0F)) {
    /* '<S189>:1:57' K1 = single(0); */
    u = 0.0F;

    /* '<S189>:1:58' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S189>:1:59' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_ir) / DelteSW0;
  }

  /* '<S189>:1:61' if LDDir<0 && K1>0 && DelteSW0<0 && Delte_Psi1>0 */
  if ((((LKAS_DW.Merge < 0.0F) && (u > 0.0F)) && (DelteSW0 < 0.0F)) &&
      (LKAS_DW.In_ir > 0.0F)) {
    /* '<S189>:1:62' K1 = single(0); */
    u = 0.0F;

    /* '<S189>:1:63' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S189>:1:64' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_ir) / DelteSW0;
  }

  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S189>:1:67' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S189>:1:69' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = u * 57.2957802F;
  LKAS_DW.K1K2Det_T1 = K1K2Det_T1;

  /* End of MATLAB Function: '<S182>/MATLABFunction1' */
}

/*
 * Output and update for atomic system:
 *    '<S244>/Saturable Gain Lut (SatGainLut)'
 *    '<S244>/Saturable Gain Lut (SatGainLut)1'
 */
void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32 rtu_InputLimLwr,
  float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32 rtu_GainLimUpr,
  float32 *rty_Gain)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S247>:1' */
  /*  Function Name: Saturable Gain Lut */
  /*  */
  /*  Description:  */
  /*    Saturable Gain Lookup Table. */
  /*  */
  /*  Assumptions and Limitation: */
  /*    The data type of all inputs and output is single. */
  /*  */
  /*  Inputs: */
  /*    Input: */
  /*    InputLimLwr: */
  /*    InputLimUpr: */
  /*    GainLimLwr: */
  /*    GainLimUpr: */
  /*  */
  /*  Outputs: */
  /*    Gain: The result of Looking up table. */
  /*  $Revision: 1.0$ */
  /*  $Author: Zhang Jianwei$ */
  /*  $Date: January 27, 2019$ */
  /*  ________________________________________ */
  /* '<S247>:1:25' if Input <= InputLimLwr */
  if (rtu_Input <= rtu_InputLimLwr) {
    /* '<S247>:1:26' Gain = GainLimLwr; */
    *rty_Gain = rtu_GainLimLwr;
  } else if (rtu_Input >= rtu_InputLimUpr) {
    /* '<S247>:1:27' elseif Input >= InputLimUpr */
    /* '<S247>:1:28' Gain = GainLimUpr; */
    *rty_Gain = rtu_GainLimUpr;
  } else {
    /* '<S247>:1:29' else */
    /* '<S247>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
    /* '<S247>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
    *rty_Gain = (((rtu_Input - rtu_InputLimLwr) / (rtu_InputLimUpr -
      rtu_InputLimLwr)) * (rtu_GainLimUpr - rtu_GainLimLwr)) + rtu_GainLimLwr;
  }
}

/*
 * Output and update for action system:
 *    '<S251>/If Action Subsystem'
 *    '<S251>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_a(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S253>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S274>/if action '
 *    '<S275>/if action '
 *    '<S282>/if action '
 *    '<S283>/if action '
 */
void LKAS_ifaction_f(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S276>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S267>/If Action Subsystem'
 *    '<S268>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_n(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_h_T *localDW)
{
  uint16 rtb_Saturation1_mx;
  uint16 rtb_Saturation1_lo;

  /* Outputs for Enabled SubSystem: '<S267>/If Action Subsystem' incorporates:
   *  EnablePort: '<S272>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S274>/Add' incorporates:
     *  Constant: '<S274>/Constant'
     *  Memory: '<S274>/Memory'
     */
    rtb_Saturation1_mx = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S274>/Saturation1' */
    if (rtb_Saturation1_mx >= ((uint16)10000U)) {
      rtb_Saturation1_mx = ((uint16)10000U);
    }

    /* End of Saturate: '<S274>/Saturation1' */

    /* If: '<S274>/If' incorporates:
     *  Constant: '<S274>/Constant2'
     */
    if (rtb_Saturation1_mx <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S274>/if action ' incorporates:
       *  ActionPort: '<S276>/Action Port'
       */
      LKAS_ifaction_f(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S274>/if action ' */
    }

    /* End of If: '<S274>/If' */

    /* Sum: '<S275>/Add' incorporates:
     *  Constant: '<S275>/Constant'
     *  Memory: '<S275>/Memory'
     */
    rtb_Saturation1_lo = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_e));

    /* Saturate: '<S275>/Saturation1' */
    if (rtb_Saturation1_lo >= ((uint16)10000U)) {
      rtb_Saturation1_lo = ((uint16)10000U);
    }

    /* End of Saturate: '<S275>/Saturation1' */

    /* If: '<S275>/If' incorporates:
     *  Constant: '<S275>/Constant2'
     */
    if (rtb_Saturation1_lo == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S275>/if action ' incorporates:
       *  ActionPort: '<S277>/Action Port'
       */
      LKAS_ifaction_f(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S275>/if action ' */
    }

    /* End of If: '<S275>/If' */

    /* Update for Memory: '<S274>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_mx;

    /* Update for Memory: '<S275>/Memory' */
    localDW->Memory_PreviousInput_e = rtb_Saturation1_lo;
  }

  /* End of Outputs for SubSystem: '<S267>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S267>/If Action Subsystem2'
 *    '<S268>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_a(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S273>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S273>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S142>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_c = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c69_LKAS = 0U;
  LKAS_DW.is_c69_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.LDWSM_stLDWActvFlg = 0U;
  LKAS_DW.LDWSM_stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S142>/LDW_State_Machine'
 * Block description for: '<S142>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S142>/LDW_State_Machine'
   *
   * Block description for '<S142>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c69_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c69_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S335>:2' */
    LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S335>:1' */
    /* Transition: '<S335>:31' */
    LKAS_DW.is_SysOff_c = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S335>:30' */
    LKAS_DW.LDWSM_stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c69_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S335>:36' */
      tmp = !LKAS_DW.LDW_Fault;
      if (tmp && ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)
             LKAS_DW.LKA_Mode) == 2))) {
        /* Transition: '<S335>:38' */
        /* Exit Internal 'Fault': '<S335>:36' */
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S335>:3' */
        /* Transition: '<S335>:77' */
        LKAS_DW.is_SysOn_a = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S335>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 0) && tmp) {
        /* Transition: '<S335>:40' */
        /* Exit Internal 'Fault': '<S335>:36' */
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_c = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S335>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else {
        LKAS_DW.LDWSM_stLDWState = 6U;

        /* During 'LDWFault': '<S335>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S335>:1' */
      if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
          && (LKAS_DW.LDW_Fault)) {
        /* Transition: '<S335>:39' */
        /* Exit Internal 'SysOff': '<S335>:1' */
        LKAS_DW.is_SysOff_c = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S335>:36' */
        /* Transition: '<S335>:75' */
        /* Entry 'LDWFault': '<S335>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
                  == 2)) {
        /* Transition: '<S335>:41' */
        /* Exit Internal 'SysOff': '<S335>:1' */
        LKAS_DW.is_SysOff_c = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S335>:3' */
        /* Transition: '<S335>:77' */
        LKAS_DW.is_SysOn_a = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S335>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_c) == LKAS_IN_Unavailable) {
        LKAS_DW.LDWSM_stLDWState = 0U;

        /* During 'Unavailable': '<S335>:30' */
        if (((sint32)LKAS_DW.LKA_Mode) == 0) {
          /* Transition: '<S335>:35' */
          LKAS_DW.is_SysOff_c = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S335>:32' */
          LKAS_DW.LDWSM_stLDWState = 1U;
        }
      } else {
        LKAS_DW.LDWSM_stLDWState = 1U;

        /* During 'Unselected': '<S335>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S335>:3' */
      if (LKAS_DW.LDW_Fault) {
        /* Transition: '<S335>:37' */
        /* Exit Internal 'SysOn': '<S335>:3' */
        if (((uint32)LKAS_DW.is_SysOn_a) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S335>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S335>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S335>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S335>:36' */
        /* Transition: '<S335>:75' */
        /* Entry 'LDWFault': '<S335>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) != 1) && (((sint32)LKAS_DW.LKA_Mode)
                  != 2)) {
        /* Transition: '<S335>:42' */
        /* Exit Internal 'SysOn': '<S335>:3' */
        if (((uint32)LKAS_DW.is_SysOn_a) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S335>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S335>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S335>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_c = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S335>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_a) == LKAS_IN_LDWSelected) {
        LKAS_DW.LDWSM_stLDWState = 2U;

        /* During 'LDWSelected': '<S335>:47' */
        if ((LKAS_DW.Merge_ew) && (!LKAS_DW.Merge1_i)) {
          /* Transition: '<S335>:50' */
          LKAS_DW.is_SysOn_a = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S335>:102' */
          /* Transition: '<S335>:113' */
          LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S335>:112' */
          LKAS_DW.LDWSM_stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S335>:102' */
        if (LKAS_DW.Merge1_i) {
          /* Transition: '<S335>:44' */
          /* Exit Internal 'Normal': '<S335>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S335>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S335>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_a = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S335>:47' */
          LKAS_DW.LDWSM_stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.LDWSM_stLDWState = 3U;

            /* During 'LDWEnable': '<S335>:112' */
            if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.LKA_Fault))
            {
              /* Transition: '<S335>:118' */
              LKAS_DW.is_Normal_i = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S335>:114' */
              LKAS_DW.LDWSM_stLDWState = 4U;
              LKAS_DW.LDWSM_stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S335>:119' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S335>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.LDWSM_stLDWState = 4U;

            /* During 'LDWLeftActive': '<S335>:114' */
            if (LKAS_DW.LKA_Fault) {
              /* Transition: '<S335>:116' */
              /* Exit 'LDWLeftActive': '<S335>:114' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S335>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S335>:120' */
                /* Exit 'LDWLeftActive': '<S335>:114' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S335>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LDWSM_stLDWState = 5U;

            /* During 'LDWRightActive': '<S335>:115' */
            if (LKAS_DW.LKA_Fault) {
              /* Transition: '<S335>:117' */
              /* Exit 'LDWRightActive': '<S335>:115' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S335>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.LKA_Fault))
              {
                /* Transition: '<S335>:121' */
                /* Exit 'LDWRightActive': '<S335>:115' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S335>:114' */
                LKAS_DW.LDWSM_stLDWState = 4U;
                LKAS_DW.LDWSM_stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S142>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S142>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_active_c70_LKAS = 0U;
  LKAS_DW.is_c70_LKAS = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.LKASM_stLKAActvFlg = 0U;
  LKAS_DW.LKASM_stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S142>/LKA_State_Machine'
 * Block description for: '<S142>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S142>/LKA_State_Machine'
   *
   * Block description for '<S142>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  if (((uint32)LKAS_DW.is_active_c70_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    LKAS_DW.is_active_c70_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    /* Transition: '<S336>:2' */
    LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_i;

    /* Entry Internal 'SysOff': '<S336>:1' */
    /* Transition: '<S336>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_h;

    /* Entry 'Unavailable': '<S336>:30' */
    LKAS_DW.LKASM_stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c70_LKAS) {
     case LKAS_IN_Fault_i:
      /* During 'Fault': '<S336>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.LKA_Mode) == 2)) {
        /* Transition: '<S336>:38' */
        /* Exit Internal 'Fault': '<S336>:36' */
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOn_h;

        /* Entry Internal 'SysOn': '<S336>:3' */
        /* Transition: '<S336>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S336>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)
                    LKAS_DW.LKA_Mode) == 1)) && tmp) {
        /* Transition: '<S336>:40' */
        /* Exit Internal 'Fault': '<S336>:36' */
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_i;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_l;

        /* Entry 'Unselected': '<S336>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else {
        LKAS_DW.LKASM_stLKAState = 6U;

        /* During 'LKAFault': '<S336>:72' */
      }
      break;

     case LKAS_IN_SysOff_i:
      /* During 'SysOff': '<S336>:1' */
      if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S336>:39' */
        /* Exit Internal 'SysOff': '<S336>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
        LKAS_DW.is_c70_LKAS = LKAS_IN_Fault_i;

        /* Entry Internal 'Fault': '<S336>:36' */
        /* Transition: '<S336>:74' */
        /* Entry 'LKAFault': '<S336>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode) == 2) {
        /* Transition: '<S336>:41' */
        /* Exit Internal 'SysOff': '<S336>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOn_h;

        /* Entry Internal 'SysOn': '<S336>:3' */
        /* Transition: '<S336>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S336>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_h) {
        LKAS_DW.LKASM_stLKAState = 0U;

        /* During 'Unavailable': '<S336>:30' */
        if ((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)LKAS_DW.LKA_Mode) ==
             1)) {
          /* Transition: '<S336>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_l;

          /* Entry 'Unselected': '<S336>:32' */
          LKAS_DW.LKASM_stLKAState = 1U;
        }
      } else {
        LKAS_DW.LKASM_stLKAState = 1U;

        /* During 'Unselected': '<S336>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S336>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S336>:37' */
        /* Exit Internal 'SysOn': '<S336>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_p) {
          /* Exit Internal 'Normal': '<S336>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S336>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S336>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        }

        LKAS_DW.is_c70_LKAS = LKAS_IN_Fault_i;

        /* Entry Internal 'Fault': '<S336>:36' */
        /* Transition: '<S336>:74' */
        /* Entry 'LKAFault': '<S336>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode) != 2) {
        /* Transition: '<S336>:42' */
        /* Exit Internal 'SysOn': '<S336>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_p) {
          /* Exit Internal 'Normal': '<S336>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S336>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S336>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        }

        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_i;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_l;

        /* Entry 'Unselected': '<S336>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.LKASM_stLKAState = 2U;

        /* During 'LKASelected': '<S336>:19' */
        if ((LKAS_DW.Merge1_a) && (!LKAS_DW.Merge2)) {
          /* Transition: '<S336>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_p;

          /* Entry Internal 'Normal': '<S336>:102' */
          /* Transition: '<S336>:103' */
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S336>:108' */
          LKAS_DW.LKASM_stLKAState = 3U;
        }
      } else {
        /* During 'Normal': '<S336>:102' */
        if (LKAS_DW.Merge2) {
          /* Transition: '<S336>:25' */
          /* Exit Internal 'Normal': '<S336>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S336>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S336>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

          /* Entry 'LKASelected': '<S336>:19' */
          LKAS_DW.LKASM_stLKAState = 2U;
        } else {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKAEnable:
            LKAS_DW.LKASM_stLKAState = 3U;

            /* During 'LKAEnable': '<S336>:108' */
            if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_c)) {
              /* Transition: '<S336>:105' */
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

              /* Entry 'LKALeftActive': '<S336>:109' */
              LKAS_DW.LKASM_stLKAState = 4U;
              LKAS_DW.LKASM_stLKAActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S336>:104' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S336>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LKALeftActive:
            LKAS_DW.LKASM_stLKAState = 4U;

            /* During 'LKALeftActive': '<S336>:109' */
            if (LKAS_DW.Merge1_c) {
              /* Transition: '<S336>:106' */
              /* Exit 'LKALeftActive': '<S336>:109' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S336>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S336>:111' */
                /* Exit 'LKALeftActive': '<S336>:109' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S336>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LKASM_stLKAState = 5U;

            /* During 'LKARightActive': '<S336>:110' */
            if (LKAS_DW.Merge1_c) {
              /* Transition: '<S336>:107' */
              /* Exit 'LKARightActive': '<S336>:110' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S336>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S336>:112' */
                /* Exit 'LKARightActive': '<S336>:110' */
                LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

                /* Entry 'LKALeftActive': '<S336>:109' */
                LKAS_DW.LKASM_stLKAState = 4U;
                LKAS_DW.LKASM_stLKAActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S142>/LKA_State_Machine' */
}

/*
 * Output and update for action system:
 *    '<S357>/Ph1SWA'
 *    '<S366>/Ph1SWA'
 *    '<S393>/Ph1SWA'
 *    '<S403>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S361>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S361>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S357>/Ph2SWA'
 *    '<S366>/Ph2SWA'
 *    '<S393>/Ph2SWA'
 *    '<S403>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S362>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S362>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S357>/Ph3SWA'
 *    '<S393>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S363>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S366>/Ph3SWA'
 *    '<S403>/Ph3SWA'
 */
void LKAS_Ph3SWA_f(float32 *rty_Out)
{
  /* SignalConversion: '<S372>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S372>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S429>/If Action Subsystem4'
 *    '<S429>/If Action Subsystem3'
 *    '<S535>/If Action Subsystem3'
 *    '<S535>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S441>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S441>/Constant'
   */
  *rty_Out = false;
}

/*
 * Output and update for action system:
 *    '<S464>/If Action Subsystem'
 *    '<S464>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_nh(boolean *rty_Out)
{
  /* SignalConversion: '<S468>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S468>/Constant'
   */
  *rty_Out = true;
}

/*
 * Output and update for atomic system:
 *    '<S549>/MATLAB Function'
 *    '<S568>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_DvtThresUprLDW, float32 rtu_LaneWidth,
  float32 rtu_LKA_CarWidth, float32 *rty_ThresDet_coefficient)
{
  float32 tmp;

  /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Enable Condition  (EnaC)/LDW Own Condition (LDWOwnC)/Vehicle Position Check (VehPosChk)/Subsystem/MATLAB Function': '<S550>:1' */
  /* '<S550>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
  /* '<S550>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
  /* '<S550>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
  /* '<S550>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
  /* '<S550>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
  tmp = (2.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth;
  *rty_ThresDet_coefficient = fminf(fmaxf(0.0F, (fminf(fmaxf(tmp, rtu_LaneWidth),
    (6.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth) - tmp) / (4.0F *
    rtu_DvtThresUprLDW)), 1.0F);
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_VehSpd;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_Gain_j;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_Gain_g;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_MAX_DELAY_EPSSTAR_TIME;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_LFClb_TFC_KpVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KpVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KpV1_C;
  float32 rtb_LL_LFClb_TFC_KpV2_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KdV1_C;
  float32 rtb_LL_LFClb_TFC_KdV2_C;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_LL_HandsOff_WarnTime;
  float32 rtb_LL_HandsOff_TextTime;
  float32 rtb_R0_VR_e;
  float32 rtb_L0_VR_e;
  float32 rtb_R0_W_d;
  float32 rtb_L0_W_f;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_VR;
  float32 rtb_R1_W;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_lStpLngth_C;
  float32 rtb_LL_DesDvt_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_i;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1;
  float32 rtb_phiHdAg_Lft;
  float32 rtb_Add5_n;
  float32 rtb_phiHdAg_Rgt;
  float32 rtb_Add_p;
  float32 rtb_Add_o;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge;
  float32 rtb_Switch_d;
  float32 rtb_Saturation_c;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Multiply;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_f;
  float32 rtb_Switch_h;
  float32 rtb_Saturation_f;
  float32 rtb_Abs1_m;
  float32 rtb_Abs_i;
  float32 rtb_UnaryMinus_n;
  float32 rtb_Merge1;
  float32 rtb_Divide_b;
  float32 rtb_Switch_c;
  float32 rtb_Switch2_o;
  float32 rtb_Divide_ba;
  float32 rtb_Switch_n;
  float32 rtb_Switch2_n;
  float32 rtb_Merge1_f;
  float32 rtb_Divide_d;
  float32 rtb_Switch_gw;
  float32 rtb_Switch2_d;
  float32 rtb_Divide_f;
  float32 rtb_Switch_gi;
  float32 rtb_Switch2_fg;
  float32 rtb_Multiply_d;
  float32 rtb_Switch_p;
  float32 rtb_Switch2_c;
  float32 rtb_Memory_e;
  float32 rtb_Merge1_n;
  float32 rtb_Divide_k;
  float32 rtb_Switch_a;
  float32 rtb_Switch2_j;
  float32 rtb_Divide_kp;
  float32 rtb_Switch_o;
  float32 rtb_Switch2_jh;
  float32 rtb_Memory_p;
  float32 rtb_Merge1_j;
  float32 rtb_Divide_bk;
  float32 rtb_Switch_gl;
  float32 rtb_Switch2_nc;
  float32 rtb_Divide_h;
  float32 rtb_Switch_e;
  float32 rtb_Switch2_g;
  float32 rtb_Saturation_d;
  float32 rtb_Divide_ca;
  float32 rtb_Divide_dv;
  float32 rtb_Add_am;
  float32 rtb_Add_e1;
  float32 rtb_phiHdAg;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_ThresDet_coefficient;
  float32 rtb_ThresDet_coefficient_a;
  float32 rtb_Saturation2_g;
  float32 rtb_Add1_i;
  float32 rtb_Merge_c;
  float32 rtb_Gain_iu;
  float32 rtb_Gain1_p;
  float32 rtb_Add_id;
  float32 rtb_Add_l;
  float32 rtb_Saturation6;
  float32 rtb_Saturation2_l;
  float32 rtb_Saturation2_n;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_gi;
  float32 rtb_Saturation_e;
  float32 rtb_Add1_h;
  float32 rtb_kphtomps_l;
  float32 rtb_Saturation_j;
  float32 rtb_Switch2_i;
  float32 rtb_Switch_k;
  float32 rtb_Switch2_at;
  float32 rtb_Gain1_i5;
  float32 rtb_Switch_fy;
  float32 rtb_Switch2_g1;
  float32 rtb_Divide5_l;
  float32 rtb_Divide2_be;
  float32 rtb_Merge_d;
  float32 rtb_Switch_fl;
  float32 rtb_Switch2_k;
  float32 rtb_Divide7;
  float32 rtb_Switch_pi;
  float32 rtb_Switch2_p;
  float32 rtb_Saturation_nf;
  float32 rtb_Switch_kb;
  float32 rtb_Add_of;
  float32 rtb_Switch_og;
  float32 rtb_Switch2_m;
  float32 rtb_UkYk1_o;
  float32 rtb_Switch_dr;
  float32 rtb_Switch2_co;
  float32 rtb_Abs1_g;
  float32 rtb_Abs_h;
  float32 rtb_Add1_kd;
  float32 rtb_Merge_f;
  float32 rtb_Merge_fs;
  float32 rtb_Merge_k;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_gv;
  float32 rtb_Saturation_ae;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_In;
  float32 rtb_In_j;
  float32 rtb_In_a;
  float32 rtb_Plan;
  float32 rtb_T1_i;
  float32 rtb_Plan_g;
  float32 rtb_T1_g;
  float32 rtb_Gain_m;
  float32 rtb_Merge_e;
  float32 rtb_kphTomps_j;
  float32 rtb_Divide3_j;
  float32 rtb_Gain2_b;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_f;
  uint16 rtb_Saturation1_a;
  uint16 rtb_Saturation1_b;
  uint16 rtb_Saturation1_k;
  uint16 rtb_Saturation1_m;
  uint16 rtb_Saturation2_b;
  uint16 rtb_Add_jk;
  uint16 rtb_Saturation1_or;
  uint16 rtb_Saturation1_p;
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_g;
  uint8 rtb_L0_Type_e;
  uint8 rtb_LDW_Warn_Mode;
  uint8 rtb_IMAPve_d_APA_AutoPark_WorkS;
  uint8 rtb_IMAPve_d_BCM_HazardLamp_g;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_EPS_TrqLim_State;
  uint8 rtb_IMAPve_d_EPS_Trq_State;
  uint8 rtb_IMAPve_d_ESC_LatAcc_Valid;
  uint8 rtb_IMAPve_d_ESC_LonAcc_Valid;
  uint8 rtb_IMAPve_d_ESC_VehSpd_Valid;
  uint8 rtb_IMAPve_d_ESC_YawRate_Valid;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L1_Type;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_R1_Type;
  uint8 rtb_IMAPve_d_SAS_Clb_State;
  uint8 rtb_IMAPve_d_SAS_Trim_State;
  uint8 rtb_IMAPve_d_SWS_Failure_Status;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_LDW_State;
  uint8 rtb_Switch8;
  uint8 rtb_Switch8_g;
  uint8 rtb_Switch8_l;
  uint8 rtb_DACMode;
  uint8 rtb_Saturation1_cv;
  boolean rtb_LogicalOperator2;
  boolean rtb_ADIA_DTC_EMS_14B_InvOorReal;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMaxT;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinN;
  boolean rtb_ADIA_DTC_EMS_17E_InvOorMinT;
  boolean rtb_ADIAve_e_Node_ACU_Validity;
  boolean rtb_ADIAve_e_Node_EPB_Validity;
  boolean rtb_ADIA_Inner_FRadar_FaultStat;
  boolean rtb_ADIAve_d_sen_sta_Corner_rad;
  boolean rtb_ADIAve_e_Node_EMS_Validity;
  boolean rtb_ADIAve_e_Node_TBOX_Validity;
  boolean rtb_ADIA_DTC_ESC_EPBErrorStatus;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorTCS;
  boolean rtb_ADIA_DTC_ESC3_121_InvOorVeh;
  boolean rtb_ADIA_DTC_MP5_366_OorAEBButt;
  boolean rtb_ADIA_DTC_MP5_366_OorFCWButt;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorSta;
  boolean rtb_ADIA_DTC_ESC5_122_InvOorYaw;
  boolean rtb_ADIA_DTC_ESC6_123_InvOorDyn;
  boolean rtb_ADIA_DTC_ESC6_123_InvUnfilY;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehDri;
  boolean rtb_ADIA_DTC_ESC6_123_InvVehHol;
  boolean rtb_ADIA_DTC_GW_MP5_413_OorISAM;
  boolean rtb_ADIA_DTC_SCC_309_OorACCButt;
  boolean rtb_ADIA_DTC_BCM3_33C_InvBrkLig;
  boolean rtb_ADIA_DTC_EMS_14A_OorACCStat;
  boolean rtb_ADIA_DTC_EMS10_88_InvAccPed;
  boolean rtb_ADIA_DTC_EMS5_E0_InvOorBrkP;
  boolean rtb_ADIA_DTC_EMS5_E0_OorEngineS;
  boolean rtb_Compare_iz;
  boolean rtb_UnitDelay_m;
  boolean rtb_Merge_i;
  boolean rtb_Compare_km;
  boolean rtb_UnitDelay_h;
  boolean rtb_Compare_cj;
  boolean rtb_Merge_c0;
  boolean rtb_Merge_n;
  boolean rtb_Compare_bi;
  boolean rtb_LogicalOperator1_f;
  boolean rtb_RelationalOperator6_i;
  boolean rtb_RelationalOperator5;
  boolean rtb_Compare_az;
  boolean rtb_Memory1;
  boolean rtb_Merge_ba;
  float32 x10;
  float32 x20;
  float32 x1;
  sint32 i;
  uint8 rtb_Mod1;
  uint8 rtb_IMAPve_d_R1_Type;
  boolean rtb_LKA_Main_Switch;
  float32 rtb_Abs_k;
  float32 rtb_L0_C0;
  float32 rtb_L0_C2;
  float32 rtb_R0_C2;
  float32 rtb_Saturation;
  float32 rtb_R0_C0;
  uint8 rtb_L0_Q;
  uint8 rtb_R0_Q;
  float32 rtb_Add1;
  float32 rtb_Saturation1;
  uint8 rtb_L0_Type;
  uint8 rtb_R0_Type;
  float32 rtb_L0_C3;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  uint8 rtb_IMAPve_d_BCM_HazardLamp;
  boolean rtb_BCM_Left_Light;
  boolean rtb_BCM_Right_Light;
  uint8 rtb_TCU_ActualGear;
  uint32 rtb_ADIAve_g_ASWFaultStatus;
  uint32 rtb_ADIAve_g_BSWFaultStatus;
  float32 rtb_L0_C0_o;
  float32 rtb_LL_CompHdAg_C;
  float32 rtb_L0_C1_i;
  float32 rtb_R0_C1_e;
  float32 rtb_L0_C1_m;
  float32 rtb_L0_C3_dc;
  float32 rtb_R0_C0_n;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  boolean rtb_LL_SingleLane_Disable_Swt;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LL_LKAExPrcs_tiExitDelayTim;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_Abs_pw;
  float32 rtb_Abs_a;
  float32 rtb_TTLC_d;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_n;
  boolean rtb_LogicalOperator3_b5;
  boolean rtb_RelationalOperator_b;
  boolean rtb_Compare_mw;
  boolean rtb_Compare_ho;
  boolean rtb_LogicalOperator_iv;
  boolean rtb_Compare_bp;
  boolean rtb_LogicalOperator_ix;
  boolean rtb_Compare_ab;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_p1;
  boolean rtb_RelationalOperator_pw;
  boolean rtb_LogicalOperator_ol;
  boolean rtb_LogicalOperator_m;
  uint8 rtb_CastToSingle3;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge_a3;
  uint32 rtb_Add;
  float32 rtb_offset;
  uint16 rtb_Saturation_h5;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  float32 rtb_TTLC;
  float32 rtb_TLft;
  uint8 rtb_ExtractDesiredBits_ad;
  uint8 rtb_ModifyScalingOnly_mo;
  uint8 rtb_ModifyScalingOnly_enu;
  uint8 rtb_ModifyScalingOnly_lt;
  uint8 rtb_ModifyScalingOnly_dt;
  uint8 rtb_ModifyScalingOnly_c;
  uint8 rtb_ModifyScalingOnly_jq;
  uint8 rtb_ModifyScalingOnly_f;
  uint8 rtb_ModifyScalingOnly_h;
  uint8 rtb_ModifyScalingOnly_lz;
  uint8 rtb_ModifyScalingOnly_ib;
  uint8 rtb_ModifyScalingOnly_na;
  uint8 rtb_ModifyScalingOnly_h2;
  uint8 rtb_ModifyScalingOnly_kk;
  uint8 rtb_ModifyScalingOnly_d;
  uint8 rtb_ModifyScalingOnly_ok;
  uint8 rtb_ModifyScalingOnly_fc;
  uint8 rtb_ModifyScalingOnly_dio;
  uint8 rtb_ModifyScalingOnly_h0;
  uint8 rtb_ModifyScalingOnly_m;
  float32 tmp;
  float32 rtb_Abs_f_tmp;
  float32 rtb_Add5_n_tmp;
  float32 rtb_LogicalOperator3_c_tmp;
  float32 rtb_LogicalOperator3_c_tmp_0;
  float32 rtb_LogicalOperator3_c_tmp_1;
  float32 rtb_Add_p_tmp;
  float32 rtb_Add_o_tmp;
  boolean exitg1;

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/FDMMve_d_LkaFcnConf_1' incorporates:
   *  Inport: '<Root>/FDMMve_d_LkaFcnConf'
   */
  rtb_Mod1 = (uint8)
    Rte_IRead_Runnable_LKAS_Step_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf();

  /* Switch: '<S104>/Switch' incorporates:
   *  Constant: '<S104>/Constant3'
   *  Constant: '<S104>/Constant4'
   */
  if (rtb_Mod1 > ((uint8)0U)) {
    rtb_IMAPve_d_R1_Type = ((uint8)1U);
  } else {
    rtb_IMAPve_d_R1_Type = ((uint8)0U);
  }

  /* End of Switch: '<S104>/Switch' */

  /* Saturate: '<S104>/Saturation1' */
  if (rtb_Mod1 > ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  } else {
    if (rtb_Mod1 < ((uint8)1U)) {
      rtb_Mod1 = ((uint8)1U);
    }
  }

  /* End of Saturate: '<S104>/Saturation1' */

  /* Sum: '<S104>/Add1' incorporates:
   *  Constant: '<S104>/Constant1'
   */
  rtb_Mod1 -= ((uint8)1U);

  /* Saturate: '<S104>/Saturation' */
  if (rtb_Mod1 >= ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  }

  /* End of Saturate: '<S104>/Saturation' */

  /* Math: '<S104>/Mod' incorporates:
   *  Constant: '<S104>/Constant2'
   */
  if (((sint32)((uint8)6U)) == 0) {
    rtb_L0_Q = rtb_Mod1;
  } else {
    rtb_L0_Q = (uint8)(rtb_Mod1 % ((uint8)6U));
  }

  /* End of Math: '<S104>/Mod' */

  /* Product: '<S104>/Divide1' incorporates:
   *  Constant: '<S104>/Constant5'
   */
  rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((uint32)rtb_L0_Q) / ((uint32)((uint8)3U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LKA_Mode'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode();

  /* MinMax: '<S104>/Max' */
  if (rtb_IMAPve_d_BCM_HazardLamp > rtb_L0_Type) {
    rtb_L0_Type = rtb_IMAPve_d_BCM_HazardLamp;
  }

  /* End of MinMax: '<S104>/Max' */

  /* Product: '<S104>/Divide' incorporates:
   *  Constant: '<S104>/Constant6'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  Inport: '<Root>/IMAPve_d_LKA_Main_Switch'
   *  Logic: '<S104>/Logical Operator'
   *  Sum: '<S104>/Add'
   */
  LKAS_DW.LKA_Mode = (uint8)((sint32)(((((sint32)rtb_IMAPve_d_R1_Type) != 0) ||
    (((sint32)((uint8)
               Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch
               ())) != 0)) ? ((sint32)((uint8)(((uint32)rtb_L0_Type) + ((uint32)
    ((uint8)1U))))) : 0));

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Q'
   */
  rtb_IMAPve_d_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q();

  /* Switch: '<S115>/Switch' incorporates:
   *  Constant: '<S115>/Constant'
   */
  if (rtb_IMAPve_d_R1_Type >= ((uint8)2U)) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = rtb_IMAPve_d_R1_Type;
  }

  /* End of Switch: '<S115>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Q'
   */
  rtb_IMAPve_d_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q();

  /* Switch: '<S112>/Switch1' incorporates:
   *  Constant: '<S112>/Constant1'
   */
  if (rtb_IMAPve_d_R1_Type >= ((uint8)2U)) {
    rtb_R0_Q = ((uint8)3U);
  } else {
    rtb_R0_Q = rtb_IMAPve_d_R1_Type;
  }

  /* End of Switch: '<S112>/Switch1' */

  /* Chart: '<S111>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c26_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c26_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S116>:4' */
    LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S116>:3' */
    /* '<S116>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S116>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S116>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c26_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S116>:9' */
      /* '<S116>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S116>:13' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S116>:3' */
        /* '<S116>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S116>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S116>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S116>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S116>:14' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S116>:7' */
          /* '<S116>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S116>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S116>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S116>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
            /* Transition: '<S116>:23' */
            LKAS_DW.is_c26_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S116>:5' */
            /* '<S116>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S116>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S116>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S116>:5' */
      /* '<S116>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S116>:16' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S116>:3' */
        /* '<S116>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S116>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S116>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S116>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S116>:18' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S116>:7' */
          /* '<S116>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S116>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S116>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S116>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_R0_Q) < 3) {
            /* Transition: '<S116>:11' */
            LKAS_DW.is_c26_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S116>:3' */
      /* '<S116>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S116>:6' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S116>:5' */
        /* '<S116>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S116>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S116>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S116>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S116>:8' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S116>:7' */
          /* '<S116>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S116>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S116>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S116>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) < 3)) {
            /* Transition: '<S116>:10' */
            /* '<S116>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c26_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S116>:7' */
      /* '<S116>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S116>:17' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S116>:3' */
        /* '<S116>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S116>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S116>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S116>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
          /* Transition: '<S116>:19' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S116>:5' */
          /* '<S116>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S116>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S116>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S116>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_L0_Q) < 3) {
            /* Transition: '<S116>:12' */
            LKAS_DW.is_c26_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S111>/LaneReconstructSM' */

  /* DataTypeConversion: '<S110>/Cast To Single64' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   *  UnaryMinus: '<S110>/Unary Minus'
   */
  rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single65' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  UnaryMinus: '<S110>/Unary Minus2'
   */
  rtb_L0_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2
    ()));

  /* UnaryMinus: '<S110>/Unary Minus6' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   */
  rtb_Abs_k = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single56' */
  rtb_R0_C2 = rtb_Abs_k;

  /* Sum: '<S121>/Add2' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single56'
   */
  rtb_Abs_k += rtb_L0_C2;

  /* Abs: '<S121>/Abs' */
  rtb_Abs_k = fabsf(rtb_Abs_k);

  /* Saturate: '<S121>/Saturation' */
  if (rtb_Abs_k > 0.004F) {
    rtb_Saturation = 0.004F;
  } else if (rtb_Abs_k < 0.0F) {
    rtb_Saturation = 0.0F;
  } else {
    rtb_Saturation = rtb_Abs_k;
  }

  /* End of Saturate: '<S121>/Saturation' */

  /* UnaryMinus: '<S110>/Unary Minus4' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   */
  rtb_Abs_k = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single55' */
  rtb_R0_C0 = rtb_Abs_k;

  /* Switch: '<S125>/Switch' incorporates:
   *  Constant: '<S134>/Constant'
   *  Constant: '<S135>/Constant'
   *  DataTypeConversion: '<S110>/Cast To Single55'
   *  Delay: '<S125>/Delay'
   *  Gain: '<S125>/Gain'
   *  Logic: '<S125>/Logical Operator'
   *  RelationalOperator: '<S134>/Compare'
   *  RelationalOperator: '<S135>/Compare'
   *  Sum: '<S125>/Add'
   */
  if ((rtb_L0_Q >= ((uint8)2U)) && (rtb_R0_Q >= ((uint8)2U))) {
    rtb_Abs_k += (-1.0F) * rtb_L0_C0;
  } else {
    rtb_Abs_k = LKAS_DW.Delay_DSTATE;
  }

  /* End of Switch: '<S125>/Switch' */

  /* Sum: '<S133>/Add1' incorporates:
   *  Memory: '<S133>/Memory'
   *  Product: '<S133>/Divide'
   *  Product: '<S133>/Divide1'
   */
  rtb_Add1 = (rtb_Abs_k * LKAS_ConstB.Divide2) + (LKAS_ConstB.Add2 *
    LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S125>/Saturation1' */
  if (rtb_Add1 > 5.5F) {
    rtb_Saturation1 = 5.5F;
  } else if (rtb_Add1 < 2.5F) {
    rtb_Saturation1 = 2.5F;
  } else {
    rtb_Saturation1 = rtb_Add1;
  }

  /* End of Saturate: '<S125>/Saturation1' */

  /* MATLAB Function: '<S121>/get_roadside_offset' */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S127>:1' */
  /* '<S127>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S127>:1:3' cur=min(single(0.004),cur); */
  /* '<S127>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S127>:1:5' offset=min(single(0.5),offset); */
  rtb_offset = fminf(0.5F, (((fminf(0.004F, rtb_Saturation) / 0.004F) + 1.0F) *
    0.2F) * (fminf(4.0F, rtb_Saturation1) - 2.0F));

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   */
  rtb_IMAPve_d_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type();

  /* DataTypeConversion: '<S110>/Cast To Single77' */
  rtb_L0_Type = rtb_IMAPve_d_R1_Type;

  /* Switch: '<S126>/Switch' incorporates:
   *  Constant: '<S137>/Constant'
   *  DataTypeConversion: '<S110>/Cast To Single77'
   *  RelationalOperator: '<S137>/Compare'
   *  Sum: '<S126>/Add'
   */
  if (rtb_IMAPve_d_R1_Type == ((uint8)10U)) {
    rtb_L0_C0 += rtb_offset;
  }

  /* End of Switch: '<S126>/Switch' */

  /* Switch: '<S136>/Switch' incorporates:
   *  Abs: '<S136>/Abs'
   *  Constant: '<S138>/Constant'
   *  Memory: '<S136>/Memory'
   *  Memory: '<S136>/Memory1'
   *  Product: '<S136>/Divide'
   *  Product: '<S136>/Divide1'
   *  RelationalOperator: '<S138>/Compare'
   *  Sum: '<S136>/Add1'
   *  Sum: '<S136>/Add3'
   */
  if (fabsf(rtb_L0_C0 - LKAS_DW.Memory1_PreviousInput) > 0.5F) {
    rtb_Saturation = rtb_L0_C0;
  } else {
    rtb_Saturation = (rtb_L0_C0 * LKAS_ConstB.Divide2_l) + (LKAS_ConstB.Add2_b *
      LKAS_DW.Memory_PreviousInput_m);
  }

  /* End of Switch: '<S136>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   */
  rtb_IMAPve_d_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type();

  /* DataTypeConversion: '<S110>/Cast To Single48' */
  rtb_R0_Type = rtb_IMAPve_d_R1_Type;

  /* Switch: '<S122>/Switch1' incorporates:
   *  Constant: '<S129>/Constant'
   *  DataTypeConversion: '<S110>/Cast To Single48'
   *  RelationalOperator: '<S129>/Compare'
   *  Sum: '<S122>/Add1'
   */
  if (rtb_IMAPve_d_R1_Type == ((uint8)10U)) {
    rtb_R0_C0 -= rtb_offset;
  }

  /* End of Switch: '<S122>/Switch1' */

  /* Switch: '<S128>/Switch' incorporates:
   *  Abs: '<S128>/Abs'
   *  Constant: '<S130>/Constant'
   *  Memory: '<S128>/Memory'
   *  Memory: '<S128>/Memory1'
   *  Product: '<S128>/Divide'
   *  Product: '<S128>/Divide1'
   *  RelationalOperator: '<S130>/Compare'
   *  Sum: '<S128>/Add1'
   *  Sum: '<S128>/Add3'
   */
  if (fabsf(rtb_R0_C0 - LKAS_DW.Memory1_PreviousInput_h) > 0.5F) {
    rtb_offset = rtb_R0_C0;
  } else {
    rtb_offset = (rtb_R0_C0 * LKAS_ConstB.Divide2_lw) + (LKAS_ConstB.Add2_j *
      LKAS_DW.Memory_PreviousInput_f);
  }

  /* End of Switch: '<S128>/Switch' */

  /* Switch: '<S111>/Switch1' incorporates:
   *  Gain: '<S118>/Gain'
   *  Sum: '<S118>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_o = rtb_Saturation;
  } else {
    rtb_L0_C0_o = (rtb_Saturation1 - rtb_offset) * (-1.0F);
  }

  /* Switch: '<S656>/Switch24' incorporates:
   *  Constant: '<S656>/LL_CompHdAg_C=0.005'
   */
  if (LKAS_ConstB.DataTypeConversion38 != 0.0F) {
    rtb_LL_CompHdAg_C = LKAS_ConstB.DataTypeConversion38;
  } else {
    rtb_LL_CompHdAg_C = LL_CompHdAg_C;
  }

  /* End of Switch: '<S656>/Switch24' */

  /* Switch: '<S123>/Switch1' incorporates:
   *  Constant: '<S131>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
   *  Inport: '<Root>/IMAPve_g_L0_C1'
   *  RelationalOperator: '<S131>/Compare'
   *  Sum: '<S123>/Add'
   *  UnaryMinus: '<S110>/Unary Minus1'
   */
  if (rtb_L0_Q == ((uint8)3U)) {
    rtb_L0_C1_i = rtb_LL_CompHdAg_C + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1())));
  } else {
    rtb_L0_C1_i = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1()));
  }

  /* End of Switch: '<S123>/Switch1' */

  /* Switch: '<S124>/Switch1' incorporates:
   *  Constant: '<S132>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
   *  Inport: '<Root>/IMAPve_g_R0_C1'
   *  RelationalOperator: '<S132>/Compare'
   *  Sum: '<S124>/Add'
   *  UnaryMinus: '<S110>/Unary Minus5'
   */
  if (rtb_R0_Q == ((uint8)3U)) {
    rtb_R0_C1_e = rtb_LL_CompHdAg_C + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1())));
  } else {
    rtb_R0_C1_e = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1()));
  }

  /* End of Switch: '<S124>/Switch1' */

  /* DataTypeConversion: '<S110>/Cast To Single67' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  UnaryMinus: '<S110>/Unary Minus3'
   */
  rtb_L0_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3
    ()));

  /* UnaryMinus: '<S110>/Unary Minus7' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   */
  rtb_Abs_k = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3
    ()));

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single60'
   *  DataTypeConversion: '<S118>/Cast To Single1'
   *  DataTypeConversion: '<S118>/Cast To Single2'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C1_m = rtb_L0_C1_i;
    rtb_LL_CompHdAg_C = rtb_L0_C2;
    rtb_L0_C3_dc = rtb_L0_C3;
  } else {
    rtb_L0_C1_m = rtb_R0_C1_e;
    rtb_LL_CompHdAg_C = rtb_R0_C2;
    rtb_L0_C3_dc = rtb_Abs_k;
  }

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single60'
   *  Sum: '<S120>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_C0_n = rtb_offset;
    rtb_L0_C1_i = rtb_R0_C1_e;
    rtb_L0_C2 = rtb_R0_C2;
    rtb_L0_C3 = rtb_Abs_k;
  } else {
    rtb_R0_C0_n = rtb_Saturation1 + rtb_Saturation;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_LKA_State'
   */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  rtb_IMAPve_g_EPS_SW_Trq = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  rtb_IMAPve_g_ESC_VehSpd = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  rtb_IMAPve_g_ESC_LonAcc = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc();

  /* Gain: '<S106>/Gain' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1'
   *  Inport: '<Root>/IMAPve_g_EPS_SteeringAngle'
   */
  rtb_R0_C2 = 1.0F * ((float32)
                      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
                      ());

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp'
   */
  rtb_IMAPve_d_BCM_HazardLamp = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp
    ();

  /* Logic: '<S101>/Logical Operator' incorporates:
   *  Constant: '<S108>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Left_Light'
   *  RelationalOperator: '<S108>/Compare'
   */
  rtb_BCM_Left_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch
                    ()) == ((uint8)1U)));

  /* Logic: '<S101>/Logical Operator1' incorporates:
   *  Constant: '<S109>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Right_Light'
   *  RelationalOperator: '<S109>/Compare'
   */
  rtb_BCM_Right_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
                    ()) == ((uint8)1U)));

  /* MultiPortSwitch: '<S105>/Multiport Switch' incorporates:
   *  Constant: '<S105>/Constant1'
   *  Constant: '<S105>/Constant3'
   *  DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1'
   *  Inport: '<Root>/IMAPve_d_TCU_Actual_Gear'
   */
  switch ((uint8)
          Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear
          ()) {
   case 0:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 1:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 2:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 3:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 4:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 5:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 6:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 7:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 8:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 9:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   default:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;
  }

  /* End of MultiPortSwitch: '<S105>/Multiport Switch' */

  /* Switch: '<S657>/Switch58' incorporates:
   *  Constant: '<S657>/LLSMConClb4'
   *
   * Block description for '<S657>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S657>/Switch58' */

  /* Gain: '<S662>/Gain' incorporates:
   *  Constant: '<S662>/Constant'
   *  Sum: '<S662>/Add'
   */
  rtb_Gain_j = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S657>/Switch84' incorporates:
   *  Constant: '<S657>/LLSMConClb5'
   *
   * Block description for '<S657>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S657>/Switch84' */

  /* Switch: '<S657>/Switch85' incorporates:
   *  Constant: '<S657>/LLSMConClb6'
   *
   * Block description for '<S657>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S657>/Switch85' */

  /* Switch: '<S657>/Switch86' incorporates:
   *  Constant: '<S657>/LLSMConClb7'
   *
   * Block description for '<S657>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S657>/Switch86' */

  /* Switch: '<S657>/Switch54' incorporates:
   *  Constant: '<S657>/LLSMConClb12'
   *
   * Block description for '<S657>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S657>/Switch54' */

  /* Switch: '<S657>/Switch55' incorporates:
   *  Constant: '<S657>/LLSMConClb13'
   *
   * Block description for '<S657>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S657>/Switch55' */

  /* Switch: '<S657>/Switch60' incorporates:
   *  Constant: '<S657>/LLSMConClb17'
   *
   * Block description for '<S657>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S657>/Switch60' */

  /* Switch: '<S657>/Switch57' incorporates:
   *  Constant: '<S657>/LLSMConClb18'
   *
   * Block description for '<S657>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S657>/Switch57' */

  /* Switch: '<S657>/Switch59' incorporates:
   *  Constant: '<S657>/LLSMConClb19'
   *
   * Block description for '<S657>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_Abs_k = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_Abs_k = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S657>/Switch59' */

  /* Switch: '<S657>/Switch69' incorporates:
   *  Constant: '<S657>/LLSMConClb22'
   *
   * Block description for '<S657>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S657>/Switch69' */

  /* Gain: '<S659>/Gain' incorporates:
   *  Constant: '<S659>/Constant'
   *  Sum: '<S659>/Add'
   */
  rtb_Gain_g = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S657>/Switch68' incorporates:
   *  Constant: '<S657>/LLSMConClb23'
   *
   * Block description for '<S657>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S657>/Switch68' */

  /* Switch: '<S657>/Switch70' incorporates:
   *  Constant: '<S657>/LLSMConClb24'
   *
   * Block description for '<S657>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S657>/Switch70' */

  /* Switch: '<S657>/Switch71' incorporates:
   *  Constant: '<S657>/LLSMConClb25'
   *
   * Block description for '<S657>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S657>/Switch71' */

  /* Switch: '<S657>/Switch73' incorporates:
   *  Constant: '<S657>/LLSMConClb27'
   *
   * Block description for '<S657>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S657>/Switch73' */

  /* Switch: '<S657>/Switch62' incorporates:
   *  Constant: '<S657>/LLSMConClb31'
   *
   * Block description for '<S657>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S657>/Switch62' */

  /* Switch: '<S657>/Switch63' incorporates:
   *  Constant: '<S657>/LLSMConClb32'
   *
   * Block description for '<S657>/LLSMConClb32':
   *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
   */
  if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LKAS_ConstB.DataTypeConversion78;
  } else {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LL_MAX_DELAY_EPSSTAR_TIME;
  }

  /* End of Switch: '<S657>/Switch63' */

  /* Switch: '<S657>/Switch66' incorporates:
   *  Constant: '<S657>/LLSMConClb35'
   *
   * Block description for '<S657>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S657>/Switch66' */

  /* Switch: '<S657>/Switch4' incorporates:
   *  Constant: '<S657>/LL_RlsDet_tiTDelTime_DISABLE=4'
   *
   * Block description for '<S657>/LL_RlsDet_tiTDelTime_DISABLE=4':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_SingleLane_Disable_Swt = (LKAS_ConstB.DataTypeConversion4 != 0.0F);
  } else {
    rtb_LL_SingleLane_Disable_Swt = LL_SingleLane_Disable_Swt;
  }

  /* End of Switch: '<S657>/Switch4' */

  /* Switch: '<S657>/Switch81' incorporates:
   *  Constant: '<S657>/LLSMConClb36'
   *
   * Block description for '<S657>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S657>/Switch81' */

  /* Switch: '<S657>/Switch82' incorporates:
   *  Constant: '<S657>/LLSMConClb37'
   *
   * Block description for '<S657>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S657>/Switch82' */

  /* Switch: '<S657>/Switch83' incorporates:
   *  Constant: '<S657>/LLSMConClb38'
   *
   * Block description for '<S657>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S657>/Switch83' */

  /* Switch: '<S657>/Switch75' incorporates:
   *  Constant: '<S657>/LLSMConClb39'
   *
   * Block description for '<S657>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S657>/Switch75' */

  /* Switch: '<S657>/Switch76' incorporates:
   *  Constant: '<S657>/LLSMConClb40'
   *
   * Block description for '<S657>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S657>/Switch76' */

  /* Switch: '<S657>/Switch77' incorporates:
   *  Constant: '<S657>/LLSMConClb41'
   *
   * Block description for '<S657>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S657>/Switch77' */

  /* Switch: '<S657>/Switch78' incorporates:
   *  Constant: '<S657>/LLSMConClb42'
   *
   * Block description for '<S657>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S657>/Switch78' */

  /* Switch: '<S656>/Switch3' incorporates:
   *  Constant: '<S656>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3_b != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3_b;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S656>/Switch3' */

  /* Switch: '<S656>/Switch31' incorporates:
   *  Constant: '<S656>/LL_LFClb_TFC_KpVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_j != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LKAS_ConstB.DataTypeConversion14_j;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S656>/Switch31' */

  /* Switch: '<S656>/Switch34' incorporates:
   *  Constant: '<S656>/LL_LFClb_TFC_KpVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4_o != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LKAS_ConstB.DataTypeConversion4_o;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S656>/Switch34' */

  /* Switch: '<S656>/Switch33' incorporates:
   *  Constant: '<S656>/LL_LFClb_TFC_KpV1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_l != 0.0F) {
    rtb_LL_LFClb_TFC_KpV1_C = LKAS_ConstB.DataTypeConversion7_l;
  } else {
    rtb_LL_LFClb_TFC_KpV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S656>/Switch33' */

  /* Switch: '<S656>/Switch35' incorporates:
   *  Constant: '<S656>/LL_LFClb_TFC_KpV2_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion17_i != 0.0F) {
    rtb_LL_LFClb_TFC_KpV2_C = LKAS_ConstB.DataTypeConversion17_i;
  } else {
    rtb_LL_LFClb_TFC_KpV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S656>/Switch35' */

  /* Switch: '<S656>/Switch20' incorporates:
   *  Constant: '<S656>/LL_LFClb_TFC_KdVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LL_LFClb_TFC_KdVehSpdLwr_C;
  }

  /* End of Switch: '<S656>/Switch20' */

  /* Switch: '<S656>/Switch22' incorporates:
   *  Constant: '<S656>/LL_LFClb_TFC_KdVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LL_LFClb_TFC_KdVehSpdUpr_C;
  }

  /* End of Switch: '<S656>/Switch22' */

  /* Switch: '<S656>/Switch21' incorporates:
   *  Constant: '<S656>/LL_LFClb_TFC_KdV1_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV1_C = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LFClb_TFC_KdV1_C = LL_LFClb_TFC_KdV1_C;
  }

  /* End of Switch: '<S656>/Switch21' */

  /* Switch: '<S656>/Switch23' incorporates:
   *  Constant: '<S656>/LL_LFClb_TFC_KdV2_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV2_C = LKAS_ConstB.DataTypeConversion30;
  } else {
    rtb_LL_LFClb_TFC_KdV2_C = LL_LFClb_TFC_KdV2_C;
  }

  /* End of Switch: '<S656>/Switch23' */

  /* Switch: '<S656>/Switch9' incorporates:
   *  Constant: '<S656>/LL_LFClb_TFC_KdBalance_C=1.2'
   */
  if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
    rtb_R0_C1_e = LKAS_ConstB.DataTypeConversion9;
  } else {
    rtb_R0_C1_e = LL_LFClb_TFC_KdBalance_C;
  }

  /* End of Switch: '<S656>/Switch9' */

  /* Switch: '<S656>/Switch11' incorporates:
   *  Constant: '<S656>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_b != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12_b;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S656>/Switch11' */

  /* Switch: '<S656>/Switch13' incorporates:
   *  Constant: '<S656>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_m != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_m;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S656>/Switch13' */

  /* Switch: '<S656>/Switch16' incorporates:
   *  Constant: '<S656>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S656>/Switch16' */

  /* Switch: '<S656>/Switch55' incorporates:
   *  Constant: '<S656>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S656>/Switch55' */

  /* Switch: '<S656>/Switch54' incorporates:
   *  Constant: '<S656>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S656>/Switch54' */

  /* Switch: '<S656>/Switch44' incorporates:
   *  Constant: '<S656>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S656>/Switch44' */

  /* Switch: '<S656>/Switch25' incorporates:
   *  Constant: '<S656>/LL_LKAExPrcs_tiExitDelayTime3=0.5'
   */
  if (LKAS_ConstB.DataTypeConversion39 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LKAS_ConstB.DataTypeConversion39;
  } else {
    rtb_LL_LKAExPrcs_tiExitDelayTim = LL_LKAExPrcs_tiExitDelayTime3;
  }

  /* End of Switch: '<S656>/Switch25' */

  /* Switch: '<S654>/Switch19' incorporates:
   *  Constant: '<S654>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_a != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_a;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S654>/Switch19' */

  /* Switch: '<S654>/Switch' incorporates:
   *  Constant: '<S654>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_f != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_f;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S654>/Switch' */

  /* Switch: '<S654>/Switch1' incorporates:
   *  Constant: '<S654>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_c != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_c;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S654>/Switch1' */

  /* Switch: '<S654>/Switch2' incorporates:
   *  Constant: '<S654>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_m != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_m = LKAS_ConstB.DataTypeConversion4_m;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_m = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S654>/Switch2' */

  /* Switch: '<S654>/Switch3' incorporates:
   *  Constant: '<S654>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_h != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_d = LKAS_ConstB.DataTypeConversion6_h;
  } else {
    LKAS_DW.LKA_StrRatio_C_d = LKA_StrRatio_C;
  }

  /* End of Switch: '<S654>/Switch3' */

  /* Switch: '<S654>/Switch11' incorporates:
   *  Constant: '<S654>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S654>/Switch11' */

  /* DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1' incorporates:
   *  Inport: '<Root>/ADIAve_g_ASWFaultStatus'
   */
  rtb_ADIAve_g_ASWFaultStatus = (uint32)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_ASWFaultStatus_ADIAve_g_ASWFaultStatus
    ();

  /* DataTypeConversion: '<S15>/Extract Desired Bits' */
  rtb_ExtractDesiredBits_ad = (uint8)(((uint8)rtb_ADIAve_g_ASWFaultStatus) &
    ((uint8)1));

  /* DataTypeConversion: '<S27>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S27>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_mo = (uint8)(((uint8)(rtb_ADIAve_g_ASWFaultStatus >> 2))
    & ((uint8)1));

  /* DataTypeConversion: '<S38>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S38>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_enu = (uint8)(((uint8)(rtb_ADIAve_g_ASWFaultStatus >> 3))
    & ((uint8)1));

  /* DataTypeConversion: '<S52>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S52>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_lt = (uint8)(((uint8)(rtb_ADIAve_g_ASWFaultStatus >> 9))
    & ((uint8)1));

  /* DataTypeConversion: '<S17>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S17>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_dt = (uint8)(((uint8)(rtb_ADIAve_g_ASWFaultStatus >> 10))
    & ((uint8)1));

  /* DataTypeConversion: '<S19>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S19>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_c = (uint8)(((uint8)(rtb_ADIAve_g_ASWFaultStatus >> 12))
    & ((uint8)1));

  /* DataTypeConversion: '<S22>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S22>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_jq = (uint8)(((uint8)(rtb_ADIAve_g_ASWFaultStatus >> 15))
    & ((uint8)1));

  /* DataTypeConversion: '<S23>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S23>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_f = (uint8)(((uint8)(rtb_ADIAve_g_ASWFaultStatus >> 16))
    & ((uint8)1));

  /* DataTypeConversion: '<S39>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S39>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_h = (uint8)((sint32)(((sint32)((uint32)
    (rtb_ADIAve_g_ASWFaultStatus >> 24))) & 1));

  /* DataTypeConversion: '<S26>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S26>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_lz = (uint8)((sint32)(((sint32)((uint32)
    (rtb_ADIAve_g_ASWFaultStatus >> 27))) & 1));

  /* DataTypeConversion: '<S28>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S28>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_ib = (uint8)((sint32)(((sint32)((uint32)
    (rtb_ADIAve_g_ASWFaultStatus >> 28))) & 1));

  /* DataTypeConversion: '<S30>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S30>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_na = (uint8)((sint32)(((sint32)((uint32)
    (rtb_ADIAve_g_ASWFaultStatus >> 30))) & 1));

  /* DataTypeConversion: '<S31>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S31>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_h2 = (uint8)(rtb_ADIAve_g_ASWFaultStatus >> 31);

  /* DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1' incorporates:
   *  Inport: '<Root>/ADIAve_g_BSWFaultStatus'
   */
  rtb_ADIAve_g_BSWFaultStatus = (uint32)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_BSWFaultStatus_ADIAve_g_BSWFaultStatus
    ();

  /* DataTypeConversion: '<S46>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S46>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_kk = (uint8)(rtb_ADIAve_g_BSWFaultStatus >> 31);

  /* DataTypeConversion: '<S54>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S54>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_d = (uint8)(((uint8)(rtb_ADIAve_g_BSWFaultStatus >> 1))
    & ((uint8)1));

  /* DataTypeConversion: '<S58>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S58>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_ok = (uint8)(((uint8)(rtb_ADIAve_g_BSWFaultStatus >> 2))
    & ((uint8)1));

  /* DataTypeConversion: '<S59>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S59>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_fc = (uint8)(((uint8)(rtb_ADIAve_g_BSWFaultStatus >> 3))
    & ((uint8)1));

  /* DataTypeConversion: '<S60>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S60>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_dio = (uint8)(((uint8)(rtb_ADIAve_g_BSWFaultStatus >> 4))
    & ((uint8)1));

  /* DataTypeConversion: '<S62>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S62>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_h0 = (uint8)(((uint8)(rtb_ADIAve_g_BSWFaultStatus >> 6))
    & ((uint8)1));

  /* DataTypeConversion: '<S64>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S64>/Extract Desired Bits'
   */
  rtb_ModifyScalingOnly_m = (uint8)(((uint8)(rtb_ADIAve_g_BSWFaultStatus >> 8))
    & ((uint8)1));

  /* DataTypeConversion: '<S65>/Modify Scaling Only' incorporates:
   *  DataTypeConversion: '<S65>/Extract Desired Bits'
   */
  rtb_IMAPve_d_R1_Type = (uint8)(((uint8)(rtb_ADIAve_g_BSWFaultStatus >> 9)) &
    ((uint8)1));

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (((sint32)LKAS_DW.LKA_Mode) > 0) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S141>/Delay' */
      LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

      /* InitializeConditions for Memory: '<S581>/Memory' */
      LKAS_DW.Memory_PreviousInput_j = 0.0F;

      /* InitializeConditions for Delay: '<S142>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S524>/Memory' */
      LKAS_DW.Memory_PreviousInput_c = 0.0F;

      /* InitializeConditions for UnitDelay: '<S456>/Delay Input1'
       *
       * Block description for '<S456>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S455>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_i = false;

      /* InitializeConditions for UnitDelay: '<S418>/Delay Input1'
       *
       * Block description for '<S418>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_c = false;

      /* InitializeConditions for UnitDelay: '<S416>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_gu = false;

      /* InitializeConditions for UnitDelay: '<S417>/Delay Input1'
       *
       * Block description for '<S417>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_p = false;

      /* InitializeConditions for Memory: '<S383>/Memory' */
      LKAS_DW.Memory_PreviousInput_eq = false;

      /* InitializeConditions for Delay: '<S142>/Delay' */
      LKAS_DW.Delay_DSTATE_j = false;

      /* InitializeConditions for Delay: '<S142>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S431>/Memory' */
      LKAS_DW.Memory_PreviousInput_id = ((uint8)0U);

      /* InitializeConditions for Memory: '<S357>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = 0.0F;

      /* InitializeConditions for Memory: '<S393>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = 0.0F;

      /* InitializeConditions for Memory: '<S593>/Memory' */
      LKAS_DW.Memory_PreviousInput_ac = 0.0F;

      /* InitializeConditions for Delay: '<S594>/Delay' */
      LKAS_DW.Delay_DSTATE_m = ((uint8)0U);

      /* InitializeConditions for Delay: '<S595>/Delay' */
      LKAS_DW.Delay_DSTATE_d = ((uint8)0U);

      /* InitializeConditions for Delay: '<S596>/Delay' */
      LKAS_DW.Delay_DSTATE_db = ((uint8)0U);

      /* InitializeConditions for Delay: '<S142>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S142>/LDW_State_Machine'
       *
       * Block description for '<S142>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S142>/LKA_State_Machine'
       *
       * Block description for '<S142>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S296>/Add1' incorporates:
     *  MATLAB Function: '<S294>/MATLABFunction3'
     */
    x20 = rtb_L0_C0_o + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S296>/Gain1' incorporates:
     *  Product: '<S296>/Divide'
     *  Product: '<S296>/Divide1'
     *  Sum: '<S296>/Add1'
     *  Sum: '<S296>/Add5'
     *  Trigonometry: '<S296>/Cos2'
     *  Trigonometry: '<S296>/Sin'
     */
    rtb_Gain1 = ((x20 * cosf(rtb_L0_C1_m)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_m))) * (-1.0F);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S140>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S288>/Gain1' incorporates:
     *  Gain: '<S184>/Gain'
     *  Gain: '<S230>/kph To mps'
     *  Gain: '<S244>/kph to mps'
     *  Gain: '<S245>/kph to mps'
     *  Gain: '<S294>/Gain2'
     *  Gain: '<S301>/kph to mps'
     *  Gain: '<S307>/kph to mps'
     *  Gain: '<S316>/kph to mps'
     *  Gain: '<S317>/kph to mps'
     */
    rtb_Abs_f_tmp = 0.277777791F * rtb_IMAPve_g_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S288>/Divide4' incorporates:
     *  Constant: '<S288>/Constant2'
     *  Constant: '<S288>/Constant3'
     *  Gain: '<S288>/Gain1'
     */
    rtb_Abs_a = (rtb_Abs_f_tmp * 2.0F) * 0.1F;

    /* Sum: '<S288>/Add3' incorporates:
     *  Product: '<S288>/Divide3'
     */
    rtb_phiHdAg_Lft = (rtb_LL_CompHdAg_C * rtb_Abs_a) + rtb_L0_C1_m;

    /* Sum: '<S297>/Add1' incorporates:
     *  MATLAB Function: '<S294>/MATLABFunction4'
     */
    rtb_Add5_n_tmp = rtb_R0_C0_n - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S297>/Add5' incorporates:
     *  Product: '<S297>/Divide'
     *  Product: '<S297>/Divide1'
     *  Sum: '<S297>/Add1'
     *  Trigonometry: '<S297>/Cos2'
     *  Trigonometry: '<S297>/Sin'
     */
    rtb_Add5_n = (rtb_Add5_n_tmp * cosf(rtb_L0_C1_i)) + (rtb_LKA_Veh2CamL_C *
      sinf(rtb_L0_C1_i));

    /* Sum: '<S288>/Add1' incorporates:
     *  Product: '<S288>/Divide5'
     */
    rtb_phiHdAg_Rgt = (rtb_L0_C2 * rtb_Abs_a) + rtb_L0_C1_i;

    /* Switch: '<S656>/Switch2' incorporates:
     *  Constant: '<S656>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_i != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_i;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S656>/Switch2' */

    /* Product: '<S301>/Divide' */
    rtb_Abs_a = rtb_Abs_f_tmp * x10;

    /* Gain: '<S298>/Gain' incorporates:
     *  Gain: '<S313>/Gain'
     *  Gain: '<S314>/Gain'
     *  Gain: '<S315>/Gain'
     */
    rtb_Add_p_tmp = 2.0F * rtb_LL_CompHdAg_C;

    /* Sum: '<S298>/Add' incorporates:
     *  Gain: '<S298>/Gain'
     *  Gain: '<S298>/Gain1'
     *  Product: '<S298>/Product'
     */
    rtb_Add_p = ((6.0F * rtb_L0_C3_dc) * rtb_Abs_a) + rtb_Add_p_tmp;

    /* Gain: '<S299>/Gain' incorporates:
     *  Gain: '<S310>/Gain'
     *  Gain: '<S311>/Gain'
     *  Gain: '<S312>/Gain'
     */
    rtb_Add_o_tmp = 2.0F * rtb_L0_C2;

    /* Sum: '<S299>/Add' incorporates:
     *  Gain: '<S299>/Gain'
     *  Gain: '<S299>/Gain1'
     *  Product: '<S299>/Product'
     */
    rtb_Add_o = ((6.0F * rtb_L0_C3) * rtb_Abs_a) + rtb_Add_o_tmp;

    /* Product: '<S288>/Divide1' incorporates:
     *  Gain: '<S288>/Gain1'
     */
    rtb_Abs_a = rtb_phiHdAg_Lft * rtb_Abs_f_tmp;

    /* Saturate: '<S294>/Saturation2' incorporates:
     *  UnaryMinus: '<S294>/Unary Minus1'
     */
    if ((-rtb_Abs_a) > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else if ((-rtb_Abs_a) < (-2.0F)) {
      rtb_LKA_Veh2CamL_C = (-2.0F);
    } else {
      rtb_LKA_Veh2CamL_C = -rtb_Abs_a;
    }

    /* End of Saturate: '<S294>/Saturation2' */

    /* MATLAB Function: '<S294>/MATLABFunction' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction': '<S325>:1' */
    /* '<S325>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1 > 0.0F) && (rtb_Gain1 < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S325>:1:3' TTLC = -dvt/vy; */
      rtb_TTLC_d = (-rtb_Gain1) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S325>:1:4' else */
      /* '<S325>:1:5' TTLC = single(3); */
      rtb_TTLC_d = 3.0F;
    }

    /* End of MATLAB Function: '<S294>/MATLABFunction' */

    /* Saturate: '<S294>/Saturation' */
    if (rtb_TTLC_d > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_TTLC_d < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_TTLC_d;
    }

    /* End of Saturate: '<S294>/Saturation' */

    /* Product: '<S288>/Divide2' incorporates:
     *  Gain: '<S288>/Gain1'
     */
    rtb_Abs_pw = rtb_phiHdAg_Rgt * rtb_Abs_f_tmp;

    /* Saturate: '<S294>/Saturation3' */
    if (rtb_Abs_pw > 2.0F) {
      rtb_TTLC_d = 2.0F;
    } else if (rtb_Abs_pw < (-2.0F)) {
      rtb_TTLC_d = (-2.0F);
    } else {
      rtb_TTLC_d = rtb_Abs_pw;
    }

    /* End of Saturate: '<S294>/Saturation3' */

    /* MATLAB Function: '<S294>/MATLABFunction1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction1': '<S326>:1' */
    /* '<S326>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_n > 0.0F) && (rtb_Add5_n < 2.0F)) && (rtb_TTLC_d < 0.0F)) &&
        (rtb_TTLC_d > -1.5F)) {
      /* '<S326>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_n = (-rtb_Add5_n) / rtb_TTLC_d;
    } else {
      /* '<S326>:1:4' else */
      /* '<S326>:1:5' TTLC = single(3); */
      rtb_TTLC_n = 3.0F;
    }

    /* End of MATLAB Function: '<S294>/MATLABFunction1' */

    /* Saturate: '<S294>/Saturation1' */
    if (rtb_TTLC_n > 2.0F) {
      rtb_TTLC_n = 2.0F;
    } else {
      if (rtb_TTLC_n < 0.6F) {
        rtb_TTLC_n = 0.6F;
      }
    }

    /* End of Saturate: '<S294>/Saturation1' */

    /* MATLAB Function: '<S294>/MATLABFunction5' incorporates:
     *  Gain: '<S324>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction5': '<S330>:1' */
    /* '<S330>:1:2' K = 0.09/vx; */
    /* '<S330>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_R0_C2) / (((((((0.09F / rtb_Abs_f_tmp) *
      rtb_Abs_f_tmp) * rtb_Abs_f_tmp) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_m) *
      LKAS_DW.LKA_StrRatio_C_d) * 2.0F);

    /* MATLAB Function: '<S294>/MATLABFunction3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction3': '<S328>:1' */
    /* '<S328>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_LL_CompHdAg_C - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_m > 0.0F) || (rtb_L0_C1_m < 0.0F))) {
      /* '<S328>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_o) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_m;
      if (x10 > 0.0F) {
        /* '<S328>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_Abs_f_tmp;
      } else {
        /* '<S328>:1:9' else */
        /* '<S328>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_m * rtb_L0_C1_m) - ((x10 * 4.0F) * x20);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S328>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S328>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_m)) / x1;

        /* '<S328>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_m) - x20) / x1;

        /* '<S328>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S328>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S328>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S328>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_Abs_f_tmp;
        } else if (x1 > 0.0F) {
          /* '<S328>:1:19' elseif x1>0 */
          /* '<S328>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_Abs_f_tmp;
        } else {
          /* '<S328>:1:21' else */
          /* '<S328>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S328>:1:24' else */
        /* '<S328>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S328>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S294>/MATLABFunction4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction4': '<S329>:1' */
    /* '<S329>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2 - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_i > 0.0F) || (rtb_L0_C1_i < 0.0F))) {
      /* '<S329>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_R0_C0_n) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1_i;
      if (x10 > 0.0F) {
        /* '<S329>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_f_tmp;
      } else {
        /* '<S329>:1:9' else */
        /* '<S329>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_i * rtb_L0_C1_i) - ((x10 * 4.0F) * rtb_Add5_n_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S329>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S329>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_i)) / x1;

        /* '<S329>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_i) - x20) / x1;

        /* '<S329>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S329>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S329>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S329>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_f_tmp;
        } else if (x1 > 0.0F) {
          /* '<S329>:1:19' elseif x1>0 */
          /* '<S329>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_Abs_f_tmp;
        } else {
          /* '<S329>:1:21' else */
          /* '<S329>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S329>:1:24' else */
        /* '<S329>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S329>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S294>/MATLABFunction2' incorporates:
     *  Constant: '<S294>/Constant'
     *  Constant: '<S294>/Constant1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction2': '<S327>:1' */
    /* '<S327>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - 2.0F) / rtb_LftTTLC) <= 0.2F) {
      /* '<S327>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, 2.0F);
    } else {
      /* '<S327>:1:4' else */
      /* '<S327>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S327>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_n - 2.0F) / rtb_TTLC_n) <= 0.2F) {
      /* '<S327>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_n = fminf(rtb_TTLC_n, 2.0F);
    } else {
      /* '<S327>:1:10' else */
      /* '<S327>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S327>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_p) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S327>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S327>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_o) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_n)
           / rtb_TTLC_n) <= 0.7F)) && (rtb_TTLC_n <= 1.95F)) {
      /* '<S327>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_n = (rtb_TTLC_n + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S294>/Saturation7' incorporates:
     *  MATLAB Function: '<S294>/MATLABFunction2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S294>/Saturation7' */

    /* Saturate: '<S294>/Saturation8' incorporates:
     *  MATLAB Function: '<S294>/MATLABFunction2'
     */
    if (rtb_TTLC_n > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_n < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_n;
    }

    /* End of Saturate: '<S294>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S140>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S149>/Subsystem' incorporates:
     *  EnablePort: '<S158>/Enable'
     */
    /* Abs: '<S289>/Abs' incorporates:
     *  MATLAB Function: '<S158>/DriverSwaTrqAdd'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_L0_C0_o);

    /* Abs: '<S289>/Abs1' incorporates:
     *  MATLAB Function: '<S158>/DriverSwaTrqAdd'
     */
    rtb_Add5_n_tmp = fabsf(rtb_R0_C0_n);

    /* End of Outputs for SubSystem: '<S149>/Subsystem' */
    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Sum: '<S289>/Add' incorporates:
     *  Abs: '<S289>/Abs'
     *  Abs: '<S289>/Abs1'
     */
    rtb_LftTTLC = rtb_LKA_Veh2CamW_C + rtb_Add5_n_tmp;

    /* Saturate: '<S289>/Saturation' */
    if (rtb_LftTTLC > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_LftTTLC < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_LftTTLC;
    }

    /* End of Saturate: '<S289>/Saturation' */

    /* If: '<S300>/If' incorporates:
     *  Delay: '<S141>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE_o) == 1) {
      /* Outputs for IfAction SubSystem: '<S300>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S303>/Action Port'
       */
      LKAS_IfActionSubsystem2_k(rtb_Add_p, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S300>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE_o) == 2) {
      /* Outputs for IfAction SubSystem: '<S300>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S302>/Action Port'
       */
      LKAS_IfActionSubsystem2_k(rtb_Add_o, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S300>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S300>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S304>/Action Port'
       */
      /* Gain: '<S304>/Gain' incorporates:
       *  Sum: '<S304>/Add'
       */
      rtb_Merge = (rtb_Add_p + rtb_Add_o) * 0.5F;

      /* End of Outputs for SubSystem: '<S300>/If Action Subsystem3' */
    }

    /* End of If: '<S300>/If' */

    /* Switch: '<S583>/Switch' incorporates:
     *  Constant: '<S660>/Constant'
     *  Constant: '<S661>/Constant'
     *  Gain: '<S660>/Gain'
     *  Gain: '<S661>/Gain'
     *  Sum: '<S660>/Add'
     *  Sum: '<S661>/Add'
     *  Switch: '<S657>/Switch47'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S657>/Switch48' incorporates:
       *  Constant: '<S657>/LLSMConClb3'
       *
       * Block description for '<S657>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S657>/Switch48' */
      rtb_Switch_d = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S657>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S657>/Switch47' incorporates:
         *  Constant: '<S657>/LLSMConClb2'
         *
         * Block description for '<S657>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_d = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S583>/Switch' */

    /* Switch: '<S581>/Switch' incorporates:
     *  Constant: '<S581>/Constant'
     *  Constant: '<S581>/Constant1'
     *  Constant: '<S586>/Constant'
     *  Constant: '<S587>/Constant'
     *  Constant: '<S588>/Constant'
     *  Logic: '<S581>/Logical Operator'
     *  RelationalOperator: '<S586>/Compare'
     *  RelationalOperator: '<S587>/Compare'
     *  RelationalOperator: '<S588>/Compare'
     */
    if (((rtb_IMAPve_d_BCM_HazardLamp >= ((uint8)3U)) || (((sint32)
           (rtb_BCM_Left_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) ||
        (((sint32)(rtb_BCM_Right_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S581>/Switch' */

    /* Sum: '<S581>/Add' incorporates:
     *  Memory: '<S581>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_j;

    /* Saturate: '<S581>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_c = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_c = (-1.0F);
    } else {
      rtb_Saturation_c = rtb_LftTTLC;
    }

    /* End of Saturate: '<S581>/Saturation' */

    /* Abs: '<S575>/Abs1' incorporates:
     *  Abs: '<S480>/Abs1'
     */
    x1 = fabsf(rtb_LaneWidth);
    rtb_Abs1 = x1;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S140>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S573>/Abs' incorporates:
     *  Abs: '<S169>/Abs'
     *  Abs: '<S170>/Abs'
     *  Abs: '<S171>/Abs4'
     *  Abs: '<S478>/Abs'
     *  MATLAB Function: '<S445>/MATLAB Function'
     */
    rtb_TTLC_n = fabsf(rtb_Merge);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC_n;

    /* Switch: '<S657>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S534>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S534>/Unary Minus' incorporates:
       *  Constant: '<S657>/LLSMConClb11'
       *
       * Block description for '<S657>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S657>/Switch53' */

    /* Switch: '<S657>/Switch87' incorporates:
     *  Constant: '<S657>/LLSMConClb8'
     *
     * Block description for '<S657>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S657>/Switch87' */

    /* Switch: '<S657>/Switch49' incorporates:
     *  Constant: '<S657>/LLSMConClb43'
     *
     * Block description for '<S657>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S657>/Switch49' */

    /* Switch: '<S657>/Switch88' incorporates:
     *  Constant: '<S657>/LLSMConClb9'
     *
     * Block description for '<S657>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_LftTTLC = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S657>/Switch88' */

    /* Switch: '<S657>/Switch50' incorporates:
     *  Constant: '<S657>/LLSMConClb10'
     *
     * Block description for '<S657>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      tmp = LKAS_ConstB.DataTypeConversion17;
    } else {
      tmp = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S657>/Switch50' */

    /* Abs: '<S571>/Abs' incorporates:
     *  Abs: '<S476>/Abs'
     *  Sum: '<S571>/Add'
     */
    rtb_LogicalOperator3_c_tmp = fabsf(rtb_L0_C1_m - rtb_L0_C1_i);

    /* Abs: '<S534>/Abs2' incorporates:
     *  Abs: '<S319>/Abs2'
     *  Abs: '<S443>/Abs2'
     */
    rtb_TTLC = fabsf(rtb_R0_C2);

    /* Abs: '<S534>/Abs3' incorporates:
     *  Abs: '<S443>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     *  Inport: '<Root>/IMAPve_g_SW_Angle_Speed'
     */
    rtb_LogicalOperator3_c_tmp_0 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
      ());

    /* Abs: '<S534>/Abs4' incorporates:
     *  Abs: '<S443>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     *  Inport: '<Root>/IMAPve_g_ESC_LatAcc'
     */
    rtb_LogicalOperator3_c_tmp_1 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc());

    /* Abs: '<S534>/Abs1' incorporates:
     *  Abs: '<S444>/Abs'
     *  Abs: '<S445>/Abs'
     */
    rtb_TLft = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S535>/Logical Operator2' incorporates:
     *  Abs: '<S534>/Abs1'
     *  Abs: '<S534>/Abs2'
     *  Abs: '<S534>/Abs3'
     *  Abs: '<S534>/Abs4'
     *  Abs: '<S571>/Abs'
     *  Constant: '<S573>/Constant'
     *  Constant: '<S576>/Constant'
     *  Constant: '<S578>/Constant'
     *  Constant: '<S579>/Constant'
     *  Constant: '<S585>/Constant'
     *  Constant: '<S589>/Constant'
     *  Logic: '<S534>/Logical Operator3'
     *  Logic: '<S540>/FixPt Logical Operator'
     *  Logic: '<S572>/Logical Operator3'
     *  Logic: '<S574>/Logical Operator'
     *  Logic: '<S577>/FixPt Logical Operator'
     *  Logic: '<S580>/FixPt Logical Operator'
     *  Logic: '<S584>/Logical Operator'
     *  Logic: '<S590>/FixPt Logical Operator'
     *  RelationalOperator: '<S534>/Relational Operator'
     *  RelationalOperator: '<S534>/Relational Operator1'
     *  RelationalOperator: '<S534>/Relational Operator2'
     *  RelationalOperator: '<S534>/Relational Operator3'
     *  RelationalOperator: '<S540>/Lower Test'
     *  RelationalOperator: '<S540>/Upper Test'
     *  RelationalOperator: '<S576>/Compare'
     *  RelationalOperator: '<S577>/Lower Test'
     *  RelationalOperator: '<S577>/Upper Test'
     *  RelationalOperator: '<S578>/Compare'
     *  RelationalOperator: '<S579>/Compare'
     *  RelationalOperator: '<S580>/Lower Test'
     *  RelationalOperator: '<S580>/Upper Test'
     *  RelationalOperator: '<S585>/Compare'
     *  RelationalOperator: '<S589>/Compare'
     *  RelationalOperator: '<S590>/Lower Test'
     *  RelationalOperator: '<S590>/Upper Test'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_LogicalOperator3_b5 = ((((((rtb_Gain_j <= rtb_IMAPve_g_ESC_VehSpd) &&
      (rtb_IMAPve_g_ESC_VehSpd <= rtb_Switch_d)) && (rtb_Saturation_c <= 0.0F)) &&
      (rtb_TCU_ActualGear == ((uint8)3U))) && (((((rtb_L0_Q > ((uint8)2U)) &&
      (rtb_R0_Q > ((uint8)2U))) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) &&
      (rtb_Abs1 <= rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) &&
      (rtb_Abs <= rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) &&
      (rtb_LogicalOperator3_c_tmp <= 0.025F))) && (((((rtb_TTLC < x10) &&
      (rtb_LogicalOperator3_c_tmp_0 < x20)) && (rtb_TLft < rtb_LftTTLC)) &&
      (rtb_LogicalOperator3_c_tmp_1 < tmp)) && ((rtb_UnaryMinus <
      rtb_IMAPve_g_ESC_LonAcc) && (rtb_IMAPve_g_ESC_LonAcc <
      rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* MATLAB Function: '<S568>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_LKA_EarliestWarnLine_C, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient);

    /* Product: '<S568>/Multiply' */
    rtb_Multiply = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_ThresDet_coefficient;

    /* Switch: '<S570>/Switch' incorporates:
     *  Constant: '<S568>/Constant'
     *  RelationalOperator: '<S570>/UpperRelop'
     */
    if (rtb_Multiply < 0.0F) {
      rtb_Switch_i = 0.0F;
    } else {
      rtb_Switch_i = rtb_Multiply;
    }

    /* End of Switch: '<S570>/Switch' */

    /* Switch: '<S570>/Switch2' incorporates:
     *  RelationalOperator: '<S570>/LowerRelop1'
     */
    if (rtb_Multiply > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_f = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_f = rtb_Switch_i;
    }

    /* End of Switch: '<S570>/Switch2' */

    /* Abs: '<S555>/Abs1' incorporates:
     *  Abs: '<S466>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S555>/Abs2' incorporates:
     *  Abs: '<S466>/Abs1'
     */
    x20 = fabsf(rtb_TTLC_d);

    /* If: '<S535>/If1' incorporates:
     *  Abs: '<S555>/Abs1'
     *  Abs: '<S555>/Abs2'
     *  Constant: '<S542>/Constant'
     *  Constant: '<S557>/Constant'
     *  Constant: '<S558>/Constant'
     *  Constant: '<S563>/Constant'
     *  Constant: '<S564>/Constant'
     *  Constant: '<S565>/Constant'
     *  Constant: '<S566>/Constant'
     *  DataTypeConversion: '<S535>/Cast To Single'
     *  Logic: '<S535>/Logical Operator1'
     *  Logic: '<S552>/Logical Operator'
     *  Logic: '<S554>/Logical Operator'
     *  Logic: '<S555>/Logical Operator'
     *  Logic: '<S556>/Logical Operator'
     *  RelationalOperator: '<S555>/Relational Operator2'
     *  RelationalOperator: '<S555>/Relational Operator3'
     *  RelationalOperator: '<S556>/Relational Operator1'
     *  RelationalOperator: '<S556>/Relational Operator2'
     *  RelationalOperator: '<S557>/Compare'
     *  RelationalOperator: '<S558>/Compare'
     *  RelationalOperator: '<S563>/Compare'
     *  RelationalOperator: '<S564>/Compare'
     *  RelationalOperator: '<S565>/Compare'
     *  RelationalOperator: '<S566>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_LogicalOperator3_b5 &&
         ((((LKAS_DW.LKA_Mode == ((uint8)2U)) && (((sint32)
              (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
                (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) ? 1 : 0)) ==
             ((sint32)(true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1 >= rtb_Switch2_f) &&
              (rtb_Add5_n >= rtb_Switch2_f)) ? 1 : 0)) == ((sint32)(true ? 1 : 0))))))
    {
      /* Outputs for IfAction SubSystem: '<S535>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S542>/Action Port'
       */
      LKAS_DW.Merge1_a = true;

      /* End of Outputs for SubSystem: '<S535>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S535>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S544>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_a);

      /* End of Outputs for SubSystem: '<S535>/If Action Subsystem4' */
    }

    /* End of If: '<S535>/If1' */

    /* Switch: '<S526>/Switch' incorporates:
     *  Constant: '<S658>/Constant'
     *  Constant: '<S663>/Constant'
     *  Gain: '<S658>/Gain'
     *  Gain: '<S663>/Gain'
     *  Sum: '<S658>/Add'
     *  Sum: '<S663>/Add'
     *  Switch: '<S657>/Switch67'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S657>/Switch80' incorporates:
       *  Constant: '<S657>/LLSMConClb21'
       *
       * Block description for '<S657>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_LftTTLC = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S657>/Switch80' */
      rtb_Switch_h = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S657>/Switch67' */
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S657>/Switch67' incorporates:
         *  Constant: '<S657>/LLSMConClb20'
         *
         * Block description for '<S657>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_LftTTLC = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_h = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S526>/Switch' */

    /* Logic: '<S526>/Logical Operator' incorporates:
     *  Logic: '<S533>/FixPt Logical Operator'
     *  RelationalOperator: '<S533>/Lower Test'
     *  RelationalOperator: '<S533>/Upper Test'
     */
    rtb_LKA_Main_Switch = ((rtb_Gain_g >= rtb_IMAPve_g_ESC_VehSpd) ||
      (rtb_IMAPve_g_ESC_VehSpd >= rtb_Switch_h));

    /* Logic: '<S524>/Logical Operator' incorporates:
     *  Logic: '<S346>/Logical Operator6'
     */
    rtb_LL_SingleLane_Disable_Swt = !rtb_LL_SingleLane_Disable_Swt;

    /* Switch: '<S524>/Switch' incorporates:
     *  Constant: '<S524>/Constant'
     *  Constant: '<S524>/Constant1'
     *  Constant: '<S529>/Constant'
     *  Constant: '<S530>/Constant'
     *  Constant: '<S531>/Constant'
     *  Delay: '<S142>/Delay1'
     *  Logic: '<S524>/Logical Operator'
     *  Logic: '<S524>/Logical Operator1'
     *  Logic: '<S524>/Logical Operator2'
     *  Logic: '<S524>/Logical Operator3'
     *  Logic: '<S524>/Logical Operator4'
     *  Logic: '<S524>/Logical Operator5'
     *  RelationalOperator: '<S529>/Compare'
     *  RelationalOperator: '<S530>/Compare'
     *  RelationalOperator: '<S531>/Compare'
     */
    if (((((rtb_IMAPve_d_BCM_HazardLamp >= ((uint8)3U)) || (rtb_BCM_Left_Light &&
            rtb_LL_SingleLane_Disable_Swt)) || (rtb_BCM_Right_Light &&
           rtb_LL_SingleLane_Disable_Swt)) || (rtb_BCM_Left_Light &&
          (LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)))) || (rtb_BCM_Right_Light &&
         (LKAS_DW.Delay1_3_DSTATE == ((uint8)5U)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S524>/Switch' */

    /* Sum: '<S524>/Add' incorporates:
     *  Memory: '<S524>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_c;

    /* Saturate: '<S524>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_f = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_f = (-1.0F);
    } else {
      rtb_Saturation_f = rtb_LftTTLC;
    }

    /* End of Saturate: '<S524>/Saturation' */

    /* RelationalOperator: '<S528>/Compare' incorporates:
     *  Constant: '<S528>/Constant'
     */
    rtb_Compare_mw = (rtb_Saturation_f > 1.0F);

    /* RelationalOperator: '<S532>/Compare' incorporates:
     *  Constant: '<S532>/Constant'
     */
    rtb_Compare_ho = (rtb_TCU_ActualGear != ((uint8)3U));

    /* Logic: '<S479>/Logical Operator' incorporates:
     *  Constant: '<S483>/Constant'
     *  Constant: '<S484>/Constant'
     *  RelationalOperator: '<S483>/Compare'
     *  RelationalOperator: '<S484>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_LogicalOperator_iv = ((rtb_L0_Q < ((uint8)3U)) && (rtb_R0_Q < ((uint8)3U)));

    /* Abs: '<S480>/Abs1' */
    rtb_Abs1_m = x1;

    /* RelationalOperator: '<S485>/Compare' incorporates:
     *  Constant: '<S485>/Constant'
     *  Logic: '<S486>/FixPt Logical Operator'
     *  RelationalOperator: '<S486>/Lower Test'
     *  RelationalOperator: '<S486>/Upper Test'
     */
    rtb_Compare_bp = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_m) &&
      (rtb_Abs1_m <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S478>/Abs' */
    rtb_Abs_i = rtb_TTLC_n;

    /* Logic: '<S478>/Logical Operator' incorporates:
     *  Constant: '<S478>/Constant'
     *  Logic: '<S482>/FixPt Logical Operator'
     *  RelationalOperator: '<S482>/Lower Test'
     *  RelationalOperator: '<S482>/Upper Test'
     */
    rtb_LogicalOperator_ix = ((0.0F > rtb_Abs_i) || (rtb_Abs_i >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S481>/Compare' incorporates:
     *  Constant: '<S481>/Constant'
     */
    rtb_Compare_ab = (rtb_LogicalOperator3_c_tmp > 0.04F);

    /* Switch: '<S657>/Switch72' incorporates:
     *  Constant: '<S657>/LLSMConClb26'
     *
     * Block description for '<S657>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S657>/Switch72' */

    /* RelationalOperator: '<S443>/Relational Operator1' */
    rtb_phiSWA_Thres = (rtb_TTLC >= rtb_LftTTLC);

    /* Switch: '<S657>/Switch74' incorporates:
     *  Constant: '<S657>/LLSMConClb28'
     *
     * Block description for '<S657>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S657>/Switch74' */

    /* RelationalOperator: '<S443>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_LogicalOperator3_c_tmp_0 >= rtb_LftTTLC);

    /* Switch: '<S657>/Switch79' incorporates:
     *  Constant: '<S657>/LLSMConClb29'
     *
     * Block description for '<S657>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_LftTTLC = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S657>/Switch79' */

    /* Logic: '<S443>/Logical Operator1' incorporates:
     *  Constant: '<S446>/Constant'
     *  RelationalOperator: '<S443>/Relational Operator3'
     *  RelationalOperator: '<S446>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_c_tmp_1 >= rtb_LftTTLC) &&
                       (rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)));

    /* Switch: '<S657>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S443>/Unary Minus' */
      rtb_UnaryMinus_n = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S443>/Unary Minus' incorporates:
       *  Constant: '<S657>/LLSMConClb30'
       *
       * Block description for '<S657>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_n = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S657>/Switch61' */

    /* RelationalOperator: '<S447>/Compare' incorporates:
     *  Constant: '<S447>/Constant'
     *  Logic: '<S448>/FixPt Logical Operator'
     *  RelationalOperator: '<S448>/Lower Test'
     *  RelationalOperator: '<S448>/Upper Test'
     */
    rtb_Compare_p1 = (((sint32)(((rtb_UnaryMinus_n < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                      ((sint32)(false ? 1 : 0)));

    /* Switch: '<S444>/Switch' incorporates:
     *  Constant: '<S449>/Constant'
     *  Constant: '<S657>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
     *  RelationalOperator: '<S449>/Compare'
     *  Switch: '<S657>/Switch38'
     *
     * Block description for '<S657>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
     *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      /* Switch: '<S657>/Switch44' incorporates:
       *  Constant: '<S657>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
       *
       * Block description for '<S657>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
       *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
       */
      if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
        rtb_TTLC_d = LKAS_ConstB.DataTypeConversion8;
      } else {
        rtb_TTLC_d = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
      }

      /* End of Switch: '<S657>/Switch44' */
    } else if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
      /* Switch: '<S657>/Switch38' */
      rtb_TTLC_d = LKAS_ConstB.DataTypeConversion6;
    } else {
      rtb_TTLC_d = LL_RlsDet_tiTrqChkT_DISABLE;
    }

    /* End of Switch: '<S444>/Switch' */

    /* Outputs for Enabled SubSystem: '<S444>/ExitCount' incorporates:
     *  EnablePort: '<S452>/Enable'
     */
    /* RelationalOperator: '<S444>/Relational Operator' */
    if (rtb_TLft <= rtb_TTLC_d) {
      if (!LKAS_DW.ExitCount_MODE) {
        /* InitializeConditions for Memory: '<S452>/Memory' */
        LKAS_DW.Memory_PreviousInput_no = 0.0F;
        LKAS_DW.ExitCount_MODE = true;
      }

      /* Sum: '<S452>/Add' incorporates:
       *  Constant: '<S450>/Constant'
       *  Constant: '<S451>/Constant'
       *  Logic: '<S444>/Logical Operator2'
       *  Memory: '<S452>/Memory'
       *  Product: '<S444>/Divide'
       *  RelationalOperator: '<S450>/Compare'
       *  RelationalOperator: '<S451>/Compare'
       */
      rtb_LKA_Veh2CamL_C = (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
        (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? rtb_LKA_SampleTime : 0.0F)
        + LKAS_DW.Memory_PreviousInput_no;

      /* Saturate: '<S452>/Saturation' */
      if (rtb_LKA_Veh2CamL_C > 60.0F) {
        rtb_LKA_Veh2CamL_C = 60.0F;
      } else {
        if (rtb_LKA_Veh2CamL_C < 0.0F) {
          rtb_LKA_Veh2CamL_C = 0.0F;
        }
      }

      /* End of Saturate: '<S452>/Saturation' */

      /* Switch: '<S657>/Switch3' incorporates:
       *  Constant: '<S657>/LL_RlsDet_tiTDelTime_DISABLE=3'
       *
       * Block description for '<S657>/LL_RlsDet_tiTDelTime_DISABLE=3':
       *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
       */
      if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion3;
      } else {
        rtb_LftTTLC = LL_HandsOff_ExitTime;
      }

      /* End of Switch: '<S657>/Switch3' */

      /* RelationalOperator: '<S452>/Relational Operator' */
      LKAS_DW.RelationalOperator_f = (rtb_LKA_Veh2CamL_C >= rtb_LftTTLC);

      /* Update for Memory: '<S452>/Memory' */
      LKAS_DW.Memory_PreviousInput_no = rtb_LKA_Veh2CamL_C;
    } else {
      if (LKAS_DW.ExitCount_MODE) {
        /* Disable for Outport: '<S452>/Out' */
        LKAS_DW.RelationalOperator_f = false;
        LKAS_DW.ExitCount_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S444>/Relational Operator' */
    /* End of Outputs for SubSystem: '<S444>/ExitCount' */

    /* Saturate: '<S445>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S453>:1' */
    /* '<S453>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S453>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S453>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S453>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_IMAPve_g_ESC_VehSpd > 80.0F) {
      rtb_LftTTLC = 80.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      rtb_LftTTLC = 60.0F;
    } else {
      rtb_LftTTLC = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S445>/Saturation' */

    /* MATLAB Function: '<S445>/MATLAB Function' */
    if (rtb_TLft >= fminf(fmaxf(1.5F, ((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
           - ((rtb_LftTTLC / 180.0F) * rtb_LL_MAX_DRIVER_TORQUE_DISABL)) +
          (rtb_TTLC_n / 0.005F)), 2.75F)) {
      /* Outputs for Enabled SubSystem: '<S445>/Sum Condition1' incorporates:
       *  EnablePort: '<S454>/state = reset'
       */
      /* '<S453>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_i) {
        /* InitializeConditions for Memory: '<S454>/Memory' */
        LKAS_DW.Memory_PreviousInput_k = 0.0F;
        LKAS_DW.SumCondition1_MODE_i = true;
      }

      /* Sum: '<S454>/Add1' incorporates:
       *  Memory: '<S454>/Memory'
       */
      rtb_LKA_Veh2CamL_C = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_k;

      /* Saturate: '<S454>/Saturation' */
      if (rtb_LKA_Veh2CamL_C > 5000.0F) {
        rtb_LKA_Veh2CamL_C = 5000.0F;
      } else {
        if (rtb_LKA_Veh2CamL_C < 0.0F) {
          rtb_LKA_Veh2CamL_C = 0.0F;
        }
      }

      /* End of Saturate: '<S454>/Saturation' */
      /* End of Outputs for SubSystem: '<S445>/Sum Condition1' */

      /* Switch: '<S657>/Switch65' incorporates:
       *  Constant: '<S657>/LLSMConClb34'
       *
       * Block description for '<S657>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_LftTTLC = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S657>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S445>/Sum Condition1' incorporates:
       *  EnablePort: '<S454>/state = reset'
       */
      /* RelationalOperator: '<S454>/Relational Operator' */
      LKAS_DW.RelationalOperator_n = (rtb_LKA_Veh2CamL_C >= rtb_LftTTLC);

      /* Update for Memory: '<S454>/Memory' */
      LKAS_DW.Memory_PreviousInput_k = rtb_LKA_Veh2CamL_C;

      /* End of Outputs for SubSystem: '<S445>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S445>/Sum Condition1' incorporates:
       *  EnablePort: '<S454>/state = reset'
       */
      /* '<S453>:1:7' else */
      /* '<S453>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S454>/Out' */
        LKAS_DW.RelationalOperator_n = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Outputs for SubSystem: '<S445>/Sum Condition1' */
    }

    /* RelationalOperator: '<S460>/Compare' incorporates:
     *  Constant: '<S460>/Constant'
     */
    rtb_Compare_iz = (((sint32)(LKAS_DW.RelationalOperator_n ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S455>/Unit Delay' */
    rtb_UnitDelay_m = LKAS_DW.UnitDelay_DSTATE_i;

    /* If: '<S455>/If' incorporates:
     *  Constant: '<S457>/Constant'
     *  RelationalOperator: '<S456>/FixPt Relational Operator'
     *  UnitDelay: '<S456>/Delay Input1'
     *
     * Block description for '<S456>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if (((sint32)(rtb_Compare_iz ? 1 : 0)) > ((sint32)
         (LKAS_DW.DelayInput1_DSTATE ? 1 : 0))) {
      /* Outputs for IfAction SubSystem: '<S455>/If Action Subsystem' incorporates:
       *  ActionPort: '<S457>/Action Port'
       */
      rtb_Merge_i = true;

      /* End of Outputs for SubSystem: '<S455>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S455>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S458>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_m, &rtb_Merge_i);

      /* End of Outputs for SubSystem: '<S455>/If Action Subsystem3' */
    }

    /* End of If: '<S455>/If' */

    /* Outputs for Enabled SubSystem: '<S455>/Sum Condition1' incorporates:
     *  EnablePort: '<S459>/state = reset'
     */
    if (rtb_Merge_i) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S459>/Memory' */
        LKAS_DW.Memory_PreviousInput_p = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S459>/Add1' incorporates:
       *  Memory: '<S459>/Memory'
       */
      rtb_LKA_Veh2CamL_C = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_p;

      /* Saturate: '<S459>/Saturation' */
      if (rtb_LKA_Veh2CamL_C > 10.0F) {
        rtb_LKA_Veh2CamL_C = 10.0F;
      } else {
        if (rtb_LKA_Veh2CamL_C < 0.0F) {
          rtb_LKA_Veh2CamL_C = 0.0F;
        }
      }

      /* End of Saturate: '<S459>/Saturation' */

      /* RelationalOperator: '<S459>/Relational Operator' */
      LKAS_DW.RelationalOperator_a = (rtb_LKA_Veh2CamL_C <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S459>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = rtb_LKA_Veh2CamL_C;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S459>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S455>/Sum Condition1' */

    /* Logic: '<S455>/Logical Operator' */
    rtb_RelationalOperator_pw = ((LKAS_DW.RelationalOperator_n) ||
      (LKAS_DW.RelationalOperator_a));

    /* Logic: '<S429>/Logical Operator2' incorporates:
     *  Logic: '<S442>/Logical Operator1'
     *  Logic: '<S443>/Logical Operator'
     *  Logic: '<S477>/Logical Operator3'
     *  Logic: '<S527>/Logical Operator3'
     */
    rtb_RelationalOperator_b = ((((rtb_LKA_Main_Switch || rtb_Compare_mw) ||
      rtb_Compare_ho) || (((rtb_LogicalOperator_iv || rtb_Compare_bp) ||
      rtb_LogicalOperator_ix) || rtb_Compare_ab)) || (((((rtb_phiSWA_Thres ||
      rtb_dphiSWARate_Thres) || rtb_aLAcc_Thres) || rtb_Compare_p1) ||
      (LKAS_DW.RelationalOperator_f)) || rtb_RelationalOperator_pw));

    /* Logic: '<S466>/Logical Operator' incorporates:
     *  RelationalOperator: '<S466>/Relational Operator1'
     *  RelationalOperator: '<S466>/Relational Operator2'
     */
    rtb_LogicalOperator_ol = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S467>/Logical Operator' incorporates:
     *  RelationalOperator: '<S467>/Relational Operator1'
     *  RelationalOperator: '<S467>/Relational Operator2'
     */
    rtb_LogicalOperator_m = ((rtb_Gain1 <= rtb_Abs_k) || (rtb_Add5_n <=
      rtb_Abs_k));

    /* If: '<S429>/If2' incorporates:
     *  Constant: '<S438>/Constant'
     *  Constant: '<S472>/Constant'
     *  Constant: '<S473>/Constant'
     *  Constant: '<S475>/Constant'
     *  DataTypeConversion: '<S429>/Cast To Single'
     *  Logic: '<S429>/Logical Operator1'
     *  Logic: '<S465>/Logical Operator'
     *  Logic: '<S465>/Logical Operator1'
     *  RelationalOperator: '<S472>/Compare'
     *  RelationalOperator: '<S473>/Compare'
     *  RelationalOperator: '<S475>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_RelationalOperator_b ||
         ((LKAS_DW.LKA_Mode == ((uint8)2U)) && ((rtb_LogicalOperator_ol == true)
           || (rtb_LogicalOperator_m == true))))) {
      /* Outputs for IfAction SubSystem: '<S429>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S438>/Action Port'
       */
      LKAS_DW.Merge2 = true;

      /* End of Outputs for SubSystem: '<S429>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S429>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S440>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2);

      /* End of Outputs for SubSystem: '<S429>/If Action Subsystem3' */
    }

    /* End of If: '<S429>/If2' */

    /* If: '<S366>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_pw >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S366>/Ph1SWA' incorporates:
       *  ActionPort: '<S370>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S366>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_pw <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S366>/Ph2SWA' incorporates:
       *  ActionPort: '<S371>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S366>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S366>/Ph3SWA' incorporates:
       *  ActionPort: '<S372>/Action Port'
       */
      LKAS_Ph3SWA_f(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S366>/Ph3SWA' */
    }

    /* End of If: '<S366>/If' */

    /* Saturate: '<S344>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = (-2.0F);
    } else {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_Gain1;
    }

    /* End of Saturate: '<S344>/Saturation5' */

    /* MATLAB Function: '<S353>/MATLAB Function' incorporates:
     *  MATLAB Function: '<S389>/MATLAB Function'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S356>:1' */
    /* '<S356>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S356>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S356>:1:5' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S356>:1:6' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S356>:1:7' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    x20 = (2.0F * rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth;
    x20 = fminf(fmaxf(0.0F, (fminf(fmaxf(x20, rtb_LaneWidth), (6.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth) - x20) / (4.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW)), 1.0F);

    /* Product: '<S353>/Divide5' incorporates:
     *  MATLAB Function: '<S353>/MATLAB Function'
     */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S353>/Divide6' incorporates:
     *  MATLAB Function: '<S353>/MATLAB Function'
     */
    rtb_TLft = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S368>/Abs' incorporates:
     *  Abs: '<S359>/Abs'
     *  Abs: '<S395>/Abs'
     */
    x1 = fabsf(rtb_Abs_a);

    /* Product: '<S368>/Divide' incorporates:
     *  Abs: '<S368>/Abs'
     */
    rtb_Divide_b = rtb_TLft * x1;

    /* Product: '<S353>/Divide4' incorporates:
     *  MATLAB Function: '<S353>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S373>/Switch' incorporates:
     *  RelationalOperator: '<S373>/UpperRelop'
     */
    if (rtb_Divide_b < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_c = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_c = rtb_Divide_b;
    }

    /* End of Switch: '<S373>/Switch' */

    /* Switch: '<S373>/Switch2' incorporates:
     *  RelationalOperator: '<S373>/LowerRelop1'
     */
    if (rtb_Divide_b > rtb_LftTTLC) {
      rtb_Switch2_o = rtb_LftTTLC;
    } else {
      rtb_Switch2_o = rtb_Switch_c;
    }

    /* End of Switch: '<S373>/Switch2' */

    /* Saturate: '<S344>/Saturation1' */
    if (rtb_Add5_n > 2.0F) {
      rtb_TTLC_d = 2.0F;
    } else if (rtb_Add5_n < (-2.0F)) {
      rtb_TTLC_d = (-2.0F);
    } else {
      rtb_TTLC_d = rtb_Add5_n;
    }

    /* End of Saturate: '<S344>/Saturation1' */

    /* Abs: '<S369>/Abs' incorporates:
     *  Abs: '<S360>/Abs'
     *  Abs: '<S396>/Abs'
     */
    rtb_LogicalOperator3_c_tmp = fabsf(rtb_Abs_pw);

    /* Product: '<S369>/Divide' incorporates:
     *  Abs: '<S369>/Abs'
     */
    rtb_Divide_ba = rtb_TLft * rtb_LogicalOperator3_c_tmp;

    /* Switch: '<S374>/Switch' incorporates:
     *  RelationalOperator: '<S374>/UpperRelop'
     */
    if (rtb_Divide_ba < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_n = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_n = rtb_Divide_ba;
    }

    /* End of Switch: '<S374>/Switch' */

    /* Switch: '<S374>/Switch2' incorporates:
     *  RelationalOperator: '<S374>/LowerRelop1'
     */
    if (rtb_Divide_ba > rtb_LftTTLC) {
      rtb_Switch2_n = rtb_LftTTLC;
    } else {
      rtb_Switch2_n = rtb_Switch_n;
    }

    /* End of Switch: '<S374>/Switch2' */

    /* Switch: '<S367>/Switch3' incorporates:
     *  Constant: '<S369>/Constant'
     *  Gain: '<S367>/Gain1'
     *  Logic: '<S369>/Logical Operator'
     *  RelationalOperator: '<S369>/Relational Operator1'
     *  RelationalOperator: '<S369>/Relational Operator2'
     */
    if (rtb_Merge1 >= 0.0F) {
      /* Switch: '<S367>/Switch2' incorporates:
       *  Constant: '<S367>/Constant2'
       *  Constant: '<S368>/Constant'
       *  DataTypeConversion: '<S367>/Cast To Single'
       *  Logic: '<S368>/Logical Operator'
       *  RelationalOperator: '<S368>/Relational Operator1'
       *  RelationalOperator: '<S368>/Relational Operator3'
       */
      if (rtb_Merge1 > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) &&
          (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <= rtb_Switch2_o)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S367>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F < rtb_TTLC_d) &&
        (rtb_TTLC_d <= rtb_Switch2_n)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S367>/Switch3' */

    /* DataTypeConversion: '<S346>/Data Type Conversion' incorporates:
     *  Constant: '<S377>/Constant'
     *  Constant: '<S378>/Constant'
     *  Constant: '<S379>/Constant'
     *  Constant: '<S380>/Constant'
     *  Logic: '<S346>/Logical Operator'
     *  Logic: '<S346>/Logical Operator1'
     *  Logic: '<S346>/Logical Operator2'
     *  Logic: '<S346>/Logical Operator3'
     *  Logic: '<S346>/Logical Operator4'
     *  Logic: '<S346>/Logical Operator5'
     *  Logic: '<S346>/Logical Operator7'
     *  RelationalOperator: '<S377>/Compare'
     *  RelationalOperator: '<S378>/Compare'
     *  RelationalOperator: '<S379>/Compare'
     *  RelationalOperator: '<S380>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((((rtb_LL_SingleLane_Disable_Swt || (
      !rtb_BCM_Right_Light)) && (rtb_R0_Q > ((uint8)2U))) && (rtb_TCU_ActualGear
      == ((uint8)2U))) || (((rtb_LL_SingleLane_Disable_Swt ||
      (!rtb_BCM_Left_Light)) && (rtb_TCU_ActualGear == ((uint8)1U))) &&
      (rtb_L0_Q > ((uint8)2U)))) ? 1 : 0);

    /* DataTypeConversion: '<S345>/Data Type Conversion' incorporates:
     *  Constant: '<S375>/Constant'
     *  Constant: '<S376>/Constant'
     *  Logic: '<S345>/Logical Operator'
     *  RelationalOperator: '<S375>/Compare'
     *  RelationalOperator: '<S376>/Compare'
     */
    rtb_CastToSingle3 = (uint8)(((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
      (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? 1 : 0);

    /* If: '<S343>/If1' incorporates:
     *  Constant: '<S348>/Constant'
     *  Constant: '<S351>/Constant'
     *  Constant: '<S352>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)rtb_TCU_ActualGear) ==
           1)) && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S343>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S351>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S343>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)
        rtb_TCU_ActualGear) == 2)) && (((sint32)rtb_CastToSingle3) == 1)) &&
               (((sint32)rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S343>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S352>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S343>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S343>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S348>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S343>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S343>/If1' */

    /* If: '<S403>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_pw >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S403>/Ph1SWA' incorporates:
       *  ActionPort: '<S407>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_f);

      /* End of Outputs for SubSystem: '<S403>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_Abs_pw <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S403>/Ph2SWA' incorporates:
       *  ActionPort: '<S408>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_f);

      /* End of Outputs for SubSystem: '<S403>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S403>/Ph3SWA' incorporates:
       *  ActionPort: '<S409>/Action Port'
       */
      LKAS_Ph3SWA_f(&rtb_Merge1_f);

      /* End of Outputs for SubSystem: '<S403>/Ph3SWA' */
    }

    /* End of If: '<S403>/If' */

    /* Saturate: '<S382>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_TLft = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_TLft = (-2.0F);
    } else {
      rtb_TLft = rtb_Gain1;
    }

    /* End of Saturate: '<S382>/Saturation5' */

    /* Product: '<S389>/Divide5' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S392>:1' */
    /* '<S392>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S392>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S392>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S392>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S392>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_LL_ThresDet_lDvtThresUprLKA *= x20;

    /* Product: '<S389>/Divide6' */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S405>/Divide' incorporates:
     *  Abs: '<S405>/Abs'
     */
    rtb_Divide_d = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_a);

    /* Product: '<S389>/Divide4' */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S410>/Switch' incorporates:
     *  RelationalOperator: '<S410>/UpperRelop'
     */
    if (rtb_Divide_d < rtb_LftTTLC) {
      rtb_Switch_gw = rtb_LftTTLC;
    } else {
      rtb_Switch_gw = rtb_Divide_d;
    }

    /* End of Switch: '<S410>/Switch' */

    /* Switch: '<S410>/Switch2' incorporates:
     *  RelationalOperator: '<S410>/LowerRelop1'
     */
    if (rtb_Divide_d > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_d = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_d = rtb_Switch_gw;
    }

    /* End of Switch: '<S410>/Switch2' */

    /* Saturate: '<S382>/Saturation1' */
    if (rtb_Add5_n > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_n < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_n;
    }

    /* End of Saturate: '<S382>/Saturation1' */

    /* Product: '<S406>/Divide' incorporates:
     *  Abs: '<S406>/Abs'
     */
    rtb_Divide_f = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_pw);

    /* Switch: '<S411>/Switch' incorporates:
     *  RelationalOperator: '<S411>/UpperRelop'
     */
    if (rtb_Divide_f < rtb_LftTTLC) {
      rtb_Switch_gi = rtb_LftTTLC;
    } else {
      rtb_Switch_gi = rtb_Divide_f;
    }

    /* End of Switch: '<S411>/Switch' */

    /* Switch: '<S411>/Switch2' incorporates:
     *  RelationalOperator: '<S411>/LowerRelop1'
     */
    if (rtb_Divide_f > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_fg = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_fg = rtb_Switch_gi;
    }

    /* End of Switch: '<S411>/Switch2' */

    /* Switch: '<S404>/Switch3' incorporates:
     *  Constant: '<S406>/Constant'
     *  Gain: '<S404>/Gain1'
     *  Logic: '<S406>/Logical Operator'
     *  RelationalOperator: '<S406>/Relational Operator1'
     *  RelationalOperator: '<S406>/Relational Operator2'
     */
    if (rtb_Merge1_f >= 0.0F) {
      /* Switch: '<S404>/Switch2' incorporates:
       *  Constant: '<S404>/Constant2'
       *  Constant: '<S405>/Constant'
       *  DataTypeConversion: '<S404>/Cast To Single'
       *  Logic: '<S405>/Logical Operator'
       *  RelationalOperator: '<S405>/Relational Operator1'
       *  RelationalOperator: '<S405>/Relational Operator3'
       */
      if (rtb_Merge1_f > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_TLft) && (rtb_TLft <=
          rtb_Switch2_d)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S404>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F <
        rtb_LL_ThresDet_lDvtThresLwrLKA) && (rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_fg)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S404>/Switch3' */

    /* MATLAB Function: '<S383>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S415>:1' */
    /* '<S415>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S415>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S415>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S415>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_IMAPve_g_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge), 0.005F)) / 0.005F);

    /* '<S415>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_TCU_ActualGear) == 2) && (rtb_IMAPve_g_EPS_SW_Trq >
          rtb_LL_MAX_DRIVER_TORQUE_DISABL)) || ((((sint32)rtb_TCU_ActualGear) ==
          1) && (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL))))
    {
      /* Outputs for Enabled SubSystem: '<S383>/Count 0.2s' incorporates:
       *  EnablePort: '<S414>/Enable'
       */
      /* '<S415>:1:7' stDvrTkConFlg=1; */
      /* '<S415>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S415>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S414>/Memory' */
        LKAS_DW.Memory_PreviousInput_m5 = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S414>/Add' incorporates:
       *  Memory: '<S414>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_m5;

      /* Saturate: '<S414>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S414>/Saturation' */
      /* End of Outputs for SubSystem: '<S383>/Count 0.2s' */

      /* Switch: '<S657>/Switch16' incorporates:
       *  Constant: '<S657>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S657>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S657>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S383>/Count 0.2s' incorporates:
       *  EnablePort: '<S414>/Enable'
       */
      /* RelationalOperator: '<S414>/Relational Operator' */
      LKAS_DW.RelationalOperator_l1 = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S414>/Memory' */
      LKAS_DW.Memory_PreviousInput_m5 = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S383>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S383>/Count 0.2s' incorporates:
       *  EnablePort: '<S414>/Enable'
       */
      /* '<S415>:1:10' else */
      /* '<S415>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S414>/Out' */
        LKAS_DW.RelationalOperator_l1 = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S383>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S383>/MATLAB Function' */

    /* RelationalOperator: '<S424>/Compare' incorporates:
     *  Constant: '<S424>/Constant'
     */
    rtb_Compare_km = (((sint32)(LKAS_DW.RelationalOperator_l1 ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S416>/Unit Delay' */
    rtb_UnitDelay_h = LKAS_DW.UnitDelay_DSTATE_gu;

    /* RelationalOperator: '<S423>/Compare' incorporates:
     *  Constant: '<S423>/Constant'
     */
    rtb_Compare_cj = (((sint32)(rtb_UnitDelay_h ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S416>/If' incorporates:
     *  Constant: '<S419>/Constant'
     *  Constant: '<S420>/Constant'
     *  RelationalOperator: '<S417>/FixPt Relational Operator'
     *  RelationalOperator: '<S418>/FixPt Relational Operator'
     *  UnitDelay: '<S417>/Delay Input1'
     *  UnitDelay: '<S418>/Delay Input1'
     *
     * Block description for '<S417>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S418>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_l1) && (((sint32)(rtb_Compare_km ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_c ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S416>/If Action Subsystem' incorporates:
       *  ActionPort: '<S419>/Action Port'
       */
      rtb_Merge_c0 = true;

      /* End of Outputs for SubSystem: '<S416>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_h) && (((sint32)(rtb_Compare_cj ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_p ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S416>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S420>/Action Port'
       */
      rtb_Merge_c0 = false;

      /* End of Outputs for SubSystem: '<S416>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S416>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S421>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_h, &rtb_Merge_c0);

      /* End of Outputs for SubSystem: '<S416>/If Action Subsystem3' */
    }

    /* End of If: '<S416>/If' */

    /* Outputs for Enabled SubSystem: '<S383>/Count' incorporates:
     *  EnablePort: '<S413>/Enable'
     */
    /* Logic: '<S383>/Logical Operator' incorporates:
     *  Constant: '<S412>/Constant'
     *  Memory: '<S383>/Memory'
     *  RelationalOperator: '<S412>/Compare'
     */
    if ((rtb_TCU_ActualGear > ((uint8)0U)) && (LKAS_DW.Memory_PreviousInput_eq))
    {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S413>/Memory' */
        LKAS_DW.Memory_PreviousInput_o = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S413>/Add' incorporates:
       *  Memory: '<S413>/Memory'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_o;

      /* Saturate: '<S413>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_LftTTLC;
      }

      /* End of Saturate: '<S413>/Saturation' */

      /* Update for Memory: '<S413>/Memory' */
      LKAS_DW.Memory_PreviousInput_o = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S413>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S383>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S383>/Count' */

    /* Outputs for Enabled SubSystem: '<S416>/Sum Condition1' incorporates:
     *  EnablePort: '<S422>/state = reset'
     */
    if (rtb_Merge_c0) {
      if (!LKAS_DW.SumCondition1_MODE_f) {
        /* InitializeConditions for Memory: '<S422>/Memory' */
        LKAS_DW.Memory_PreviousInput_n2 = 0.0F;
        LKAS_DW.SumCondition1_MODE_f = true;
      }

      /* Sum: '<S422>/Add1' incorporates:
       *  Memory: '<S422>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_n2;

      /* Saturate: '<S422>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 5.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 5.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S422>/Saturation' */

      /* Switch: '<S657>/Switch40' incorporates:
       *  Constant: '<S657>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S657>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S657>/Switch40' */

      /* RelationalOperator: '<S422>/Relational Operator' incorporates:
       *  Sum: '<S383>/Add'
       */
      LKAS_DW.RelationalOperator_c = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S422>/Memory' */
      LKAS_DW.Memory_PreviousInput_n2 = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_f) {
        /* Disable for Outport: '<S422>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_f = false;
      }
    }

    /* End of Outputs for SubSystem: '<S416>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S384>/Sum Condition1' incorporates:
     *  EnablePort: '<S428>/state = reset'
     */
    /* Logic: '<S384>/Logical Operator' incorporates:
     *  Constant: '<S426>/Constant'
     *  Constant: '<S427>/Constant'
     *  Delay: '<S142>/Delay1'
     *  RelationalOperator: '<S426>/Compare'
     *  RelationalOperator: '<S427>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_b) {
        /* InitializeConditions for Memory: '<S428>/Memory' */
        LKAS_DW.Memory_PreviousInput_cp = 0.0F;
        LKAS_DW.SumCondition1_MODE_b = true;
      }

      /* Sum: '<S428>/Add1' incorporates:
       *  Memory: '<S428>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_cp;

      /* Saturate: '<S428>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S428>/Saturation' */

      /* RelationalOperator: '<S428>/Relational Operator' */
      LKAS_DW.RelationalOperator_l = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S428>/Memory' */
      LKAS_DW.Memory_PreviousInput_cp = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S428>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }
    }

    /* End of Logic: '<S384>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S384>/Sum Condition1' */

    /* If: '<S381>/If1' incorporates:
     *  Constant: '<S386>/Constant'
     *  Constant: '<S388>/Constant'
     *  Constant: '<S425>/Constant'
     *  Delay: '<S142>/Delay'
     *  Logic: '<S381>/Logical Operator'
     *  Logic: '<S384>/Logical Operator1'
     *  RelationalOperator: '<S425>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((LKAS_DW.RelationalOperator_c) ||
          ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_l))) || (LKAS_DW.Delay_DSTATE_j))) {
      /* Outputs for IfAction SubSystem: '<S381>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S388>/Action Port'
       */
      LKAS_DW.Merge1_c = true;

      /* End of Outputs for SubSystem: '<S381>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S381>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S386>/Action Port'
       */
      LKAS_DW.Merge1_c = false;

      /* End of Outputs for SubSystem: '<S381>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S381>/If1' */

    /* MATLAB Function: '<S549>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_ThresDet_lDvtThresUprLDW, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient_a);

    /* Product: '<S549>/Multiply' */
    rtb_Multiply_d = rtb_LL_ThresDet_lDvtThresUprLDW *
      rtb_ThresDet_coefficient_a;

    /* Switch: '<S551>/Switch' incorporates:
     *  Constant: '<S549>/Constant'
     *  RelationalOperator: '<S551>/UpperRelop'
     */
    if (rtb_Multiply_d < 0.0F) {
      rtb_Switch_p = 0.0F;
    } else {
      rtb_Switch_p = rtb_Multiply_d;
    }

    /* End of Switch: '<S551>/Switch' */

    /* Switch: '<S551>/Switch2' incorporates:
     *  RelationalOperator: '<S551>/LowerRelop1'
     */
    if (rtb_Multiply_d > rtb_LL_ThresDet_lDvtThresUprLDW) {
      rtb_Switch2_c = rtb_LL_ThresDet_lDvtThresUprLDW;
    } else {
      rtb_Switch2_c = rtb_Switch_p;
    }

    /* End of Switch: '<S551>/Switch2' */

    /* Logic: '<S535>/Logical Operator3' incorporates:
     *  Constant: '<S547>/Constant'
     *  Constant: '<S548>/Constant'
     *  Logic: '<S545>/Logical Operator'
     *  Logic: '<S546>/Logical Operator'
     *  RelationalOperator: '<S546>/Relational Operator1'
     *  RelationalOperator: '<S546>/Relational Operator2'
     *  RelationalOperator: '<S547>/Compare'
     *  RelationalOperator: '<S548>/Compare'
     */
    rtb_LogicalOperator3_b5 = (((LKAS_DW.LKA_Mode >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1 >= rtb_Switch2_c) && (rtb_Add5_n >= rtb_Switch2_c)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_b5);

    /* If: '<S535>/If' incorporates:
     *  Constant: '<S541>/Constant'
     *  DataTypeConversion: '<S535>/Cast To Single'
     *  DataTypeConversion: '<S535>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_LogicalOperator3_b5) {
      /* Outputs for IfAction SubSystem: '<S535>/If Action Subsystem' incorporates:
       *  ActionPort: '<S541>/Action Port'
       */
      LKAS_DW.Merge_ew = true;

      /* End of Outputs for SubSystem: '<S535>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S535>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S543>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_ew);

      /* End of Outputs for SubSystem: '<S535>/If Action Subsystem3' */
    }

    /* End of If: '<S535>/If' */

    /* Delay: '<S142>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S431>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S431>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_id != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S431>/If Action Subsystem' incorporates:
         *  ActionPort: '<S461>/Action Port'
         */
        /* InitializeConditions for If: '<S431>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S461>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_n = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S431>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S431>/If Action Subsystem' incorporates:
       *  ActionPort: '<S461>/Action Port'
       */
      /* Sum: '<S461>/Add1' incorporates:
       *  Memory: '<S461>/Memory'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_n;

      /* Saturate: '<S461>/Saturation' */
      if (rtb_LL_TkOvStChk_tiTDelTime > 10.0F) {
        rtb_LL_TkOvStChk_tiTDelTime = 10.0F;
      } else {
        if (rtb_LL_TkOvStChk_tiTDelTime < 0.0F) {
          rtb_LL_TkOvStChk_tiTDelTime = 0.0F;
        }
      }

      /* End of Saturate: '<S461>/Saturation' */
      /* End of Outputs for SubSystem: '<S431>/If Action Subsystem' */

      /* Switch: '<S657>/Switch64' incorporates:
       *  Constant: '<S657>/LLSMConClb33'
       *
       * Block description for '<S657>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S657>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S431>/If Action Subsystem' incorporates:
       *  ActionPort: '<S461>/Action Port'
       */
      /* RelationalOperator: '<S461>/Relational Operator' */
      rtb_Merge_a3 = (rtb_LL_TkOvStChk_tiTDelTime >= x10);

      /* Update for Memory: '<S461>/Memory' */
      LKAS_DW.Memory_PreviousInput_n = rtb_LL_TkOvStChk_tiTDelTime;

      /* End of Outputs for SubSystem: '<S431>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S431>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S462>/Action Port'
       */
      /* SignalConversion: '<S462>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S462>/Constant'
       */
      rtb_Merge_a3 = false;

      /* End of Outputs for SubSystem: '<S431>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S431>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S432>/Logical Operator1' incorporates:
     *  Constant: '<S463>/Constant'
     *  Logic: '<S432>/Logical Operator'
     *  RelationalOperator: '<S432>/Relational Operator1'
     *  RelationalOperator: '<S432>/Relational Operator2'
     *  RelationalOperator: '<S463>/Compare'
     */
    rtb_BCM_Left_Light = ((LKAS_DW.LKA_Mode >= ((uint8)1U)) && ((rtb_Gain1 <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_n <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S429>/Logical Operator3' */
    rtb_RelationalOperator_b = ((rtb_BCM_Left_Light || rtb_Merge_a3) ||
      rtb_RelationalOperator_b);

    /* If: '<S429>/If1' incorporates:
     *  Constant: '<S439>/Constant'
     *  DataTypeConversion: '<S429>/Cast To Single'
     *  DataTypeConversion: '<S429>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_RelationalOperator_b) {
      /* Outputs for IfAction SubSystem: '<S429>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S439>/Action Port'
       */
      LKAS_DW.Merge1_i = true;

      /* End of Outputs for SubSystem: '<S429>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S429>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S441>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_i);

      /* End of Outputs for SubSystem: '<S429>/If Action Subsystem4' */
    }

    /* End of If: '<S429>/If1' */

    /* Memory: '<S357>/Memory' */
    rtb_Memory_e = LKAS_DW.Memory_PreviousInput_i;

    /* If: '<S357>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_pw >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S357>/Ph1SWA' incorporates:
       *  ActionPort: '<S361>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S357>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_pw <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S357>/Ph2SWA' incorporates:
       *  ActionPort: '<S362>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S357>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S357>/Ph3SWA' incorporates:
       *  ActionPort: '<S363>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_e, &rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S357>/Ph3SWA' */
    }

    /* End of If: '<S357>/If' */

    /* Product: '<S353>/Divide2' incorporates:
     *  MATLAB Function: '<S353>/MATLAB Function'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S353>/Divide3' incorporates:
     *  MATLAB Function: '<S353>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S359>/Divide' */
    rtb_Divide_k = rtb_LKA_Veh2CamL_C * x1;

    /* Product: '<S353>/Divide1' incorporates:
     *  MATLAB Function: '<S353>/MATLAB Function'
     */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S364>/Switch' incorporates:
     *  RelationalOperator: '<S364>/UpperRelop'
     */
    if (rtb_Divide_k < rtb_LftTTLC) {
      rtb_Switch_a = rtb_LftTTLC;
    } else {
      rtb_Switch_a = rtb_Divide_k;
    }

    /* End of Switch: '<S364>/Switch' */

    /* Switch: '<S364>/Switch2' incorporates:
     *  RelationalOperator: '<S364>/LowerRelop1'
     */
    if (rtb_Divide_k > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_j = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_j = rtb_Switch_a;
    }

    /* End of Switch: '<S364>/Switch2' */

    /* Product: '<S360>/Divide' */
    rtb_Divide_kp = rtb_LKA_Veh2CamL_C * rtb_LogicalOperator3_c_tmp;

    /* Switch: '<S365>/Switch' incorporates:
     *  RelationalOperator: '<S365>/UpperRelop'
     */
    if (rtb_Divide_kp < rtb_LftTTLC) {
      rtb_Switch_o = rtb_LftTTLC;
    } else {
      rtb_Switch_o = rtb_Divide_kp;
    }

    /* End of Switch: '<S365>/Switch' */

    /* Switch: '<S365>/Switch2' incorporates:
     *  RelationalOperator: '<S365>/LowerRelop1'
     */
    if (rtb_Divide_kp > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_jh = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_jh = rtb_Switch_o;
    }

    /* End of Switch: '<S365>/Switch2' */

    /* Switch: '<S358>/Switch3' incorporates:
     *  Gain: '<S358>/Gain1'
     *  RelationalOperator: '<S360>/Relational Operator2'
     */
    if (rtb_Merge1_n >= 0.0F) {
      /* Switch: '<S358>/Switch2' incorporates:
       *  Constant: '<S358>/Constant2'
       *  DataTypeConversion: '<S358>/Cast To Single'
       *  RelationalOperator: '<S359>/Relational Operator2'
       */
      if (rtb_Merge1_n > 0.0F) {
        rtb_CastToSingle3 = (uint8)((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
          rtb_Switch2_j) ? 1 : 0);
      } else {
        rtb_CastToSingle3 = ((uint8)0U);
      }

      /* End of Switch: '<S358>/Switch2' */
    } else {
      rtb_CastToSingle3 = (uint8)((((uint32)((rtb_TTLC_d <= rtb_Switch2_jh) ? 1 :
        0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S358>/Switch3' */

    /* If: '<S343>/If' incorporates:
     *  Constant: '<S347>/Constant'
     *  Constant: '<S349>/Constant'
     *  Constant: '<S350>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
         && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S343>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S349>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S343>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
      == 2)) && (((sint32)rtb_CastToSingle3) == 2)) && (((sint32)
                 rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S343>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S350>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S343>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S343>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S347>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S343>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S343>/If' */

    /* Memory: '<S393>/Memory' */
    rtb_Memory_p = LKAS_DW.Memory_PreviousInput_a;

    /* If: '<S393>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_pw >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S393>/Ph1SWA' incorporates:
       *  ActionPort: '<S397>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S393>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_pw <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S393>/Ph2SWA' incorporates:
       *  ActionPort: '<S398>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S393>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S393>/Ph3SWA' incorporates:
       *  ActionPort: '<S399>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_p, &rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S393>/Ph3SWA' */
    }

    /* End of If: '<S393>/If' */

    /* Product: '<S389>/Divide2' */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S389>/Divide3' */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S395>/Divide' */
    rtb_Divide_bk = rtb_LKA_Veh2CamL_C * x1;

    /* Product: '<S389>/Divide1' */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S401>/Switch' incorporates:
     *  RelationalOperator: '<S401>/UpperRelop'
     */
    if (rtb_Divide_bk < rtb_LftTTLC) {
      rtb_Switch_gl = rtb_LftTTLC;
    } else {
      rtb_Switch_gl = rtb_Divide_bk;
    }

    /* End of Switch: '<S401>/Switch' */

    /* Switch: '<S401>/Switch2' incorporates:
     *  RelationalOperator: '<S401>/LowerRelop1'
     */
    if (rtb_Divide_bk > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_nc = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_nc = rtb_Switch_gl;
    }

    /* End of Switch: '<S401>/Switch2' */

    /* Product: '<S396>/Divide' */
    rtb_Divide_h = rtb_LKA_Veh2CamL_C * rtb_LogicalOperator3_c_tmp;

    /* Switch: '<S402>/Switch' incorporates:
     *  RelationalOperator: '<S402>/UpperRelop'
     */
    if (rtb_Divide_h < rtb_LftTTLC) {
      rtb_Switch_e = rtb_LftTTLC;
    } else {
      rtb_Switch_e = rtb_Divide_h;
    }

    /* End of Switch: '<S402>/Switch' */

    /* Switch: '<S402>/Switch2' incorporates:
     *  RelationalOperator: '<S402>/LowerRelop1'
     */
    if (rtb_Divide_h > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_g = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_g = rtb_Switch_e;
    }

    /* End of Switch: '<S402>/Switch2' */

    /* Switch: '<S394>/Switch3' incorporates:
     *  Gain: '<S394>/Gain1'
     *  RelationalOperator: '<S396>/Relational Operator2'
     */
    if (rtb_Merge1_j >= 0.0F) {
      /* Switch: '<S394>/Switch2' incorporates:
       *  Constant: '<S394>/Constant2'
       *  DataTypeConversion: '<S394>/Cast To Single'
       *  RelationalOperator: '<S395>/Relational Operator2'
       */
      if (rtb_Merge1_j > 0.0F) {
        rtb_IMAPve_d_BCM_HazardLamp = (uint8)((rtb_TLft <= rtb_Switch2_nc) ? 1 :
          0);
      } else {
        rtb_IMAPve_d_BCM_HazardLamp = ((uint8)0U);
      }

      /* End of Switch: '<S394>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((((uint32)
        ((rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_g) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S394>/Switch3' */

    /* Outputs for Enabled SubSystem: '<S394>/Sum Condition' incorporates:
     *  EnablePort: '<S400>/Enable'
     */
    if (((sint32)rtb_IMAPve_d_BCM_HazardLamp) > 0) {
      if (!LKAS_DW.SumCondition_MODE) {
        /* InitializeConditions for Memory: '<S400>/Memory' */
        LKAS_DW.Memory_PreviousInput_d = 0.0F;
        LKAS_DW.SumCondition_MODE = true;
      }

      /* Sum: '<S400>/Add1' incorporates:
       *  Memory: '<S400>/Memory'
       */
      rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_d;

      /* Saturate: '<S400>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 5.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 5.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S400>/Saturation' */

      /* RelationalOperator: '<S400>/Relational Operator' incorporates:
       *  Constant: '<S394>/Constant'
       */
      LKAS_DW.RelationalOperator_na = (rtb_LL_LDW_LatestWarnLine_C <= 2.0F);

      /* Update for Memory: '<S400>/Memory' */
      LKAS_DW.Memory_PreviousInput_d = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S400>/Out' */
        LKAS_DW.RelationalOperator_na = false;
        LKAS_DW.SumCondition_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S394>/Sum Condition' */

    /* If: '<S381>/If' incorporates:
     *  Constant: '<S385>/Constant'
     *  Constant: '<S387>/Constant'
     *  DataTypeConversion: '<S394>/Cast To Single3'
     *  DataTypeConversion: '<S394>/Cast To Single4'
     *  Product: '<S394>/Divide'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && (((sint32)((uint32)(((uint32)rtb_IMAPve_d_BCM_HazardLamp) *
            (LKAS_DW.RelationalOperator_na ? 1U : 0U)))) == 0)) {
      /* Outputs for IfAction SubSystem: '<S381>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S387>/Action Port'
       */
      LKAS_DW.LKA_Fault = true;

      /* End of Outputs for SubSystem: '<S381>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S381>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S385>/Action Port'
       */
      LKAS_DW.LKA_Fault = false;

      /* End of Outputs for SubSystem: '<S381>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S381>/If' */

    /* Logic: '<S342>/Logical Operator2' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  DataTypeConversion: '<S13>/Cast To Boolean2'
     *  DataTypeConversion: '<S13>/Cast To Boolean3'
     *  DataTypeConversion: '<S13>/Cast To Boolean4'
     *  DataTypeConversion: '<S13>/Cast To Boolean6'
     *  DataTypeConversion: '<S13>/Cast To Boolean8'
     *  DataTypeConversion: '<S13>/Cast To Boolean9'
     */
    rtb_LL_SingleLane_Disable_Swt = (((((((((sint32)rtb_ModifyScalingOnly_d) !=
      0) || (((sint32)rtb_ModifyScalingOnly_ok) != 0)) || (((sint32)
      rtb_ModifyScalingOnly_fc) != 0)) || (((sint32)rtb_ModifyScalingOnly_dio)
      != 0)) || (((sint32)rtb_ModifyScalingOnly_h0) != 0)) || (((sint32)
      rtb_ModifyScalingOnly_m) != 0)) || (((sint32)rtb_IMAPve_d_R1_Type) != 0));

    /* Logic: '<S342>/Logical Operator1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S12>/Cast To Boolean10'
     *  DataTypeConversion: '<S12>/Cast To Boolean12'
     *  DataTypeConversion: '<S12>/Cast To Boolean15'
     *  DataTypeConversion: '<S12>/Cast To Boolean16'
     *  DataTypeConversion: '<S12>/Cast To Boolean19'
     *  DataTypeConversion: '<S12>/Cast To Boolean2'
     *  DataTypeConversion: '<S12>/Cast To Boolean20'
     *  DataTypeConversion: '<S12>/Cast To Boolean21'
     *  DataTypeConversion: '<S12>/Cast To Boolean3'
     *  DataTypeConversion: '<S12>/Cast To Boolean35'
     *  DataTypeConversion: '<S12>/Cast To Boolean36'
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  DataTypeConversion: '<S12>/Cast To Boolean9'
     *  DataTypeConversion: '<S15>/Modify Scaling Only'
     */
    rtb_BCM_Right_Light = ((((((((((((((((sint32)rtb_ExtractDesiredBits_ad) != 0)
      || (((sint32)rtb_ModifyScalingOnly_mo) != 0)) || (((sint32)
      rtb_ModifyScalingOnly_enu) != 0)) || (((sint32)rtb_ModifyScalingOnly_lt)
      != 0)) || (((sint32)rtb_ModifyScalingOnly_dt) != 0)) || (((sint32)
      rtb_ModifyScalingOnly_c) != 0)) || (((sint32)rtb_ModifyScalingOnly_f) != 0))
      || (((sint32)rtb_ModifyScalingOnly_jq) != 0)) || (((sint32)
      rtb_ModifyScalingOnly_h) != 0)) || (((sint32)rtb_ModifyScalingOnly_lz) !=
      0)) || (((sint32)rtb_ModifyScalingOnly_ib) != 0)) || (((sint32)
      rtb_ModifyScalingOnly_na) != 0)) || (((sint32)rtb_ModifyScalingOnly_h2) !=
      0)) || (((sint32)rtb_ModifyScalingOnly_kk) != 0));

    /* Logic: '<S342>/Logical Operator10' */
    LKAS_DW.LDW_Fault = (rtb_LL_SingleLane_Disable_Swt || rtb_BCM_Right_Light);

    /* Chart: '<S142>/LDW_State_Machine'
     *
     * Block description for '<S142>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* Sum: '<S593>/Add' incorporates:
     *  Memory: '<S593>/Memory'
     */
    rtb_LftTTLC = LKAS_DW.Memory_PreviousInput_ac + rtb_LKA_SampleTime;

    /* Saturate: '<S593>/Saturation' */
    if (rtb_LftTTLC > 11.0F) {
      rtb_Saturation_d = 11.0F;
    } else if (rtb_LftTTLC < 0.0F) {
      rtb_Saturation_d = 0.0F;
    } else {
      rtb_Saturation_d = rtb_LftTTLC;
    }

    /* End of Saturate: '<S593>/Saturation' */

    /* Logic: '<S342>/Logical Operator8' incorporates:
     *  Constant: '<S592>/Constant'
     *  Constant: '<S593>/Constant1'
     *  Logic: '<S342>/AND'
     *  RelationalOperator: '<S592>/Compare'
     *  RelationalOperator: '<S593>/Relational Operator'
     */
    LKAS_DW.LKA_Fault = ((rtb_LL_SingleLane_Disable_Swt || rtb_BCM_Right_Light) ||
                         ((rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U)) &&
                          (rtb_Saturation_d >= ((float32)((uint16)5U)))));

    /* Chart: '<S142>/LKA_State_Machine'
     *
     * Block description for '<S142>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S319>/Subsystem' incorporates:
     *  EnablePort: '<S323>/Enable'
     */
    /* Logic: '<S319>/Logical Operator3' incorporates:
     *  Abs: '<S319>/Abs4'
     *  Abs: '<S319>/Abs5'
     *  Abs: '<S319>/Abs6'
     *  Abs: '<S319>/Abs7'
     *  Constant: '<S319>/Constant'
     *  Constant: '<S319>/Constant1'
     *  Constant: '<S319>/Constant4'
     *  Constant: '<S319>/Constant5'
     *  Constant: '<S321>/Constant'
     *  Constant: '<S322>/Constant'
     *  Logic: '<S319>/Logical Operator'
     *  Logic: '<S319>/Logical Operator1'
     *  Logic: '<S319>/Logical Operator4'
     *  RelationalOperator: '<S319>/Relational Operator'
     *  RelationalOperator: '<S319>/Relational Operator1'
     *  RelationalOperator: '<S319>/Relational Operator2'
     *  RelationalOperator: '<S319>/Relational Operator3'
     *  RelationalOperator: '<S319>/Relational Operator6'
     *  RelationalOperator: '<S319>/Relational Operator7'
     *  RelationalOperator: '<S321>/Compare'
     *  RelationalOperator: '<S322>/Compare'
     *  Switch: '<S111>/Switch'
     *  Switch: '<S111>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_m) <= 0.008F) && (fabsf(rtb_L0_C1_i) <= 0.008F)) &&
           ((fabsf(rtb_LL_CompHdAg_C) <= 0.0001F) && (fabsf(rtb_L0_C2) <=
             0.0001F))) && ((rtb_L0_Q == ((uint8)3U)) && (rtb_R0_Q == ((uint8)3U))))
         && (rtb_IMAPve_g_ESC_VehSpd >= 35.0F)) && (rtb_TTLC <= 4.0F)) {
      if (!LKAS_DW.Subsystem_MODE_p) {
        /* InitializeConditions for Memory: '<S323>/Memory' */
        LKAS_DW.Memory_PreviousInput_h = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_p = true;
      }

      /* Sum: '<S323>/Add1' incorporates:
       *  Memory: '<S323>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(1U + ((uint32)LKAS_DW.Memory_PreviousInput_h));

      /* Saturate: '<S323>/Saturation' */
      if (rtb_Saturation_h5 >= ((uint16)3000U)) {
        rtb_Saturation_h5 = ((uint16)3000U);
      }

      /* End of Saturate: '<S323>/Saturation' */

      /* RelationalOperator: '<S323>/Relational Operator' incorporates:
       *  Constant: '<S319>/Constant3'
       *  DataTypeConversion: '<S323>/Cast To Single1'
       *  Product: '<S319>/Divide'
       */
      LKAS_DW.RelationalOperator_k = (rtb_Saturation_h5 >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S323>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = rtb_Saturation_h5;
    } else {
      if (LKAS_DW.Subsystem_MODE_p) {
        /* Disable for Outport: '<S323>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Subsystem_MODE_p = false;
      }
    }

    /* End of Logic: '<S319>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S319>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S293>/Subsystem' incorporates:
     *  EnablePort: '<S318>/Enable'
     */
    if (LKAS_DW.RelationalOperator_k) {
      /* Sum: '<S320>/Add2' incorporates:
       *  Constant: '<S320>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S320>/Memory3'
       */
      rtb_LL_LDW_LatestWarnLine_C = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S320>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 50.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 50.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S320>/Saturation' */

      /* Switch: '<S320>/Switch' incorporates:
       *  Constant: '<S318>/Constant'
       *  Product: '<S320>/Divide'
       *  Product: '<S320>/Divide1'
       *  Sum: '<S320>/Add'
       *  Sum: '<S320>/Add1'
       *  UnitDelay: '<S320>/Unit Delay'
       */
      if (rtb_LL_LDW_LatestWarnLine_C > 1.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_R0_C2 - LKAS_DW.UnitDelay_DSTATE)) + LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_R0_C2;
      }

      /* End of Switch: '<S320>/Switch' */

      /* Saturate: '<S318>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 3.0F) {
        LKAS_DW.Saturation_h = 3.0F;
      } else if (rtb_LL_ThresDet_lDvtThresLwrLDW < (-3.0F)) {
        LKAS_DW.Saturation_h = (-3.0F);
      } else {
        LKAS_DW.Saturation_h = rtb_LL_ThresDet_lDvtThresLwrLDW;
      }

      /* End of Saturate: '<S318>/Saturation' */

      /* Update for UnitDelay: '<S320>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Update for Memory: '<S320>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Outputs for SubSystem: '<S293>/Subsystem' */

    /* Saturate: '<S295>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 0.001F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.001F;
    } else {
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S295>/Saturation' */

    /* Gain: '<S331>/kph To mps' incorporates:
     *  Gain: '<S332>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = 0.277777791F *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S331>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S333>:1' */
    /* '<S333>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 60.0F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_LL_ThresDet_lDvtThresUprLKA;
    }

    /* End of Saturate: '<S331>/Saturation3' */

    /* Product: '<S331>/Divide1' incorporates:
     *  Constant: '<S331>/Constant'
     */
    rtb_LftTTLC = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S331>/Saturation1' */
    if (rtb_LftTTLC > 0.0117F) {
      rtb_LftTTLC = 0.0117F;
    } else {
      if (rtb_LftTTLC < 0.00237F) {
        rtb_LftTTLC = 0.00237F;
      }
    }

    /* End of Saturate: '<S331>/Saturation1' */

    /* Switch: '<S656>/Switch7' incorporates:
     *  Constant: '<S656>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_k != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_k;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S656>/Switch7' */

    /* MATLAB Function: '<S331>/MATLAB Function' incorporates:
     *  Gain: '<S331>/kph To mps'
     */
    rtb_LL_LDW_LatestWarnLine_C = ((((((((rtb_LftTTLC *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_d) * LKAS_DW.LKA_WhlBaseL_C_m) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S332>/Saturation3' */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 60.0F;
      }
    }

    /* End of Saturate: '<S332>/Saturation3' */

    /* Product: '<S332>/Divide1' incorporates:
     *  Constant: '<S332>/Constant'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = 0.09F / rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S332>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S334>:1' */
    /* '<S334>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 0.0117F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.0117F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 0.00237F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 0.00237F;
      }
    }

    /* End of Saturate: '<S332>/Saturation1' */

    /* Switch: '<S656>/Switch4' incorporates:
     *  Constant: '<S656>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_j != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_j;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S656>/Switch4' */

    /* MATLAB Function: '<S332>/MATLAB Function' */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_d) * LKAS_DW.LKA_WhlBaseL_C_m) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Gain: '<S290>/Gain1' incorporates:
     *  Sum: '<S290>/Add1'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = (rtb_Add_p + rtb_Add_o) * 0.5F;

    /* Switch: '<S292>/Switch' incorporates:
     *  Constant: '<S308>/Constant'
     *  RelationalOperator: '<S308>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_LftTTLC = rtb_LFTTTLC;
    } else {
      rtb_LftTTLC = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S292>/Switch' */

    /* Saturate: '<S292>/Saturation' */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else {
      if (rtb_LftTTLC < 0.5F) {
        rtb_LftTTLC = 0.5F;
      }
    }

    /* End of Saturate: '<S292>/Saturation' */

    /* Product: '<S316>/Divide' */
    rtb_Divide_ca = rtb_Abs_f_tmp * rtb_LftTTLC;

    /* Switch: '<S292>/Switch1' incorporates:
     *  Constant: '<S309>/Constant'
     *  RelationalOperator: '<S309>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S292>/Switch1' */

    /* Saturate: '<S292>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S292>/Saturation1' */

    /* Product: '<S317>/Divide' */
    rtb_Divide_dv = rtb_Abs_f_tmp * rtb_LL_HdAgPrvwT_C;

    /* Gain: '<S292>/Gain1' incorporates:
     *  Sum: '<S292>/Add1'
     */
    rtb_LL_HdAgPrvwT_C = (rtb_Divide_ca + rtb_Divide_dv) * 0.5F;

    /* Switch: '<S656>/Switch8' incorporates:
     *  Constant: '<S656>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_i != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_i;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S656>/Switch8' */

    /* Product: '<S307>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_Abs_f_tmp * x10;

    /* Product: '<S305>/Z*Z' incorporates:
     *  Product: '<S306>/Z*Z'
     */
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Sum: '<S305>/Add' incorporates:
     *  Product: '<S305>/Product'
     *  Product: '<S305>/Product3'
     *  Product: '<S305>/Product4'
     *  Product: '<S305>/Z*Z'
     *  Product: '<S305>/Z*Z*Z'
     */
    rtb_Add_am = (((rtb_L0_C1_m * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_L0_C0_o)
                  + (rtb_LL_CompHdAg_C * rtb_LL_DvtSpdDet_vDvtSpdMin_C)) +
      ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_DvtSpdDet_vDvtSpdMin_C) *
       rtb_L0_C3_dc);

    /* Sum: '<S306>/Add' incorporates:
     *  Product: '<S306>/Product'
     *  Product: '<S306>/Product3'
     *  Product: '<S306>/Product4'
     *  Product: '<S306>/Z*Z*Z'
     */
    rtb_Add_e1 = (((rtb_L0_C1_i * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_R0_C0_n)
                  + (rtb_L0_C2 * rtb_LL_DvtSpdDet_vDvtSpdMin_C)) +
      ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_DvtSpdDet_vDvtSpdMin_C) *
       rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S140>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S169>/Memory' */
        LKAS_DW.Memory_PreviousInput_ok = 0.0F;

        /* InitializeConditions for Memory: '<S200>/Memory' */
        LKAS_DW.Memory_PreviousInput_mx = ((uint16)0U);

        /* InitializeConditions for Memory: '<S187>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_l = ((uint8)0U);

        /* InitializeConditions for Memory: '<S199>/Memory' */
        LKAS_DW.Memory_PreviousInput_av = ((uint16)0U);

        /* InitializeConditions for Memory: '<S201>/Memory' */
        LKAS_DW.Memory_PreviousInput_nj = ((uint16)0U);

        /* InitializeConditions for Memory: '<S196>/Memory' */
        LKAS_DW.Memory_PreviousInput_p1 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S184>/Memory' */
        LKAS_DW.Memory_PreviousInput_i3 = 0.0F;

        /* InitializeConditions for Memory: '<S170>/Memory' */
        LKAS_DW.Memory_PreviousInput_kz = 0.0F;

        /* InitializeConditions for Memory: '<S171>/Memory' */
        LKAS_DW.Memory_PreviousInput_mo = 0.0F;

        /* InitializeConditions for UnitDelay: '<S173>/Delay Input1'
         *
         * Block description for '<S173>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_px = false;

        /* InitializeConditions for Memory: '<S171>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_k = false;

        /* InitializeConditions for Memory: '<S162>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e = 0.0F;

        /* InitializeConditions for Memory: '<S263>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_p = 0.0F;

        /* InitializeConditions for Memory: '<S246>/Memory' */
        LKAS_DW.Memory_PreviousInput_g = 0.0F;

        /* InitializeConditions for UnitDelay: '<S244>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_a = 0.0F;

        /* InitializeConditions for Memory: '<S252>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_m = 0.0F;

        /* InitializeConditions for Memory: '<S258>/Memory' */
        LKAS_DW.Memory_PreviousInput_f4 = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S262>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

        /* InitializeConditions for Memory: '<S262>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_b = 0.0F;

        /* InitializeConditions for UnitDelay: '<S239>/Delay Input2'
         *
         * Block description for '<S239>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_b = 0.0F;

        /* InitializeConditions for Memory: '<S239>/Memory' */
        LKAS_DW.Memory_PreviousInput_e = ((uint16)0U);

        /* InitializeConditions for Memory: '<S195>/Memory' */
        LKAS_DW.Memory_PreviousInput_b = ((uint16)0U);

        /* InitializeConditions for Memory: '<S197>/Memory' */
        LKAS_DW.Memory_PreviousInput_l = ((uint16)0U);

        /* InitializeConditions for Memory: '<S198>/Memory' */
        LKAS_DW.Memory_PreviousInput_oj = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S157>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S157>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S171>/Moving Standard Deviation1' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S171>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S171>/Moving Standard Deviation2' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation2_d);

        /* End of SystemReset for SubSystem: '<S171>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Memory: '<S169>/Memory' */
      rtb_Divide3_j = LKAS_DW.Memory_PreviousInput_ok;

      /* Sum: '<S169>/Add2' */
      rtb_Divide3_j += rtb_LKA_SampleTime;

      /* Saturate: '<S169>/Saturation2' */
      if (rtb_Divide3_j > 20.0F) {
        rtb_Saturation2_g = 20.0F;
      } else if (rtb_Divide3_j < 0.0F) {
        rtb_Saturation2_g = 0.0F;
      } else {
        rtb_Saturation2_g = rtb_Divide3_j;
      }

      /* End of Saturate: '<S169>/Saturation2' */

      /* Abs: '<S169>/Abs' */
      rtb_Divide3_j = rtb_TTLC_n;

      /* Saturate: '<S169>/Saturation' */
      if (rtb_Divide3_j > 0.004F) {
        rtb_Divide3_j = 0.004F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S169>/Saturation' */

      /* RelationalOperator: '<S169>/Relational Operator4' incorporates:
       *  Constant: '<S169>/Constant'
       *  Constant: '<S169>/Constant1'
       *  Product: '<S169>/Divide'
       *  Sum: '<S169>/Add'
       */
      rtb_BCM_Right_Light = (rtb_Saturation2_g >=
        ((((rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F) * rtb_Divide3_j) / 0.004F) +
         rtb_LL_LKAExPrcs_tiExitTime1));

      /* Abs: '<S170>/Abs' */
      rtb_Divide3_j = rtb_TTLC_n;

      /* Saturate: '<S170>/Saturation' */
      if (rtb_Divide3_j > 0.004F) {
        rtb_Divide3_j = 0.004F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S170>/Saturation' */

      /* Product: '<S170>/Divide' incorporates:
       *  Constant: '<S170>/Constant'
       *  Constant: '<S170>/Constant1'
       */
      rtb_LL_DvtSpdDet_vDvtSpdMin_C = ((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) *
        rtb_Divide3_j) / 0.004F;

      /* Sum: '<S200>/Add' incorporates:
       *  Constant: '<S200>/Constant'
       *  Memory: '<S200>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_mx));

      /* Saturate: '<S200>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_f = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_f = ((uint16)10000U);
      }

      /* End of Saturate: '<S200>/Saturation1' */

      /* Gain: '<S245>/kph to mps' */
      rtb_Divide3_j = rtb_Abs_f_tmp;

      /* Saturate: '<S245>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S245>/Saturation3' */

      /* Product: '<S245>/Divide2' incorporates:
       *  Constant: '<S245>/Constant'
       */
      rtb_LftTTLC = 0.09F / x10;

      /* Switch: '<S656>/Switch36' incorporates:
       *  Constant: '<S656>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_p != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_p;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S656>/Switch36' */

      /* Saturate: '<S245>/Saturation1' */
      if (rtb_LftTTLC > 0.01F) {
        rtb_LftTTLC = 0.01F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S245>/Saturation1' */

      /* Gain: '<S245>/Gain2' incorporates:
       *  Constant: '<S245>/Constant1'
       *  Gain: '<S245>/rad to deg'
       *  Gain: '<S290>/Gain1'
       *  Math: '<S245>/Math Function'
       *  Product: '<S245>/Divide'
       *  Product: '<S245>/Divide1'
       *  Product: '<S245>/Product'
       *  Product: '<S245>/Product1'
       *  Product: '<S245>/Product2'
       *  Product: '<S245>/Product3'
       *  Sum: '<S245>/Add'
       *
       * About '<S245>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = (((((((rtb_Divide3_j * rtb_Divide3_j) *
        rtb_LftTTLC) + 1.0F) / (rtb_Divide3_j / LKAS_DW.LKA_WhlBaseL_C_m)) *
        ((rtb_Divide3_j * rtb_LL_ThresDet_tiTTLCThresLDW) * 57.2957802F)) * x10)
        * LKAS_DW.LKA_StrRatio_C_d) * (-1.0F);

      /* Sum: '<S183>/Add1' */
      rtb_Add1_i = (rtb_R0_C2 - rtb_LL_LKAExPrcs_tiExitTime1) -
        LKAS_DW.Saturation_h;

      /* If: '<S200>/If' incorporates:
       *  Constant: '<S200>/Constant2'
       */
      if (rtb_Saturation1_f == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S200>/if action ' incorporates:
         *  ActionPort: '<S223>/Action Port'
         */
        LKAS_ifaction(rtb_Add1_i, &LKAS_DW.In_n);

        /* End of Outputs for SubSystem: '<S200>/if action ' */
      }

      /* End of If: '<S200>/If' */

      /* Sum: '<S187>/Add' incorporates:
       *  Constant: '<S187>/Constant'
       *  Memory: '<S187>/Memory1'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_l));

      /* Saturate: '<S187>/Saturation1' */
      if (rtb_IMAPve_d_BCM_HazardLamp < ((uint8)5U)) {
        rtb_Saturation1_cv = rtb_IMAPve_d_BCM_HazardLamp;
      } else {
        rtb_Saturation1_cv = ((uint8)5U);
      }

      /* End of Saturate: '<S187>/Saturation1' */

      /* Saturate: '<S183>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        rtb_Divide3_j = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        rtb_Divide3_j = 60.0F;
      } else {
        rtb_Divide3_j = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S183>/Saturation3' */

      /* Product: '<S183>/Divide1' incorporates:
       *  Constant: '<S183>/Constant'
       */
      rtb_Divide3_j = 0.09F / rtb_Divide3_j;

      /* Saturate: '<S183>/Saturation1' */
      if (rtb_Divide3_j > 0.0117F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.0117F;
      } else if (rtb_Divide3_j < 0.00237F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.MPInP_StbFacm_SY = rtb_Divide3_j;
      }

      /* End of Saturate: '<S183>/Saturation1' */

      /* Gain: '<S183>/Gain' */
      LKAS_DW.MPInP_dphiSWARMax = 1.0F * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S199>/Add' incorporates:
       *  Constant: '<S199>/Constant'
       *  Memory: '<S199>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_av));

      /* Saturate: '<S199>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_a = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_a = ((uint16)10000U);
      }

      /* End of Saturate: '<S199>/Saturation1' */

      /* If: '<S190>/If' incorporates:
       *  DataTypeConversion: '<S140>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S190>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S204>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_LFTTTLC, &rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S190>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S203>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_RGTTTLC, &rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S190>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S205>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem3' */
      }

      /* End of If: '<S190>/If' */

      /* If: '<S199>/If' incorporates:
       *  Constant: '<S199>/Constant2'
       */
      if (rtb_Saturation1_a == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S199>/if action ' incorporates:
         *  ActionPort: '<S222>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_c, &LKAS_DW.In_l);

        /* End of Outputs for SubSystem: '<S199>/if action ' */
      }

      /* End of If: '<S199>/If' */

      /* Saturate: '<S183>/Saturation2' */
      if (LKAS_DW.In_l > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_l < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_l;
      }

      /* End of Saturate: '<S183>/Saturation2' */

      /* Sum: '<S201>/Add' incorporates:
       *  Constant: '<S201>/Constant'
       *  Memory: '<S201>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_nj));

      /* Saturate: '<S201>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_b = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S201>/Saturation1' */

      /* If: '<S201>/If' incorporates:
       *  Constant: '<S201>/Constant2'
       */
      if (rtb_Saturation1_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S201>/if action ' incorporates:
         *  ActionPort: '<S224>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_ESC_VehSpd, &LKAS_DW.In_c);

        /* End of Outputs for SubSystem: '<S201>/if action ' */
      }

      /* End of If: '<S201>/If' */

      /* Sum: '<S196>/Add' incorporates:
       *  Constant: '<S196>/Constant'
       *  Memory: '<S196>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_p1));

      /* Saturate: '<S196>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_k = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_k = ((uint16)10000U);
      }

      /* End of Saturate: '<S196>/Saturation1' */

      /* Product: '<S314>/Z*Z' incorporates:
       *  Product: '<S311>/Z*Z'
       */
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_Divide_ca * rtb_Divide_ca;

      /* Gain: '<S314>/Gain1' incorporates:
       *  Gain: '<S313>/Gain1'
       *  Gain: '<S315>/Gain1'
       */
      rtb_L0_C3_dc *= 3.0F;

      /* Gain: '<S311>/Gain1' incorporates:
       *  Gain: '<S310>/Gain1'
       *  Gain: '<S312>/Gain1'
       */
      rtb_L0_C3 *= 3.0F;

      /* Gain: '<S191>/Gain' incorporates:
       *  Gain: '<S311>/Gain1'
       *  Gain: '<S314>/Gain1'
       *  Product: '<S311>/Product3'
       *  Product: '<S311>/Product4'
       *  Product: '<S314>/Product3'
       *  Product: '<S314>/Product4'
       *  Product: '<S314>/Z*Z'
       *  Sum: '<S191>/Add'
       *  Sum: '<S311>/Add'
       *  Sum: '<S314>/Add'
       */
      rtb_Gain_iu = ((((rtb_Add_p_tmp * rtb_Divide_ca) + rtb_L0_C1_m) +
                      (rtb_L0_C3_dc * rtb_LL_ThresDet_lDvtThresUprLKA)) +
                     (((rtb_Add_o_tmp * rtb_Divide_ca) + rtb_L0_C1_i) +
                      (rtb_L0_C3 * rtb_LL_ThresDet_lDvtThresUprLKA))) * 0.5F;

      /* Product: '<S315>/Z*Z' incorporates:
       *  Product: '<S312>/Z*Z'
       */
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_Divide_dv * rtb_Divide_dv;

      /* Gain: '<S191>/Gain1' incorporates:
       *  Product: '<S312>/Product3'
       *  Product: '<S312>/Product4'
       *  Product: '<S315>/Product3'
       *  Product: '<S315>/Product4'
       *  Product: '<S315>/Z*Z'
       *  Sum: '<S191>/Add1'
       *  Sum: '<S312>/Add'
       *  Sum: '<S315>/Add'
       */
      rtb_Gain1_p = ((((rtb_Add_p_tmp * rtb_Divide_dv) + rtb_L0_C1_m) +
                      (rtb_L0_C3_dc * rtb_LL_ThresDet_lDvtThresUprLKA)) +
                     (((rtb_Add_o_tmp * rtb_Divide_dv) + rtb_L0_C1_i) +
                      (rtb_L0_C3 * rtb_LL_ThresDet_lDvtThresUprLKA))) * 0.5F;

      /* If: '<S191>/If' incorporates:
       *  DataTypeConversion: '<S140>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S191>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S207>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Gain_iu, &rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S191>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S191>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S206>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Gain1_p, &rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S191>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S191>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S208>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S191>/If Action Subsystem3' */
      }

      /* End of If: '<S191>/If' */

      /* If: '<S193>/If' incorporates:
       *  DataTypeConversion: '<S140>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S213>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Divide_ca, &rtb_Gain2_b);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S212>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Divide_dv, &rtb_Gain2_b);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S214>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Gain2_b);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem3' */
      }

      /* End of If: '<S193>/If' */

      /* Sum: '<S183>/Add' incorporates:
       *  Gain: '<S290>/Gain1'
       *  Product: '<S183>/Divide2'
       */
      rtb_Add_id = rtb_Divide3_j - (rtb_LL_ThresDet_tiTTLCThresLDW * rtb_Gain2_b);

      /* If: '<S196>/If' incorporates:
       *  Constant: '<S196>/Constant2'
       */
      if (rtb_Saturation1_k == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S196>/if action ' incorporates:
         *  ActionPort: '<S219>/Action Port'
         */
        LKAS_ifaction(rtb_Add_id, &LKAS_DW.In_ir);

        /* End of Outputs for SubSystem: '<S196>/if action ' */
      }

      /* End of If: '<S196>/If' */

      /* If: '<S202>/If' incorporates:
       *  DataTypeConversion: '<S140>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S202>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S226>/Action Port'
         */
        /* SignalConversion: '<S226>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S226>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S202>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S202>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S225>/Action Port'
         */
        /* SignalConversion: '<S225>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S225>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S202>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S202>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S227>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S202>/If Action Subsystem3' */
      }

      /* End of If: '<S202>/If' */

      /* If: '<S187>/If' incorporates:
       *  Constant: '<S187>/Constant19'
       */
      rtAction = -1;
      if (rtb_Saturation1_cv == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        /* Outputs for IfAction SubSystem: '<S151>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S182>/Action Port'
         *
         * Block description for '<S151>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S151>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S187>/If' */

      /* Memory: '<S184>/Memory' */
      rtb_Gain2_b = LKAS_DW.Memory_PreviousInput_i3;

      /* Sum: '<S184>/Add' incorporates:
       *  Gain: '<S184>/Gain1'
       *  Product: '<S184>/Divide'
       *  Product: '<S184>/Product'
       */
      rtb_Add_l = ((rtb_Abs_f_tmp * rtb_LKA_SampleTime) / (0.277777791F *
        LKAS_DW.In_c)) + rtb_Gain2_b;

      /* MATLAB Function: '<S185>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S228>:1' */
      /* '<S228>:1:19' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S228>:1:20' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S228>:1:21' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S228>:1:22' Delte2PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S228>:1:23' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S228>:1:24' NomT = SWACmd_tiNomT; */
      /* '<S228>:1:25' T1 = K1K2Det_T1; */
      /* '<S228>:1:26' T2 = T1; */
      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S228>:1:34' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_l < LKAS_DW.K1K2Det_T1) && (rtb_Add_l >= 0.0F)) {
        /* '<S228>:1:35' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_l) +
          LKAS_DW.In_n;
      } else if ((rtb_Add_l <= LKAS_DW.K1K2Det_T1) && (rtb_Add_l >=
                  LKAS_DW.K1K2Det_T1)) {
        /* '<S228>:1:36' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S228>:1:38' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
          LKAS_DW.K1K2Det_T1) + LKAS_DW.In_n;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_l >= LKAS_DW.K1K2Det_T1) {
          /* '<S228>:1:40' elseif(NomT >= T2) */
          /* '<S228>:1:41' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
            LKAS_DW.K1K2Det_T1) + LKAS_DW.In_n;

          /*    DelteSWCmd = single(0); */
        }
      }

      /* Saturate: '<S151>/Saturation6' incorporates:
       *  MATLAB Function: '<S185>/SWACmd'
       */
      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S228>:1:47' SWACmd_phiSWACmd = DelteSWCmd; */
      if (LKAS_DW.K1K2Det_T1 > 2.0F) {
        rtb_Saturation6 = 2.0F;
      } else if (LKAS_DW.K1K2Det_T1 < 0.2F) {
        rtb_Saturation6 = 0.2F;
      } else {
        rtb_Saturation6 = LKAS_DW.K1K2Det_T1;
      }

      /* End of Saturate: '<S151>/Saturation6' */

      /* Memory: '<S170>/Memory' */
      rtb_Gain2_b = LKAS_DW.Memory_PreviousInput_kz;

      /* Sum: '<S170>/Add2' */
      rtb_Gain2_b += rtb_LKA_SampleTime;

      /* Saturate: '<S170>/Saturation2' */
      if (rtb_Gain2_b > 12.0F) {
        rtb_Saturation2_l = 12.0F;
      } else if (rtb_Gain2_b < 0.0F) {
        rtb_Saturation2_l = 0.0F;
      } else {
        rtb_Saturation2_l = rtb_Gain2_b;
      }

      /* End of Saturate: '<S170>/Saturation2' */

      /* Abs: '<S170>/Abs2' */
      rtb_Gain2_b = fabsf(rtb_Gain1);

      /* Sum: '<S170>/Add3' incorporates:
       *  Sum: '<S171>/Add'
       *  Sum: '<S230>/Add'
       *  Sum: '<S251>/Add6'
       */
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Gain: '<S170>/Gain' incorporates:
       *  Sum: '<S170>/Add3'
       */
      rtb_Divide3_j = rtb_LL_ThresDet_lDvtThresUprLKA * 0.166666672F;

      /* RelationalOperator: '<S170>/Relational Operator2' */
      rtb_LogicalOperator3_b5 = (rtb_Gain2_b >= rtb_Divide3_j);

      /* Abs: '<S170>/Abs3' */
      rtb_Gain2_b = fabsf(rtb_Add5_n);

      /* Outputs for Enabled SubSystem: '<S170>/Sum Condition1' incorporates:
       *  EnablePort: '<S172>/Enable'
       */
      /* Logic: '<S170>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S170>/Relational Operator3'
       *  RelationalOperator: '<S170>/Relational Operator4'
       */
      if (((rtb_Saturation2_l >= rtb_Saturation6) && rtb_LogicalOperator3_b5) &&
          (rtb_Gain2_b >= rtb_Divide3_j)) {
        if (!LKAS_DW.SumCondition1_MODE_h) {
          /* InitializeConditions for Memory: '<S172>/Memory' */
          LKAS_DW.Memory_PreviousInput_n0 = 0.0F;
          LKAS_DW.SumCondition1_MODE_h = true;
        }

        /* Sum: '<S172>/Add1' incorporates:
         *  Memory: '<S172>/Memory'
         */
        rtb_Abs_pw = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_n0;

        /* Saturate: '<S172>/Saturation' */
        if (rtb_Abs_pw > 10.0F) {
          rtb_Abs_pw = 10.0F;
        } else {
          if (rtb_Abs_pw < 0.0F) {
            rtb_Abs_pw = 0.0F;
          }
        }

        /* End of Saturate: '<S172>/Saturation' */

        /* RelationalOperator: '<S172>/Relational Operator' incorporates:
         *  Sum: '<S170>/Add1'
         */
        LKAS_DW.RelationalOperator_ew = (rtb_Abs_pw >=
          (rtb_LL_LKAExPrcs_tiExitTime2 + rtb_LL_DvtSpdDet_vDvtSpdMin_C));

        /* Update for Memory: '<S172>/Memory' */
        LKAS_DW.Memory_PreviousInput_n0 = rtb_Abs_pw;
      } else {
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S172>/Out' */
          LKAS_DW.RelationalOperator_ew = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }
      }

      /* End of Logic: '<S170>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S170>/Sum Condition1' */

      /* Memory: '<S171>/Memory' */
      rtb_Gain2_b = LKAS_DW.Memory_PreviousInput_mo;

      /* Sum: '<S171>/Add2' */
      rtb_Gain2_b += rtb_LKA_SampleTime;

      /* Saturate: '<S171>/Saturation2' */
      if (rtb_Gain2_b > 10.0F) {
        rtb_Saturation2_n = 10.0F;
      } else if (rtb_Gain2_b < 0.0F) {
        rtb_Saturation2_n = 0.0F;
      } else {
        rtb_Saturation2_n = rtb_Gain2_b;
      }

      /* End of Saturate: '<S171>/Saturation2' */

      /* Gain: '<S171>/Gain' */
      rtb_Gain2_b = rtb_LL_ThresDet_lDvtThresUprLKA * 0.333333343F;

      /* Logic: '<S171>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S171>/Relational Operator2'
       *  RelationalOperator: '<S171>/Relational Operator3'
       *  RelationalOperator: '<S171>/Relational Operator4'
       */
      rtb_LogicalOperator3_b5 = (((rtb_Saturation2_n >= rtb_Saturation6) &&
        (rtb_Gain1 >= rtb_Gain2_b)) && (rtb_Add5_n >= rtb_Gain2_b));

      /* Abs: '<S171>/Abs4' */
      rtb_Gain2_b = rtb_TTLC_n;

      /* Saturate: '<S171>/Saturation' */
      if (rtb_Gain2_b > 0.004F) {
        rtb_Gain2_b = 0.004F;
      } else {
        if (rtb_Gain2_b < 0.0F) {
          rtb_Gain2_b = 0.0F;
        }
      }

      /* End of Saturate: '<S171>/Saturation' */

      /* Switch: '<S656>/Switch45' incorporates:
       *  Constant: '<S656>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S656>/Switch45' */

      /* Sum: '<S171>/Add6' incorporates:
       *  Constant: '<S171>/Constant'
       *  Constant: '<S171>/Constant7'
       *  Product: '<S171>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Gain2_b) / 0.004F) + x10;

      /* Outputs for Atomic SubSystem: '<S157>/Moving Standard Deviation2' */
      LKAS_MovingStandardDeviation2(rtb_IMAPve_g_EPS_SW_Trq, &rtb_kphTomps_j,
        &rtb_Merge_e, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S157>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S171>/Moving Standard Deviation1' */
      rtb_Gain_m = (float32) LKAS_MovingStandardDeviation1(rtb_Add5_n,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S171>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S171>/Relational Operator6' */
      rtb_RelationalOperator6_i = (rtb_Gain_m <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S171>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_i, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_k3, &LKAS_DW.SumCondition1_j);

      /* End of Outputs for SubSystem: '<S171>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S171>/Moving Standard Deviation2' */
      rtb_Gain_m = (float32) LKAS_MovingStandardDeviation1(rtb_Gain1,
        &LKAS_DW.MovingStandardDeviation2_d);

      /* End of Outputs for SubSystem: '<S171>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S171>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain_m <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S171>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_e, &LKAS_DW.SumCondition_c);

      /* End of Outputs for SubSystem: '<S171>/Sum Condition' */

      /* RelationalOperator: '<S181>/Compare' incorporates:
       *  Constant: '<S181>/Constant'
       *  Constant: '<S656>/LL_LKAExPrcs_ExitC0Swt=1'
       *  Logic: '<S171>/Logical Operator2'
       *  Switch: '<S656>/Switch46'
       */
      rtb_Compare_az = (((sint32)((((rtb_LogicalOperator3_b5 &&
        (LKAS_DW.RelationalOperator_k3)) && (LKAS_DW.RelationalOperator_e)) &&
        ((LKAS_ConstB.DataTypeConversion35) || (LL_LKAExPrcs_ExitC0Swt))) ? 1 :
        0)) > ((sint32)(false ? 1 : 0)));

      /* Memory: '<S171>/Memory1' */
      rtb_Memory1 = LKAS_DW.Memory1_PreviousInput_k;

      /* If: '<S171>/If' incorporates:
       *  Constant: '<S174>/Constant'
       *  RelationalOperator: '<S173>/FixPt Relational Operator'
       *  UnitDelay: '<S173>/Delay Input1'
       *
       * Block description for '<S173>/Delay Input1':
       *
       *  Store in Global RAM
       */
      if (((sint32)(rtb_Compare_az ? 1 : 0)) > ((sint32)
           (LKAS_DW.DelayInput1_DSTATE_px ? 1 : 0))) {
        /* Outputs for IfAction SubSystem: '<S171>/If Action Subsystem' incorporates:
         *  ActionPort: '<S174>/Action Port'
         */
        rtb_Merge_ba = true;

        /* End of Outputs for SubSystem: '<S171>/If Action Subsystem' */
      } else {
        /* Outputs for IfAction SubSystem: '<S171>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S175>/Action Port'
         */
        LKAS_IfActionSubsystem3(rtb_Memory1, &rtb_Merge_ba);

        /* End of Outputs for SubSystem: '<S171>/If Action Subsystem3' */
      }

      /* End of If: '<S171>/If' */

      /* Outputs for Enabled SubSystem: '<S157>/Sum Condition2' incorporates:
       *  EnablePort: '<S161>/state = reset'
       */
      /* Outputs for Enabled SubSystem: '<S171>/Sum Condition2' incorporates:
       *  EnablePort: '<S180>/state = reset'
       */
      if (rtb_Merge_ba) {
        if (!LKAS_DW.SumCondition2_MODE) {
          /* InitializeConditions for Memory: '<S180>/Memory' */
          LKAS_DW.Memory_PreviousInput_ik = 0.0F;
          LKAS_DW.SumCondition2_MODE = true;
        }

        /* Sum: '<S180>/Add1' incorporates:
         *  Memory: '<S180>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_ik;

        /* Saturate: '<S180>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S180>/Saturation' */

        /* RelationalOperator: '<S180>/Relational Operator' */
        LKAS_DW.RelationalOperator_h = (rtb_LL_LKAExPrcs_tiExitTime2 >=
          rtb_LL_LKAExPrcs_tiExitDelayTim);

        /* Update for Memory: '<S180>/Memory' */
        LKAS_DW.Memory_PreviousInput_ik = rtb_LL_LKAExPrcs_tiExitTime2;
        if (!LKAS_DW.SumCondition2_MODE_g) {
          /* InitializeConditions for Memory: '<S161>/Memory' */
          LKAS_DW.Memory_PreviousInput_m4 = 0.0F;
          LKAS_DW.SumCondition2_MODE_g = true;
        }

        /* Sum: '<S161>/Add1' incorporates:
         *  Memory: '<S161>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_m4;

        /* Saturate: '<S161>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime2 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime2 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime2 = 0.0F;
          }
        }

        /* End of Saturate: '<S161>/Saturation' */

        /* Switch: '<S656>/Switch28' incorporates:
         *  Constant: '<S656>/LL_LKASWASyn_M4K=0.1'
         */
        if (LKAS_ConstB.DataTypeConversion42 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion42;
        } else {
          x10 = LL_LKASWASyn_M4K;
        }

        /* End of Switch: '<S656>/Switch28' */

        /* Sum: '<S161>/Add2' incorporates:
         *  Constant: '<S161>/Constant1'
         */
        rtb_LftTTLC = x10 - 1.0F;

        /* Product: '<S161>/Divide' */
        rtb_LL_LKAExPrcs_tiExitDelayTim = rtb_LL_LKAExPrcs_tiExitTime2 /
          rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Saturate: '<S161>/Saturation1' */
        if (rtb_LL_LKAExPrcs_tiExitDelayTim > 1.0F) {
          rtb_LL_LKAExPrcs_tiExitDelayTim = 1.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitDelayTim < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitDelayTim = 0.0F;
          }
        }

        /* End of Saturate: '<S161>/Saturation1' */

        /* Saturate: '<S161>/Saturation2' */
        if (rtb_LftTTLC > 0.0F) {
          rtb_LftTTLC = 0.0F;
        } else {
          if (rtb_LftTTLC < (-1.0F)) {
            rtb_LftTTLC = (-1.0F);
          }
        }

        /* End of Saturate: '<S161>/Saturation2' */

        /* Sum: '<S161>/Add3' incorporates:
         *  Constant: '<S161>/Constant2'
         *  Product: '<S161>/Divide1'
         */
        rtb_LftTTLC = (rtb_LL_LKAExPrcs_tiExitDelayTim * rtb_LftTTLC) + 1.0F;

        /* Saturate: '<S161>/Saturation3' */
        if (rtb_LftTTLC > 1.0F) {
          LKAS_DW.Saturation3 = 1.0F;
        } else if (rtb_LftTTLC < 0.0F) {
          LKAS_DW.Saturation3 = 0.0F;
        } else {
          LKAS_DW.Saturation3 = rtb_LftTTLC;
        }

        /* End of Saturate: '<S161>/Saturation3' */

        /* Update for Memory: '<S161>/Memory' */
        LKAS_DW.Memory_PreviousInput_m4 = rtb_LL_LKAExPrcs_tiExitTime2;
      } else {
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S180>/Out' */
          LKAS_DW.RelationalOperator_h = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        if (LKAS_DW.SumCondition2_MODE_g) {
          LKAS_DW.SumCondition2_MODE_g = false;
        }
      }

      /* End of Outputs for SubSystem: '<S171>/Sum Condition2' */
      /* End of Outputs for SubSystem: '<S157>/Sum Condition2' */

      /* Fcn: '<S150>/Fcn' incorporates:
       *  DataTypeConversion: '<S150>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((LKAS_DW.RelationalOperator_h ? 1 : 0) *
        (LKAS_DW.RelationalOperator_h ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!LKAS_DW.RelationalOperator_h) ? 1 : 0)) *
        (LKAS_DW.RelationalOperator_ew ? 1 : 0)) * ((sint32)2.0F))) + (((sint32)
        (((!LKAS_DW.RelationalOperator_ew) && (!LKAS_DW.RelationalOperator_h)) ?
         1 : 0)) * (rtb_BCM_Right_Light ? 1 : 0))));

      /* Logic: '<S150>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_BCM_Right_Light ||
        (LKAS_DW.RelationalOperator_ew)) || (LKAS_DW.RelationalOperator_h));

      /* DataTypeConversion: '<S153>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon_l = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Sum: '<S157>/Add' */
      rtb_Gain2_b = rtb_IMAPve_g_EPS_SW_Trq - rtb_kphTomps_j;

      /* Saturate: '<S157>/Saturation4' */
      if (rtb_Gain2_b > 2.0F) {
        rtb_Gain2_b = 2.0F;
      } else {
        if (rtb_Gain2_b < 0.0F) {
          rtb_Gain2_b = 0.0F;
        }
      }

      /* End of Saturate: '<S157>/Saturation4' */

      /* Abs: '<S157>/Abs' */
      rtb_Gain2_b = fabsf(rtb_Gain2_b);

      /* Saturate: '<S157>/Saturation7' */
      if (rtb_Gain2_b > 1.0F) {
        rtb_Gain2_b = 1.0F;
      } else {
        if (rtb_Gain2_b < 0.0F) {
          rtb_Gain2_b = 0.0F;
        }
      }

      /* End of Saturate: '<S157>/Saturation7' */

      /* Switch: '<S656>/Switch26' incorporates:
       *  Constant: '<S656>/LL_LKASWASyn_M3D=0.5'
       */
      if (LKAS_ConstB.DataTypeConversion40 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion40;
      } else {
        x10 = LL_LKASWASyn_M3D;
      }

      /* End of Switch: '<S656>/Switch26' */

      /* Product: '<S157>/Divide2' */
      rtb_Gain2_b /= x10;

      /* Saturate: '<S157>/Saturation5' */
      if (rtb_Gain2_b > 1.0F) {
        rtb_Gain2_b = 1.0F;
      } else {
        if (rtb_Gain2_b < 0.0F) {
          rtb_Gain2_b = 0.0F;
        }
      }

      /* End of Saturate: '<S157>/Saturation5' */

      /* Switch: '<S656>/Switch18' incorporates:
       *  Constant: '<S656>/LL_LKASWASyn_M3K_DT=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion25;
      } else {
        x10 = LL_LKASWASyn_M3K_DT;
      }

      /* End of Switch: '<S656>/Switch18' */

      /* Product: '<S157>/Divide1' */
      rtb_Gain2_b *= x10;

      /* Saturate: '<S157>/Saturation3' */
      if (rtb_Gain2_b > 0.4F) {
        rtb_Gain2_b = 0.4F;
      } else {
        if (rtb_Gain2_b < 0.0F) {
          rtb_Gain2_b = 0.0F;
        }
      }

      /* End of Saturate: '<S157>/Saturation3' */

      /* Switch: '<S656>/Switch27' incorporates:
       *  Constant: '<S656>/LL_LKASWASyn_M3K_MSD=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion41 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion41;
      } else {
        x10 = LL_LKASWASyn_M3K_MSD;
      }

      /* End of Switch: '<S656>/Switch27' */

      /* Product: '<S157>/Divide' */
      rtb_Divide3_j = rtb_Merge_e * x10;

      /* Saturate: '<S157>/Saturation1' */
      if (rtb_Divide3_j > 0.4F) {
        rtb_Divide3_j = 0.4F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S157>/Saturation1' */

      /* Sum: '<S162>/Add2' incorporates:
       *  Memory: '<S162>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_e;

      /* Saturate: '<S162>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_gi = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_gi = 0.0F;
      } else {
        rtb_Saturation_gi = rtb_LftTTLC;
      }

      /* End of Saturate: '<S162>/Saturation' */

      /* MATLAB Function: '<S157>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Driver Torque Assist/MATLAB Function': '<S159>:1' */
      /* '<S159>:1:2' if T<T1 */
      if (rtb_Saturation_gi < rtb_Saturation6) {
        /* '<S159>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_LL_LKASWASyn_M0 += ((rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6) * rtb_Saturation_gi;
      } else if ((rtb_Saturation_gi >= rtb_Saturation6) && (rtb_Saturation_gi <=
                  (rtb_Saturation6 + rtb_LL_LKASWASyn_T2))) {
        /* Switch: '<S656>/Switch14' incorporates:
         *  Constant: '<S656>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S159>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S159>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_i != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_i;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (((x10 - rtb_LL_LKASWASyn_M1) /
          rtb_LL_LKASWASyn_T2) * (rtb_Saturation_gi - rtb_Saturation6)) +
          rtb_LL_LKASWASyn_M1;
      } else {
        /* Switch: '<S656>/Switch14' incorporates:
         *  Constant: '<S656>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S159>:1:6' else */
        /* '<S159>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_i != 0.0F) {
          rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20_i;
        } else {
          rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S157>/MATLAB Function' */

      /* Sum: '<S157>/Add1' */
      rtb_Gain2_b = (rtb_LL_LKASWASyn_M0 - rtb_Gain2_b) - rtb_Divide3_j;

      /* Saturate: '<S157>/Saturation6' */
      if (rtb_Gain2_b > 1.0F) {
        rtb_Gain2_b = 1.0F;
      } else {
        if (rtb_Gain2_b < 0.01F) {
          rtb_Gain2_b = 0.01F;
        }
      }

      /* End of Saturate: '<S157>/Saturation6' */

      /* Product: '<S157>/Divide5' */
      rtb_Gain2_b *= LKAS_DW.Saturation3;

      /* Saturate: '<S157>/Saturation2' */
      if (rtb_Gain2_b > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Gain2_b < 0.01F) {
        LKAS_DW.Saturation2 = 0.01F;
      } else {
        LKAS_DW.Saturation2 = rtb_Gain2_b;
      }

      /* End of Saturate: '<S157>/Saturation2' */

      /* Outputs for Enabled SubSystem: '<S149>/Subsystem' incorporates:
       *  EnablePort: '<S158>/Enable'
       */
      /* RelationalOperator: '<S156>/Compare' incorporates:
       *  Constant: '<S156>/Constant'
       *  Constant: '<S656>/LL_LKASWASyn_TrqSwaAddSwt=1'
       *  Switch: '<S656>/Switch47'
       */
      if (((sint32)(((LKAS_ConstB.DataTypeConversion47_j) ||
                     (LL_LKASWASyn_TrqSwaAddSwt)) ? 1 : 0)) > ((sint32)(false ?
            1 : 0))) {
        if (!LKAS_DW.Subsystem_MODE_l) {
          LKAS_DW.Subsystem_MODE_l = true;
        }

        /* MATLAB Function: '<S158>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S163>:1' */
        /* '<S163>:1:2' Swaadd=single(0); */
        /* '<S163>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S163>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S163>:1:5' l0c0=abs(l0c0); */
        /* '<S163>:1:6' r0c0=abs(r0c0); */
        /* '<S163>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_LL_LKASWASyn_M1 = fmaxf(fminf(rtb_LKA_Veh2CamW_C + rtb_Add5_n_tmp,
          5.4F), 2.5F);

        /* '<S163>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_LL_LKASWASyn_M1 > 2.5F) && (rtb_LL_LKASWASyn_M1 < 5.4F)) {
          /* '<S163>:1:9' leftlane=l0c0/lanewidth; */
          rtb_LL_LKASWASyn_T2 = rtb_LKA_Veh2CamW_C / rtb_LL_LKASWASyn_M1;

          /* '<S163>:1:10' rightlane=r0c0/lanewidth; */
          rtb_LL_LKASWASyn_M0 = rtb_Add5_n_tmp / rtb_LL_LKASWASyn_M1;
        } else {
          /* '<S163>:1:11' else */
          /* '<S163>:1:12' leftlane=single(0.5); */
          rtb_LL_LKASWASyn_T2 = 0.5F;

          /* '<S163>:1:13' rightlane=single(0.5); */
          rtb_LL_LKASWASyn_M0 = 0.5F;
        }

        /* '<S163>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S163>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S163>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S656>/Switch42' incorporates:
           *  Constant: '<S656>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S163>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S656>/Switch43' incorporates:
           *  Constant: '<S656>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M0 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_LL_LKASWASyn_T2) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S656>/Switch42' incorporates:
           *  Constant: '<S656>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S163>:1:19' else */
          /* '<S163>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S656>/Switch43' incorporates:
           *  Constant: '<S656>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKASWASyn_M0 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_LL_LKASWASyn_M0) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S164>/Add2' incorporates:
         *  Constant: '<S164>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S164>/Memory3'
         */
        rtb_LL_LKASWASyn_M1 = 1.0F + LKAS_DW.Memory3_PreviousInput_a;

        /* Saturate: '<S164>/Saturation' */
        if (rtb_LL_LKASWASyn_M1 > 50.0F) {
          rtb_LL_LKASWASyn_M1 = 50.0F;
        } else {
          if (rtb_LL_LKASWASyn_M1 < 0.0F) {
            rtb_LL_LKASWASyn_M1 = 0.0F;
          }
        }

        /* End of Saturate: '<S164>/Saturation' */

        /* Switch: '<S164>/Switch' incorporates:
         *  Product: '<S164>/Divide'
         *  Product: '<S164>/Divide1'
         *  Sum: '<S164>/Add'
         *  Sum: '<S164>/Add1'
         *  UnitDelay: '<S164>/Unit Delay'
         */
        if (rtb_LL_LKASWASyn_M1 > 1.0F) {
          /* Switch: '<S656>/Switch50' incorporates:
           *  Constant: '<S656>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S656>/Switch50' */
          rtb_LL_LKASWASyn_M0 = ((rtb_LKA_SampleTime / x10) *
            (rtb_LL_LKASWASyn_M0 - LKAS_DW.UnitDelay_DSTATE_n)) +
            LKAS_DW.UnitDelay_DSTATE_n;
        }

        /* End of Switch: '<S164>/Switch' */

        /* SampleTimeMath: '<S167>/TSamp'
         *
         * About '<S167>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_LKASWASyn_T2 = rtb_LL_LKASWASyn_M0 * 100.0F;

        /* Sum: '<S165>/Add2' incorporates:
         *  Constant: '<S165>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S165>/Memory3'
         */
        rtb_LL_LKAExPrcs_tiExitDelayTim = 1.0F +
          LKAS_DW.Memory3_PreviousInput_e4;

        /* Saturate: '<S165>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitDelayTim > 50.0F) {
          rtb_LL_LKAExPrcs_tiExitDelayTim = 50.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitDelayTim < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitDelayTim = 0.0F;
          }
        }

        /* End of Saturate: '<S165>/Saturation' */

        /* Switch: '<S165>/Switch' incorporates:
         *  Product: '<S165>/Divide'
         *  Product: '<S165>/Divide1'
         *  Sum: '<S165>/Add'
         *  Sum: '<S165>/Add1'
         *  Sum: '<S167>/Diff'
         *  UnitDelay: '<S165>/Unit Delay'
         *  UnitDelay: '<S167>/UD'
         *
         * Block description for '<S167>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S167>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_LKAExPrcs_tiExitDelayTim > 2.0F) {
          /* Switch: '<S656>/Switch52' incorporates:
           *  Constant: '<S656>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S656>/Switch52' */
          rtb_LL_LKAExPrcs_tiExitTime2 = (((rtb_LL_LKASWASyn_T2 -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_nl) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_nl;
        } else {
          rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LL_LKASWASyn_T2 - LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S165>/Switch' */

        /* Saturate: '<S158>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime2 > 30.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 30.0F;
        } else if (rtb_LL_LKAExPrcs_tiExitTime2 < (-30.0F)) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = (-30.0F);
        } else {
          rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LL_LKAExPrcs_tiExitTime2;
        }

        /* End of Saturate: '<S158>/Saturation' */

        /* Switch: '<S656>/Switch53' incorporates:
         *  Constant: '<S656>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S656>/Switch53' */

        /* Sum: '<S166>/Difference Inputs1' incorporates:
         *  Product: '<S158>/Divide1'
         *  Product: '<S158>/Divide3'
         *  Sum: '<S158>/Add'
         *  UnitDelay: '<S166>/Delay Input2'
         *
         * Block description for '<S166>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S166>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_LKAExPrcs_ExitC0Dvt = ((rtb_LL_LKAExPrcs_ExitC0Dvt * x10) +
          rtb_LL_LKASWASyn_M0) - LKAS_DW.DelayInput2_DSTATE_o;

        /* Product: '<S166>/delta rise limit' incorporates:
         *  Constant: '<S158>/Constant1'
         *  SampleTimeMath: '<S166>/sample time'
         *
         * About '<S166>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = 5.0F * 0.01F;

        /* Product: '<S166>/delta fall limit' incorporates:
         *  Constant: '<S158>/Constant2'
         *  SampleTimeMath: '<S166>/sample time'
         *
         * About '<S166>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_Abs_pw = (-5.0F) * 0.01F;

        /* Switch: '<S168>/Switch2' incorporates:
         *  Product: '<S166>/delta fall limit'
         *  Product: '<S166>/delta rise limit'
         *  RelationalOperator: '<S168>/LowerRelop1'
         *  RelationalOperator: '<S168>/UpperRelop'
         *  Switch: '<S168>/Switch'
         */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > rtb_LL_DvtSpdDet_vDvtSpdMin_C) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LL_DvtSpdDet_vDvtSpdMin_C;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < rtb_Abs_pw) {
            /* Switch: '<S168>/Switch' incorporates:
             *  Product: '<S166>/delta fall limit'
             */
            rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_Abs_pw;
          }
        }

        /* End of Switch: '<S168>/Switch2' */

        /* Sum: '<S166>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S166>/Delay Input2'
         *
         * Block description for '<S166>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S166>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_g = rtb_LL_LKAExPrcs_ExitC0Dvt +
          LKAS_DW.DelayInput2_DSTATE_o;

        /* Update for UnitDelay: '<S164>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_n = rtb_LL_LKASWASyn_M0;

        /* Update for Memory: '<S164>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_a = rtb_LL_LKASWASyn_M1;

        /* Update for UnitDelay: '<S167>/UD'
         *
         * Block description for '<S167>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_LKASWASyn_T2;

        /* Update for UnitDelay: '<S165>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_nl = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for Memory: '<S165>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e4 = rtb_LL_LKAExPrcs_tiExitDelayTim;

        /* Update for UnitDelay: '<S166>/Delay Input2'
         *
         * Block description for '<S166>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_o = LKAS_DW.DifferenceInputs2_g;
      } else {
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S158>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_g = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }
      }

      /* End of RelationalOperator: '<S156>/Compare' */
      /* End of Outputs for SubSystem: '<S149>/Subsystem' */

      /* Sum: '<S263>/Add2' incorporates:
       *  Memory: '<S263>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_p;

      /* Saturate: '<S263>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_e = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_e = 0.0F;
      } else {
        rtb_Saturation_e = rtb_LftTTLC;
      }

      /* End of Saturate: '<S263>/Saturation' */

      /* If: '<S261>/If' incorporates:
       *  DataTypeConversion: '<S140>/Cast To Single'
       *  Inport: '<S269>/Plan'
       *  Inport: '<S269>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_l;
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_l = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S261>/If Action Subsystem' incorporates:
           *  ActionPort: '<S267>/Action Port'
           */
          /* InitializeConditions for If: '<S261>/If' incorporates:
           *  Memory: '<S267>/Memory'
           *  UnitDelay: '<S271>/Delay Input1'
           *
           * Block description for '<S271>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_b = false;
          LKAS_DW.Memory_PreviousInput_ge = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S261>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S261>/If Action Subsystem' incorporates:
         *  ActionPort: '<S267>/Action Port'
         */
        /* RelationalOperator: '<S270>/Compare' incorporates:
         *  Constant: '<S270>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Lft >= 0.0F);

        /* Memory: '<S267>/Memory' */
        rtb_Plan_g = LKAS_DW.Memory_PreviousInput_ge;

        /* Sum: '<S267>/Add' incorporates:
         *  Logic: '<S267>/Logical Operator'
         *  RelationalOperator: '<S267>/Relational Operator'
         *  RelationalOperator: '<S271>/FixPt Relational Operator'
         *  UnitDelay: '<S271>/Delay Input1'
         *
         * Block description for '<S271>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_g = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_b ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_e)) ? 1 : 0)) + rtb_Plan_g;

        /* Saturate: '<S267>/Saturation' */
        if (rtb_T1_g > 5.0F) {
          rtb_Saturation_ae = 5.0F;
        } else if (rtb_T1_g < 0.0F) {
          rtb_Saturation_ae = 0.0F;
        } else {
          rtb_Saturation_ae = rtb_T1_g;
        }

        /* End of Saturate: '<S267>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S267>/If Action Subsystem' */
        LKAS_IfActionSubsystem_n(rtb_Saturation_ae, rtb_Saturation_e,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_i, &LKAS_DW.In_g,
          &LKAS_DW.IfActionSubsystem_n4);

        /* End of Outputs for SubSystem: '<S267>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S267>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_a(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_g, &rtb_Plan_g);

        /* End of Outputs for SubSystem: '<S267>/If Action Subsystem2' */

        /* Switch: '<S267>/Switch' incorporates:
         *  Switch: '<S267>/Switch1'
         */
        if (rtb_Saturation_ae > 0.0F) {
          LKAS_DW.Merge_e = LKAS_DW.In_i;
          LKAS_DW.Merge1 = LKAS_DW.In_g;
        } else {
          LKAS_DW.Merge_e = rtb_T1_g;
          LKAS_DW.Merge1 = rtb_Plan_g;
        }

        /* End of Switch: '<S267>/Switch' */

        /* Update for UnitDelay: '<S271>/Delay Input1'
         *
         * Block description for '<S271>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_b = rtb_BCM_Right_Light;

        /* Update for Memory: '<S267>/Memory' */
        LKAS_DW.Memory_PreviousInput_ge = rtb_Saturation_ae;

        /* End of Outputs for SubSystem: '<S261>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S261>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S268>/Action Port'
           */
          /* InitializeConditions for If: '<S261>/If' incorporates:
           *  Memory: '<S268>/Memory'
           *  UnitDelay: '<S279>/Delay Input1'
           *
           * Block description for '<S279>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_m = false;
          LKAS_DW.Memory_PreviousInput_ph = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S261>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S261>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S268>/Action Port'
         */
        /* RelationalOperator: '<S278>/Compare' incorporates:
         *  Constant: '<S278>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Rgt <= 0.0F);

        /* Memory: '<S268>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_ph;

        /* Sum: '<S268>/Add' incorporates:
         *  Logic: '<S268>/Logical Operator'
         *  RelationalOperator: '<S268>/Relational Operator'
         *  RelationalOperator: '<S279>/FixPt Relational Operator'
         *  UnitDelay: '<S279>/Delay Input1'
         *
         * Block description for '<S279>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_i = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_m ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_e)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S268>/Saturation' */
        if (rtb_T1_i > 5.0F) {
          rtb_Saturation_gv = 5.0F;
        } else if (rtb_T1_i < 0.0F) {
          rtb_Saturation_gv = 0.0F;
        } else {
          rtb_Saturation_gv = rtb_T1_i;
        }

        /* End of Saturate: '<S268>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S268>/If Action Subsystem' */
        LKAS_IfActionSubsystem_n(rtb_Saturation_gv, rtb_Saturation_e,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_j, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_g);

        /* End of Outputs for SubSystem: '<S268>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S268>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_a(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_i, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S268>/If Action Subsystem2' */

        /* Switch: '<S268>/Switch' incorporates:
         *  Switch: '<S268>/Switch1'
         */
        if (rtb_Saturation_gv > 0.0F) {
          LKAS_DW.Merge_e = LKAS_DW.In_j;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_e = rtb_T1_i;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S268>/Switch' */

        /* Update for UnitDelay: '<S279>/Delay Input1'
         *
         * Block description for '<S279>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_m = rtb_BCM_Right_Light;

        /* Update for Memory: '<S268>/Memory' */
        LKAS_DW.Memory_PreviousInput_ph = rtb_Saturation_gv;

        /* End of Outputs for SubSystem: '<S261>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S261>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S269>/Action Port'
         */
        LKAS_DW.Merge_e = rtb_Saturation6;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S261>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S261>/If' */

      /* Saturate: '<S155>/Saturation6' */
      if (LKAS_DW.Merge_e > 0.5F) {
        rtb_LL_LKASWASyn_M0 = 0.5F;
      } else if (LKAS_DW.Merge_e < 0.2F) {
        rtb_LL_LKASWASyn_M0 = 0.2F;
      } else {
        rtb_LL_LKASWASyn_M0 = LKAS_DW.Merge_e;
      }

      /* End of Saturate: '<S155>/Saturation6' */

      /* Product: '<S155>/Divide' incorporates:
       *  Product: '<S155>/Divide4'
       *  Product: '<S264>/Divide'
       *  Sum: '<S155>/Add2'
       */
      rtb_LL_LKASWASyn_M0 = (rtb_Saturation_e - LKAS_DW.Merge_e) /
        rtb_LL_LKASWASyn_M0;
      rtb_Gain2_b = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S155>/Saturation2' */
      if (rtb_Gain2_b > 1.0F) {
        rtb_Gain2_b = 1.0F;
      } else {
        if (rtb_Gain2_b < 0.0F) {
          rtb_Gain2_b = 0.0F;
        }
      }

      /* End of Saturate: '<S155>/Saturation2' */

      /* Sum: '<S155>/Add5' incorporates:
       *  Constant: '<S155>/Constant2'
       */
      rtb_LL_LKASWASyn_M1 = 1.0F - rtb_Gain2_b;

      /* Memory: '<S246>/Memory' */
      rtb_Divide3_j = LKAS_DW.Memory_PreviousInput_g;

      /* Product: '<S313>/Z*Z' incorporates:
       *  Product: '<S310>/Z*Z'
       */
      rtb_LL_LKASWASyn_T2 = rtb_LL_HdAgPrvwT_C * rtb_LL_HdAgPrvwT_C;

      /* Sum: '<S246>/Add1' incorporates:
       *  Gain: '<S292>/Gain2'
       *  Product: '<S246>/Divide'
       *  Product: '<S246>/Divide1'
       *  Product: '<S310>/Product3'
       *  Product: '<S310>/Product4'
       *  Product: '<S313>/Product3'
       *  Product: '<S313>/Product4'
       *  Product: '<S313>/Z*Z'
       *  Sum: '<S292>/Add2'
       *  Sum: '<S310>/Add'
       *  Sum: '<S313>/Add'
       */
      rtb_Add1_h = ((((((rtb_Add_p_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_m) +
                       (rtb_L0_C3_dc * rtb_LL_LKASWASyn_T2)) + (((rtb_Add_o_tmp *
        rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_i) + (rtb_L0_C3 * rtb_LL_LKASWASyn_T2)))
                     * 0.5F) * LKAS_ConstB.Divide2_k) + (LKAS_ConstB.Add2_o *
        rtb_Divide3_j);

      /* Product: '<S244>/Divide3' incorporates:
       *  Gain: '<S290>/Gain1'
       */
      rtb_Divide3_j = rtb_LL_HdAgPrvwT_C * rtb_LL_ThresDet_tiTTLCThresLDW;

      /* Gain: '<S244>/kph to mps' */
      rtb_kphtomps_l = rtb_Abs_f_tmp;

      /* MATLAB Function: '<S244>/Saturable Gain Lut (SatGainLut)' */
      LKAS_SaturableGainLutSatGainLut(rtb_IMAPve_g_ESC_VehSpd,
        rtb_LL_LFClb_TFC_KpVehSpdLwr_C, rtb_LL_LFClb_TFC_KpVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KpV1_C, rtb_LL_LFClb_TFC_KpV2_C, &rtb_Gain_m);

      /* Switch: '<S656>/Switch32' incorporates:
       *  Constant: '<S656>/LL_LFClb_TFC_PrvwT_C=2'
       */
      if (LKAS_ConstB.DataTypeConversion15_f != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_f;
      } else {
        x10 = LL_LFClb_TFC_PrvwT_C;
      }

      /* End of Switch: '<S656>/Switch32' */

      /* Product: '<S244>/Divide1' */
      rtb_LftTTLC = x10 * rtb_kphtomps_l;

      /* Switch: '<S656>/Switch30' incorporates:
       *  Constant: '<S656>/LL_LFClb_TFC_KpKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_g != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_g;
      } else {
        x10 = LL_LFClb_TFC_KpKlat_C;
      }

      /* End of Switch: '<S656>/Switch30' */

      /* Saturate: '<S244>/Saturation' */
      if (rtb_LftTTLC > 40.0F) {
        rtb_LftTTLC = 40.0F;
      } else {
        if (rtb_LftTTLC < 5.0F) {
          rtb_LftTTLC = 5.0F;
        }
      }

      /* End of Saturate: '<S244>/Saturation' */

      /* Sum: '<S244>/Subtract2' incorporates:
       *  Sum: '<S244>/Add1'
       */
      rtb_LL_HdAgPrvwT_C = rtb_Add1_h - rtb_Divide3_j;

      /* Product: '<S244>/Product4' incorporates:
       *  Gain: '<S291>/Gain1'
       *  Product: '<S244>/Divide'
       *  Product: '<S244>/Product1'
       *  Sum: '<S244>/Subtract1'
       *  Sum: '<S244>/Subtract2'
       *  Sum: '<S291>/Add1'
       */
      rtb_L0_C1_i = (((((rtb_Add_am + rtb_Add_e1) * 0.5F) / rtb_LftTTLC) * x10)
                     - rtb_LL_HdAgPrvwT_C) * rtb_Gain_m;

      /* Switch: '<S656>/Switch19' incorporates:
       *  Constant: '<S656>/LL_LFClb_TFC_Kp_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion26_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion26_h;
      } else {
        x10 = LL_LFClb_TFC_Kp_C;
      }

      /* End of Switch: '<S656>/Switch19' */

      /* Product: '<S244>/Product2' */
      rtb_Merge_e = rtb_L0_C1_i * x10;

      /* Saturate: '<S244>/Saturation2' */
      if (rtb_Merge_e > 360.0F) {
        rtb_Merge_e = 360.0F;
      } else {
        if (rtb_Merge_e < (-360.0F)) {
          rtb_Merge_e = (-360.0F);
        }
      }

      /* End of Saturate: '<S244>/Saturation2' */

      /* Abs: '<S244>/Abs' incorporates:
       *  Gain: '<S290>/Gain1'
       */
      rtb_kphTomps_j = fabsf(rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Saturate: '<S244>/Saturation1' */
      if (rtb_kphTomps_j > 0.004F) {
        rtb_kphTomps_j = 0.004F;
      } else {
        if (rtb_kphTomps_j < 1.0E-5F) {
          rtb_kphTomps_j = 1.0E-5F;
        }
      }

      /* End of Saturate: '<S244>/Saturation1' */

      /* Switch: '<S656>/Switch39' incorporates:
       *  Constant: '<S656>/LL_LFClb_TFC_KiMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_KiMaxSWA_C;
      }

      /* End of Switch: '<S656>/Switch39' */

      /* Sum: '<S244>/Add3' incorporates:
       *  Constant: '<S244>/Constant3'
       *  Constant: '<S244>/Constant4'
       *  Product: '<S244>/Divide4'
       *  Sum: '<S244>/Add5'
       */
      rtb_kphTomps_j = (((x10 - 1.0F) * rtb_kphTomps_j) / 0.004F) + 1.0F;

      /* Sum: '<S252>/Add2' incorporates:
       *  Memory: '<S252>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_m;

      /* Saturate: '<S252>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_j = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_j = 0.0F;
      } else {
        rtb_Saturation_j = rtb_LftTTLC;
      }

      /* End of Saturate: '<S252>/Saturation' */

      /* Switch: '<S244>/Switch2' incorporates:
       *  Product: '<S244>/Divide2'
       *  Sum: '<S244>/Add'
       *  Sum: '<S244>/Add2'
       *  Switch: '<S656>/Switch40'
       *  UnitDelay: '<S244>/Unit Delay'
       */
      if ((rtb_Saturation_j - rtb_Saturation6) >= 0.0F) {
        /* Switch: '<S656>/Switch40' incorporates:
         *  Constant: '<S656>/LL_LFClb_TFC_Ki_C=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_i = (rtb_L0_C1_i * x10) + LKAS_DW.UnitDelay_DSTATE_a;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S656>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S656>/Switch40' incorporates:
           *  Constant: '<S656>/LL_LFClb_TFC_Ki_C=0.01'
           */
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_i = rtb_L0_C1_i * x10;
      }

      /* End of Switch: '<S244>/Switch2' */

      /* Gain: '<S244>/Gain' */
      rtb_L0_C1_i = (-1.0F) * rtb_kphTomps_j;

      /* Switch: '<S249>/Switch' incorporates:
       *  RelationalOperator: '<S249>/UpperRelop'
       */
      if (rtb_Switch2_i < rtb_L0_C1_i) {
        rtb_Switch_k = rtb_L0_C1_i;
      } else {
        rtb_Switch_k = rtb_Switch2_i;
      }

      /* End of Switch: '<S249>/Switch' */

      /* Switch: '<S249>/Switch2' incorporates:
       *  RelationalOperator: '<S249>/LowerRelop1'
       */
      if (rtb_Switch2_i > rtb_kphTomps_j) {
        rtb_Switch2_at = rtb_kphTomps_j;
      } else {
        rtb_Switch2_at = rtb_Switch_k;
      }

      /* End of Switch: '<S249>/Switch2' */

      /* Product: '<S155>/Divide1' incorporates:
       *  Sum: '<S155>/Add3'
       */
      rtb_L0_C1_m = (rtb_Merge_e + rtb_Switch2_at) * rtb_Gain2_b;

      /* Switch: '<S656>/Switch49' incorporates:
       *  Constant: '<S656>/LL_LFClb_TFC_KdMaxSWA_C=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_KdMaxSWA_C;
      }

      /* End of Switch: '<S656>/Switch49' */

      /* Product: '<S244>/Divide8' incorporates:
       *  Constant: '<S244>/Constant7'
       *  Constant: '<S244>/Constant8'
       *  Sum: '<S244>/Add4'
       */
      rtb_kphTomps_j = ((180.0F - rtb_kphtomps_l) * x10) / 120.0F;

      /* MATLAB Function: '<S244>/Saturable Gain Lut (SatGainLut)1' */
      LKAS_SaturableGainLutSatGainLut(rtb_kphtomps_l,
        rtb_LL_LFClb_TFC_KdVehSpdLwr_C, rtb_LL_LFClb_TFC_KdVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KdV1_C, rtb_LL_LFClb_TFC_KdV2_C, &rtb_Gain_m);

      /* Product: '<S251>/Divide1' incorporates:
       *  Constant: '<S251>/Constant3'
       *  Sum: '<S251>/Add4'
       */
      rtb_Merge_e = (1.0F + rtb_R0_C1_e) * rtb_Gain_m;

      /* Gain: '<S251>/Gain' incorporates:
       *  Abs: '<S251>/Abs'
       */
      rtb_L0_C1_i = fabsf(rtb_LL_ThresDet_lDvtThresUprLKA) * 0.5F;

      /* Gain: '<S251>/Gain1' incorporates:
       *  Sum: '<S251>/Add2'
       */
      rtb_Gain1_i5 = (rtb_L0_C0_o + rtb_R0_C0_n) * 0.5F;

      /* Gain: '<S251>/Gain2' */
      rtb_Gain2_b = (-1.0F) * rtb_L0_C1_i;

      /* Switch: '<S256>/Switch' incorporates:
       *  RelationalOperator: '<S256>/UpperRelop'
       */
      if (rtb_Gain1_i5 < rtb_Gain2_b) {
        rtb_Switch_fy = rtb_Gain2_b;
      } else {
        rtb_Switch_fy = rtb_Gain1_i5;
      }

      /* End of Switch: '<S256>/Switch' */

      /* Switch: '<S256>/Switch2' incorporates:
       *  RelationalOperator: '<S256>/LowerRelop1'
       */
      if (rtb_Gain1_i5 > rtb_L0_C1_i) {
        rtb_Switch2_g1 = rtb_L0_C1_i;
      } else {
        rtb_Switch2_g1 = rtb_Switch_fy;
      }

      /* End of Switch: '<S256>/Switch2' */

      /* Product: '<S251>/Divide4' */
      rtb_L0_C1_i = (rtb_Switch2_g1 / rtb_L0_C1_i) * rtb_R0_C1_e;

      /* Product: '<S251>/Divide5' incorporates:
       *  Constant: '<S251>/Constant2'
       *  Sum: '<S251>/Add5'
       */
      rtb_Divide5_l = (1.0F + rtb_L0_C1_i) * rtb_Gain_m;

      /* Product: '<S251>/Divide2' incorporates:
       *  Constant: '<S251>/Constant2'
       *  Sum: '<S251>/Add1'
       */
      rtb_Divide2_be = (1.0F - rtb_L0_C1_i) * rtb_Gain_m;

      /* Sum: '<S258>/Add' incorporates:
       *  Constant: '<S258>/Constant'
       *  Memory: '<S258>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_f4));

      /* Saturate: '<S258>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_m = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_m = ((uint16)10000U);
      }

      /* End of Saturate: '<S258>/Saturation1' */

      /* If: '<S258>/If' incorporates:
       *  Constant: '<S258>/Constant2'
       *  DataTypeConversion: '<S140>/Cast To Single'
       *  Inport: '<S259>/In'
       */
      if (rtb_Saturation1_m == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S258>/if action ' incorporates:
         *  ActionPort: '<S259>/Action Port'
         */
        LKAS_DW.In_h = LKAS_DW.LKASM_stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S258>/if action ' */
      }

      /* End of If: '<S258>/If' */

      /* If: '<S251>/If' incorporates:
       *  Inport: '<S255>/In1'
       */
      if (((sint32)LKAS_DW.In_h) == 1) {
        /* Outputs for IfAction SubSystem: '<S251>/If Action Subsystem' incorporates:
         *  ActionPort: '<S253>/Action Port'
         */
        LKAS_IfActionSubsystem_a(rtb_Divide2_be, &rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S251>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_h) == 2) {
        /* Outputs for IfAction SubSystem: '<S251>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S254>/Action Port'
         */
        LKAS_IfActionSubsystem_a(rtb_Divide5_l, &rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S251>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S251>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S255>/Action Port'
         */
        rtb_Merge_d = rtb_Gain_m;

        /* End of Outputs for SubSystem: '<S251>/If Action Subsystem2' */
      }

      /* End of If: '<S251>/If' */

      /* Product: '<S251>/Divide3' incorporates:
       *  Constant: '<S251>/Constant1'
       *  Sum: '<S251>/Add3'
       */
      rtb_L0_C1_i = (1.0F - rtb_R0_C1_e) * rtb_Gain_m;

      /* Switch: '<S257>/Switch' incorporates:
       *  RelationalOperator: '<S257>/UpperRelop'
       */
      if (rtb_Merge_d < rtb_L0_C1_i) {
        rtb_Switch_fl = rtb_L0_C1_i;
      } else {
        rtb_Switch_fl = rtb_Merge_d;
      }

      /* End of Switch: '<S257>/Switch' */

      /* Switch: '<S257>/Switch2' incorporates:
       *  RelationalOperator: '<S257>/LowerRelop1'
       */
      if (rtb_Merge_d > rtb_Merge_e) {
        rtb_Switch2_k = rtb_Merge_e;
      } else {
        rtb_Switch2_k = rtb_Switch_fl;
      }

      /* End of Switch: '<S257>/Switch2' */

      /* Product: '<S244>/Divide7' incorporates:
       *  Gain: '<S244>/Gain1'
       */
      rtb_Divide7 = (rtb_LL_HdAgPrvwT_C * (-1.0F)) * rtb_Switch2_k;

      /* Gain: '<S244>/Gain3' */
      rtb_Merge_e = (-1.0F) * rtb_kphTomps_j;

      /* Switch: '<S250>/Switch' incorporates:
       *  RelationalOperator: '<S250>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_Merge_e) {
        rtb_Switch_pi = rtb_Merge_e;
      } else {
        rtb_Switch_pi = rtb_Divide7;
      }

      /* End of Switch: '<S250>/Switch' */

      /* Switch: '<S250>/Switch2' incorporates:
       *  RelationalOperator: '<S250>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_kphTomps_j) {
        rtb_Switch2_p = rtb_kphTomps_j;
      } else {
        rtb_Switch2_p = rtb_Switch_pi;
      }

      /* End of Switch: '<S250>/Switch2' */

      /* Product: '<S155>/Divide4' */
      rtb_kphTomps_j = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S155>/Saturation1' */
      if (rtb_kphTomps_j > 1.0F) {
        rtb_kphTomps_j = 1.0F;
      } else {
        if (rtb_kphTomps_j < 0.0F) {
          rtb_kphTomps_j = 0.0F;
        }
      }

      /* End of Saturate: '<S155>/Saturation1' */

      /* Product: '<S155>/Divide2' */
      rtb_L0_C0_o = rtb_Switch2_p * rtb_kphTomps_j;

      /* Saturate: '<S264>/Saturation4' */
      if (rtb_LL_LKASWASyn_M0 > 1.0F) {
        rtb_LL_LKASWASyn_M0 = 1.0F;
      } else {
        if (rtb_LL_LKASWASyn_M0 < 0.0F) {
          rtb_LL_LKASWASyn_M0 = 0.0F;
        }
      }

      /* End of Saturate: '<S264>/Saturation4' */

      /* Product: '<S155>/Divide5' incorporates:
       *  Constant: '<S264>/Constant1'
       *  Product: '<S264>/Divide8'
       *  Sum: '<S264>/Add1'
       */
      rtb_kphTomps_j = ((LKAS_ConstB.Add3 * rtb_LL_LKASWASyn_M0) + 0.0F) *
        rtb_LL_LKAExPrcs_tiExitTime1;

      /* Saturate: '<S155>/Saturation3' */
      if (rtb_Merge > 0.004F) {
        rtb_Merge_e = 0.004F;
      } else if (rtb_Merge < (-0.004F)) {
        rtb_Merge_e = (-0.004F);
      } else {
        rtb_Merge_e = rtb_Merge;
      }

      /* End of Saturate: '<S155>/Saturation3' */

      /* Product: '<S155>/Divide3' */
      rtb_LftTTLC = rtb_Saturation_e / LKAS_DW.Merge_e;

      /* Saturate: '<S155>/Saturation' */
      if (rtb_LftTTLC > 1.0F) {
        rtb_LftTTLC = 1.0F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S155>/Saturation' */

      /* Sum: '<S155>/Add4' incorporates:
       *  Product: '<S155>/Divide6'
       *  Product: '<S155>/Divide7'
       *  Sum: '<S155>/Add6'
       */
      rtb_L0_C0_o = (((((LKAS_DW.Merge1 + rtb_LL_LKAExPrcs_tiExitTime1) *
                        rtb_LL_LKASWASyn_M1) + rtb_L0_C1_m) + rtb_L0_C0_o) +
                     rtb_kphTomps_j) + (LKAS_DW.DifferenceInputs2_g *
        rtb_LftTTLC);

      /* Memory: '<S262>/Memory3' */
      rtb_kphTomps_j = LKAS_DW.Memory3_PreviousInput_b;

      /* Sum: '<S262>/Add2' incorporates:
       *  Constant: '<S262>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_kphTomps_j += 1.0F;

      /* Saturate: '<S262>/Saturation' */
      if (rtb_kphTomps_j > 50.0F) {
        rtb_Saturation_nf = 50.0F;
      } else if (rtb_kphTomps_j < 0.0F) {
        rtb_Saturation_nf = 0.0F;
      } else {
        rtb_Saturation_nf = rtb_kphTomps_j;
      }

      /* End of Saturate: '<S262>/Saturation' */

      /* Switch: '<S262>/Switch' incorporates:
       *  Constant: '<S155>/Constant1'
       *  Product: '<S262>/Divide'
       *  Product: '<S262>/Divide1'
       *  Sum: '<S262>/Add'
       *  Sum: '<S262>/Add1'
       *  UnitDelay: '<S262>/Unit Delay'
       */
      if (rtb_Saturation_nf > 30.0F) {
        rtb_Switch_kb = ((rtb_LKA_SampleTime / 0.1F) * (rtb_L0_C0_o -
          LKAS_DW.UnitDelay_DSTATE_g)) + LKAS_DW.UnitDelay_DSTATE_g;
      } else {
        rtb_Switch_kb = rtb_L0_C0_o;
      }

      /* End of Switch: '<S262>/Switch' */

      /* Switch: '<S656>/Switch17' incorporates:
       *  Constant: '<S656>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S656>/Switch17' */

      /* Sum: '<S152>/Add' */
      rtb_Add_of = (rtb_Switch_kb - x10) + LKAS_DW.Saturation_h;

      /* Sum: '<S152>/Add1' */
      rtb_kphTomps_j = rtb_LL_LKAExPrcs_tiExitTime1 +
        rtb_LL_LDW_LatestWarnLine_C;

      /* Sum: '<S152>/Add2' incorporates:
       *  Gain: '<S152>/Gain2'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 += (-1.0F) * rtb_LL_LDW_LatestWarnLine_C;

      /* Switch: '<S240>/Switch' incorporates:
       *  RelationalOperator: '<S240>/UpperRelop'
       */
      if (rtb_Add_of < rtb_LL_LKAExPrcs_tiExitTime1) {
        rtb_Switch_og = rtb_LL_LKAExPrcs_tiExitTime1;
      } else {
        rtb_Switch_og = rtb_Add_of;
      }

      /* End of Switch: '<S240>/Switch' */

      /* Switch: '<S240>/Switch2' incorporates:
       *  RelationalOperator: '<S240>/LowerRelop1'
       */
      if (rtb_Add_of > rtb_kphTomps_j) {
        rtb_Switch2_m = rtb_kphTomps_j;
      } else {
        rtb_Switch2_m = rtb_Switch_og;
      }

      /* End of Switch: '<S240>/Switch2' */

      /* Sum: '<S239>/Add1' incorporates:
       *  Constant: '<S239>/Constant'
       *  Memory: '<S239>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_e));

      /* Switch: '<S239>/Switch' incorporates:
       *  Constant: '<S239>/LatchTime_SY'
       *  RelationalOperator: '<S239>/Relational Operator'
       *  UnitDelay: '<S239>/Delay Input2'
       *
       * Block description for '<S239>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_h5 <= ((uint16)1U)) {
        rtb_kphTomps_j = rtb_Switch2_m;
      } else {
        rtb_kphTomps_j = LKAS_DW.DelayInput2_DSTATE_b;
      }

      /* End of Switch: '<S239>/Switch' */

      /* Sum: '<S239>/Difference Inputs1'
       *
       * Block description for '<S239>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_o = rtb_Switch2_m - rtb_kphTomps_j;

      /* SampleTimeMath: '<S239>/sample time'
       *
       * About '<S239>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_Merge_e = 0.01F;

      /* Product: '<S239>/delta rise limit' incorporates:
       *  Gain: '<S152>/Gain3'
       */
      rtb_L0_C1_i = (1.4F * rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_Merge_e;

      /* Product: '<S239>/delta fall limit' incorporates:
       *  Gain: '<S152>/Gain1'
       */
      rtb_Merge_e *= (-1.4F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S241>/Switch' incorporates:
       *  RelationalOperator: '<S241>/UpperRelop'
       */
      if (rtb_UkYk1_o < rtb_Merge_e) {
        rtb_Switch_dr = rtb_Merge_e;
      } else {
        rtb_Switch_dr = rtb_UkYk1_o;
      }

      /* End of Switch: '<S241>/Switch' */

      /* Switch: '<S241>/Switch2' incorporates:
       *  RelationalOperator: '<S241>/LowerRelop1'
       */
      if (rtb_UkYk1_o > rtb_L0_C1_i) {
        rtb_Switch2_co = rtb_L0_C1_i;
      } else {
        rtb_Switch2_co = rtb_Switch_dr;
      }

      /* End of Switch: '<S241>/Switch2' */

      /* Sum: '<S239>/Difference Inputs2'
       *
       * Block description for '<S239>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_co + rtb_kphTomps_j;

      /* Saturate: '<S239>/Saturation2' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation2_b = rtb_Saturation_h5;
      } else {
        rtb_Saturation2_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S239>/Saturation2' */

      /* DataTypeConversion: '<S153>/CastLKA3' */
      LKAS_DW.T1_Mon_g = LKAS_DW.Merge_e;

      /* If: '<S192>/If' incorporates:
       *  DataTypeConversion: '<S140>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S192>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S210>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Add_am, &rtb_Merge_fs);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S192>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S209>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Add_e1, &rtb_Merge_fs);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S192>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S211>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_fs);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem3' */
      }

      /* End of If: '<S192>/If' */

      /* If: '<S194>/If' incorporates:
       *  DataTypeConversion: '<S140>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S194>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S216>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_phiHdAg_Lft, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S194>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S194>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S215>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_phiHdAg_Rgt, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S194>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S194>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S217>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S194>/If Action Subsystem3' */
      }

      /* End of If: '<S194>/If' */

      /* DataTypeConversion: '<S234>/Data Type Conversion' incorporates:
       *  Constant: '<S235>/Constant'
       *  RelationalOperator: '<S235>/Compare'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((rtb_Merge <= 0.0F) ? 1 : 0);

      /* Gain: '<S230>/kph To mps' */
      rtb_kphTomps_j = rtb_Abs_f_tmp;

      /* Switch: '<S656>/Switch5' incorporates:
       *  Constant: '<S656>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_p != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_p;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S656>/Switch5' */

      /* Product: '<S234>/Divide' */
      rtb_Merge_e = (rtb_Merge * rtb_kphTomps_j) * x10;

      /* Abs: '<S234>/Abs1' incorporates:
       *  Abs: '<S234>/Abs'
       */
      rtb_L0_C0_o = fabsf(rtb_Merge_e);
      rtb_Abs1_g = rtb_L0_C0_o;

      /* Abs: '<S234>/Abs' */
      rtb_Abs_h = rtb_L0_C0_o;

      /* If: '<S234>/If' incorporates:
       *  DataTypeConversion: '<S140>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) && (((sint32)
            rtb_IMAPve_d_BCM_HazardLamp) == 0)) {
        /* Outputs for IfAction SubSystem: '<S234>/If Action Subsystem' incorporates:
         *  ActionPort: '<S236>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_h, &rtb_Merge_e);

        /* End of Outputs for SubSystem: '<S234>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) && (((sint32)
                   rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
        /* Outputs for IfAction SubSystem: '<S234>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S238>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_g, &rtb_Merge_e);

        /* End of Outputs for SubSystem: '<S234>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S234>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S237>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_e);

        /* End of Outputs for SubSystem: '<S234>/If Action Subsystem2' */
      }

      /* End of If: '<S234>/If' */

      /* Switch: '<S656>/Switch6' incorporates:
       *  Constant: '<S656>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_g != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_g;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S656>/Switch6' */

      /* Sum: '<S230>/Add1' incorporates:
       *  Product: '<S230>/Divide'
       *  Product: '<S230>/Divide1'
       */
      rtb_Add1_kd = (((1.0F / x10) * rtb_LL_ThresDet_lDvtThresUprLKA) /
                     rtb_kphTomps_j) + rtb_Merge_e;

      /* If: '<S186>/If' incorporates:
       *  Constant: '<S233>/Constant2'
       *  DataTypeConversion: '<S140>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S186>/If Action Subsystem' incorporates:
         *  ActionPort: '<S231>/Action Port'
         */
        /* Gain: '<S231>/Gain2' */
        rtb_Merge_f = (-1.0F) * rtb_Add1_kd;

        /* End of Outputs for SubSystem: '<S186>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S186>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S232>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_kd, &rtb_Merge_f);

        /* End of Outputs for SubSystem: '<S186>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S186>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S233>/Action Port'
         */
        rtb_Merge_f = 0.0F;

        /* End of Outputs for SubSystem: '<S186>/If Action Subsystem2' */
      }

      /* End of If: '<S186>/If' */

      /* Sum: '<S195>/Add' incorporates:
       *  Constant: '<S195>/Constant'
       *  Memory: '<S195>/Memory'
       */
      rtb_Add_jk = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_b));

      /* Saturate: '<S195>/Saturation1' */
      if (rtb_Add_jk < ((uint16)10000U)) {
        rtb_Saturation_h5 = rtb_Add_jk;
      } else {
        rtb_Saturation_h5 = ((uint16)10000U);
      }

      /* End of Saturate: '<S195>/Saturation1' */

      /* If: '<S195>/If' incorporates:
       *  Constant: '<S195>/Constant2'
       */
      if (rtb_Saturation_h5 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S195>/if action ' incorporates:
         *  ActionPort: '<S218>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_f, &rtb_In_a);

        /* End of Outputs for SubSystem: '<S195>/if action ' */
      }

      /* End of If: '<S195>/If' */

      /* Sum: '<S197>/Add' incorporates:
       *  Constant: '<S197>/Constant'
       *  Memory: '<S197>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_l));

      /* Saturate: '<S197>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_or = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_or = ((uint16)10000U);
      }

      /* End of Saturate: '<S197>/Saturation1' */

      /* If: '<S197>/If' incorporates:
       *  Constant: '<S197>/Constant2'
       */
      if (rtb_Saturation1_or == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S197>/if action ' incorporates:
         *  ActionPort: '<S220>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_fs, &rtb_In_j);

        /* End of Outputs for SubSystem: '<S197>/if action ' */
      }

      /* End of If: '<S197>/If' */

      /* Sum: '<S198>/Add' incorporates:
       *  Constant: '<S198>/Constant'
       *  Memory: '<S198>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_oj));

      /* Saturate: '<S198>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_p = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_p = ((uint16)10000U);
      }

      /* End of Saturate: '<S198>/Saturation1' */

      /* If: '<S198>/If' incorporates:
       *  Constant: '<S198>/Constant2'
       */
      if (rtb_Saturation1_p == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S198>/if action ' incorporates:
         *  ActionPort: '<S221>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_k, &rtb_In);

        /* End of Outputs for SubSystem: '<S198>/if action ' */
      }

      /* End of If: '<S198>/If' */

      /* DataTypeConversion: '<S183>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_IMAPve_g_ESC_VehSpd;

      /* DataTypeConversion: '<S153>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon_p = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S187>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S170>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S172>/Out' */
          LKAS_DW.RelationalOperator_ew = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S170>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_j.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_k3,
            &LKAS_DW.SumCondition1_j);
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition' */
        if (LKAS_DW.SumCondition_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_e,
            &LKAS_DW.SumCondition_c);
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S180>/Out' */
          LKAS_DW.RelationalOperator_h = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S157>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_g) {
          LKAS_DW.SumCondition2_MODE_g = false;
        }

        /* End of Disable for SubSystem: '<S157>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S149>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S158>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_g = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S149>/Subsystem' */

        /* Disable for If: '<S261>/If' */
        LKAS_DW.If_ActiveSubsystem_l = -1;

        /* Disable for Outport: '<S140>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S140>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S140>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S140>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_l = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_p = 0.0F;
        LKAS_DW.T1_Mon_g = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon_l;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon_p;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.T1_Mon = LKAS_DW.T1_Mon_g;

    /* Switch: '<S594>/Switch1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean'
     *  DataTypeConversion: '<S15>/Modify Scaling Only'
     *  Delay: '<S594>/Delay'
     *  S-Function (sfix_bitop): '<S597>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S597>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S597>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S605>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ExtractDesiredBits_ad) != 0) {
      rtb_ExtractDesiredBits_ad = (uint8)(LKAS_DW.Delay_DSTATE_m | ((uint8)1U));
    } else {
      rtb_ExtractDesiredBits_ad = (uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_m)) | ((uint8)1U))));
    }

    /* End of Switch: '<S594>/Switch1' */

    /* Switch: '<S594>/Switch2' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean2'
     *  S-Function (sfix_bitop): '<S598>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S598>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S598>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S606>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_mo) != 0) {
      rtb_ModifyScalingOnly_mo = (uint8)(rtb_ExtractDesiredBits_ad | ((uint8)2U));
    } else {
      rtb_ModifyScalingOnly_mo = (uint8)(~((uint8)(((uint8)
        (~rtb_ExtractDesiredBits_ad)) | ((uint8)2U))));
    }

    /* End of Switch: '<S594>/Switch2' */

    /* Switch: '<S594>/Switch3' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean3'
     *  S-Function (sfix_bitop): '<S599>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S599>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S599>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S607>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_enu) != 0) {
      rtb_ModifyScalingOnly_enu = (uint8)(rtb_ModifyScalingOnly_mo | ((uint8)4U));
    } else {
      rtb_ModifyScalingOnly_enu = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_mo)) | ((uint8)4U))));
    }

    /* End of Switch: '<S594>/Switch3' */

    /* Switch: '<S594>/Switch4' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean9'
     *  S-Function (sfix_bitop): '<S600>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S600>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S600>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S608>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_lt) != 0) {
      rtb_ModifyScalingOnly_lt = (uint8)(rtb_ModifyScalingOnly_enu | ((uint8)8U));
    } else {
      rtb_ModifyScalingOnly_lt = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_enu)) | ((uint8)8U))));
    }

    /* End of Switch: '<S594>/Switch4' */

    /* Switch: '<S594>/Switch5' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean10'
     *  S-Function (sfix_bitop): '<S602>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S602>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S602>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S609>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_dt) != 0) {
      rtb_ModifyScalingOnly_dt = (uint8)(rtb_ModifyScalingOnly_lt | ((uint8)16U));
    } else {
      rtb_ModifyScalingOnly_dt = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_lt)) | ((uint8)16U))));
    }

    /* End of Switch: '<S594>/Switch5' */

    /* Switch: '<S594>/Switch6' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean11'
     *  DataTypeConversion: '<S18>/Extract Desired Bits'
     *  S-Function (sfix_bitop): '<S601>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S601>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S601>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S610>/FixPt Bitwise Operator1'
     */
    if ((((uint32)((uint8)(rtb_ADIAve_g_ASWFaultStatus >> 11))) & 1U) != 0U) {
      rtb_ModifyScalingOnly_dt |= ((uint8)32U);
    } else {
      rtb_ModifyScalingOnly_dt = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_dt)) | ((uint8)32U))));
    }

    /* End of Switch: '<S594>/Switch6' */

    /* Switch: '<S594>/Switch7' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean12'
     *  S-Function (sfix_bitop): '<S603>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S603>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S603>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S611>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_c) != 0) {
      rtb_ModifyScalingOnly_c = (uint8)(rtb_ModifyScalingOnly_dt | ((uint8)64U));
    } else {
      rtb_ModifyScalingOnly_c = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_dt)) | ((uint8)64U))));
    }

    /* End of Switch: '<S594>/Switch7' */

    /* Switch: '<S594>/Switch8' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean21'
     *  S-Function (sfix_bitop): '<S604>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S604>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S604>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S612>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_f) != 0) {
      rtb_Switch8 = (uint8)(rtb_ModifyScalingOnly_c | ((uint8)128U));
    } else {
      rtb_Switch8 = (uint8)(~((uint8)(((uint8)(~rtb_ModifyScalingOnly_c)) |
        ((uint8)128U))));
    }

    /* End of Switch: '<S594>/Switch8' */

    /* Switch: '<S595>/Switch1' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean15'
     *  Delay: '<S595>/Delay'
     *  S-Function (sfix_bitop): '<S613>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S613>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S613>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S621>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_jq) != 0) {
      rtb_ModifyScalingOnly_jq = (uint8)(LKAS_DW.Delay_DSTATE_d | ((uint8)1U));
    } else {
      rtb_ModifyScalingOnly_jq = (uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_d)) | ((uint8)1U))));
    }

    /* End of Switch: '<S595>/Switch1' */

    /* Switch: '<S595>/Switch2' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean16'
     *  S-Function (sfix_bitop): '<S614>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S614>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S614>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S622>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_h) != 0) {
      rtb_ModifyScalingOnly_h = (uint8)(rtb_ModifyScalingOnly_jq | ((uint8)2U));
    } else {
      rtb_ModifyScalingOnly_h = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_jq)) | ((uint8)2U))));
    }

    /* End of Switch: '<S595>/Switch2' */

    /* Switch: '<S595>/Switch3' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean19'
     *  S-Function (sfix_bitop): '<S615>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S615>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S615>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S623>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_lz) != 0) {
      rtb_ModifyScalingOnly_lz = (uint8)(rtb_ModifyScalingOnly_h | ((uint8)4U));
    } else {
      rtb_ModifyScalingOnly_lz = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_h)) | ((uint8)4U))));
    }

    /* End of Switch: '<S595>/Switch3' */

    /* Switch: '<S595>/Switch4' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean20'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S616>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S624>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_ib) != 0) {
      rtb_ModifyScalingOnly_ib = (uint8)(rtb_ModifyScalingOnly_lz | ((uint8)8U));
    } else {
      rtb_ModifyScalingOnly_ib = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_lz)) | ((uint8)8U))));
    }

    /* End of Switch: '<S595>/Switch4' */

    /* Switch: '<S595>/Switch5' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean35'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S618>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S625>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_na) != 0) {
      rtb_ModifyScalingOnly_na = (uint8)(rtb_ModifyScalingOnly_ib | ((uint8)16U));
    } else {
      rtb_ModifyScalingOnly_na = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_ib)) | ((uint8)16U))));
    }

    /* End of Switch: '<S595>/Switch5' */

    /* Switch: '<S595>/Switch6' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean36'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S617>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S626>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_h2) != 0) {
      rtb_ModifyScalingOnly_h2 = (uint8)(rtb_ModifyScalingOnly_na | ((uint8)32U));
    } else {
      rtb_ModifyScalingOnly_h2 = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_na)) | ((uint8)32U))));
    }

    /* End of Switch: '<S595>/Switch6' */

    /* Switch: '<S595>/Switch7' incorporates:
     *  DataTypeConversion: '<S12>/Cast To Boolean42'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S619>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S627>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_kk) != 0) {
      rtb_ModifyScalingOnly_kk = (uint8)(rtb_ModifyScalingOnly_h2 | ((uint8)64U));
    } else {
      rtb_ModifyScalingOnly_kk = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_h2)) | ((uint8)64U))));
    }

    /* End of Switch: '<S595>/Switch7' */

    /* Switch: '<S595>/Switch8' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean1'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S620>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S628>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_d) != 0) {
      rtb_Switch8_g = (uint8)(rtb_ModifyScalingOnly_kk | ((uint8)128U));
    } else {
      rtb_Switch8_g = (uint8)(~((uint8)(((uint8)(~rtb_ModifyScalingOnly_kk)) |
        ((uint8)128U))));
    }

    /* End of Switch: '<S595>/Switch8' */

    /* Switch: '<S596>/Switch1' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean2'
     *  Delay: '<S596>/Delay'
     *  S-Function (sfix_bitop): '<S629>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S629>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S629>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S637>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_ok) != 0) {
      rtb_ModifyScalingOnly_d = (uint8)(LKAS_DW.Delay_DSTATE_db | ((uint8)1U));
    } else {
      rtb_ModifyScalingOnly_d = (uint8)(~((uint8)(((uint8)
        (~LKAS_DW.Delay_DSTATE_db)) | ((uint8)1U))));
    }

    /* End of Switch: '<S596>/Switch1' */

    /* Switch: '<S596>/Switch2' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean3'
     *  S-Function (sfix_bitop): '<S630>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S630>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S630>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S638>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_fc) != 0) {
      rtb_ModifyScalingOnly_fc = (uint8)(rtb_ModifyScalingOnly_d | ((uint8)2U));
    } else {
      rtb_ModifyScalingOnly_fc = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_d)) | ((uint8)2U))));
    }

    /* End of Switch: '<S596>/Switch2' */

    /* Switch: '<S596>/Switch3' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean4'
     *  S-Function (sfix_bitop): '<S631>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S631>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S631>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S639>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_dio) != 0) {
      rtb_ModifyScalingOnly_dio = (uint8)(rtb_ModifyScalingOnly_fc | ((uint8)4U));
    } else {
      rtb_ModifyScalingOnly_dio = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_fc)) | ((uint8)4U))));
    }

    /* End of Switch: '<S596>/Switch3' */

    /* Switch: '<S596>/Switch4' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean6'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S632>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S640>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_h0) != 0) {
      rtb_ModifyScalingOnly_h0 = (uint8)(rtb_ModifyScalingOnly_dio | ((uint8)8U));
    } else {
      rtb_ModifyScalingOnly_h0 = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_dio)) | ((uint8)8U))));
    }

    /* End of Switch: '<S596>/Switch4' */

    /* Switch: '<S596>/Switch5' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean8'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S634>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S641>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_ModifyScalingOnly_m) != 0) {
      rtb_ModifyScalingOnly_m = (uint8)(rtb_ModifyScalingOnly_h0 | ((uint8)16U));
    } else {
      rtb_ModifyScalingOnly_m = (uint8)(~((uint8)(((uint8)
        (~rtb_ModifyScalingOnly_h0)) | ((uint8)16U))));
    }

    /* End of Switch: '<S596>/Switch5' */

    /* Switch: '<S596>/Switch6' incorporates:
     *  DataTypeConversion: '<S13>/Cast To Boolean9'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S633>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S642>/FixPt Bitwise Operator1'
     */
    if (((sint32)rtb_IMAPve_d_R1_Type) != 0) {
      rtb_IMAPve_d_R1_Type = (uint8)(rtb_ModifyScalingOnly_m | ((uint8)32U));
    } else {
      rtb_IMAPve_d_R1_Type = (uint8)(~((uint8)(((uint8)(~rtb_ModifyScalingOnly_m))
        | ((uint8)32U))));
    }

    /* End of Switch: '<S596>/Switch6' */

    /* Switch: '<S596>/Switch7' incorporates:
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S635>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S643>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LDW_Fault) {
      rtb_IMAPve_d_R1_Type |= ((uint8)64U);
    } else {
      rtb_IMAPve_d_R1_Type = (uint8)(~((uint8)(((uint8)(~rtb_IMAPve_d_R1_Type)) |
        ((uint8)64U))));
    }

    /* End of Switch: '<S596>/Switch7' */

    /* Switch: '<S596>/Switch8' incorporates:
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator3'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator4'
     *  S-Function (sfix_bitop): '<S636>/FixPt Bitwise Operator5'
     *  S-Function (sfix_bitop): '<S644>/FixPt Bitwise Operator1'
     */
    if (LKAS_DW.LKA_Fault) {
      rtb_Switch8_l = (uint8)(rtb_IMAPve_d_R1_Type | ((uint8)128U));
    } else {
      rtb_Switch8_l = (uint8)(~((uint8)(((uint8)(~rtb_IMAPve_d_R1_Type)) |
        ((uint8)128U))));
    }

    /* End of Switch: '<S596>/Switch8' */

    /* Sum: '<S591>/Add' incorporates:
     *  ArithShift: '<S591>/Shift Arithmetic'
     *  ArithShift: '<S591>/Shift Arithmetic1'
     *  DataTypeConversion: '<S591>/Data Type Conversion'
     *  DataTypeConversion: '<S591>/Data Type Conversion1'
     *  DataTypeConversion: '<S591>/Data Type Conversion2'
     */
    rtb_Add = ((((uint32)rtb_Switch8_g) << 8) + ((uint32)rtb_Switch8)) +
      (((uint32)rtb_Switch8_l) << 16);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Fault_Reason = rtb_Add;

    /* DataTypeConversion: '<S337>/Cast2' */
    ob_LKA_Fault_Reason = rtb_Add;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_State_Mon = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LDW_State_Mon = LKAS_DW.LDWSM_stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.LDWSM_stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S139>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S144>/If' */
      if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S144>/If Action Subsystem' incorporates:
         *  ActionPort: '<S145>/Action Port'
         */
        /* Gain: '<S145>/rad to deg' incorporates:
         *  Gain: '<S145>/Gain'
         */
        LKAS_DW.Merge_l = ((-1.0F) * rtb_phiHdAg_Lft) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S144>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S144>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        /* Gain: '<S146>/rad to deg' */
        LKAS_DW.Merge_l = 57.2957802F * rtb_phiHdAg_Rgt;

        /* End of Outputs for SubSystem: '<S144>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S144>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_l);

        /* End of Outputs for SubSystem: '<S144>/If Action Subsystem2' */
      }

      /* End of If: '<S144>/If' */

      /* Switch: '<S655>/Switch2' incorporates:
       *  Constant: '<S655>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_j != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_j;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S655>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S144>/Sum Condition' incorporates:
       *  EnablePort: '<S148>/Enable'
       */
      /* RelationalOperator: '<S144>/Relational Operator' */
      if (LKAS_DW.Merge_l >= x10) {
        if (!LKAS_DW.SumCondition_MODE_o) {
          /* InitializeConditions for Memory: '<S148>/Memory' */
          LKAS_DW.Memory_PreviousInput_o2 = 0.0F;
          LKAS_DW.SumCondition_MODE_o = true;
        }

        /* Sum: '<S148>/Add1' incorporates:
         *  Memory: '<S148>/Memory'
         */
        rtb_L0_C0_o = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_o2;

        /* Saturate: '<S148>/Saturation' */
        if (rtb_L0_C0_o > 0.6F) {
          rtb_L0_C0_o = 0.6F;
        } else {
          if (rtb_L0_C0_o < 0.0F) {
            rtb_L0_C0_o = 0.0F;
          }
        }

        /* End of Saturate: '<S148>/Saturation' */

        /* RelationalOperator: '<S148>/Relational Operator' incorporates:
         *  Constant: '<S144>/Constant'
         */
        LKAS_DW.RelationalOperator_o = (rtb_L0_C0_o >= 0.05F);

        /* Update for Memory: '<S148>/Memory' */
        LKAS_DW.Memory_PreviousInput_o2 = rtb_L0_C0_o;
      } else {
        if (LKAS_DW.SumCondition_MODE_o) {
          /* Disable for Outport: '<S148>/Out' */
          LKAS_DW.RelationalOperator_o = false;
          LKAS_DW.SumCondition_MODE_o = false;
        }
      }

      /* End of RelationalOperator: '<S144>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S144>/Sum Condition' */

      /* Product: '<S139>/Product' incorporates:
       *  Logic: '<S139>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.LDWSM_stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_o) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S144>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_o) {
          /* Disable for Outport: '<S148>/Out' */
          LKAS_DW.RelationalOperator_o = false;
          LKAS_DW.SumCondition_MODE_o = false;
        }

        /* End of Disable for SubSystem: '<S144>/Sum Condition' */

        /* Disable for Outport: '<S139>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* If: '<S464>/If' incorporates:
     *  Constant: '<S470>/Constant'
     *  Delay: '<S142>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_IMAPve_d_EPS_LKA_State) != 1)) {
      /* Outputs for IfAction SubSystem: '<S464>/If Action Subsystem' incorporates:
       *  ActionPort: '<S468>/Action Port'
       */
      LKAS_IfActionSubsystem_nh(&rtb_Merge_n);

      /* End of Outputs for SubSystem: '<S464>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_IMAPve_d_EPS_LKA_State) != 3)) {
      /* Outputs for IfAction SubSystem: '<S464>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S469>/Action Port'
       */
      LKAS_IfActionSubsystem_nh(&rtb_Merge_n);

      /* End of Outputs for SubSystem: '<S464>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S464>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S470>/Action Port'
       */
      rtb_Merge_n = false;

      /* End of Outputs for SubSystem: '<S464>/If Action Subsystem3' */
    }

    /* End of If: '<S464>/If' */

    /* Outputs for Enabled SubSystem: '<S464>/Sum Condition1' */
    LKAS_SumCondition1(rtb_Merge_n, rtb_LKA_SampleTime,
                       rtb_LL_MAX_DELAY_EPSSTAR_TIME,
                       &LKAS_DW.RelationalOperator, &LKAS_DW.SumCondition1_l);

    /* End of Outputs for SubSystem: '<S464>/Sum Condition1' */

    /* SignalConversion: '<S523>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S436>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LKA_Main_Switch;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_Compare_mw;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_Compare_ho;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_iv;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_bp;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_ix;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_ab;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_p1;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_f;
    rtb_TmpSignalConversionAtSFunct[12] = rtb_RelationalOperator_pw;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_LogicalOperator_ol;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_m;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_BCM_Left_Light;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge_a3;

    /* MATLAB Function: '<S436>/Disable Reason' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S523>:1' */
    /* '<S523>:1:2' y = single(0); */
    rtb_L0_C0_o = 0.0F;

    /* '<S523>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S523>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S523>:1:5' y = single(i); */
        rtb_L0_C0_o = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Disable_Reason = rtb_L0_C0_o;

    /* DataTypeConversion: '<S337>/Cast' */
    ob_LKA_Disable_Reason = rtb_L0_C0_o;

    /* RelationalOperator: '<S474>/Compare' incorporates:
     *  Constant: '<S474>/Constant'
     */
    rtb_Compare_bi = (LKAS_DW.RelationalOperator == true);

    /* DataTypeConversion: '<S337>/Cast1' */
    ob_LKA_LKADeactvCSyn = (float32)(LKAS_DW.Merge1_c ? 1.0F : 0.0F);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LFTTTLC_Mon = rtb_LFTTTLC;

    /* Gain: '<S288>/Gain' incorporates:
     *  Sum: '<S288>/Add4'
     */
    rtb_phiHdAg = (rtb_phiHdAg_Lft + rtb_phiHdAg_Rgt) * 0.5F;

    /* Logic: '<S556>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S556>/Relational Operator3'
     *  RelationalOperator: '<S556>/Relational Operator4'
     */
    rtb_LogicalOperator1_f = ((rtb_Gain1 <= rtb_Abs_k) || (rtb_Add5_n <=
      rtb_Abs_k));

    /* Gain: '<S287>/Gain' incorporates:
     *  Sum: '<S287>/Add'
     */
    rtb_lDvt = (rtb_Gain1 + rtb_Add5_n) * 0.5F;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.DACMode = LKAS_DW.LKA_Mode;

    /* Gain: '<S286>/Gain' incorporates:
     *  Sum: '<S286>/Add'
     */
    rtb_crCrvt = (rtb_LL_CompHdAg_C + rtb_L0_C2) * 0.5F;

    /* Delay: '<S142>/Delay1' */
    rtb_DACMode = LKAS_DW.Delay1_2_DSTATE;
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S444>/ExitCount' */
      if (LKAS_DW.ExitCount_MODE) {
        /* Disable for Outport: '<S452>/Out' */
        LKAS_DW.RelationalOperator_f = false;
        LKAS_DW.ExitCount_MODE = false;
      }

      /* End of Disable for SubSystem: '<S444>/ExitCount' */

      /* Disable for Enabled SubSystem: '<S445>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S454>/Out' */
        LKAS_DW.RelationalOperator_n = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Disable for SubSystem: '<S445>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S455>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S459>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S455>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S383>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S414>/Out' */
        LKAS_DW.RelationalOperator_l1 = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S383>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S383>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S413>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S383>/Count' */

      /* Disable for Enabled SubSystem: '<S416>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_f) {
        /* Disable for Outport: '<S422>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_f = false;
      }

      /* End of Disable for SubSystem: '<S416>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S384>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S428>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }

      /* End of Disable for SubSystem: '<S384>/Sum Condition1' */

      /* Disable for If: '<S431>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S394>/Sum Condition' */
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S400>/Out' */
        LKAS_DW.RelationalOperator_na = false;
        LKAS_DW.SumCondition_MODE = false;
      }

      /* End of Disable for SubSystem: '<S394>/Sum Condition' */

      /* Disable for Enabled SubSystem: '<S319>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_p) {
        /* Disable for Outport: '<S323>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Subsystem_MODE_p = false;
      }

      /* End of Disable for SubSystem: '<S319>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S187>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S170>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S172>/Out' */
          LKAS_DW.RelationalOperator_ew = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S170>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_j.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_k3,
            &LKAS_DW.SumCondition1_j);
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition' */
        if (LKAS_DW.SumCondition_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_e,
            &LKAS_DW.SumCondition_c);
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S171>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S180>/Out' */
          LKAS_DW.RelationalOperator_h = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S171>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S157>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE_g) {
          LKAS_DW.SumCondition2_MODE_g = false;
        }

        /* End of Disable for SubSystem: '<S157>/Sum Condition2' */

        /* Disable for Enabled SubSystem: '<S149>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S158>/DTA_phiDTASWACmd' */
          LKAS_DW.DifferenceInputs2_g = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S149>/Subsystem' */

        /* Disable for If: '<S261>/If' */
        LKAS_DW.If_ActiveSubsystem_l = -1;

        /* Disable for Outport: '<S140>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S140>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S140>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S140>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_l = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_p = 0.0F;
        LKAS_DW.T1_Mon_g = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S144>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_o) {
          /* Disable for Outport: '<S148>/Out' */
          LKAS_DW.RelationalOperator_o = false;
          LKAS_DW.SumCondition_MODE_o = false;
        }

        /* End of Disable for SubSystem: '<S144>/Sum Condition' */

        /* Disable for Outport: '<S139>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Enabled SubSystem: '<S464>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_l.SumCondition1_MODE) {
        LKAS_SumCondition1_Disable(&LKAS_DW.RelationalOperator,
          &LKAS_DW.SumCondition1_l);
      }

      /* End of Disable for SubSystem: '<S464>/Sum Condition1' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.DACMode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MATLAB Function: '<S8>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S111>/Switch'
   *  Switch: '<S111>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S89>:1' */
  /* '<S89>:1:2' if stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S89>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:6' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:8' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S89>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S89>:1:10' Vehicle_Lane_Display=uint8(10); */
        rtb_L0_Q = 10U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:12' Vehicle_Lane_Display=uint8(11); */
        rtb_L0_Q = 11U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:14' Vehicle_Lane_Display=uint8(12); */
        rtb_L0_Q = 12U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:16' Vehicle_Lane_Display=uint8(13); */
        rtb_L0_Q = 13U;
      } else {
        /* '<S89>:1:17' else */
        /* '<S89>:1:18' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S89>:1:4' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   case 2:
    /* '<S89>:1:20' elseif stDACmode==2 */
    /* '<S89>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:24' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:26' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S89>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S89>:1:28' Vehicle_Lane_Display=uint8(6); */
        rtb_L0_Q = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S89>:1:30' Vehicle_Lane_Display=uint8(7); */
        rtb_L0_Q = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:32' Vehicle_Lane_Display=uint8(8); */
        rtb_L0_Q = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S89>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S89>:1:34' Vehicle_Lane_Display=uint8(9); */
        rtb_L0_Q = 9U;
      } else {
        /* '<S89>:1:35' else */
        /* '<S89>:1:36' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S89>:1:22' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   default:
    /* '<S89>:1:38' else */
    /* '<S89>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_L0_Q = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/Vehicle_Lane_Display' */

  /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S11>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_IMAPve_d_R1_Type = ((uint8)1U);
    break;

   case 1:
    rtb_IMAPve_d_R1_Type = ((uint8)1U);
    break;

   case 2:
    rtb_IMAPve_d_R1_Type = ((uint8)2U);
    break;

   case 3:
    rtb_IMAPve_d_R1_Type = ((uint8)3U);
    break;

   case 4:
    rtb_IMAPve_d_R1_Type = ((uint8)4U);
    break;

   case 5:
    rtb_IMAPve_d_R1_Type = ((uint8)4U);
    break;

   default:
    rtb_IMAPve_d_R1_Type = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S11>/Multiport Switch' */

  /* RelationalOperator: '<S646>/Compare' incorporates:
   *  Constant: '<S646>/Constant'
   */
  rtb_Merge_a3 = (rtb_IMAPve_d_R1_Type == ((uint8)4U));

  /* Switch: '<S11>/Switch1' incorporates:
   *  Constant: '<S11>/1'
   *  Constant: '<S11>/x0'
   */
  if (rtb_Merge_a3) {
    rtb_R0_Q = ((uint8)1U);
  } else {
    rtb_R0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S645>/Subsystem' incorporates:
   *  EnablePort: '<S652>/Enable'
   */
  if (((sint32)rtb_R0_Q) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S652>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S652>/Add' */
    rtb_L0_C2 = LKAS_DW.OutputSWACmd - rtb_R0_C2;

    /* Sum: '<S652>/Add1' incorporates:
     *  Constant: '<S652>/Ki'
     *  Delay: '<S652>/Delay1'
     *  Product: '<S652>/Product2'
     */
    rtb_LL_CompHdAg_C = (rtb_L0_C2 * 0.0005F) + LKAS_DW.Delay1_DSTATE;

    /* Saturate: '<S652>/Saturation' */
    if (rtb_LL_CompHdAg_C > 0.5F) {
      rtb_LL_CompHdAg_C = 0.5F;
    } else {
      if (rtb_LL_CompHdAg_C < (-0.5F)) {
        rtb_LL_CompHdAg_C = (-0.5F);
      }
    }

    /* End of Saturate: '<S652>/Saturation' */

    /* Fcn: '<S652>/Fcn' */
    rtb_Abs_k = LKAS_DW.OutputSWACmd * LKAS_DW.OutputSWACmd;

    /* Sum: '<S652>/Add2' incorporates:
     *  Constant: '<S652>/Kp'
     *  Fcn: '<S652>/Fcn'
     *  Product: '<S652>/Product1'
     */
    LKAS_DW.in_trq = (((((rtb_Abs_k * LKAS_DW.OutputSWACmd) * 2.0e-6F) +
                        (rtb_Abs_k * -0.0005F)) + (LKAS_DW.OutputSWACmd *
      0.0505F)) + (rtb_L0_C2 * 0.02F)) + rtb_LL_CompHdAg_C;

    /* Update for Delay: '<S652>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_LL_CompHdAg_C;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S652>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S645>/Subsystem' */

  /* Sum: '<S650>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S650>/Delay Input2'
   *
   * Block description for '<S650>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S650>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S650>/delta rise limit' incorporates:
   *  Constant: '<S645>/Constant'
   *  SampleTimeMath: '<S650>/sample time'
   *
   * About '<S650>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_LL_CompHdAg_C = 5.0F * 0.01F;

  /* Product: '<S650>/delta fall limit' incorporates:
   *  Constant: '<S645>/Constant1'
   *  SampleTimeMath: '<S650>/sample time'
   *
   * About '<S650>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C0_o = (-5.0F) * 0.01F;

  /* Switch: '<S653>/Switch2' incorporates:
   *  Product: '<S650>/delta fall limit'
   *  Product: '<S650>/delta rise limit'
   *  RelationalOperator: '<S653>/LowerRelop1'
   *  RelationalOperator: '<S653>/UpperRelop'
   *  Switch: '<S653>/Switch'
   */
  if (rtb_L0_C2 > rtb_LL_CompHdAg_C) {
    rtb_L0_C2 = rtb_LL_CompHdAg_C;
  } else {
    if (rtb_L0_C2 < rtb_L0_C0_o) {
      /* Switch: '<S653>/Switch' incorporates:
       *  Product: '<S650>/delta fall limit'
       */
      rtb_L0_C2 = rtb_L0_C0_o;
    }
  }

  /* End of Switch: '<S653>/Switch2' */

  /* Sum: '<S650>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S650>/Delay Input2'
   *
   * Block description for '<S650>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S650>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 += LKAS_DW.DelayInput2_DSTATE;

  /* MATLAB Function: '<S8>/LDW_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Status_Display': '<S85>:1' */
  /* '<S85>:1:2' if (stDACmode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S85>:1:3' LDW_Status_Display=uint8(1); */
    rtb_ModifyScalingOnly_m = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S85>:1:4' elseif (stDACmode==1)&&LDW_STATE==6 */
    /* '<S85>:1:5' LDW_Status_Display=uint8(2); */
    rtb_ModifyScalingOnly_m = 2U;
  } else {
    /* '<S85>:1:6' else */
    /* '<S85>:1:7' LDW_Status_Display=uint8(0); */
    rtb_ModifyScalingOnly_m = 0U;
  }

  /* End of MATLAB Function: '<S8>/LDW_Status_Display' */

  /* MATLAB Function: '<S8>/LKA_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_Status_Display': '<S86>:1' */
  /* '<S86>:1:3' if stDACmode==2&&LKA_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) != 6)) {
    /* '<S86>:1:4' LKA_Status_Display=single(1); */
    rtb_LL_CompHdAg_C = 1.0F;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S86>:1:5' elseif stDACmode==2&&LKA_STATE==6 */
    /* '<S86>:1:6' LKA_Status_Display=single(2); */
    rtb_LL_CompHdAg_C = 2.0F;
  } else {
    /* '<S86>:1:7' else */
    /* '<S86>:1:8' LKA_Status_Display=single(0); */
    rtb_LL_CompHdAg_C = 0.0F;
  }

  /* End of MATLAB Function: '<S8>/LKA_Status_Display' */

  /* MATLAB Function: '<S8>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S84>:1' */
  /* '<S84>:1:2' if HMI_stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S84>:1:3' if HMI_LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S84>:1:4' LDW_Flag=uint8(1); */
      rtb_ModifyScalingOnly_h0 = 1U;
      break;

     case 2:
      /* '<S84>:1:5' elseif HMI_LDWWarnInfo==2 */
      /* '<S84>:1:6' LDW_Flag=uint8(2); */
      rtb_ModifyScalingOnly_h0 = 2U;
      break;

     default:
      /* '<S84>:1:7' else */
      /* '<S84>:1:8' LDW_Flag=uint8(0); */
      rtb_ModifyScalingOnly_h0 = 0U;
      break;
    }
    break;

   case 2:
    /* '<S84>:1:10' elseif HMI_stDACmode==2 */
    /* '<S84>:1:11' if HMI_LDWWarnInfo==1 && HMI_LKA_STATE==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S84>:1:12' LDW_Flag=uint8(1); */
      rtb_ModifyScalingOnly_h0 = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S84>:1:13' elseif HMI_LDWWarnInfo==2 && HMI_LKA_STATE==5 */
      /* '<S84>:1:14' LDW_Flag=uint8(2); */
      rtb_ModifyScalingOnly_h0 = 2U;
    } else {
      /* '<S84>:1:15' else */
      /* '<S84>:1:16' LDW_Flag=uint8(0); */
      rtb_ModifyScalingOnly_h0 = 0U;
    }
    break;

   default:
    /* '<S84>:1:18' else */
    /* '<S84>:1:19' LDW_Flag=uint8(0); */
    rtb_ModifyScalingOnly_h0 = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/LDW_Flag' */

  /* Switch: '<S88>/Switch' incorporates:
   *  Constant: '<S88>/Constant'
   *  Constant: '<S88>/Constant1'
   *  Constant: '<S90>/Constant'
   *  RelationalOperator: '<S90>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_TTLC_d = 0.5F;
  } else {
    rtb_TTLC_d = 0.25F;
  }

  /* End of Switch: '<S88>/Switch' */

  /* Logic: '<S88>/Logical Operator2' incorporates:
   *  Abs: '<S88>/Abs'
   *  Constant: '<S91>/Constant'
   *  Constant: '<S92>/Constant'
   *  Constant: '<S93>/Constant'
   *  Constant: '<S94>/Constant'
   *  Constant: '<S95>/Constant'
   *  Constant: '<S96>/Constant'
   *  Constant: '<S97>/Constant'
   *  Constant: '<S98>/Constant'
   *  Logic: '<S88>/Logical Operator1'
   *  Logic: '<S88>/Logical Operator3'
   *  RelationalOperator: '<S88>/Relational Operator'
   *  RelationalOperator: '<S91>/Compare'
   *  RelationalOperator: '<S92>/Compare'
   *  RelationalOperator: '<S93>/Compare'
   *  RelationalOperator: '<S94>/Compare'
   *  RelationalOperator: '<S95>/Compare'
   *  RelationalOperator: '<S96>/Compare'
   *  RelationalOperator: '<S97>/Compare'
   *  RelationalOperator: '<S98>/Compare'
   */
  rtb_LogicalOperator2 = ((((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (LKAS_DW.LKA_State == ((uint8)5U))) || (LKAS_DW.LKA_State == ((uint8)4U))) ||
    (LKAS_DW.LKA_State == ((uint8)3U))) && ((rtb_IMAPve_d_EPS_LKA_State ==
    ((uint8)3U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)))) && (fabsf
    (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_TTLC_d));

  /* Switch: '<S657>/Switch2' incorporates:
   *  Constant: '<S657>/LL_RlsDet_tiTDelTime_DISABLE=2'
   *
   * Block description for '<S657>/LL_RlsDet_tiTDelTime_DISABLE=2':
   *  ��ʻԱ���ֿ�ʼ����������������ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion2_a != 0.0F) {
    rtb_LL_HandsOff_WarnTime = LKAS_ConstB.DataTypeConversion2_a;
  } else {
    rtb_LL_HandsOff_WarnTime = LL_HandsOff_WarnTime;
  }

  /* End of Switch: '<S657>/Switch2' */

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition2' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_WarnTime, &LKAS_DW.RelationalOperator_cf,
                     &LKAS_DW.SumCondition2);

  /* End of Outputs for SubSystem: '<S88>/Sum Condition2' */

  /* MATLAB Function: '<S8>/Hands_Off_Warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_Off_Warning': '<S83>:1' */
  /* '<S83>:1:2' if HandsOff==0 */
  if (!LKAS_DW.RelationalOperator_cf) {
    /* '<S83>:1:3' Hands_Off_Warning= uint8(0); */
    rtb_IMAPve_d_EPS_LKA_State = 0U;
  } else {
    /* '<S83>:1:4' elseif HandsOff==1 */
    /* '<S83>:1:5' Hands_Off_Warning= uint8(1); */
    rtb_IMAPve_d_EPS_LKA_State = 1U;
  }

  /* End of MATLAB Function: '<S8>/Hands_Off_Warning' */

  /* Switch: '<S657>/Switch1' incorporates:
   *  Constant: '<S657>/LL_RlsDet_tiTDelTime_DISABLE=1'
   *
   * Block description for '<S657>/LL_RlsDet_tiTDelTime_DISABLE=1':
   *  ��ʻԱ���ֿ�ʼ�����ܷ����������ѵ�ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_HandsOff_TextTime = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_HandsOff_TextTime = LL_HandsOff_TextTime;
  }

  /* End of Switch: '<S657>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S88>/Sum Condition1' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_TextTime, &LKAS_DW.RelationalOperator_e2,
                     &LKAS_DW.SumCondition1);

  /* End of Outputs for SubSystem: '<S88>/Sum Condition1' */

  /* MATLAB Function: '<S8>/HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1'
   *  Inport: '<Root>/IMAPve_d_Camera_Status'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S82>:1' */
  /* '<S82>:1:2' if stDACmode==2&&LKA_STATE==6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 6)) {
    /* �������ָ������� */
    /* '<S82>:1:3' HMI_Popup_Status=uint8(6); */
    rtb_ModifyScalingOnly_dio = 6U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (((sint32)((uint8)
                      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status
                      ())) == 5)) {
    /* '<S82>:1:6' elseif (stDACmode==2||stDACmode==1)&&(Front_Camera_Blocked==5) */
    /* ����ͷ���ڵ� */
    /* '<S82>:1:7' HMI_Popup_Status=uint8(4); */
    rtb_ModifyScalingOnly_dio = 4U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (LKAS_DW.RelationalOperator_e2)) {
    /* '<S82>:1:8' elseif (stDACmode==2||stDACmode==1)&&HandsOff==1 */
    /* ���շ����� */
    /* '<S82>:1:9' HMI_Popup_Status=uint8(2); */
    rtb_ModifyScalingOnly_dio = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              2)) {
    /* '<S82>:1:10' elseif stDACmode==2&&(LKA_STATE==2) */
    /* '<S82>:1:11' HMI_Popup_Status=uint8(1); */
    rtb_ModifyScalingOnly_dio = 1U;
  } else if (((sint32)LKAS_DW.LKA_Mode) != 2) {
    /* '<S82>:1:12' elseif stDACmode~=2&&stFaultCSyn==0 */
    /* '<S82>:1:13' HMI_Popup_Status=uint8(8); */
    rtb_ModifyScalingOnly_dio = 8U;
  } else {
    /* '<S82>:1:14' elseif stFaultCSyn==0 */
    /* '<S82>:1:15' HMI_Popup_Status=uint8(7); */
    rtb_ModifyScalingOnly_dio = 7U;
  }

  /* End of MATLAB Function: '<S8>/HMI_Popup_Status' */

  /* MATLAB Function: '<S8>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S87>:1' */
  /* '<S87>:1:2' if stDACmode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S87>:1:3' LKA_Action_Indication=uint8(1); */
    rtb_ModifyScalingOnly_fc = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S87>:1:4' elseif stDACmode==2&&LKA_STATE==3 */
    /* '<S87>:1:5' LKA_Action_Indication=uint8(2); */
    rtb_ModifyScalingOnly_fc = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S87>:1:6' elseif stDACmode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S87>:1:7' LKA_Action_Indication=uint8(3); */
    rtb_ModifyScalingOnly_fc = 3U;
  } else {
    /* '<S87>:1:8' else */
    /* '<S87>:1:9' LKA_Action_Indication=uint8(0); */
    rtb_ModifyScalingOnly_fc = 0U;
  }

  /* End of MATLAB Function: '<S8>/LKA_action_indication' */

  /* DataTypeConversion: '<S11>/Cast To Single10' incorporates:
   *  Constant: '<S647>/Constant'
   *  RelationalOperator: '<S647>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.DACMode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S4>/Cast To Single1' */
  LKAS_DW.CastToSingle1 = LKAS_DW.LFTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single2' */
  LKAS_DW.CastToSingle2 = LKAS_DW.RGTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single3' */
  LKAS_DW.CastToSingle3 = (float32)LKAS_DW.LDW_State_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single4' */
  LKAS_DW.CastToSingle4 = (float32)LKAS_DW.LKA_State_Mon;

  /* S-Function (scanpack): '<S4>/CAN Pack' */
  /* S-Function (scanpack): '<S4>/CAN Pack' */
  LKAS_DW.CANPack.ID = 1U;
  LKAS_DW.CANPack.Length = 8U;
  LKAS_DW.CANPack.Extended = 0U;
  LKAS_DW.CANPack.Remote = 0;
  LKAS_DW.CANPack.Data[0] = 0;
  LKAS_DW.CANPack.Data[1] = 0;
  LKAS_DW.CANPack.Data[2] = 0;
  LKAS_DW.CANPack.Data[3] = 0;
  LKAS_DW.CANPack.Data[4] = 0;
  LKAS_DW.CANPack.Data[5] = 0;
  LKAS_DW.CANPack.Data[6] = 0;
  LKAS_DW.CANPack.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle1;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[1] = LKAS_DW.CANPack.Data[1] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[0] = LKAS_DW.CANPack.Data[0] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle2;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[3] = LKAS_DW.CANPack.Data[3] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[2] = LKAS_DW.CANPack.Data[2] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle3;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[5] = LKAS_DW.CANPack.Data[5] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[4] = LKAS_DW.CANPack.Data[4] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle4;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[7] = LKAS_DW.CANPack.Data[7] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[6] = LKAS_DW.CANPack.Data[6] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single5' */
  LKAS_DW.CastToSingle5 = LKAS_DW.LKA_ExitFlg_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single6' */
  LKAS_DW.CastToSingle6 = LKAS_DW.LKA_SampleTime_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single7' */
  LKAS_DW.CastToSingle7 = LKAS_DW.T1_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single8' */
  LKAS_DW.CastToSingle8 = LKAS_DW.Disable_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  LKAS_DW.CANPack1.ID = 2U;
  LKAS_DW.CANPack1.Length = 8U;
  LKAS_DW.CANPack1.Extended = 0U;
  LKAS_DW.CANPack1.Remote = 0;
  LKAS_DW.CANPack1.Data[0] = 0;
  LKAS_DW.CANPack1.Data[1] = 0;
  LKAS_DW.CANPack1.Data[2] = 0;
  LKAS_DW.CANPack1.Data[3] = 0;
  LKAS_DW.CANPack1.Data[4] = 0;
  LKAS_DW.CANPack1.Data[5] = 0;
  LKAS_DW.CANPack1.Data[6] = 0;
  LKAS_DW.CANPack1.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle5;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[1] = LKAS_DW.CANPack1.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[0] = LKAS_DW.CANPack1.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle6;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[3] = LKAS_DW.CANPack1.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[2] = LKAS_DW.CANPack1.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle7;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[5] = LKAS_DW.CANPack1.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[4] = LKAS_DW.CANPack1.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle8;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[7] = LKAS_DW.CANPack1.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[6] = LKAS_DW.CANPack1.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single9' */
  LKAS_DW.CastToSingle9 = (float32)LKAS_DW.Fault_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack2' */
  /* S-Function (scanpack): '<S4>/CAN Pack2' */
  LKAS_DW.CANPack2.ID = 3U;
  LKAS_DW.CANPack2.Length = 8U;
  LKAS_DW.CANPack2.Extended = 0U;
  LKAS_DW.CANPack2.Remote = 0;
  LKAS_DW.CANPack2.Data[0] = 0;
  LKAS_DW.CANPack2.Data[1] = 0;
  LKAS_DW.CANPack2.Data[2] = 0;
  LKAS_DW.CANPack2.Data[3] = 0;
  LKAS_DW.CANPack2.Data[4] = 0;
  LKAS_DW.CANPack2.Data[5] = 0;
  LKAS_DW.CANPack2.Data[6] = 0;
  LKAS_DW.CANPack2.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle9;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[1] = LKAS_DW.CANPack2.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[0] = LKAS_DW.CANPack2.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle10;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[3] = LKAS_DW.CANPack2.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[2] = LKAS_DW.CANPack2.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle21;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[5] = LKAS_DW.CANPack2.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[4] = LKAS_DW.CANPack2.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_ConstB.CastToSingle22;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack2.Data[7] = LKAS_DW.CANPack2.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack2.Data[6] = LKAS_DW.CANPack2.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack' */
    if ((8 == LKAS_DW.CANPack.Length) && (LKAS_DW.CANPack.ID != INVALID_CAN_ID) )
    {
      if ((1 == LKAS_DW.CANPack.ID) && (0U == LKAS_DW.CANPack.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
    if ((8 == LKAS_DW.CANPack1.Length) && (LKAS_DW.CANPack1.ID != INVALID_CAN_ID)
        ) {
      if ((2 == LKAS_DW.CANPack1.ID) && (0U == LKAS_DW.CANPack1.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
    if ((8 == LKAS_DW.CANPack2.Length) && (LKAS_DW.CANPack2.ID != INVALID_CAN_ID)
        ) {
      if ((3 == LKAS_DW.CANPack2.ID) && (0U == LKAS_DW.CANPack2.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack2.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack2.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack2.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07L_100 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
    if ((8 == LKAS_ConstB.CANPack3.Length) && (LKAS_ConstB.CANPack3.ID !=
         INVALID_CAN_ID) ) {
      if ((4 == LKAS_ConstB.CANPack3.ID) && (0U == LKAS_ConstB.CANPack3.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08L_100 = result;
            }
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S12>/Cast To Boolean37' incorporates:
   *  DataTypeConversion: '<S41>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_14B_InvOorReal = (((rtb_ADIAve_g_BSWFaultStatus >> 26) & 1U)
    != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean38' incorporates:
   *  DataTypeConversion: '<S42>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxN = (((rtb_ADIAve_g_BSWFaultStatus >> 27) & 1U)
    != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean39' incorporates:
   *  DataTypeConversion: '<S43>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMaxT = (((rtb_ADIAve_g_BSWFaultStatus >> 28) & 1U)
    != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean40' incorporates:
   *  DataTypeConversion: '<S44>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinN = (((rtb_ADIAve_g_BSWFaultStatus >> 29) & 1U)
    != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean41' incorporates:
   *  DataTypeConversion: '<S45>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_17E_InvOorMinT = (((rtb_ADIAve_g_BSWFaultStatus >> 30) & 1U)
    != 0U);

  /* DataTypeConversion: '<S13>/Cast To Boolean' incorporates:
   *  DataTypeConversion: '<S53>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_ACU_Validity = ((((uint32)((uint8)
    rtb_ADIAve_g_BSWFaultStatus)) & 1U) != 0U);

  /* DataTypeConversion: '<S13>/Cast To Boolean10' incorporates:
   *  DataTypeConversion: '<S55>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_EPB_Validity = ((((uint32)((uint8)
    (rtb_ADIAve_g_BSWFaultStatus >> 10))) & 1U) != 0U);

  /* DataTypeConversion: '<S13>/Cast To Boolean11' incorporates:
   *  DataTypeConversion: '<S56>/Extract Desired Bits'
   */
  rtb_ADIA_Inner_FRadar_FaultStat = ((((uint32)((uint8)
    (rtb_ADIAve_g_BSWFaultStatus >> 16))) & 1U) != 0U);

  /* DataTypeConversion: '<S13>/Cast To Boolean12' incorporates:
   *  DataTypeConversion: '<S57>/Extract Desired Bits'
   */
  rtb_ADIAve_d_sen_sta_Corner_rad = ((((uint32)((uint8)
    (rtb_ADIAve_g_BSWFaultStatus >> 17))) & 1U) != 0U);

  /* DataTypeConversion: '<S13>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S61>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_EMS_Validity = ((((uint32)((uint8)
    (rtb_ADIAve_g_BSWFaultStatus >> 5))) & 1U) != 0U);

  /* DataTypeConversion: '<S13>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S63>/Extract Desired Bits'
   */
  rtb_ADIAve_e_Node_TBOX_Validity = ((((uint32)((uint8)
    (rtb_ADIAve_g_BSWFaultStatus >> 7))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean1' incorporates:
   *  DataTypeConversion: '<S16>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC_EPBErrorStatus = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 1))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean13' incorporates:
   *  DataTypeConversion: '<S20>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorTCS = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 13))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean14' incorporates:
   *  DataTypeConversion: '<S21>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC3_121_InvOorVeh = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 14))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean17' incorporates:
   *  DataTypeConversion: '<S40>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_MP5_366_OorAEBButt = (((rtb_ADIAve_g_ASWFaultStatus >> 25) & 1U)
    != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean18' incorporates:
   *  DataTypeConversion: '<S25>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_MP5_366_OorFCWButt = (((rtb_ADIAve_g_ASWFaultStatus >> 26) & 1U)
    != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean22' incorporates:
   *  DataTypeConversion: '<S24>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorSta = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 17))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean23' incorporates:
   *  DataTypeConversion: '<S32>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC5_122_InvOorYaw = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 18))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean24' incorporates:
   *  DataTypeConversion: '<S33>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvOorDyn = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 19))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean25' incorporates:
   *  DataTypeConversion: '<S34>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvUnfilY = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 20))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean26' incorporates:
   *  DataTypeConversion: '<S35>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehDri = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 21))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean27' incorporates:
   *  DataTypeConversion: '<S36>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_ESC6_123_InvVehHol = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 22))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean28' incorporates:
   *  DataTypeConversion: '<S37>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_GW_MP5_413_OorISAM = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 23))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean29' incorporates:
   *  DataTypeConversion: '<S29>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_SCC_309_OorACCButt = (((rtb_ADIAve_g_ASWFaultStatus >> 29) & 1U)
    != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean4' incorporates:
   *  DataTypeConversion: '<S47>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_BCM3_33C_InvBrkLig = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 4))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean5' incorporates:
   *  DataTypeConversion: '<S48>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS_14A_OorACCStat = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 5))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean6' incorporates:
   *  DataTypeConversion: '<S49>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS10_88_InvAccPed = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 6))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean7' incorporates:
   *  DataTypeConversion: '<S50>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS5_E0_InvOorBrkP = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 7))) & 1U) != 0U);

  /* DataTypeConversion: '<S12>/Cast To Boolean8' incorporates:
   *  DataTypeConversion: '<S51>/Extract Desired Bits'
   */
  rtb_ADIA_DTC_EMS5_E0_OorEngineS = ((((uint32)((uint8)
    (rtb_ADIAve_g_ASWFaultStatus >> 8))) & 1U) != 0U);

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S120>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_g = rtb_R0_Type;
  } else {
    rtb_R0_Type_g = rtb_L0_Type;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  Constant: '<S117>/Constant'
   *  DataTypeConversion: '<S118>/Cast To Single5'
   *  Switch: '<S117>/Switch3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_e = rtb_L0_Type;

    /* DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     */
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q();

    /* Switch: '<S113>/Switch1' incorporates:
     *  Constant: '<S113>/Constant1'
     */
    if (rtb_L0_Type >= ((uint8)2U)) {
      rtb_L1_Q = (uint16)((uint8)3U);
    } else {
      rtb_L1_Q = (uint16)rtb_L0_Type;
    }

    /* End of Switch: '<S113>/Switch1' */
  } else {
    rtb_L0_Type_e = rtb_R0_Type;
    rtb_L1_Q = ((uint16)0U);
  }

  /* DataTypeConversion: '<S110>/Cast To Single57' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   */
  rtb_R0_C2 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   */
  rtb_L0_C0_o = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR();

  /* Switch: '<S119>/Switch3' incorporates:
   *  Constant: '<S119>/Constant'
   *  DataTypeConversion: '<S110>/Cast To Single66'
   *  Switch: '<S111>/Switch'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    /* DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q();

    /* Switch: '<S114>/Switch1' incorporates:
     *  Constant: '<S114>/Constant1'
     */
    if (rtb_L0_Type >= ((uint8)2U)) {
      rtb_R1_Q = (uint16)((uint8)3U);
    } else {
      rtb_R1_Q = (uint16)rtb_L0_Type;
    }

    /* End of Switch: '<S114>/Switch1' */
    rtb_R0_VR_e = rtb_R0_C2;
  } else {
    rtb_R1_Q = ((uint16)0U);
    rtb_R0_VR_e = rtb_L0_C0_o;
  }

  /* End of Switch: '<S119>/Switch3' */

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single66'
   *  DataTypeConversion: '<S118>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_e = rtb_L0_C0_o;
  } else {
    rtb_L0_VR_e = rtb_R0_C2;
  }

  /* DataTypeConversion: '<S110>/Cast To Single75' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  rtb_R0_C2 = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_W_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_W'
   */
  rtb_L0_C0_o = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W();

  /* Switch: '<S111>/Switch' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single71'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_d = rtb_R0_C2;
  } else {
    rtb_R0_W_d = rtb_L0_C0_o;
  }

  /* Switch: '<S111>/Switch1' incorporates:
   *  DataTypeConversion: '<S110>/Cast To Single71'
   *  DataTypeConversion: '<S118>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_f = rtb_L0_C0_o;
  } else {
    rtb_L0_W_f = rtb_R0_C2;
  }

  /* Math: '<S104>/Mod1' incorporates:
   *  Constant: '<S104>/Constant7'
   */
  if (((sint32)((uint8)3U)) != 0) {
    rtb_Mod1 %= ((uint8)3U);
  }

  /* End of Math: '<S104>/Mod1' */

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LDW_Warn_Mode'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode();

  /* MinMax: '<S104>/Max1' */
  if (rtb_Mod1 > rtb_L0_Type) {
    rtb_LDW_Warn_Mode = rtb_Mod1;
  } else {
    rtb_LDW_Warn_Mode = rtb_L0_Type;
  }

  /* End of MinMax: '<S104>/Max1' */

  /* DataTypeConversion: '<S1>/IMAPve_d_APA_AutoPark_WorkSt_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_APA_AutoPark_WorkSt'
   */
  rtb_IMAPve_d_APA_AutoPark_WorkS = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp_Switch'
   */
  rtb_IMAPve_d_BCM_HazardLamp_g = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_Switch_IMAPve_d_BCM_HazardLamp_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Override'
   */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_ESA_State'
   */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State'
   */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag'
   */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_TrqLim_State'
   */
  rtb_IMAPve_d_EPS_TrqLim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Trq_State'
   */
  rtb_IMAPve_d_EPS_Trq_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid'
   */
  rtb_IMAPve_d_ESC_LatAcc_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid'
   */
  rtb_IMAPve_d_ESC_LonAcc_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid'
   */
  rtb_IMAPve_d_ESC_VehSpd_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid'
   */
  rtb_IMAPve_d_ESC_YawRate_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Fusion_Status'
   */
  rtb_IMAPve_d_Fusion_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status();

  /* DataTypeConversion: '<S110>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   */
  rtb_L1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_Work_State'
   */
  rtb_IMAPve_d_MP5_Work_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State
    ();

  /* DataTypeConversion: '<S110>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   */
  rtb_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SAS_Clb_State'
   */
  rtb_IMAPve_d_SAS_Clb_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SAS_Trim_State'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SWS_Failure_Status'
   */
  rtb_IMAPve_d_SWS_Failure_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Sensor_Status'
   */
  rtb_IMAPve_d_Sensor_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_TCU_Available'
   */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  rtb_IMAPve_g_EMS_RealPedal = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  rtb_IMAPve_g_EPS_LKA_Current = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  rtb_IMAPve_g_ESC_Brake_Press = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  rtb_IMAPve_g_ESC_UnYawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  rtb_IMAPve_g_ESC_YawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate();

  /* DataTypeConversion: '<S110>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   *  UnaryMinus: '<S110>/Unary Minus8'
   */
  rtb_L1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   *  UnaryMinus: '<S110>/Unary Minus9'
   */
  rtb_L1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   *  UnaryMinus: '<S110>/Unary Minus10'
   */
  rtb_L1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   *  UnaryMinus: '<S110>/Unary Minus11'
   */
  rtb_L1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single78' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  rtb_L1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR();

  /* DataTypeConversion: '<S110>/Cast To Single74' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  rtb_L1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W();

  /* DataTypeConversion: '<S110>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   *  UnaryMinus: '<S110>/Unary Minus14'
   */
  rtb_R1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   *  UnaryMinus: '<S110>/Unary Minus15'
   */
  rtb_R1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   *  UnaryMinus: '<S110>/Unary Minus12'
   */
  rtb_R1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   *  UnaryMinus: '<S110>/Unary Minus13'
   */
  rtb_R1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3
    ()));

  /* DataTypeConversion: '<S110>/Cast To Single50' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  rtb_R1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR();

  /* DataTypeConversion: '<S110>/Cast To Single52' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  rtb_R1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  rtb_IMAPve_g_SW_Angle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle();

  /* Switch: '<S656>/Switch1' incorporates:
   *  Constant: '<S656>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1_l != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1_l;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S656>/Switch1' */

  /* Switch: '<S656>/Switch15' incorporates:
   *  Constant: '<S656>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    rtb_LL_lStpLngth_C = LKAS_ConstB.DataTypeConversion21;
  } else {
    rtb_LL_lStpLngth_C = LL_lStpLngth_C;
  }

  /* End of Switch: '<S656>/Switch15' */

  /* Switch: '<S656>/Switch10' incorporates:
   *  Constant: '<S656>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22_k != 0.0F) {
    rtb_LL_DesDvt_C = LKAS_ConstB.DataTypeConversion22_k;
  } else {
    rtb_LL_DesDvt_C = LL_DesDvt_C;
  }

  /* End of Switch: '<S656>/Switch10' */

  /* Switch: '<S656>/Switch12' incorporates:
   *  Constant: '<S656>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S656>/Switch12' */

  /* Switch: '<S657>/Switch56' incorporates:
   *  Constant: '<S657>/LLSMConClb14'
   *
   * Block description for '<S657>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_k != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_k;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S657>/Switch56' */

  /* Switch: '<S657>/Switch51' incorporates:
   *  Constant: '<S657>/LLSMConClb15'
   *
   * Block description for '<S657>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_o != 0.0F) {
    rtb_LL_DvtComp_C_i = LKAS_ConstB.DataTypeConversion25_o;
  } else {
    rtb_LL_DvtComp_C_i = LL_DvtComp_C;
  }

  /* End of Switch: '<S657>/Switch51' */

  /* Switch: '<S657>/Switch52' incorporates:
   *  Constant: '<S657>/LLSMConClb16'
   *
   * Block description for '<S657>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36_b != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36_b;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S657>/Switch52' */

  /* Switch: '<S657>/Switch46' incorporates:
   *  Constant: '<S657>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S657>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_e != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_e;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S657>/Switch46' */

  /* Update for Delay: '<S125>/Delay' */
  LKAS_DW.Delay_DSTATE = rtb_Saturation1;

  /* Update for Memory: '<S133>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Add1;

  /* Update for Memory: '<S136>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = rtb_L0_C0;

  /* Update for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = rtb_Saturation;

  /* Update for Memory: '<S128>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_h = rtb_R0_C0;

  /* Update for Memory: '<S128>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = rtb_offset;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S141>/Delay' */
    LKAS_DW.Delay_DSTATE_o = LKAS_DW.LKASM_stLKAActvFlg;

    /* Update for Memory: '<S581>/Memory' */
    LKAS_DW.Memory_PreviousInput_j = rtb_Saturation_c;

    /* Update for Delay: '<S142>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.LKASM_stLKAState;

    /* Update for Memory: '<S524>/Memory' */
    LKAS_DW.Memory_PreviousInput_c = rtb_Saturation_f;

    /* Update for UnitDelay: '<S456>/Delay Input1'
     *
     * Block description for '<S456>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_iz;

    /* Update for UnitDelay: '<S455>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_i = LKAS_DW.RelationalOperator_a;

    /* Update for UnitDelay: '<S418>/Delay Input1'
     *
     * Block description for '<S418>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_c = rtb_Compare_km;

    /* Update for UnitDelay: '<S416>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_gu = LKAS_DW.RelationalOperator_c;

    /* Update for UnitDelay: '<S417>/Delay Input1'
     *
     * Block description for '<S417>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_p = rtb_Compare_cj;

    /* Update for Memory: '<S383>/Memory' */
    LKAS_DW.Memory_PreviousInput_eq = LKAS_DW.RelationalOperator_c;

    /* Update for Delay: '<S142>/Delay' */
    LKAS_DW.Delay_DSTATE_j = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S142>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.LDWSM_stLDWState;

    /* Update for Memory: '<S431>/Memory' */
    LKAS_DW.Memory_PreviousInput_id = rtb_LDW_State;

    /* Update for Memory: '<S357>/Memory' */
    LKAS_DW.Memory_PreviousInput_i = rtb_Merge1_n;

    /* Update for Memory: '<S393>/Memory' */
    LKAS_DW.Memory_PreviousInput_a = rtb_Merge1_j;

    /* Update for Memory: '<S593>/Memory' */
    LKAS_DW.Memory_PreviousInput_ac = rtb_Saturation_d;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S140>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S169>/Memory' */
      LKAS_DW.Memory_PreviousInput_ok = rtb_Saturation2_g;

      /* Update for Memory: '<S200>/Memory' */
      LKAS_DW.Memory_PreviousInput_mx = rtb_Saturation1_f;

      /* Update for Memory: '<S187>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_l = rtb_Saturation1_cv;

      /* Update for Memory: '<S199>/Memory' */
      LKAS_DW.Memory_PreviousInput_av = rtb_Saturation1_a;

      /* Update for Memory: '<S201>/Memory' */
      LKAS_DW.Memory_PreviousInput_nj = rtb_Saturation1_b;

      /* Update for Memory: '<S196>/Memory' */
      LKAS_DW.Memory_PreviousInput_p1 = rtb_Saturation1_k;

      /* Update for Memory: '<S184>/Memory' */
      LKAS_DW.Memory_PreviousInput_i3 = rtb_Add_l;

      /* Update for Memory: '<S170>/Memory' */
      LKAS_DW.Memory_PreviousInput_kz = rtb_Saturation2_l;

      /* Update for Memory: '<S171>/Memory' */
      LKAS_DW.Memory_PreviousInput_mo = rtb_Saturation2_n;

      /* Update for UnitDelay: '<S173>/Delay Input1'
       *
       * Block description for '<S173>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_px = rtb_Compare_az;

      /* Update for Memory: '<S171>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_k = rtb_Merge_ba;

      /* Update for Memory: '<S162>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_e = rtb_Saturation_gi;

      /* Update for Memory: '<S263>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_p = rtb_Saturation_e;

      /* Update for Memory: '<S246>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = rtb_Add1_h;

      /* Update for UnitDelay: '<S244>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_a = rtb_Switch2_at;

      /* Update for Memory: '<S252>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_m = rtb_Saturation_j;

      /* Update for Memory: '<S258>/Memory' */
      LKAS_DW.Memory_PreviousInput_f4 = rtb_Saturation1_m;

      /* Update for UnitDelay: '<S262>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_g = rtb_Switch_kb;

      /* Update for Memory: '<S262>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_b = rtb_Saturation_nf;

      /* Update for UnitDelay: '<S239>/Delay Input2'
       *
       * Block description for '<S239>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_b = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S239>/Memory' */
      LKAS_DW.Memory_PreviousInput_e = rtb_Saturation2_b;

      /* Update for Memory: '<S195>/Memory' */
      LKAS_DW.Memory_PreviousInput_b = rtb_Add_jk;

      /* Update for Memory: '<S197>/Memory' */
      LKAS_DW.Memory_PreviousInput_l = rtb_Saturation1_or;

      /* Update for Memory: '<S198>/Memory' */
      LKAS_DW.Memory_PreviousInput_oj = rtb_Saturation1_p;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S594>/Delay' */
    LKAS_DW.Delay_DSTATE_m = rtb_Switch8;

    /* Update for Delay: '<S595>/Delay' */
    LKAS_DW.Delay_DSTATE_d = rtb_Switch8_g;

    /* Update for Delay: '<S596>/Delay' */
    LKAS_DW.Delay_DSTATE_db = rtb_Switch8_l;

    /* Update for Delay: '<S142>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.LKA_Mode;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S650>/Delay Input2'
   *
   * Block description for '<S650>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_L0_C2;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_L0_Q);

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_ModifyScalingOnly_m);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single2'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)((uint8)rtb_LL_CompHdAg_C));

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single3'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    rtb_ModifyScalingOnly_h0);

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single4'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning
    ((UInt8)rtb_IMAPve_d_EPS_LKA_State);

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single5'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_ModifyScalingOnly_fc);

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single6'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status
    ((UInt8)rtb_ModifyScalingOnly_dio);

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq
    ((UInt8)rtb_R0_Q);

  /* Switch: '<S651>/Switch2' incorporates:
   *  Constant: '<S645>/Constant3'
   *  Constant: '<S645>/Constant4'
   *  RelationalOperator: '<S651>/LowerRelop1'
   *  RelationalOperator: '<S651>/UpperRelop'
   *  Switch: '<S651>/Switch'
   */
  if (rtb_L0_C2 > 5.0F) {
    rtb_L0_C2 = 5.0F;
  } else {
    if (rtb_L0_C2 < (-5.0F)) {
      /* Switch: '<S651>/Switch' incorporates:
       *  Constant: '<S645>/Constant4'
       */
      rtb_L0_C2 = (-5.0F);
    }
  }

  /* End of Switch: '<S651>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_L0_C2);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single8'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control
    ((UInt8)rtb_IMAPve_d_R1_Type);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/x1'
   */
  if (rtb_Merge_a3) {
    rtb_L0_C0 = LKAS_DW.OutputM;
  } else {
    rtb_L0_C0 = (float32)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_L0_C0);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S11>/Switch2' incorporates:
   *  Constant: '<S11>/2'
   *  Constant: '<S11>/x2'
   *  Constant: '<S648>/Constant'
   *  Constant: '<S649>/Constant'
   *  Logic: '<S11>/Logical Operator'
   *  RelationalOperator: '<S648>/Compare'
   *  RelationalOperator: '<S649>/Compare'
   */
  if ((rtb_IMAPve_d_R1_Type == ((uint8)4U)) || (rtb_IMAPve_d_R1_Type == ((uint8)
        3U))) {
    rtb_IMAPve_d_R1_Type = ((uint8)1U);
  } else {
    rtb_IMAPve_d_R1_Type = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    ((UInt8)rtb_IMAPve_d_R1_Type);

  /* Outport: '<Root>/LKASve_g_ob5H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5H_10_LKASve_g_ob5H_10
    (LKAS_DW.LKASve_g_ob5H_10);

  /* Outport: '<Root>/LKASve_g_ob5L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5L_10_LKASve_g_ob5L_10
    (LKAS_DW.LKASve_g_ob5L_10);

  /* Outport: '<Root>/LKASve_g_ob6H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6H_10_LKASve_g_ob6H_10
    (LKAS_DW.LKASve_g_ob6H_10);

  /* Outport: '<Root>/LKASve_g_ob6L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6L_10_LKASve_g_ob6L_10
    (LKAS_DW.LKASve_g_ob6L_10);

  /* Outport: '<Root>/LKASve_g_ob07H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07H_100_LKASve_g_ob07H_100
    (LKAS_DW.LKASve_g_ob07H_100);

  /* Outport: '<Root>/LKASve_g_ob07L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07L_100_LKASve_g_ob07L_100
    (LKAS_DW.LKASve_g_ob07L_100);

  /* Outport: '<Root>/LKASve_g_ob08H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08H_100_LKASve_g_ob08H_100
    (LKAS_DW.LKASve_g_ob08H_100);

  /* Outport: '<Root>/LKASve_g_ob08L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08L_100_LKASve_g_ob08L_100
    (LKAS_DW.LKASve_g_ob08L_100);
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S431>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S187>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S261>/If' */
  LKAS_DW.If_ActiveSubsystem_l = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack' */

  /*-----------S-Function Block: <S4>/CAN Unpack -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack1' */

  /*-----------S-Function Block: <S4>/CAN Unpack1 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack2' */

  /*-----------S-Function Block: <S4>/CAN Unpack2 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack3' */

  /*-----------S-Function Block: <S4>/CAN Unpack3 -----------------*/

  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* ConstCode for Constant: '<S2>/Version' */
  ob_LKA_Version = 220317.0F;

  /* End of ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S133>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* InitializeConditions for Memory: '<S136>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = (-1.75F);

  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = (-1.75F);

  /* InitializeConditions for Memory: '<S128>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_h = 1.75F;

  /* InitializeConditions for Memory: '<S128>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = 1.75F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S141>/Delay' */
  LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

  /* InitializeConditions for Memory: '<S581>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = 0.0F;

  /* InitializeConditions for Delay: '<S142>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S524>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 0.0F;

  /* InitializeConditions for UnitDelay: '<S456>/Delay Input1'
   *
   * Block description for '<S456>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S455>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_i = false;

  /* InitializeConditions for UnitDelay: '<S418>/Delay Input1'
   *
   * Block description for '<S418>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_c = false;

  /* InitializeConditions for UnitDelay: '<S416>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_gu = false;

  /* InitializeConditions for UnitDelay: '<S417>/Delay Input1'
   *
   * Block description for '<S417>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_p = false;

  /* InitializeConditions for Memory: '<S383>/Memory' */
  LKAS_DW.Memory_PreviousInput_eq = false;

  /* InitializeConditions for Delay: '<S142>/Delay' */
  LKAS_DW.Delay_DSTATE_j = false;

  /* InitializeConditions for Delay: '<S142>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S431>/Memory' */
  LKAS_DW.Memory_PreviousInput_id = ((uint8)0U);

  /* InitializeConditions for Memory: '<S357>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = 0.0F;

  /* InitializeConditions for Memory: '<S393>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S593>/Memory' */
  LKAS_DW.Memory_PreviousInput_ac = 0.0F;

  /* InitializeConditions for Delay: '<S594>/Delay' */
  LKAS_DW.Delay_DSTATE_m = ((uint8)0U);

  /* InitializeConditions for Delay: '<S595>/Delay' */
  LKAS_DW.Delay_DSTATE_d = ((uint8)0U);

  /* InitializeConditions for Delay: '<S596>/Delay' */
  LKAS_DW.Delay_DSTATE_db = ((uint8)0U);

  /* InitializeConditions for Delay: '<S142>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S444>/ExitCount' */
  /* InitializeConditions for Memory: '<S452>/Memory' */
  LKAS_DW.Memory_PreviousInput_no = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S444>/ExitCount' */

  /* SystemInitialize for Enabled SubSystem: '<S445>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S454>/Memory' */
  LKAS_DW.Memory_PreviousInput_k = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S445>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S455>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S459>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S455>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S383>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S414>/Memory' */
  LKAS_DW.Memory_PreviousInput_m5 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S383>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S383>/Count' */
  /* InitializeConditions for Memory: '<S413>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S383>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S416>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S422>/Memory' */
  LKAS_DW.Memory_PreviousInput_n2 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S416>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S384>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S428>/Memory' */
  LKAS_DW.Memory_PreviousInput_cp = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S384>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S431>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S461>/Memory' */
  LKAS_DW.Memory_PreviousInput_n = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S431>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S394>/Sum Condition' */
  /* InitializeConditions for Memory: '<S400>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S394>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S319>/Subsystem' */
  /* InitializeConditions for Memory: '<S323>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S319>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S169>/Memory' */
  LKAS_DW.Memory_PreviousInput_ok = 0.0F;

  /* InitializeConditions for Memory: '<S200>/Memory' */
  LKAS_DW.Memory_PreviousInput_mx = ((uint16)0U);

  /* InitializeConditions for Memory: '<S187>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_l = ((uint8)0U);

  /* InitializeConditions for Memory: '<S199>/Memory' */
  LKAS_DW.Memory_PreviousInput_av = ((uint16)0U);

  /* InitializeConditions for Memory: '<S201>/Memory' */
  LKAS_DW.Memory_PreviousInput_nj = ((uint16)0U);

  /* InitializeConditions for Memory: '<S196>/Memory' */
  LKAS_DW.Memory_PreviousInput_p1 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S184>/Memory' */
  LKAS_DW.Memory_PreviousInput_i3 = 0.0F;

  /* InitializeConditions for Memory: '<S170>/Memory' */
  LKAS_DW.Memory_PreviousInput_kz = 0.0F;

  /* InitializeConditions for Memory: '<S171>/Memory' */
  LKAS_DW.Memory_PreviousInput_mo = 0.0F;

  /* InitializeConditions for UnitDelay: '<S173>/Delay Input1'
   *
   * Block description for '<S173>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_px = false;

  /* InitializeConditions for Memory: '<S171>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_k = false;

  /* InitializeConditions for Memory: '<S162>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_e = 0.0F;

  /* InitializeConditions for Memory: '<S263>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_p = 0.0F;

  /* InitializeConditions for Memory: '<S246>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 0.0F;

  /* InitializeConditions for UnitDelay: '<S244>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_a = 0.0F;

  /* InitializeConditions for Memory: '<S252>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_m = 0.0F;

  /* InitializeConditions for Memory: '<S258>/Memory' */
  LKAS_DW.Memory_PreviousInput_f4 = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S262>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

  /* InitializeConditions for Memory: '<S262>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_b = 0.0F;

  /* InitializeConditions for UnitDelay: '<S239>/Delay Input2'
   *
   * Block description for '<S239>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_b = 0.0F;

  /* InitializeConditions for Memory: '<S239>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = ((uint16)0U);

  /* InitializeConditions for Memory: '<S195>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = ((uint16)0U);

  /* InitializeConditions for Memory: '<S197>/Memory' */
  LKAS_DW.Memory_PreviousInput_l = ((uint16)0U);

  /* InitializeConditions for Memory: '<S198>/Memory' */
  LKAS_DW.Memory_PreviousInput_oj = ((uint16)0U);

  /* SystemInitialize for Enabled SubSystem: '<S170>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S172>/Memory' */
  LKAS_DW.Memory_PreviousInput_n0 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S170>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S157>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S157>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S171>/Moving Standard Deviation1' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S171>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S171>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_j);

  /* End of SystemInitialize for SubSystem: '<S171>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S171>/Moving Standard Deviation2' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation2_d);

  /* End of SystemInitialize for SubSystem: '<S171>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S171>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_c);

  /* End of SystemInitialize for SubSystem: '<S171>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S171>/Sum Condition2' */
  /* InitializeConditions for Memory: '<S180>/Memory' */
  LKAS_DW.Memory_PreviousInput_ik = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S171>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S157>/Sum Condition2' */
  /* InitializeConditions for Memory: '<S161>/Memory' */
  LKAS_DW.Memory_PreviousInput_m4 = 0.0F;

  /* SystemInitialize for Outport: '<S161>/M3K' */
  LKAS_DW.Saturation3 = 1.0F;

  /* End of SystemInitialize for SubSystem: '<S157>/Sum Condition2' */

  /* SystemInitialize for IfAction SubSystem: '<S261>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S271>/Delay Input1'
   *
   * Block description for '<S271>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_b = false;

  /* InitializeConditions for Memory: '<S267>/Memory' */
  LKAS_DW.Memory_PreviousInput_ge = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S261>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S261>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S279>/Delay Input1'
   *
   * Block description for '<S279>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_m = false;

  /* InitializeConditions for Memory: '<S268>/Memory' */
  LKAS_DW.Memory_PreviousInput_ph = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S261>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S261>/Merge' */
  LKAS_DW.Merge_e = 1.0F;

  /* SystemInitialize for Merge: '<S261>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S144>/Merge' */
  LKAS_DW.Merge_l = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S144>/Sum Condition' */
  /* InitializeConditions for Memory: '<S148>/Memory' */
  LKAS_DW.Memory_PreviousInput_o2 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S144>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */

  /* SystemInitialize for Enabled SubSystem: '<S464>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1_l);

  /* End of SystemInitialize for SubSystem: '<S464>/Sum Condition1' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S645>/Subsystem' */
  /* InitializeConditions for Delay: '<S652>/Delay1' */
  LKAS_DW.Delay1_DSTATE = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S645>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S88>/Sum Condition2' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition2);

  /* End of SystemInitialize for SubSystem: '<S88>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S88>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1);

  /* End of SystemInitialize for SubSystem: '<S88>/Sum Condition1' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
