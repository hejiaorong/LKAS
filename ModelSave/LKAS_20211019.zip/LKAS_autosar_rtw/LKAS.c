/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.71
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Oct 19 08:36:44 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S78>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S78>/LKA_State_Machine' */
#define LKAS_IN_Fault_f                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_p      ((uint8)0U)
#define LKAS_IN_Normal_a               ((uint8)2U)
#define LKAS_IN_SysOff_c               ((uint8)2U)
#define LKAS_IN_SysOn_k                ((uint8)3U)
#define LKAS_IN_Unavailable_l          ((uint8)1U)
#define LKAS_IN_Unselected_n           ((uint8)2U)

/* Named constants for Chart: '<S55>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * Output and update for action system:
 *    '<S80>/If Action Subsystem2'
 *    '<S119>/if action 4'
 *    '<S120>/if action 4'
 *    '<S121>/if action 4'
 *    '<S122>/if action 4'
 *    '<S133>/If Action Subsystem3'
 *    '<S134>/If Action Subsystem3'
 *    '<S135>/If Action Subsystem3'
 *    '<S143>/If Action Subsystem3'
 *    '<S168>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S83>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S83>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/*
 * System initialize for atomic system:
 *    '<S94>/Moving Standard Deviation2'
 *    '<S106>/Moving Standard Deviation1'
 *    '<S106>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S102>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S94>/Moving Standard Deviation2'
 *    '<S106>/Moving Standard Deviation1'
 *    '<S106>/Moving Standard Deviation2'
 */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S102>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S94>/Moving Standard Deviation2'
 *    '<S106>/Moving Standard Deviation1'
 *    '<S106>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation2(float32 rtu_In1,
  DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_p;
  float32 rtb_Delay1_a;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S102>/Delay' */
  rtb_Delay_p = localDW->Delay_DSTATE;

  /* Delay: '<S102>/Delay1' */
  rtb_Delay1_a = localDW->Delay1_DSTATE;

  /* Delay: '<S102>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S102>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S102>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S102>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S102>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S102>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S102>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S102>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S102>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S102>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S102>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S102>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S102>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S102>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S102>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S102>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S102>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S102>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S102>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S102>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S102>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S102>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S102>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S102>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S102>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S102>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S102>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S102>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S102>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S102>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S102>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S102>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S102>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S102>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S102>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S102>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S102>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S102>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S102>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S102>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S102>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S102>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S102>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S102>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S102>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S102>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S102>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S102>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_p;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_a;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S102>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S102>/Standard Deviation' */

  /* Update for Delay: '<S102>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S102>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_p;

  /* Update for Delay: '<S102>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S102>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S102>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S102>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S102>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S102>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S102>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S102>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S102>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S102>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S102>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_a;

  /* Update for Delay: '<S102>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S102>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S102>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S102>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S102>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S102>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S102>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S102>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S102>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S102>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S102>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S102>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S102>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S102>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S102>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S102>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S102>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S102>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S102>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S102>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S102>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S102>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S102>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S102>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S102>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S102>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S102>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S102>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S102>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S102>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S102>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S102>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S102>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S102>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S102>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S102>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S106>/Sum Condition'
 *    '<S106>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S110>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S106>/Sum Condition'
 *    '<S106>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S110>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S106>/Sum Condition'
 *    '<S106>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S106>/Sum Condition' incorporates:
   *  EnablePort: '<S110>/Enable'
   */
  /* Disable for Outport: '<S110>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S106>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S106>/Sum Condition'
 *    '<S106>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_dn;

  /* Outputs for Enabled SubSystem: '<S106>/Sum Condition' incorporates:
   *  EnablePort: '<S110>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S110>/Add1' incorporates:
     *  Memory: '<S110>/Memory'
     */
    rtb_Saturation_dn = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S110>/Saturation' */
    if (rtb_Saturation_dn > 100.0F) {
      rtb_Saturation_dn = 100.0F;
    } else {
      if (rtb_Saturation_dn < 0.0F) {
        rtb_Saturation_dn = 0.0F;
      }
    }

    /* End of Saturate: '<S110>/Saturation' */

    /* RelationalOperator: '<S110>/Relational Operator' */
    *rty_Out = (rtb_Saturation_dn >= rtu_In1);

    /* Update for Memory: '<S110>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_dn;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S106>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S119>/if action 3'
 *    '<S120>/if action 3'
 *    '<S121>/if action 3'
 *    '<S122>/if action 3'
 *    '<S133>/If Action Subsystem2'
 *    '<S133>/If Action Subsystem1'
 *    '<S134>/If Action Subsystem2'
 *    '<S134>/If Action Subsystem1'
 *    '<S135>/If Action Subsystem2'
 *    '<S135>/If Action Subsystem1'
 *    ...
 */
void LKAS_ifaction3(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S125>/In1' */
  *rty_Out1 = rtu_In1;
}

/* System initialize for action system: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculati_Init(void)
{
  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_fm = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory' */
  LKAS_DW.Memory_PreviousInput_hm = ((uint16)0U);

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_p5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_h = 0.0F;

  /* InitializeConditions for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_kp = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S121>/Memory' */
  LKAS_DW.Memory_PreviousInput_a1 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_d = 0.0F;

  /* InitializeConditions for Memory: '<S122>/Memory' */
  LKAS_DW.Memory_PreviousInput_ce = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/* System reset for action system: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculat_Reset(void)
{
  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_fm = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory' */
  LKAS_DW.Memory_PreviousInput_hm = ((uint16)0U);

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_p5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_h = 0.0F;

  /* InitializeConditions for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_kp = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S121>/Memory' */
  LKAS_DW.Memory_PreviousInput_a1 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_d = 0.0F;

  /* InitializeConditions for Memory: '<S122>/Memory' */
  LKAS_DW.Memory_PreviousInput_ce = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/*
 * Output and update for action system: '<S87>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S87>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  /* local block i/o variables */
  float32 rtb_Memory1;
  float32 rtb_Memory2;
  float32 rtb_Memory3;
  float32 rtb_Memory4;
  float32 rtb_Merge1;
  float32 rtb_Merge1_b;
  float32 rtb_Merge1_e;
  float32 rtb_Merge1_d;
  float32 rtb_K1K2Det_dphi2PhSWAGrad2;
  float32 rtb_K1K2Det_stReplFlag;
  float32 rtb_K1K2Det_dphi1PhHdAgIni;
  float32 DelteSW0;
  float32 u;
  float32 Kw;
  float32 StpLngth;
  float32 Mode1Num;
  float32 Mode2Num;
  float32 D2_End;
  float32 DelteSW1;
  float32 K1;
  float32 K2_2;
  float32 T2;
  sint32 a;
  float32 K2;
  float32 c_T1;
  float32 c_T2;
  float32 K1_0;
  uint16 rtb_Add;
  uint16 rtb_Add_im;
  uint16 rtb_Add_bj;
  uint16 rtb_Add_f2;
  uint16 rtb_Add_e;
  uint16 rtb_Merge;
  uint16 rtb_Add_e_0;

  /* Sum: '<S118>/Add' incorporates:
   *  Constant: '<S118>/Constant'
   *  Memory: '<S118>/Memory'
   */
  rtb_Add = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_fm));

  /* Saturate: '<S118>/Saturation1' */
  if (rtb_Add < ((uint16)100U)) {
    rtb_Merge = rtb_Add;
  } else {
    rtb_Merge = ((uint16)100U);
  }

  /* End of Saturate: '<S118>/Saturation1' */

  /* If: '<S118>/If' incorporates:
   *  Constant: '<S118>/Constant19'
   *  Inport: '<S123>/In1'
   *  Memory: '<S112>/Memory'
   */
  if (rtb_Merge == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S118>/if action 2' incorporates:
     *  ActionPort: '<S124>/Action Port'
     */
    /* SignalConversion: '<S124>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
     *  Constant: '<S124>/Constant'
     */
    rtb_Merge = ((uint16)0U);

    /* End of Outputs for SubSystem: '<S118>/if action 2' */
  } else {
    /* Outputs for IfAction SubSystem: '<S118>/if action 1' incorporates:
     *  ActionPort: '<S123>/Action Port'
     */
    rtb_Merge = LKAS_DW.Memory_PreviousInput_hm;

    /* End of Outputs for SubSystem: '<S118>/if action 1' */
  }

  /* End of If: '<S118>/If' */

  /* Sum: '<S119>/Add' incorporates:
   *  Constant: '<S119>/Constant'
   *  Memory: '<S119>/Memory'
   */
  rtb_Add_im = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_p5));

  /* Memory: '<S112>/Memory1' */
  rtb_Memory1 = LKAS_DW.Memory1_PreviousInput_h;

  /* Saturate: '<S119>/Saturation1' */
  if (rtb_Add_im < ((uint16)100U)) {
    rtb_Add_bj = rtb_Add_im;
  } else {
    rtb_Add_bj = ((uint16)100U);
  }

  /* End of Saturate: '<S119>/Saturation1' */

  /* If: '<S119>/If' incorporates:
   *  Constant: '<S119>/Constant19'
   */
  if (rtb_Add_bj == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S119>/if action 4' incorporates:
     *  ActionPort: '<S126>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1);

    /* End of Outputs for SubSystem: '<S119>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S119>/if action 3' incorporates:
     *  ActionPort: '<S125>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory1, &rtb_Merge1);

    /* End of Outputs for SubSystem: '<S119>/if action 3' */
  }

  /* End of If: '<S119>/If' */

  /* Sum: '<S120>/Add' incorporates:
   *  Constant: '<S120>/Constant'
   *  Memory: '<S120>/Memory'
   */
  rtb_Add_bj = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_kp));

  /* Memory: '<S112>/Memory2' */
  rtb_Memory2 = LKAS_DW.Memory2_PreviousInput;

  /* Saturate: '<S120>/Saturation1' */
  if (rtb_Add_bj < ((uint16)100U)) {
    rtb_Add_f2 = rtb_Add_bj;
  } else {
    rtb_Add_f2 = ((uint16)100U);
  }

  /* End of Saturate: '<S120>/Saturation1' */

  /* If: '<S120>/If' incorporates:
   *  Constant: '<S120>/Constant19'
   */
  if (rtb_Add_f2 == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S120>/if action 4' incorporates:
     *  ActionPort: '<S128>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_b);

    /* End of Outputs for SubSystem: '<S120>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S120>/if action 3' incorporates:
     *  ActionPort: '<S127>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory2, &rtb_Merge1_b);

    /* End of Outputs for SubSystem: '<S120>/if action 3' */
  }

  /* End of If: '<S120>/If' */

  /* Sum: '<S121>/Add' incorporates:
   *  Constant: '<S121>/Constant'
   *  Memory: '<S121>/Memory'
   */
  rtb_Add_f2 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_a1));

  /* Memory: '<S112>/Memory3' */
  rtb_Memory3 = LKAS_DW.Memory3_PreviousInput_d;

  /* Saturate: '<S121>/Saturation1' */
  if (rtb_Add_f2 < ((uint16)100U)) {
    rtb_Add_e = rtb_Add_f2;
  } else {
    rtb_Add_e = ((uint16)100U);
  }

  /* End of Saturate: '<S121>/Saturation1' */

  /* If: '<S121>/If' incorporates:
   *  Constant: '<S121>/Constant19'
   */
  if (rtb_Add_e == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S121>/if action 4' incorporates:
     *  ActionPort: '<S130>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_e);

    /* End of Outputs for SubSystem: '<S121>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S121>/if action 3' incorporates:
     *  ActionPort: '<S129>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory3, &rtb_Merge1_e);

    /* End of Outputs for SubSystem: '<S121>/if action 3' */
  }

  /* End of If: '<S121>/If' */

  /* Sum: '<S122>/Add' incorporates:
   *  Constant: '<S122>/Constant'
   *  Memory: '<S122>/Memory'
   */
  rtb_Add_e = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_ce));

  /* Memory: '<S112>/Memory4' */
  rtb_Memory4 = LKAS_DW.Memory4_PreviousInput;

  /* Saturate: '<S122>/Saturation1' */
  if (rtb_Add_e < ((uint16)100U)) {
    rtb_Add_e_0 = rtb_Add_e;
  } else {
    rtb_Add_e_0 = ((uint16)100U);
  }

  /* End of Saturate: '<S122>/Saturation1' */

  /* If: '<S122>/If' incorporates:
   *  Constant: '<S122>/Constant19'
   */
  if (rtb_Add_e_0 == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S122>/if action 4' incorporates:
     *  ActionPort: '<S132>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_d);

    /* End of Outputs for SubSystem: '<S122>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S122>/if action 3' incorporates:
     *  ActionPort: '<S131>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory4, &rtb_Merge1_d);

    /* End of Outputs for SubSystem: '<S122>/if action 3' */
  }

  /* End of If: '<S122>/If' */

  /* MATLAB Function: '<S112>/MATLAB Function' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLAB Function': '<S117>:1' */
  /* '<S117>:1:55' LDDir = K1K2Det_stLDDir; */
  /* '<S117>:1:56' D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S117>:1:57' D2_des = K1K2Det_lDesDvt; */
  /* '<S117>:1:58' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_k * 0.0174532924F;

  /* '<S117>:1:59' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S117>:1:60' TTLCHdAg = K1K2Det_phiTTLCHdAgIni; */
  /* '<S117>:1:61' Delte_Psi2 = K1K2Det_phi2PhDesHdAg; */
  /* '<S117>:1:62' Delte_Psi1Ini = K1K2Det_phi1PhDesHdAgIni; */
  /* '<S117>:1:63' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S117>:1:64' TTLCCrvt = K1K2Det_crPrvwTTLCCrvt; */
  /* '<S117>:1:65' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S117>:1:66' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S117>:1:67' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S117>:1:68' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_e / 3.6F;

  /* '<S117>:1:69' Kw=u/(L*(1+K*u*u)*i); */
  Kw = u / (((((LKAS_DW.StbFacm_SY * u) * u) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_k)
            * LKAS_DW.LKA_StrRatio_C_g);

  /*      DelteSW1 = single(0); */
  /* '<S117>:1:71' K1K2Det_stReplFlag = single(0); */
  rtb_K1K2Det_stReplFlag = 0.0F;

  /* '<S117>:1:72' StpLngth = K1K2Det_lStpLngth*(pi/180); */
  StpLngth = LKAS_DW.LL_lStpLngth_C_h * 0.0174532924F;

  /* '<S117>:1:73' ModeFlg = K1K2Det_bsTDivInfo_ModeFlg; */
  /* '<S117>:1:74' Mode1Num = K1K2Det_bsTDivInfo_Mode1Num; */
  Mode1Num = rtb_Merge1;

  /* '<S117>:1:75' Mode2Num = K1K2Det_bsTDivInfo_Mode2Num; */
  Mode2Num = rtb_Merge1_b;

  /* '<S117>:1:76' D2_End =  K1K2Det_bsTDivInfo_Ph2DvtEnd; */
  D2_End = rtb_Merge1_e;

  /* '<S117>:1:77' DelteSW1 = K1K2Det_bsTDivInfo_Ph2SWAIni; */
  DelteSW1 = rtb_Merge1_d;

  /* '<S117>:1:78' K1 = single(0); */
  K1 = 0.0F;

  /* '<S117>:1:79' K2_1 = single(0); */
  K2 = 0.0F;

  /* '<S117>:1:80' K2_2 = single(0); */
  K2_2 = 0.0F;

  /* '<S117>:1:81' KMax = K1K2Det_dphiSWARMax; */
  /* ************************************************************************** */
  /*  */
  /*  if (LDDir*PrvwHdAg < LDDir*TTLCHdAg) */
  /*      Delte_Psi1 = PrvwHdAg; */
  /*  else */
  /*      Delte_Psi1 = TTLCHdAg; */
  /*  end */
  /* '<S117>:1:89' Delte_Psi1 = PrvwHdAg; */
  /* '<S117>:1:90' if (ModeFlg == 0) */
  if (((sint32)rtb_Merge) == 0) {
    /* '<S117>:1:91' [K1,K2_1,K2_2,D2_End,DelteSW1]= func1(Delte_Psi1,TTLC,Kw,DelteSW0,Delte_Psi2,u,D1_Ini,Delte_Psi1Ini); */
    /*     ���ܣ� */
    /*     ��֪����ʼת����ת�ǣ�TTLC��һ����������Ǳ������뿪����ʱ����������� */
    /*     Լ����1��һ������ʱ����TTLCʱ��ʵ�������ĺ���Ǳ仯�� */
    /*           2����������ʱ��ת����ת��Ϊ�㣻 */
    /*           3����������ʱ��ʵ�������ĺ���ǵĺ���ǡ� */
    /*      */
    /*     ����� һ��ת����ת�Ǳ仯��K1������ת����ת�Ǳ仯��K2_1��K2_2����������ʱ��ƫ��������ֵD2 */
    /* ************************************************************************** */
    /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
    /*  end of function K1K2Det */
    /*  */
    /* ***************************************** */
    /*  1������func1�������������ʱ��ƫ��������ֵƫ����D2_0; */
    /*      */
    /*  2����D2_0<=D2_des������ú���func2�����������k1��k2_1��k2_2��ͬ���ڶ�������ʱ�� */
    /*     Ӧ��ͬʱʵ����������Ǻ�����ƫ������ */
    /*  3����D2_0>D2_des_max������ú���F,2�����������k1��k2_1��k2_2������k2_1 = k2_2�� */
    /*     �ڶ�������ʱ��Ӧ��ͬʱʵ����������Ǻ�����ƫ������ */
    /*  */
    /* '<S117>:1:168' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
    K1 = ((-2.0F * LKAS_DW.In_e3) / ((Kw * LKAS_DW.MPInP_tiTTLCIni) *
           LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F * DelteSW0) /
      LKAS_DW.MPInP_tiTTLCIni);

    /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
    /* '<S117>:1:171' DelteSW1 = DelteSW0+K1*TTLC; */
    DelteSW1 = (K1 * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

    /* '<S117>:1:172' Delte_Psi = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1)*TTLC*Kw; */
    D2_End = ((((DelteSW0 + DelteSW1) * 0.5F) * LKAS_DW.MPInP_tiTTLCIni) * Kw) +
      LKAS_DW.In_it;

    /* ����Լ��2��3���������K2�� */
    /* '<S117>:1:174' K2 = -DelteSW1*DelteSW1*Kw/(2*(Delte_Psi2-Delte_Psi)); */
    K2 = (((-DelteSW1) * DelteSW1) * Kw) / ((LKAS_DW.In_br - D2_End) * 2.0F);

    /* ����K2��DelteSW1�ͳ��٣����Լ��������������ƫ�����ı仯��D2�Ͷ�������ʱ��T2�� */
    /* '<S117>:1:176' T1 = (DelteSW1-DelteSW0)/K1; */
    c_T1 = (DelteSW1 - DelteSW0) / K1;

    /* '<S117>:1:177' T2 = (0-DelteSW1)/K2; */
    c_T2 = (0.0F - DelteSW1) / K2;

    /*      D1 = u*((1/6)*Kw*(2*DelteSW0+DelteSW1)*T1^2+Delte_Psi1*T1); */
    /*      D2 = u*((1/3)*Kw*T2^2*DelteSW1); */
    /* '<S117>:1:180' D1 = u*((1/6)*Kw*(DelteSW1+2*DelteSW0)*T1*T1+Delte_Psi1Ini*T1); */
    /* '<S117>:1:181' D2 = u*((1/3)*Kw*T2*T2*DelteSW1+Delte_Psi*T2); */
    /* '<S117>:1:182' D2_End = D1+D2; */
    /*  */
    /* ************************************************************************** */
    /* ����� */
    /*    K1 = K1; */
    /* '<S117>:1:187' K2_1 = K2; */
    /* '<S117>:1:188' K2_2 = K2; */
    K2_2 = K2;
    D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) * c_T1) *
                c_T1) + (LKAS_DW.In_it * c_T1)) * u) + ((((((0.333333343F * Kw) *
      c_T2) * c_T2) * DelteSW1) + (D2_End * c_T2)) * u);
  }

  /* '<S117>:1:93' if(0< D2_End*LDDir && D2_End*LDDir <= D2_des && ModeFlg == 0) */
  c_T1 = D2_End * LKAS_DW.Merge;
  if (((0.0F < c_T1) && (c_T1 <= LKAS_DW.LL_DesDvt_C_e)) && (((sint32)rtb_Merge)
       == 0)) {
    /* '<S117>:1:95' K1K2Det_stReplFlag = single(0); */
    rtb_K1K2Det_stReplFlag = 0.0F;
  } else {
    if ((c_T1 > LKAS_DW.LL_DesDvt_C_e) || (((sint32)rtb_Merge) != 0)) {
      /* '<S117>:1:97' elseif(D2_End*LDDir > D2_des || ModeFlg ~= 0 ) */
      /* '<S117>:1:99' K1K2Det_stReplFlag = single(1); */
      rtb_K1K2Det_stReplFlag = 1.0F;

      /* '<S117>:1:101' for a = 1:8 */
      for (a = 0; a < 8; a++) {
        /* '<S117>:1:103' if (D2_End*LDDir>D2_des && ModeFlg==0) */
        c_T1 = D2_End * LKAS_DW.Merge;
        if ((c_T1 > LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 0)) {
          /* '<S117>:1:104' ModeFlg = uint16(1); */
          rtb_Merge = 1U;
        }

        /* '<S117>:1:106' if (D2_End*LDDir>D2_des && ModeFlg==1) */
        if ((c_T1 > LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 1)) {
          /* '<S117>:1:107' DelteSW1 =  LDDir*StpLngth+DelteSW1; */
          DelteSW1 += LKAS_DW.Merge * StpLngth;

          /* '<S117>:1:108' Mode1Num = Mode1Num+1; */
          Mode1Num++;
        }

        /* '<S117>:1:110' if (D2_End*LDDir <= D2_des && ModeFlg==1) */
        if ((c_T1 <= LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 1)) {
          /* '<S117>:1:111' ModeFlg = uint16(2); */
          rtb_Merge = 2U;
        }

        /* '<S117>:1:113' if (D2_End*LDDir<D2_des && ModeFlg==2) */
        if ((c_T1 < LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 2)) {
          /* '<S117>:1:114' DelteSW1 =  DelteSW1-LDDir*StpLngth*((1/2)^(Mode2Num+1)); */
          DelteSW1 -= (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);

          /* '<S117>:1:115' Mode2Num = Mode2Num+1; */
          Mode2Num++;
        }

        /* '<S117>:1:117' if (D2_End*LDDir>=D2_des && ModeFlg==2) */
        if ((c_T1 >= LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 2)) {
          /* '<S117>:1:118' DelteSW1 =  DelteSW1+LDDir*StpLngth*((1/2)^(Mode2Num+1)); */
          DelteSW1 += (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);

          /* '<S117>:1:119' Mode2Num = Mode2Num+1; */
          Mode2Num++;
        }

        /* '<S117>:1:121' [T1,T2,D2_End] = func3(Delte_Psi1Ini,Delte_Psi2,DelteSW1,KMax,Delte_Psi1,... */
        /* '<S117>:1:122'                                 DelteSW0,u,Kw,LDDir); */
        /*     ���ܣ� */
        /*     ��֪������һ��ʱ��ʼ����ǣ��뿪����ʱ����������ǣ�����һ��ʱ��ƫ�����ĳ�ʼֵ */
        /*           �������ʱ��ת����ת�ǳ�ʼֵ����ʼת����ת�ǣ����١� */
        /*     ���裺1������һ������ʱ��ת����ת�ǣ�ʵ��һ���������ĺ���Ǳ仯�� */
        /*           2������һ������ʱ��ת����ת�ǣ�ʵ�ֶ����������ĺ���Ǳ仯�� */
        /*           3������ʵ��һ���������ĺ���Ǳ仯����������һ��ƫ�����仯��D1�� */
        /*           4������ʵ�ֶ����������ĺ���Ǳ仯���������Ķ���ƫ�����仯��D2�� */
        /*           5) ���ݽ���һ��ʱ��ƫ�����ĳ�ʼֵ��D1��D2���õ���������ʱ��ƫ����D2_End */
        /*      */
        /*     ����� һ��ʹ��ʱ��T1������ʹ��ʱ��T2����������ʱ��ƫ����D2_End */
        /* ************************************************************************** */
        /*  end of function func1 */
        /*  function [K1,K2_1,K2_2,DelteSW1]= func2(Delte_Psi1,Delte_Psi2,D1_Ini,T1,... */
        /*                                          D2_des,LDDir,DelteSW0,u,Kw) */
        /*  %    ���ܣ� */
        /*  %    ��֪��һ����������Ǳ仯�����뿪����ʱ����������ǣ���������ʱ������ƫ�����ľ���ֵ */
        /*  %          �����ĳ���ƫ��ķ��򣬳�ʼת����ת�ǣ����١� */
        /*  %    Լ����1������һ������ʱ��ת����ת�ǣ�ʵ�������ĺ���Ǳ仯�� */
        /*  %          2����������ʱ��ƫ����ʵ������ƫ������ */
        /*  %          3����������ʱ��ʵ�������ĺ���ǵĺ���ǣ� */
        /*  %          4����������ʱ��ת����ת��Ϊ�㡣 */
        /*  %     */
        /*  %    ����� һ��ת����ת�Ǳ仯��K1������ת����ת�Ǳ仯��K2_1��K2_2�� */
        /*  %           �������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
        /*  %************************************************************************** */
        /*  %   ����Լ��2��3��4���������DelteSW1�Ͷ���ת����ת�Ǳ仯�ʡ� */
        /*  Delte_D = LDDir*D2_des-D1_Ini; */
        /*  Delte_Psi = Delte_Psi2-Delte_Psi1; */
        /*  DelteSW1 = ((4/3)*(Delte_Psi/Kw)*(Delte_Psi/Kw)-(1/3)*(Delte_Psi/Kw)*DelteSW0*T1-(1/6)*DelteSW0*DelteSW0*T1*T1... */
        /*              +2*(Delte_Psi/Kw)*Delte_Psi1-Delte_Psi1*DelteSW0*T1)/(Delte_D/(Kw*u)+(1/3)*(Delte_Psi/Kw)*T1); */
        /*  T2 = (2*(Delte_Psi/Kw)-(DelteSW1+DelteSW0)*T1)/DelteSW1; */
        /*  K2 = -DelteSW1/T2; */
        /*  %   ����Լ��1�ͽ������ʱ��ת����ת�ǳ�ʼֵDelteSW1���������һ��ת����ת�Ǳ仯�ʡ� */
        /*  K1 = (DelteSW1-DelteSW0)/T1; */
        /*  % */
        /*  %************************************************************************** */
        /*  %   ����� */
        /*  K2_1 = K2; */
        /*  K2_2 = K2; */
        /*   */
        /*  end % end of function func1 */
        /* '<S117>:1:233' K1_0 = (DelteSW1*DelteSW1-DelteSW0*DelteSW0)*Kw/(-2*Delte_Psi1); */
        K1_0 = (((DelteSW1 * DelteSW1) - (DelteSW0 * DelteSW0)) * Kw) / (-2.0F *
          LKAS_DW.In_e3);

        /* '<S117>:1:234' if (LDDir*K1_0 > KMax) */
        if ((LKAS_DW.Merge * K1_0) > LKAS_DW.SWARmax) {
          /* '<S117>:1:235' K1_1 = single(LDDir*KMax); */
          K1_0 = LKAS_DW.Merge * LKAS_DW.SWARmax;
        } else {
          /* '<S117>:1:236' else */
          /* '<S117>:1:237' K1_1 = K1_0; */
        }

        /*  */
        /* '<S117>:1:240' T1 = (DelteSW1-DelteSW0)/K1_1; */
        K1_0 = (DelteSW1 - DelteSW0) / K1_0;

        /* '<S117>:1:243' Delte_Psi = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1)*T1*Kw; */
        K1 = ((((DelteSW0 + DelteSW1) * 0.5F) * K1_0) * Kw) + LKAS_DW.In_it;

        /*  DelteSW1_0 = 2*(Delte_Psi2-Delte_Psi1Ini)/(T1*Kw)-DelteSW0; */
        /*  if (-1*Delte_Psi >= -1*Delte_Psi2) */
        /*     DelteSW1_1 = DelteSW1_0; */
        /*  else */
        /*     DelteSW1_1 = DelteSW1; */
        /*  end */
        /*  Delte_Psi_1 = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1_1)*T1*Kw; */
        /* '<S117>:1:251' T2 = 2*(Delte_Psi2-Delte_Psi)/(DelteSW1*Kw); */
        T2 = ((LKAS_DW.In_br - K1) * 2.0F) / (DelteSW1 * Kw);

        /*      T1 = 2*(Delte_Psi-Delte_Psi1)/((DelteSW0+DelteSW1)*Kw); */
        /*      T1 = TTLC; */
        /*      T2 = 2*(Delte_Psi2-Delte_Psi)/(DelteSW1*Kw); */
        /* '<S117>:1:256' D1 = u*((1/6)*Kw*(DelteSW1+2*DelteSW0)*T1*T1+Delte_Psi1Ini*T1); */
        /* '<S117>:1:257' D2 = u*((1/3)*Kw*T2*T2*DelteSW1+Delte_Psi*T2); */
        /* '<S117>:1:258' D2_End = D2+D1; */
        D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) *
                     K1_0) * K1_0) + (LKAS_DW.In_it * K1_0)) * u) +
          ((((((0.333333343F * Kw) * T2) * T2) * DelteSW1) + (K1 * T2)) * u);
      }

      /* '<S117>:1:124' K1 = (DelteSW1-DelteSW0)/T1; */
      K1 = (DelteSW1 - DelteSW0) / K1_0;

      /* '<S117>:1:125' K2_1 = (0-DelteSW1)/T2; */
      K2 = (0.0F - DelteSW1) / T2;

      /* '<S117>:1:126' K2_2 = K2_1; */
      K2_2 = K2;
    }
  }

  /*  */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S117>:1:130' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S117>:1:132' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = K1 * 57.2957802F;

  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /* '<S117>:1:134' K1K2Det_dphi2PhSWAGrad1 = K2_1*(180/pi); */
  LKAS_DW.K1K2Det_dphi2PhSWAGrad1 = K2 * 57.2957802F;

  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /* '<S117>:1:136' K1K2Det_dphi2PhSWAGrad2 = K2_2*(180/pi); */
  rtb_K1K2Det_dphi2PhSWAGrad2 = K2_2 * 57.2957802F;

  /*  */
  /* '<S117>:1:138' K1K2Det_dphi1PhHdAgIni = Delte_Psi1; */
  rtb_K1K2Det_dphi1PhHdAgIni = LKAS_DW.In_e3;

  /* Update for Memory: '<S118>/Memory' */
  /*  */
  /* '<S117>:1:140' K1K2Det_bsTDivInfoOut_ModeFlg = ModeFlg; */
  /* '<S117>:1:141' K1K2Det_bsTDivInfoOut_Mode1Num = Mode1Num; */
  /* '<S117>:1:142' K1K2Det_bsTDivInfoOut_Mode2Num = Mode2Num; */
  /* '<S117>:1:143' K1K2Det_bsTDivInfoOut_Ph2DvtEnd = D2_End; */
  /* '<S117>:1:144' K1K2Det_bsTDivInfoOut_Ph2SWAIni = DelteSW1; */
  LKAS_DW.Memory_PreviousInput_fm = rtb_Add;

  /* Update for Memory: '<S112>/Memory' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory_PreviousInput_hm = rtb_Merge;

  /* Update for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_p5 = rtb_Add_im;

  /* Update for Memory: '<S112>/Memory1' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory1_PreviousInput_h = Mode1Num;

  /* Update for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_kp = rtb_Add_bj;

  /* Update for Memory: '<S112>/Memory2' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory2_PreviousInput = Mode2Num;

  /* Update for Memory: '<S121>/Memory' */
  LKAS_DW.Memory_PreviousInput_a1 = rtb_Add_f2;

  /* Update for Memory: '<S112>/Memory3' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory3_PreviousInput_d = D2_End;

  /* Update for Memory: '<S122>/Memory' */
  LKAS_DW.Memory_PreviousInput_ce = rtb_Add_e;

  /* Update for Memory: '<S112>/Memory4' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory4_PreviousInput = DelteSW1;
}

/*
 * Output and update for action system:
 *    '<S136>/if action '
 *    '<S137>/if action '
 *    '<S138>/if action '
 *    '<S139>/if action '
 *    '<S140>/if action '
 *    '<S141>/if action '
 *    '<S142>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S153>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S168>/If Action Subsystem'
 *    '<S168>/If Action Subsystem4'
 *    '<S116>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S170>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for atomic system:
 *    '<S178>/Saturable Gain Lut (SatGainLut)'
 *    '<S178>/Saturable Gain Lut (SatGainLut)1'
 */
void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32 rtu_InputLimLwr,
  float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32 rtu_GainLimUpr,
  float32 *rty_Gain)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S181>:1' */
  /*  Function Name: Saturable Gain Lut */
  /*  */
  /*  Description:  */
  /*    Saturable Gain Lookup Table. */
  /*  */
  /*  Assumptions and Limitation: */
  /*    The data type of all inputs and output is single. */
  /*  */
  /*  Inputs: */
  /*    Input: */
  /*    InputLimLwr: */
  /*    InputLimUpr: */
  /*    GainLimLwr: */
  /*    GainLimUpr: */
  /*  */
  /*  Outputs: */
  /*    Gain: The result of Looking up table. */
  /*  $Revision: 1.0$ */
  /*  $Author: Zhang Jianwei$ */
  /*  $Date: January 27, 2019$ */
  /*  ________________________________________ */
  /* '<S181>:1:25' if Input <= InputLimLwr */
  if (rtu_Input <= rtu_InputLimLwr) {
    /* '<S181>:1:26' Gain = GainLimLwr; */
    *rty_Gain = rtu_GainLimLwr;
  } else if (rtu_Input >= rtu_InputLimUpr) {
    /* '<S181>:1:27' elseif Input >= InputLimUpr */
    /* '<S181>:1:28' Gain = GainLimUpr; */
    *rty_Gain = rtu_GainLimUpr;
  } else {
    /* '<S181>:1:29' else */
    /* '<S181>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
    /* '<S181>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
    *rty_Gain = (((rtu_Input - rtu_InputLimLwr) / (rtu_InputLimUpr -
      rtu_InputLimLwr)) * (rtu_GainLimUpr - rtu_GainLimLwr)) + rtu_GainLimLwr;
  }
}

/*
 * Output and update for action system:
 *    '<S185>/If Action Subsystem'
 *    '<S185>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_b(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S187>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S206>/if action '
 *    '<S207>/if action '
 *    '<S214>/if action '
 *    '<S215>/if action '
 */
void LKAS_ifaction_p(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S208>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S199>/If Action Subsystem'
 *    '<S200>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_m(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_i_T *localDW)
{
  uint16 rtb_Saturation1_l;
  uint16 rtb_Saturation1_og;

  /* Outputs for Enabled SubSystem: '<S199>/If Action Subsystem' incorporates:
   *  EnablePort: '<S204>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S206>/Add' incorporates:
     *  Constant: '<S206>/Constant'
     *  Memory: '<S206>/Memory'
     */
    rtb_Saturation1_l = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S206>/Saturation1' */
    if (rtb_Saturation1_l >= ((uint16)10000U)) {
      rtb_Saturation1_l = ((uint16)10000U);
    }

    /* End of Saturate: '<S206>/Saturation1' */

    /* If: '<S206>/If' incorporates:
     *  Constant: '<S206>/Constant2'
     */
    if (rtb_Saturation1_l <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S206>/if action ' incorporates:
       *  ActionPort: '<S208>/Action Port'
       */
      LKAS_ifaction_p(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S206>/if action ' */
    }

    /* End of If: '<S206>/If' */

    /* Sum: '<S207>/Add' incorporates:
     *  Constant: '<S207>/Constant'
     *  Memory: '<S207>/Memory'
     */
    rtb_Saturation1_og = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_k));

    /* Saturate: '<S207>/Saturation1' */
    if (rtb_Saturation1_og >= ((uint16)10000U)) {
      rtb_Saturation1_og = ((uint16)10000U);
    }

    /* End of Saturate: '<S207>/Saturation1' */

    /* If: '<S207>/If' incorporates:
     *  Constant: '<S207>/Constant2'
     */
    if (rtb_Saturation1_og == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S207>/if action ' incorporates:
       *  ActionPort: '<S209>/Action Port'
       */
      LKAS_ifaction_p(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S207>/if action ' */
    }

    /* End of If: '<S207>/If' */

    /* Update for Memory: '<S206>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_l;

    /* Update for Memory: '<S207>/Memory' */
    localDW->Memory_PreviousInput_k = rtb_Saturation1_og;
  }

  /* End of Outputs for SubSystem: '<S199>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S199>/If Action Subsystem2'
 *    '<S200>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_f(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S205>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S205>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S78>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_l = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_m = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c33_LKAS = 0U;
  LKAS_DW.is_c33_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.LDWSM_stLDWActvFlg = 0U;
  LKAS_DW.LDWSM_stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S78>/LDW_State_Machine'
 * Block description for: '<S78>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S78>/LDW_State_Machine'
   *
   * Block description for '<S78>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c33_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c33_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S263>:2' */
    LKAS_DW.is_c33_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S263>:1' */
    /* Transition: '<S263>:31' */
    LKAS_DW.is_SysOff_l = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S263>:30' */
    LKAS_DW.LDWSM_stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c33_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S263>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && ((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) ==
            2))) {
        /* Transition: '<S263>:38' */
        /* Exit Internal 'Fault': '<S263>:36' */
        LKAS_DW.is_c33_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S263>:3' */
        /* Transition: '<S263>:77' */
        LKAS_DW.is_SysOn_m = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S263>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.Divide) == 0) && tmp) {
        /* Transition: '<S263>:40' */
        /* Exit Internal 'Fault': '<S263>:36' */
        LKAS_DW.is_c33_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_l = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S263>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else {
        LKAS_DW.LDWSM_stLDWState = 6U;

        /* During 'LDWFault': '<S263>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S263>:1' */
      if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
          (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S263>:39' */
        /* Exit Internal 'SysOff': '<S263>:1' */
        LKAS_DW.is_SysOff_l = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c33_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S263>:36' */
        /* Transition: '<S263>:75' */
        /* Entry 'LDWFault': '<S263>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) ==
                  2)) {
        /* Transition: '<S263>:41' */
        /* Exit Internal 'SysOff': '<S263>:1' */
        LKAS_DW.is_SysOff_l = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c33_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S263>:3' */
        /* Transition: '<S263>:77' */
        LKAS_DW.is_SysOn_m = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S263>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_l) == LKAS_IN_Unavailable) {
        LKAS_DW.LDWSM_stLDWState = 0U;

        /* During 'Unavailable': '<S263>:30' */
        if (((sint32)LKAS_DW.Divide) == 0) {
          /* Transition: '<S263>:35' */
          LKAS_DW.is_SysOff_l = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S263>:32' */
          LKAS_DW.LDWSM_stLDWState = 1U;
        }
      } else {
        LKAS_DW.LDWSM_stLDWState = 1U;

        /* During 'Unselected': '<S263>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S263>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S263>:37' */
        /* Exit Internal 'SysOn': '<S263>:3' */
        if (((uint32)LKAS_DW.is_SysOn_m) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S263>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S263>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S263>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_m = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_m = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c33_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S263>:36' */
        /* Transition: '<S263>:75' */
        /* Entry 'LDWFault': '<S263>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.Divide) != 1) && (((sint32)LKAS_DW.Divide) !=
                  2)) {
        /* Transition: '<S263>:42' */
        /* Exit Internal 'SysOn': '<S263>:3' */
        if (((uint32)LKAS_DW.is_SysOn_m) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S263>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S263>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S263>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_m = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_m = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c33_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_l = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S263>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_m) == LKAS_IN_LDWSelected) {
        LKAS_DW.LDWSM_stLDWState = 2U;

        /* During 'LDWSelected': '<S263>:47' */
        if ((LKAS_DW.Merge_la) && (!LKAS_DW.Merge1_b)) {
          /* Transition: '<S263>:50' */
          LKAS_DW.is_SysOn_m = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S263>:102' */
          /* Transition: '<S263>:113' */
          LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S263>:112' */
          LKAS_DW.LDWSM_stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S263>:102' */
        if (LKAS_DW.Merge1_b) {
          /* Transition: '<S263>:44' */
          /* Exit Internal 'Normal': '<S263>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S263>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S263>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_m = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S263>:47' */
          LKAS_DW.LDWSM_stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.LDWSM_stLDWState = 3U;

            /* During 'LDWEnable': '<S263>:112' */
            if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_a)) {
              /* Transition: '<S263>:118' */
              LKAS_DW.is_Normal_i = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S263>:114' */
              LKAS_DW.LDWSM_stLDWState = 4U;
              LKAS_DW.LDWSM_stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_a))
              {
                /* Transition: '<S263>:119' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S263>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.LDWSM_stLDWState = 4U;

            /* During 'LDWLeftActive': '<S263>:114' */
            if (LKAS_DW.Merge_a) {
              /* Transition: '<S263>:116' */
              /* Exit 'LDWLeftActive': '<S263>:114' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S263>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_a))
              {
                /* Transition: '<S263>:120' */
                /* Exit 'LDWLeftActive': '<S263>:114' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S263>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LDWSM_stLDWState = 5U;

            /* During 'LDWRightActive': '<S263>:115' */
            if (LKAS_DW.Merge_a) {
              /* Transition: '<S263>:117' */
              /* Exit 'LDWRightActive': '<S263>:115' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S263>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_a))
              {
                /* Transition: '<S263>:121' */
                /* Exit 'LDWRightActive': '<S263>:115' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S263>:114' */
                LKAS_DW.LDWSM_stLDWState = 4U;
                LKAS_DW.LDWSM_stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S78>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S78>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_p;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_p;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
  LKAS_DW.is_active_c35_LKAS = 0U;
  LKAS_DW.is_c35_LKAS = LKAS_IN_NO_ACTIVE_CHILD_p;
  LKAS_DW.LKASM_stLKAActvFlg = 0U;
  LKAS_DW.LKASM_stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S78>/LKA_State_Machine'
 * Block description for: '<S78>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S78>/LKA_State_Machine'
   *
   * Block description for '<S78>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  if (((uint32)LKAS_DW.is_active_c35_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    LKAS_DW.is_active_c35_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    /* Transition: '<S264>:2' */
    LKAS_DW.is_c35_LKAS = LKAS_IN_SysOff_c;

    /* Entry Internal 'SysOff': '<S264>:1' */
    /* Transition: '<S264>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_l;

    /* Entry 'Unavailable': '<S264>:30' */
    LKAS_DW.LKASM_stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c35_LKAS) {
     case LKAS_IN_Fault_f:
      /* During 'Fault': '<S264>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.Divide) == 2)) {
        /* Transition: '<S264>:38' */
        /* Exit Internal 'Fault': '<S264>:36' */
        LKAS_DW.is_c35_LKAS = LKAS_IN_SysOn_k;

        /* Entry Internal 'SysOn': '<S264>:3' */
        /* Transition: '<S264>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S264>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.Divide) == 0) || (((sint32)LKAS_DW.Divide) ==
        1)) && tmp) {
        /* Transition: '<S264>:40' */
        /* Exit Internal 'Fault': '<S264>:36' */
        LKAS_DW.is_c35_LKAS = LKAS_IN_SysOff_c;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_n;

        /* Entry 'Unselected': '<S264>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else {
        LKAS_DW.LKASM_stLKAState = 6U;

        /* During 'LKAFault': '<S264>:72' */
      }
      break;

     case LKAS_IN_SysOff_c:
      /* During 'SysOff': '<S264>:1' */
      if ((((sint32)LKAS_DW.Divide) == 2) && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S264>:39' */
        /* Exit Internal 'SysOff': '<S264>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_p;
        LKAS_DW.is_c35_LKAS = LKAS_IN_Fault_f;

        /* Entry Internal 'Fault': '<S264>:36' */
        /* Transition: '<S264>:74' */
        /* Entry 'LKAFault': '<S264>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.Divide) == 2) {
        /* Transition: '<S264>:41' */
        /* Exit Internal 'SysOff': '<S264>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_p;
        LKAS_DW.is_c35_LKAS = LKAS_IN_SysOn_k;

        /* Entry Internal 'SysOn': '<S264>:3' */
        /* Transition: '<S264>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S264>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_l) {
        LKAS_DW.LKASM_stLKAState = 0U;

        /* During 'Unavailable': '<S264>:30' */
        if ((((sint32)LKAS_DW.Divide) == 0) || (((sint32)LKAS_DW.Divide) == 1))
        {
          /* Transition: '<S264>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_n;

          /* Entry 'Unselected': '<S264>:32' */
          LKAS_DW.LKASM_stLKAState = 1U;
        }
      } else {
        LKAS_DW.LKASM_stLKAState = 1U;

        /* During 'Unselected': '<S264>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S264>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S264>:37' */
        /* Exit Internal 'SysOn': '<S264>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_a) {
          /* Exit Internal 'Normal': '<S264>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S264>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S264>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_p;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_p;
        }

        LKAS_DW.is_c35_LKAS = LKAS_IN_Fault_f;

        /* Entry Internal 'Fault': '<S264>:36' */
        /* Transition: '<S264>:74' */
        /* Entry 'LKAFault': '<S264>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.Divide) != 2) {
        /* Transition: '<S264>:42' */
        /* Exit Internal 'SysOn': '<S264>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_a) {
          /* Exit Internal 'Normal': '<S264>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S264>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S264>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_p;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_p;
        }

        LKAS_DW.is_c35_LKAS = LKAS_IN_SysOff_c;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_n;

        /* Entry 'Unselected': '<S264>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.LKASM_stLKAState = 2U;

        /* During 'LKASelected': '<S264>:19' */
        if ((LKAS_DW.Merge1_m) && (!LKAS_DW.Merge2)) {
          /* Transition: '<S264>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_a;

          /* Entry Internal 'Normal': '<S264>:102' */
          /* Transition: '<S264>:103' */
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S264>:108' */
          LKAS_DW.LKASM_stLKAState = 3U;
        }
      } else {
        /* During 'Normal': '<S264>:102' */
        if (LKAS_DW.Merge2) {
          /* Transition: '<S264>:25' */
          /* Exit Internal 'Normal': '<S264>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S264>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S264>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_p;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

          /* Entry 'LKASelected': '<S264>:19' */
          LKAS_DW.LKASM_stLKAState = 2U;
        } else {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKAEnable:
            LKAS_DW.LKASM_stLKAState = 3U;

            /* During 'LKAEnable': '<S264>:108' */
            if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_k)) {
              /* Transition: '<S264>:105' */
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

              /* Entry 'LKALeftActive': '<S264>:109' */
              LKAS_DW.LKASM_stLKAState = 4U;
              LKAS_DW.LKASM_stLKAActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_k))
              {
                /* Transition: '<S264>:104' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S264>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LKALeftActive:
            LKAS_DW.LKASM_stLKAState = 4U;

            /* During 'LKALeftActive': '<S264>:109' */
            if (LKAS_DW.Merge1_k) {
              /* Transition: '<S264>:106' */
              /* Exit 'LKALeftActive': '<S264>:109' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S264>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_k))
              {
                /* Transition: '<S264>:111' */
                /* Exit 'LKALeftActive': '<S264>:109' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S264>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LKASM_stLKAState = 5U;

            /* During 'LKARightActive': '<S264>:110' */
            if (LKAS_DW.Merge1_k) {
              /* Transition: '<S264>:107' */
              /* Exit 'LKARightActive': '<S264>:110' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S264>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_k))
              {
                /* Transition: '<S264>:112' */
                /* Exit 'LKARightActive': '<S264>:110' */
                LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

                /* Entry 'LKALeftActive': '<S264>:109' */
                LKAS_DW.LKASM_stLKAState = 4U;
                LKAS_DW.LKASM_stLKAActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S78>/LKA_State_Machine' */
}

/*
 * Output and update for atomic system:
 *    '<S281>/MATLAB Function'
 *    '<S317>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_LaneWidth, float32 rtu_LKA_CarWidth,
  float32 rtu_DvtThresUprLDW, float32 *rty_ThresDet_coefficient)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S284>:1' */
  /* '<S284>:1:2' LanWid = single(min(max(single(2.4),LaneWidth),single(3.6))); */
  /* '<S284>:1:3' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
  /* '<S284>:1:4' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
  *rty_ThresDet_coefficient = fminf(fmaxf(0.0F, (fminf(fmaxf(2.4F, rtu_LaneWidth),
    3.6F) - ((2.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth)) / (4.0F *
    rtu_DvtThresUprLDW)), 1.0F);
}

/*
 * Output and update for action system:
 *    '<S285>/Ph1SWA'
 *    '<S294>/Ph1SWA'
 *    '<S321>/Ph1SWA'
 *    '<S331>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S289>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S289>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S285>/Ph2SWA'
 *    '<S294>/Ph2SWA'
 *    '<S321>/Ph2SWA'
 *    '<S331>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S290>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S290>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S285>/Ph3SWA'
 *    '<S321>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S291>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S294>/Ph3SWA'
 *    '<S331>/Ph3SWA'
 */
void LKAS_Ph3SWA_c(float32 *rty_Out)
{
  /* SignalConversion: '<S300>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S300>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S344>/If Action Subsystem3'
 *    '<S383>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S349>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S357>/If Action Subsystem4'
 *    '<S357>/If Action Subsystem3'
 *    '<S466>/If Action Subsystem3'
 *    '<S466>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S369>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S369>/Constant'
   */
  *rty_Out = false;
}

/*
 * Output and update for action system:
 *    '<S395>/If Action Subsystem'
 *    '<S395>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_e(boolean *rty_Out)
{
  /* SignalConversion: '<S399>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S399>/Constant'
   */
  *rty_Out = true;
}

/*
 * System initialize for enable system:
 *    '<S270>/Count_5s1'
 *    '<S270>/Count_5s2'
 */
void LKAS_Count_5s1_Init(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S533>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S270>/Count_5s1'
 *    '<S270>/Count_5s2'
 */
void LKAS_Count_5s1_Reset(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S533>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S270>/Count_5s1'
 *    '<S270>/Count_5s2'
 */
void LKAS_Count_5s1_Disable(boolean *rty_Out, DW_Count_5s1_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S270>/Count_5s1' incorporates:
   *  EnablePort: '<S533>/Enable'
   */
  /* Disable for Outport: '<S533>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S270>/Count_5s1' */
  localDW->Count_5s1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S270>/Count_5s1'
 *    '<S270>/Count_5s2'
 */
void LKAS_Count_5s1(boolean rtu_Enable, float32 rtu_SampleTime, boolean *rty_Out,
                    DW_Count_5s1_LKAS_T *localDW)
{
  float32 rtb_Saturation_ds;

  /* Outputs for Enabled SubSystem: '<S270>/Count_5s1' incorporates:
   *  EnablePort: '<S533>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Reset(localDW);
      localDW->Count_5s1_MODE = true;
    }

    /* Sum: '<S533>/Add' incorporates:
     *  Memory: '<S533>/Memory'
     */
    rtb_Saturation_ds = localDW->Memory_PreviousInput + rtu_SampleTime;

    /* Saturate: '<S533>/Saturation' */
    if (rtb_Saturation_ds > 11.0F) {
      rtb_Saturation_ds = 11.0F;
    } else {
      if (rtb_Saturation_ds < 0.0F) {
        rtb_Saturation_ds = 0.0F;
      }
    }

    /* End of Saturate: '<S533>/Saturation' */

    /* RelationalOperator: '<S533>/Relational Operator' incorporates:
     *  Constant: '<S533>/Constant1'
     */
    *rty_Out = (rtb_Saturation_ds >= ((float32)((uint16)5U)));

    /* Update for Memory: '<S533>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_ds;
  } else {
    if (localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S270>/Count_5s1' */
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_IMAPve_g_ESC_VehSpd;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_Gain_p;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_Gain_pu;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_LFClb_TFC_KpVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KpVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KpV1_C;
  float32 rtb_LL_LFClb_TFC_KpV2_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KdV1_C;
  float32 rtb_LL_LFClb_TFC_KdV2_C;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_R0_VR_m;
  float32 rtb_L0_VR_g;
  float32 rtb_R0_W_d;
  float32 rtb_L0_W_c;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_L1_TLC;
  float32 rtb_R1_VR;
  float32 rtb_R1_W;
  float32 rtb_R1_TLC;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_EPS_SteeringAngle;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_IMAPve_g_L0_Confidence;
  float32 rtb_IMAPve_g_L1_Confidence;
  float32 rtb_IMAPve_g_R0_Confidence;
  float32 rtb_IMAPve_g_R1_Confidence;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_j;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1;
  float32 rtb_Add5_j;
  float32 rtb_Add_pq;
  float32 rtb_Add_m;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge_c;
  float32 rtb_Switch_k;
  float32 rtb_Saturation_g;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Add1_o;
  float32 rtb_Switch_h;
  float32 rtb_Switch2_f;
  float32 rtb_Switch_go;
  float32 rtb_Saturation_l;
  float32 rtb_Abs1_o;
  float32 rtb_Abs_h;
  float32 rtb_UnaryMinus_b;
  float32 rtb_Merge1_a;
  float32 rtb_Divide_c;
  float32 rtb_Switch_g2;
  float32 rtb_Switch2_ad;
  float32 rtb_Divide_l;
  float32 rtb_Switch_a;
  float32 rtb_Switch2_d;
  float32 rtb_Merge1_k;
  float32 rtb_Divide_ll;
  float32 rtb_Switch_gc;
  float32 rtb_Switch2_m;
  float32 rtb_Divide_n;
  float32 rtb_Switch_b4;
  float32 rtb_Switch2_j;
  float32 rtb_Add1_a;
  float32 rtb_Switch_b3;
  float32 rtb_Switch2_n;
  float32 rtb_Memory_a;
  float32 rtb_Merge1_o;
  float32 rtb_Divide_i4;
  float32 rtb_Switch_l;
  float32 rtb_Switch2_k;
  float32 rtb_Divide_g;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_l;
  float32 rtb_Memory_dr;
  float32 rtb_Merge1_l;
  float32 rtb_Divide_iz;
  float32 rtb_Switch_er;
  float32 rtb_Switch2_b;
  float32 rtb_Divide_d;
  float32 rtb_Switch_p;
  float32 rtb_Switch2_ne;
  float32 rtb_phiHdAg;
  float32 rtb_Add_nb;
  float32 rtb_Add_jr;
  float32 rtb_Add_d;
  float32 rtb_Add_pv;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_ThresDet_coefficient;
  float32 rtb_ThresDet_coefficient_f;
  float32 rtb_Saturation2;
  float32 rtb_Merge_h;
  float32 rtb_Abs1_n;
  float32 rtb_Abs_p;
  float32 rtb_Add1_ac;
  float32 rtb_Merge_p;
  float32 rtb_Merge_i;
  float32 rtb_Merge_pw;
  float32 rtb_Add_oi;
  float32 rtb_Saturation6_k;
  float32 rtb_Saturation2_n;
  float32 rtb_Saturation2_g;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_k;
  float32 rtb_Saturation_ns;
  float32 rtb_Add1_eq;
  float32 rtb_kphtomps_j;
  float32 rtb_Saturation_a;
  float32 rtb_Switch2_ly;
  float32 rtb_Switch_ku;
  float32 rtb_Switch2_d1;
  float32 rtb_Divide5;
  float32 rtb_Divide2_e;
  float32 rtb_Divide7;
  float32 rtb_Switch_j0;
  float32 rtb_Switch2_ke;
  float32 rtb_Saturation_kf;
  float32 rtb_Switch_js;
  float32 rtb_Add_mb;
  float32 rtb_Switch_m;
  float32 rtb_Switch2_i;
  float32 rtb_UkYk1_k;
  float32 rtb_Switch_b1f;
  float32 rtb_Switch2_i1;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_g3;
  float32 rtb_Saturation_o;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_T2;
  float32 rtb_Plan;
  float32 rtb_T1_n;
  float32 rtb_Plan_d;
  float32 rtb_T1_d;
  float32 rtb_Gain_n;
  float32 rtb_Yk1_h;
  float32 rtb_deltafalllimit_c;
  float32 rtb_Saturation4;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_b;
  uint16 rtb_Saturation1_p;
  uint16 rtb_Saturation1_h;
  uint16 rtb_Add_ov;
  uint16 rtb_Saturation1_n;
  uint16 rtb_Saturation1_hl;
  uint16 rtb_Saturation1_j;
  uint16 rtb_Saturation1_id;
  uint16 rtb_Saturation2_m;
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_p;
  uint8 rtb_L0_Type_a;
  uint8 rtb_R0_LC_j;
  uint8 rtb_L0_LC_f;
  uint8 rtb_L1_Type;
  uint8 rtb_L1_LC;
  uint8 rtb_R1_Type;
  uint8 rtb_R1_LC;
  uint8 rtb_IMAPve_d_APA_AutoPark_WorkS;
  uint8 rtb_IMAPve_d_BCM_LeftTurn_Switc;
  uint8 rtb_IMAPve_d_BCM_RightTurn_Swit;
  uint8 rtb_IMAPve_d_Camera_Signal_Faul;
  uint8 rtb_IMAPve_d_ConsArea;
  uint8 rtb_IMAPve_d_EPS_Driver_Active_;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_IMAPve_d_LDW_Warn_Mode;
  uint8 rtb_IMAPve_d_Lane_Valid;
  uint8 rtb_IMAPve_d_MP5_AutoPilot_Swit;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_IMAPve_d_ORI_Lane_ConsArea;
  uint8 rtb_IMAPve_d_ORI_Lane_RoadType;
  uint8 rtb_IMAPve_d_ORI_Lane_Valid;
  uint8 rtb_IMAPve_d_Road_Type;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_LDW_State;
  uint8 rtb_DACMode;
  uint8 rtb_Saturation1_cw;
  boolean rtb_Compare_l5;
  boolean rtb_Compare_d;
  boolean rtb_Event_FaulETATDA;
  boolean rtb_Compare_d5;
  boolean rtb_Compare_ao;
  boolean rtb_Compare_aw;
  boolean rtb_Compare_pt;
  boolean rtb_Compare_lf;
  boolean rtb_Compare_m;
  boolean rtb_Compare_f;
  boolean rtb_Compare_n;
  boolean rtb_Event_FaulSWS;
  boolean rtb_Compare_gpu;
  boolean rtb_UnitDelay_e;
  boolean rtb_Compare_by;
  boolean rtb_Merge_n;
  boolean rtb_Merge_b;
  boolean rtb_Compare_hu;
  boolean rtb_UnitDelay_eg;
  boolean rtb_Compare_oq;
  boolean rtb_Merge_ph;
  boolean rtb_Compare_f2;
  boolean rtb_Compare_jc;
  boolean rtb_LogicalOperator1_ht;
  boolean rtb_Compare_mw;
  boolean rtb_Compare_eh;
  boolean rtb_RelationalOperator6_g;
  boolean rtb_RelationalOperator5;
  float32 x10;
  float32 x20;
  float32 x1;
  sint32 i;
  uint8 rtb_IMAPve_d_BCM_HazardLamp;
  uint8 rtb_IMAPve_d_BCM_Left_Light;
  uint8 rtb_IMAPve_d_BCM_Right_Light;
  uint8 rtb_IMAPve_d_Camera_Status;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  float32 rtb_IMAPve_g_ESC_LatAcc;
  UInt8 rtb_EPS_LKA_Control;
  uint8 rtb_DataTypeConversion;
  float32 rtb_L0_C2;
  float32 rtb_R0_C2;
  float32 rtb_L0_C0;
  float32 rtb_R0_C0;
  float32 rtb_Add1;
  float32 rtb_Saturation_jn;
  uint8 rtb_R0_Type;
  uint8 rtb_IMAPve_d_TCU_Actual_Gear;
  uint8 rtb_TCU_ActualGear;
  uint8 rtb_LKA_Action_Indication;
  float32 rtb_Switch_f;
  uint8 rtb_R0_Q;
  float32 rtb_L0_C0_c;
  float32 rtb_L0_C1;
  float32 rtb_R0_C1;
  float32 rtb_L0_C1_c;
  float32 rtb_L0_C2_c;
  float32 rtb_L0_C3;
  float32 rtb_R0_C3;
  float32 rtb_L0_C3_k;
  float32 rtb_L0_TLC;
  float32 rtb_R0_TLC;
  float32 rtb_L0_TLC_i;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LKASWASyn_TrqSwaAddSwt;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_Saturation6;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_o;
  boolean rtb_LogicalOperator3_np;
  boolean rtb_LogicalOperator3_b;
  boolean rtb_LogicalOperator_ps;
  boolean rtb_Compare_hv;
  boolean rtb_Compare_og;
  boolean rtb_LogicalOperator_lz;
  boolean rtb_Compare_gn;
  boolean rtb_LogicalOperator_f;
  boolean rtb_Compare_a2p;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_fh;
  boolean rtb_stDvrTkConFlg_i;
  boolean rtb_LogicalOperator_i3;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge;
  boolean rtb_Compare_l4;
  boolean rtb_Compare_ckd;
  float32 rtb_offset;
  uint16 rtb_Saturation_i3;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  uint8 rtb_L0_Q_l;
  uint8 rtb_R0_Q_dp;
  float32 rtb_TTLC;
  float32 rtb_TLft;
  float32 rtb_LKA_Veh2CamL_C_tmp;
  float32 rtb_Add5_j_tmp;
  float32 rtb_LogicalOperator3_h_tmp;
  float32 rtb_LogicalOperator3_h_tmp_0;
  float32 rtb_Add_pq_tmp;
  float32 rtb_Add_m_tmp;
  boolean exitg1;

  /* Inport: '<Root>/IMAPve_d_LKA_Main_Switch' */
  Rte_Read_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch(&rtb_Saturation_i3);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp'
   */
  rtb_IMAPve_d_BCM_HazardLamp = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_Left_Light'
   */
  rtb_IMAPve_d_BCM_Left_Light = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_Right_Light'
   */
  rtb_IMAPve_d_BCM_Right_Light = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Camera_Status'
   */
  rtb_IMAPve_d_Camera_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_LKA_State'
   */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  rtb_IMAPve_g_EPS_SW_Trq = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  rtb_IMAPve_g_ESC_LonAcc = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  rtb_IMAPve_g_ESC_VehSpd = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  rtb_IMAPve_g_SW_Angle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle();

  /* Product: '<S50>/Divide' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1'
   *  Inport: '<Root>/IMAPve_d_LKA_Mode'
   *  Sum: '<S50>/Add'
   */
  LKAS_DW.Divide = (uint8)(((uint32)((uint8)(((uint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode())) +
    ((uint32)((uint8)1U))))) * ((uint32)((uint8)rtb_Saturation_i3)));

  /* DataTypeConversion: '<S54>/Data Type Conversion' incorporates:
   *  Constant: '<S54>/Constant'
   */
  rtb_DataTypeConversion = (uint8)LL_LaneSelect;

  /* Switch: '<S54>/Switch' */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L0_Q'
     */
    rtb_L0_Q_l = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q
      ();

    /* Switch: '<S59>/Switch' incorporates:
     *  Constant: '<S59>/Constant'
     */
    if (rtb_L0_Q_l >= ((uint8)2U)) {
      rtb_L0_Q_l = ((uint8)3U);
    }

    /* End of Switch: '<S59>/Switch' */

    /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R0_Q'
     */
    rtb_R0_Q_dp = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q();

    /* Switch: '<S56>/Switch1' incorporates:
     *  Constant: '<S56>/Constant1'
     */
    if (rtb_R0_Q_dp >= ((uint8)2U)) {
      rtb_R0_Q = ((uint8)3U);
    } else {
      rtb_R0_Q = rtb_R0_Q_dp;
    }

    /* End of Switch: '<S56>/Switch1' */
  } else {
    /* DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_ORI_L0_Q'
     */
    rtb_L0_Q_l = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L0_Q_IMAPve_d_ORI_L0_Q();

    /* Switch: '<S58>/Switch' incorporates:
     *  Constant: '<S58>/Constant'
     */
    if (rtb_L0_Q_l >= ((uint8)2U)) {
      rtb_L0_Q_l = ((uint8)3U);
    }

    /* End of Switch: '<S58>/Switch' */

    /* DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_ORI_R0_Q'
     */
    rtb_R0_Q_dp = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R0_Q_IMAPve_d_ORI_R0_Q();

    /* Switch: '<S57>/Switch1' incorporates:
     *  Constant: '<S57>/Constant1'
     */
    if (rtb_R0_Q_dp >= ((uint8)2U)) {
      rtb_R0_Q = ((uint8)3U);
    } else {
      rtb_R0_Q = rtb_R0_Q_dp;
    }

    /* End of Switch: '<S57>/Switch1' */
  }

  /* Chart: '<S55>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c9_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c9_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S60>:4' */
    LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S60>:3' */
    /* '<S60>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S60>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S60>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c9_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S60>:9' */
      /* '<S60>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q_l) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S60>:13' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S60>:3' */
        /* '<S60>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S60>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S60>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S60>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q_l) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S60>:14' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S60>:7' */
          /* '<S60>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S60>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S60>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S60>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_L0_Q_l) < 3) && (((sint32)rtb_R0_Q) == 3)) {
            /* Transition: '<S60>:23' */
            LKAS_DW.is_c9_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S60>:5' */
            /* '<S60>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S60>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S60>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S60>:5' */
      /* '<S60>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q_l) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S60>:16' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S60>:3' */
        /* '<S60>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S60>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S60>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S60>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q_l) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S60>:18' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S60>:7' */
          /* '<S60>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S60>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S60>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S60>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_R0_Q) < 3) {
            /* Transition: '<S60>:11' */
            LKAS_DW.is_c9_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S60>:3' */
      /* '<S60>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q_l) < 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S60>:6' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S60>:5' */
        /* '<S60>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S60>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S60>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S60>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q_l) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S60>:8' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S60>:7' */
          /* '<S60>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S60>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S60>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S60>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_L0_Q_l) < 3) && (((sint32)rtb_R0_Q) < 3)) {
            /* Transition: '<S60>:10' */
            /* '<S60>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c9_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S60>:7' */
      /* '<S60>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q_l) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S60>:17' */
        LKAS_DW.is_c9_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S60>:3' */
        /* '<S60>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S60>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S60>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S60>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_L0_Q_l) < 3) && (((sint32)rtb_R0_Q) == 3)) {
          /* Transition: '<S60>:19' */
          LKAS_DW.is_c9_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S60>:5' */
          /* '<S60>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S60>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S60>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S60>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_L0_Q_l) < 3) {
            /* Transition: '<S60>:12' */
            LKAS_DW.is_c9_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S55>/LaneReconstructSM' */

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C0'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C2'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C0'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C2'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   *  UnaryMinus: '<S54>/Unary Minus'
   *  UnaryMinus: '<S54>/Unary Minus2'
   *  UnaryMinus: '<S54>/Unary Minus4'
   *  UnaryMinus: '<S54>/Unary Minus6'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0
      ()));
    rtb_L0_C2 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2
      ()));
    rtb_R0_C2 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2
      ()));
    rtb_R0_C0 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0
      ()));
  } else {
    rtb_L0_C0 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C0_IMAPve_g_ORI_L0_C0();
    rtb_L0_C2 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C2_IMAPve_g_ORI_L0_C2();
    rtb_R0_C2 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C2_IMAPve_g_ORI_R0_C2();
    rtb_R0_C0 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C0_IMAPve_g_ORI_R0_C0();
  }

  /* Sum: '<S74>/Add1' incorporates:
   *  Gain: '<S70>/Gain'
   *  Memory: '<S74>/Memory'
   *  Product: '<S74>/Divide'
   *  Product: '<S74>/Divide1'
   *  Sum: '<S70>/Add'
   */
  rtb_Add1 = ((((-1.0F) * rtb_L0_C0) + rtb_R0_C0) * LKAS_ConstB.Divide2) +
    (LKAS_ConstB.Add2 * LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S70>/Saturation' */
  if (rtb_Add1 > 5.5F) {
    rtb_Saturation_jn = 5.5F;
  } else if (rtb_Add1 < 2.5F) {
    rtb_Saturation_jn = 2.5F;
  } else {
    rtb_Saturation_jn = rtb_Add1;
  }

  /* End of Saturate: '<S70>/Saturation' */

  /* Abs: '<S65>/Abs' incorporates:
   *  Sum: '<S65>/Add2'
   */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S71>:1' */
  /* '<S71>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S71>:1:3' cur=min(single(0.004),cur); */
  /* '<S71>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S71>:1:5' offset=min(single(0.5),offset); */
  rtb_L0_TLC_i = fabsf(rtb_L0_C2 + rtb_R0_C2);

  /* Saturate: '<S65>/Saturation' */
  if (rtb_L0_TLC_i > 0.004F) {
    rtb_L0_TLC_i = 0.004F;
  } else {
    if (rtb_L0_TLC_i < 0.0F) {
      rtb_L0_TLC_i = 0.0F;
    }
  }

  /* End of Saturate: '<S65>/Saturation' */

  /* MATLAB Function: '<S65>/get_roadside_offset' */
  rtb_offset = fminf(0.5F, (((fminf(0.004F, rtb_L0_TLC_i) / 0.004F) + 1.0F) *
    0.2F) * (fminf(4.0F, rtb_Saturation_jn) - 2.0F));

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_Type_1'
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   *  Inport: '<Root>/IMAPve_d_ORI_L0_Type'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_R0_Q_dp = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type();
  } else {
    rtb_R0_Q_dp = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L0_Type_IMAPve_d_ORI_L0_Type();
  }

  /* Switch: '<S65>/Switch' incorporates:
   *  Constant: '<S68>/Constant'
   *  RelationalOperator: '<S68>/Compare'
   *  Sum: '<S65>/Add'
   */
  if (rtb_R0_Q_dp == ((uint8)10U)) {
    rtb_L0_C0 += rtb_offset;
  }

  /* End of Switch: '<S65>/Switch' */

  /* Switch: '<S66>/Switch' incorporates:
   *  Abs: '<S66>/Abs'
   *  Constant: '<S72>/Constant'
   *  Memory: '<S66>/Memory'
   *  Memory: '<S66>/Memory1'
   *  Product: '<S66>/Divide'
   *  Product: '<S66>/Divide1'
   *  RelationalOperator: '<S72>/Compare'
   *  Sum: '<S66>/Add1'
   *  Sum: '<S66>/Add3'
   */
  if (fabsf(rtb_L0_C0 - LKAS_DW.Memory1_PreviousInput) > 0.5F) {
    rtb_Switch_f = rtb_L0_C0;
  } else {
    rtb_Switch_f = (rtb_L0_C0 * LKAS_ConstB.Divide2_m) + (LKAS_ConstB.Add2_i *
      LKAS_DW.Memory_PreviousInput_m);
  }

  /* End of Switch: '<S66>/Switch' */

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_LT_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1'
   *  Inport: '<Root>/IMAPve_d_ORI_R0_LT'
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_R0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type();
  } else {
    rtb_R0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R0_LT_IMAPve_d_ORI_R0_LT();
  }

  /* Switch: '<S65>/Switch1' incorporates:
   *  Constant: '<S69>/Constant'
   *  RelationalOperator: '<S69>/Compare'
   *  Sum: '<S65>/Add1'
   */
  if (rtb_R0_Type == ((uint8)10U)) {
    rtb_R0_C0 -= rtb_offset;
  }

  /* End of Switch: '<S65>/Switch1' */

  /* Switch: '<S67>/Switch' incorporates:
   *  Abs: '<S67>/Abs'
   *  Constant: '<S73>/Constant'
   *  Memory: '<S67>/Memory'
   *  Memory: '<S67>/Memory1'
   *  Product: '<S67>/Divide'
   *  Product: '<S67>/Divide1'
   *  RelationalOperator: '<S73>/Compare'
   *  Sum: '<S67>/Add1'
   *  Sum: '<S67>/Add3'
   */
  if (fabsf(rtb_R0_C0 - LKAS_DW.Memory1_PreviousInput_d) > 0.5F) {
    rtb_offset = rtb_R0_C0;
  } else {
    rtb_offset = (rtb_R0_C0 * LKAS_ConstB.Divide2_mc) + (LKAS_ConstB.Add2_b *
      LKAS_DW.Memory_PreviousInput_my);
  }

  /* End of Switch: '<S67>/Switch' */

  /* Switch: '<S55>/Switch1' incorporates:
   *  Gain: '<S62>/Gain'
   *  Sum: '<S62>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_c = rtb_Switch_f;
  } else {
    rtb_L0_C0_c = (rtb_Saturation_jn - rtb_offset) * (-1.0F);
  }

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
   *  Inport: '<Root>/IMAPve_g_L0_C1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C1'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C1'
   *  Inport: '<Root>/IMAPve_g_R0_C1'
   *  UnaryMinus: '<S54>/Unary Minus1'
   *  UnaryMinus: '<S54>/Unary Minus5'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_L0_C1 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1
      ()));
    rtb_R0_C1 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1
      ()));
  } else {
    rtb_L0_C1 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C1_IMAPve_g_ORI_L0_C1();
    rtb_R0_C1 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C1_IMAPve_g_ORI_R0_C1();
  }

  /* Switch: '<S55>/Switch1' incorporates:
   *  DataTypeConversion: '<S62>/Cast To Single1'
   *  DataTypeConversion: '<S62>/Cast To Single2'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C1_c = rtb_L0_C1;
    rtb_L0_C2_c = rtb_L0_C2;
  } else {
    rtb_L0_C1_c = rtb_R0_C1;
    rtb_L0_C2_c = rtb_R0_C2;
  }

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C3'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C3'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   *  UnaryMinus: '<S54>/Unary Minus3'
   *  UnaryMinus: '<S54>/Unary Minus7'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_L0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3
      ()));
    rtb_R0_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3
      ()));
  } else {
    rtb_L0_C3 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C3_IMAPve_g_ORI_L0_C3();
    rtb_R0_C3 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C3_IMAPve_g_ORI_R0_C3();
  }

  /* Switch: '<S55>/Switch1' incorporates:
   *  DataTypeConversion: '<S62>/Cast To Single3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C3_k = rtb_L0_C3;
  } else {
    rtb_L0_C3_k = rtb_R0_C3;
  }

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_TLC_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_TLC_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_TLC_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_TLC_1'
   *  Inport: '<Root>/IMAPve_g_L0_TLC'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_TLC'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_TLC'
   *  Inport: '<Root>/IMAPve_g_R0_TLC'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_L0_TLC = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_TLC_IMAPve_g_L0_TLC();
    rtb_R0_TLC = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_TLC_IMAPve_g_R0_TLC();
  } else {
    rtb_L0_TLC = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_TLC_IMAPve_g_ORI_L0_TLC();
    rtb_R0_TLC = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_TLC_IMAPve_g_ORI_R0_TLC();
  }

  /* Switch: '<S55>/Switch1' incorporates:
   *  DataTypeConversion: '<S62>/Cast To Single7'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_TLC_i = rtb_L0_TLC;
  } else {
    rtb_L0_TLC_i = rtb_R0_TLC;
  }

  /* Switch: '<S55>/Switch' incorporates:
   *  Sum: '<S64>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_Saturation_jn = rtb_offset;
    rtb_L0_C1 = rtb_R0_C1;
    rtb_L0_C2 = rtb_R0_C2;
    rtb_L0_C3 = rtb_R0_C3;
    rtb_L0_TLC = rtb_R0_TLC;
  } else {
    rtb_Saturation_jn += rtb_Switch_f;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_Actual_Gear'
   */
  rtb_IMAPve_d_TCU_Actual_Gear = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear
    ();

  /* MultiPortSwitch: '<S51>/Multiport Switch' incorporates:
   *  Constant: '<S51>/Constant1'
   *  Constant: '<S51>/Constant3'
   */
  switch (rtb_IMAPve_d_TCU_Actual_Gear) {
   case 0:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 1:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 2:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 3:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 4:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 5:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 6:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 7:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 8:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 9:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   default:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;
  }

  /* End of MultiPortSwitch: '<S51>/Multiport Switch' */

  /* Switch: '<S546>/Switch58' incorporates:
   *  Constant: '<S546>/LLSMConClb4'
   *
   * Block description for '<S546>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S546>/Switch58' */

  /* Gain: '<S551>/Gain' incorporates:
   *  Constant: '<S551>/Constant'
   *  Sum: '<S551>/Add'
   */
  rtb_Gain_p = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S546>/Switch84' incorporates:
   *  Constant: '<S546>/LLSMConClb5'
   *
   * Block description for '<S546>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S546>/Switch84' */

  /* Switch: '<S546>/Switch85' incorporates:
   *  Constant: '<S546>/LLSMConClb6'
   *
   * Block description for '<S546>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S546>/Switch85' */

  /* Switch: '<S546>/Switch86' incorporates:
   *  Constant: '<S546>/LLSMConClb7'
   *
   * Block description for '<S546>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S546>/Switch86' */

  /* Switch: '<S546>/Switch54' incorporates:
   *  Constant: '<S546>/LLSMConClb12'
   *
   * Block description for '<S546>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S546>/Switch54' */

  /* Switch: '<S546>/Switch55' incorporates:
   *  Constant: '<S546>/LLSMConClb13'
   *
   * Block description for '<S546>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S546>/Switch55' */

  /* Switch: '<S546>/Switch52' incorporates:
   *  Constant: '<S546>/LLSMConClb16'
   *
   * Block description for '<S546>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S546>/Switch52' */

  /* Switch: '<S546>/Switch60' incorporates:
   *  Constant: '<S546>/LLSMConClb17'
   *
   * Block description for '<S546>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S546>/Switch60' */

  /* Switch: '<S546>/Switch57' incorporates:
   *  Constant: '<S546>/LLSMConClb18'
   *
   * Block description for '<S546>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S546>/Switch57' */

  /* Switch: '<S546>/Switch59' incorporates:
   *  Constant: '<S546>/LLSMConClb19'
   *
   * Block description for '<S546>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_R0_C2 = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_R0_C2 = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S546>/Switch59' */

  /* Switch: '<S546>/Switch69' incorporates:
   *  Constant: '<S546>/LLSMConClb22'
   *
   * Block description for '<S546>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S546>/Switch69' */

  /* Gain: '<S548>/Gain' incorporates:
   *  Constant: '<S548>/Constant'
   *  Sum: '<S548>/Add'
   */
  rtb_Gain_pu = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S546>/Switch68' incorporates:
   *  Constant: '<S546>/LLSMConClb23'
   *
   * Block description for '<S546>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S546>/Switch68' */

  /* Switch: '<S546>/Switch70' incorporates:
   *  Constant: '<S546>/LLSMConClb24'
   *
   * Block description for '<S546>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S546>/Switch70' */

  /* Switch: '<S546>/Switch71' incorporates:
   *  Constant: '<S546>/LLSMConClb25'
   *
   * Block description for '<S546>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S546>/Switch71' */

  /* Switch: '<S546>/Switch73' incorporates:
   *  Constant: '<S546>/LLSMConClb27'
   *
   * Block description for '<S546>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S546>/Switch73' */

  /* Switch: '<S546>/Switch62' incorporates:
   *  Constant: '<S546>/LLSMConClb31'
   *
   * Block description for '<S546>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S546>/Switch62' */

  /* Switch: '<S546>/Switch66' incorporates:
   *  Constant: '<S546>/LLSMConClb35'
   *
   * Block description for '<S546>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S546>/Switch66' */

  /* Switch: '<S546>/Switch81' incorporates:
   *  Constant: '<S546>/LLSMConClb36'
   *
   * Block description for '<S546>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S546>/Switch81' */

  /* Switch: '<S546>/Switch82' incorporates:
   *  Constant: '<S546>/LLSMConClb37'
   *
   * Block description for '<S546>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S546>/Switch82' */

  /* Switch: '<S546>/Switch83' incorporates:
   *  Constant: '<S546>/LLSMConClb38'
   *
   * Block description for '<S546>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S546>/Switch83' */

  /* Switch: '<S546>/Switch75' incorporates:
   *  Constant: '<S546>/LLSMConClb39'
   *
   * Block description for '<S546>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S546>/Switch75' */

  /* Switch: '<S546>/Switch76' incorporates:
   *  Constant: '<S546>/LLSMConClb40'
   *
   * Block description for '<S546>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S546>/Switch76' */

  /* Switch: '<S546>/Switch77' incorporates:
   *  Constant: '<S546>/LLSMConClb41'
   *
   * Block description for '<S546>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S546>/Switch77' */

  /* Switch: '<S546>/Switch78' incorporates:
   *  Constant: '<S546>/LLSMConClb42'
   *
   * Block description for '<S546>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S546>/Switch78' */

  /* Switch: '<S545>/Switch3' incorporates:
   *  Constant: '<S545>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S545>/Switch3' */

  /* Switch: '<S545>/Switch10' incorporates:
   *  Constant: '<S545>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    LKAS_DW.LL_DesDvt_C_e = LKAS_ConstB.DataTypeConversion22;
  } else {
    LKAS_DW.LL_DesDvt_C_e = LL_DesDvt_C;
  }

  /* End of Switch: '<S545>/Switch10' */

  /* Switch: '<S545>/Switch15' incorporates:
   *  Constant: '<S545>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    LKAS_DW.LL_lStpLngth_C_h = LKAS_ConstB.DataTypeConversion21;
  } else {
    LKAS_DW.LL_lStpLngth_C_h = LL_lStpLngth_C;
  }

  /* End of Switch: '<S545>/Switch15' */

  /* Switch: '<S545>/Switch31' incorporates:
   *  Constant: '<S545>/LL_LFClb_TFC_KpVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_p != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LKAS_ConstB.DataTypeConversion14_p;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S545>/Switch31' */

  /* Switch: '<S545>/Switch34' incorporates:
   *  Constant: '<S545>/LL_LFClb_TFC_KpVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LKAS_ConstB.DataTypeConversion4;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S545>/Switch34' */

  /* Switch: '<S545>/Switch33' incorporates:
   *  Constant: '<S545>/LL_LFClb_TFC_KpV1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_n != 0.0F) {
    rtb_LL_LFClb_TFC_KpV1_C = LKAS_ConstB.DataTypeConversion7_n;
  } else {
    rtb_LL_LFClb_TFC_KpV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S545>/Switch33' */

  /* Switch: '<S545>/Switch35' incorporates:
   *  Constant: '<S545>/LL_LFClb_TFC_KpV2_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion17_d != 0.0F) {
    rtb_LL_LFClb_TFC_KpV2_C = LKAS_ConstB.DataTypeConversion17_d;
  } else {
    rtb_LL_LFClb_TFC_KpV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S545>/Switch35' */

  /* Switch: '<S545>/Switch20' incorporates:
   *  Constant: '<S545>/LL_LFClb_TFC_KdVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S545>/Switch20' */

  /* Switch: '<S545>/Switch22' incorporates:
   *  Constant: '<S545>/LL_LFClb_TFC_KdVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion36_c != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LKAS_ConstB.DataTypeConversion36_c;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S545>/Switch22' */

  /* Switch: '<S545>/Switch21' incorporates:
   *  Constant: '<S545>/LL_LFClb_TFC_KdV1_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV1_C = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LFClb_TFC_KdV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S545>/Switch21' */

  /* Switch: '<S545>/Switch23' incorporates:
   *  Constant: '<S545>/LL_LFClb_TFC_KdV2_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV2_C = LKAS_ConstB.DataTypeConversion30;
  } else {
    rtb_LL_LFClb_TFC_KdV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S545>/Switch23' */

  /* Switch: '<S545>/Switch47' incorporates:
   *  Constant: '<S545>/LL_LKASWASyn_TrqSwaAddSwt=1'
   */
  if (LKAS_ConstB.DataTypeConversion47_g) {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LKAS_ConstB.DataTypeConversion47_g ? 1.0F :
      0.0F;
  } else {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LL_LKASWASyn_TrqSwaAddSwt ? 1.0F : 0.0F;
  }

  /* End of Switch: '<S545>/Switch47' */

  /* Switch: '<S545>/Switch11' incorporates:
   *  Constant: '<S545>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_a != 0.0F) {
    rtb_R0_C1 = LKAS_ConstB.DataTypeConversion12_a;
  } else {
    rtb_R0_C1 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S545>/Switch11' */

  /* Switch: '<S545>/Switch13' incorporates:
   *  Constant: '<S545>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_i != 0.0F) {
    rtb_R0_C3 = LKAS_ConstB.DataTypeConversion19_i;
  } else {
    rtb_R0_C3 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S545>/Switch13' */

  /* Switch: '<S545>/Switch16' incorporates:
   *  Constant: '<S545>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_R0_TLC = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_R0_TLC = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S545>/Switch16' */

  /* Switch: '<S545>/Switch55' incorporates:
   *  Constant: '<S545>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S545>/Switch55' */

  /* Switch: '<S545>/Switch54' incorporates:
   *  Constant: '<S545>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S545>/Switch54' */

  /* Switch: '<S545>/Switch44' incorporates:
   *  Constant: '<S545>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S545>/Switch44' */

  /* Switch: '<S543>/Switch19' incorporates:
   *  Constant: '<S543>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_n != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_n;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S543>/Switch19' */

  /* Switch: '<S543>/Switch' incorporates:
   *  Constant: '<S543>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_hf != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_hf;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S543>/Switch' */

  /* Switch: '<S543>/Switch1' incorporates:
   *  Constant: '<S543>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_g != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_g;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S543>/Switch1' */

  /* Switch: '<S543>/Switch2' incorporates:
   *  Constant: '<S543>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_p != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_k = LKAS_ConstB.DataTypeConversion4_p;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_k = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S543>/Switch2' */

  /* Switch: '<S543>/Switch3' incorporates:
   *  Constant: '<S543>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_c != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_g = LKAS_ConstB.DataTypeConversion6_c;
  } else {
    LKAS_DW.LKA_StrRatio_C_g = LKA_StrRatio_C;
  }

  /* End of Switch: '<S543>/Switch3' */

  /* Switch: '<S543>/Switch11' incorporates:
   *  Constant: '<S543>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22_g != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22_g;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S543>/Switch11' */

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (((sint32)LKAS_DW.Divide) > 0) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S77>/Delay' */
      LKAS_DW.Delay_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S510>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = 0.0F;

      /* InitializeConditions for Memory: '<S455>/Memory' */
      LKAS_DW.Memory_PreviousInput_o = 0.0F;

      /* InitializeConditions for UnitDelay: '<S385>/Delay Input1'
       *
       * Block description for '<S385>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S383>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_c = false;

      /* InitializeConditions for UnitDelay: '<S384>/Delay Input1'
       *
       * Block description for '<S384>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_a = false;

      /* InitializeConditions for Delay: '<S78>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for UnitDelay: '<S346>/Delay Input1'
       *
       * Block description for '<S346>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_j = false;

      /* InitializeConditions for UnitDelay: '<S344>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_a = false;

      /* InitializeConditions for UnitDelay: '<S345>/Delay Input1'
       *
       * Block description for '<S345>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_i = false;

      /* InitializeConditions for Memory: '<S311>/Memory' */
      LKAS_DW.Memory_PreviousInput_jc = false;

      /* InitializeConditions for Delay: '<S78>/Delay' */
      LKAS_DW.Delay_DSTATE_l = false;

      /* InitializeConditions for Delay: '<S78>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S359>/Memory' */
      LKAS_DW.Memory_PreviousInput_i5 = ((uint8)0U);

      /* InitializeConditions for Memory: '<S285>/Memory' */
      LKAS_DW.Memory_PreviousInput_k = 0.0F;

      /* InitializeConditions for Memory: '<S321>/Memory' */
      LKAS_DW.Memory_PreviousInput_c = 0.0F;

      /* InitializeConditions for Delay: '<S78>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S78>/LDW_State_Machine'
       *
       * Block description for '<S78>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S78>/LKA_State_Machine'
       *
       * Block description for '<S78>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S228>/Add1' incorporates:
     *  MATLAB Function: '<S226>/MATLAB Function3'
     */
    x20 = rtb_L0_C0_c + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S228>/Gain1' incorporates:
     *  Product: '<S228>/Divide'
     *  Product: '<S228>/Divide1'
     *  Sum: '<S228>/Add1'
     *  Sum: '<S228>/Add5'
     *  Trigonometry: '<S228>/Cos2'
     *  Trigonometry: '<S228>/Sin'
     */
    rtb_Gain1 = ((x20 * cosf(rtb_L0_C1_c)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_c))) * (-1.0F);

    /* Sum: '<S229>/Add1' incorporates:
     *  MATLAB Function: '<S226>/MATLAB Function4'
     */
    rtb_Add5_j_tmp = rtb_Saturation_jn - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S229>/Add5' incorporates:
     *  Product: '<S229>/Divide'
     *  Product: '<S229>/Divide1'
     *  Sum: '<S229>/Add1'
     *  Trigonometry: '<S229>/Cos2'
     *  Trigonometry: '<S229>/Sin'
     */
    rtb_Add5_j = (rtb_Add5_j_tmp * cosf(rtb_L0_C1)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1));

    /* Switch: '<S545>/Switch2' incorporates:
     *  Constant: '<S545>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_o != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_o;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S545>/Switch2' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S233>/kph to mps' incorporates:
     *  Gain: '<S114>/Gain'
     *  Gain: '<S164>/kph To mps'
     *  Gain: '<S178>/kph to mps'
     *  Gain: '<S179>/kph to mps'
     *  Gain: '<S226>/Gain2'
     *  Gain: '<S239>/kph to mps'
     *  Gain: '<S244>/kph to mps'
     *  Gain: '<S245>/kph to mps'
     *  Gain: '<S272>/Gain'
     *  Gain: '<S310>/Gain'
     */
    rtb_LKA_Veh2CamL_C_tmp = 0.277777791F * rtb_IMAPve_g_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S233>/Divide' incorporates:
     *  Gain: '<S233>/kph to mps'
     */
    rtb_LKA_Veh2CamL_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Gain: '<S230>/Gain' incorporates:
     *  Gain: '<S243>/Gain'
     */
    rtb_Add_pq_tmp = 2.0F * rtb_L0_C2_c;

    /* Sum: '<S230>/Add' incorporates:
     *  Gain: '<S230>/Gain'
     *  Gain: '<S230>/Gain1'
     *  Product: '<S230>/Product'
     */
    rtb_Add_pq = ((6.0F * rtb_L0_C3_k) * rtb_LKA_Veh2CamL_C) + rtb_Add_pq_tmp;

    /* Gain: '<S231>/Gain' incorporates:
     *  Gain: '<S242>/Gain'
     */
    rtb_Add_m_tmp = 2.0F * rtb_L0_C2;

    /* Sum: '<S231>/Add' incorporates:
     *  Gain: '<S231>/Gain'
     *  Gain: '<S231>/Gain1'
     *  Product: '<S231>/Product'
     */
    rtb_Add_m = ((6.0F * rtb_L0_C3) * rtb_LKA_Veh2CamL_C) + rtb_Add_m_tmp;

    /* Saturate: '<S226>/Saturation5' */
    if (rtb_L0_TLC_i > 2.0F) {
      rtb_L0_TLC_i = 2.0F;
    } else {
      if (rtb_L0_TLC_i < 0.6F) {
        rtb_L0_TLC_i = 0.6F;
      }
    }

    /* End of Saturate: '<S226>/Saturation5' */

    /* Saturate: '<S226>/Saturation6' */
    if (rtb_L0_TLC > 2.0F) {
      rtb_Saturation6 = 2.0F;
    } else if (rtb_L0_TLC < 0.6F) {
      rtb_Saturation6 = 0.6F;
    } else {
      rtb_Saturation6 = rtb_L0_TLC;
    }

    /* End of Saturate: '<S226>/Saturation6' */

    /* UnaryMinus: '<S226>/Unary Minus' incorporates:
     *  Product: '<S226>/Product'
     */
    rtb_LKA_Veh2CamL_C = -(rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1_c);

    /* Saturate: '<S226>/Saturation9' */
    if (rtb_LKA_Veh2CamL_C > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else {
      if (rtb_LKA_Veh2CamL_C < (-2.0F)) {
        rtb_LKA_Veh2CamL_C = (-2.0F);
      }
    }

    /* End of Saturate: '<S226>/Saturation9' */

    /* MATLAB Function: '<S226>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function': '<S253>:1' */
    /* '<S253>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1 > 0.0F) && (rtb_Gain1 < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S253>:1:3' TTLC = -dvt/vy; */
      rtb_L0_TLC = (-rtb_Gain1) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S253>:1:4' else */
      /* '<S253>:1:5' TTLC = single(3); */
      rtb_L0_TLC = 3.0F;
    }

    /* End of MATLAB Function: '<S226>/MATLAB Function' */

    /* Saturate: '<S226>/Saturation' */
    if (rtb_L0_TLC > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_L0_TLC < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_L0_TLC;
    }

    /* End of Saturate: '<S226>/Saturation' */

    /* Product: '<S226>/Product3' */
    rtb_L0_TLC = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* Saturate: '<S226>/Saturation10' */
    if (rtb_L0_TLC > 2.0F) {
      rtb_L0_TLC = 2.0F;
    } else {
      if (rtb_L0_TLC < (-2.0F)) {
        rtb_L0_TLC = (-2.0F);
      }
    }

    /* End of Saturate: '<S226>/Saturation10' */

    /* MATLAB Function: '<S226>/MATLAB Function1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function1': '<S254>:1' */
    /* '<S254>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_j > 0.0F) && (rtb_Add5_j < 2.0F)) && (rtb_L0_TLC < 0.0F)) &&
        (rtb_L0_TLC > -1.5F)) {
      /* '<S254>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_o = (-rtb_Add5_j) / rtb_L0_TLC;
    } else {
      /* '<S254>:1:4' else */
      /* '<S254>:1:5' TTLC = single(3); */
      rtb_TTLC_o = 3.0F;
    }

    /* End of MATLAB Function: '<S226>/MATLAB Function1' */

    /* Saturate: '<S226>/Saturation1' */
    if (rtb_TTLC_o > 2.0F) {
      rtb_TTLC_o = 2.0F;
    } else {
      if (rtb_TTLC_o < 0.6F) {
        rtb_TTLC_o = 0.6F;
      }
    }

    /* End of Saturate: '<S226>/Saturation1' */

    /* MATLAB Function: '<S226>/MATLAB Function5' incorporates:
     *  Gain: '<S252>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function5': '<S258>:1' */
    /* '<S258>:1:2' K = 0.09/vx; */
    /* '<S258>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_IMAPve_g_SW_Angle) / (((((((0.09F /
      rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp)
      + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_k) * LKAS_DW.LKA_StrRatio_C_g) * 2.0F);

    /* MATLAB Function: '<S226>/MATLAB Function3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function3': '<S256>:1' */
    /* '<S256>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2_c - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_c > 0.0F) || (rtb_L0_C1_c < 0.0F))) {
      /* '<S256>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_c) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_c;
      if (x10 > 0.0F) {
        /* '<S256>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        /* '<S256>:1:9' else */
        /* '<S256>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_c * rtb_L0_C1_c) - ((x10 * 4.0F) * x20);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S256>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S256>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_c)) / x1;

        /* '<S256>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_c) - x20) / x1;

        /* '<S256>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S256>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S256>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S256>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          /* '<S256>:1:19' elseif x1>0 */
          /* '<S256>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          /* '<S256>:1:21' else */
          /* '<S256>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S256>:1:24' else */
        /* '<S256>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S256>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S226>/MATLAB Function4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function4': '<S257>:1' */
    /* '<S257>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2 - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1 > 0.0F) || (rtb_L0_C1 < 0.0F))) {
      /* '<S257>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_Saturation_jn) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1;
      if (x10 > 0.0F) {
        /* '<S257>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        /* '<S257>:1:9' else */
        /* '<S257>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1 * rtb_L0_C1) - ((x10 * 4.0F) * rtb_Add5_j_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S257>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S257>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1)) / x1;

        /* '<S257>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1) - x20) / x1;

        /* '<S257>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S257>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S257>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S257>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          /* '<S257>:1:19' elseif x1>0 */
          /* '<S257>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          /* '<S257>:1:21' else */
          /* '<S257>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S257>:1:24' else */
        /* '<S257>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S257>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S226>/MATLAB Function2' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function2': '<S255>:1' */
    /* '<S255>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - rtb_L0_TLC_i) / rtb_LftTTLC) <= 0.2F) {
      /* '<S255>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, rtb_L0_TLC_i);
    } else {
      /* '<S255>:1:4' else */
      /* '<S255>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S255>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_o - rtb_Saturation6) / rtb_TTLC_o) <= 0.2F) {
      /* '<S255>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_o = fminf(rtb_TTLC_o, rtb_Saturation6);
    } else {
      /* '<S255>:1:10' else */
      /* '<S255>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S255>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_pq) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S255>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S255>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_m) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_o)
           / rtb_TTLC_o) <= 0.7F)) && (rtb_TTLC_o <= 1.95F)) {
      /* '<S255>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_o = (rtb_TTLC_o + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S226>/Saturation7' incorporates:
     *  MATLAB Function: '<S226>/MATLAB Function2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S226>/Saturation7' */

    /* Saturate: '<S226>/Saturation8' incorporates:
     *  MATLAB Function: '<S226>/MATLAB Function2'
     */
    if (rtb_TTLC_o > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_o < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_o;
    }

    /* End of Saturate: '<S226>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S85>/Subsystem' incorporates:
     *  EnablePort: '<S93>/Enable'
     */
    /* Abs: '<S221>/Abs' incorporates:
     *  MATLAB Function: '<S93>/DriverSwaTrqAdd'
     */
    rtb_LftTTLC = fabsf(rtb_L0_C0_c);

    /* Abs: '<S221>/Abs1' incorporates:
     *  MATLAB Function: '<S93>/DriverSwaTrqAdd'
     */
    rtb_TTLC_o = fabsf(rtb_Saturation_jn);

    /* End of Outputs for SubSystem: '<S85>/Subsystem' */

    /* Sum: '<S221>/Add' incorporates:
     *  Abs: '<S221>/Abs'
     *  Abs: '<S221>/Abs1'
     *  Sum: '<S185>/Add6'
     */
    rtb_Add5_j_tmp = rtb_LftTTLC + rtb_TTLC_o;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Saturate: '<S221>/Saturation' incorporates:
     *  Sum: '<S221>/Add'
     */
    if (rtb_Add5_j_tmp > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_Add5_j_tmp < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_Add5_j_tmp;
    }

    /* End of Saturate: '<S221>/Saturation' */

    /* If: '<S232>/If' incorporates:
     *  Delay: '<S77>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE) == 1) {
      /* Outputs for IfAction SubSystem: '<S232>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S235>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_pq, &rtb_Merge_c);

      /* End of Outputs for SubSystem: '<S232>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE) == 2) {
      /* Outputs for IfAction SubSystem: '<S232>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S234>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_m, &rtb_Merge_c);

      /* End of Outputs for SubSystem: '<S232>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S232>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S236>/Action Port'
       */
      /* Gain: '<S236>/Gain' incorporates:
       *  Sum: '<S236>/Add'
       */
      rtb_Merge_c = (rtb_Add_pq + rtb_Add_m) * 0.5F;

      /* End of Outputs for SubSystem: '<S232>/If Action Subsystem3' */
    }

    /* End of If: '<S232>/If' */

    /* Switch: '<S512>/Switch' incorporates:
     *  Constant: '<S549>/Constant'
     *  Constant: '<S550>/Constant'
     *  Gain: '<S549>/Gain'
     *  Gain: '<S550>/Gain'
     *  Sum: '<S549>/Add'
     *  Sum: '<S550>/Add'
     *  Switch: '<S546>/Switch47'
     */
    if (LKAS_DW.Divide >= ((uint8)2U)) {
      /* Switch: '<S546>/Switch48' incorporates:
       *  Constant: '<S546>/LLSMConClb3'
       *
       * Block description for '<S546>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S546>/Switch48' */
      rtb_Switch_k = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S546>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S546>/Switch47' incorporates:
         *  Constant: '<S546>/LLSMConClb2'
         *
         * Block description for '<S546>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_k = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S512>/Switch' */

    /* Switch: '<S510>/Switch' incorporates:
     *  Constant: '<S510>/Constant'
     *  Constant: '<S510>/Constant1'
     *  Constant: '<S515>/Constant'
     *  Constant: '<S516>/Constant'
     *  Constant: '<S517>/Constant'
     *  Logic: '<S510>/Logical Operator'
     *  RelationalOperator: '<S515>/Compare'
     *  RelationalOperator: '<S516>/Compare'
     *  RelationalOperator: '<S517>/Compare'
     */
    if (((rtb_IMAPve_d_BCM_HazardLamp > ((uint8)0U)) ||
         (rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U))) ||
        (rtb_IMAPve_d_BCM_Right_Light > ((uint8)0U))) {
      rtb_L0_TLC_i = 3.0F;
    } else {
      rtb_L0_TLC_i = (-1.0F);
    }

    /* End of Switch: '<S510>/Switch' */

    /* Sum: '<S510>/Add' incorporates:
     *  Memory: '<S510>/Memory'
     */
    rtb_L0_TLC_i += LKAS_DW.Memory_PreviousInput_p;

    /* Saturate: '<S510>/Saturation' */
    if (rtb_L0_TLC_i > 200.0F) {
      rtb_Saturation_g = 200.0F;
    } else if (rtb_L0_TLC_i < (-1.0F)) {
      rtb_Saturation_g = (-1.0F);
    } else {
      rtb_Saturation_g = rtb_L0_TLC_i;
    }

    /* End of Saturate: '<S510>/Saturation' */

    /* Abs: '<S504>/Abs1' incorporates:
     *  Abs: '<S411>/Abs1'
     */
    rtb_Saturation6 = fabsf(rtb_LaneWidth);
    rtb_Abs1 = rtb_Saturation6;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S502>/Abs' incorporates:
     *  Abs: '<S104>/Abs'
     *  Abs: '<S105>/Abs'
     *  Abs: '<S106>/Abs4'
     *  Abs: '<S409>/Abs'
     *  MATLAB Function: '<S373>/MATLAB Function'
     */
    rtb_TTLC = fabsf(rtb_Merge_c);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC;

    /* Switch: '<S546>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S465>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S465>/Unary Minus' incorporates:
       *  Constant: '<S546>/LLSMConClb11'
       *
       * Block description for '<S546>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S546>/Switch53' */

    /* Switch: '<S546>/Switch87' incorporates:
     *  Constant: '<S546>/LLSMConClb8'
     *
     * Block description for '<S546>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S546>/Switch87' */

    /* Switch: '<S546>/Switch49' incorporates:
     *  Constant: '<S546>/LLSMConClb43'
     *
     * Block description for '<S546>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S546>/Switch49' */

    /* Switch: '<S546>/Switch88' incorporates:
     *  Constant: '<S546>/LLSMConClb9'
     *
     * Block description for '<S546>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_L0_TLC_i = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_L0_TLC_i = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S546>/Switch88' */

    /* Switch: '<S546>/Switch50' incorporates:
     *  Constant: '<S546>/LLSMConClb10'
     *
     * Block description for '<S546>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      x1 = LKAS_ConstB.DataTypeConversion17;
    } else {
      x1 = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S546>/Switch50' */

    /* Abs: '<S500>/Abs' incorporates:
     *  Abs: '<S407>/Abs'
     *  Sum: '<S500>/Add'
     */
    rtb_IMAPve_g_ESC_LatAcc = fabsf(rtb_L0_C1_c - rtb_L0_C1);

    /* Abs: '<S465>/Abs2' incorporates:
     *  Abs: '<S247>/Abs2'
     *  Abs: '<S371>/Abs2'
     */
    rtb_TLft = fabsf(rtb_IMAPve_g_SW_Angle);

    /* Abs: '<S465>/Abs3' incorporates:
     *  Abs: '<S371>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     *  Inport: '<Root>/IMAPve_g_SW_Angle_Speed'
     */
    rtb_LogicalOperator3_h_tmp = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
      ());

    /* Abs: '<S465>/Abs4' incorporates:
     *  Abs: '<S371>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     *  Inport: '<Root>/IMAPve_g_ESC_LatAcc'
     */
    rtb_LogicalOperator3_h_tmp_0 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc());

    /* Abs: '<S465>/Abs1' incorporates:
     *  Abs: '<S372>/Abs'
     *  Abs: '<S373>/Abs'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S466>/Logical Operator2' incorporates:
     *  Abs: '<S465>/Abs1'
     *  Abs: '<S465>/Abs2'
     *  Abs: '<S465>/Abs3'
     *  Abs: '<S465>/Abs4'
     *  Abs: '<S500>/Abs'
     *  Constant: '<S502>/Constant'
     *  Constant: '<S505>/Constant'
     *  Constant: '<S507>/Constant'
     *  Constant: '<S508>/Constant'
     *  Constant: '<S514>/Constant'
     *  Constant: '<S518>/Constant'
     *  Logic: '<S465>/Logical Operator3'
     *  Logic: '<S471>/FixPt Logical Operator'
     *  Logic: '<S501>/Logical Operator3'
     *  Logic: '<S503>/Logical Operator'
     *  Logic: '<S506>/FixPt Logical Operator'
     *  Logic: '<S509>/FixPt Logical Operator'
     *  Logic: '<S513>/Logical Operator'
     *  Logic: '<S519>/FixPt Logical Operator'
     *  RelationalOperator: '<S465>/Relational Operator'
     *  RelationalOperator: '<S465>/Relational Operator1'
     *  RelationalOperator: '<S465>/Relational Operator2'
     *  RelationalOperator: '<S465>/Relational Operator3'
     *  RelationalOperator: '<S471>/Lower Test'
     *  RelationalOperator: '<S471>/Upper Test'
     *  RelationalOperator: '<S505>/Compare'
     *  RelationalOperator: '<S506>/Lower Test'
     *  RelationalOperator: '<S506>/Upper Test'
     *  RelationalOperator: '<S507>/Compare'
     *  RelationalOperator: '<S508>/Compare'
     *  RelationalOperator: '<S509>/Lower Test'
     *  RelationalOperator: '<S509>/Upper Test'
     *  RelationalOperator: '<S514>/Compare'
     *  RelationalOperator: '<S518>/Compare'
     *  RelationalOperator: '<S519>/Lower Test'
     *  RelationalOperator: '<S519>/Upper Test'
     *  Switch: '<S55>/Switch'
     *  Switch: '<S55>/Switch1'
     */
    rtb_LogicalOperator3_np = ((((((rtb_Gain_p <= rtb_IMAPve_g_ESC_VehSpd) &&
      (rtb_IMAPve_g_ESC_VehSpd <= rtb_Switch_k)) && (rtb_Saturation_g <= 0.0F)) &&
      (rtb_TCU_ActualGear == ((uint8)3U))) && (((((rtb_L0_Q_l > ((uint8)2U)) &&
      (rtb_R0_Q > ((uint8)2U))) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) &&
      (rtb_Abs1 <= rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) &&
      (rtb_Abs <= rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) && (rtb_IMAPve_g_ESC_LatAcc
      <= 0.025F))) && (((((rtb_TLft < x10) && (rtb_LogicalOperator3_h_tmp < x20))
                         && (rtb_LKA_Veh2CamW_C < rtb_L0_TLC_i)) &&
                        (rtb_LogicalOperator3_h_tmp_0 < x1)) && ((rtb_UnaryMinus
      < rtb_IMAPve_g_ESC_LonAcc) && (rtb_IMAPve_g_ESC_LonAcc <
      rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* Sum: '<S498>/Add1' incorporates:
     *  Constant: '<S498>/Constant1'
     *  Gain: '<S498>/Gain'
     *  Sum: '<S480>/Add1'
     */
    x1 = (0.5F * rtb_LaneWidth) - 1.5F;
    rtb_Add1_o = x1;

    /* Switch: '<S499>/Switch' incorporates:
     *  Constant: '<S498>/Constant'
     *  RelationalOperator: '<S499>/UpperRelop'
     */
    if (rtb_Add1_o < 0.0F) {
      rtb_Switch_h = 0.0F;
    } else {
      rtb_Switch_h = rtb_Add1_o;
    }

    /* End of Switch: '<S499>/Switch' */

    /* Switch: '<S499>/Switch2' incorporates:
     *  RelationalOperator: '<S499>/LowerRelop1'
     */
    if (rtb_Add1_o > rtb_LL_LKA_EarliestWarnLine_C) {
      rtb_Switch2_f = rtb_LL_LKA_EarliestWarnLine_C;
    } else {
      rtb_Switch2_f = rtb_Switch_h;
    }

    /* End of Switch: '<S499>/Switch2' */

    /* Abs: '<S485>/Abs1' incorporates:
     *  Abs: '<S397>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S485>/Abs2' incorporates:
     *  Abs: '<S397>/Abs1'
     */
    x20 = fabsf(rtb_L0_TLC);

    /* If: '<S466>/If1' incorporates:
     *  Abs: '<S485>/Abs1'
     *  Abs: '<S485>/Abs2'
     *  Constant: '<S473>/Constant'
     *  Constant: '<S487>/Constant'
     *  Constant: '<S488>/Constant'
     *  Constant: '<S493>/Constant'
     *  Constant: '<S494>/Constant'
     *  Constant: '<S495>/Constant'
     *  Constant: '<S496>/Constant'
     *  DataTypeConversion: '<S466>/Cast To Single'
     *  Logic: '<S466>/Logical Operator1'
     *  Logic: '<S482>/Logical Operator'
     *  Logic: '<S484>/Logical Operator'
     *  Logic: '<S485>/Logical Operator'
     *  Logic: '<S486>/Logical Operator'
     *  RelationalOperator: '<S485>/Relational Operator2'
     *  RelationalOperator: '<S485>/Relational Operator3'
     *  RelationalOperator: '<S486>/Relational Operator1'
     *  RelationalOperator: '<S486>/Relational Operator2'
     *  RelationalOperator: '<S487>/Compare'
     *  RelationalOperator: '<S488>/Compare'
     *  RelationalOperator: '<S493>/Compare'
     *  RelationalOperator: '<S494>/Compare'
     *  RelationalOperator: '<S495>/Compare'
     *  RelationalOperator: '<S496>/Compare'
     */
    if ((((sint32)LKAS_DW.Divide) == 2) && (rtb_LogicalOperator3_np &&
         ((((LKAS_DW.Divide == ((uint8)2U)) && (((sint32)
              (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
                (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) ? 1 : 0)) ==
             ((sint32)(true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1 >= rtb_Switch2_f) &&
              (rtb_Add5_j >= rtb_Switch2_f)) ? 1 : 0)) == ((sint32)(true ? 1 : 0))))))
    {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S473>/Action Port'
       */
      LKAS_DW.Merge1_m = true;

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S475>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_m);

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem4' */
    }

    /* End of If: '<S466>/If1' */

    /* Switch: '<S457>/Switch' incorporates:
     *  Constant: '<S547>/Constant'
     *  Constant: '<S552>/Constant'
     *  Gain: '<S547>/Gain'
     *  Gain: '<S552>/Gain'
     *  Sum: '<S547>/Add'
     *  Sum: '<S552>/Add'
     *  Switch: '<S546>/Switch67'
     */
    if (LKAS_DW.Divide >= ((uint8)2U)) {
      /* Switch: '<S546>/Switch80' incorporates:
       *  Constant: '<S546>/LLSMConClb21'
       *
       * Block description for '<S546>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_L0_TLC_i = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_L0_TLC_i = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S546>/Switch80' */
      rtb_Switch_go = (rtb_L0_TLC_i - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S546>/Switch67' */
        rtb_L0_TLC_i = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S546>/Switch67' incorporates:
         *  Constant: '<S546>/LLSMConClb20'
         *
         * Block description for '<S546>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_L0_TLC_i = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_go = (rtb_L0_TLC_i - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S457>/Switch' */

    /* Logic: '<S457>/Logical Operator' incorporates:
     *  Logic: '<S464>/FixPt Logical Operator'
     *  RelationalOperator: '<S464>/Lower Test'
     *  RelationalOperator: '<S464>/Upper Test'
     */
    rtb_LogicalOperator_ps = ((rtb_Gain_pu >= rtb_IMAPve_g_ESC_VehSpd) ||
      (rtb_IMAPve_g_ESC_VehSpd >= rtb_Switch_go));

    /* Switch: '<S455>/Switch' incorporates:
     *  Constant: '<S455>/Constant'
     *  Constant: '<S455>/Constant1'
     *  Constant: '<S460>/Constant'
     *  Constant: '<S461>/Constant'
     *  Constant: '<S462>/Constant'
     *  Logic: '<S455>/Logical Operator'
     *  RelationalOperator: '<S460>/Compare'
     *  RelationalOperator: '<S461>/Compare'
     *  RelationalOperator: '<S462>/Compare'
     */
    if (((rtb_IMAPve_d_BCM_HazardLamp > ((uint8)0U)) ||
         (rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U))) ||
        (rtb_IMAPve_d_BCM_Right_Light > ((uint8)0U))) {
      rtb_L0_TLC_i = 3.0F;
    } else {
      rtb_L0_TLC_i = (-1.0F);
    }

    /* End of Switch: '<S455>/Switch' */

    /* Sum: '<S455>/Add' incorporates:
     *  Memory: '<S455>/Memory'
     */
    rtb_L0_TLC_i += LKAS_DW.Memory_PreviousInput_o;

    /* Saturate: '<S455>/Saturation' */
    if (rtb_L0_TLC_i > 200.0F) {
      rtb_Saturation_l = 200.0F;
    } else if (rtb_L0_TLC_i < (-1.0F)) {
      rtb_Saturation_l = (-1.0F);
    } else {
      rtb_Saturation_l = rtb_L0_TLC_i;
    }

    /* End of Saturate: '<S455>/Saturation' */

    /* RelationalOperator: '<S459>/Compare' incorporates:
     *  Constant: '<S459>/Constant'
     */
    rtb_Compare_hv = (rtb_Saturation_l > 1.0F);

    /* RelationalOperator: '<S463>/Compare' incorporates:
     *  Constant: '<S463>/Constant'
     */
    rtb_Compare_og = (rtb_TCU_ActualGear != ((uint8)3U));

    /* Logic: '<S410>/Logical Operator' incorporates:
     *  Constant: '<S414>/Constant'
     *  Constant: '<S415>/Constant'
     *  RelationalOperator: '<S414>/Compare'
     *  RelationalOperator: '<S415>/Compare'
     *  Switch: '<S55>/Switch'
     *  Switch: '<S55>/Switch1'
     */
    rtb_LogicalOperator_lz = ((rtb_L0_Q_l < ((uint8)3U)) && (rtb_R0_Q < ((uint8)
      3U)));

    /* Abs: '<S411>/Abs1' */
    rtb_Abs1_o = rtb_Saturation6;

    /* RelationalOperator: '<S416>/Compare' incorporates:
     *  Constant: '<S416>/Constant'
     *  Logic: '<S417>/FixPt Logical Operator'
     *  RelationalOperator: '<S417>/Lower Test'
     *  RelationalOperator: '<S417>/Upper Test'
     */
    rtb_Compare_gn = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_o) &&
      (rtb_Abs1_o <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S409>/Abs' */
    rtb_Abs_h = rtb_TTLC;

    /* Logic: '<S409>/Logical Operator' incorporates:
     *  Constant: '<S409>/Constant'
     *  Logic: '<S413>/FixPt Logical Operator'
     *  RelationalOperator: '<S413>/Lower Test'
     *  RelationalOperator: '<S413>/Upper Test'
     */
    rtb_LogicalOperator_f = ((0.0F > rtb_Abs_h) || (rtb_Abs_h >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S412>/Compare' incorporates:
     *  Constant: '<S412>/Constant'
     */
    rtb_Compare_a2p = (rtb_IMAPve_g_ESC_LatAcc > 0.04F);

    /* Switch: '<S546>/Switch72' incorporates:
     *  Constant: '<S546>/LLSMConClb26'
     *
     * Block description for '<S546>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_L0_TLC_i = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_L0_TLC_i = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S546>/Switch72' */

    /* RelationalOperator: '<S371>/Relational Operator1' */
    rtb_phiSWA_Thres = (rtb_TLft >= rtb_L0_TLC_i);

    /* Switch: '<S546>/Switch74' incorporates:
     *  Constant: '<S546>/LLSMConClb28'
     *
     * Block description for '<S546>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_L0_TLC_i = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_L0_TLC_i = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S546>/Switch74' */

    /* RelationalOperator: '<S371>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_LogicalOperator3_h_tmp >= rtb_L0_TLC_i);

    /* Switch: '<S546>/Switch79' incorporates:
     *  Constant: '<S546>/LLSMConClb29'
     *
     * Block description for '<S546>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_L0_TLC_i = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_L0_TLC_i = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S546>/Switch79' */

    /* Logic: '<S371>/Logical Operator1' incorporates:
     *  Constant: '<S374>/Constant'
     *  RelationalOperator: '<S371>/Relational Operator3'
     *  RelationalOperator: '<S374>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_h_tmp_0 >= rtb_L0_TLC_i) &&
                       (rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)));

    /* Switch: '<S546>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S371>/Unary Minus' */
      rtb_UnaryMinus_b = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S371>/Unary Minus' incorporates:
       *  Constant: '<S546>/LLSMConClb30'
       *
       * Block description for '<S546>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_b = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S546>/Switch61' */

    /* RelationalOperator: '<S375>/Compare' incorporates:
     *  Constant: '<S375>/Constant'
     *  Logic: '<S376>/FixPt Logical Operator'
     *  RelationalOperator: '<S376>/Lower Test'
     *  RelationalOperator: '<S376>/Upper Test'
     */
    rtb_Compare_fh = (((sint32)(((rtb_UnaryMinus_b < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                      ((sint32)(false ? 1 : 0)));

    /* Switch: '<S372>/Switch' incorporates:
     *  Constant: '<S377>/Constant'
     *  Constant: '<S546>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
     *  RelationalOperator: '<S377>/Compare'
     *  Switch: '<S546>/Switch38'
     *
     * Block description for '<S546>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
     *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      /* Switch: '<S546>/Switch44' incorporates:
       *  Constant: '<S546>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
       *
       * Block description for '<S546>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
       *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
       */
      if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
        rtb_L0_TLC = LKAS_ConstB.DataTypeConversion8;
      } else {
        rtb_L0_TLC = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
      }

      /* End of Switch: '<S546>/Switch44' */
    } else if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
      /* Switch: '<S546>/Switch38' */
      rtb_L0_TLC = LKAS_ConstB.DataTypeConversion6;
    } else {
      rtb_L0_TLC = LL_RlsDet_tiTrqChkT_DISABLE;
    }

    /* End of Switch: '<S372>/Switch' */

    /* Outputs for Enabled SubSystem: '<S372>/Count 20s' incorporates:
     *  EnablePort: '<S380>/Enable'
     */
    /* Logic: '<S372>/Logical Operator1' incorporates:
     *  Constant: '<S378>/Constant'
     *  Constant: '<S379>/Constant'
     *  Logic: '<S372>/Logical Operator2'
     *  RelationalOperator: '<S372>/Relational Operator'
     *  RelationalOperator: '<S378>/Compare'
     *  RelationalOperator: '<S379>/Compare'
     */
    if (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
         (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) && (rtb_LKA_Veh2CamW_C <=
         rtb_L0_TLC)) {
      if (!LKAS_DW.Count20s_MODE) {
        /* InitializeConditions for Memory: '<S380>/Memory' */
        LKAS_DW.Memory_PreviousInput_pl = 0.0F;
        LKAS_DW.Count20s_MODE = true;
      }

      /* Sum: '<S380>/Add' incorporates:
       *  Memory: '<S380>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_pl;

      /* Saturate: '<S380>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 50.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 50.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S380>/Saturation' */

      /* RelationalOperator: '<S380>/Relational Operator' incorporates:
       *  Constant: '<S380>/Constant'
       */
      LKAS_DW.RelationalOperator_nj = (rtb_IMAPve_g_ESC_LatAcc >= 20.0F);

      /* Update for Memory: '<S380>/Memory' */
      LKAS_DW.Memory_PreviousInput_pl = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S380>/Out' */
        LKAS_DW.RelationalOperator_nj = false;
        LKAS_DW.Count20s_MODE = false;
      }
    }

    /* End of Logic: '<S372>/Logical Operator1' */
    /* End of Outputs for SubSystem: '<S372>/Count 20s' */

    /* Saturate: '<S373>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S381>:1' */
    /* '<S381>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S381>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S381>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S381>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_IMAPve_g_ESC_VehSpd > 80.0F) {
      rtb_L0_TLC_i = 80.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      rtb_L0_TLC_i = 60.0F;
    } else {
      rtb_L0_TLC_i = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S373>/Saturation' */

    /* MATLAB Function: '<S373>/MATLAB Function' */
    if (rtb_LKA_Veh2CamW_C >= fminf(fmaxf(1.5F, ((1.5F *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL) - ((rtb_L0_TLC_i / 180.0F) *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL)) + (rtb_TTLC / 0.005F)), 2.75F)) {
      /* Outputs for Enabled SubSystem: '<S373>/Sum Condition1' incorporates:
       *  EnablePort: '<S382>/state = reset'
       */
      /* '<S381>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_p) {
        /* InitializeConditions for Memory: '<S382>/Memory' */
        LKAS_DW.Memory_PreviousInput_i = 0.0F;
        LKAS_DW.SumCondition1_MODE_p = true;
      }

      /* Sum: '<S382>/Add1' incorporates:
       *  Memory: '<S382>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_i;

      /* Saturate: '<S382>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 5000.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 5000.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S382>/Saturation' */
      /* End of Outputs for SubSystem: '<S373>/Sum Condition1' */

      /* Switch: '<S546>/Switch65' incorporates:
       *  Constant: '<S546>/LLSMConClb34'
       *
       * Block description for '<S546>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_L0_TLC_i = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_L0_TLC_i = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S546>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S373>/Sum Condition1' incorporates:
       *  EnablePort: '<S382>/state = reset'
       */
      /* RelationalOperator: '<S382>/Relational Operator' */
      LKAS_DW.RelationalOperator_c = (rtb_IMAPve_g_ESC_LatAcc >= rtb_L0_TLC_i);

      /* Update for Memory: '<S382>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = rtb_IMAPve_g_ESC_LatAcc;

      /* End of Outputs for SubSystem: '<S373>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S373>/Sum Condition1' incorporates:
       *  EnablePort: '<S382>/state = reset'
       */
      /* '<S381>:1:7' else */
      /* '<S381>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_p) {
        /* Disable for Outport: '<S382>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_p = false;
      }

      /* End of Outputs for SubSystem: '<S373>/Sum Condition1' */
    }

    /* RelationalOperator: '<S391>/Compare' incorporates:
     *  Constant: '<S391>/Constant'
     */
    rtb_Compare_gpu = (((sint32)(LKAS_DW.RelationalOperator_c ? 1 : 0)) >
                       ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S383>/Unit Delay' */
    rtb_UnitDelay_e = LKAS_DW.UnitDelay_DSTATE_c;

    /* RelationalOperator: '<S390>/Compare' incorporates:
     *  Constant: '<S390>/Constant'
     */
    rtb_Compare_by = (((sint32)(rtb_UnitDelay_e ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S383>/If' incorporates:
     *  Constant: '<S386>/Constant'
     *  Constant: '<S387>/Constant'
     *  RelationalOperator: '<S384>/FixPt Relational Operator'
     *  RelationalOperator: '<S385>/FixPt Relational Operator'
     *  UnitDelay: '<S384>/Delay Input1'
     *  UnitDelay: '<S385>/Delay Input1'
     *
     * Block description for '<S384>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S385>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_c) && (((sint32)(rtb_Compare_gpu ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S383>/If Action Subsystem' incorporates:
       *  ActionPort: '<S386>/Action Port'
       */
      rtb_Merge_n = true;

      /* End of Outputs for SubSystem: '<S383>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_e) && (((sint32)(rtb_Compare_by ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_a ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S383>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S387>/Action Port'
       */
      rtb_Merge_n = false;

      /* End of Outputs for SubSystem: '<S383>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S383>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S388>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_e, &rtb_Merge_n);

      /* End of Outputs for SubSystem: '<S383>/If Action Subsystem3' */
    }

    /* End of If: '<S383>/If' */

    /* Outputs for Enabled SubSystem: '<S383>/Sum Condition1' incorporates:
     *  EnablePort: '<S389>/state = reset'
     */
    if (rtb_Merge_n) {
      if (!LKAS_DW.SumCondition1_MODE_a) {
        /* InitializeConditions for Memory: '<S389>/Memory' */
        LKAS_DW.Memory_PreviousInput_f = 0.0F;
        LKAS_DW.SumCondition1_MODE_a = true;
      }

      /* Sum: '<S389>/Add1' incorporates:
       *  Memory: '<S389>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_f;

      /* Saturate: '<S389>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 10.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 10.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S389>/Saturation' */

      /* RelationalOperator: '<S389>/Relational Operator' */
      LKAS_DW.RelationalOperator_mx = (rtb_IMAPve_g_ESC_LatAcc <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S389>/Memory' */
      LKAS_DW.Memory_PreviousInput_f = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.SumCondition1_MODE_a) {
        /* Disable for Outport: '<S389>/Out' */
        LKAS_DW.RelationalOperator_mx = false;
        LKAS_DW.SumCondition1_MODE_a = false;
      }
    }

    /* End of Outputs for SubSystem: '<S383>/Sum Condition1' */

    /* Logic: '<S357>/Logical Operator2' incorporates:
     *  Logic: '<S370>/Logical Operator1'
     *  Logic: '<S371>/Logical Operator'
     *  Logic: '<S408>/Logical Operator3'
     *  Logic: '<S458>/Logical Operator3'
     */
    rtb_LogicalOperator3_b = ((((rtb_LogicalOperator_ps || rtb_Compare_hv) ||
      rtb_Compare_og) || (((rtb_LogicalOperator_lz || rtb_Compare_gn) ||
      rtb_LogicalOperator_f) || rtb_Compare_a2p)) || (((((rtb_phiSWA_Thres ||
      rtb_dphiSWARate_Thres) || rtb_aLAcc_Thres) || rtb_Compare_fh) ||
      (LKAS_DW.RelationalOperator_nj)) || (LKAS_DW.RelationalOperator_mx)));

    /* Logic: '<S397>/Logical Operator' incorporates:
     *  RelationalOperator: '<S397>/Relational Operator1'
     *  RelationalOperator: '<S397>/Relational Operator2'
     */
    rtb_stDvrTkConFlg_i = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S398>/Logical Operator' incorporates:
     *  RelationalOperator: '<S398>/Relational Operator1'
     *  RelationalOperator: '<S398>/Relational Operator2'
     */
    rtb_LogicalOperator_i3 = ((rtb_Gain1 <= rtb_R0_C2) || (rtb_Add5_j <=
      rtb_R0_C2));

    /* If: '<S395>/If' incorporates:
     *  Constant: '<S401>/Constant'
     *  Delay: '<S78>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_IMAPve_d_EPS_LKA_State) != 1)) {
      /* Outputs for IfAction SubSystem: '<S395>/If Action Subsystem' incorporates:
       *  ActionPort: '<S399>/Action Port'
       */
      LKAS_IfActionSubsystem_e(&rtb_Merge_b);

      /* End of Outputs for SubSystem: '<S395>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_IMAPve_d_EPS_LKA_State) != 3)) {
      /* Outputs for IfAction SubSystem: '<S395>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S400>/Action Port'
       */
      LKAS_IfActionSubsystem_e(&rtb_Merge_b);

      /* End of Outputs for SubSystem: '<S395>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S395>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S401>/Action Port'
       */
      rtb_Merge_b = false;

      /* End of Outputs for SubSystem: '<S395>/If Action Subsystem3' */
    }

    /* End of If: '<S395>/If' */

    /* Outputs for Enabled SubSystem: '<S395>/Sum Condition1' incorporates:
     *  EnablePort: '<S402>/state = reset'
     */
    if (rtb_Merge_b) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S402>/Memory' */
        LKAS_DW.Memory_PreviousInput_a = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S402>/Add1' incorporates:
       *  Memory: '<S402>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_a;

      /* Saturate: '<S402>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 60.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 60.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S402>/Saturation' */

      /* Switch: '<S546>/Switch63' incorporates:
       *  Constant: '<S546>/LLSMConClb32'
       *
       * Block description for '<S546>/LLSMConClb32':
       *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion78;
      } else {
        x10 = LL_MAX_DELAY_EPSSTAR_TIME;
      }

      /* End of Switch: '<S546>/Switch63' */

      /* RelationalOperator: '<S402>/Relational Operator' */
      LKAS_DW.RelationalOperator_k = (rtb_IMAPve_g_ESC_LatAcc >= x10);

      /* Update for Memory: '<S402>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S402>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S395>/Sum Condition1' */

    /* If: '<S357>/If2' incorporates:
     *  Constant: '<S366>/Constant'
     *  Constant: '<S403>/Constant'
     *  Constant: '<S404>/Constant'
     *  Constant: '<S405>/Constant'
     *  Constant: '<S406>/Constant'
     *  DataTypeConversion: '<S357>/Cast To Single'
     *  Logic: '<S357>/Logical Operator1'
     *  Logic: '<S396>/Logical Operator'
     *  Logic: '<S396>/Logical Operator1'
     *  RelationalOperator: '<S403>/Compare'
     *  RelationalOperator: '<S404>/Compare'
     *  RelationalOperator: '<S405>/Compare'
     *  RelationalOperator: '<S406>/Compare'
     */
    if ((((sint32)LKAS_DW.Divide) == 2) && (rtb_LogicalOperator3_b ||
         ((LKAS_DW.Divide == ((uint8)2U)) && (((rtb_stDvrTkConFlg_i == true) ||
            (rtb_LogicalOperator_i3 == true)) || (LKAS_DW.RelationalOperator_k ==
            true))))) {
      /* Outputs for IfAction SubSystem: '<S357>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S366>/Action Port'
       */
      LKAS_DW.Merge2 = true;

      /* End of Outputs for SubSystem: '<S357>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S357>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S368>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2);

      /* End of Outputs for SubSystem: '<S357>/If Action Subsystem3' */
    }

    /* End of If: '<S357>/If2' */

    /* Product: '<S272>/Divide' */
    rtb_LKA_Veh2CamL_C = rtb_L0_C1_c * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S272>/Divide1' */
    rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* If: '<S294>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_IMAPve_g_ESC_LatAcc >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S294>/Ph1SWA' incorporates:
       *  ActionPort: '<S298>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S294>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_IMAPve_g_ESC_LatAcc <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S294>/Ph2SWA' incorporates:
       *  ActionPort: '<S299>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S294>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S294>/Ph3SWA' incorporates:
       *  ActionPort: '<S300>/Action Port'
       */
      LKAS_Ph3SWA_c(&rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S294>/Ph3SWA' */
    }

    /* End of If: '<S294>/If' */

    /* Saturate: '<S272>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      x20 = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      x20 = (-2.0F);
    } else {
      x20 = rtb_Gain1;
    }

    /* End of Saturate: '<S272>/Saturation5' */

    /* MATLAB Function: '<S281>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LaneWidth, rtb_LKA_CarWidth,
                        rtb_LL_ThresDet_lDvtThresUprLDW,
                        &rtb_ThresDet_coefficient_f);

    /* Product: '<S281>/Divide5' */
    rtb_Saturation6 = rtb_ThresDet_coefficient_f *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S281>/Divide6' */
    rtb_L0_TLC_i = rtb_ThresDet_coefficient_f * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S296>/Abs' incorporates:
     *  Abs: '<S287>/Abs'
     */
    rtb_LogicalOperator3_h_tmp = fabsf(rtb_LKA_Veh2CamL_C);

    /* Product: '<S296>/Divide' incorporates:
     *  Abs: '<S296>/Abs'
     */
    rtb_Divide_c = rtb_L0_TLC_i * rtb_LogicalOperator3_h_tmp;

    /* Product: '<S281>/Divide4' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_ThresDet_coefficient_f *
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S301>/Switch' incorporates:
     *  RelationalOperator: '<S301>/UpperRelop'
     */
    if (rtb_Divide_c < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_g2 = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_g2 = rtb_Divide_c;
    }

    /* End of Switch: '<S301>/Switch' */

    /* Switch: '<S301>/Switch2' incorporates:
     *  RelationalOperator: '<S301>/LowerRelop1'
     */
    if (rtb_Divide_c > rtb_Saturation6) {
      rtb_Switch2_ad = rtb_Saturation6;
    } else {
      rtb_Switch2_ad = rtb_Switch_g2;
    }

    /* End of Switch: '<S301>/Switch2' */

    /* Saturate: '<S272>/Saturation1' */
    if (rtb_Add5_j > 2.0F) {
      rtb_LL_LKA_EarliestWarnLine_C = 2.0F;
    } else if (rtb_Add5_j < (-2.0F)) {
      rtb_LL_LKA_EarliestWarnLine_C = (-2.0F);
    } else {
      rtb_LL_LKA_EarliestWarnLine_C = rtb_Add5_j;
    }

    /* End of Saturate: '<S272>/Saturation1' */

    /* Abs: '<S297>/Abs' incorporates:
     *  Abs: '<S288>/Abs'
     */
    rtb_LogicalOperator3_h_tmp_0 = fabsf(rtb_IMAPve_g_ESC_LatAcc);

    /* Product: '<S297>/Divide' incorporates:
     *  Abs: '<S297>/Abs'
     */
    rtb_Divide_l = rtb_L0_TLC_i * rtb_LogicalOperator3_h_tmp_0;

    /* Switch: '<S302>/Switch' incorporates:
     *  RelationalOperator: '<S302>/UpperRelop'
     */
    if (rtb_Divide_l < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_a = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_a = rtb_Divide_l;
    }

    /* End of Switch: '<S302>/Switch' */

    /* Switch: '<S302>/Switch2' incorporates:
     *  RelationalOperator: '<S302>/LowerRelop1'
     */
    if (rtb_Divide_l > rtb_Saturation6) {
      rtb_Switch2_d = rtb_Saturation6;
    } else {
      rtb_Switch2_d = rtb_Switch_a;
    }

    /* End of Switch: '<S302>/Switch2' */

    /* Switch: '<S295>/Switch3' incorporates:
     *  Constant: '<S297>/Constant'
     *  Gain: '<S295>/Gain1'
     *  Logic: '<S297>/Logical Operator'
     *  RelationalOperator: '<S297>/Relational Operator1'
     *  RelationalOperator: '<S297>/Relational Operator2'
     */
    if (rtb_Merge1_a >= 0.0F) {
      /* Switch: '<S295>/Switch2' incorporates:
       *  Constant: '<S295>/Constant2'
       *  Constant: '<S296>/Constant'
       *  DataTypeConversion: '<S295>/Cast To Single'
       *  Logic: '<S296>/Logical Operator'
       *  RelationalOperator: '<S296>/Relational Operator1'
       *  RelationalOperator: '<S296>/Relational Operator3'
       */
      if (rtb_Merge1_a > 0.0F) {
        rtb_IMAPve_d_BCM_Left_Light = (uint8)(((0.0F < x20) && (x20 <=
          rtb_Switch2_ad)) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_Left_Light = ((uint8)0U);
      }

      /* End of Switch: '<S295>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Left_Light = (uint8)((((uint32)(((0.0F <
        rtb_LL_LKA_EarliestWarnLine_C) && (rtb_LL_LKA_EarliestWarnLine_C <=
        rtb_Switch2_d)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S295>/Switch3' */

    /* DataTypeConversion: '<S274>/Data Type Conversion' incorporates:
     *  Constant: '<S305>/Constant'
     *  Constant: '<S306>/Constant'
     *  Constant: '<S307>/Constant'
     *  Constant: '<S308>/Constant'
     *  Logic: '<S274>/Logical Operator'
     *  Logic: '<S274>/Logical Operator1'
     *  Logic: '<S274>/Logical Operator2'
     *  RelationalOperator: '<S305>/Compare'
     *  RelationalOperator: '<S306>/Compare'
     *  RelationalOperator: '<S307>/Compare'
     *  RelationalOperator: '<S308>/Compare'
     *  Switch: '<S55>/Switch'
     *  Switch: '<S55>/Switch1'
     */
    rtb_IMAPve_d_BCM_HazardLamp = (uint8)((((rtb_R0_Q > ((uint8)2U)) &&
      (rtb_IMAPve_d_BCM_Left_Light == ((uint8)2U))) ||
      ((rtb_IMAPve_d_BCM_Left_Light == ((uint8)1U)) && (rtb_L0_Q_l > ((uint8)2U))))
      ? 1 : 0);

    /* DataTypeConversion: '<S273>/Data Type Conversion' incorporates:
     *  Constant: '<S303>/Constant'
     *  Constant: '<S304>/Constant'
     *  Logic: '<S273>/Logical Operator'
     *  RelationalOperator: '<S303>/Compare'
     *  RelationalOperator: '<S304>/Compare'
     */
    rtb_IMAPve_d_BCM_Right_Light = (uint8)(((rtb_IMAPve_d_EPS_LKA_State ==
      ((uint8)1U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? 1 : 0);

    /* If: '<S271>/If1' incorporates:
     *  Constant: '<S276>/Constant'
     *  Constant: '<S279>/Constant'
     *  Constant: '<S280>/Constant'
     */
    if ((((((sint32)LKAS_DW.Divide) == 2) && (((sint32)
            rtb_IMAPve_d_BCM_Left_Light) == 1)) && (((sint32)
           rtb_IMAPve_d_BCM_Right_Light) == 1)) && (((sint32)
          rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S271>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S279>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S271>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.Divide) == 2) && (((sint32)
        rtb_IMAPve_d_BCM_Left_Light) == 2)) && (((sint32)
                  rtb_IMAPve_d_BCM_Right_Light) == 1)) && (((sint32)
                 rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S271>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S280>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S271>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S271>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S276>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S271>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S271>/If1' */

    /* Product: '<S310>/Divide' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_L0_C1_c * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S310>/Divide1' */
    rtb_LKA_Veh2CamW_C = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* If: '<S331>/If' */
    if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) ||
        (rtb_LKA_Veh2CamW_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S331>/Ph1SWA' incorporates:
       *  ActionPort: '<S335>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_k);

      /* End of Outputs for SubSystem: '<S331>/Ph1SWA' */
    } else if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_LKA_Veh2CamW_C <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S331>/Ph2SWA' incorporates:
       *  ActionPort: '<S336>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_k);

      /* End of Outputs for SubSystem: '<S331>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S331>/Ph3SWA' incorporates:
       *  ActionPort: '<S337>/Action Port'
       */
      LKAS_Ph3SWA_c(&rtb_Merge1_k);

      /* End of Outputs for SubSystem: '<S331>/Ph3SWA' */
    }

    /* End of If: '<S331>/If' */

    /* Saturate: '<S310>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_L0_TLC = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_L0_TLC = (-2.0F);
    } else {
      rtb_L0_TLC = rtb_Gain1;
    }

    /* End of Saturate: '<S310>/Saturation5' */

    /* MATLAB Function: '<S317>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LaneWidth, rtb_LKA_CarWidth,
                        rtb_LL_ThresDet_lDvtThresUprLDW,
                        &rtb_ThresDet_coefficient);

    /* Product: '<S317>/Divide5' */
    rtb_L0_TLC_i = rtb_ThresDet_coefficient * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S317>/Divide6' */
    rtb_Saturation6 = rtb_ThresDet_coefficient * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S333>/Divide' incorporates:
     *  Abs: '<S333>/Abs'
     */
    rtb_Divide_ll = rtb_Saturation6 * fabsf(rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Product: '<S317>/Divide4' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S338>/Switch' incorporates:
     *  RelationalOperator: '<S338>/UpperRelop'
     */
    if (rtb_Divide_ll < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_gc = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_gc = rtb_Divide_ll;
    }

    /* End of Switch: '<S338>/Switch' */

    /* Switch: '<S338>/Switch2' incorporates:
     *  RelationalOperator: '<S338>/LowerRelop1'
     */
    if (rtb_Divide_ll > rtb_L0_TLC_i) {
      rtb_Switch2_m = rtb_L0_TLC_i;
    } else {
      rtb_Switch2_m = rtb_Switch_gc;
    }

    /* End of Switch: '<S338>/Switch2' */

    /* Saturate: '<S310>/Saturation1' */
    if (rtb_Add5_j > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_j < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_j;
    }

    /* End of Saturate: '<S310>/Saturation1' */

    /* Product: '<S334>/Divide' incorporates:
     *  Abs: '<S334>/Abs'
     */
    rtb_Divide_n = rtb_Saturation6 * fabsf(rtb_LKA_Veh2CamW_C);

    /* Switch: '<S339>/Switch' incorporates:
     *  RelationalOperator: '<S339>/UpperRelop'
     */
    if (rtb_Divide_n < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_b4 = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_b4 = rtb_Divide_n;
    }

    /* End of Switch: '<S339>/Switch' */

    /* Switch: '<S339>/Switch2' incorporates:
     *  RelationalOperator: '<S339>/LowerRelop1'
     */
    if (rtb_Divide_n > rtb_L0_TLC_i) {
      rtb_Switch2_j = rtb_L0_TLC_i;
    } else {
      rtb_Switch2_j = rtb_Switch_b4;
    }

    /* End of Switch: '<S339>/Switch2' */

    /* Switch: '<S332>/Switch3' incorporates:
     *  Constant: '<S334>/Constant'
     *  Gain: '<S332>/Gain1'
     *  Logic: '<S334>/Logical Operator'
     *  RelationalOperator: '<S334>/Relational Operator1'
     *  RelationalOperator: '<S334>/Relational Operator2'
     */
    if (rtb_Merge1_k >= 0.0F) {
      /* Switch: '<S332>/Switch2' incorporates:
       *  Constant: '<S332>/Constant2'
       *  Constant: '<S333>/Constant'
       *  DataTypeConversion: '<S332>/Cast To Single'
       *  Logic: '<S333>/Logical Operator'
       *  RelationalOperator: '<S333>/Relational Operator1'
       *  RelationalOperator: '<S333>/Relational Operator3'
       */
      if (rtb_Merge1_k > 0.0F) {
        rtb_IMAPve_d_BCM_Left_Light = (uint8)(((0.0F < rtb_L0_TLC) &&
          (rtb_L0_TLC <= rtb_Switch2_m)) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_Left_Light = ((uint8)0U);
      }

      /* End of Switch: '<S332>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Left_Light = (uint8)((((uint32)(((0.0F <
        rtb_LL_ThresDet_lDvtThresLwrLKA) && (rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_j)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S332>/Switch3' */

    /* MATLAB Function: '<S311>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S343>:1' */
    /* '<S343>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S343>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S343>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S343>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_IMAPve_g_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge_c), 0.005F)) / 0.005F);

    /* '<S343>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_IMAPve_d_BCM_Left_Light) == 2) &&
         (rtb_IMAPve_g_EPS_SW_Trq > rtb_LL_MAX_DRIVER_TORQUE_DISABL)) ||
        ((((sint32)rtb_IMAPve_d_BCM_Left_Light) == 1) &&
         (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL)))) {
      /* Outputs for Enabled SubSystem: '<S311>/Count 0.2s' incorporates:
       *  EnablePort: '<S342>/Enable'
       */
      /* '<S343>:1:7' stDvrTkConFlg=1; */
      /* '<S343>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S343>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S342>/Memory' */
        LKAS_DW.Memory_PreviousInput_g = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S342>/Add' incorporates:
       *  Memory: '<S342>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_g;

      /* Saturate: '<S342>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S342>/Saturation' */
      /* End of Outputs for SubSystem: '<S311>/Count 0.2s' */

      /* Switch: '<S546>/Switch16' incorporates:
       *  Constant: '<S546>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S546>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S546>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S311>/Count 0.2s' incorporates:
       *  EnablePort: '<S342>/Enable'
       */
      /* RelationalOperator: '<S342>/Relational Operator' */
      LKAS_DW.RelationalOperator_d = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S342>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S311>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S311>/Count 0.2s' incorporates:
       *  EnablePort: '<S342>/Enable'
       */
      /* '<S343>:1:10' else */
      /* '<S343>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S342>/Out' */
        LKAS_DW.RelationalOperator_d = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S311>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S311>/MATLAB Function' */

    /* RelationalOperator: '<S352>/Compare' incorporates:
     *  Constant: '<S352>/Constant'
     */
    rtb_Compare_hu = (((sint32)(LKAS_DW.RelationalOperator_d ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S344>/Unit Delay' */
    rtb_UnitDelay_eg = LKAS_DW.UnitDelay_DSTATE_a;

    /* RelationalOperator: '<S351>/Compare' incorporates:
     *  Constant: '<S351>/Constant'
     */
    rtb_Compare_oq = (((sint32)(rtb_UnitDelay_eg ? 1 : 0)) <= ((sint32)(false ?
      1 : 0)));

    /* If: '<S344>/If' incorporates:
     *  Constant: '<S347>/Constant'
     *  Constant: '<S348>/Constant'
     *  RelationalOperator: '<S345>/FixPt Relational Operator'
     *  RelationalOperator: '<S346>/FixPt Relational Operator'
     *  UnitDelay: '<S345>/Delay Input1'
     *  UnitDelay: '<S346>/Delay Input1'
     *
     * Block description for '<S345>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S346>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_d) && (((sint32)(rtb_Compare_hu ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_j ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S344>/If Action Subsystem' incorporates:
       *  ActionPort: '<S347>/Action Port'
       */
      rtb_Merge_ph = true;

      /* End of Outputs for SubSystem: '<S344>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_eg) && (((sint32)(rtb_Compare_oq ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_i ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S344>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S348>/Action Port'
       */
      rtb_Merge_ph = false;

      /* End of Outputs for SubSystem: '<S344>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S344>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S349>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_eg, &rtb_Merge_ph);

      /* End of Outputs for SubSystem: '<S344>/If Action Subsystem3' */
    }

    /* End of If: '<S344>/If' */

    /* Outputs for Enabled SubSystem: '<S311>/Count' incorporates:
     *  EnablePort: '<S341>/Enable'
     */
    /* Logic: '<S311>/Logical Operator' incorporates:
     *  Constant: '<S340>/Constant'
     *  Memory: '<S311>/Memory'
     *  RelationalOperator: '<S340>/Compare'
     */
    if ((rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U)) &&
        (LKAS_DW.Memory_PreviousInput_jc)) {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S341>/Memory' */
        LKAS_DW.Memory_PreviousInput_ay = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S341>/Add' incorporates:
       *  Memory: '<S341>/Memory'
       */
      rtb_L0_TLC_i = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_ay;

      /* Saturate: '<S341>/Saturation' */
      if (rtb_L0_TLC_i > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_L0_TLC_i < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_L0_TLC_i;
      }

      /* End of Saturate: '<S341>/Saturation' */

      /* Update for Memory: '<S341>/Memory' */
      LKAS_DW.Memory_PreviousInput_ay = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S341>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S311>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S311>/Count' */

    /* Outputs for Enabled SubSystem: '<S344>/Sum Condition1' incorporates:
     *  EnablePort: '<S350>/state = reset'
     */
    if (rtb_Merge_ph) {
      if (!LKAS_DW.SumCondition1_MODE_g) {
        /* InitializeConditions for Memory: '<S350>/Memory' */
        LKAS_DW.Memory_PreviousInput_f1 = 0.0F;
        LKAS_DW.SumCondition1_MODE_g = true;
      }

      /* Sum: '<S350>/Add1' incorporates:
       *  Memory: '<S350>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_f1;

      /* Saturate: '<S350>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S350>/Saturation' */

      /* Switch: '<S546>/Switch40' incorporates:
       *  Constant: '<S546>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S546>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S546>/Switch40' */

      /* RelationalOperator: '<S350>/Relational Operator' incorporates:
       *  Sum: '<S311>/Add'
       */
      LKAS_DW.RelationalOperator_b = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S350>/Memory' */
      LKAS_DW.Memory_PreviousInput_f1 = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_g) {
        /* Disable for Outport: '<S350>/Out' */
        LKAS_DW.RelationalOperator_b = false;
        LKAS_DW.SumCondition1_MODE_g = false;
      }
    }

    /* End of Outputs for SubSystem: '<S344>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S312>/Sum Condition1' incorporates:
     *  EnablePort: '<S356>/state = reset'
     */
    /* Logic: '<S312>/Logical Operator' incorporates:
     *  Constant: '<S354>/Constant'
     *  Constant: '<S355>/Constant'
     *  Delay: '<S78>/Delay1'
     *  RelationalOperator: '<S354>/Compare'
     *  RelationalOperator: '<S355>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_b) {
        /* InitializeConditions for Memory: '<S356>/Memory' */
        LKAS_DW.Memory_PreviousInput_b = 0.0F;
        LKAS_DW.SumCondition1_MODE_b = true;
      }

      /* Sum: '<S356>/Add1' incorporates:
       *  Memory: '<S356>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_b;

      /* Saturate: '<S356>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S356>/Saturation' */

      /* RelationalOperator: '<S356>/Relational Operator' */
      LKAS_DW.RelationalOperator_nl = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S356>/Memory' */
      LKAS_DW.Memory_PreviousInput_b = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S356>/Out' */
        LKAS_DW.RelationalOperator_nl = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }
    }

    /* End of Logic: '<S312>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S312>/Sum Condition1' */

    /* If: '<S309>/If1' incorporates:
     *  Constant: '<S314>/Constant'
     *  Constant: '<S316>/Constant'
     *  Constant: '<S353>/Constant'
     *  Delay: '<S78>/Delay'
     *  Logic: '<S309>/Logical Operator'
     *  Logic: '<S312>/Logical Operator1'
     *  RelationalOperator: '<S353>/Compare'
     */
    if ((((sint32)LKAS_DW.Divide) == 2) && (((LKAS_DW.RelationalOperator_b) ||
          ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_nl))) || (LKAS_DW.Delay_DSTATE_l))) {
      /* Outputs for IfAction SubSystem: '<S309>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S316>/Action Port'
       */
      LKAS_DW.Merge1_k = true;

      /* End of Outputs for SubSystem: '<S309>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S309>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S314>/Action Port'
       */
      LKAS_DW.Merge1_k = false;

      /* End of Outputs for SubSystem: '<S309>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S309>/If1' */

    /* Sum: '<S480>/Add1' */
    rtb_Add1_a = x1;

    /* Switch: '<S481>/Switch' incorporates:
     *  Constant: '<S480>/Constant'
     *  RelationalOperator: '<S481>/UpperRelop'
     */
    if (rtb_Add1_a < 0.0F) {
      rtb_Switch_b3 = 0.0F;
    } else {
      rtb_Switch_b3 = rtb_Add1_a;
    }

    /* End of Switch: '<S481>/Switch' */

    /* Switch: '<S481>/Switch2' incorporates:
     *  RelationalOperator: '<S481>/LowerRelop1'
     */
    if (rtb_Add1_a > rtb_LL_LDW_EarliestWarnLine_C) {
      rtb_Switch2_n = rtb_LL_LDW_EarliestWarnLine_C;
    } else {
      rtb_Switch2_n = rtb_Switch_b3;
    }

    /* End of Switch: '<S481>/Switch2' */

    /* Logic: '<S466>/Logical Operator3' incorporates:
     *  Constant: '<S478>/Constant'
     *  Constant: '<S479>/Constant'
     *  Logic: '<S476>/Logical Operator'
     *  Logic: '<S477>/Logical Operator'
     *  RelationalOperator: '<S477>/Relational Operator1'
     *  RelationalOperator: '<S477>/Relational Operator2'
     *  RelationalOperator: '<S478>/Compare'
     *  RelationalOperator: '<S479>/Compare'
     */
    rtb_LogicalOperator3_np = (((LKAS_DW.Divide >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1 >= rtb_Switch2_n) && (rtb_Add5_j >= rtb_Switch2_n)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_np);

    /* If: '<S466>/If' incorporates:
     *  Constant: '<S472>/Constant'
     *  DataTypeConversion: '<S466>/Cast To Single'
     *  DataTypeConversion: '<S466>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
        rtb_LogicalOperator3_np) {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem' incorporates:
       *  ActionPort: '<S472>/Action Port'
       */
      LKAS_DW.Merge_la = true;

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S466>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S474>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_la);

      /* End of Outputs for SubSystem: '<S466>/If Action Subsystem3' */
    }

    /* End of If: '<S466>/If' */

    /* Delay: '<S78>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S359>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S359>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_i5 != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S359>/If Action Subsystem' incorporates:
         *  ActionPort: '<S392>/Action Port'
         */
        /* InitializeConditions for If: '<S359>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S392>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_af = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S359>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S359>/If Action Subsystem' incorporates:
       *  ActionPort: '<S392>/Action Port'
       */
      /* Sum: '<S392>/Add1' incorporates:
       *  Memory: '<S392>/Memory'
       */
      rtb_LL_LDW_EarliestWarnLine_C = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_af;

      /* Saturate: '<S392>/Saturation' */
      if (rtb_LL_LDW_EarliestWarnLine_C > 10.0F) {
        rtb_LL_LDW_EarliestWarnLine_C = 10.0F;
      } else {
        if (rtb_LL_LDW_EarliestWarnLine_C < 0.0F) {
          rtb_LL_LDW_EarliestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S392>/Saturation' */
      /* End of Outputs for SubSystem: '<S359>/If Action Subsystem' */

      /* Switch: '<S546>/Switch64' incorporates:
       *  Constant: '<S546>/LLSMConClb33'
       *
       * Block description for '<S546>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S546>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S359>/If Action Subsystem' incorporates:
       *  ActionPort: '<S392>/Action Port'
       */
      /* RelationalOperator: '<S392>/Relational Operator' */
      rtb_Merge = (rtb_LL_LDW_EarliestWarnLine_C >= x10);

      /* Update for Memory: '<S392>/Memory' */
      LKAS_DW.Memory_PreviousInput_af = rtb_LL_LDW_EarliestWarnLine_C;

      /* End of Outputs for SubSystem: '<S359>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S359>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S393>/Action Port'
       */
      /* SignalConversion: '<S393>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S393>/Constant'
       */
      rtb_Merge = false;

      /* End of Outputs for SubSystem: '<S359>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S359>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S360>/Logical Operator1' incorporates:
     *  Constant: '<S394>/Constant'
     *  Logic: '<S360>/Logical Operator'
     *  RelationalOperator: '<S360>/Relational Operator1'
     *  RelationalOperator: '<S360>/Relational Operator2'
     *  RelationalOperator: '<S394>/Compare'
     */
    rtb_LogicalOperator3_np = ((LKAS_DW.Divide >= ((uint8)1U)) && ((rtb_Gain1 <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_j <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S357>/Logical Operator3' */
    rtb_LogicalOperator3_b = ((rtb_LogicalOperator3_np || rtb_Merge) ||
      rtb_LogicalOperator3_b);

    /* If: '<S357>/If1' incorporates:
     *  Constant: '<S367>/Constant'
     *  DataTypeConversion: '<S357>/Cast To Single'
     *  DataTypeConversion: '<S357>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
        rtb_LogicalOperator3_b) {
      /* Outputs for IfAction SubSystem: '<S357>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S367>/Action Port'
       */
      LKAS_DW.Merge1_b = true;

      /* End of Outputs for SubSystem: '<S357>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S357>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S369>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_b);

      /* End of Outputs for SubSystem: '<S357>/If Action Subsystem4' */
    }

    /* End of If: '<S357>/If1' */

    /* Memory: '<S285>/Memory' */
    rtb_Memory_a = LKAS_DW.Memory_PreviousInput_k;

    /* If: '<S285>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_IMAPve_g_ESC_LatAcc >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S285>/Ph1SWA' incorporates:
       *  ActionPort: '<S289>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_o);

      /* End of Outputs for SubSystem: '<S285>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_IMAPve_g_ESC_LatAcc <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S285>/Ph2SWA' incorporates:
       *  ActionPort: '<S290>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_o);

      /* End of Outputs for SubSystem: '<S285>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S285>/Ph3SWA' incorporates:
       *  ActionPort: '<S291>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_a, &rtb_Merge1_o);

      /* End of Outputs for SubSystem: '<S285>/Ph3SWA' */
    }

    /* End of If: '<S285>/If' */

    /* Product: '<S281>/Divide2' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_ThresDet_coefficient_f *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S281>/Divide3' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient_f *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S287>/Divide' */
    rtb_Divide_i4 = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LogicalOperator3_h_tmp;

    /* Product: '<S281>/Divide1' */
    rtb_L0_TLC_i = rtb_ThresDet_coefficient_f * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S292>/Switch' incorporates:
     *  RelationalOperator: '<S292>/UpperRelop'
     */
    if (rtb_Divide_i4 < rtb_L0_TLC_i) {
      rtb_Switch_l = rtb_L0_TLC_i;
    } else {
      rtb_Switch_l = rtb_Divide_i4;
    }

    /* End of Switch: '<S292>/Switch' */

    /* Switch: '<S292>/Switch2' incorporates:
     *  RelationalOperator: '<S292>/LowerRelop1'
     */
    if (rtb_Divide_i4 > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_k = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_k = rtb_Switch_l;
    }

    /* End of Switch: '<S292>/Switch2' */

    /* Product: '<S288>/Divide' */
    rtb_Divide_g = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LogicalOperator3_h_tmp_0;

    /* Switch: '<S293>/Switch' incorporates:
     *  RelationalOperator: '<S293>/UpperRelop'
     */
    if (rtb_Divide_g < rtb_L0_TLC_i) {
      rtb_Switch_i = rtb_L0_TLC_i;
    } else {
      rtb_Switch_i = rtb_Divide_g;
    }

    /* End of Switch: '<S293>/Switch' */

    /* Switch: '<S293>/Switch2' incorporates:
     *  RelationalOperator: '<S293>/LowerRelop1'
     */
    if (rtb_Divide_g > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_l = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_l = rtb_Switch_i;
    }

    /* End of Switch: '<S293>/Switch2' */

    /* Switch: '<S286>/Switch3' incorporates:
     *  Gain: '<S286>/Gain1'
     *  RelationalOperator: '<S288>/Relational Operator2'
     */
    if (rtb_Merge1_o >= 0.0F) {
      /* Switch: '<S286>/Switch2' incorporates:
       *  Constant: '<S286>/Constant2'
       *  DataTypeConversion: '<S286>/Cast To Single'
       *  RelationalOperator: '<S287>/Relational Operator2'
       */
      if (rtb_Merge1_o > 0.0F) {
        rtb_IMAPve_d_BCM_Right_Light = (uint8)((x20 <= rtb_Switch2_k) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_Right_Light = ((uint8)0U);
      }

      /* End of Switch: '<S286>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Right_Light = (uint8)((((uint32)
        ((rtb_LL_LKA_EarliestWarnLine_C <= rtb_Switch2_l) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S286>/Switch3' */

    /* If: '<S271>/If' incorporates:
     *  Constant: '<S275>/Constant'
     *  Constant: '<S277>/Constant'
     *  Constant: '<S278>/Constant'
     */
    if ((((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
         (((sint32)rtb_IMAPve_d_BCM_Right_Light) == 1)) && (((sint32)
          rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S271>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S277>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S271>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) ==
      2)) && (((sint32)rtb_IMAPve_d_BCM_Right_Light) == 2)) && (((sint32)
                 rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S271>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S278>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S271>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S271>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S275>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S271>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S271>/If' */

    /* Memory: '<S321>/Memory' */
    rtb_Memory_dr = LKAS_DW.Memory_PreviousInput_c;

    /* If: '<S321>/If' */
    if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_LKA_Veh2CamW_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S321>/Ph1SWA' incorporates:
       *  ActionPort: '<S325>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_l);

      /* End of Outputs for SubSystem: '<S321>/Ph1SWA' */
    } else if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_LKA_Veh2CamW_C <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S321>/Ph2SWA' incorporates:
       *  ActionPort: '<S326>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_l);

      /* End of Outputs for SubSystem: '<S321>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S321>/Ph3SWA' incorporates:
       *  ActionPort: '<S327>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_dr, &rtb_Merge1_l);

      /* End of Outputs for SubSystem: '<S321>/Ph3SWA' */
    }

    /* End of If: '<S321>/If' */

    /* Product: '<S317>/Divide2' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S317>/Divide3' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Abs: '<S323>/Abs' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = fabsf(rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Product: '<S323>/Divide' */
    rtb_Divide_iz = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;

    /* Product: '<S317>/Divide1' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S329>/Switch' incorporates:
     *  RelationalOperator: '<S329>/UpperRelop'
     */
    if (rtb_Divide_iz < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_er = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_er = rtb_Divide_iz;
    }

    /* End of Switch: '<S329>/Switch' */

    /* Switch: '<S329>/Switch2' incorporates:
     *  RelationalOperator: '<S329>/LowerRelop1'
     */
    if (rtb_Divide_iz > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_b = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_b = rtb_Switch_er;
    }

    /* End of Switch: '<S329>/Switch2' */

    /* Abs: '<S324>/Abs' */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_LKA_Veh2CamW_C);

    /* Product: '<S324>/Divide' */
    rtb_Divide_d = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LKA_Veh2CamW_C;

    /* Switch: '<S330>/Switch' incorporates:
     *  RelationalOperator: '<S330>/UpperRelop'
     */
    if (rtb_Divide_d < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_p = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_p = rtb_Divide_d;
    }

    /* End of Switch: '<S330>/Switch' */

    /* Switch: '<S330>/Switch2' incorporates:
     *  RelationalOperator: '<S330>/LowerRelop1'
     */
    if (rtb_Divide_d > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_ne = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_ne = rtb_Switch_p;
    }

    /* End of Switch: '<S330>/Switch2' */

    /* Switch: '<S322>/Switch3' incorporates:
     *  Gain: '<S322>/Gain1'
     *  RelationalOperator: '<S324>/Relational Operator2'
     */
    if (rtb_Merge1_l >= 0.0F) {
      /* Switch: '<S322>/Switch2' incorporates:
       *  Constant: '<S322>/Constant2'
       *  DataTypeConversion: '<S322>/Cast To Single'
       *  RelationalOperator: '<S323>/Relational Operator2'
       */
      if (rtb_Merge1_l > 0.0F) {
        rtb_IMAPve_d_BCM_HazardLamp = (uint8)((rtb_L0_TLC <= rtb_Switch2_b) ? 1 :
          0);
      } else {
        rtb_IMAPve_d_BCM_HazardLamp = ((uint8)0U);
      }

      /* End of Switch: '<S322>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((((uint32)
        ((rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_ne) ? 1 : 0)) *
        ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S322>/Switch3' */

    /* Outputs for Enabled SubSystem: '<S322>/Sum Condition' incorporates:
     *  EnablePort: '<S328>/Enable'
     */
    if (((sint32)rtb_IMAPve_d_BCM_HazardLamp) > 0) {
      if (!LKAS_DW.SumCondition_MODE) {
        /* InitializeConditions for Memory: '<S328>/Memory' */
        LKAS_DW.Memory_PreviousInput_c2 = 0.0F;
        LKAS_DW.SumCondition_MODE = true;
      }

      /* Sum: '<S328>/Add1' incorporates:
       *  Memory: '<S328>/Memory'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_c2;

      /* Saturate: '<S328>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 5.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 5.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S328>/Saturation' */

      /* RelationalOperator: '<S328>/Relational Operator' incorporates:
       *  Constant: '<S322>/Constant'
       */
      LKAS_DW.RelationalOperator_j = (rtb_LL_ThresDet_lDvtThresLwrLDW <= 2.0F);

      /* Update for Memory: '<S328>/Memory' */
      LKAS_DW.Memory_PreviousInput_c2 = rtb_LL_ThresDet_lDvtThresLwrLDW;
    } else {
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S328>/Out' */
        LKAS_DW.RelationalOperator_j = false;
        LKAS_DW.SumCondition_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S322>/Sum Condition' */

    /* If: '<S309>/If' incorporates:
     *  Constant: '<S313>/Constant'
     *  Constant: '<S315>/Constant'
     *  DataTypeConversion: '<S322>/Cast To Single3'
     *  DataTypeConversion: '<S322>/Cast To Single4'
     *  Product: '<S322>/Divide'
     */
    if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
        (((sint32)((uint32)(((uint32)rtb_IMAPve_d_BCM_HazardLamp) *
                            (LKAS_DW.RelationalOperator_j ? 1U : 0U)))) == 0)) {
      /* Outputs for IfAction SubSystem: '<S309>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S315>/Action Port'
       */
      LKAS_DW.Merge_a = true;

      /* End of Outputs for SubSystem: '<S309>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S309>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S313>/Action Port'
       */
      LKAS_DW.Merge_a = false;

      /* End of Outputs for SubSystem: '<S309>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S309>/If' */

    /* Outputs for Enabled SubSystem: '<S270>/Count_5s3' incorporates:
     *  EnablePort: '<S535>/Enable'
     */
    /* RelationalOperator: '<S520>/Compare' incorporates:
     *  Constant: '<S520>/Constant'
     *  Constant: '<S553>/Constant'
     */
    if (((uint8)0U) == ((uint8)1U)) {
      if (!LKAS_DW.Count_5s3_MODE) {
        /* InitializeConditions for Memory: '<S535>/Memory' */
        LKAS_DW.Memory_PreviousInput_n = 0.0F;
        LKAS_DW.Count_5s3_MODE = true;
      }

      /* Sum: '<S535>/Add' incorporates:
       *  Memory: '<S535>/Memory'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_DW.Memory_PreviousInput_n +
        rtb_LKA_SampleTime;

      /* Saturate: '<S535>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 11.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 11.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S535>/Saturation' */

      /* RelationalOperator: '<S535>/Relational Operator' incorporates:
       *  Constant: '<S535>/Constant1'
       */
      LKAS_DW.RelationalOperator = (rtb_LL_ThresDet_lDvtThresLwrLDW >= ((float32)
        ((uint16)5U)));

      /* Update for Memory: '<S535>/Memory' */
      LKAS_DW.Memory_PreviousInput_n = rtb_LL_ThresDet_lDvtThresLwrLDW;
    } else {
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S535>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S520>/Compare' */
    /* End of Outputs for SubSystem: '<S270>/Count_5s3' */

    /* RelationalOperator: '<S525>/Compare' incorporates:
     *  Constant: '<S525>/Constant'
     */
    rtb_Compare_f2 = (rtb_IMAPve_d_Camera_Status == ((uint8)3U));

    /* Outputs for Enabled SubSystem: '<S270>/Count_5s2' */
    LKAS_Count_5s1(rtb_Compare_f2, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_m, &LKAS_DW.Count_5s2);

    /* End of Outputs for SubSystem: '<S270>/Count_5s2' */

    /* Logic: '<S270>/Logical Operator10' */
    LKAS_DW.LKA_Fault = ((LKAS_DW.RelationalOperator) ||
                         (LKAS_DW.RelationalOperator_m));

    /* Chart: '<S78>/LDW_State_Machine'
     *
     * Block description for '<S78>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* RelationalOperator: '<S524>/Compare' incorporates:
     *  Constant: '<S524>/Constant'
     */
    rtb_Compare_jc = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

    /* Outputs for Enabled SubSystem: '<S270>/Count_5s1' */
    LKAS_Count_5s1(rtb_Compare_jc, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_n, &LKAS_DW.Count_5s1);

    /* End of Outputs for SubSystem: '<S270>/Count_5s1' */

    /* Logic: '<S270>/Logical Operator8' */
    LKAS_DW.LKA_Fault = (((LKAS_DW.RelationalOperator) ||
                          (LKAS_DW.RelationalOperator_m)) ||
                         (LKAS_DW.RelationalOperator_n));

    /* Chart: '<S78>/LKA_State_Machine'
     *
     * Block description for '<S78>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S247>/Subsystem' incorporates:
     *  EnablePort: '<S251>/Enable'
     */
    /* Logic: '<S247>/Logical Operator3' incorporates:
     *  Abs: '<S247>/Abs4'
     *  Abs: '<S247>/Abs5'
     *  Abs: '<S247>/Abs6'
     *  Abs: '<S247>/Abs7'
     *  Constant: '<S247>/Constant'
     *  Constant: '<S247>/Constant1'
     *  Constant: '<S247>/Constant4'
     *  Constant: '<S247>/Constant5'
     *  Constant: '<S249>/Constant'
     *  Constant: '<S250>/Constant'
     *  Logic: '<S247>/Logical Operator'
     *  Logic: '<S247>/Logical Operator1'
     *  Logic: '<S247>/Logical Operator4'
     *  RelationalOperator: '<S247>/Relational Operator'
     *  RelationalOperator: '<S247>/Relational Operator1'
     *  RelationalOperator: '<S247>/Relational Operator2'
     *  RelationalOperator: '<S247>/Relational Operator3'
     *  RelationalOperator: '<S247>/Relational Operator6'
     *  RelationalOperator: '<S247>/Relational Operator7'
     *  RelationalOperator: '<S249>/Compare'
     *  RelationalOperator: '<S250>/Compare'
     *  Switch: '<S55>/Switch'
     *  Switch: '<S55>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_c) <= 0.005F) && (fabsf(rtb_L0_C1) <= 0.005F)) &&
           ((fabsf(rtb_L0_C2_c) <= 0.0001F) && (fabsf(rtb_L0_C2) <= 0.0001F))) &&
          ((rtb_L0_Q_l == ((uint8)3U)) && (rtb_R0_Q == ((uint8)3U)))) &&
         (rtb_IMAPve_g_ESC_VehSpd >= 50.0F)) && (rtb_TLft <= 1.0F)) {
      if (!LKAS_DW.Subsystem_MODE_m) {
        /* InitializeConditions for Memory: '<S251>/Memory' */
        LKAS_DW.Memory_PreviousInput_c2t = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_m = true;
      }

      /* Sum: '<S251>/Add1' incorporates:
       *  Memory: '<S251>/Memory'
       */
      rtb_Saturation_i3 = (uint16)(1U + ((uint32)
        LKAS_DW.Memory_PreviousInput_c2t));

      /* Saturate: '<S251>/Saturation' */
      if (rtb_Saturation_i3 >= ((uint16)3000U)) {
        rtb_Saturation_i3 = ((uint16)3000U);
      }

      /* End of Saturate: '<S251>/Saturation' */

      /* RelationalOperator: '<S251>/Relational Operator' incorporates:
       *  Constant: '<S247>/Constant3'
       *  DataTypeConversion: '<S251>/Cast To Single1'
       *  Product: '<S247>/Divide'
       */
      LKAS_DW.RelationalOperator_h = (rtb_Saturation_i3 >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S251>/Memory' */
      LKAS_DW.Memory_PreviousInput_c2t = rtb_Saturation_i3;
    } else {
      if (LKAS_DW.Subsystem_MODE_m) {
        /* Disable for Outport: '<S251>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.Subsystem_MODE_m = false;
      }
    }

    /* End of Logic: '<S247>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S247>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S225>/Subsystem' incorporates:
     *  EnablePort: '<S246>/Enable'
     */
    if (LKAS_DW.RelationalOperator_h) {
      /* Sum: '<S248>/Add2' incorporates:
       *  Constant: '<S248>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S248>/Memory3'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S248>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 50.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 50.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S248>/Saturation' */

      /* Switch: '<S248>/Switch' incorporates:
       *  Constant: '<S246>/Constant'
       *  Product: '<S248>/Divide'
       *  Product: '<S248>/Divide1'
       *  Sum: '<S248>/Add'
       *  Sum: '<S248>/Add1'
       *  UnitDelay: '<S248>/Unit Delay'
       */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 1.0F) {
        rtb_LL_ThresDet_tiTTLCThresLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_IMAPve_g_SW_Angle - LKAS_DW.UnitDelay_DSTATE)) +
          LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_tiTTLCThresLDW = rtb_IMAPve_g_SW_Angle;
      }

      /* End of Switch: '<S248>/Switch' */

      /* Saturate: '<S246>/Saturation' */
      if (rtb_LL_ThresDet_tiTTLCThresLDW > 3.0F) {
        LKAS_DW.Saturation_k = 3.0F;
      } else if (rtb_LL_ThresDet_tiTTLCThresLDW < (-3.0F)) {
        LKAS_DW.Saturation_k = (-3.0F);
      } else {
        LKAS_DW.Saturation_k = rtb_LL_ThresDet_tiTTLCThresLDW;
      }

      /* End of Saturate: '<S246>/Saturation' */

      /* Update for UnitDelay: '<S248>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_tiTTLCThresLDW;

      /* Update for Memory: '<S248>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_ThresDet_lDvtThresLwrLDW;
    }

    /* End of Outputs for SubSystem: '<S225>/Subsystem' */

    /* Saturate: '<S227>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 0.001F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.001F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S227>/Saturation' */

    /* Gain: '<S259>/kph To mps' incorporates:
     *  Gain: '<S260>/kph To mps'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = 0.277777791F * rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S259>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S261>:1' */
    /* '<S261>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 150.0F;
    } else if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 60.0F;
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Saturate: '<S259>/Saturation3' */

    /* Product: '<S259>/Divide1' incorporates:
     *  Constant: '<S259>/Constant'
     */
    rtb_L0_TLC_i = 0.09F / rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Saturate: '<S259>/Saturation1' */
    if (rtb_L0_TLC_i > 0.0117F) {
      rtb_L0_TLC_i = 0.0117F;
    } else {
      if (rtb_L0_TLC_i < 0.00237F) {
        rtb_L0_TLC_i = 0.00237F;
      }
    }

    /* End of Saturate: '<S259>/Saturation1' */

    /* Switch: '<S545>/Switch7' incorporates:
     *  Constant: '<S545>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_h != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_h;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S545>/Switch7' */

    /* MATLAB Function: '<S259>/MATLAB Function' incorporates:
     *  Gain: '<S259>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_L0_TLC_i *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_g) * LKAS_DW.LKA_WhlBaseL_C_k) /
      (rtb_LL_ThresDet_tiTTLCThresLDW * rtb_LL_ThresDet_tiTTLCThresLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S260>/Saturation3' */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 60.0F;
      }
    }

    /* End of Saturate: '<S260>/Saturation3' */

    /* Product: '<S260>/Divide1' incorporates:
     *  Constant: '<S260>/Constant'
     */
    rtb_LL_LDW_LatestWarnLine_C = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S260>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S262>:1' */
    /* '<S262>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_LDW_LatestWarnLine_C > 0.0117F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.0117F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 0.00237F) {
        rtb_LL_LDW_LatestWarnLine_C = 0.00237F;
      }
    }

    /* End of Saturate: '<S260>/Saturation1' */

    /* Switch: '<S545>/Switch4' incorporates:
     *  Constant: '<S545>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_d != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_d;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S545>/Switch4' */

    /* MATLAB Function: '<S260>/MATLAB Function' */
    LKAS_DW.SWARmax = ((((((((rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_g) * LKAS_DW.LKA_WhlBaseL_C_k) /
                        (rtb_LL_ThresDet_tiTTLCThresLDW *
                         rtb_LL_ThresDet_tiTTLCThresLDW)) * 180.0F) / 3.14F;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Sum: '<S220>/Add' incorporates:
     *  Sum: '<S178>/Add1'
     */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_L0_C1_c + rtb_L0_C1;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Gain: '<S220>/Gain' incorporates:
     *  Sum: '<S220>/Add'
     */
    rtb_phiHdAg = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * 0.5F;

    /* Gain: '<S222>/Gain1' incorporates:
     *  Sum: '<S222>/Add1'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = (rtb_Add_pq + rtb_Add_m) * 0.5F;

    /* Switch: '<S224>/Switch' incorporates:
     *  Constant: '<S240>/Constant'
     *  RelationalOperator: '<S240>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_L0_TLC_i = rtb_LFTTTLC;
    } else {
      rtb_L0_TLC_i = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S224>/Switch' */

    /* Saturate: '<S224>/Saturation' */
    if (rtb_L0_TLC_i > 2.0F) {
      rtb_L0_TLC_i = 2.0F;
    } else {
      if (rtb_L0_TLC_i < 0.5F) {
        rtb_L0_TLC_i = 0.5F;
      }
    }

    /* End of Saturate: '<S224>/Saturation' */

    /* Product: '<S244>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_TLC_i;

    /* Sum: '<S243>/Add' incorporates:
     *  Gain: '<S243>/Gain1'
     *  Product: '<S243>/Product3'
     *  Product: '<S243>/Product4'
     *  Product: '<S243>/Z*Z'
     */
    rtb_Add_nb = ((rtb_Add_pq_tmp * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C1_c)
      + ((3.0F * rtb_L0_C3_k) * (rtb_LL_LDW_LatestWarnLine_C *
          rtb_LL_LDW_LatestWarnLine_C));

    /* Switch: '<S224>/Switch1' incorporates:
     *  Constant: '<S241>/Constant'
     *  RelationalOperator: '<S241>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S224>/Switch1' */

    /* Saturate: '<S224>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S224>/Saturation1' */

    /* Product: '<S245>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * rtb_LL_HdAgPrvwT_C;

    /* Sum: '<S242>/Add' incorporates:
     *  Gain: '<S242>/Gain1'
     *  Product: '<S242>/Product3'
     *  Product: '<S242>/Product4'
     *  Product: '<S242>/Z*Z'
     */
    rtb_Add_jr = ((rtb_Add_m_tmp * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C1) +
      ((3.0F * rtb_L0_C3) * (rtb_LL_LDW_LatestWarnLine_C *
        rtb_LL_LDW_LatestWarnLine_C));

    /* Switch: '<S545>/Switch8' incorporates:
     *  Constant: '<S545>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_k != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_k;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S545>/Switch8' */

    /* Product: '<S239>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Product: '<S237>/Z*Z' incorporates:
     *  Product: '<S238>/Z*Z'
     */
    rtb_LL_HdAgPrvwT_C = rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_LDW_LatestWarnLine_C;

    /* Sum: '<S237>/Add' incorporates:
     *  Product: '<S237>/Product'
     *  Product: '<S237>/Product3'
     *  Product: '<S237>/Product4'
     *  Product: '<S237>/Z*Z'
     *  Product: '<S237>/Z*Z*Z'
     */
    rtb_Add_d = (((rtb_L0_C1_c * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C0_c) +
                 (rtb_L0_C2_c * rtb_LL_HdAgPrvwT_C)) +
      ((rtb_LL_LDW_LatestWarnLine_C * rtb_LL_HdAgPrvwT_C) * rtb_L0_C3_k);

    /* Sum: '<S238>/Add' incorporates:
     *  Product: '<S238>/Product'
     *  Product: '<S238>/Product3'
     *  Product: '<S238>/Product4'
     *  Product: '<S238>/Z*Z*Z'
     */
    rtb_Add_pv = (((rtb_L0_C1 * rtb_LL_LDW_LatestWarnLine_C) + rtb_Saturation_jn)
                  + (rtb_L0_C2 * rtb_LL_HdAgPrvwT_C)) +
      ((rtb_LL_LDW_LatestWarnLine_C * rtb_LL_HdAgPrvwT_C) * rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S104>/Memory' */
        LKAS_DW.Memory_PreviousInput_gq = 0.0F;

        /* InitializeConditions for Memory: '<S141>/Memory' */
        LKAS_DW.Memory_PreviousInput_h = ((uint16)0U);

        /* InitializeConditions for Memory: '<S87>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_a = ((uint8)0U);

        /* InitializeConditions for Memory: '<S140>/Memory' */
        LKAS_DW.Memory_PreviousInput_oc = ((uint16)0U);

        /* InitializeConditions for Memory: '<S142>/Memory' */
        LKAS_DW.Memory_PreviousInput_py2 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S136>/Memory' */
        LKAS_DW.Memory_PreviousInput_mu = ((uint16)0U);

        /* InitializeConditions for Memory: '<S139>/Memory' */
        LKAS_DW.Memory_PreviousInput_n3 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S138>/Memory' */
        LKAS_DW.Memory_PreviousInput_bc = ((uint16)0U);

        /* InitializeConditions for Memory: '<S137>/Memory' */
        LKAS_DW.Memory_PreviousInput_mn = ((uint16)0U);

        /* InitializeConditions for Memory: '<S114>/Memory' */
        LKAS_DW.Memory_PreviousInput_ip = 0.0F;

        /* InitializeConditions for Memory: '<S105>/Memory' */
        LKAS_DW.Memory_PreviousInput_py = 0.0F;

        /* InitializeConditions for Memory: '<S106>/Memory' */
        LKAS_DW.Memory_PreviousInput_oy = 0.0F;

        /* InitializeConditions for Memory: '<S103>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_k = 0.0F;

        /* InitializeConditions for Memory: '<S195>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e = 0.0F;

        /* InitializeConditions for Memory: '<S180>/Memory' */
        LKAS_DW.Memory_PreviousInput_e = 0.0F;

        /* InitializeConditions for UnitDelay: '<S178>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_k = 0.0F;

        /* InitializeConditions for Memory: '<S186>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_c = 0.0F;

        /* InitializeConditions for Memory: '<S190>/Memory' */
        LKAS_DW.Memory_PreviousInput_l = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S194>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_m = 0.0F;

        /* InitializeConditions for Memory: '<S194>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_h = 0.0F;

        /* InitializeConditions for UnitDelay: '<S173>/Delay Input2'
         *
         * Block description for '<S173>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_g = 0.0F;

        /* InitializeConditions for Memory: '<S173>/Memory' */
        LKAS_DW.Memory_PreviousInput_e1 = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S94>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S94>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S106>/Moving Standard Deviation1' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S106>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S106>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2_m);

        /* End of SystemReset for SubSystem: '<S106>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Sum: '<S104>/Add2' incorporates:
       *  Memory: '<S104>/Memory'
       */
      rtb_L0_TLC_i = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_gq;

      /* Saturate: '<S104>/Saturation2' */
      if (rtb_L0_TLC_i > 20.0F) {
        rtb_Saturation2 = 20.0F;
      } else if (rtb_L0_TLC_i < 0.0F) {
        rtb_Saturation2 = 0.0F;
      } else {
        rtb_Saturation2 = rtb_L0_TLC_i;
      }

      /* End of Saturate: '<S104>/Saturation2' */

      /* Saturate: '<S104>/Saturation' */
      if (rtb_TTLC > 0.004F) {
        rtb_L0_TLC_i = 0.004F;
      } else if (rtb_TTLC < 0.0F) {
        rtb_L0_TLC_i = 0.0F;
      } else {
        rtb_L0_TLC_i = rtb_TTLC;
      }

      /* End of Saturate: '<S104>/Saturation' */

      /* RelationalOperator: '<S104>/Relational Operator4' incorporates:
       *  Constant: '<S104>/Constant'
       *  Constant: '<S104>/Constant1'
       *  Product: '<S104>/Divide'
       *  Sum: '<S104>/Add'
       */
      rtb_LogicalOperator3_b = (rtb_Saturation2 >=
        ((((rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F) * rtb_L0_TLC_i) / 0.004F) +
         rtb_LL_LKAExPrcs_tiExitTime1));

      /* Sum: '<S141>/Add' incorporates:
       *  Constant: '<S141>/Constant'
       *  Memory: '<S141>/Memory'
       */
      rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_h));

      /* Saturate: '<S141>/Saturation1' */
      if (rtb_Saturation_i3 < ((uint16)10000U)) {
        rtb_Saturation1_b = rtb_Saturation_i3;
      } else {
        rtb_Saturation1_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S141>/Saturation1' */

      /* If: '<S141>/If' incorporates:
       *  Constant: '<S141>/Constant2'
       */
      if (rtb_Saturation1_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S141>/if action ' incorporates:
         *  ActionPort: '<S158>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_SW_Angle, &LKAS_DW.In_k);

        /* End of Outputs for SubSystem: '<S141>/if action ' */
      }

      /* End of If: '<S141>/If' */

      /* Sum: '<S87>/Add' incorporates:
       *  Constant: '<S87>/Constant'
       *  Memory: '<S87>/Memory1'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_a));

      /* Saturate: '<S87>/Saturation1' */
      if (rtb_IMAPve_d_BCM_HazardLamp < ((uint8)5U)) {
        rtb_Saturation1_cw = rtb_IMAPve_d_BCM_HazardLamp;
      } else {
        rtb_Saturation1_cw = ((uint8)5U);
      }

      /* End of Saturate: '<S87>/Saturation1' */

      /* Saturate: '<S113>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S113>/Saturation3' */

      /* Product: '<S113>/Divide1' incorporates:
       *  Constant: '<S113>/Constant'
       */
      rtb_L0_TLC_i = 0.09F / x10;

      /* Saturate: '<S113>/Saturation1' */
      if (rtb_L0_TLC_i > 0.0117F) {
        LKAS_DW.StbFacm_SY = 0.0117F;
      } else if (rtb_L0_TLC_i < 0.00237F) {
        LKAS_DW.StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.StbFacm_SY = rtb_L0_TLC_i;
      }

      /* End of Saturate: '<S113>/Saturation1' */

      /* Sum: '<S140>/Add' incorporates:
       *  Constant: '<S140>/Constant'
       *  Memory: '<S140>/Memory'
       */
      rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_oc));

      /* Saturate: '<S140>/Saturation1' */
      if (rtb_Saturation_i3 < ((uint16)10000U)) {
        rtb_Saturation1_p = rtb_Saturation_i3;
      } else {
        rtb_Saturation1_p = ((uint16)10000U);
      }

      /* End of Saturate: '<S140>/Saturation1' */

      /* If: '<S133>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S145>/Action Port'
         */
        LKAS_ifaction3(rtb_LFTTTLC, &rtb_Merge_h);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S144>/Action Port'
         */
        LKAS_ifaction3(rtb_RGTTTLC, &rtb_Merge_h);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_h);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem3' */
      }

      /* End of If: '<S133>/If' */

      /* If: '<S140>/If' incorporates:
       *  Constant: '<S140>/Constant2'
       */
      if (rtb_Saturation1_p == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S140>/if action ' incorporates:
         *  ActionPort: '<S157>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_h, &LKAS_DW.In_m);

        /* End of Outputs for SubSystem: '<S140>/if action ' */
      }

      /* End of If: '<S140>/If' */

      /* Saturate: '<S113>/Saturation2' */
      if (LKAS_DW.In_m > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_m < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_m;
      }

      /* End of Saturate: '<S113>/Saturation2' */

      /* Sum: '<S142>/Add' incorporates:
       *  Constant: '<S142>/Constant'
       *  Memory: '<S142>/Memory'
       */
      rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_py2));

      /* Saturate: '<S142>/Saturation1' */
      if (rtb_Saturation_i3 < ((uint16)10000U)) {
        rtb_Saturation1_h = rtb_Saturation_i3;
      } else {
        rtb_Saturation1_h = ((uint16)10000U);
      }

      /* End of Saturate: '<S142>/Saturation1' */

      /* If: '<S142>/If' incorporates:
       *  Constant: '<S142>/Constant2'
       */
      if (rtb_Saturation1_h == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S142>/if action ' incorporates:
         *  ActionPort: '<S159>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_ESC_VehSpd, &LKAS_DW.In_e);

        /* End of Outputs for SubSystem: '<S142>/if action ' */
      }

      /* End of If: '<S142>/If' */

      /* Sum: '<S136>/Add' incorporates:
       *  Constant: '<S136>/Constant'
       *  Memory: '<S136>/Memory'
       */
      rtb_Add_ov = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_mu));

      /* DataTypeConversion: '<S168>/Data Type Conversion' incorporates:
       *  Constant: '<S169>/Constant'
       *  RelationalOperator: '<S169>/Compare'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((rtb_Merge_c <= 0.0F) ? 1 : 0);

      /* Switch: '<S545>/Switch5' incorporates:
       *  Constant: '<S545>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_h;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S545>/Switch5' */

      /* Product: '<S168>/Divide' */
      rtb_Saturation4 = (rtb_Merge_c * rtb_LKA_Veh2CamL_C_tmp) * x10;

      /* Abs: '<S168>/Abs1' incorporates:
       *  Abs: '<S168>/Abs'
       */
      rtb_L0_C3 = fabsf(rtb_Saturation4);
      rtb_Abs1_n = rtb_L0_C3;

      /* Abs: '<S168>/Abs' */
      rtb_Abs_p = rtb_L0_C3;

      /* If: '<S168>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) && (((sint32)
            rtb_IMAPve_d_BCM_HazardLamp) == 0)) {
        /* Outputs for IfAction SubSystem: '<S168>/If Action Subsystem' incorporates:
         *  ActionPort: '<S170>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_p, &rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S168>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) && (((sint32)
                   rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
        /* Outputs for IfAction SubSystem: '<S168>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S172>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_n, &rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S168>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S168>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S171>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S168>/If Action Subsystem2' */
      }

      /* End of If: '<S168>/If' */

      /* Switch: '<S545>/Switch6' incorporates:
       *  Constant: '<S545>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_f != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_f;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S545>/Switch6' */

      /* Sum: '<S164>/Add' incorporates:
       *  Sum: '<S105>/Add3'
       *  Sum: '<S106>/Add'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Sum: '<S164>/Add1' incorporates:
       *  Product: '<S164>/Divide'
       *  Product: '<S164>/Divide1'
       *  Sum: '<S164>/Add'
       */
      rtb_Add1_ac = (((1.0F / x10) * rtb_LL_LKAExPrcs_tiExitTime1) /
                     rtb_LKA_Veh2CamL_C_tmp) + rtb_Saturation4;

      /* If: '<S116>/If' incorporates:
       *  Constant: '<S167>/Constant2'
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S116>/If Action Subsystem' incorporates:
         *  ActionPort: '<S165>/Action Port'
         */
        /* Gain: '<S165>/Gain2' */
        rtb_Merge_p = (-1.0F) * rtb_Add1_ac;

        /* End of Outputs for SubSystem: '<S116>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S116>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S166>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_ac, &rtb_Merge_p);

        /* End of Outputs for SubSystem: '<S116>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S116>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S167>/Action Port'
         */
        rtb_Merge_p = 0.0F;

        /* End of Outputs for SubSystem: '<S116>/If Action Subsystem2' */
      }

      /* End of If: '<S116>/If' */

      /* Saturate: '<S136>/Saturation1' */
      if (rtb_Add_ov < ((uint16)10000U)) {
        rtb_Saturation_i3 = rtb_Add_ov;
      } else {
        rtb_Saturation_i3 = ((uint16)10000U);
      }

      /* End of Saturate: '<S136>/Saturation1' */

      /* If: '<S136>/If' incorporates:
       *  Constant: '<S136>/Constant2'
       */
      if (rtb_Saturation_i3 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S136>/if action ' incorporates:
         *  ActionPort: '<S153>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_p, &LKAS_DW.In_br);

        /* End of Outputs for SubSystem: '<S136>/if action ' */
      }

      /* End of If: '<S136>/If' */

      /* Sum: '<S139>/Add' incorporates:
       *  Constant: '<S139>/Constant'
       *  Memory: '<S139>/Memory'
       */
      rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_n3));

      /* Saturate: '<S139>/Saturation1' */
      if (rtb_Saturation_i3 < ((uint16)10000U)) {
        rtb_Saturation1_n = rtb_Saturation_i3;
      } else {
        rtb_Saturation1_n = ((uint16)10000U);
      }

      /* End of Saturate: '<S139>/Saturation1' */

      /* If: '<S139>/If' incorporates:
       *  Constant: '<S139>/Constant2'
       */
      if (rtb_Saturation1_n == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S139>/if action ' incorporates:
         *  ActionPort: '<S156>/Action Port'
         */
        LKAS_ifaction(rtb_phiHdAg, &LKAS_DW.In_it);

        /* End of Outputs for SubSystem: '<S139>/if action ' */
      }

      /* End of If: '<S139>/If' */

      /* Sum: '<S138>/Add' incorporates:
       *  Constant: '<S138>/Constant'
       *  Memory: '<S138>/Memory'
       */
      rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_bc));

      /* Saturate: '<S138>/Saturation1' */
      if (rtb_Saturation_i3 < ((uint16)10000U)) {
        rtb_Saturation1_hl = rtb_Saturation_i3;
      } else {
        rtb_Saturation1_hl = ((uint16)10000U);
      }

      /* End of Saturate: '<S138>/Saturation1' */

      /* If: '<S135>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S135>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S151>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_d, &rtb_Merge_i);

        /* End of Outputs for SubSystem: '<S135>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S135>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S150>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_pv, &rtb_Merge_i);

        /* End of Outputs for SubSystem: '<S135>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S135>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S152>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_i);

        /* End of Outputs for SubSystem: '<S135>/If Action Subsystem3' */
      }

      /* End of If: '<S135>/If' */

      /* If: '<S138>/If' incorporates:
       *  Constant: '<S138>/Constant2'
       */
      if (rtb_Saturation1_hl == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S138>/if action ' incorporates:
         *  ActionPort: '<S155>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_i, &LKAS_DW.In_p);

        /* End of Outputs for SubSystem: '<S138>/if action ' */
      }

      /* End of If: '<S138>/If' */

      /* Sum: '<S137>/Add' incorporates:
       *  Constant: '<S137>/Constant'
       *  Memory: '<S137>/Memory'
       */
      rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_mn));

      /* Saturate: '<S137>/Saturation1' */
      if (rtb_Saturation_i3 < ((uint16)10000U)) {
        rtb_Saturation1_j = rtb_Saturation_i3;
      } else {
        rtb_Saturation1_j = ((uint16)10000U);
      }

      /* End of Saturate: '<S137>/Saturation1' */

      /* If: '<S134>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S134>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_nb, &rtb_Merge_pw);

        /* End of Outputs for SubSystem: '<S134>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S134>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_jr, &rtb_Merge_pw);

        /* End of Outputs for SubSystem: '<S134>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S134>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S149>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_pw);

        /* End of Outputs for SubSystem: '<S134>/If Action Subsystem3' */
      }

      /* End of If: '<S134>/If' */

      /* If: '<S137>/If' incorporates:
       *  Constant: '<S137>/Constant2'
       */
      if (rtb_Saturation1_j == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S137>/if action ' incorporates:
         *  ActionPort: '<S154>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_pw, &LKAS_DW.In_e3);

        /* End of Outputs for SubSystem: '<S137>/if action ' */
      }

      /* End of If: '<S137>/If' */

      /* If: '<S143>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S143>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S161>/Action Port'
         */
        /* SignalConversion: '<S161>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S161>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S143>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S143>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S160>/Action Port'
         */
        /* SignalConversion: '<S160>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S160>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S143>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S143>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S162>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S143>/If Action Subsystem3' */
      }

      /* End of If: '<S143>/If' */

      /* If: '<S87>/If' incorporates:
       *  Constant: '<S87>/Constant19'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem;
      rtAction = -1;
      if (rtb_Saturation1_cw == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        if (0 != rtPrevAction) {
          /* SystemReset for IfAction SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
           *  ActionPort: '<S112>/Action Port'
           *
           * Block description for '<S87>/LKA Motion Planning Calculation (LKAMPCal)':
           *  Block Name: LKA Motion Planning Calculation
           *  Ab.: LKAMPCal
           *  No.: 1.2.3.2
           *  Rev: 0.0.1
           *  Update Date: 19-3-26
           */
          /* SystemReset for If: '<S87>/If' */
          LKAMotionPlanningCalculat_Reset();

          /* End of SystemReset for SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */
        }

        /* Outputs for IfAction SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S112>/Action Port'
         *
         * Block description for '<S87>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S87>/If' */

      /* Memory: '<S114>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_ip;

      /* Sum: '<S114>/Add' incorporates:
       *  Gain: '<S114>/Gain1'
       *  Product: '<S114>/Divide'
       *  Product: '<S114>/Product'
       */
      rtb_Add_oi = ((rtb_LKA_Veh2CamL_C_tmp * rtb_LKA_SampleTime) /
                    (0.277777791F * LKAS_DW.In_e)) + rtb_Saturation4;

      /* MATLAB Function: '<S115>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S163>:1' */
      /* '<S163>:1:20' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S163>:1:21' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S163>:1:22' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S163>:1:23' Delte2PhSWGrad = SWACmd_dphi2PhSWAGrad; */
      /* '<S163>:1:24' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S163>:1:25' NomT = SWACmd_tiNomT; */
      /* '<S163>:1:26' T1 = (DelteSW1-DelteSW0)/Delte1PhSWGrad; */
      rtb_L0_C3 = (LKAS_DW.K1K2Det_phi2PhSWAIni - LKAS_DW.In_k) /
        LKAS_DW.K1K2Det_dphi1PhSWAGrad;

      /* '<S163>:1:27' T2 = (0-DelteSW1)/Delte2PhSWGrad+T1; */
      rtb_L0_C3_k = ((0.0F - LKAS_DW.K1K2Det_phi2PhSWAIni) /
                     LKAS_DW.K1K2Det_dphi2PhSWAGrad1) + rtb_L0_C3;

      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S163>:1:35' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_oi < rtb_L0_C3) && (rtb_Add_oi >= 0.0F)) {
        /* '<S163>:1:36' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_oi) +
          LKAS_DW.In_k;
      } else if ((rtb_Add_oi <= rtb_L0_C3_k) && (rtb_Add_oi >= rtb_L0_C3)) {
        /* '<S163>:1:37' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S163>:1:39' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_L0_C3) +
          LKAS_DW.In_k;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_oi >= rtb_L0_C3_k) {
          /* '<S163>:1:41' elseif(NomT >= T2) */
          /* '<S163>:1:42' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_L0_C3) +
            LKAS_DW.In_k;

          /*    DelteSWCmd = single(0); */
        }
      }

      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S163>:1:48' SWACmd_phiSWACmd = DelteSWCmd; */
      rtb_T2 = rtb_L0_C3_k;

      /* Saturate: '<S87>/Saturation6' incorporates:
       *  MATLAB Function: '<S115>/SWACmd'
       */
      if (rtb_L0_C3 > 2.0F) {
        rtb_Saturation6_k = 2.0F;
      } else if (rtb_L0_C3 < 0.2F) {
        rtb_Saturation6_k = 0.2F;
      } else {
        rtb_Saturation6_k = rtb_L0_C3;
      }

      /* End of Saturate: '<S87>/Saturation6' */

      /* Memory: '<S105>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_py;

      /* Sum: '<S105>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S105>/Saturation2' */
      if (rtb_Saturation4 > 12.0F) {
        rtb_Saturation2_n = 12.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation2_n = 0.0F;
      } else {
        rtb_Saturation2_n = rtb_Saturation4;
      }

      /* End of Saturate: '<S105>/Saturation2' */

      /* Abs: '<S105>/Abs2' */
      rtb_Saturation4 = fabsf(rtb_Gain1);

      /* Gain: '<S105>/Gain' */
      rtb_L0_C3 = rtb_LL_LKAExPrcs_tiExitTime1 * 0.166666672F;

      /* RelationalOperator: '<S105>/Relational Operator2' */
      rtb_Compare_l4 = (rtb_Saturation4 >= rtb_L0_C3);

      /* Abs: '<S105>/Abs3' */
      rtb_Saturation4 = fabsf(rtb_Add5_j);

      /* Outputs for Enabled SubSystem: '<S105>/Sum Condition1' incorporates:
       *  EnablePort: '<S107>/Enable'
       */
      /* Logic: '<S105>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S105>/Relational Operator3'
       *  RelationalOperator: '<S105>/Relational Operator4'
       */
      if (((rtb_Saturation2_n >= rtb_Saturation6_k) && rtb_Compare_l4) &&
          (rtb_Saturation4 >= rtb_L0_C3)) {
        if (!LKAS_DW.SumCondition1_MODE_p2) {
          /* InitializeConditions for Memory: '<S107>/Memory' */
          LKAS_DW.Memory_PreviousInput_j = 0.0F;
          LKAS_DW.SumCondition1_MODE_p2 = true;
        }

        /* Sum: '<S107>/Add1' incorporates:
         *  Memory: '<S107>/Memory'
         */
        rtb_L0_C3 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_j;

        /* Saturate: '<S107>/Saturation' */
        if (rtb_L0_C3 > 10.0F) {
          rtb_L0_C3 = 10.0F;
        } else {
          if (rtb_L0_C3 < 0.0F) {
            rtb_L0_C3 = 0.0F;
          }
        }

        /* End of Saturate: '<S107>/Saturation' */

        /* Saturate: '<S105>/Saturation' */
        if (rtb_TTLC > 0.004F) {
          rtb_L0_TLC_i = 0.004F;
        } else if (rtb_TTLC < 0.0F) {
          rtb_L0_TLC_i = 0.0F;
        } else {
          rtb_L0_TLC_i = rtb_TTLC;
        }

        /* End of Saturate: '<S105>/Saturation' */

        /* RelationalOperator: '<S107>/Relational Operator' incorporates:
         *  Constant: '<S105>/Constant'
         *  Constant: '<S105>/Constant1'
         *  Product: '<S105>/Divide'
         *  Sum: '<S105>/Add1'
         */
        LKAS_DW.RelationalOperator_mf = (rtb_L0_C3 >=
          ((((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) * rtb_L0_TLC_i) / 0.004F) +
           rtb_LL_LKAExPrcs_tiExitTime2));

        /* Update for Memory: '<S107>/Memory' */
        LKAS_DW.Memory_PreviousInput_j = rtb_L0_C3;
      } else {
        if (LKAS_DW.SumCondition1_MODE_p2) {
          /* Disable for Outport: '<S107>/Out' */
          LKAS_DW.RelationalOperator_mf = false;
          LKAS_DW.SumCondition1_MODE_p2 = false;
        }
      }

      /* End of Logic: '<S105>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S105>/Sum Condition1' */

      /* Memory: '<S106>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_oy;

      /* Sum: '<S106>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S106>/Saturation2' */
      if (rtb_Saturation4 > 10.0F) {
        rtb_Saturation2_g = 10.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation2_g = 0.0F;
      } else {
        rtb_Saturation2_g = rtb_Saturation4;
      }

      /* End of Saturate: '<S106>/Saturation2' */

      /* Gain: '<S106>/Gain' */
      rtb_Saturation4 = rtb_LL_LKAExPrcs_tiExitTime1 * 0.333333343F;

      /* RelationalOperator: '<S106>/Relational Operator2' */
      rtb_Compare_l4 = (rtb_Gain1 >= rtb_Saturation4);

      /* RelationalOperator: '<S106>/Relational Operator3' */
      rtb_Compare_ckd = (rtb_Add5_j >= rtb_Saturation4);

      /* Abs: '<S106>/Abs4' */
      rtb_Saturation4 = rtb_TTLC;

      /* Saturate: '<S106>/Saturation' */
      if (rtb_Saturation4 > 0.004F) {
        rtb_Saturation4 = 0.004F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S106>/Saturation' */

      /* Switch: '<S545>/Switch45' incorporates:
       *  Constant: '<S545>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S545>/Switch45' */

      /* Sum: '<S106>/Add6' incorporates:
       *  Constant: '<S106>/Constant'
       *  Constant: '<S106>/Constant7'
       *  Product: '<S106>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Saturation4) / 0.004F) + x10;

      /* Outputs for Enabled SubSystem: '<S85>/Subsystem' incorporates:
       *  EnablePort: '<S93>/Enable'
       */
      /* RelationalOperator: '<S92>/Compare' incorporates:
       *  Constant: '<S92>/Constant'
       */
      if (rtb_LL_LKASWASyn_TrqSwaAddSwt > 0.0F) {
        if (!LKAS_DW.Subsystem_MODE_mq) {
          LKAS_DW.Subsystem_MODE_mq = true;
        }

        /* MATLAB Function: '<S93>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S95>:1' */
        /* '<S95>:1:2' Swaadd=single(0); */
        /* '<S95>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S95>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S95>:1:5' l0c0=abs(l0c0); */
        /* '<S95>:1:6' r0c0=abs(r0c0); */
        /* '<S95>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_L0_C3_k = fmaxf(fminf(rtb_LftTTLC + rtb_TTLC_o, 5.4F), 2.5F);

        /* '<S95>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_L0_C3_k > 2.5F) && (rtb_L0_C3_k < 5.4F)) {
          /* '<S95>:1:9' leftlane=l0c0/lanewidth; */
          rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LftTTLC / rtb_L0_C3_k;

          /* '<S95>:1:10' rightlane=r0c0/lanewidth; */
          rtb_L0_C3 = rtb_TTLC_o / rtb_L0_C3_k;
        } else {
          /* '<S95>:1:11' else */
          /* '<S95>:1:12' leftlane=single(0.5); */
          rtb_LL_LKAExPrcs_tiExitTime2 = 0.5F;

          /* '<S95>:1:13' rightlane=single(0.5); */
          rtb_L0_C3 = 0.5F;
        }

        /* '<S95>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S95>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S95>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S545>/Switch42' incorporates:
           *  Constant: '<S545>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S95>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S545>/Switch43' incorporates:
           *  Constant: '<S545>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_L0_C3 = (((((180.0F - fmaxf(fminf(rtb_IMAPve_g_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_LL_LKAExPrcs_tiExitTime2) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S545>/Switch42' incorporates:
           *  Constant: '<S545>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S95>:1:19' else */
          /* '<S95>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S545>/Switch43' incorporates:
           *  Constant: '<S545>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_L0_C3 = (((((180.0F - fmaxf(fminf(rtb_IMAPve_g_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_L0_C3) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S96>/Add2' incorporates:
         *  Constant: '<S96>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S96>/Memory3'
         */
        rtb_L0_C3_k = 1.0F + LKAS_DW.Memory3_PreviousInput_g;

        /* Saturate: '<S96>/Saturation' */
        if (rtb_L0_C3_k > 50.0F) {
          rtb_L0_C3_k = 50.0F;
        } else {
          if (rtb_L0_C3_k < 0.0F) {
            rtb_L0_C3_k = 0.0F;
          }
        }

        /* End of Saturate: '<S96>/Saturation' */

        /* Switch: '<S96>/Switch' incorporates:
         *  Product: '<S96>/Divide'
         *  Product: '<S96>/Divide1'
         *  Sum: '<S96>/Add'
         *  Sum: '<S96>/Add1'
         *  UnitDelay: '<S96>/Unit Delay'
         */
        if (rtb_L0_C3_k > 1.0F) {
          /* Switch: '<S545>/Switch50' incorporates:
           *  Constant: '<S545>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S545>/Switch50' */
          rtb_L0_C3 = ((rtb_LKA_SampleTime / x10) * (rtb_L0_C3 -
            LKAS_DW.UnitDelay_DSTATE_j)) + LKAS_DW.UnitDelay_DSTATE_j;
        }

        /* End of Switch: '<S96>/Switch' */

        /* SampleTimeMath: '<S99>/TSamp'
         *
         * About '<S99>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_L0_C3 * 100.0F;

        /* Sum: '<S97>/Add2' incorporates:
         *  Constant: '<S97>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S97>/Memory3'
         */
        rtb_LL_HdAgPrvwT_C = 1.0F + LKAS_DW.Memory3_PreviousInput_n;

        /* Saturate: '<S97>/Saturation' */
        if (rtb_LL_HdAgPrvwT_C > 50.0F) {
          rtb_LL_HdAgPrvwT_C = 50.0F;
        } else {
          if (rtb_LL_HdAgPrvwT_C < 0.0F) {
            rtb_LL_HdAgPrvwT_C = 0.0F;
          }
        }

        /* End of Saturate: '<S97>/Saturation' */

        /* Switch: '<S97>/Switch' incorporates:
         *  Product: '<S97>/Divide'
         *  Product: '<S97>/Divide1'
         *  Sum: '<S97>/Add'
         *  Sum: '<S97>/Add1'
         *  Sum: '<S99>/Diff'
         *  UnitDelay: '<S97>/Unit Delay'
         *  UnitDelay: '<S99>/UD'
         *
         * Block description for '<S99>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S99>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_HdAgPrvwT_C > 2.0F) {
          /* Switch: '<S545>/Switch52' incorporates:
           *  Constant: '<S545>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S545>/Switch52' */
          rtb_LL_LKAExPrcs_tiExitTime1 = (((rtb_LL_LKAExPrcs_tiExitTime2 -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_o) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_o;
        } else {
          rtb_LL_LKAExPrcs_tiExitTime1 = rtb_LL_LKAExPrcs_tiExitTime2 -
            LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S97>/Switch' */

        /* Saturate: '<S93>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime1 > 30.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 30.0F;
        } else if (rtb_LL_LKAExPrcs_tiExitTime1 < (-30.0F)) {
          rtb_LL_LDW_LatestWarnLine_C = (-30.0F);
        } else {
          rtb_LL_LDW_LatestWarnLine_C = rtb_LL_LKAExPrcs_tiExitTime1;
        }

        /* End of Saturate: '<S93>/Saturation' */

        /* Switch: '<S545>/Switch53' incorporates:
         *  Constant: '<S545>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S545>/Switch53' */

        /* Sum: '<S98>/Difference Inputs1' incorporates:
         *  Product: '<S93>/Divide1'
         *  Product: '<S93>/Divide3'
         *  Sum: '<S93>/Add'
         *  UnitDelay: '<S98>/Delay Input2'
         *
         * Block description for '<S98>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S98>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_LKASWASyn_TrqSwaAddSwt = (((rtb_LL_LKASWASyn_TrqSwaAddSwt *
          rtb_LL_LDW_LatestWarnLine_C) * x10) + (rtb_LL_LKASWASyn_TrqSwaAddSwt *
          rtb_L0_C3)) - LKAS_DW.DelayInput2_DSTATE_d;

        /* Product: '<S98>/delta rise limit' incorporates:
         *  Constant: '<S93>/Constant1'
         *  SampleTimeMath: '<S98>/sample time'
         *
         * About '<S98>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_LDW_LatestWarnLine_C = 5.0F * 0.01F;

        /* Product: '<S98>/delta fall limit' incorporates:
         *  Constant: '<S93>/Constant2'
         *  SampleTimeMath: '<S98>/sample time'
         *
         * About '<S98>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_Add_pq_tmp = (-5.0F) * 0.01F;

        /* Switch: '<S100>/Switch2' incorporates:
         *  Product: '<S98>/delta fall limit'
         *  Product: '<S98>/delta rise limit'
         *  RelationalOperator: '<S100>/LowerRelop1'
         *  RelationalOperator: '<S100>/UpperRelop'
         *  Switch: '<S100>/Switch'
         */
        if (rtb_LL_LKASWASyn_TrqSwaAddSwt > rtb_LL_LDW_LatestWarnLine_C) {
          rtb_LL_LKASWASyn_TrqSwaAddSwt = rtb_LL_LDW_LatestWarnLine_C;
        } else {
          if (rtb_LL_LKASWASyn_TrqSwaAddSwt < rtb_Add_pq_tmp) {
            /* Switch: '<S100>/Switch' incorporates:
             *  Product: '<S98>/delta fall limit'
             */
            rtb_LL_LKASWASyn_TrqSwaAddSwt = rtb_Add_pq_tmp;
          }
        }

        /* End of Switch: '<S100>/Switch2' */

        /* Sum: '<S98>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S98>/Delay Input2'
         *
         * Block description for '<S98>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S98>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_f = rtb_LL_LKASWASyn_TrqSwaAddSwt +
          LKAS_DW.DelayInput2_DSTATE_d;

        /* Update for UnitDelay: '<S96>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_j = rtb_L0_C3;

        /* Update for Memory: '<S96>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_g = rtb_L0_C3_k;

        /* Update for UnitDelay: '<S99>/UD'
         *
         * Block description for '<S99>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for UnitDelay: '<S97>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_o = rtb_LL_LKAExPrcs_tiExitTime1;

        /* Update for Memory: '<S97>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_n = rtb_LL_HdAgPrvwT_C;

        /* Update for UnitDelay: '<S98>/Delay Input2'
         *
         * Block description for '<S98>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_d = LKAS_DW.DifferenceInputs2_f;
      } else {
        if (LKAS_DW.Subsystem_MODE_mq) {
          /* Disable for Outport: '<S93>/Out1' */
          LKAS_DW.DifferenceInputs2_f = 0.0F;
          LKAS_DW.Subsystem_MODE_mq = false;
        }
      }

      /* End of RelationalOperator: '<S92>/Compare' */
      /* End of Outputs for SubSystem: '<S85>/Subsystem' */

      /* Outputs for Atomic SubSystem: '<S94>/Moving Standard Deviation2' */
      rtb_Yk1_h = (float32) LKAS_MovingStandardDeviation2
        (rtb_IMAPve_g_EPS_SW_Trq, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S94>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S106>/Moving Standard Deviation1' */
      rtb_Gain_n = (float32) LKAS_MovingStandardDeviation2(rtb_Add5_j,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S106>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S106>/Relational Operator6' */
      rtb_RelationalOperator6_g = (rtb_Gain_n <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S106>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_g, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_l, &LKAS_DW.SumCondition1_l);

      /* End of Outputs for SubSystem: '<S106>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S106>/Moving Standard Deviation2' */
      rtb_Gain_n = (float32) LKAS_MovingStandardDeviation2(rtb_Gain1,
        &LKAS_DW.MovingStandardDeviation2_m);

      /* End of Outputs for SubSystem: '<S106>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S106>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain_n <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S106>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_cy, &LKAS_DW.SumCondition_l);

      /* End of Outputs for SubSystem: '<S106>/Sum Condition' */

      /* Switch: '<S545>/Switch46' incorporates:
       *  Constant: '<S545>/LL_LKAExPrcs_ExitC0Swt=1'
       */
      if (LKAS_ConstB.DataTypeConversion35) {
        i = LKAS_ConstB.DataTypeConversion35 ? 1 : 0;
      } else {
        i = LL_LKAExPrcs_ExitC0Swt ? 1 : 0;
      }

      /* End of Switch: '<S545>/Switch46' */

      /* Logic: '<S106>/Logical Operator2' incorporates:
       *  Logic: '<S106>/Logical Operator1'
       *  RelationalOperator: '<S106>/Relational Operator4'
       */
      rtb_Compare_l4 = ((((((rtb_Saturation2_g >= rtb_Saturation6_k) &&
                            rtb_Compare_l4) && rtb_Compare_ckd) &&
                          (LKAS_DW.RelationalOperator_l)) &&
                         (LKAS_DW.RelationalOperator_cy)) && (i != 0));

      /* Fcn: '<S86>/Fcn' incorporates:
       *  DataTypeConversion: '<S86>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((rtb_Compare_l4 ? 1 : 0) *
        (rtb_Compare_l4 ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!rtb_Compare_l4) ? 1 : 0)) * (LKAS_DW.RelationalOperator_mf ? 1 : 0)) *
        ((sint32)2.0F))) + (((sint32)(((!LKAS_DW.RelationalOperator_mf) &&
        (!rtb_Compare_l4)) ? 1 : 0)) * (rtb_LogicalOperator3_b ? 1 : 0))));

      /* Logic: '<S86>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_LogicalOperator3_b ||
        (LKAS_DW.RelationalOperator_mf)) || rtb_Compare_l4);

      /* DataTypeConversion: '<S89>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon_m = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Switch: '<S545>/Switch18' incorporates:
       *  Constant: '<S545>/LL_LKASWASyn_M3K=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion25;
      } else {
        x10 = LL_LKASWASyn_M3K;
      }

      /* End of Switch: '<S545>/Switch18' */

      /* Product: '<S94>/Divide' */
      rtb_Saturation4 = rtb_Yk1_h * x10;

      /* Saturate: '<S94>/Saturation1' */
      if (rtb_Saturation4 > 0.2F) {
        rtb_Saturation4 = 0.2F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S94>/Saturation1' */

      /* Sum: '<S103>/Add2' incorporates:
       *  Memory: '<S103>/Memory3'
       */
      rtb_L0_TLC_i = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_k;

      /* Saturate: '<S103>/Saturation' */
      if (rtb_L0_TLC_i > 50.0F) {
        rtb_Saturation_k = 50.0F;
      } else if (rtb_L0_TLC_i < 0.0F) {
        rtb_Saturation_k = 0.0F;
      } else {
        rtb_Saturation_k = rtb_L0_TLC_i;
      }

      /* End of Saturate: '<S103>/Saturation' */

      /* MATLAB Function: '<S94>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem1/MATLAB Function': '<S101>:1' */
      /* '<S101>:1:2' if T<T1 */
      if (rtb_Saturation_k < rtb_Saturation6_k) {
        /* '<S101>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_R0_C1 += ((rtb_R0_C3 - rtb_R0_C1) / rtb_Saturation6_k) *
          rtb_Saturation_k;
      } else if ((rtb_Saturation_k >= rtb_Saturation6_k) && (rtb_Saturation_k <=
                  (rtb_Saturation6_k + rtb_R0_TLC))) {
        /* Switch: '<S545>/Switch14' incorporates:
         *  Constant: '<S545>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S101>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S101>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_g != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_g;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_R0_C1 = (((x10 - rtb_R0_C3) / rtb_R0_TLC) * (rtb_Saturation_k -
          rtb_Saturation6_k)) + rtb_R0_C3;
      } else {
        /* Switch: '<S545>/Switch14' incorporates:
         *  Constant: '<S545>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S101>:1:6' else */
        /* '<S101>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_g != 0.0F) {
          rtb_R0_C1 = LKAS_ConstB.DataTypeConversion20_g;
        } else {
          rtb_R0_C1 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S94>/MATLAB Function' */

      /* Sum: '<S94>/Add1' */
      rtb_Saturation4 = rtb_R0_C1 - rtb_Saturation4;

      /* Saturate: '<S94>/Saturation2' */
      if (rtb_Saturation4 > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Saturation4 < 0.01F) {
        LKAS_DW.Saturation2 = 0.01F;
      } else {
        LKAS_DW.Saturation2 = rtb_Saturation4;
      }

      /* End of Saturate: '<S94>/Saturation2' */

      /* Memory: '<S195>/Memory3' */
      rtb_Saturation4 = LKAS_DW.Memory3_PreviousInput_e;

      /* Sum: '<S195>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S195>/Saturation' */
      if (rtb_Saturation4 > 50.0F) {
        rtb_Saturation_ns = 50.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation_ns = 0.0F;
      } else {
        rtb_Saturation_ns = rtb_Saturation4;
      }

      /* End of Saturate: '<S195>/Saturation' */

      /* If: '<S193>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       *  Inport: '<S201>/Plan'
       *  Inport: '<S201>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_f;
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_f = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S193>/If Action Subsystem' incorporates:
           *  ActionPort: '<S199>/Action Port'
           */
          /* InitializeConditions for If: '<S193>/If' incorporates:
           *  Memory: '<S199>/Memory'
           *  UnitDelay: '<S203>/Delay Input1'
           *
           * Block description for '<S203>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_p = false;
          LKAS_DW.Memory_PreviousInput_d = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S193>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem' incorporates:
         *  ActionPort: '<S199>/Action Port'
         */
        /* RelationalOperator: '<S202>/Compare' incorporates:
         *  Constant: '<S202>/Constant'
         */
        rtb_LogicalOperator3_b = (rtb_L0_C1_c >= 0.0F);

        /* Memory: '<S199>/Memory' */
        rtb_Plan_d = LKAS_DW.Memory_PreviousInput_d;

        /* Sum: '<S199>/Add' incorporates:
         *  Logic: '<S199>/Logical Operator'
         *  RelationalOperator: '<S199>/Relational Operator'
         *  RelationalOperator: '<S203>/FixPt Relational Operator'
         *  UnitDelay: '<S203>/Delay Input1'
         *
         * Block description for '<S203>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_d = ((float32)(((((sint32)(rtb_LogicalOperator3_b ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_p ? 1 : 0))) &&
          (rtb_Saturation6_k >= rtb_Saturation_ns)) ? 1 : 0)) + rtb_Plan_d;

        /* Saturate: '<S199>/Saturation' */
        if (rtb_T1_d > 5.0F) {
          rtb_Saturation_o = 5.0F;
        } else if (rtb_T1_d < 0.0F) {
          rtb_Saturation_o = 0.0F;
        } else {
          rtb_Saturation_o = rtb_T1_d;
        }

        /* End of Saturate: '<S199>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S199>/If Action Subsystem' */
        LKAS_IfActionSubsystem_m(rtb_Saturation_o, rtb_Saturation_ns,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_b, &LKAS_DW.In_i,
          &LKAS_DW.IfActionSubsystem_mp);

        /* End of Outputs for SubSystem: '<S199>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S199>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_f(rtb_Saturation6_k, rtb_SWACmd_phiSWACmd,
          &rtb_T1_d, &rtb_Plan_d);

        /* End of Outputs for SubSystem: '<S199>/If Action Subsystem2' */

        /* Switch: '<S199>/Switch' incorporates:
         *  Switch: '<S199>/Switch1'
         */
        if (rtb_Saturation_o > 0.0F) {
          LKAS_DW.Merge_l = LKAS_DW.In_b;
          LKAS_DW.Merge1 = LKAS_DW.In_i;
        } else {
          LKAS_DW.Merge_l = rtb_T1_d;
          LKAS_DW.Merge1 = rtb_Plan_d;
        }

        /* End of Switch: '<S199>/Switch' */

        /* Update for UnitDelay: '<S203>/Delay Input1'
         *
         * Block description for '<S203>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_p = rtb_LogicalOperator3_b;

        /* Update for Memory: '<S199>/Memory' */
        LKAS_DW.Memory_PreviousInput_d = rtb_Saturation_o;

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S193>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S200>/Action Port'
           */
          /* InitializeConditions for If: '<S193>/If' incorporates:
           *  Memory: '<S200>/Memory'
           *  UnitDelay: '<S211>/Delay Input1'
           *
           * Block description for '<S211>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_f = false;
          LKAS_DW.Memory_PreviousInput_ek = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S193>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S200>/Action Port'
         */
        /* RelationalOperator: '<S210>/Compare' incorporates:
         *  Constant: '<S210>/Constant'
         */
        rtb_LogicalOperator3_b = (rtb_L0_C1 <= 0.0F);

        /* Memory: '<S200>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_ek;

        /* Sum: '<S200>/Add' incorporates:
         *  Logic: '<S200>/Logical Operator'
         *  RelationalOperator: '<S200>/Relational Operator'
         *  RelationalOperator: '<S211>/FixPt Relational Operator'
         *  UnitDelay: '<S211>/Delay Input1'
         *
         * Block description for '<S211>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_n = ((float32)(((((sint32)(rtb_LogicalOperator3_b ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_f ? 1 : 0))) &&
          (rtb_Saturation6_k >= rtb_Saturation_ns)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S200>/Saturation' */
        if (rtb_T1_n > 5.0F) {
          rtb_Saturation_g3 = 5.0F;
        } else if (rtb_T1_n < 0.0F) {
          rtb_Saturation_g3 = 0.0F;
        } else {
          rtb_Saturation_g3 = rtb_T1_n;
        }

        /* End of Saturate: '<S200>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S200>/If Action Subsystem' */
        LKAS_IfActionSubsystem_m(rtb_Saturation_g3, rtb_Saturation_ns,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_l, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_oc);

        /* End of Outputs for SubSystem: '<S200>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S200>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_f(rtb_Saturation6_k, rtb_SWACmd_phiSWACmd,
          &rtb_T1_n, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S200>/If Action Subsystem2' */

        /* Switch: '<S200>/Switch' incorporates:
         *  Switch: '<S200>/Switch1'
         */
        if (rtb_Saturation_g3 > 0.0F) {
          LKAS_DW.Merge_l = LKAS_DW.In_l;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_l = rtb_T1_n;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S200>/Switch' */

        /* Update for UnitDelay: '<S211>/Delay Input1'
         *
         * Block description for '<S211>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_f = rtb_LogicalOperator3_b;

        /* Update for Memory: '<S200>/Memory' */
        LKAS_DW.Memory_PreviousInput_ek = rtb_Saturation_g3;

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S193>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S201>/Action Port'
         */
        LKAS_DW.Merge_l = rtb_Saturation6_k;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S193>/If' */

      /* Product: '<S91>/Divide3' */
      rtb_Saturation4 = rtb_Saturation_ns / LKAS_DW.Merge_l;

      /* Saturate: '<S91>/Saturation' */
      if (rtb_Saturation4 > 1.0F) {
        rtb_Saturation4 = 1.0F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S91>/Saturation' */

      /* Product: '<S91>/Divide6' */
      rtb_R0_C1 = LKAS_DW.DifferenceInputs2_f * rtb_Saturation4;

      /* Saturate: '<S91>/Saturation6' */
      if (LKAS_DW.Merge_l > 0.5F) {
        rtb_Saturation4 = 0.5F;
      } else if (LKAS_DW.Merge_l < 0.2F) {
        rtb_Saturation4 = 0.2F;
      } else {
        rtb_Saturation4 = LKAS_DW.Merge_l;
      }

      /* End of Saturate: '<S91>/Saturation6' */

      /* Product: '<S91>/Divide' incorporates:
       *  Product: '<S196>/Divide'
       *  Product: '<S91>/Divide4'
       *  Sum: '<S91>/Add2'
       */
      rtb_LftTTLC = (rtb_Saturation_ns - LKAS_DW.Merge_l) / rtb_Saturation4;

      /* Saturate: '<S91>/Saturation2' incorporates:
       *  Product: '<S91>/Divide'
       */
      if (rtb_LftTTLC > 1.0F) {
        rtb_L0_C3 = 1.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_L0_C3 = 0.0F;
      } else {
        rtb_L0_C3 = rtb_LftTTLC;
      }

      /* End of Saturate: '<S91>/Saturation2' */

      /* Sum: '<S180>/Add1' incorporates:
       *  Gain: '<S224>/Gain2'
       *  Memory: '<S180>/Memory'
       *  Product: '<S180>/Divide'
       *  Product: '<S180>/Divide1'
       *  Sum: '<S224>/Add2'
       */
      rtb_Add1_eq = (((rtb_Add_nb + rtb_Add_jr) * 0.5F) * LKAS_ConstB.Divide2_i)
        + (LKAS_ConstB.Add2_ie * LKAS_DW.Memory_PreviousInput_e);

      /* Gain: '<S178>/kph to mps' */
      rtb_kphtomps_j = rtb_LKA_Veh2CamL_C_tmp;

      /* MATLAB Function: '<S178>/Saturable Gain Lut (SatGainLut)' */
      LKAS_SaturableGainLutSatGainLut(rtb_IMAPve_g_ESC_VehSpd,
        rtb_LL_LFClb_TFC_KpVehSpdLwr_C, rtb_LL_LFClb_TFC_KpVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KpV1_C, rtb_LL_LFClb_TFC_KpV2_C, &rtb_Gain_n);

      /* Switch: '<S545>/Switch32' incorporates:
       *  Constant: '<S545>/LL_LFClb_TFC_PrvwT_C=2'
       */
      if (LKAS_ConstB.DataTypeConversion15_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_h;
      } else {
        x10 = LL_LFClb_TFC_PrvwT_C;
      }

      /* End of Switch: '<S545>/Switch32' */

      /* Product: '<S178>/Divide1' */
      rtb_L0_TLC_i = x10 * rtb_kphtomps_j;

      /* Switch: '<S545>/Switch30' incorporates:
       *  Constant: '<S545>/LL_LFClb_TFC_KpKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_g != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_g;
      } else {
        x10 = LL_LFClb_TFC_KpKlat_C;
      }

      /* End of Switch: '<S545>/Switch30' */

      /* Saturate: '<S178>/Saturation' */
      if (rtb_L0_TLC_i > 40.0F) {
        rtb_L0_TLC_i = 40.0F;
      } else {
        if (rtb_L0_TLC_i < 5.0F) {
          rtb_L0_TLC_i = 5.0F;
        }
      }

      /* End of Saturate: '<S178>/Saturation' */

      /* Product: '<S178>/Product4' incorporates:
       *  Gain: '<S223>/Gain1'
       *  Product: '<S178>/Divide'
       *  Product: '<S178>/Product1'
       *  Sum: '<S178>/Subtract1'
       *  Sum: '<S223>/Add1'
       */
      rtb_R0_TLC = (((((rtb_Add_d + rtb_Add_pv) * 0.5F) / rtb_L0_TLC_i) * x10) -
                    rtb_Add1_eq) * rtb_Gain_n;

      /* Switch: '<S545>/Switch19' incorporates:
       *  Constant: '<S545>/LL_LFClb_TFC_Kp_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion26_c != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion26_c;
      } else {
        x10 = LL_LFClb_TFC_Kp_C;
      }

      /* End of Switch: '<S545>/Switch19' */

      /* Product: '<S178>/Product2' */
      rtb_deltafalllimit_c = rtb_R0_TLC * x10;

      /* Saturate: '<S178>/Saturation2' */
      if (rtb_deltafalllimit_c > 360.0F) {
        rtb_deltafalllimit_c = 360.0F;
      } else {
        if (rtb_deltafalllimit_c < (-360.0F)) {
          rtb_deltafalllimit_c = (-360.0F);
        }
      }

      /* End of Saturate: '<S178>/Saturation2' */

      /* Abs: '<S178>/Abs' incorporates:
       *  Gain: '<S222>/Gain1'
       */
      rtb_Yk1_h = fabsf(rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Saturate: '<S178>/Saturation1' */
      rtb_L0_TLC_i = rtb_Yk1_h;
      if (rtb_L0_TLC_i > 0.004F) {
        rtb_Yk1_h = 0.004F;
      } else if (rtb_L0_TLC_i < 1.0E-5F) {
        rtb_Yk1_h = 1.0E-5F;
      } else {
        rtb_Yk1_h = rtb_L0_TLC_i;
      }

      /* End of Saturate: '<S178>/Saturation1' */

      /* Switch: '<S545>/Switch39' incorporates:
       *  Constant: '<S545>/LL_LFClb_TFC_KiMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_KiMaxSWA_C;
      }

      /* End of Switch: '<S545>/Switch39' */

      /* Sum: '<S178>/Add3' incorporates:
       *  Constant: '<S178>/Constant3'
       *  Constant: '<S178>/Constant4'
       *  Product: '<S178>/Divide4'
       *  Sum: '<S178>/Add5'
       */
      rtb_Yk1_h = (((x10 - 1.0F) * rtb_Yk1_h) / 0.004F) + 1.0F;

      /* Sum: '<S186>/Add2' incorporates:
       *  Memory: '<S186>/Memory3'
       */
      rtb_L0_TLC_i = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_c;

      /* Saturate: '<S186>/Saturation' */
      if (rtb_L0_TLC_i > 50.0F) {
        rtb_Saturation_a = 50.0F;
      } else if (rtb_L0_TLC_i < 0.0F) {
        rtb_Saturation_a = 0.0F;
      } else {
        rtb_Saturation_a = rtb_L0_TLC_i;
      }

      /* End of Saturate: '<S186>/Saturation' */

      /* Switch: '<S178>/Switch2' incorporates:
       *  Product: '<S178>/Divide2'
       *  Sum: '<S178>/Add'
       *  Sum: '<S178>/Add2'
       *  Switch: '<S545>/Switch40'
       *  UnitDelay: '<S178>/Unit Delay'
       */
      if ((rtb_Saturation_a - rtb_Saturation6_k) >= 0.0F) {
        /* Switch: '<S545>/Switch40' incorporates:
         *  Constant: '<S545>/LL_LFClb_TFC_Ki_C=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_ly = (rtb_R0_TLC * x10) + LKAS_DW.UnitDelay_DSTATE_k;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S545>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S545>/Switch40' incorporates:
           *  Constant: '<S545>/LL_LFClb_TFC_Ki_C=0.01'
           */
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_ly = rtb_R0_TLC * x10;
      }

      /* End of Switch: '<S178>/Switch2' */

      /* Gain: '<S178>/Gain' */
      rtb_R0_TLC = (-1.0F) * rtb_Yk1_h;

      /* Switch: '<S183>/Switch' incorporates:
       *  RelationalOperator: '<S183>/UpperRelop'
       */
      if (rtb_Switch2_ly < rtb_R0_TLC) {
        rtb_Switch_ku = rtb_R0_TLC;
      } else {
        rtb_Switch_ku = rtb_Switch2_ly;
      }

      /* End of Switch: '<S183>/Switch' */

      /* Switch: '<S183>/Switch2' incorporates:
       *  RelationalOperator: '<S183>/LowerRelop1'
       */
      if (rtb_Switch2_ly > rtb_Yk1_h) {
        rtb_Switch2_d1 = rtb_Yk1_h;
      } else {
        rtb_Switch2_d1 = rtb_Switch_ku;
      }

      /* End of Switch: '<S183>/Switch2' */

      /* Product: '<S91>/Divide1' incorporates:
       *  Sum: '<S91>/Add3'
       */
      rtb_R0_C3 = (rtb_deltafalllimit_c + rtb_Switch2_d1) * rtb_L0_C3;

      /* Switch: '<S545>/Switch49' incorporates:
       *  Constant: '<S545>/LL_LFClb_TFC_KdMaxSWA_C=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_KdMaxSWA_C;
      }

      /* End of Switch: '<S545>/Switch49' */

      /* Product: '<S178>/Divide8' incorporates:
       *  Constant: '<S178>/Constant7'
       *  Constant: '<S178>/Constant8'
       *  Sum: '<S178>/Add4'
       */
      rtb_Yk1_h = ((180.0F - rtb_kphtomps_j) * x10) / 120.0F;

      /* MATLAB Function: '<S178>/Saturable Gain Lut (SatGainLut)1' */
      LKAS_SaturableGainLutSatGainLut(rtb_kphtomps_j,
        rtb_LL_LFClb_TFC_KdVehSpdLwr_C, rtb_LL_LFClb_TFC_KdVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KdV1_C, rtb_LL_LFClb_TFC_KdV2_C, &rtb_Gain_n);

      /* Sum: '<S185>/Add2' */
      rtb_deltafalllimit_c = rtb_L0_C0_c + rtb_Saturation_jn;

      /* Saturate: '<S185>/Saturation' */
      if (rtb_deltafalllimit_c > 2.0F) {
        rtb_deltafalllimit_c = 2.0F;
      } else {
        if (rtb_deltafalllimit_c < (-2.0F)) {
          rtb_deltafalllimit_c = (-2.0F);
        }
      }

      /* End of Saturate: '<S185>/Saturation' */

      /* Switch: '<S545>/Switch9' incorporates:
       *  Constant: '<S545>/LL_LFClb_TFC_KdBalance_C=1.2'
       */
      if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion9;
      } else {
        x10 = LL_LFClb_TFC_KdBalance_C;
      }

      /* End of Switch: '<S545>/Switch9' */

      /* Sum: '<S185>/Add6' */
      rtb_R0_TLC = rtb_Add5_j_tmp - x10;

      /* Product: '<S185>/Divide5' incorporates:
       *  Constant: '<S185>/Constant3'
       *  Product: '<S185>/Divide4'
       *  Sum: '<S185>/Add5'
       */
      rtb_Divide5 = ((rtb_deltafalllimit_c / rtb_R0_TLC) + 1.0F) * rtb_Gain_n;

      /* Product: '<S185>/Divide2' incorporates:
       *  Constant: '<S185>/Constant2'
       *  Product: '<S185>/Divide1'
       *  Sum: '<S185>/Add1'
       *  UnaryMinus: '<S185>/Unary Minus'
       */
      rtb_Divide2_e = (((-rtb_deltafalllimit_c) / rtb_R0_TLC) + 1.0F) *
        rtb_Gain_n;

      /* Sum: '<S190>/Add' incorporates:
       *  Constant: '<S190>/Constant'
       *  Memory: '<S190>/Memory'
       */
      rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_l));

      /* Saturate: '<S190>/Saturation1' */
      if (rtb_Saturation_i3 < ((uint16)10000U)) {
        rtb_Saturation1_id = rtb_Saturation_i3;
      } else {
        rtb_Saturation1_id = ((uint16)10000U);
      }

      /* End of Saturate: '<S190>/Saturation1' */

      /* If: '<S190>/If' incorporates:
       *  Constant: '<S190>/Constant2'
       *  DataTypeConversion: '<S76>/Cast To Single'
       *  Inport: '<S191>/In'
       */
      if (rtb_Saturation1_id == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S190>/if action ' incorporates:
         *  ActionPort: '<S191>/Action Port'
         */
        LKAS_DW.In_g = LKAS_DW.LKASM_stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S190>/if action ' */
      }

      /* End of If: '<S190>/If' */

      /* If: '<S185>/If' incorporates:
       *  Inport: '<S189>/In1'
       */
      if (((sint32)LKAS_DW.In_g) == 1) {
        /* Outputs for IfAction SubSystem: '<S185>/If Action Subsystem' incorporates:
         *  ActionPort: '<S187>/Action Port'
         */
        LKAS_IfActionSubsystem_b(rtb_Divide2_e, &rtb_deltafalllimit_c);

        /* End of Outputs for SubSystem: '<S185>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_g) == 2) {
        /* Outputs for IfAction SubSystem: '<S185>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S188>/Action Port'
         */
        LKAS_IfActionSubsystem_b(rtb_Divide5, &rtb_deltafalllimit_c);

        /* End of Outputs for SubSystem: '<S185>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S185>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S189>/Action Port'
         */
        rtb_deltafalllimit_c = rtb_Gain_n;

        /* End of Outputs for SubSystem: '<S185>/If Action Subsystem2' */
      }

      /* End of If: '<S185>/If' */

      /* Saturate: '<S185>/Saturation1' */
      if (rtb_deltafalllimit_c > 1000.0F) {
        rtb_deltafalllimit_c = 1000.0F;
      } else {
        if (rtb_deltafalllimit_c < 0.0F) {
          rtb_deltafalllimit_c = 0.0F;
        }
      }

      /* End of Saturate: '<S185>/Saturation1' */

      /* Product: '<S178>/Divide7' incorporates:
       *  Gain: '<S178>/Gain2'
       */
      rtb_Divide7 = (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * (-0.5F)) *
        rtb_deltafalllimit_c;

      /* Gain: '<S178>/Gain3' */
      rtb_deltafalllimit_c = (-1.0F) * rtb_Yk1_h;

      /* Switch: '<S184>/Switch' incorporates:
       *  RelationalOperator: '<S184>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_deltafalllimit_c) {
        rtb_Switch_j0 = rtb_deltafalllimit_c;
      } else {
        rtb_Switch_j0 = rtb_Divide7;
      }

      /* End of Switch: '<S184>/Switch' */

      /* Switch: '<S184>/Switch2' incorporates:
       *  RelationalOperator: '<S184>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_Yk1_h) {
        rtb_Switch2_ke = rtb_Yk1_h;
      } else {
        rtb_Switch2_ke = rtb_Switch_j0;
      }

      /* End of Switch: '<S184>/Switch2' */

      /* Product: '<S91>/Divide4' */
      rtb_Yk1_h = rtb_LftTTLC;

      /* Saturate: '<S91>/Saturation1' */
      rtb_L0_TLC_i = rtb_Yk1_h;
      if (rtb_L0_TLC_i > 1.0F) {
        rtb_Yk1_h = 1.0F;
      } else if (rtb_L0_TLC_i < 0.0F) {
        rtb_Yk1_h = 0.0F;
      } else {
        rtb_Yk1_h = rtb_L0_TLC_i;
      }

      /* End of Saturate: '<S91>/Saturation1' */

      /* Product: '<S91>/Divide2' */
      rtb_L0_C0_c = rtb_Switch2_ke * rtb_Yk1_h;

      /* Product: '<S196>/Divide' */
      rtb_Saturation4 = rtb_LftTTLC;

      /* Saturate: '<S196>/Saturation4' */
      if (rtb_Saturation4 > 1.0F) {
        rtb_Saturation4 = 1.0F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S196>/Saturation4' */

      /* Gain: '<S179>/kph to mps' */
      rtb_Yk1_h = rtb_LKA_Veh2CamL_C_tmp;

      /* Saturate: '<S179>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        rtb_deltafalllimit_c = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        rtb_deltafalllimit_c = 60.0F;
      } else {
        rtb_deltafalllimit_c = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S179>/Saturation3' */

      /* Product: '<S179>/Divide2' incorporates:
       *  Constant: '<S179>/Constant'
       */
      rtb_deltafalllimit_c = 0.09F / rtb_deltafalllimit_c;

      /* Saturate: '<S179>/Saturation1' */
      if (rtb_deltafalllimit_c > 0.01F) {
        rtb_deltafalllimit_c = 0.01F;
      } else {
        if (rtb_deltafalllimit_c < 0.0F) {
          rtb_deltafalllimit_c = 0.0F;
        }
      }

      /* End of Saturate: '<S179>/Saturation1' */

      /* Switch: '<S545>/Switch36' incorporates:
       *  Constant: '<S545>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_d != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_d;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S545>/Switch36' */

      /* Gain: '<S179>/Gain2' incorporates:
       *  Constant: '<S179>/Constant1'
       *  Gain: '<S179>/rad to deg'
       *  Gain: '<S222>/Gain1'
       *  Math: '<S179>/Math Function'
       *  Product: '<S179>/Divide'
       *  Product: '<S179>/Divide1'
       *  Product: '<S179>/Product'
       *  Product: '<S179>/Product1'
       *  Product: '<S179>/Product2'
       *  Product: '<S179>/Product3'
       *  Sum: '<S179>/Add'
       *
       * About '<S179>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_Yk1_h = (((((((rtb_Yk1_h * rtb_Yk1_h) * rtb_deltafalllimit_c) + 1.0F) /
                      (rtb_Yk1_h / LKAS_DW.LKA_WhlBaseL_C_k)) * ((rtb_Yk1_h *
        rtb_LL_ThresDet_tiTTLCThresLDW) * 57.2957802F)) * x10) *
                   LKAS_DW.LKA_StrRatio_C_g) * (-1.0F);

      /* Product: '<S91>/Divide5' incorporates:
       *  Constant: '<S196>/Constant1'
       *  Product: '<S196>/Divide8'
       *  Sum: '<S196>/Add1'
       */
      rtb_deltafalllimit_c = ((LKAS_ConstB.Add3 * rtb_Saturation4) + 0.0F) *
        rtb_Yk1_h;

      /* Sum: '<S91>/Add4' incorporates:
       *  Constant: '<S91>/Constant2'
       *  Product: '<S91>/Divide7'
       *  Sum: '<S91>/Add5'
       */
      rtb_L0_C0_c = (((((1.0F - rtb_L0_C3) * LKAS_DW.Merge1) + rtb_R0_C3) +
                      rtb_L0_C0_c) + rtb_deltafalllimit_c) + rtb_R0_C1;

      /* Memory: '<S194>/Memory3' */
      rtb_deltafalllimit_c = LKAS_DW.Memory3_PreviousInput_h;

      /* Sum: '<S194>/Add2' incorporates:
       *  Constant: '<S194>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_deltafalllimit_c += 1.0F;

      /* Saturate: '<S194>/Saturation' */
      if (rtb_deltafalllimit_c > 50.0F) {
        rtb_Saturation_kf = 50.0F;
      } else if (rtb_deltafalllimit_c < 0.0F) {
        rtb_Saturation_kf = 0.0F;
      } else {
        rtb_Saturation_kf = rtb_deltafalllimit_c;
      }

      /* End of Saturate: '<S194>/Saturation' */

      /* Switch: '<S194>/Switch' incorporates:
       *  Constant: '<S91>/Constant1'
       *  Product: '<S194>/Divide'
       *  Product: '<S194>/Divide1'
       *  Sum: '<S194>/Add'
       *  Sum: '<S194>/Add1'
       *  UnitDelay: '<S194>/Unit Delay'
       */
      if (rtb_Saturation_kf > 30.0F) {
        rtb_Switch_js = ((rtb_LKA_SampleTime / 0.1F) * (rtb_L0_C0_c -
          LKAS_DW.UnitDelay_DSTATE_m)) + LKAS_DW.UnitDelay_DSTATE_m;
      } else {
        rtb_Switch_js = rtb_L0_C0_c;
      }

      /* End of Switch: '<S194>/Switch' */

      /* Switch: '<S545>/Switch17' incorporates:
       *  Constant: '<S545>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S545>/Switch17' */

      /* Sum: '<S88>/Add' */
      rtb_Add_mb = (rtb_Switch_js - x10) + LKAS_DW.Saturation_k;

      /* Sum: '<S88>/Add1' */
      rtb_deltafalllimit_c = rtb_Yk1_h + rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S88>/Add2' incorporates:
       *  Gain: '<S88>/Gain2'
       */
      rtb_Yk1_h += (-1.0F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S174>/Switch' incorporates:
       *  RelationalOperator: '<S174>/UpperRelop'
       */
      if (rtb_Add_mb < rtb_Yk1_h) {
        rtb_Switch_m = rtb_Yk1_h;
      } else {
        rtb_Switch_m = rtb_Add_mb;
      }

      /* End of Switch: '<S174>/Switch' */

      /* Switch: '<S174>/Switch2' incorporates:
       *  RelationalOperator: '<S174>/LowerRelop1'
       */
      if (rtb_Add_mb > rtb_deltafalllimit_c) {
        rtb_Switch2_i = rtb_deltafalllimit_c;
      } else {
        rtb_Switch2_i = rtb_Switch_m;
      }

      /* End of Switch: '<S174>/Switch2' */

      /* Sum: '<S173>/Add1' incorporates:
       *  Constant: '<S173>/Constant'
       *  Memory: '<S173>/Memory'
       */
      rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_e1));

      /* Switch: '<S173>/Switch' incorporates:
       *  Constant: '<S173>/LatchTime_SY'
       *  RelationalOperator: '<S173>/Relational Operator'
       *  UnitDelay: '<S173>/Delay Input2'
       *
       * Block description for '<S173>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_i3 <= ((uint16)1U)) {
        rtb_Yk1_h = rtb_Switch2_i;
      } else {
        rtb_Yk1_h = LKAS_DW.DelayInput2_DSTATE_g;
      }

      /* End of Switch: '<S173>/Switch' */

      /* Sum: '<S173>/Difference Inputs1'
       *
       * Block description for '<S173>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_k = rtb_Switch2_i - rtb_Yk1_h;

      /* SampleTimeMath: '<S173>/sample time'
       *
       * About '<S173>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_deltafalllimit_c = 0.01F;

      /* Product: '<S173>/delta rise limit' incorporates:
       *  Gain: '<S88>/Gain3'
       */
      rtb_R0_TLC = (1.4F * LKAS_DW.SWARmax) * rtb_deltafalllimit_c;

      /* Product: '<S173>/delta fall limit' incorporates:
       *  Gain: '<S88>/Gain1'
       */
      rtb_deltafalllimit_c *= (-1.4F) * LKAS_DW.SWARmax;

      /* Switch: '<S175>/Switch' incorporates:
       *  RelationalOperator: '<S175>/UpperRelop'
       */
      if (rtb_UkYk1_k < rtb_deltafalllimit_c) {
        rtb_Switch_b1f = rtb_deltafalllimit_c;
      } else {
        rtb_Switch_b1f = rtb_UkYk1_k;
      }

      /* End of Switch: '<S175>/Switch' */

      /* Switch: '<S175>/Switch2' incorporates:
       *  RelationalOperator: '<S175>/LowerRelop1'
       */
      if (rtb_UkYk1_k > rtb_R0_TLC) {
        rtb_Switch2_i1 = rtb_R0_TLC;
      } else {
        rtb_Switch2_i1 = rtb_Switch_b1f;
      }

      /* End of Switch: '<S175>/Switch2' */

      /* Sum: '<S173>/Difference Inputs2'
       *
       * Block description for '<S173>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_i1 + rtb_Yk1_h;

      /* Saturate: '<S173>/Saturation2' */
      if (rtb_Saturation_i3 < ((uint16)10000U)) {
        rtb_Saturation2_m = rtb_Saturation_i3;
      } else {
        rtb_Saturation2_m = ((uint16)10000U);
      }

      /* End of Saturate: '<S173>/Saturation2' */

      /* DataTypeConversion: '<S89>/CastLKA3' */
      LKAS_DW.T1_Mon_b = LKAS_DW.Merge_l;

      /* DataTypeConversion: '<S113>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_IMAPve_g_ESC_VehSpd;

      /* DataTypeConversion: '<S89>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon_e = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S87>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S105>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_p2) {
          /* Disable for Outport: '<S107>/Out' */
          LKAS_DW.RelationalOperator_mf = false;
          LKAS_DW.SumCondition1_MODE_p2 = false;
        }

        /* End of Disable for SubSystem: '<S105>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S85>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_mq) {
          /* Disable for Outport: '<S93>/Out1' */
          LKAS_DW.DifferenceInputs2_f = 0.0F;
          LKAS_DW.Subsystem_MODE_mq = false;
        }

        /* End of Disable for SubSystem: '<S85>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S106>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_l.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_l,
            &LKAS_DW.SumCondition1_l);
        }

        /* End of Disable for SubSystem: '<S106>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S106>/Sum Condition' */
        if (LKAS_DW.SumCondition_l.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_cy,
            &LKAS_DW.SumCondition_l);
        }

        /* End of Disable for SubSystem: '<S106>/Sum Condition' */

        /* Disable for If: '<S193>/If' */
        LKAS_DW.If_ActiveSubsystem_f = -1;

        /* Disable for Outport: '<S76>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S76>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S76>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S76>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_m = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_e = 0.0F;
        LKAS_DW.T1_Mon_b = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon_m;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon_e;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.T1_Mon = LKAS_DW.T1_Mon_b;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_State_Mon = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LDW_State_Mon = LKAS_DW.LDWSM_stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.LDWSM_stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S75>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S80>/If' */
      if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S80>/If Action Subsystem' incorporates:
         *  ActionPort: '<S81>/Action Port'
         */
        /* Gain: '<S81>/rad to deg' incorporates:
         *  Gain: '<S81>/Gain'
         */
        LKAS_DW.Merge_f = ((-1.0F) * rtb_L0_C1_c) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S80>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S80>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S82>/Action Port'
         */
        /* Gain: '<S82>/rad to deg' */
        LKAS_DW.Merge_f = 57.2957802F * rtb_L0_C1;

        /* End of Outputs for SubSystem: '<S80>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S80>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S83>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_f);

        /* End of Outputs for SubSystem: '<S80>/If Action Subsystem2' */
      }

      /* End of If: '<S80>/If' */

      /* Switch: '<S544>/Switch2' incorporates:
       *  Constant: '<S544>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_n != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_n;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S544>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S80>/Sum Condition' incorporates:
       *  EnablePort: '<S84>/Enable'
       */
      /* RelationalOperator: '<S80>/Relational Operator' */
      if (LKAS_DW.Merge_f >= x10) {
        if (!LKAS_DW.SumCondition_MODE_e) {
          /* InitializeConditions for Memory: '<S84>/Memory' */
          LKAS_DW.Memory_PreviousInput_bo = 0.0F;
          LKAS_DW.SumCondition_MODE_e = true;
        }

        /* Sum: '<S84>/Add1' incorporates:
         *  Memory: '<S84>/Memory'
         */
        rtb_L0_C1 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_bo;

        /* Saturate: '<S84>/Saturation' */
        if (rtb_L0_C1 > 0.6F) {
          rtb_L0_C1 = 0.6F;
        } else {
          if (rtb_L0_C1 < 0.0F) {
            rtb_L0_C1 = 0.0F;
          }
        }

        /* End of Saturate: '<S84>/Saturation' */

        /* RelationalOperator: '<S84>/Relational Operator' incorporates:
         *  Constant: '<S80>/Constant'
         */
        LKAS_DW.RelationalOperator_i = (rtb_L0_C1 >= 0.05F);

        /* Update for Memory: '<S84>/Memory' */
        LKAS_DW.Memory_PreviousInput_bo = rtb_L0_C1;
      } else {
        if (LKAS_DW.SumCondition_MODE_e) {
          /* Disable for Outport: '<S84>/Out' */
          LKAS_DW.RelationalOperator_i = false;
          LKAS_DW.SumCondition_MODE_e = false;
        }
      }

      /* End of RelationalOperator: '<S80>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S80>/Sum Condition' */

      /* Product: '<S75>/Product' incorporates:
       *  Logic: '<S75>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.LDWSM_stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_i) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S80>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_e) {
          /* Disable for Outport: '<S84>/Out' */
          LKAS_DW.RelationalOperator_i = false;
          LKAS_DW.SumCondition_MODE_e = false;
        }

        /* End of Disable for SubSystem: '<S80>/Sum Condition' */

        /* Disable for Outport: '<S75>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* SignalConversion: '<S454>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S364>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LogicalOperator_ps;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_Compare_hv;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_Compare_og;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_lz;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_gn;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_f;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_a2p;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_fh;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_nj;
    rtb_TmpSignalConversionAtSFunct[12] = LKAS_DW.RelationalOperator_mx;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_stDvrTkConFlg_i;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_i3;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator_k;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_LogicalOperator3_np;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' incorporates:
     *  MATLAB Function: '<S364>/Disable Reason'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S454>:1' */
    /* '<S454>:1:2' y = single(0); */
    LKAS_DW.Disable_Reason = 0.0F;

    /* MATLAB Function: '<S364>/Disable Reason' */
    /* '<S454>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S454>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S454>:1:5' y = single(i); */
        LKAS_DW.Disable_Reason = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LFTTTLC_Mon = rtb_LFTTTLC;

    /* Logic: '<S486>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S486>/Relational Operator3'
     *  RelationalOperator: '<S486>/Relational Operator4'
     */
    rtb_LogicalOperator1_ht = ((rtb_Gain1 <= rtb_R0_C2) || (rtb_Add5_j <=
      rtb_R0_C2));

    /* Gain: '<S219>/Gain' incorporates:
     *  Sum: '<S219>/Add'
     */
    rtb_lDvt = (rtb_Gain1 + rtb_Add5_j) * 0.5F;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.DACMode = LKAS_DW.Divide;

    /* Gain: '<S218>/Gain' incorporates:
     *  Sum: '<S218>/Add'
     */
    rtb_crCrvt = (rtb_L0_C2_c + rtb_L0_C2) * 0.5F;

    /* Delay: '<S78>/Delay1' */
    rtb_DACMode = LKAS_DW.Delay1_2_DSTATE;

    /* RelationalOperator: '<S521>/Compare' incorporates:
     *  Constant: '<S521>/Constant'
     *  Constant: '<S553>/Constant14'
     */
    rtb_Compare_mw = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S530>/Compare' incorporates:
     *  Constant: '<S530>/Constant'
     *  Constant: '<S553>/Constant11'
     */
    rtb_Compare_eh = (((uint8)0U) == ((uint8)1U));
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S372>/Count 20s' */
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S380>/Out' */
        LKAS_DW.RelationalOperator_nj = false;
        LKAS_DW.Count20s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S372>/Count 20s' */

      /* Disable for Enabled SubSystem: '<S373>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_p) {
        /* Disable for Outport: '<S382>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_p = false;
      }

      /* End of Disable for SubSystem: '<S373>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S383>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_a) {
        /* Disable for Outport: '<S389>/Out' */
        LKAS_DW.RelationalOperator_mx = false;
        LKAS_DW.SumCondition1_MODE_a = false;
      }

      /* End of Disable for SubSystem: '<S383>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S395>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S402>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S395>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S311>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S342>/Out' */
        LKAS_DW.RelationalOperator_d = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S311>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S311>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S341>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S311>/Count' */

      /* Disable for Enabled SubSystem: '<S344>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_g) {
        /* Disable for Outport: '<S350>/Out' */
        LKAS_DW.RelationalOperator_b = false;
        LKAS_DW.SumCondition1_MODE_g = false;
      }

      /* End of Disable for SubSystem: '<S344>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S312>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S356>/Out' */
        LKAS_DW.RelationalOperator_nl = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }

      /* End of Disable for SubSystem: '<S312>/Sum Condition1' */

      /* Disable for If: '<S359>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S322>/Sum Condition' */
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S328>/Out' */
        LKAS_DW.RelationalOperator_j = false;
        LKAS_DW.SumCondition_MODE = false;
      }

      /* End of Disable for SubSystem: '<S322>/Sum Condition' */

      /* Disable for Enabled SubSystem: '<S270>/Count_5s3' */
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S535>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }

      /* End of Disable for SubSystem: '<S270>/Count_5s3' */

      /* Disable for Enabled SubSystem: '<S270>/Count_5s2' */
      if (LKAS_DW.Count_5s2.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_m, &LKAS_DW.Count_5s2);
      }

      /* End of Disable for SubSystem: '<S270>/Count_5s2' */

      /* Disable for Enabled SubSystem: '<S270>/Count_5s1' */
      if (LKAS_DW.Count_5s1.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_n, &LKAS_DW.Count_5s1);
      }

      /* End of Disable for SubSystem: '<S270>/Count_5s1' */

      /* Disable for Enabled SubSystem: '<S247>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_m) {
        /* Disable for Outport: '<S251>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.Subsystem_MODE_m = false;
      }

      /* End of Disable for SubSystem: '<S247>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S87>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S105>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_p2) {
          /* Disable for Outport: '<S107>/Out' */
          LKAS_DW.RelationalOperator_mf = false;
          LKAS_DW.SumCondition1_MODE_p2 = false;
        }

        /* End of Disable for SubSystem: '<S105>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S85>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_mq) {
          /* Disable for Outport: '<S93>/Out1' */
          LKAS_DW.DifferenceInputs2_f = 0.0F;
          LKAS_DW.Subsystem_MODE_mq = false;
        }

        /* End of Disable for SubSystem: '<S85>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S106>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_l.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_l,
            &LKAS_DW.SumCondition1_l);
        }

        /* End of Disable for SubSystem: '<S106>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S106>/Sum Condition' */
        if (LKAS_DW.SumCondition_l.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_cy,
            &LKAS_DW.SumCondition_l);
        }

        /* End of Disable for SubSystem: '<S106>/Sum Condition' */

        /* Disable for If: '<S193>/If' */
        LKAS_DW.If_ActiveSubsystem_f = -1;

        /* Disable for Outport: '<S76>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S76>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S76>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S76>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_m = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_e = 0.0F;
        LKAS_DW.T1_Mon_b = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S80>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_e) {
          /* Disable for Outport: '<S84>/Out' */
          LKAS_DW.RelationalOperator_i = false;
          LKAS_DW.SumCondition_MODE_e = false;
        }

        /* End of Disable for SubSystem: '<S80>/Sum Condition' */

        /* Disable for Outport: '<S75>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.DACMode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
   *  Constant: '<S11>/Constant'
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S11>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
    break;

   case 1:
    rtb_EPS_LKA_Control = (UInt8)((uint8)1U);
    break;

   case 2:
    rtb_EPS_LKA_Control = (UInt8)((uint8)2U);
    break;

   case 3:
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
    break;

   case 4:
    rtb_EPS_LKA_Control = (UInt8)((uint8)4U);
    break;

   case 5:
    rtb_EPS_LKA_Control = (UInt8)((uint8)4U);
    break;

   default:
    rtb_EPS_LKA_Control = (UInt8)((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S11>/Multiport Switch' */

  /* RelationalOperator: '<S537>/Compare' incorporates:
   *  Constant: '<S537>/Constant'
   */
  rtb_LogicalOperator_ps = (rtb_EPS_LKA_Control == ((UInt8)((uint8)4U)));

  /* Switch: '<S11>/Switch1' incorporates:
   *  Constant: '<S11>/1'
   *  Constant: '<S11>/x0'
   */
  if (rtb_LogicalOperator_ps) {
    rtb_IMAPve_d_BCM_HazardLamp = ((uint8)1U);
  } else {
    rtb_IMAPve_d_BCM_HazardLamp = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S536>/Subsystem' incorporates:
   *  EnablePort: '<S541>/Enable'
   */
  if (((sint32)rtb_IMAPve_d_BCM_HazardLamp) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S541>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S541>/Add' */
    rtb_L0_C2 = LKAS_DW.OutputSWACmd - rtb_IMAPve_g_SW_Angle;

    /* Sum: '<S541>/Add1' incorporates:
     *  Constant: '<S541>/Ki'
     *  Delay: '<S541>/Delay1'
     *  Product: '<S541>/Product2'
     */
    rtb_L0_C2_c = (rtb_L0_C2 * 0.0005F) + LKAS_DW.Delay1_DSTATE;

    /* Saturate: '<S541>/Saturation' */
    if (rtb_L0_C2_c > 0.5F) {
      rtb_L0_C2_c = 0.5F;
    } else {
      if (rtb_L0_C2_c < (-0.5F)) {
        rtb_L0_C2_c = (-0.5F);
      }
    }

    /* End of Saturate: '<S541>/Saturation' */

    /* Fcn: '<S541>/Fcn' */
    rtb_R0_C2 = LKAS_DW.OutputSWACmd * LKAS_DW.OutputSWACmd;

    /* Sum: '<S541>/Add2' incorporates:
     *  Constant: '<S541>/Kp'
     *  Fcn: '<S541>/Fcn'
     *  Product: '<S541>/Product1'
     */
    LKAS_DW.in_trq = (((((rtb_R0_C2 * LKAS_DW.OutputSWACmd) * 2.0e-6F) +
                        (rtb_R0_C2 * -0.0005F)) + (LKAS_DW.OutputSWACmd *
      0.0505F)) + (rtb_L0_C2 * 0.02F)) + rtb_L0_C2_c;

    /* Update for Delay: '<S541>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_L0_C2_c;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S541>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S536>/Subsystem' */

  /* Sum: '<S539>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S539>/Delay Input2'
   *
   * Block description for '<S539>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S539>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S539>/delta rise limit' incorporates:
   *  Constant: '<S536>/Constant'
   *  SampleTimeMath: '<S539>/sample time'
   *
   * About '<S539>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C2_c = 5.0F * 0.01F;

  /* Product: '<S539>/delta fall limit' incorporates:
   *  Constant: '<S536>/Constant1'
   *  SampleTimeMath: '<S539>/sample time'
   *
   * About '<S539>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C1 = (-5.0F) * 0.01F;

  /* Switch: '<S542>/Switch2' incorporates:
   *  Product: '<S539>/delta fall limit'
   *  Product: '<S539>/delta rise limit'
   *  RelationalOperator: '<S542>/LowerRelop1'
   *  RelationalOperator: '<S542>/UpperRelop'
   *  Switch: '<S542>/Switch'
   */
  if (rtb_L0_C2 > rtb_L0_C2_c) {
    rtb_L0_C2 = rtb_L0_C2_c;
  } else {
    if (rtb_L0_C2 < rtb_L0_C1) {
      /* Switch: '<S542>/Switch' incorporates:
       *  Product: '<S539>/delta fall limit'
       */
      rtb_L0_C2 = rtb_L0_C1;
    }
  }

  /* End of Switch: '<S542>/Switch2' */

  /* Sum: '<S539>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S539>/Delay Input2'
   *
   * Block description for '<S539>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S539>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 += LKAS_DW.DelayInput2_DSTATE;

  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_EPS_State_Control_1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control
    (rtb_EPS_LKA_Control);

  /* Switch: '<S32>/Switch' incorporates:
   *  Constant: '<S32>/Constant'
   *  Constant: '<S32>/Constant1'
   *  Constant: '<S34>/Constant'
   *  RelationalOperator: '<S34>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_L0_TLC = 0.5F;
  } else {
    rtb_L0_TLC = 0.25F;
  }

  /* End of Switch: '<S32>/Switch' */

  /* Logic: '<S32>/Logical Operator2' incorporates:
   *  Abs: '<S32>/Abs'
   *  Constant: '<S35>/Constant'
   *  Constant: '<S36>/Constant'
   *  Constant: '<S37>/Constant'
   *  Constant: '<S38>/Constant'
   *  Constant: '<S39>/Constant'
   *  Constant: '<S40>/Constant'
   *  Constant: '<S41>/Constant'
   *  Constant: '<S42>/Constant'
   *  Logic: '<S32>/Logical Operator1'
   *  Logic: '<S32>/Logical Operator3'
   *  RelationalOperator: '<S32>/Relational Operator'
   *  RelationalOperator: '<S35>/Compare'
   *  RelationalOperator: '<S36>/Compare'
   *  RelationalOperator: '<S37>/Compare'
   *  RelationalOperator: '<S38>/Compare'
   *  RelationalOperator: '<S39>/Compare'
   *  RelationalOperator: '<S40>/Compare'
   *  RelationalOperator: '<S41>/Compare'
   *  RelationalOperator: '<S42>/Compare'
   */
  rtb_Compare_hv = ((((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
                        (LKAS_DW.LKA_State == ((uint8)5U))) ||
                       (LKAS_DW.LKA_State == ((uint8)4U))) || (LKAS_DW.LKA_State
    == ((uint8)3U))) && ((rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) ||
    (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)))) && (fabsf
    (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_L0_TLC));

  /* Outputs for Enabled SubSystem: '<S32>/Count 10s' incorporates:
   *  EnablePort: '<S43>/Enable'
   */
  if (rtb_Compare_hv) {
    if (!LKAS_DW.Count10s_MODE) {
      /* InitializeConditions for Memory: '<S43>/Memory' */
      LKAS_DW.Memory_PreviousInput_jm = ((uint16)0U);
      LKAS_DW.Count10s_MODE = true;
    }

    /* Sum: '<S43>/Add' incorporates:
     *  Constant: '<S43>/Constant'
     *  Memory: '<S43>/Memory'
     */
    rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      LKAS_DW.Memory_PreviousInput_jm));

    /* Saturate: '<S43>/Saturation' */
    if (rtb_Saturation_i3 >= ((uint16)2100U)) {
      rtb_Saturation_i3 = ((uint16)2100U);
    }

    /* End of Saturate: '<S43>/Saturation' */

    /* RelationalOperator: '<S45>/Compare' incorporates:
     *  Constant: '<S45>/Constant'
     */
    LKAS_DW.Compare_p = (rtb_Saturation_i3 >= ((uint16)1000U));

    /* Update for Memory: '<S43>/Memory' */
    LKAS_DW.Memory_PreviousInput_jm = rtb_Saturation_i3;
  } else {
    if (LKAS_DW.Count10s_MODE) {
      /* Disable for Outport: '<S43>/Out' */
      LKAS_DW.Compare_p = false;
      LKAS_DW.Count10s_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S32>/Count 10s' */

  /* MATLAB Function: '<S8>/HMI_Popup_Status' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S26>:1' */
  /* '<S26>:1:2' if stDACmode==2&&LKA_STATE==6 */
  if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) == 6)) {
    /* �������ָ������� */
    /* '<S26>:1:3' HMI_Popup_Status=uint8(6); */
    rtb_IMAPve_d_Camera_Status = 6U;
  } else if (((((sint32)LKAS_DW.Divide) == 2) || (((sint32)LKAS_DW.Divide) == 1))
             && (((sint32)rtb_IMAPve_d_Camera_Status) == 5)) {
    /* '<S26>:1:6' elseif (stDACmode==2||stDACmode==1)&&(Front_Camera_Blocked==5) */
    /* ����ͷ���ڵ� */
    /* '<S26>:1:7' HMI_Popup_Status=uint8(4); */
    rtb_IMAPve_d_Camera_Status = 4U;
  } else if (((((sint32)LKAS_DW.Divide) == 2) || (((sint32)LKAS_DW.Divide) == 1))
             && (LKAS_DW.Compare_p)) {
    /* '<S26>:1:8' elseif (stDACmode==2||stDACmode==1)&&HandsOff==1 */
    /* ���շ����� */
    /* '<S26>:1:9' HMI_Popup_Status=uint8(2); */
    rtb_IMAPve_d_Camera_Status = 2U;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              2)) {
    /* '<S26>:1:10' elseif stDACmode==2&&(LKA_STATE==2) */
    /* '<S26>:1:11' HMI_Popup_Status=uint8(1); */
    rtb_IMAPve_d_Camera_Status = 1U;
  } else if (((sint32)LKAS_DW.Divide) != 2) {
    /* '<S26>:1:12' elseif stDACmode~=2&&stFaultCSyn==0 */
    /* '<S26>:1:13' HMI_Popup_Status=uint8(8); */
    rtb_IMAPve_d_Camera_Status = 8U;
  } else {
    /* '<S26>:1:14' elseif stFaultCSyn==0 */
    /* '<S26>:1:15' HMI_Popup_Status=uint8(7); */
    rtb_IMAPve_d_Camera_Status = 7U;
  }

  /* End of MATLAB Function: '<S8>/HMI_Popup_Status' */

  /* Outputs for Enabled SubSystem: '<S32>/Count 15s' incorporates:
   *  EnablePort: '<S44>/Enable'
   */
  if (rtb_Compare_hv) {
    if (!LKAS_DW.Count15s_MODE) {
      /* InitializeConditions for Memory: '<S44>/Memory' */
      LKAS_DW.Memory_PreviousInput_hl = ((uint16)0U);
      LKAS_DW.Count15s_MODE = true;
    }

    /* Sum: '<S44>/Add' incorporates:
     *  Constant: '<S44>/Constant'
     *  Memory: '<S44>/Memory'
     */
    rtb_Saturation_i3 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      LKAS_DW.Memory_PreviousInput_hl));

    /* Saturate: '<S44>/Saturation' */
    if (rtb_Saturation_i3 >= ((uint16)2100U)) {
      rtb_Saturation_i3 = ((uint16)2100U);
    }

    /* End of Saturate: '<S44>/Saturation' */

    /* RelationalOperator: '<S46>/Compare' incorporates:
     *  Constant: '<S46>/Constant'
     */
    LKAS_DW.Compare = (rtb_Saturation_i3 >= ((uint16)1500U));

    /* Update for Memory: '<S44>/Memory' */
    LKAS_DW.Memory_PreviousInput_hl = rtb_Saturation_i3;
  } else {
    if (LKAS_DW.Count15s_MODE) {
      /* Disable for Outport: '<S44>/Out' */
      LKAS_DW.Compare = false;
      LKAS_DW.Count15s_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S32>/Count 15s' */

  /* MATLAB Function: '<S8>/Hands_Off_Warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_Off_Warning': '<S27>:1' */
  /* '<S27>:1:2' if HandsOff==0 */
  if (!LKAS_DW.Compare) {
    /* '<S27>:1:3' Hands_Off_Warning= uint8(0); */
    rtb_IMAPve_d_BCM_Left_Light = 0U;
  } else {
    /* '<S27>:1:4' elseif HandsOff==1 */
    /* '<S27>:1:5' Hands_Off_Warning= uint8(1); */
    rtb_IMAPve_d_BCM_Left_Light = 1U;
  }

  /* End of MATLAB Function: '<S8>/Hands_Off_Warning' */

  /* MATLAB Function: '<S8>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S28>:1' */
  /* '<S28>:1:2' if HMI_stDACmode==1 */
  switch (LKAS_DW.Divide) {
   case 1:
    /* '<S28>:1:3' if HMI_LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S28>:1:4' LDW_Flag=uint8(1); */
      rtb_IMAPve_d_BCM_Right_Light = 1U;
      break;

     case 2:
      /* '<S28>:1:5' elseif HMI_LDWWarnInfo==2 */
      /* '<S28>:1:6' LDW_Flag=uint8(2); */
      rtb_IMAPve_d_BCM_Right_Light = 2U;
      break;

     default:
      /* '<S28>:1:7' else */
      /* '<S28>:1:8' LDW_Flag=uint8(0); */
      rtb_IMAPve_d_BCM_Right_Light = 0U;
      break;
    }
    break;

   case 2:
    /* '<S28>:1:10' elseif HMI_stDACmode==2 */
    /* '<S28>:1:11' if HMI_LDWWarnInfo==1 && HMI_LKA_STATE==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S28>:1:12' LDW_Flag=uint8(1); */
      rtb_IMAPve_d_BCM_Right_Light = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S28>:1:13' elseif HMI_LDWWarnInfo==2 && HMI_LKA_STATE==5 */
      /* '<S28>:1:14' LDW_Flag=uint8(2); */
      rtb_IMAPve_d_BCM_Right_Light = 2U;
    } else {
      /* '<S28>:1:15' else */
      /* '<S28>:1:16' LDW_Flag=uint8(0); */
      rtb_IMAPve_d_BCM_Right_Light = 0U;
    }
    break;

   default:
    /* '<S28>:1:18' else */
    /* '<S28>:1:19' LDW_Flag=uint8(0); */
    rtb_IMAPve_d_BCM_Right_Light = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/LDW_Flag' */

  /* MATLAB Function: '<S8>/LDW_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Status_Display': '<S29>:1' */
  /* '<S29>:1:2' if (stDACmode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.Divide) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S29>:1:3' LDW_Status_Display=uint8(1); */
    rtb_TCU_ActualGear = 1U;
  } else if ((((sint32)LKAS_DW.Divide) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S29>:1:4' elseif (stDACmode==1)&&LDW_STATE==6 */
    /* '<S29>:1:5' LDW_Status_Display=uint8(2); */
    rtb_TCU_ActualGear = 2U;
  } else {
    /* '<S29>:1:6' else */
    /* '<S29>:1:7' LDW_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;
  }

  /* End of MATLAB Function: '<S8>/LDW_Status_Display' */

  /* MATLAB Function: '<S8>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S31>:1' */
  /* '<S31>:1:2' if stDACmode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S31>:1:3' LKA_Action_Indication=uint8(1); */
    rtb_LKA_Action_Indication = 1U;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S31>:1:4' elseif stDACmode==2&&LKA_STATE==3 */
    /* '<S31>:1:5' LKA_Action_Indication=uint8(2); */
    rtb_LKA_Action_Indication = 2U;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S31>:1:6' elseif stDACmode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S31>:1:7' LKA_Action_Indication=uint8(3); */
    rtb_LKA_Action_Indication = 3U;
  } else {
    /* '<S31>:1:8' else */
    /* '<S31>:1:9' LKA_Action_Indication=uint8(0); */
    rtb_LKA_Action_Indication = 0U;
  }

  /* End of MATLAB Function: '<S8>/LKA_action_indication' */

  /* MATLAB Function: '<S8>/LKA_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_Status_Display': '<S30>:1' */
  /* '<S30>:1:3' if stDACmode==2&&LKA_STATE~=6 */
  if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) != 6)) {
    /* '<S30>:1:4' LKA_Status_Display=single(1); */
    rtb_L0_C2_c = 1.0F;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S30>:1:5' elseif stDACmode==2&&LKA_STATE==6 */
    /* '<S30>:1:6' LKA_Status_Display=single(2); */
    rtb_L0_C2_c = 2.0F;
  } else {
    /* '<S30>:1:7' else */
    /* '<S30>:1:8' LKA_Status_Display=single(0); */
    rtb_L0_C2_c = 0.0F;
  }

  /* End of MATLAB Function: '<S8>/LKA_Status_Display' */

  /* MATLAB Function: '<S8>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S55>/Switch'
   *  Switch: '<S55>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S33>:1' */
  /* '<S33>:1:2' if stDACmode==1 */
  switch (LKAS_DW.Divide) {
   case 1:
    /* '<S33>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_L0_Q_l) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q_l) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S33>:1:6' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q_l = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q_l) ==
        3)) && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S33>:1:8' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q_l = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q_l) ==
        3)) && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S33>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S33>:1:10' Vehicle_Lane_Display=uint8(10); */
        rtb_L0_Q_l = 10U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q_l) !=
        3)) && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S33>:1:12' Vehicle_Lane_Display=uint8(11); */
        rtb_L0_Q_l = 11U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q_l) ==
        3)) && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S33>:1:14' Vehicle_Lane_Display=uint8(12); */
        rtb_L0_Q_l = 12U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q_l) ==
        3)) && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S33>:1:16' Vehicle_Lane_Display=uint8(13); */
        rtb_L0_Q_l = 13U;
      } else {
        /* '<S33>:1:17' else */
        /* '<S33>:1:18' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q_l = 1U;
      }
    } else {
      /* '<S33>:1:4' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   case 2:
    /* '<S33>:1:20' elseif stDACmode==2 */
    /* '<S33>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_L0_Q_l) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q_l) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S33>:1:24' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q_l = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q_l) ==
        3)) && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S33>:1:26' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q_l = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q_l) ==
        3)) && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S33>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S33>:1:28' Vehicle_Lane_Display=uint8(6); */
        rtb_L0_Q_l = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q_l) !=
        3)) && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S33>:1:30' Vehicle_Lane_Display=uint8(7); */
        rtb_L0_Q_l = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q_l) ==
        3)) && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S33>:1:32' Vehicle_Lane_Display=uint8(8); */
        rtb_L0_Q_l = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q_l) ==
        3)) && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S33>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S33>:1:34' Vehicle_Lane_Display=uint8(9); */
        rtb_L0_Q_l = 9U;
      } else {
        /* '<S33>:1:35' else */
        /* '<S33>:1:36' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q_l = 1U;
      }
    } else {
      /* '<S33>:1:22' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   default:
    /* '<S33>:1:38' else */
    /* '<S33>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_L0_Q_l = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/Vehicle_Lane_Display' */

  /* DataTypeConversion: '<S11>/Cast To Single10' incorporates:
   *  Constant: '<S538>/Constant'
   *  RelationalOperator: '<S538>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.DACMode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S4>/Cast To Single1' */
  LKAS_DW.CastToSingle1 = LKAS_DW.LFTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single2' */
  LKAS_DW.CastToSingle2 = LKAS_DW.RGTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single3' */
  LKAS_DW.CastToSingle3 = (float32)LKAS_DW.LDW_State_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single4' */
  LKAS_DW.CastToSingle4 = (float32)LKAS_DW.LKA_State_Mon;

  /* S-Function (scanpack): '<S4>/CAN Pack' */
  /* S-Function (scanpack): '<S4>/CAN Pack' */
  LKAS_DW.CANPack.ID = 1U;
  LKAS_DW.CANPack.Length = 8U;
  LKAS_DW.CANPack.Extended = 0U;
  LKAS_DW.CANPack.Remote = 0;
  LKAS_DW.CANPack.Data[0] = 0;
  LKAS_DW.CANPack.Data[1] = 0;
  LKAS_DW.CANPack.Data[2] = 0;
  LKAS_DW.CANPack.Data[3] = 0;
  LKAS_DW.CANPack.Data[4] = 0;
  LKAS_DW.CANPack.Data[5] = 0;
  LKAS_DW.CANPack.Data[6] = 0;
  LKAS_DW.CANPack.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle1;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[1] = LKAS_DW.CANPack.Data[1] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[0] = LKAS_DW.CANPack.Data[0] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle2;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[3] = LKAS_DW.CANPack.Data[3] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[2] = LKAS_DW.CANPack.Data[2] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle3;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[5] = LKAS_DW.CANPack.Data[5] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[4] = LKAS_DW.CANPack.Data[4] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle4;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[7] = LKAS_DW.CANPack.Data[7] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[6] = LKAS_DW.CANPack.Data[6] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single5' */
  LKAS_DW.CastToSingle5 = LKAS_DW.LKA_ExitFlg_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single6' */
  LKAS_DW.CastToSingle6 = LKAS_DW.LKA_SampleTime_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single7' */
  LKAS_DW.CastToSingle7 = LKAS_DW.T1_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single8' */
  LKAS_DW.CastToSingle8 = LKAS_DW.Disable_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  LKAS_DW.CANPack1.ID = 2U;
  LKAS_DW.CANPack1.Length = 8U;
  LKAS_DW.CANPack1.Extended = 0U;
  LKAS_DW.CANPack1.Remote = 0;
  LKAS_DW.CANPack1.Data[0] = 0;
  LKAS_DW.CANPack1.Data[1] = 0;
  LKAS_DW.CANPack1.Data[2] = 0;
  LKAS_DW.CANPack1.Data[3] = 0;
  LKAS_DW.CANPack1.Data[4] = 0;
  LKAS_DW.CANPack1.Data[5] = 0;
  LKAS_DW.CANPack1.Data[6] = 0;
  LKAS_DW.CANPack1.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle5;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[1] = LKAS_DW.CANPack1.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[0] = LKAS_DW.CANPack1.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle6;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[3] = LKAS_DW.CANPack1.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[2] = LKAS_DW.CANPack1.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle7;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[5] = LKAS_DW.CANPack1.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[4] = LKAS_DW.CANPack1.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle8;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[7] = LKAS_DW.CANPack1.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[6] = LKAS_DW.CANPack1.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack' */
    if ((8 == LKAS_DW.CANPack.Length) && (LKAS_DW.CANPack.ID != INVALID_CAN_ID) )
    {
      if ((1 == LKAS_DW.CANPack.ID) && (0U == LKAS_DW.CANPack.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
    if ((8 == LKAS_DW.CANPack1.Length) && (LKAS_DW.CANPack1.ID != INVALID_CAN_ID)
        ) {
      if ((2 == LKAS_DW.CANPack1.ID) && (0U == LKAS_DW.CANPack1.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
    if ((8 == LKAS_ConstB.CANPack2.Length) && (LKAS_ConstB.CANPack2.ID !=
         INVALID_CAN_ID) ) {
      if ((3 == LKAS_ConstB.CANPack2.ID) && (0U == LKAS_ConstB.CANPack2.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack2.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack2.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07L_100 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
    if ((8 == LKAS_ConstB.CANPack3.Length) && (LKAS_ConstB.CANPack3.ID !=
         INVALID_CAN_ID) ) {
      if ((4 == LKAS_ConstB.CANPack3.ID) && (0U == LKAS_ConstB.CANPack3.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08L_100 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack4' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack4' */
    if ((8 == LKAS_ConstB.CANPack4.Length) && (LKAS_ConstB.CANPack4.ID !=
         INVALID_CAN_ID) ) {
      if ((4 == LKAS_ConstB.CANPack4.ID) && (0U == LKAS_ConstB.CANPack4.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack4.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob09H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack4.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob09L_100 = result;
            }
          }
        }
      }
    }
  }

  /* RelationalOperator: '<S20>/Compare' incorporates:
   *  Constant: '<S20>/Constant'
   */
  rtb_Compare_l5 = (rtb_IMAPve_d_TCU_Actual_Gear > ((uint8)3U));

  /* Switch: '<S55>/Switch' incorporates:
   *  DataTypeConversion: '<S64>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_p = rtb_R0_Type;
  } else {
    rtb_R0_Type_p = rtb_R0_Q_dp;
  }

  /* Switch: '<S55>/Switch1' incorporates:
   *  Constant: '<S61>/Constant'
   *  DataTypeConversion: '<S62>/Cast To Single5'
   *  Switch: '<S61>/Switch3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_a = rtb_R0_Q_dp;

    /* Switch: '<S54>/Switch' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1'
     *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_Q_1'
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     *  Inport: '<Root>/IMAPve_d_ORI_L1_Q'
     */
    if (rtb_DataTypeConversion > ((uint8)0U)) {
      rtb_L1_Q = (uint16)((uint8)
                          Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q
                          ());
    } else {
      rtb_L1_Q = (uint16)((uint8)
                          Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L1_Q_IMAPve_d_ORI_L1_Q
                          ());
    }
  } else {
    rtb_L0_Type_a = rtb_R0_Type;
    rtb_L1_Q = ((uint16)0U);
  }

  /* Switch: '<S63>/Switch3' incorporates:
   *  Constant: '<S63>/Constant'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    /* Switch: '<S54>/Switch' incorporates:
     *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_Q_1'
     *  DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1'
     *  Inport: '<Root>/IMAPve_d_ORI_R1_Q'
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    if (rtb_DataTypeConversion > ((uint8)0U)) {
      rtb_R1_Q = (uint16)((uint8)
                          Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q
                          ());
    } else {
      rtb_R1_Q = (uint16)((uint8)
                          Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R1_Q_IMAPve_d_ORI_R1_Q
                          ());
    }
  } else {
    rtb_R1_Q = ((uint16)0U);
  }

  /* End of Switch: '<S63>/Switch3' */

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_LC_1'
   *  Inport: '<Root>/IMAPve_d_L0_LC'
   *  Inport: '<Root>/IMAPve_d_ORI_L0_LC'
   *  Inport: '<Root>/IMAPve_d_ORI_R0_LC'
   *  Inport: '<Root>/IMAPve_d_R0_LC'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_R0_Q_dp = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_LC_IMAPve_d_R0_LC();
    rtb_R0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_LC_IMAPve_d_L0_LC();
  } else {
    rtb_R0_Q_dp = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R0_LC_IMAPve_d_ORI_R0_LC();
    rtb_R0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L0_LC_IMAPve_d_ORI_L0_LC();
  }

  /* Switch: '<S55>/Switch' incorporates:
   *  DataTypeConversion: '<S64>/Cast To Single8'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_LC_j = rtb_R0_Q_dp;
  } else {
    rtb_R0_LC_j = rtb_R0_Type;
  }

  /* Switch: '<S55>/Switch1' incorporates:
   *  DataTypeConversion: '<S62>/Cast To Single8'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_LC_f = rtb_R0_Type;
  } else {
    rtb_L0_LC_f = rtb_R0_Q_dp;
  }

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_VR'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_VR'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_L0_C1 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR();
    rtb_L0_C1_c = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR();
  } else {
    rtb_L0_C1 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_VR_IMAPve_g_ORI_R0_VR();
    rtb_L0_C1_c = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_VR_IMAPve_g_ORI_L0_VR();
  }

  /* Switch: '<S55>/Switch' incorporates:
   *  DataTypeConversion: '<S64>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_VR_m = rtb_L0_C1;
  } else {
    rtb_R0_VR_m = rtb_L0_C1_c;
  }

  /* Switch: '<S55>/Switch1' incorporates:
   *  DataTypeConversion: '<S62>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_g = rtb_L0_C1_c;
  } else {
    rtb_L0_VR_g = rtb_L0_C1;
  }

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_W_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_W_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_W_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_L0_W'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_W'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_W'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_L0_C1 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W();
    rtb_L0_C1_c = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W();
  } else {
    rtb_L0_C1 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_W_IMAPve_g_ORI_R0_W();
    rtb_L0_C1_c = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_W_IMAPve_g_ORI_L0_W();
  }

  /* Switch: '<S55>/Switch' incorporates:
   *  DataTypeConversion: '<S64>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_d = rtb_L0_C1;
  } else {
    rtb_R0_W_d = rtb_L0_C1_c;
  }

  /* Switch: '<S55>/Switch1' incorporates:
   *  DataTypeConversion: '<S62>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_c = rtb_L0_C1_c;
  } else {
    rtb_L0_W_c = rtb_L0_C1;
  }

  /* Switch: '<S54>/Switch' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_LT_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_TLC_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_W_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_TLC_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_W_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_TLC_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_W_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_TLC_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_VR_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_W_1'
   *  Inport: '<Root>/IMAPve_d_L1_LC'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_LC'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_Type'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_LC'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_LT'
   *  Inport: '<Root>/IMAPve_d_R1_LC'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   *  Inport: '<Root>/IMAPve_g_L1_TLC'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C0'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C2'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C3'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_TLC'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_VR'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_W'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C0'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C2'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C3'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_TLC'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_VR'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_W'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   *  Inport: '<Root>/IMAPve_g_R1_TLC'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   *  UnaryMinus: '<S54>/Unary Minus10'
   *  UnaryMinus: '<S54>/Unary Minus11'
   *  UnaryMinus: '<S54>/Unary Minus12'
   *  UnaryMinus: '<S54>/Unary Minus13'
   *  UnaryMinus: '<S54>/Unary Minus14'
   *  UnaryMinus: '<S54>/Unary Minus15'
   *  UnaryMinus: '<S54>/Unary Minus8'
   *  UnaryMinus: '<S54>/Unary Minus9'
   */
  if (rtb_DataTypeConversion > ((uint8)0U)) {
    rtb_L1_VR = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR();
    rtb_L1_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type();
    rtb_L1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W
      ();
    rtb_L1_TLC = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_TLC_IMAPve_g_L1_TLC();
    rtb_L1_LC = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_LC_IMAPve_d_L1_LC();
    rtb_R1_VR = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR();
    rtb_R1_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type();
    rtb_R1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W
      ();
    rtb_R1_TLC = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_TLC_IMAPve_g_R1_TLC();
    rtb_R1_LC = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_LC_IMAPve_d_R1_LC();
    rtb_L1_C0 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0
      ()));
    rtb_L1_C1 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1
      ()));
    rtb_L1_C2 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2
      ()));
    rtb_L1_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3
      ()));
    rtb_R1_C0 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0
      ()));
    rtb_R1_C1 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1
      ()));
    rtb_R1_C2 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2
      ()));
    rtb_R1_C3 = (float32)((T_M_Nm_Float32)
                          (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3
      ()));
  } else {
    rtb_L1_VR = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_VR_IMAPve_g_ORI_L1_VR();
    rtb_L1_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L1_Type_IMAPve_d_ORI_L1_Type();
    rtb_L1_W = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_W_IMAPve_g_ORI_L1_W();
    rtb_L1_TLC = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_TLC_IMAPve_g_ORI_L1_TLC();
    rtb_L1_LC = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L1_LC_IMAPve_d_ORI_L1_LC();
    rtb_R1_VR = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_VR_IMAPve_g_ORI_R1_VR();
    rtb_R1_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R1_LT_IMAPve_d_ORI_R1_LT();
    rtb_R1_W = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_W_IMAPve_g_ORI_R1_W();
    rtb_R1_TLC = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_TLC_IMAPve_g_ORI_R1_TLC();
    rtb_R1_LC = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R1_LC_IMAPve_d_ORI_R1_LC();
    rtb_L1_C0 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C0_IMAPve_g_ORI_L1_C0();
    rtb_L1_C1 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C1_IMAPve_g_ORI_L1_C1();
    rtb_L1_C2 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C2_IMAPve_g_ORI_L1_C2();
    rtb_L1_C3 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C3_IMAPve_g_ORI_L1_C3();
    rtb_R1_C0 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C0_IMAPve_g_ORI_R1_C0();
    rtb_R1_C1 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C1_IMAPve_g_ORI_R1_C1();
    rtb_R1_C2 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C2_IMAPve_g_ORI_R1_C2();
    rtb_R1_C3 = (float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C3_IMAPve_g_ORI_R1_C3();
  }

  /* RelationalOperator: '<S13>/Compare' incorporates:
   *  Constant: '<S13>/Constant'
   */
  rtb_Compare_d = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

  /* DataTypeConversion: '<S1>/IMAPve_d_APA_AutoPark_WorkSt_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_APA_AutoPark_WorkSt'
   */
  rtb_IMAPve_d_APA_AutoPark_WorkS = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch'
   */
  rtb_IMAPve_d_BCM_LeftTurn_Switc = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch'
   */
  rtb_IMAPve_d_BCM_RightTurn_Swit = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Signal_Fault_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Camera_Signal_Fault'
   */
  rtb_IMAPve_d_Camera_Signal_Faul = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Signal_Fault_IMAPve_d_Camera_Signal_Fault
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ConsArea_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ConsArea'
   */
  rtb_IMAPve_d_ConsArea = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ConsArea_IMAPve_d_ConsArea();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Active_ESA_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Active_ESA'
   */
  rtb_IMAPve_d_EPS_Driver_Active_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Active_ESA_IMAPve_d_EPS_Driver_Active_ESA
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Override'
   */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_ESA_State'
   */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Error_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Error_State'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Error_State_IMAPve_d_EPS_Error_State
    ();

  /* Logic: '<S7>/Logical Operator5' incorporates:
   *  Constant: '<S14>/Constant'
   *  Constant: '<S17>/Constant'
   *  RelationalOperator: '<S14>/Compare'
   *  RelationalOperator: '<S17>/Compare'
   */
  rtb_Event_FaulETATDA = ((rtb_EPS_LKA_Control == ((UInt8)((uint8)1U))) ||
    (rtb_EPS_LKA_Control == ((UInt8)((uint8)2U))));

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State'
   */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag'
   */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    ();

  /* RelationalOperator: '<S21>/Compare' incorporates:
   *  Constant: '<S21>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_TrqLim_State'
   */
  rtb_Compare_d5 = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State
                     ()) == ((uint8)0U));

  /* RelationalOperator: '<S22>/Compare' incorporates:
   *  Constant: '<S22>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_Trq_State'
   */
  rtb_Compare_ao = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S23>/Compare' incorporates:
   *  Constant: '<S23>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid'
   */
  rtb_Compare_aw = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S25>/Compare' incorporates:
   *  Constant: '<S25>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid'
   */
  rtb_Compare_pt = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S12>/Compare' incorporates:
   *  Constant: '<S12>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid'
   */
  rtb_Compare_lf = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid
                     ()) != ((uint8)1U));

  /* RelationalOperator: '<S24>/Compare' incorporates:
   *  Constant: '<S24>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid'
   */
  rtb_Compare_m = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid
                    ()) == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Fusion_Status'
   */
  rtb_IMAPve_d_Fusion_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LDW_Warn_Mode'
   */
  rtb_IMAPve_d_LDW_Warn_Mode = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode();

  /* DataTypeConversion: '<S1>/IMAPve_d_Lane_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Lane_Valid'
   */
  rtb_IMAPve_d_Lane_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Lane_Valid_IMAPve_d_Lane_Valid();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_AutoPilot_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_AutoPilot_Switch'
   */
  rtb_IMAPve_d_MP5_AutoPilot_Swit = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_AutoPilot_Switch_IMAPve_d_MP5_AutoPilot_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_Work_State'
   */
  rtb_IMAPve_d_MP5_Work_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_ConsArea_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_Lane_ConsArea'
   */
  rtb_IMAPve_d_ORI_Lane_ConsArea = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_Lane_ConsArea_IMAPve_d_ORI_Lane_ConsArea
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_RoadType_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_Lane_RoadType'
   */
  rtb_IMAPve_d_ORI_Lane_RoadType = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_Lane_RoadType_IMAPve_d_ORI_Lane_RoadType
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_Lane_Valid'
   */
  rtb_IMAPve_d_ORI_Lane_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_Lane_Valid_IMAPve_d_ORI_Lane_Valid
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Road_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Road_Type'
   */
  rtb_IMAPve_d_Road_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Road_Type_IMAPve_d_Road_Type();

  /* RelationalOperator: '<S15>/Compare' incorporates:
   *  Constant: '<S15>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Clb_State'
   */
  rtb_Compare_f = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State
                    ()) == ((uint8)0U));

  /* RelationalOperator: '<S16>/Compare' incorporates:
   *  Constant: '<S16>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Trim_State'
   */
  rtb_Compare_n = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State
                    ()) == ((uint8)1U));

  /* Logic: '<S7>/Logical Operator6' incorporates:
   *  Constant: '<S18>/Constant'
   *  Constant: '<S19>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_SWS_Fault_Code_1'
   *  Inport: '<Root>/IMAPve_d_SWS_Failure_Status'
   *  Inport: '<Root>/IMAPve_d_SWS_Fault_Code'
   *  RelationalOperator: '<S18>/Compare'
   *  RelationalOperator: '<S19>/Compare'
   */
  rtb_Event_FaulSWS = ((((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Fault_Code_IMAPve_d_SWS_Fault_Code
    ()) != ((uint8)0U)) || (((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status
    ()) != ((uint8)1U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Sensor_Status'
   */
  rtb_IMAPve_d_Sensor_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_TCU_Available'
   */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  rtb_IMAPve_g_EMS_RealPedal = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  rtb_IMAPve_g_EPS_LKA_Current = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SteeringAngle'
   */
  rtb_IMAPve_g_EPS_SteeringAngle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  rtb_IMAPve_g_ESC_Brake_Press = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  rtb_IMAPve_g_ESC_UnYawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  rtb_IMAPve_g_ESC_YawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_Confidence'
   */
  rtb_IMAPve_g_L0_Confidence = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_Confidence_IMAPve_g_L0_Confidence();

  /* DataTypeConversion: '<S1>/IMAPve_g_L1_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L1_Confidence'
   */
  rtb_IMAPve_g_L1_Confidence = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_Confidence_IMAPve_g_L1_Confidence();

  /* DataTypeConversion: '<S1>/IMAPve_g_R0_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_R0_Confidence'
   */
  rtb_IMAPve_g_R0_Confidence = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_Confidence_IMAPve_g_R0_Confidence();

  /* DataTypeConversion: '<S1>/IMAPve_g_R1_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_R1_Confidence'
   */
  rtb_IMAPve_g_R1_Confidence = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_Confidence_IMAPve_g_R1_Confidence();

  /* Switch: '<S545>/Switch1' incorporates:
   *  Constant: '<S545>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S545>/Switch1' */

  /* Switch: '<S545>/Switch12' incorporates:
   *  Constant: '<S545>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S545>/Switch12' */

  /* Switch: '<S546>/Switch56' incorporates:
   *  Constant: '<S546>/LLSMConClb14'
   *
   * Block description for '<S546>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_d != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_d;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S546>/Switch56' */

  /* Switch: '<S546>/Switch51' incorporates:
   *  Constant: '<S546>/LLSMConClb15'
   *
   * Block description for '<S546>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_h != 0.0F) {
    rtb_LL_DvtComp_C_j = LKAS_ConstB.DataTypeConversion25_h;
  } else {
    rtb_LL_DvtComp_C_j = LL_DvtComp_C;
  }

  /* End of Switch: '<S546>/Switch51' */

  /* Switch: '<S546>/Switch46' incorporates:
   *  Constant: '<S546>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S546>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_i != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_i;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S546>/Switch46' */

  /* Update for Memory: '<S74>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Add1;

  /* Update for Memory: '<S66>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = rtb_L0_C0;

  /* Update for Memory: '<S66>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = rtb_Switch_f;

  /* Update for Memory: '<S67>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_d = rtb_R0_C0;

  /* Update for Memory: '<S67>/Memory' */
  LKAS_DW.Memory_PreviousInput_my = rtb_offset;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S77>/Delay' */
    LKAS_DW.Delay_DSTATE = LKAS_DW.LKASM_stLKAActvFlg;

    /* Update for Memory: '<S510>/Memory' */
    LKAS_DW.Memory_PreviousInput_p = rtb_Saturation_g;

    /* Update for Memory: '<S455>/Memory' */
    LKAS_DW.Memory_PreviousInput_o = rtb_Saturation_l;

    /* Update for UnitDelay: '<S385>/Delay Input1'
     *
     * Block description for '<S385>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_gpu;

    /* Update for UnitDelay: '<S383>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_c = LKAS_DW.RelationalOperator_mx;

    /* Update for UnitDelay: '<S384>/Delay Input1'
     *
     * Block description for '<S384>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_a = rtb_Compare_by;

    /* Update for Delay: '<S78>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.LKASM_stLKAState;

    /* Update for UnitDelay: '<S346>/Delay Input1'
     *
     * Block description for '<S346>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_j = rtb_Compare_hu;

    /* Update for UnitDelay: '<S344>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_a = LKAS_DW.RelationalOperator_b;

    /* Update for UnitDelay: '<S345>/Delay Input1'
     *
     * Block description for '<S345>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_i = rtb_Compare_oq;

    /* Update for Memory: '<S311>/Memory' */
    LKAS_DW.Memory_PreviousInput_jc = LKAS_DW.RelationalOperator_b;

    /* Update for Delay: '<S78>/Delay' */
    LKAS_DW.Delay_DSTATE_l = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S78>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.LDWSM_stLDWState;

    /* Update for Memory: '<S359>/Memory' */
    LKAS_DW.Memory_PreviousInput_i5 = rtb_LDW_State;

    /* Update for Memory: '<S285>/Memory' */
    LKAS_DW.Memory_PreviousInput_k = rtb_Merge1_o;

    /* Update for Memory: '<S321>/Memory' */
    LKAS_DW.Memory_PreviousInput_c = rtb_Merge1_l;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S104>/Memory' */
      LKAS_DW.Memory_PreviousInput_gq = rtb_Saturation2;

      /* Update for Memory: '<S141>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = rtb_Saturation1_b;

      /* Update for Memory: '<S87>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_a = rtb_Saturation1_cw;

      /* Update for Memory: '<S140>/Memory' */
      LKAS_DW.Memory_PreviousInput_oc = rtb_Saturation1_p;

      /* Update for Memory: '<S142>/Memory' */
      LKAS_DW.Memory_PreviousInput_py2 = rtb_Saturation1_h;

      /* Update for Memory: '<S136>/Memory' */
      LKAS_DW.Memory_PreviousInput_mu = rtb_Add_ov;

      /* Update for Memory: '<S139>/Memory' */
      LKAS_DW.Memory_PreviousInput_n3 = rtb_Saturation1_n;

      /* Update for Memory: '<S138>/Memory' */
      LKAS_DW.Memory_PreviousInput_bc = rtb_Saturation1_hl;

      /* Update for Memory: '<S137>/Memory' */
      LKAS_DW.Memory_PreviousInput_mn = rtb_Saturation1_j;

      /* Update for Memory: '<S114>/Memory' */
      LKAS_DW.Memory_PreviousInput_ip = rtb_Add_oi;

      /* Update for Memory: '<S105>/Memory' */
      LKAS_DW.Memory_PreviousInput_py = rtb_Saturation2_n;

      /* Update for Memory: '<S106>/Memory' */
      LKAS_DW.Memory_PreviousInput_oy = rtb_Saturation2_g;

      /* Update for Memory: '<S103>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_k = rtb_Saturation_k;

      /* Update for Memory: '<S195>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_e = rtb_Saturation_ns;

      /* Update for Memory: '<S180>/Memory' */
      LKAS_DW.Memory_PreviousInput_e = rtb_Add1_eq;

      /* Update for UnitDelay: '<S178>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_k = rtb_Switch2_d1;

      /* Update for Memory: '<S186>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_c = rtb_Saturation_a;

      /* Update for Memory: '<S190>/Memory' */
      LKAS_DW.Memory_PreviousInput_l = rtb_Saturation1_id;

      /* Update for UnitDelay: '<S194>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_m = rtb_Switch_js;

      /* Update for Memory: '<S194>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_h = rtb_Saturation_kf;

      /* Update for UnitDelay: '<S173>/Delay Input2'
       *
       * Block description for '<S173>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_g = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S173>/Memory' */
      LKAS_DW.Memory_PreviousInput_e1 = rtb_Saturation2_m;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S78>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.Divide;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S539>/Delay Input2'
   *
   * Block description for '<S539>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_L0_C2;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_L0_Q_l);

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_TCU_ActualGear);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single2'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)((uint8)rtb_L0_C2_c));

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single3'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    rtb_IMAPve_d_BCM_Right_Light);

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single4'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning
    ((UInt8)rtb_IMAPve_d_BCM_Left_Light);

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single5'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_LKA_Action_Indication);

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single6'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status
    ((UInt8)rtb_IMAPve_d_Camera_Status);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/x1'
   */
  if (rtb_LogicalOperator_ps) {
    rtb_L0_C0 = LKAS_DW.OutputM;
  } else {
    rtb_L0_C0 = (float32)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_L0_C0);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' incorporates:
   *  DataTypeConversion: '<S5>/Cast To Single9'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    ((UInt8)LKAS_ConstB.EPS_LKA_Control);

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq
    ((UInt8)rtb_IMAPve_d_BCM_HazardLamp);

  /* Switch: '<S540>/Switch2' incorporates:
   *  Constant: '<S536>/Constant3'
   *  Constant: '<S536>/Constant4'
   *  RelationalOperator: '<S540>/LowerRelop1'
   *  RelationalOperator: '<S540>/UpperRelop'
   *  Switch: '<S540>/Switch'
   */
  if (rtb_L0_C2 > 5.0F) {
    rtb_L0_C2 = 5.0F;
  } else {
    if (rtb_L0_C2 < (-5.0F)) {
      /* Switch: '<S540>/Switch' incorporates:
       *  Constant: '<S536>/Constant4'
       */
      rtb_L0_C2 = (-5.0F);
    }
  }

  /* End of Switch: '<S540>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_L0_C2);

  /* Outport: '<Root>/LKASve_g_ob5H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5H_10_LKASve_g_ob5H_10
    (LKAS_DW.LKASve_g_ob5H_10);

  /* Outport: '<Root>/LKASve_g_ob5L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5L_10_LKASve_g_ob5L_10
    (LKAS_DW.LKASve_g_ob5L_10);

  /* Outport: '<Root>/LKASve_g_ob6H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6H_10_LKASve_g_ob6H_10
    (LKAS_DW.LKASve_g_ob6H_10);

  /* Outport: '<Root>/LKASve_g_ob6L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6L_10_LKASve_g_ob6L_10
    (LKAS_DW.LKASve_g_ob6L_10);

  /* Outport: '<Root>/LKASve_g_ob07H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07H_100_LKASve_g_ob07H_100
    (LKAS_DW.LKASve_g_ob07H_100);

  /* Outport: '<Root>/LKASve_g_ob07L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07L_100_LKASve_g_ob07L_100
    (LKAS_DW.LKASve_g_ob07L_100);

  /* Outport: '<Root>/LKASve_g_ob08H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08H_100_LKASve_g_ob08H_100
    (LKAS_DW.LKASve_g_ob08H_100);

  /* Outport: '<Root>/LKASve_g_ob08L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08L_100_LKASve_g_ob08L_100
    (LKAS_DW.LKASve_g_ob08L_100);

  /* Outport: '<Root>/LKASve_g_ob09H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob09H_100_LKASve_g_ob09H_100
    (LKAS_DW.LKASve_g_ob09H_100);

  /* Outport: '<Root>/LKASve_g_ob09L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob09L_100_LKASve_g_ob09L_100
    (LKAS_DW.LKASve_g_ob09L_100);
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S359>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S87>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S193>/If' */
  LKAS_DW.If_ActiveSubsystem_f = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack' */

  /*-----------S-Function Block: <S4>/CAN Unpack -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack1' */

  /*-----------S-Function Block: <S4>/CAN Unpack1 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack2' */

  /*-----------S-Function Block: <S4>/CAN Unpack2 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack3' */

  /*-----------S-Function Block: <S4>/CAN Unpack3 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack4' */

  /*-----------S-Function Block: <S4>/CAN Unpack4 -----------------*/

  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S74>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* InitializeConditions for Memory: '<S66>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = (-1.75F);

  /* InitializeConditions for Memory: '<S66>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = (-1.75F);

  /* InitializeConditions for Memory: '<S67>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_d = 1.75F;

  /* InitializeConditions for Memory: '<S67>/Memory' */
  LKAS_DW.Memory_PreviousInput_my = 1.75F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S77>/Delay' */
  LKAS_DW.Delay_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S510>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = 0.0F;

  /* InitializeConditions for Memory: '<S455>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = 0.0F;

  /* InitializeConditions for UnitDelay: '<S385>/Delay Input1'
   *
   * Block description for '<S385>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S383>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_c = false;

  /* InitializeConditions for UnitDelay: '<S384>/Delay Input1'
   *
   * Block description for '<S384>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_a = false;

  /* InitializeConditions for Delay: '<S78>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for UnitDelay: '<S346>/Delay Input1'
   *
   * Block description for '<S346>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_j = false;

  /* InitializeConditions for UnitDelay: '<S344>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_a = false;

  /* InitializeConditions for UnitDelay: '<S345>/Delay Input1'
   *
   * Block description for '<S345>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_i = false;

  /* InitializeConditions for Memory: '<S311>/Memory' */
  LKAS_DW.Memory_PreviousInput_jc = false;

  /* InitializeConditions for Delay: '<S78>/Delay' */
  LKAS_DW.Delay_DSTATE_l = false;

  /* InitializeConditions for Delay: '<S78>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S359>/Memory' */
  LKAS_DW.Memory_PreviousInput_i5 = ((uint8)0U);

  /* InitializeConditions for Memory: '<S285>/Memory' */
  LKAS_DW.Memory_PreviousInput_k = 0.0F;

  /* InitializeConditions for Memory: '<S321>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 0.0F;

  /* InitializeConditions for Delay: '<S78>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S372>/Count 20s' */
  /* InitializeConditions for Memory: '<S380>/Memory' */
  LKAS_DW.Memory_PreviousInput_pl = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S372>/Count 20s' */

  /* SystemInitialize for Enabled SubSystem: '<S373>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S382>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S373>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S383>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S389>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S383>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S395>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S402>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S395>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S311>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S342>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S311>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S311>/Count' */
  /* InitializeConditions for Memory: '<S341>/Memory' */
  LKAS_DW.Memory_PreviousInput_ay = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S311>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S344>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S350>/Memory' */
  LKAS_DW.Memory_PreviousInput_f1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S344>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S312>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S356>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S312>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S359>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S392>/Memory' */
  LKAS_DW.Memory_PreviousInput_af = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S359>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S322>/Sum Condition' */
  /* InitializeConditions for Memory: '<S328>/Memory' */
  LKAS_DW.Memory_PreviousInput_c2 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S322>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S270>/Count_5s3' */
  /* InitializeConditions for Memory: '<S535>/Memory' */
  LKAS_DW.Memory_PreviousInput_n = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S270>/Count_5s3' */

  /* SystemInitialize for Enabled SubSystem: '<S270>/Count_5s2' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s2);

  /* End of SystemInitialize for SubSystem: '<S270>/Count_5s2' */

  /* SystemInitialize for Enabled SubSystem: '<S270>/Count_5s1' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s1);

  /* End of SystemInitialize for SubSystem: '<S270>/Count_5s1' */

  /* SystemInitialize for Enabled SubSystem: '<S247>/Subsystem' */
  /* InitializeConditions for Memory: '<S251>/Memory' */
  LKAS_DW.Memory_PreviousInput_c2t = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S247>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S104>/Memory' */
  LKAS_DW.Memory_PreviousInput_gq = 0.0F;

  /* InitializeConditions for Memory: '<S141>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = ((uint16)0U);

  /* InitializeConditions for Memory: '<S87>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_a = ((uint8)0U);

  /* InitializeConditions for Memory: '<S140>/Memory' */
  LKAS_DW.Memory_PreviousInput_oc = ((uint16)0U);

  /* InitializeConditions for Memory: '<S142>/Memory' */
  LKAS_DW.Memory_PreviousInput_py2 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput_mu = ((uint16)0U);

  /* InitializeConditions for Memory: '<S139>/Memory' */
  LKAS_DW.Memory_PreviousInput_n3 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S138>/Memory' */
  LKAS_DW.Memory_PreviousInput_bc = ((uint16)0U);

  /* InitializeConditions for Memory: '<S137>/Memory' */
  LKAS_DW.Memory_PreviousInput_mn = ((uint16)0U);

  /* InitializeConditions for Memory: '<S114>/Memory' */
  LKAS_DW.Memory_PreviousInput_ip = 0.0F;

  /* InitializeConditions for Memory: '<S105>/Memory' */
  LKAS_DW.Memory_PreviousInput_py = 0.0F;

  /* InitializeConditions for Memory: '<S106>/Memory' */
  LKAS_DW.Memory_PreviousInput_oy = 0.0F;

  /* InitializeConditions for Memory: '<S103>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_k = 0.0F;

  /* InitializeConditions for Memory: '<S195>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_e = 0.0F;

  /* InitializeConditions for Memory: '<S180>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = 0.0F;

  /* InitializeConditions for UnitDelay: '<S178>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_k = 0.0F;

  /* InitializeConditions for Memory: '<S186>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_c = 0.0F;

  /* InitializeConditions for Memory: '<S190>/Memory' */
  LKAS_DW.Memory_PreviousInput_l = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S194>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_m = 0.0F;

  /* InitializeConditions for Memory: '<S194>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_h = 0.0F;

  /* InitializeConditions for UnitDelay: '<S173>/Delay Input2'
   *
   * Block description for '<S173>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_g = 0.0F;

  /* InitializeConditions for Memory: '<S173>/Memory' */
  LKAS_DW.Memory_PreviousInput_e1 = ((uint16)0U);

  /* SystemInitialize for IfAction SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)'
   *
   * Block description for '<S87>/LKA Motion Planning Calculation (LKAMPCal)':
   *  Block Name: LKA Motion Planning Calculation
   *  Ab.: LKAMPCal
   *  No.: 1.2.3.2
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  LKAMotionPlanningCalculati_Init();

  /* End of SystemInitialize for SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */

  /* SystemInitialize for Enabled SubSystem: '<S105>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S107>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S105>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S94>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S94>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S106>/Moving Standard Deviation1' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S106>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S106>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_l);

  /* End of SystemInitialize for SubSystem: '<S106>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S106>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2_m);

  /* End of SystemInitialize for SubSystem: '<S106>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S106>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_l);

  /* End of SystemInitialize for SubSystem: '<S106>/Sum Condition' */

  /* SystemInitialize for IfAction SubSystem: '<S193>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S203>/Delay Input1'
   *
   * Block description for '<S203>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_p = false;

  /* InitializeConditions for Memory: '<S199>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S193>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S193>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S211>/Delay Input1'
   *
   * Block description for '<S211>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_f = false;

  /* InitializeConditions for Memory: '<S200>/Memory' */
  LKAS_DW.Memory_PreviousInput_ek = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S193>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S193>/Merge' */
  LKAS_DW.Merge_l = 1.0F;

  /* SystemInitialize for Merge: '<S193>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S80>/Merge' */
  LKAS_DW.Merge_f = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S80>/Sum Condition' */
  /* InitializeConditions for Memory: '<S84>/Memory' */
  LKAS_DW.Memory_PreviousInput_bo = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S80>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S536>/Subsystem' */
  /* InitializeConditions for Delay: '<S541>/Delay1' */
  LKAS_DW.Delay1_DSTATE = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S536>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S32>/Count 10s' */
  /* InitializeConditions for Memory: '<S43>/Memory' */
  LKAS_DW.Memory_PreviousInput_jm = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S32>/Count 10s' */

  /* SystemInitialize for Enabled SubSystem: '<S32>/Count 15s' */
  /* InitializeConditions for Memory: '<S44>/Memory' */
  LKAS_DW.Memory_PreviousInput_hl = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S32>/Count 15s' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
