/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.7
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Mon Mar 15 16:23:27 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S76>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S76>/LKA_State_Machine' */
#define LKAS_IN_Fault_i                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_h      ((uint8)0U)
#define LKAS_IN_Normal_d               ((uint8)2U)
#define LKAS_IN_SysOff_k               ((uint8)2U)
#define LKAS_IN_SysOn_d                ((uint8)3U)
#define LKAS_IN_Unavailable_n          ((uint8)1U)
#define LKAS_IN_Unselected_c           ((uint8)2U)

/* Named constants for Chart: '<S51>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * Output and update for action system:
 *    '<S78>/If Action Subsystem2'
 *    '<S117>/if action 4'
 *    '<S118>/if action 4'
 *    '<S119>/if action 4'
 *    '<S120>/if action 4'
 *    '<S131>/If Action Subsystem3'
 *    '<S132>/If Action Subsystem3'
 *    '<S133>/If Action Subsystem3'
 *    '<S141>/If Action Subsystem3'
 *    '<S166>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S81>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S81>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/*
 * System initialize for atomic system:
 *    '<S92>/Moving Standard Deviation2'
 *    '<S104>/Moving Standard Deviation1'
 *    '<S104>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S100>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S92>/Moving Standard Deviation2'
 *    '<S104>/Moving Standard Deviation1'
 *    '<S104>/Moving Standard Deviation2'
 */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S100>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S100>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S92>/Moving Standard Deviation2'
 *    '<S104>/Moving Standard Deviation1'
 *    '<S104>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation2(float32 rtu_In1,
  DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_i;
  float32 rtb_Delay1;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S100>/Delay' */
  rtb_Delay_i = localDW->Delay_DSTATE;

  /* Delay: '<S100>/Delay1' */
  rtb_Delay1 = localDW->Delay1_DSTATE;

  /* Delay: '<S100>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S100>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S100>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S100>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S100>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S100>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S100>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S100>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S100>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S100>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S100>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S100>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S100>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S100>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S100>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S100>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S100>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S100>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S100>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S100>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S100>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S100>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S100>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S100>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S100>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S100>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S100>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S100>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S100>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S100>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S100>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S100>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S100>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S100>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S100>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S100>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S100>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S100>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S100>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S100>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S100>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S100>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S100>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S100>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S100>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S100>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S100>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S100>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_i;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S100>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S100>/Standard Deviation' */

  /* Update for Delay: '<S100>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S100>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_i;

  /* Update for Delay: '<S100>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S100>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S100>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S100>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S100>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S100>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S100>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S100>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S100>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S100>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S100>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1;

  /* Update for Delay: '<S100>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S100>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S100>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S100>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S100>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S100>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S100>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S100>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S100>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S100>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S100>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S100>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S100>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S100>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S100>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S100>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S100>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S100>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S100>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S100>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S100>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S100>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S100>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S100>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S100>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S100>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S100>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S100>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S100>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S100>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S100>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S100>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S100>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S100>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S100>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S100>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S104>/Sum Condition'
 *    '<S104>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S108>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S104>/Sum Condition'
 *    '<S104>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S108>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S104>/Sum Condition'
 *    '<S104>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S104>/Sum Condition' incorporates:
   *  EnablePort: '<S108>/Enable'
   */
  /* Disable for Outport: '<S108>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S104>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S104>/Sum Condition'
 *    '<S104>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_bb;

  /* Outputs for Enabled SubSystem: '<S104>/Sum Condition' incorporates:
   *  EnablePort: '<S108>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S108>/Add1' incorporates:
     *  Memory: '<S108>/Memory'
     */
    rtb_Saturation_bb = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S108>/Saturation' */
    if (rtb_Saturation_bb > 100.0F) {
      rtb_Saturation_bb = 100.0F;
    } else {
      if (rtb_Saturation_bb < 0.0F) {
        rtb_Saturation_bb = 0.0F;
      }
    }

    /* End of Saturate: '<S108>/Saturation' */

    /* RelationalOperator: '<S108>/Relational Operator' */
    *rty_Out = (rtb_Saturation_bb >= rtu_In1);

    /* Update for Memory: '<S108>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_bb;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S104>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S117>/if action 3'
 *    '<S118>/if action 3'
 *    '<S119>/if action 3'
 *    '<S120>/if action 3'
 *    '<S131>/If Action Subsystem2'
 *    '<S131>/If Action Subsystem1'
 *    '<S132>/If Action Subsystem2'
 *    '<S132>/If Action Subsystem1'
 *    '<S133>/If Action Subsystem2'
 *    '<S133>/If Action Subsystem1'
 *    ...
 */
void LKAS_ifaction3(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S123>/In1' */
  *rty_Out1 = rtu_In1;
}

/* System initialize for action system: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculati_Init(void)
{
  /* InitializeConditions for Memory: '<S116>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory' */
  LKAS_DW.Memory_PreviousInput_de = ((uint16)0U);

  /* InitializeConditions for Memory: '<S117>/Memory' */
  LKAS_DW.Memory_PreviousInput_m5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_cb = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_o = 0.0F;

  /* InitializeConditions for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_po = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/* System reset for action system: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculat_Reset(void)
{
  /* InitializeConditions for Memory: '<S116>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory' */
  LKAS_DW.Memory_PreviousInput_de = ((uint16)0U);

  /* InitializeConditions for Memory: '<S117>/Memory' */
  LKAS_DW.Memory_PreviousInput_m5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_cb = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_o = 0.0F;

  /* InitializeConditions for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_po = ((uint16)0U);

  /* InitializeConditions for Memory: '<S110>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/*
 * Output and update for action system: '<S85>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S85>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  /* local block i/o variables */
  float32 rtb_Memory1;
  float32 rtb_Memory2;
  float32 rtb_Memory3;
  float32 rtb_Memory4;
  float32 rtb_Merge1;
  float32 rtb_Merge1_f;
  float32 rtb_Merge1_b;
  float32 rtb_Merge1_i;
  float32 rtb_K1K2Det_dphi2PhSWAGrad2;
  float32 rtb_K1K2Det_stReplFlag;
  float32 rtb_K1K2Det_dphi1PhHdAgIni;
  float32 DelteSW0;
  float32 u;
  float32 Kw;
  float32 StpLngth;
  float32 Mode1Num;
  float32 Mode2Num;
  float32 D2_End;
  float32 DelteSW1;
  float32 K1;
  float32 K2_2;
  float32 T2;
  sint32 a;
  float32 K2;
  float32 c_T1;
  float32 c_T2;
  float32 K1_0;
  uint16 rtb_Add;
  uint16 rtb_Add_el;
  uint16 rtb_Add_o;
  uint16 rtb_Add_lr;
  uint16 rtb_Add_jn;
  uint16 rtb_Merge;
  uint16 rtb_Add_ey;

  /* Sum: '<S116>/Add' incorporates:
   *  Constant: '<S116>/Constant'
   *  Memory: '<S116>/Memory'
   */
  rtb_Add = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_p));

  /* Saturate: '<S116>/Saturation1' */
  if (rtb_Add < ((uint16)100U)) {
    rtb_Merge = rtb_Add;
  } else {
    rtb_Merge = ((uint16)100U);
  }

  /* End of Saturate: '<S116>/Saturation1' */

  /* If: '<S116>/If' incorporates:
   *  Constant: '<S116>/Constant19'
   *  Inport: '<S121>/In1'
   *  Memory: '<S110>/Memory'
   */
  if (rtb_Merge == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S116>/if action 2' incorporates:
     *  ActionPort: '<S122>/Action Port'
     */
    /* SignalConversion: '<S122>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
     *  Constant: '<S122>/Constant'
     */
    rtb_Merge = ((uint16)0U);

    /* End of Outputs for SubSystem: '<S116>/if action 2' */
  } else {
    /* Outputs for IfAction SubSystem: '<S116>/if action 1' incorporates:
     *  ActionPort: '<S121>/Action Port'
     */
    rtb_Merge = LKAS_DW.Memory_PreviousInput_de;

    /* End of Outputs for SubSystem: '<S116>/if action 1' */
  }

  /* End of If: '<S116>/If' */

  /* Sum: '<S117>/Add' incorporates:
   *  Constant: '<S117>/Constant'
   *  Memory: '<S117>/Memory'
   */
  rtb_Add_el = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_m5));

  /* Memory: '<S110>/Memory1' */
  rtb_Memory1 = LKAS_DW.Memory1_PreviousInput_a;

  /* Saturate: '<S117>/Saturation1' */
  if (rtb_Add_el < ((uint16)100U)) {
    rtb_Add_o = rtb_Add_el;
  } else {
    rtb_Add_o = ((uint16)100U);
  }

  /* End of Saturate: '<S117>/Saturation1' */

  /* If: '<S117>/If' incorporates:
   *  Constant: '<S117>/Constant19'
   */
  if (rtb_Add_o == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S117>/if action 4' incorporates:
     *  ActionPort: '<S124>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1);

    /* End of Outputs for SubSystem: '<S117>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S117>/if action 3' incorporates:
     *  ActionPort: '<S123>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory1, &rtb_Merge1);

    /* End of Outputs for SubSystem: '<S117>/if action 3' */
  }

  /* End of If: '<S117>/If' */

  /* Sum: '<S118>/Add' incorporates:
   *  Constant: '<S118>/Constant'
   *  Memory: '<S118>/Memory'
   */
  rtb_Add_o = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_j));

  /* Memory: '<S110>/Memory2' */
  rtb_Memory2 = LKAS_DW.Memory2_PreviousInput;

  /* Saturate: '<S118>/Saturation1' */
  if (rtb_Add_o < ((uint16)100U)) {
    rtb_Add_lr = rtb_Add_o;
  } else {
    rtb_Add_lr = ((uint16)100U);
  }

  /* End of Saturate: '<S118>/Saturation1' */

  /* If: '<S118>/If' incorporates:
   *  Constant: '<S118>/Constant19'
   */
  if (rtb_Add_lr == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S118>/if action 4' incorporates:
     *  ActionPort: '<S126>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_f);

    /* End of Outputs for SubSystem: '<S118>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S118>/if action 3' incorporates:
     *  ActionPort: '<S125>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory2, &rtb_Merge1_f);

    /* End of Outputs for SubSystem: '<S118>/if action 3' */
  }

  /* End of If: '<S118>/If' */

  /* Sum: '<S119>/Add' incorporates:
   *  Constant: '<S119>/Constant'
   *  Memory: '<S119>/Memory'
   */
  rtb_Add_lr = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_cb));

  /* Memory: '<S110>/Memory3' */
  rtb_Memory3 = LKAS_DW.Memory3_PreviousInput_o;

  /* Saturate: '<S119>/Saturation1' */
  if (rtb_Add_lr < ((uint16)100U)) {
    rtb_Add_jn = rtb_Add_lr;
  } else {
    rtb_Add_jn = ((uint16)100U);
  }

  /* End of Saturate: '<S119>/Saturation1' */

  /* If: '<S119>/If' incorporates:
   *  Constant: '<S119>/Constant19'
   */
  if (rtb_Add_jn == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S119>/if action 4' incorporates:
     *  ActionPort: '<S128>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_b);

    /* End of Outputs for SubSystem: '<S119>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S119>/if action 3' incorporates:
     *  ActionPort: '<S127>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory3, &rtb_Merge1_b);

    /* End of Outputs for SubSystem: '<S119>/if action 3' */
  }

  /* End of If: '<S119>/If' */

  /* Sum: '<S120>/Add' incorporates:
   *  Constant: '<S120>/Constant'
   *  Memory: '<S120>/Memory'
   */
  rtb_Add_jn = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_po));

  /* Memory: '<S110>/Memory4' */
  rtb_Memory4 = LKAS_DW.Memory4_PreviousInput;

  /* Saturate: '<S120>/Saturation1' */
  if (rtb_Add_jn < ((uint16)100U)) {
    rtb_Add_ey = rtb_Add_jn;
  } else {
    rtb_Add_ey = ((uint16)100U);
  }

  /* End of Saturate: '<S120>/Saturation1' */

  /* If: '<S120>/If' incorporates:
   *  Constant: '<S120>/Constant19'
   */
  if (rtb_Add_ey == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S120>/if action 4' incorporates:
     *  ActionPort: '<S130>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_i);

    /* End of Outputs for SubSystem: '<S120>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S120>/if action 3' incorporates:
     *  ActionPort: '<S129>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory4, &rtb_Merge1_i);

    /* End of Outputs for SubSystem: '<S120>/if action 3' */
  }

  /* End of If: '<S120>/If' */

  /* MATLAB Function: '<S110>/MATLAB Function' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLAB Function': '<S115>:1' */
  /* '<S115>:1:55' LDDir = K1K2Det_stLDDir; */
  /* '<S115>:1:56' D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S115>:1:57' D2_des = K1K2Det_lDesDvt; */
  /* '<S115>:1:58' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_as * 0.0174532924F;

  /* '<S115>:1:59' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S115>:1:60' TTLCHdAg = K1K2Det_phiTTLCHdAgIni; */
  /* '<S115>:1:61' Delte_Psi2 = K1K2Det_phi2PhDesHdAg; */
  /* '<S115>:1:62' Delte_Psi1Ini = K1K2Det_phi1PhDesHdAgIni; */
  /* '<S115>:1:63' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S115>:1:64' TTLCCrvt = K1K2Det_crPrvwTTLCCrvt; */
  /* '<S115>:1:65' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S115>:1:66' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S115>:1:67' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S115>:1:68' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_m / 3.6F;

  /* '<S115>:1:69' Kw=u/(L*(1+K*u*u)*i); */
  Kw = u / (((((LKAS_DW.StbFacm_SY * u) * u) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_f)
            * LKAS_DW.LKA_StrRatio_C_e);

  /*      DelteSW1 = single(0); */
  /* '<S115>:1:71' K1K2Det_stReplFlag = single(0); */
  rtb_K1K2Det_stReplFlag = 0.0F;

  /* '<S115>:1:72' StpLngth = K1K2Det_lStpLngth*(pi/180); */
  StpLngth = LKAS_DW.LL_lStpLngth_C_g * 0.0174532924F;

  /* '<S115>:1:73' ModeFlg = K1K2Det_bsTDivInfo_ModeFlg; */
  /* '<S115>:1:74' Mode1Num = K1K2Det_bsTDivInfo_Mode1Num; */
  Mode1Num = rtb_Merge1;

  /* '<S115>:1:75' Mode2Num = K1K2Det_bsTDivInfo_Mode2Num; */
  Mode2Num = rtb_Merge1_f;

  /* '<S115>:1:76' D2_End =  K1K2Det_bsTDivInfo_Ph2DvtEnd; */
  D2_End = rtb_Merge1_b;

  /* '<S115>:1:77' DelteSW1 = K1K2Det_bsTDivInfo_Ph2SWAIni; */
  DelteSW1 = rtb_Merge1_i;

  /* '<S115>:1:78' K1 = single(0); */
  K1 = 0.0F;

  /* '<S115>:1:79' K2_1 = single(0); */
  K2 = 0.0F;

  /* '<S115>:1:80' K2_2 = single(0); */
  K2_2 = 0.0F;

  /* '<S115>:1:81' KMax = K1K2Det_dphiSWARMax; */
  /* ************************************************************************** */
  /*  */
  /*  if (LDDir*PrvwHdAg < LDDir*TTLCHdAg) */
  /*      Delte_Psi1 = PrvwHdAg; */
  /*  else */
  /*      Delte_Psi1 = TTLCHdAg; */
  /*  end */
  /* '<S115>:1:89' Delte_Psi1 = PrvwHdAg; */
  /* '<S115>:1:90' if (ModeFlg == 0) */
  if (((sint32)rtb_Merge) == 0) {
    /* '<S115>:1:91' [K1,K2_1,K2_2,D2_End,DelteSW1]= func1(Delte_Psi1,TTLC,Kw,DelteSW0,Delte_Psi2,u,D1_Ini,Delte_Psi1Ini); */
    /*     ���ܣ� */
    /*     ��֪����ʼת����ת�ǣ�TTLC��һ����������Ǳ������뿪����ʱ����������� */
    /*     Լ����1��һ������ʱ����TTLCʱ��ʵ�������ĺ���Ǳ仯�� */
    /*           2����������ʱ��ת����ת��Ϊ�㣻 */
    /*           3����������ʱ��ʵ�������ĺ���ǵĺ���ǡ� */
    /*      */
    /*     ����� һ��ת����ת�Ǳ仯��K1������ת����ת�Ǳ仯��K2_1��K2_2����������ʱ��ƫ��������ֵD2 */
    /* ************************************************************************** */
    /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
    /*  end of function K1K2Det */
    /*  */
    /* ***************************************** */
    /*  1������func1�������������ʱ��ƫ��������ֵƫ����D2_0; */
    /*      */
    /*  2����D2_0<=D2_des������ú���func2�����������k1��k2_1��k2_2��ͬ���ڶ�������ʱ�� */
    /*     Ӧ��ͬʱʵ����������Ǻ�����ƫ������ */
    /*  3����D2_0>D2_des_max������ú���F,2�����������k1��k2_1��k2_2������k2_1 = k2_2�� */
    /*     �ڶ�������ʱ��Ӧ��ͬʱʵ����������Ǻ�����ƫ������ */
    /*  */
    /* '<S115>:1:168' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
    K1 = ((-2.0F * LKAS_DW.In_j) / ((Kw * LKAS_DW.MPInP_tiTTLCIni) *
           LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F * DelteSW0) /
      LKAS_DW.MPInP_tiTTLCIni);

    /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
    /* '<S115>:1:171' DelteSW1 = DelteSW0+K1*TTLC; */
    DelteSW1 = (K1 * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

    /* '<S115>:1:172' Delte_Psi = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1)*TTLC*Kw; */
    D2_End = ((((DelteSW0 + DelteSW1) * 0.5F) * LKAS_DW.MPInP_tiTTLCIni) * Kw) +
      LKAS_DW.In_o5;

    /* ����Լ��2��3���������K2�� */
    /* '<S115>:1:174' K2 = -DelteSW1*DelteSW1*Kw/(2*(Delte_Psi2-Delte_Psi)); */
    K2 = (((-DelteSW1) * DelteSW1) * Kw) / ((LKAS_DW.In_p - D2_End) * 2.0F);

    /* ����K2��DelteSW1�ͳ��٣����Լ��������������ƫ�����ı仯��D2�Ͷ�������ʱ��T2�� */
    /* '<S115>:1:176' T1 = (DelteSW1-DelteSW0)/K1; */
    c_T1 = (DelteSW1 - DelteSW0) / K1;

    /* '<S115>:1:177' T2 = (0-DelteSW1)/K2; */
    c_T2 = (0.0F - DelteSW1) / K2;

    /*      D1 = u*((1/6)*Kw*(2*DelteSW0+DelteSW1)*T1^2+Delte_Psi1*T1); */
    /*      D2 = u*((1/3)*Kw*T2^2*DelteSW1); */
    /* '<S115>:1:180' D1 = u*((1/6)*Kw*(DelteSW1+2*DelteSW0)*T1*T1+Delte_Psi1Ini*T1); */
    /* '<S115>:1:181' D2 = u*((1/3)*Kw*T2*T2*DelteSW1+Delte_Psi*T2); */
    /* '<S115>:1:182' D2_End = D1+D2; */
    /*  */
    /* ************************************************************************** */
    /* ����� */
    /*    K1 = K1; */
    /* '<S115>:1:187' K2_1 = K2; */
    /* '<S115>:1:188' K2_2 = K2; */
    K2_2 = K2;
    D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) * c_T1) *
                c_T1) + (LKAS_DW.In_o5 * c_T1)) * u) + ((((((0.333333343F * Kw) *
      c_T2) * c_T2) * DelteSW1) + (D2_End * c_T2)) * u);
  }

  /* '<S115>:1:93' if(0< D2_End*LDDir && D2_End*LDDir <= D2_des && ModeFlg == 0) */
  c_T1 = D2_End * LKAS_DW.Merge;
  if (((0.0F < c_T1) && (c_T1 <= LKAS_DW.LL_DesDvt_C_e)) && (((sint32)rtb_Merge)
       == 0)) {
    /* '<S115>:1:95' K1K2Det_stReplFlag = single(0); */
    rtb_K1K2Det_stReplFlag = 0.0F;
  } else {
    if ((c_T1 > LKAS_DW.LL_DesDvt_C_e) || (((sint32)rtb_Merge) != 0)) {
      /* '<S115>:1:97' elseif(D2_End*LDDir > D2_des || ModeFlg ~= 0 ) */
      /* '<S115>:1:99' K1K2Det_stReplFlag = single(1); */
      rtb_K1K2Det_stReplFlag = 1.0F;

      /* '<S115>:1:101' for a = 1:8 */
      for (a = 0; a < 8; a++) {
        /* '<S115>:1:103' if (D2_End*LDDir>D2_des && ModeFlg==0) */
        c_T1 = D2_End * LKAS_DW.Merge;
        if ((c_T1 > LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 0)) {
          /* '<S115>:1:104' ModeFlg = uint16(1); */
          rtb_Merge = 1U;
        }

        /* '<S115>:1:106' if (D2_End*LDDir>D2_des && ModeFlg==1) */
        if ((c_T1 > LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 1)) {
          /* '<S115>:1:107' DelteSW1 =  LDDir*StpLngth+DelteSW1; */
          DelteSW1 += LKAS_DW.Merge * StpLngth;

          /* '<S115>:1:108' Mode1Num = Mode1Num+1; */
          Mode1Num++;
        }

        /* '<S115>:1:110' if (D2_End*LDDir <= D2_des && ModeFlg==1) */
        if ((c_T1 <= LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 1)) {
          /* '<S115>:1:111' ModeFlg = uint16(2); */
          rtb_Merge = 2U;
        }

        /* '<S115>:1:113' if (D2_End*LDDir<D2_des && ModeFlg==2) */
        if ((c_T1 < LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 2)) {
          /* '<S115>:1:114' DelteSW1 =  DelteSW1-LDDir*StpLngth*((1/2)^(Mode2Num+1)); */
          DelteSW1 -= (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);

          /* '<S115>:1:115' Mode2Num = Mode2Num+1; */
          Mode2Num++;
        }

        /* '<S115>:1:117' if (D2_End*LDDir>=D2_des && ModeFlg==2) */
        if ((c_T1 >= LKAS_DW.LL_DesDvt_C_e) && (((sint32)rtb_Merge) == 2)) {
          /* '<S115>:1:118' DelteSW1 =  DelteSW1+LDDir*StpLngth*((1/2)^(Mode2Num+1)); */
          DelteSW1 += (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);

          /* '<S115>:1:119' Mode2Num = Mode2Num+1; */
          Mode2Num++;
        }

        /* '<S115>:1:121' [T1,T2,D2_End] = func3(Delte_Psi1Ini,Delte_Psi2,DelteSW1,KMax,Delte_Psi1,... */
        /* '<S115>:1:122'                                 DelteSW0,u,Kw,LDDir); */
        /*     ���ܣ� */
        /*     ��֪������һ��ʱ��ʼ����ǣ��뿪����ʱ����������ǣ�����һ��ʱ��ƫ�����ĳ�ʼֵ */
        /*           �������ʱ��ת����ת�ǳ�ʼֵ����ʼת����ת�ǣ����١� */
        /*     ���裺1������һ������ʱ��ת����ת�ǣ�ʵ��һ���������ĺ���Ǳ仯�� */
        /*           2������һ������ʱ��ת����ת�ǣ�ʵ�ֶ����������ĺ���Ǳ仯�� */
        /*           3������ʵ��һ���������ĺ���Ǳ仯����������һ��ƫ�����仯��D1�� */
        /*           4������ʵ�ֶ����������ĺ���Ǳ仯���������Ķ���ƫ�����仯��D2�� */
        /*           5) ���ݽ���һ��ʱ��ƫ�����ĳ�ʼֵ��D1��D2���õ���������ʱ��ƫ����D2_End */
        /*      */
        /*     ����� һ��ʹ��ʱ��T1������ʹ��ʱ��T2����������ʱ��ƫ����D2_End */
        /* ************************************************************************** */
        /*  end of function func1 */
        /*  function [K1,K2_1,K2_2,DelteSW1]= func2(Delte_Psi1,Delte_Psi2,D1_Ini,T1,... */
        /*                                          D2_des,LDDir,DelteSW0,u,Kw) */
        /*  %    ���ܣ� */
        /*  %    ��֪��һ����������Ǳ仯�����뿪����ʱ����������ǣ���������ʱ������ƫ�����ľ���ֵ */
        /*  %          �����ĳ���ƫ��ķ��򣬳�ʼת����ת�ǣ����١� */
        /*  %    Լ����1������һ������ʱ��ת����ת�ǣ�ʵ�������ĺ���Ǳ仯�� */
        /*  %          2����������ʱ��ƫ����ʵ������ƫ������ */
        /*  %          3����������ʱ��ʵ�������ĺ���ǵĺ���ǣ� */
        /*  %          4����������ʱ��ת����ת��Ϊ�㡣 */
        /*  %     */
        /*  %    ����� һ��ת����ת�Ǳ仯��K1������ת����ת�Ǳ仯��K2_1��K2_2�� */
        /*  %           �������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
        /*  %************************************************************************** */
        /*  %   ����Լ��2��3��4���������DelteSW1�Ͷ���ת����ת�Ǳ仯�ʡ� */
        /*  Delte_D = LDDir*D2_des-D1_Ini; */
        /*  Delte_Psi = Delte_Psi2-Delte_Psi1; */
        /*  DelteSW1 = ((4/3)*(Delte_Psi/Kw)*(Delte_Psi/Kw)-(1/3)*(Delte_Psi/Kw)*DelteSW0*T1-(1/6)*DelteSW0*DelteSW0*T1*T1... */
        /*              +2*(Delte_Psi/Kw)*Delte_Psi1-Delte_Psi1*DelteSW0*T1)/(Delte_D/(Kw*u)+(1/3)*(Delte_Psi/Kw)*T1); */
        /*  T2 = (2*(Delte_Psi/Kw)-(DelteSW1+DelteSW0)*T1)/DelteSW1; */
        /*  K2 = -DelteSW1/T2; */
        /*  %   ����Լ��1�ͽ������ʱ��ת����ת�ǳ�ʼֵDelteSW1���������һ��ת����ת�Ǳ仯�ʡ� */
        /*  K1 = (DelteSW1-DelteSW0)/T1; */
        /*  % */
        /*  %************************************************************************** */
        /*  %   ����� */
        /*  K2_1 = K2; */
        /*  K2_2 = K2; */
        /*   */
        /*  end % end of function func1 */
        /* '<S115>:1:233' K1_0 = (DelteSW1*DelteSW1-DelteSW0*DelteSW0)*Kw/(-2*Delte_Psi1); */
        K1_0 = (((DelteSW1 * DelteSW1) - (DelteSW0 * DelteSW0)) * Kw) / (-2.0F *
          LKAS_DW.In_j);

        /* '<S115>:1:234' if (LDDir*K1_0 > KMax) */
        if ((LKAS_DW.Merge * K1_0) > LKAS_DW.SWARmax) {
          /* '<S115>:1:235' K1_1 = single(LDDir*KMax); */
          K1_0 = LKAS_DW.Merge * LKAS_DW.SWARmax;
        } else {
          /* '<S115>:1:236' else */
          /* '<S115>:1:237' K1_1 = K1_0; */
        }

        /*  */
        /* '<S115>:1:240' T1 = (DelteSW1-DelteSW0)/K1_1; */
        K1_0 = (DelteSW1 - DelteSW0) / K1_0;

        /* '<S115>:1:243' Delte_Psi = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1)*T1*Kw; */
        K1 = ((((DelteSW0 + DelteSW1) * 0.5F) * K1_0) * Kw) + LKAS_DW.In_o5;

        /*  DelteSW1_0 = 2*(Delte_Psi2-Delte_Psi1Ini)/(T1*Kw)-DelteSW0; */
        /*  if (-1*Delte_Psi >= -1*Delte_Psi2) */
        /*     DelteSW1_1 = DelteSW1_0; */
        /*  else */
        /*     DelteSW1_1 = DelteSW1; */
        /*  end */
        /*  Delte_Psi_1 = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1_1)*T1*Kw; */
        /* '<S115>:1:251' T2 = 2*(Delte_Psi2-Delte_Psi)/(DelteSW1*Kw); */
        T2 = ((LKAS_DW.In_p - K1) * 2.0F) / (DelteSW1 * Kw);

        /*      T1 = 2*(Delte_Psi-Delte_Psi1)/((DelteSW0+DelteSW1)*Kw); */
        /*      T1 = TTLC; */
        /*      T2 = 2*(Delte_Psi2-Delte_Psi)/(DelteSW1*Kw); */
        /* '<S115>:1:256' D1 = u*((1/6)*Kw*(DelteSW1+2*DelteSW0)*T1*T1+Delte_Psi1Ini*T1); */
        /* '<S115>:1:257' D2 = u*((1/3)*Kw*T2*T2*DelteSW1+Delte_Psi*T2); */
        /* '<S115>:1:258' D2_End = D2+D1; */
        D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) *
                     K1_0) * K1_0) + (LKAS_DW.In_o5 * K1_0)) * u) +
          ((((((0.333333343F * Kw) * T2) * T2) * DelteSW1) + (K1 * T2)) * u);
      }

      /* '<S115>:1:124' K1 = (DelteSW1-DelteSW0)/T1; */
      K1 = (DelteSW1 - DelteSW0) / K1_0;

      /* '<S115>:1:125' K2_1 = (0-DelteSW1)/T2; */
      K2 = (0.0F - DelteSW1) / T2;

      /* '<S115>:1:126' K2_2 = K2_1; */
      K2_2 = K2;
    }
  }

  /*  */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S115>:1:130' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S115>:1:132' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = K1 * 57.2957802F;

  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /* '<S115>:1:134' K1K2Det_dphi2PhSWAGrad1 = K2_1*(180/pi); */
  LKAS_DW.K1K2Det_dphi2PhSWAGrad1 = K2 * 57.2957802F;

  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /* '<S115>:1:136' K1K2Det_dphi2PhSWAGrad2 = K2_2*(180/pi); */
  rtb_K1K2Det_dphi2PhSWAGrad2 = K2_2 * 57.2957802F;

  /*  */
  /* '<S115>:1:138' K1K2Det_dphi1PhHdAgIni = Delte_Psi1; */
  rtb_K1K2Det_dphi1PhHdAgIni = LKAS_DW.In_j;

  /* Update for Memory: '<S116>/Memory' */
  /*  */
  /* '<S115>:1:140' K1K2Det_bsTDivInfoOut_ModeFlg = ModeFlg; */
  /* '<S115>:1:141' K1K2Det_bsTDivInfoOut_Mode1Num = Mode1Num; */
  /* '<S115>:1:142' K1K2Det_bsTDivInfoOut_Mode2Num = Mode2Num; */
  /* '<S115>:1:143' K1K2Det_bsTDivInfoOut_Ph2DvtEnd = D2_End; */
  /* '<S115>:1:144' K1K2Det_bsTDivInfoOut_Ph2SWAIni = DelteSW1; */
  LKAS_DW.Memory_PreviousInput_p = rtb_Add;

  /* Update for Memory: '<S110>/Memory' incorporates:
   *  MATLAB Function: '<S110>/MATLAB Function'
   */
  LKAS_DW.Memory_PreviousInput_de = rtb_Merge;

  /* Update for Memory: '<S117>/Memory' */
  LKAS_DW.Memory_PreviousInput_m5 = rtb_Add_el;

  /* Update for Memory: '<S110>/Memory1' incorporates:
   *  MATLAB Function: '<S110>/MATLAB Function'
   */
  LKAS_DW.Memory1_PreviousInput_a = Mode1Num;

  /* Update for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = rtb_Add_o;

  /* Update for Memory: '<S110>/Memory2' incorporates:
   *  MATLAB Function: '<S110>/MATLAB Function'
   */
  LKAS_DW.Memory2_PreviousInput = Mode2Num;

  /* Update for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_cb = rtb_Add_lr;

  /* Update for Memory: '<S110>/Memory3' incorporates:
   *  MATLAB Function: '<S110>/MATLAB Function'
   */
  LKAS_DW.Memory3_PreviousInput_o = D2_End;

  /* Update for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_po = rtb_Add_jn;

  /* Update for Memory: '<S110>/Memory4' incorporates:
   *  MATLAB Function: '<S110>/MATLAB Function'
   */
  LKAS_DW.Memory4_PreviousInput = DelteSW1;
}

/*
 * Output and update for action system:
 *    '<S134>/if action '
 *    '<S135>/if action '
 *    '<S136>/if action '
 *    '<S137>/if action '
 *    '<S138>/if action '
 *    '<S139>/if action '
 *    '<S140>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S151>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S166>/If Action Subsystem'
 *    '<S166>/If Action Subsystem4'
 *    '<S114>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S168>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S182>/If Action Subsystem'
 *    '<S182>/If Action Subsystem1'
 *    '<S182>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem_e(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S184>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S203>/if action '
 *    '<S204>/if action '
 *    '<S211>/if action '
 *    '<S212>/if action '
 */
void LKAS_ifaction_f(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S205>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S196>/If Action Subsystem'
 *    '<S197>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_j(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_p_T *localDW)
{
  uint16 rtb_Saturation1_a;
  uint16 rtb_Saturation1_i;

  /* Outputs for Enabled SubSystem: '<S196>/If Action Subsystem' incorporates:
   *  EnablePort: '<S201>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S203>/Add' incorporates:
     *  Constant: '<S203>/Constant'
     *  Memory: '<S203>/Memory'
     */
    rtb_Saturation1_a = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S203>/Saturation1' */
    if (rtb_Saturation1_a >= ((uint16)10000U)) {
      rtb_Saturation1_a = ((uint16)10000U);
    }

    /* End of Saturate: '<S203>/Saturation1' */

    /* If: '<S203>/If' incorporates:
     *  Constant: '<S203>/Constant2'
     */
    if (rtb_Saturation1_a <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S203>/if action ' incorporates:
       *  ActionPort: '<S205>/Action Port'
       */
      LKAS_ifaction_f(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S203>/if action ' */
    }

    /* End of If: '<S203>/If' */

    /* Sum: '<S204>/Add' incorporates:
     *  Constant: '<S204>/Constant'
     *  Memory: '<S204>/Memory'
     */
    rtb_Saturation1_i = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_p));

    /* Saturate: '<S204>/Saturation1' */
    if (rtb_Saturation1_i >= ((uint16)10000U)) {
      rtb_Saturation1_i = ((uint16)10000U);
    }

    /* End of Saturate: '<S204>/Saturation1' */

    /* If: '<S204>/If' incorporates:
     *  Constant: '<S204>/Constant2'
     */
    if (rtb_Saturation1_i == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S204>/if action ' incorporates:
       *  ActionPort: '<S206>/Action Port'
       */
      LKAS_ifaction_f(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S204>/if action ' */
    }

    /* End of If: '<S204>/If' */

    /* Update for Memory: '<S203>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_a;

    /* Update for Memory: '<S204>/Memory' */
    localDW->Memory_PreviousInput_p = rtb_Saturation1_i;
  }

  /* End of Outputs for SubSystem: '<S196>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S196>/If Action Subsystem2'
 *    '<S197>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_l(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S202>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S202>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S76>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_m = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_f = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c67_LKAS = 0U;
  LKAS_DW.is_c67_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.LDWSM_stLDWActvFlg = 0U;
  LKAS_DW.LDWSM_stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S76>/LDW_State_Machine'
 * Block description for: '<S76>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S76>/LDW_State_Machine'
   *
   * Block description for '<S76>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c67_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c67_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S260>:2' */
    LKAS_DW.is_c67_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S260>:1' */
    /* Transition: '<S260>:31' */
    LKAS_DW.is_SysOff_m = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S260>:30' */
    LKAS_DW.LDWSM_stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c67_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S260>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && ((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) ==
            2))) {
        /* Transition: '<S260>:38' */
        /* Exit Internal 'Fault': '<S260>:36' */
        LKAS_DW.is_c67_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S260>:3' */
        /* Transition: '<S260>:77' */
        LKAS_DW.is_SysOn_f = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S260>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.Divide) == 0) && tmp) {
        /* Transition: '<S260>:40' */
        /* Exit Internal 'Fault': '<S260>:36' */
        LKAS_DW.is_c67_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_m = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S260>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else {
        LKAS_DW.LDWSM_stLDWState = 6U;

        /* During 'LDWFault': '<S260>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S260>:1' */
      if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
          (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S260>:39' */
        /* Exit Internal 'SysOff': '<S260>:1' */
        LKAS_DW.is_SysOff_m = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c67_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S260>:36' */
        /* Transition: '<S260>:75' */
        /* Entry 'LDWFault': '<S260>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) ==
                  2)) {
        /* Transition: '<S260>:41' */
        /* Exit Internal 'SysOff': '<S260>:1' */
        LKAS_DW.is_SysOff_m = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c67_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S260>:3' */
        /* Transition: '<S260>:77' */
        LKAS_DW.is_SysOn_f = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S260>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_m) == LKAS_IN_Unavailable) {
        LKAS_DW.LDWSM_stLDWState = 0U;

        /* During 'Unavailable': '<S260>:30' */
        if (((sint32)LKAS_DW.Divide) == 0) {
          /* Transition: '<S260>:35' */
          LKAS_DW.is_SysOff_m = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S260>:32' */
          LKAS_DW.LDWSM_stLDWState = 1U;
        }
      } else {
        LKAS_DW.LDWSM_stLDWState = 1U;

        /* During 'Unselected': '<S260>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S260>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S260>:37' */
        /* Exit Internal 'SysOn': '<S260>:3' */
        if (((uint32)LKAS_DW.is_SysOn_f) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S260>:102' */
          switch (LKAS_DW.is_Normal_p) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S260>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S260>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_f = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_f = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c67_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S260>:36' */
        /* Transition: '<S260>:75' */
        /* Entry 'LDWFault': '<S260>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.Divide) != 1) && (((sint32)LKAS_DW.Divide) !=
                  2)) {
        /* Transition: '<S260>:42' */
        /* Exit Internal 'SysOn': '<S260>:3' */
        if (((uint32)LKAS_DW.is_SysOn_f) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S260>:102' */
          switch (LKAS_DW.is_Normal_p) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S260>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S260>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_f = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_f = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c67_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_m = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S260>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_f) == LKAS_IN_LDWSelected) {
        LKAS_DW.LDWSM_stLDWState = 2U;

        /* During 'LDWSelected': '<S260>:47' */
        if ((LKAS_DW.Merge_d) && (!LKAS_DW.Merge1_n)) {
          /* Transition: '<S260>:50' */
          LKAS_DW.is_SysOn_f = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S260>:102' */
          /* Transition: '<S260>:113' */
          LKAS_DW.is_Normal_p = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S260>:112' */
          LKAS_DW.LDWSM_stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S260>:102' */
        if (LKAS_DW.Merge1_n) {
          /* Transition: '<S260>:44' */
          /* Exit Internal 'Normal': '<S260>:102' */
          switch (LKAS_DW.is_Normal_p) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S260>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S260>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_p = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_f = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S260>:47' */
          LKAS_DW.LDWSM_stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_p) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.LDWSM_stLDWState = 3U;

            /* During 'LDWEnable': '<S260>:112' */
            if ((((sint32)LKAS_DW.Merge_k) == 1) && (!LKAS_DW.Merge_o)) {
              /* Transition: '<S260>:118' */
              LKAS_DW.is_Normal_p = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S260>:114' */
              LKAS_DW.LDWSM_stLDWState = 4U;
              LKAS_DW.LDWSM_stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.Merge_k) == 2) && (!LKAS_DW.Merge_o)) {
                /* Transition: '<S260>:119' */
                LKAS_DW.is_Normal_p = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S260>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.LDWSM_stLDWState = 4U;

            /* During 'LDWLeftActive': '<S260>:114' */
            if (LKAS_DW.Merge_o) {
              /* Transition: '<S260>:116' */
              /* Exit 'LDWLeftActive': '<S260>:114' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_p = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S260>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.Merge_k) == 2) && (!LKAS_DW.Merge_o)) {
                /* Transition: '<S260>:120' */
                /* Exit 'LDWLeftActive': '<S260>:114' */
                LKAS_DW.is_Normal_p = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S260>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LDWSM_stLDWState = 5U;

            /* During 'LDWRightActive': '<S260>:115' */
            if (LKAS_DW.Merge_o) {
              /* Transition: '<S260>:117' */
              /* Exit 'LDWRightActive': '<S260>:115' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_p = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S260>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.Merge_k) == 1) && (!LKAS_DW.Merge_o)) {
                /* Transition: '<S260>:121' */
                /* Exit 'LDWRightActive': '<S260>:115' */
                LKAS_DW.is_Normal_p = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S260>:114' */
                LKAS_DW.LDWSM_stLDWState = 4U;
                LKAS_DW.LDWSM_stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S76>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S76>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_h;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
  LKAS_DW.is_active_c68_LKAS = 0U;
  LKAS_DW.is_c68_LKAS = LKAS_IN_NO_ACTIVE_CHILD_h;
  LKAS_DW.LKASM_stLKAActvFlg = 0U;
  LKAS_DW.LKASM_stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S76>/LKA_State_Machine'
 * Block description for: '<S76>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S76>/LKA_State_Machine'
   *
   * Block description for '<S76>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  if (((uint32)LKAS_DW.is_active_c68_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    LKAS_DW.is_active_c68_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    /* Transition: '<S261>:2' */
    LKAS_DW.is_c68_LKAS = LKAS_IN_SysOff_k;

    /* Entry Internal 'SysOff': '<S261>:1' */
    /* Transition: '<S261>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_n;

    /* Entry 'Unavailable': '<S261>:30' */
    LKAS_DW.LKASM_stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c68_LKAS) {
     case LKAS_IN_Fault_i:
      /* During 'Fault': '<S261>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.Divide) == 2)) {
        /* Transition: '<S261>:38' */
        /* Exit Internal 'Fault': '<S261>:36' */
        LKAS_DW.is_c68_LKAS = LKAS_IN_SysOn_d;

        /* Entry Internal 'SysOn': '<S261>:3' */
        /* Transition: '<S261>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S261>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.Divide) == 0) || (((sint32)LKAS_DW.Divide) ==
        1)) && tmp) {
        /* Transition: '<S261>:40' */
        /* Exit Internal 'Fault': '<S261>:36' */
        LKAS_DW.is_c68_LKAS = LKAS_IN_SysOff_k;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_c;

        /* Entry 'Unselected': '<S261>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else {
        LKAS_DW.LKASM_stLKAState = 6U;

        /* During 'LKAFault': '<S261>:72' */
      }
      break;

     case LKAS_IN_SysOff_k:
      /* During 'SysOff': '<S261>:1' */
      if ((((sint32)LKAS_DW.Divide) == 2) && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S261>:39' */
        /* Exit Internal 'SysOff': '<S261>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_h;
        LKAS_DW.is_c68_LKAS = LKAS_IN_Fault_i;

        /* Entry Internal 'Fault': '<S261>:36' */
        /* Transition: '<S261>:74' */
        /* Entry 'LKAFault': '<S261>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.Divide) == 2) {
        /* Transition: '<S261>:41' */
        /* Exit Internal 'SysOff': '<S261>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_h;
        LKAS_DW.is_c68_LKAS = LKAS_IN_SysOn_d;

        /* Entry Internal 'SysOn': '<S261>:3' */
        /* Transition: '<S261>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S261>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_n) {
        LKAS_DW.LKASM_stLKAState = 0U;

        /* During 'Unavailable': '<S261>:30' */
        if ((((sint32)LKAS_DW.Divide) == 0) || (((sint32)LKAS_DW.Divide) == 1))
        {
          /* Transition: '<S261>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_c;

          /* Entry 'Unselected': '<S261>:32' */
          LKAS_DW.LKASM_stLKAState = 1U;
        }
      } else {
        LKAS_DW.LKASM_stLKAState = 1U;

        /* During 'Unselected': '<S261>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S261>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S261>:37' */
        /* Exit Internal 'SysOn': '<S261>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_d) {
          /* Exit Internal 'Normal': '<S261>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S261>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S261>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
        }

        LKAS_DW.is_c68_LKAS = LKAS_IN_Fault_i;

        /* Entry Internal 'Fault': '<S261>:36' */
        /* Transition: '<S261>:74' */
        /* Entry 'LKAFault': '<S261>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.Divide) != 2) {
        /* Transition: '<S261>:42' */
        /* Exit Internal 'SysOn': '<S261>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_d) {
          /* Exit Internal 'Normal': '<S261>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S261>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S261>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
        }

        LKAS_DW.is_c68_LKAS = LKAS_IN_SysOff_k;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_c;

        /* Entry 'Unselected': '<S261>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.LKASM_stLKAState = 2U;

        /* During 'LKASelected': '<S261>:19' */
        if ((LKAS_DW.Merge1_p) && (!LKAS_DW.Merge2_l)) {
          /* Transition: '<S261>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_d;

          /* Entry Internal 'Normal': '<S261>:102' */
          /* Transition: '<S261>:103' */
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S261>:108' */
          LKAS_DW.LKASM_stLKAState = 3U;
        }
      } else {
        /* During 'Normal': '<S261>:102' */
        if (LKAS_DW.Merge2_l) {
          /* Transition: '<S261>:25' */
          /* Exit Internal 'Normal': '<S261>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S261>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S261>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

          /* Entry 'LKASelected': '<S261>:19' */
          LKAS_DW.LKASM_stLKAState = 2U;
        } else {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKAEnable:
            LKAS_DW.LKASM_stLKAState = 3U;

            /* During 'LKAEnable': '<S261>:108' */
            if ((((sint32)LKAS_DW.Merge2) == 1) && (!LKAS_DW.Merge1_g)) {
              /* Transition: '<S261>:105' */
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

              /* Entry 'LKALeftActive': '<S261>:109' */
              LKAS_DW.LKASM_stLKAState = 4U;
              LKAS_DW.LKASM_stLKAActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.Merge2) == 2) && (!LKAS_DW.Merge1_g)) {
                /* Transition: '<S261>:104' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S261>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LKALeftActive:
            LKAS_DW.LKASM_stLKAState = 4U;

            /* During 'LKALeftActive': '<S261>:109' */
            if (LKAS_DW.Merge1_g) {
              /* Transition: '<S261>:106' */
              /* Exit 'LKALeftActive': '<S261>:109' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S261>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.Merge2) == 2) && (!LKAS_DW.Merge1_g)) {
                /* Transition: '<S261>:111' */
                /* Exit 'LKALeftActive': '<S261>:109' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S261>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LKASM_stLKAState = 5U;

            /* During 'LKARightActive': '<S261>:110' */
            if (LKAS_DW.Merge1_g) {
              /* Transition: '<S261>:107' */
              /* Exit 'LKARightActive': '<S261>:110' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S261>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.Merge2) == 1) && (!LKAS_DW.Merge1_g)) {
                /* Transition: '<S261>:112' */
                /* Exit 'LKARightActive': '<S261>:110' */
                LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

                /* Entry 'LKALeftActive': '<S261>:109' */
                LKAS_DW.LKASM_stLKAState = 4U;
                LKAS_DW.LKASM_stLKAActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S76>/LKA_State_Machine' */
}

/*
 * Output and update for atomic system:
 *    '<S278>/MATLAB Function'
 *    '<S314>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_LaneWidth, float32 rtu_LKA_CarWidth,
  float32 rtu_DvtThresUprLDW, float32 *rty_ThresDet_coefficient)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S281>:1' */
  /* '<S281>:1:2' LanWid = single(min(max(single(2.4),LaneWidth),single(3.6))); */
  /* '<S281>:1:3' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
  /* '<S281>:1:4' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
  *rty_ThresDet_coefficient = fminf(fmaxf(0.0F, (fminf(fmaxf(2.4F, rtu_LaneWidth),
    3.6F) - ((2.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth)) / (4.0F *
    rtu_DvtThresUprLDW)), 1.0F);
}

/*
 * Output and update for action system:
 *    '<S282>/Ph1SWA'
 *    '<S291>/Ph1SWA'
 *    '<S318>/Ph1SWA'
 *    '<S327>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S286>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S286>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S282>/Ph2SWA'
 *    '<S291>/Ph2SWA'
 *    '<S318>/Ph2SWA'
 *    '<S327>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S287>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S287>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S282>/Ph3SWA'
 *    '<S318>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S288>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S291>/Ph3SWA'
 *    '<S327>/Ph3SWA'
 */
void LKAS_Ph3SWA_l(float32 *rty_Out)
{
  /* SignalConversion: '<S297>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S297>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S340>/If Action Subsystem3'
 *    '<S379>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S345>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S353>/If Action Subsystem4'
 *    '<S353>/If Action Subsystem3'
 *    '<S462>/If Action Subsystem3'
 *    '<S462>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S365>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S365>/Constant'
   */
  *rty_Out = false;
}

/*
 * Output and update for action system:
 *    '<S391>/If Action Subsystem'
 *    '<S391>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_ei(boolean *rty_Out)
{
  /* SignalConversion: '<S395>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S395>/Constant'
   */
  *rty_Out = true;
}

/*
 * System initialize for enable system:
 *    '<S267>/Count_5s1'
 *    '<S267>/Count_5s2'
 */
void LKAS_Count_5s1_Init(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S529>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S267>/Count_5s1'
 *    '<S267>/Count_5s2'
 */
void LKAS_Count_5s1_Reset(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S529>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S267>/Count_5s1'
 *    '<S267>/Count_5s2'
 */
void LKAS_Count_5s1_Disable(boolean *rty_Out, DW_Count_5s1_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S267>/Count_5s1' incorporates:
   *  EnablePort: '<S529>/Enable'
   */
  /* Disable for Outport: '<S529>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S267>/Count_5s1' */
  localDW->Count_5s1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S267>/Count_5s1'
 *    '<S267>/Count_5s2'
 */
void LKAS_Count_5s1(boolean rtu_Enable, float32 rtu_SampleTime, boolean *rty_Out,
                    DW_Count_5s1_LKAS_T *localDW)
{
  float32 rtb_Saturation_ne;

  /* Outputs for Enabled SubSystem: '<S267>/Count_5s1' incorporates:
   *  EnablePort: '<S529>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Reset(localDW);
      localDW->Count_5s1_MODE = true;
    }

    /* Sum: '<S529>/Add' incorporates:
     *  Memory: '<S529>/Memory'
     */
    rtb_Saturation_ne = localDW->Memory_PreviousInput + rtu_SampleTime;

    /* Saturate: '<S529>/Saturation' */
    if (rtb_Saturation_ne > 11.0F) {
      rtb_Saturation_ne = 11.0F;
    } else {
      if (rtb_Saturation_ne < 0.0F) {
        rtb_Saturation_ne = 0.0F;
      }
    }

    /* End of Saturate: '<S529>/Saturation' */

    /* RelationalOperator: '<S529>/Relational Operator' incorporates:
     *  Constant: '<S529>/Constant1'
     */
    *rty_Out = (rtb_Saturation_ne >= ((float32)((uint16)5U)));

    /* Update for Memory: '<S529>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_ne;
  } else {
    if (localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S267>/Count_5s1' */
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_IMAPve_g_ESC_VehSpd;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_Gain_d;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_Gain_kz;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_LFClb_TFC_DiffCtrlRatio;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_R0_VR_h;
  float32 rtb_L0_VR_m;
  float32 rtb_R0_W_p;
  float32 rtb_L0_W_k;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_EPS_SteeringAngle;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L0_C0_lb;
  float32 rtb_L0_C1_n;
  float32 rtb_L0_C2_k;
  float32 rtb_L0_C3_d;
  float32 rtb_IMAPve_g_L0_Confidence;
  float32 rtb_L0_TLC_h;
  float32 rtb_L0_VR_o;
  float32 rtb_L0_W_j;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_IMAPve_g_L1_Confidence;
  float32 rtb_L1_TLC;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_L1_C0_a;
  float32 rtb_L1_C1_h;
  float32 rtb_L1_C2_e;
  float32 rtb_L1_C3_g;
  float32 rtb_L1_TLC_e;
  float32 rtb_L1_VR_b;
  float32 rtb_L1_W_m;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_TLC;
  float32 rtb_R1_VR;
  float32 rtb_R1_W;
  float32 rtb_R0_C0_o;
  float32 rtb_R0_C1_c;
  float32 rtb_R0_C2_l;
  float32 rtb_R0_C3_d;
  float32 rtb_IMAPve_g_R0_Confidence;
  float32 rtb_R0_TLC_d;
  float32 rtb_R0_VR_g;
  float32 rtb_R0_W_c;
  float32 rtb_R1_C0_e;
  float32 rtb_R1_C1_l;
  float32 rtb_R1_C2_h;
  float32 rtb_R1_C3_m;
  float32 rtb_IMAPve_g_R1_Confidence;
  float32 rtb_R1_TLC_f;
  float32 rtb_R1_VR_e;
  float32 rtb_R1_W_d;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_e;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1;
  float32 rtb_Add5_k;
  float32 rtb_Add_hf;
  float32 rtb_Add_g5;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge_i;
  float32 rtb_Switch_k;
  float32 rtb_Saturation_j;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Add1_k;
  float32 rtb_Switch_m;
  float32 rtb_Switch2;
  float32 rtb_Switch_e;
  float32 rtb_Saturation_h;
  float32 rtb_Abs1_m;
  float32 rtb_Abs_p;
  float32 rtb_UnaryMinus_p;
  float32 rtb_Merge1_j;
  float32 rtb_Divide_h;
  float32 rtb_Switch_n;
  float32 rtb_Switch2_j;
  float32 rtb_Divide_i;
  float32 rtb_Switch_ki;
  float32 rtb_Switch2_n;
  float32 rtb_Merge1_m;
  float32 rtb_Divide_j;
  float32 rtb_Switch_d;
  float32 rtb_Switch2_m;
  float32 rtb_Divide_m;
  float32 rtb_Switch_g;
  float32 rtb_Switch2_i;
  float32 rtb_Add1_j;
  float32 rtb_Switch_o;
  float32 rtb_Switch2_p;
  float32 rtb_Memory_g;
  float32 rtb_Merge1_e;
  float32 rtb_Divide_it;
  float32 rtb_Switch_on;
  float32 rtb_Switch2_f;
  float32 rtb_Divide_pg;
  float32 rtb_Switch_gf;
  float32 rtb_Switch2_l;
  float32 rtb_Memory_b;
  float32 rtb_Merge1_bm;
  float32 rtb_Divide_c;
  float32 rtb_Switch_g0;
  float32 rtb_Switch2_ni;
  float32 rtb_Divide_g;
  float32 rtb_Switch_kp;
  float32 rtb_Switch2_ll;
  float32 rtb_phiHdAg;
  float32 rtb_Add_p;
  float32 rtb_Add_mw;
  float32 rtb_Add_ns;
  float32 rtb_Add_f;
  float32 rtb_LKA_ExitFlg_Mon;
  float32 rtb_LKA_SampleTime_Mon;
  float32 rtb_T1_Mon;
  float32 rtb_RGTTTLC_Mon;
  float32 rtb_LFTTTLC_Mon;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_ThresDet_coefficient;
  float32 rtb_ThresDet_coefficient_c;
  float32 rtb_Saturation2;
  float32 rtb_Merge_j;
  float32 rtb_Abs1_d;
  float32 rtb_Abs_f;
  float32 rtb_Add1_h;
  float32 rtb_Merge_m;
  float32 rtb_Merge_me;
  float32 rtb_Merge_n;
  float32 rtb_Add_fh;
  float32 rtb_Saturation6_g;
  float32 rtb_Saturation2_f;
  float32 rtb_Saturation2_k;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_g;
  float32 rtb_Saturation_d;
  float32 rtb_Add1_m;
  float32 rtb_Saturation_n;
  float32 rtb_Switch2_o;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_b;
  float32 rtb_Divide5;
  float32 rtb_Divide2_n;
  float32 rtb_Divide7;
  float32 rtb_Switch_ns;
  float32 rtb_Switch2_e;
  float32 rtb_Saturation_oq;
  float32 rtb_Switch_j;
  float32 rtb_Add_i;
  float32 rtb_Switch_gr;
  float32 rtb_Switch2_k;
  float32 rtb_UkYk1;
  float32 rtb_Switch_mh;
  float32 rtb_Switch2_ll4;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_j4;
  float32 rtb_Saturation_i;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_T2;
  float32 rtb_Plan;
  float32 rtb_T1_j;
  float32 rtb_Plan_b;
  float32 rtb_T1_n;
  float32 rtb_Yk1_f;
  float32 rtb_deltafalllimit_j;
  float32 rtb_Saturation4;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_p;
  uint16 rtb_Saturation1_c;
  uint16 rtb_Saturation1_g;
  uint16 rtb_Add_iy;
  uint16 rtb_Saturation1_f;
  uint16 rtb_Saturation1_p2;
  uint16 rtb_Saturation1_fd;
  uint16 rtb_Saturation1_nn;
  uint16 rtb_Saturation2_n;
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_LKA_Mode_from_Camera;
  uint8 rtb_R0_Type_e;
  uint8 rtb_L0_Type_h;
  uint8 rtb_R0_LC_b;
  uint8 rtb_L0_LC_o;
  uint8 rtb_IMAPve_d_BCM_LeftTurn_Switc;
  uint8 rtb_IMAPve_d_BCM_RightTurn_Swit;
  uint8 rtb_IMAPve_d_Camera_Signal_Faul;
  uint8 rtb_IMAPve_d_ConsArea;
  uint8 rtb_IMAPve_d_EPS_Driver_Active_;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L0_LC_c;
  uint8 rtb_L0_Q_ku;
  uint8 rtb_L0_Type_l;
  uint8 rtb_L1_LC;
  uint8 rtb_L1_Q_p;
  uint8 rtb_L1_Type;
  uint8 rtb_IMAPve_d_LDW_Warn_Mode;
  uint8 rtb_IMAPve_d_Lane_Valid;
  uint8 rtb_IMAPve_d_MP5_AutoPilot_Swit;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_L1_LC_p;
  uint8 rtb_L1_Type_m;
  uint8 rtb_IMAPve_d_ORI_Lane_ConsArea;
  uint8 rtb_IMAPve_d_ORI_Lane_RoadType;
  uint8 rtb_IMAPve_d_ORI_Lane_Valid;
  uint8 rtb_R1_LC;
  uint8 rtb_R1_Type;
  uint8 rtb_R0_LC_j;
  uint8 rtb_R0_Q_j;
  uint8 rtb_R0_Type_j;
  uint8 rtb_R1_LC_a;
  uint8 rtb_R1_Q_j;
  uint8 rtb_R1_Type_o;
  uint8 rtb_IMAPve_d_Road_Type;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_LDW_State;
  uint8 rtb_LKA_State_Mon;
  uint8 rtb_LDW_State_Mon;
  uint8 rtb_DACMode;
  uint8 rtb_Saturation1_m;
  boolean rtb_Compare_g;
  boolean rtb_Compare_bb;
  boolean rtb_Event_FaulETATDA;
  boolean rtb_Compare_di;
  boolean rtb_Compare_p;
  boolean rtb_Compare_pg;
  boolean rtb_Compare_l;
  boolean rtb_Compare_hs;
  boolean rtb_Compare_i;
  boolean rtb_Compare_g3;
  boolean rtb_Compare_lf;
  boolean rtb_Event_FaulSWS;
  boolean rtb_Compare_b2;
  boolean rtb_UnitDelay_o;
  boolean rtb_Compare_f5;
  boolean rtb_Merge_d;
  boolean rtb_Merge_g;
  boolean rtb_Compare_md;
  boolean rtb_UnitDelay_e;
  boolean rtb_Compare_pf;
  boolean rtb_Merge_o;
  boolean rtb_Compare_jf;
  boolean rtb_Compare_fqp;
  boolean rtb_LogicalOperator1_p;
  boolean rtb_Compare_l1;
  boolean rtb_Compare_lb;
  boolean rtb_RelationalOperator6_p;
  boolean rtb_RelationalOperator5;
  float32 x10;
  float32 x20;
  float32 x1;
  sint32 i;
  uint8 rtb_IMAPve_d_BCM_HazardLamp;
  uint8 rtb_IMAPve_d_BCM_Left_Light;
  uint8 rtb_IMAPve_d_BCM_Right_Light;
  uint8 rtb_IMAPve_d_Camera_Status;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  uint8 rtb_IMAPve_d_TCU_Actual_Gear;
  float32 rtb_IMAPve_g_ESC_LatAcc;
  UInt8 rtb_EPS_LKA_Control;
  float32 rtb_Abs_kj;
  float32 rtb_L0_C0;
  float32 rtb_L0_C2;
  float32 rtb_R0_C2;
  float32 rtb_Saturation;
  float32 rtb_Add1;
  float32 rtb_Saturation_mn;
  uint8 rtb_L0_Type;
  uint8 rtb_R0_Type;
  float32 rtb_L0_C1;
  float32 rtb_R0_C1;
  float32 rtb_L0_C3;
  float32 rtb_R0_C3;
  float32 rtb_L0_TLC;
  uint8 rtb_LKA_action_indication;
  float32 rtb_Switch_dp;
  uint8 rtb_L0_Q;
  uint8 rtb_R0_Q;
  float32 rtb_L0_C0_o;
  float32 rtb_L0_C1_k;
  float32 rtb_L0_C2_o;
  float32 rtb_L0_C3_k;
  float32 rtb_L0_TLC_a;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LKASWASyn_TrqSwaAddSwt;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_Saturation6;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_n;
  boolean rtb_LogicalOperator3_d;
  boolean rtb_LogicalOperator3_a;
  boolean rtb_LogicalOperator_kn;
  boolean rtb_Compare_oi;
  boolean rtb_Compare_mc4;
  boolean rtb_LogicalOperator_bm;
  boolean rtb_Compare_jv;
  boolean rtb_LogicalOperator_d;
  boolean rtb_Compare_e0;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_mb;
  boolean rtb_stDvrTkConFlg_h;
  boolean rtb_LogicalOperator_ar;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge;
  boolean rtb_Compare_d3;
  boolean rtb_Compare_dmy;
  float32 rtb_offset;
  uint16 rtb_Saturation_pw;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  float32 rtb_TTLC;
  float32 rtb_TLft;
  float32 rtb_LKA_Veh2CamL_C_tmp;
  float32 rtb_Add5_k_tmp;
  float32 rtb_LogicalOperator3_b_tmp;
  float32 rtb_LogicalOperator3_b_tmp_0;
  float32 rtb_Add_hf_tmp;
  float32 rtb_Add_g5_tmp;
  boolean exitg1;

  /* Inport: '<Root>/IMAPve_d_LKA_Main_Switch' */
  Rte_Read_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch(&rtb_Saturation_pw);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp'
   */
  rtb_IMAPve_d_BCM_HazardLamp = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_Left_Light'
   */
  rtb_IMAPve_d_BCM_Left_Light = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_Right_Light'
   */
  rtb_IMAPve_d_BCM_Right_Light = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Camera_Status'
   */
  rtb_IMAPve_d_Camera_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_LKA_State'
   */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_Actual_Gear'
   */
  rtb_IMAPve_d_TCU_Actual_Gear = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  rtb_IMAPve_g_EPS_SW_Trq = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  rtb_IMAPve_g_ESC_LonAcc = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  rtb_IMAPve_g_ESC_VehSpd = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  rtb_IMAPve_g_SW_Angle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle();

  /* Product: '<S46>/Divide' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1'
   *  Inport: '<Root>/IMAPve_d_LKA_Mode'
   */
  LKAS_DW.Divide = (uint8)(((uint32)((uint8)rtb_Saturation_pw)) * ((uint32)
    ((uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode())));

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_L0_Q'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L0_Q_IMAPve_d_ORI_L0_Q();

  /* Switch: '<S54>/Switch' incorporates:
   *  Constant: '<S54>/Constant'
   */
  if (rtb_EPS_LKA_Control >= ((UInt8)((uint8)2U))) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = (uint8)rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S54>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_R0_Q'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R0_Q_IMAPve_d_ORI_R0_Q();

  /* Switch: '<S53>/Switch1' incorporates:
   *  Constant: '<S53>/Constant1'
   */
  if (rtb_EPS_LKA_Control >= ((UInt8)((uint8)2U))) {
    rtb_R0_Q = ((uint8)3U);
  } else {
    rtb_R0_Q = (uint8)rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S53>/Switch1' */

  /* Chart: '<S51>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c29_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c29_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S56>:4' */
    LKAS_DW.is_c29_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S56>:3' */
    /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c29_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S56>:9' */
      /* '<S56>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:13' */
        LKAS_DW.is_c29_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S56>:3' */
        /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S56>:14' */
          LKAS_DW.is_c29_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S56>:7' */
          /* '<S56>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S56>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S56>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
            /* Transition: '<S56>:23' */
            LKAS_DW.is_c29_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S56>:5' */
            /* '<S56>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S56>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S56>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S56>:5' */
      /* '<S56>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:16' */
        LKAS_DW.is_c29_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S56>:3' */
        /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S56>:18' */
          LKAS_DW.is_c29_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S56>:7' */
          /* '<S56>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S56>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S56>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_R0_Q) < 3) {
            /* Transition: '<S56>:11' */
            LKAS_DW.is_c29_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S56>:3' */
      /* '<S56>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:6' */
        LKAS_DW.is_c29_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S56>:5' */
        /* '<S56>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S56>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S56>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S56>:8' */
          LKAS_DW.is_c29_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S56>:7' */
          /* '<S56>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S56>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S56>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) < 3)) {
            /* Transition: '<S56>:10' */
            /* '<S56>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c29_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S56>:7' */
      /* '<S56>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:17' */
        LKAS_DW.is_c29_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S56>:3' */
        /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
          /* Transition: '<S56>:19' */
          LKAS_DW.is_c29_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S56>:5' */
          /* '<S56>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S56>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S56>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_L0_Q) < 3) {
            /* Transition: '<S56>:12' */
            LKAS_DW.is_c29_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S51>/LaneReconstructSM' */

  /* DataTypeConversion: '<S50>/Cast To Single30' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C0'
   */
  rtb_L0_C0 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C0_IMAPve_g_ORI_L0_C0();

  /* DataTypeConversion: '<S50>/Cast To Single31' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C2_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C2'
   */
  rtb_L0_C2 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C2_IMAPve_g_ORI_L0_C2();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C2_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C2'
   */
  rtb_Abs_kj = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C2_IMAPve_g_ORI_R0_C2();

  /* DataTypeConversion: '<S50>/Cast To Single23' */
  rtb_R0_C2 = rtb_Abs_kj;

  /* Sum: '<S61>/Add2' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single23'
   */
  rtb_Abs_kj += rtb_L0_C2;

  /* Abs: '<S61>/Abs' */
  rtb_Abs_kj = fabsf(rtb_Abs_kj);

  /* Saturate: '<S61>/Saturation' */
  if (rtb_Abs_kj > 0.004F) {
    rtb_Saturation = 0.004F;
  } else if (rtb_Abs_kj < 0.0F) {
    rtb_Saturation = 0.0F;
  } else {
    rtb_Saturation = rtb_Abs_kj;
  }

  /* End of Saturate: '<S61>/Saturation' */

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C0_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C0'
   */
  rtb_Abs_kj = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C0_IMAPve_g_ORI_R0_C0();

  /* Sum: '<S70>/Add1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single22'
   *  Gain: '<S66>/Gain'
   *  Memory: '<S70>/Memory'
   *  Product: '<S70>/Divide'
   *  Product: '<S70>/Divide1'
   *  Sum: '<S66>/Add'
   */
  rtb_Add1 = ((((-1.0F) * rtb_L0_C0) + rtb_Abs_kj) * LKAS_ConstB.Divide2) +
    (LKAS_ConstB.Add2 * LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S66>/Saturation' */
  if (rtb_Add1 > 5.5F) {
    rtb_Saturation_mn = 5.5F;
  } else if (rtb_Add1 < 2.5F) {
    rtb_Saturation_mn = 2.5F;
  } else {
    rtb_Saturation_mn = rtb_Add1;
  }

  /* End of Saturate: '<S66>/Saturation' */

  /* MATLAB Function: '<S61>/get_roadside_offset' */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S67>:1' */
  /* '<S67>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S67>:1:3' cur=min(single(0.004),cur); */
  /* '<S67>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S67>:1:5' offset=min(single(0.5),offset); */
  rtb_offset = fminf(0.5F, (((fminf(0.004F, rtb_Saturation) / 0.004F) + 1.0F) *
    0.2F) * (fminf(4.0F, rtb_Saturation_mn) - 2.0F));

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_L0_Type'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L0_Type_IMAPve_d_ORI_L0_Type();

  /* DataTypeConversion: '<S50>/Cast To Single6' */
  rtb_L0_Type = (uint8)rtb_EPS_LKA_Control;

  /* Switch: '<S61>/Switch' incorporates:
   *  Constant: '<S64>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single6'
   *  RelationalOperator: '<S64>/Compare'
   *  Sum: '<S61>/Add'
   */
  if (rtb_EPS_LKA_Control == ((UInt8)((uint8)2U))) {
    rtb_L0_C0 += rtb_offset;
  }

  /* End of Switch: '<S61>/Switch' */

  /* Switch: '<S62>/Switch' incorporates:
   *  Abs: '<S62>/Abs'
   *  Constant: '<S68>/Constant'
   *  Memory: '<S62>/Memory'
   *  Memory: '<S62>/Memory1'
   *  Product: '<S62>/Divide'
   *  Product: '<S62>/Divide1'
   *  RelationalOperator: '<S68>/Compare'
   *  Sum: '<S62>/Add1'
   *  Sum: '<S62>/Add3'
   */
  if (fabsf(rtb_L0_C0 - LKAS_DW.Memory1_PreviousInput) > 0.5F) {
    rtb_Saturation = rtb_L0_C0;
  } else {
    rtb_Saturation = (rtb_L0_C0 * LKAS_ConstB.Divide2_p) + (LKAS_ConstB.Add2_g *
      LKAS_DW.Memory_PreviousInput_d);
  }

  /* End of Switch: '<S62>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_LT_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_R0_LT'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R0_LT_IMAPve_d_ORI_R0_LT();

  /* DataTypeConversion: '<S50>/Cast To Single16' */
  rtb_R0_Type = (uint8)rtb_EPS_LKA_Control;

  /* Switch: '<S61>/Switch1' incorporates:
   *  Constant: '<S65>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single16'
   *  DataTypeConversion: '<S50>/Cast To Single22'
   *  RelationalOperator: '<S65>/Compare'
   *  Sum: '<S61>/Add1'
   */
  if (rtb_EPS_LKA_Control == ((UInt8)((uint8)2U))) {
    rtb_offset = rtb_Abs_kj - rtb_offset;
  } else {
    rtb_offset = rtb_Abs_kj;
  }

  /* End of Switch: '<S61>/Switch1' */

  /* Switch: '<S63>/Switch' incorporates:
   *  Abs: '<S63>/Abs'
   *  Constant: '<S69>/Constant'
   *  Memory: '<S63>/Memory'
   *  Memory: '<S63>/Memory1'
   *  Product: '<S63>/Divide'
   *  Product: '<S63>/Divide1'
   *  RelationalOperator: '<S69>/Compare'
   *  Sum: '<S63>/Add1'
   *  Sum: '<S63>/Add3'
   */
  if (fabsf(rtb_offset - LKAS_DW.Memory1_PreviousInput_l) > 0.5F) {
    rtb_Switch_dp = rtb_offset;
  } else {
    rtb_Switch_dp = (rtb_offset * LKAS_ConstB.Divide2_n) + (LKAS_ConstB.Add2_h *
      LKAS_DW.Memory_PreviousInput_g);
  }

  /* End of Switch: '<S63>/Switch' */

  /* DataTypeConversion: '<S50>/Cast To Single28' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C1_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C1'
   */
  rtb_L0_C1 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C1_IMAPve_g_ORI_L0_C1();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C1_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C1'
   */
  rtb_Abs_kj = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C1_IMAPve_g_ORI_R0_C1();

  /* DataTypeConversion: '<S50>/Cast To Single21' */
  rtb_R0_C1 = rtb_Abs_kj;

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single21'
   *  DataTypeConversion: '<S58>/Cast To Single2'
   *  Gain: '<S58>/Gain'
   *  Sum: '<S58>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_o = rtb_Saturation;
    rtb_L0_C1_k = rtb_L0_C1;
    rtb_L0_C2_o = rtb_L0_C2;
  } else {
    rtb_L0_C0_o = (rtb_Saturation_mn - rtb_Switch_dp) * (-1.0F);
    rtb_L0_C1_k = rtb_Abs_kj;
    rtb_L0_C2_o = rtb_R0_C2;
  }

  /* DataTypeConversion: '<S50>/Cast To Single33' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_C3_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C3'
   */
  rtb_L0_C3 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_C3_IMAPve_g_ORI_L0_C3();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_C3_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C3'
   */
  rtb_Abs_kj = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_C3_IMAPve_g_ORI_R0_C3();

  /* DataTypeConversion: '<S50>/Cast To Single27' */
  rtb_R0_C3 = rtb_Abs_kj;

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single27'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C3_k = rtb_L0_C3;
  } else {
    rtb_L0_C3_k = rtb_Abs_kj;
  }

  /* DataTypeConversion: '<S50>/Cast To Single34' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_TLC_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_TLC'
   */
  rtb_L0_TLC = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_TLC_IMAPve_g_ORI_L0_TLC();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_TLC_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_R0_TLC'
   */
  rtb_Abs_kj = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_TLC_IMAPve_g_ORI_R0_TLC();

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single38'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_TLC_a = rtb_L0_TLC;
  } else {
    rtb_L0_TLC_a = rtb_Abs_kj;
  }

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single38'
   *  Sum: '<S60>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_Saturation_mn = rtb_Switch_dp;
    rtb_L0_C1 = rtb_R0_C1;
    rtb_L0_C2 = rtb_R0_C2;
    rtb_L0_C3 = rtb_R0_C3;
    rtb_L0_TLC = rtb_Abs_kj;
  } else {
    rtb_Saturation_mn += rtb_Saturation;
  }

  /* Switch: '<S535>/Switch58' incorporates:
   *  Constant: '<S535>/LLSMConClb4'
   *
   * Block description for '<S535>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S535>/Switch58' */

  /* Gain: '<S540>/Gain' incorporates:
   *  Constant: '<S540>/Constant'
   *  Sum: '<S540>/Add'
   */
  rtb_Gain_d = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S535>/Switch84' incorporates:
   *  Constant: '<S535>/LLSMConClb5'
   *
   * Block description for '<S535>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S535>/Switch84' */

  /* Switch: '<S535>/Switch85' incorporates:
   *  Constant: '<S535>/LLSMConClb6'
   *
   * Block description for '<S535>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S535>/Switch85' */

  /* Switch: '<S535>/Switch86' incorporates:
   *  Constant: '<S535>/LLSMConClb7'
   *
   * Block description for '<S535>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S535>/Switch86' */

  /* Switch: '<S535>/Switch54' incorporates:
   *  Constant: '<S535>/LLSMConClb12'
   *
   * Block description for '<S535>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S535>/Switch54' */

  /* Switch: '<S535>/Switch55' incorporates:
   *  Constant: '<S535>/LLSMConClb13'
   *
   * Block description for '<S535>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S535>/Switch55' */

  /* Switch: '<S535>/Switch52' incorporates:
   *  Constant: '<S535>/LLSMConClb16'
   *
   * Block description for '<S535>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S535>/Switch52' */

  /* Switch: '<S535>/Switch60' incorporates:
   *  Constant: '<S535>/LLSMConClb17'
   *
   * Block description for '<S535>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S535>/Switch60' */

  /* Switch: '<S535>/Switch57' incorporates:
   *  Constant: '<S535>/LLSMConClb18'
   *
   * Block description for '<S535>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S535>/Switch57' */

  /* Switch: '<S535>/Switch59' incorporates:
   *  Constant: '<S535>/LLSMConClb19'
   *
   * Block description for '<S535>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_Abs_kj = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_Abs_kj = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S535>/Switch59' */

  /* Switch: '<S535>/Switch69' incorporates:
   *  Constant: '<S535>/LLSMConClb22'
   *
   * Block description for '<S535>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S535>/Switch69' */

  /* Gain: '<S537>/Gain' incorporates:
   *  Constant: '<S537>/Constant'
   *  Sum: '<S537>/Add'
   */
  rtb_Gain_kz = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S535>/Switch68' incorporates:
   *  Constant: '<S535>/LLSMConClb23'
   *
   * Block description for '<S535>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S535>/Switch68' */

  /* Switch: '<S535>/Switch70' incorporates:
   *  Constant: '<S535>/LLSMConClb24'
   *
   * Block description for '<S535>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S535>/Switch70' */

  /* Switch: '<S535>/Switch71' incorporates:
   *  Constant: '<S535>/LLSMConClb25'
   *
   * Block description for '<S535>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S535>/Switch71' */

  /* Switch: '<S535>/Switch73' incorporates:
   *  Constant: '<S535>/LLSMConClb27'
   *
   * Block description for '<S535>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S535>/Switch73' */

  /* Switch: '<S535>/Switch62' incorporates:
   *  Constant: '<S535>/LLSMConClb31'
   *
   * Block description for '<S535>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S535>/Switch62' */

  /* Switch: '<S535>/Switch66' incorporates:
   *  Constant: '<S535>/LLSMConClb35'
   *
   * Block description for '<S535>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S535>/Switch66' */

  /* Switch: '<S535>/Switch81' incorporates:
   *  Constant: '<S535>/LLSMConClb36'
   *
   * Block description for '<S535>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S535>/Switch81' */

  /* Switch: '<S535>/Switch82' incorporates:
   *  Constant: '<S535>/LLSMConClb37'
   *
   * Block description for '<S535>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S535>/Switch82' */

  /* Switch: '<S535>/Switch83' incorporates:
   *  Constant: '<S535>/LLSMConClb38'
   *
   * Block description for '<S535>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S535>/Switch83' */

  /* Switch: '<S535>/Switch75' incorporates:
   *  Constant: '<S535>/LLSMConClb39'
   *
   * Block description for '<S535>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S535>/Switch75' */

  /* Switch: '<S535>/Switch76' incorporates:
   *  Constant: '<S535>/LLSMConClb40'
   *
   * Block description for '<S535>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S535>/Switch76' */

  /* Switch: '<S535>/Switch77' incorporates:
   *  Constant: '<S535>/LLSMConClb41'
   *
   * Block description for '<S535>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S535>/Switch77' */

  /* Switch: '<S535>/Switch78' incorporates:
   *  Constant: '<S535>/LLSMConClb42'
   *
   * Block description for '<S535>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S535>/Switch78' */

  /* Switch: '<S534>/Switch3' incorporates:
   *  Constant: '<S534>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S534>/Switch3' */

  /* Switch: '<S534>/Switch10' incorporates:
   *  Constant: '<S534>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    LKAS_DW.LL_DesDvt_C_e = LKAS_ConstB.DataTypeConversion22;
  } else {
    LKAS_DW.LL_DesDvt_C_e = LL_DesDvt_C;
  }

  /* End of Switch: '<S534>/Switch10' */

  /* Switch: '<S534>/Switch15' incorporates:
   *  Constant: '<S534>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    LKAS_DW.LL_lStpLngth_C_g = LKAS_ConstB.DataTypeConversion21;
  } else {
    LKAS_DW.LL_lStpLngth_C_g = LL_lStpLngth_C;
  }

  /* End of Switch: '<S534>/Switch15' */

  /* Switch: '<S534>/Switch31' incorporates:
   *  Constant: '<S534>/LL_LFClb_TFC_vGainLutVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_l != 0.0F) {
    rtb_R0_C2 = LKAS_ConstB.DataTypeConversion14_l;
  } else {
    rtb_R0_C2 = LL_LFClb_TFC_vGainLutVehSpdLwr_C;
  }

  /* End of Switch: '<S534>/Switch31' */

  /* Switch: '<S534>/Switch34' incorporates:
   *  Constant: '<S534>/LL_LFClb_TFC_vGainLutVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_R0_C1 = LKAS_ConstB.DataTypeConversion4;
  } else {
    rtb_R0_C1 = LL_LFClb_TFC_vGainLutVehSpdUpr_C;
  }

  /* End of Switch: '<S534>/Switch34' */

  /* Switch: '<S534>/Switch33' incorporates:
   *  Constant: '<S534>/LL_LFClb_TFC_facmGainLutGain1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_i != 0.0F) {
    rtb_R0_C3 = LKAS_ConstB.DataTypeConversion7_i;
  } else {
    rtb_R0_C3 = LL_LFClb_TFC_facmGainLutGain1_C;
  }

  /* End of Switch: '<S534>/Switch33' */

  /* Switch: '<S534>/Switch48' incorporates:
   *  Constant: '<S534>/LL_LFClb_TFC_DiffCtrlRatio=600'
   */
  if (LKAS_ConstB.DataTypeConversion48 != 0.0F) {
    rtb_LL_LFClb_TFC_DiffCtrlRatio = LKAS_ConstB.DataTypeConversion48;
  } else {
    rtb_LL_LFClb_TFC_DiffCtrlRatio = LL_LFClb_TFC_DiffCtrlRatio;
  }

  /* End of Switch: '<S534>/Switch48' */

  /* Switch: '<S534>/Switch47' incorporates:
   *  Constant: '<S534>/LL_LKASWASyn_TrqSwaAddSwt=1'
   */
  if (LKAS_ConstB.DataTypeConversion47_l) {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LKAS_ConstB.DataTypeConversion47_l ? 1.0F :
      0.0F;
  } else {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LL_LKASWASyn_TrqSwaAddSwt ? 1.0F : 0.0F;
  }

  /* End of Switch: '<S534>/Switch47' */

  /* Switch: '<S534>/Switch11' incorporates:
   *  Constant: '<S534>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_b != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12_b;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S534>/Switch11' */

  /* Switch: '<S534>/Switch13' incorporates:
   *  Constant: '<S534>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_a != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_a;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S534>/Switch13' */

  /* Switch: '<S534>/Switch16' incorporates:
   *  Constant: '<S534>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S534>/Switch16' */

  /* Switch: '<S534>/Switch55' incorporates:
   *  Constant: '<S534>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S534>/Switch55' */

  /* Switch: '<S534>/Switch54' incorporates:
   *  Constant: '<S534>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S534>/Switch54' */

  /* Switch: '<S534>/Switch44' incorporates:
   *  Constant: '<S534>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S534>/Switch44' */

  /* Switch: '<S532>/Switch19' incorporates:
   *  Constant: '<S532>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_g != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_g;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S532>/Switch19' */

  /* Switch: '<S532>/Switch' incorporates:
   *  Constant: '<S532>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_g != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_g;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S532>/Switch' */

  /* Switch: '<S532>/Switch1' incorporates:
   *  Constant: '<S532>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_i != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_i;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S532>/Switch1' */

  /* Switch: '<S532>/Switch2' incorporates:
   *  Constant: '<S532>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_h != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_f = LKAS_ConstB.DataTypeConversion4_h;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_f = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S532>/Switch2' */

  /* Switch: '<S532>/Switch3' incorporates:
   *  Constant: '<S532>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_p != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_e = LKAS_ConstB.DataTypeConversion6_p;
  } else {
    LKAS_DW.LKA_StrRatio_C_e = LKA_StrRatio_C;
  }

  /* End of Switch: '<S532>/Switch3' */

  /* Switch: '<S532>/Switch11' incorporates:
   *  Constant: '<S532>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22_n != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22_n;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S532>/Switch11' */

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (((sint32)LKAS_DW.Divide) > 0) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S75>/Delay' */
      LKAS_DW.Delay_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S506>/Memory' */
      LKAS_DW.Memory_PreviousInput_e = 0.0F;

      /* InitializeConditions for Memory: '<S451>/Memory' */
      LKAS_DW.Memory_PreviousInput_k = 0.0F;

      /* InitializeConditions for UnitDelay: '<S381>/Delay Input1'
       *
       * Block description for '<S381>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S379>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_b = false;

      /* InitializeConditions for UnitDelay: '<S380>/Delay Input1'
       *
       * Block description for '<S380>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_a = false;

      /* InitializeConditions for Delay: '<S76>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for UnitDelay: '<S342>/Delay Input1'
       *
       * Block description for '<S342>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_e = false;

      /* InitializeConditions for UnitDelay: '<S340>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_lt = false;

      /* InitializeConditions for UnitDelay: '<S341>/Delay Input1'
       *
       * Block description for '<S341>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_n = false;

      /* InitializeConditions for Memory: '<S308>/Memory' */
      LKAS_DW.Memory_PreviousInput_i2 = false;

      /* InitializeConditions for Delay: '<S76>/Delay' */
      LKAS_DW.Delay_DSTATE_l = false;

      /* InitializeConditions for Delay: '<S76>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S355>/Memory' */
      LKAS_DW.Memory_PreviousInput_mz = ((uint8)0U);

      /* InitializeConditions for Memory: '<S282>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = 0.0F;

      /* InitializeConditions for Memory: '<S318>/Memory' */
      LKAS_DW.Memory_PreviousInput_b = 0.0F;

      /* InitializeConditions for Delay: '<S76>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S76>/LDW_State_Machine'
       *
       * Block description for '<S76>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S76>/LKA_State_Machine'
       *
       * Block description for '<S76>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S225>/Add1' incorporates:
     *  MATLAB Function: '<S223>/MATLAB Function3'
     */
    x20 = rtb_L0_C0_o + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S225>/Gain1' incorporates:
     *  Product: '<S225>/Divide'
     *  Product: '<S225>/Divide1'
     *  Sum: '<S225>/Add1'
     *  Sum: '<S225>/Add5'
     *  Trigonometry: '<S225>/Cos2'
     *  Trigonometry: '<S225>/Sin'
     */
    rtb_Gain1 = ((x20 * cosf(rtb_L0_C1_k)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_k))) * (-1.0F);

    /* Sum: '<S226>/Add1' incorporates:
     *  MATLAB Function: '<S223>/MATLAB Function4'
     */
    rtb_Add5_k_tmp = rtb_Saturation_mn - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S226>/Add5' incorporates:
     *  Product: '<S226>/Divide'
     *  Product: '<S226>/Divide1'
     *  Sum: '<S226>/Add1'
     *  Trigonometry: '<S226>/Cos2'
     *  Trigonometry: '<S226>/Sin'
     */
    rtb_Add5_k = (rtb_Add5_k_tmp * cosf(rtb_L0_C1)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1));

    /* Switch: '<S534>/Switch2' incorporates:
     *  Constant: '<S534>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_d != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_d;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S534>/Switch2' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S74>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S230>/kph to mps' incorporates:
     *  Gain: '<S112>/Gain'
     *  Gain: '<S162>/kph To mps'
     *  Gain: '<S176>/kph to mps'
     *  Gain: '<S177>/kph to mps'
     *  Gain: '<S223>/Gain2'
     *  Gain: '<S236>/kph to mps'
     *  Gain: '<S241>/kph to mps'
     *  Gain: '<S242>/kph to mps'
     *  Gain: '<S269>/Gain'
     *  Gain: '<S307>/Gain'
     */
    rtb_LKA_Veh2CamL_C_tmp = 0.277777791F * rtb_IMAPve_g_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S230>/Divide' incorporates:
     *  Gain: '<S230>/kph to mps'
     */
    rtb_LKA_Veh2CamL_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Gain: '<S227>/Gain' incorporates:
     *  Gain: '<S240>/Gain'
     */
    rtb_Add_hf_tmp = 2.0F * rtb_L0_C2_o;

    /* Sum: '<S227>/Add' incorporates:
     *  Gain: '<S227>/Gain'
     *  Gain: '<S227>/Gain1'
     *  Product: '<S227>/Product'
     */
    rtb_Add_hf = ((6.0F * rtb_L0_C3_k) * rtb_LKA_Veh2CamL_C) + rtb_Add_hf_tmp;

    /* Gain: '<S228>/Gain' incorporates:
     *  Gain: '<S239>/Gain'
     */
    rtb_Add_g5_tmp = 2.0F * rtb_L0_C2;

    /* Sum: '<S228>/Add' incorporates:
     *  Gain: '<S228>/Gain'
     *  Gain: '<S228>/Gain1'
     *  Product: '<S228>/Product'
     */
    rtb_Add_g5 = ((6.0F * rtb_L0_C3) * rtb_LKA_Veh2CamL_C) + rtb_Add_g5_tmp;

    /* Saturate: '<S223>/Saturation5' */
    if (rtb_L0_TLC_a > 2.0F) {
      rtb_L0_TLC_a = 2.0F;
    } else {
      if (rtb_L0_TLC_a < 0.6F) {
        rtb_L0_TLC_a = 0.6F;
      }
    }

    /* End of Saturate: '<S223>/Saturation5' */

    /* Saturate: '<S223>/Saturation6' */
    if (rtb_L0_TLC > 2.0F) {
      rtb_Saturation6 = 2.0F;
    } else if (rtb_L0_TLC < 0.6F) {
      rtb_Saturation6 = 0.6F;
    } else {
      rtb_Saturation6 = rtb_L0_TLC;
    }

    /* End of Saturate: '<S223>/Saturation6' */

    /* UnaryMinus: '<S223>/Unary Minus' incorporates:
     *  Product: '<S223>/Product'
     */
    rtb_LKA_Veh2CamL_C = -(rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1_k);

    /* Saturate: '<S223>/Saturation9' */
    if (rtb_LKA_Veh2CamL_C > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else {
      if (rtb_LKA_Veh2CamL_C < (-2.0F)) {
        rtb_LKA_Veh2CamL_C = (-2.0F);
      }
    }

    /* End of Saturate: '<S223>/Saturation9' */

    /* MATLAB Function: '<S223>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function': '<S250>:1' */
    /* '<S250>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1 > 0.0F) && (rtb_Gain1 < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S250>:1:3' TTLC = -dvt/vy; */
      rtb_L0_TLC = (-rtb_Gain1) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S250>:1:4' else */
      /* '<S250>:1:5' TTLC = single(3); */
      rtb_L0_TLC = 3.0F;
    }

    /* End of MATLAB Function: '<S223>/MATLAB Function' */

    /* Saturate: '<S223>/Saturation' */
    if (rtb_L0_TLC > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_L0_TLC < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_L0_TLC;
    }

    /* End of Saturate: '<S223>/Saturation' */

    /* Product: '<S223>/Product3' */
    rtb_L0_TLC = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* Saturate: '<S223>/Saturation10' */
    if (rtb_L0_TLC > 2.0F) {
      rtb_L0_TLC = 2.0F;
    } else {
      if (rtb_L0_TLC < (-2.0F)) {
        rtb_L0_TLC = (-2.0F);
      }
    }

    /* End of Saturate: '<S223>/Saturation10' */

    /* MATLAB Function: '<S223>/MATLAB Function1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function1': '<S251>:1' */
    /* '<S251>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_k > 0.0F) && (rtb_Add5_k < 2.0F)) && (rtb_L0_TLC < 0.0F)) &&
        (rtb_L0_TLC > -1.5F)) {
      /* '<S251>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_n = (-rtb_Add5_k) / rtb_L0_TLC;
    } else {
      /* '<S251>:1:4' else */
      /* '<S251>:1:5' TTLC = single(3); */
      rtb_TTLC_n = 3.0F;
    }

    /* End of MATLAB Function: '<S223>/MATLAB Function1' */

    /* Saturate: '<S223>/Saturation1' */
    if (rtb_TTLC_n > 2.0F) {
      rtb_TTLC_n = 2.0F;
    } else {
      if (rtb_TTLC_n < 0.6F) {
        rtb_TTLC_n = 0.6F;
      }
    }

    /* End of Saturate: '<S223>/Saturation1' */

    /* MATLAB Function: '<S223>/MATLAB Function5' incorporates:
     *  Gain: '<S249>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function5': '<S255>:1' */
    /* '<S255>:1:2' K = 0.09/vx; */
    /* '<S255>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_IMAPve_g_SW_Angle) / (((((((0.09F /
      rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp)
      + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_f) * LKAS_DW.LKA_StrRatio_C_e) * 2.0F);

    /* MATLAB Function: '<S223>/MATLAB Function3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function3': '<S253>:1' */
    /* '<S253>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2_o - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_k > 0.0F) || (rtb_L0_C1_k < 0.0F))) {
      /* '<S253>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_o) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_k;
      if (x10 > 0.0F) {
        /* '<S253>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        /* '<S253>:1:9' else */
        /* '<S253>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_k * rtb_L0_C1_k) - ((x10 * 4.0F) * x20);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S253>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S253>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_k)) / x1;

        /* '<S253>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_k) - x20) / x1;

        /* '<S253>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S253>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S253>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S253>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          /* '<S253>:1:19' elseif x1>0 */
          /* '<S253>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          /* '<S253>:1:21' else */
          /* '<S253>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S253>:1:24' else */
        /* '<S253>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S253>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S223>/MATLAB Function4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function4': '<S254>:1' */
    /* '<S254>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2 - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1 > 0.0F) || (rtb_L0_C1 < 0.0F))) {
      /* '<S254>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_Saturation_mn) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1;
      if (x10 > 0.0F) {
        /* '<S254>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        /* '<S254>:1:9' else */
        /* '<S254>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1 * rtb_L0_C1) - ((x10 * 4.0F) * rtb_Add5_k_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S254>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S254>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1)) / x1;

        /* '<S254>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1) - x20) / x1;

        /* '<S254>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S254>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S254>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S254>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          /* '<S254>:1:19' elseif x1>0 */
          /* '<S254>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          /* '<S254>:1:21' else */
          /* '<S254>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S254>:1:24' else */
        /* '<S254>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S254>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S223>/MATLAB Function2' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function2': '<S252>:1' */
    /* '<S252>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - rtb_L0_TLC_a) / rtb_LftTTLC) <= 0.2F) {
      /* '<S252>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, rtb_L0_TLC_a);
    } else {
      /* '<S252>:1:4' else */
      /* '<S252>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S252>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_n - rtb_Saturation6) / rtb_TTLC_n) <= 0.2F) {
      /* '<S252>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_n = fminf(rtb_TTLC_n, rtb_Saturation6);
    } else {
      /* '<S252>:1:10' else */
      /* '<S252>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S252>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_hf) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S252>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S252>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_g5) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_n)
           / rtb_TTLC_n) <= 0.7F)) && (rtb_TTLC_n <= 1.95F)) {
      /* '<S252>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_n = (rtb_TTLC_n + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S223>/Saturation7' incorporates:
     *  MATLAB Function: '<S223>/MATLAB Function2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S223>/Saturation7' */

    /* Saturate: '<S223>/Saturation8' incorporates:
     *  MATLAB Function: '<S223>/MATLAB Function2'
     */
    if (rtb_TTLC_n > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_n < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_n;
    }

    /* End of Saturate: '<S223>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S74>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S83>/Subsystem' incorporates:
     *  EnablePort: '<S91>/Enable'
     */
    /* Abs: '<S218>/Abs' incorporates:
     *  MATLAB Function: '<S91>/DriverSwaTrqAdd'
     */
    rtb_LftTTLC = fabsf(rtb_L0_C0_o);

    /* Abs: '<S218>/Abs1' incorporates:
     *  MATLAB Function: '<S91>/DriverSwaTrqAdd'
     */
    rtb_TTLC_n = fabsf(rtb_Saturation_mn);

    /* End of Outputs for SubSystem: '<S83>/Subsystem' */

    /* Sum: '<S218>/Add' incorporates:
     *  Abs: '<S218>/Abs'
     *  Abs: '<S218>/Abs1'
     *  Sum: '<S182>/Add6'
     */
    rtb_Add5_k_tmp = rtb_LftTTLC + rtb_TTLC_n;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Saturate: '<S218>/Saturation' incorporates:
     *  Sum: '<S218>/Add'
     */
    if (rtb_Add5_k_tmp > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_Add5_k_tmp < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_Add5_k_tmp;
    }

    /* End of Saturate: '<S218>/Saturation' */

    /* If: '<S229>/If' incorporates:
     *  Delay: '<S75>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE) == 1) {
      /* Outputs for IfAction SubSystem: '<S229>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S232>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_hf, &rtb_Merge_i);

      /* End of Outputs for SubSystem: '<S229>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE) == 2) {
      /* Outputs for IfAction SubSystem: '<S229>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S231>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_g5, &rtb_Merge_i);

      /* End of Outputs for SubSystem: '<S229>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S229>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S233>/Action Port'
       */
      /* Gain: '<S233>/Gain' incorporates:
       *  Sum: '<S233>/Add'
       */
      rtb_Merge_i = (rtb_Add_hf + rtb_Add_g5) * 0.5F;

      /* End of Outputs for SubSystem: '<S229>/If Action Subsystem3' */
    }

    /* End of If: '<S229>/If' */

    /* Switch: '<S508>/Switch' incorporates:
     *  Constant: '<S538>/Constant'
     *  Constant: '<S539>/Constant'
     *  Gain: '<S538>/Gain'
     *  Gain: '<S539>/Gain'
     *  Sum: '<S538>/Add'
     *  Sum: '<S539>/Add'
     *  Switch: '<S535>/Switch47'
     */
    if (LKAS_DW.Divide >= ((uint8)2U)) {
      /* Switch: '<S535>/Switch48' incorporates:
       *  Constant: '<S535>/LLSMConClb3'
       *
       * Block description for '<S535>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S535>/Switch48' */
      rtb_Switch_k = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S535>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S535>/Switch47' incorporates:
         *  Constant: '<S535>/LLSMConClb2'
         *
         * Block description for '<S535>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_k = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S508>/Switch' */

    /* Switch: '<S506>/Switch' incorporates:
     *  Constant: '<S506>/Constant'
     *  Constant: '<S506>/Constant1'
     *  Constant: '<S511>/Constant'
     *  Constant: '<S512>/Constant'
     *  Constant: '<S513>/Constant'
     *  Logic: '<S506>/Logical Operator'
     *  RelationalOperator: '<S511>/Compare'
     *  RelationalOperator: '<S512>/Compare'
     *  RelationalOperator: '<S513>/Compare'
     */
    if (((rtb_IMAPve_d_BCM_HazardLamp > ((uint8)0U)) ||
         (rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U))) ||
        (rtb_IMAPve_d_BCM_Right_Light > ((uint8)0U))) {
      rtb_L0_TLC_a = 3.0F;
    } else {
      rtb_L0_TLC_a = (-1.0F);
    }

    /* End of Switch: '<S506>/Switch' */

    /* Sum: '<S506>/Add' incorporates:
     *  Memory: '<S506>/Memory'
     */
    rtb_L0_TLC_a += LKAS_DW.Memory_PreviousInput_e;

    /* Saturate: '<S506>/Saturation' */
    if (rtb_L0_TLC_a > 200.0F) {
      rtb_Saturation_j = 200.0F;
    } else if (rtb_L0_TLC_a < (-1.0F)) {
      rtb_Saturation_j = (-1.0F);
    } else {
      rtb_Saturation_j = rtb_L0_TLC_a;
    }

    /* End of Saturate: '<S506>/Saturation' */

    /* Abs: '<S500>/Abs1' incorporates:
     *  Abs: '<S407>/Abs1'
     */
    rtb_Saturation6 = fabsf(rtb_LaneWidth);
    rtb_Abs1 = rtb_Saturation6;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S74>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S498>/Abs' incorporates:
     *  Abs: '<S102>/Abs'
     *  Abs: '<S103>/Abs'
     *  Abs: '<S104>/Abs4'
     *  Abs: '<S405>/Abs'
     *  MATLAB Function: '<S369>/MATLAB Function'
     */
    rtb_TTLC = fabsf(rtb_Merge_i);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC;

    /* Switch: '<S535>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S461>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S461>/Unary Minus' incorporates:
       *  Constant: '<S535>/LLSMConClb11'
       *
       * Block description for '<S535>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S535>/Switch53' */

    /* Switch: '<S535>/Switch87' incorporates:
     *  Constant: '<S535>/LLSMConClb8'
     *
     * Block description for '<S535>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S535>/Switch87' */

    /* Switch: '<S535>/Switch49' incorporates:
     *  Constant: '<S535>/LLSMConClb43'
     *
     * Block description for '<S535>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S535>/Switch49' */

    /* Switch: '<S535>/Switch88' incorporates:
     *  Constant: '<S535>/LLSMConClb9'
     *
     * Block description for '<S535>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_L0_TLC_a = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_L0_TLC_a = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S535>/Switch88' */

    /* Switch: '<S535>/Switch50' incorporates:
     *  Constant: '<S535>/LLSMConClb10'
     *
     * Block description for '<S535>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      x1 = LKAS_ConstB.DataTypeConversion17;
    } else {
      x1 = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S535>/Switch50' */

    /* Abs: '<S496>/Abs' incorporates:
     *  Abs: '<S403>/Abs'
     *  Sum: '<S496>/Add'
     */
    rtb_IMAPve_g_ESC_LatAcc = fabsf(rtb_L0_C1_k - rtb_L0_C1);

    /* Abs: '<S461>/Abs2' incorporates:
     *  Abs: '<S244>/Abs2'
     *  Abs: '<S367>/Abs2'
     */
    rtb_TLft = fabsf(rtb_IMAPve_g_SW_Angle);

    /* Abs: '<S461>/Abs3' incorporates:
     *  Abs: '<S367>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     *  Inport: '<Root>/IMAPve_g_SW_Angle_Speed'
     */
    rtb_LogicalOperator3_b_tmp = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
      ());

    /* Abs: '<S461>/Abs4' incorporates:
     *  Abs: '<S367>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     *  Inport: '<Root>/IMAPve_g_ESC_LatAcc'
     */
    rtb_LogicalOperator3_b_tmp_0 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc());

    /* Abs: '<S461>/Abs1' incorporates:
     *  Abs: '<S368>/Abs'
     *  Abs: '<S369>/Abs'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S462>/Logical Operator2' incorporates:
     *  Abs: '<S461>/Abs1'
     *  Abs: '<S461>/Abs2'
     *  Abs: '<S461>/Abs3'
     *  Abs: '<S461>/Abs4'
     *  Abs: '<S496>/Abs'
     *  Constant: '<S498>/Constant'
     *  Constant: '<S501>/Constant'
     *  Constant: '<S503>/Constant'
     *  Constant: '<S504>/Constant'
     *  Constant: '<S510>/Constant'
     *  Constant: '<S514>/Constant'
     *  Logic: '<S461>/Logical Operator3'
     *  Logic: '<S467>/FixPt Logical Operator'
     *  Logic: '<S497>/Logical Operator3'
     *  Logic: '<S499>/Logical Operator'
     *  Logic: '<S502>/FixPt Logical Operator'
     *  Logic: '<S505>/FixPt Logical Operator'
     *  Logic: '<S509>/Logical Operator'
     *  Logic: '<S515>/FixPt Logical Operator'
     *  RelationalOperator: '<S461>/Relational Operator'
     *  RelationalOperator: '<S461>/Relational Operator1'
     *  RelationalOperator: '<S461>/Relational Operator2'
     *  RelationalOperator: '<S461>/Relational Operator3'
     *  RelationalOperator: '<S467>/Lower Test'
     *  RelationalOperator: '<S467>/Upper Test'
     *  RelationalOperator: '<S501>/Compare'
     *  RelationalOperator: '<S502>/Lower Test'
     *  RelationalOperator: '<S502>/Upper Test'
     *  RelationalOperator: '<S503>/Compare'
     *  RelationalOperator: '<S504>/Compare'
     *  RelationalOperator: '<S505>/Lower Test'
     *  RelationalOperator: '<S505>/Upper Test'
     *  RelationalOperator: '<S510>/Compare'
     *  RelationalOperator: '<S514>/Compare'
     *  RelationalOperator: '<S515>/Lower Test'
     *  RelationalOperator: '<S515>/Upper Test'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_LogicalOperator3_d = ((((((rtb_Gain_d <= rtb_IMAPve_g_ESC_VehSpd) &&
      (rtb_IMAPve_g_ESC_VehSpd <= rtb_Switch_k)) && (rtb_Saturation_j <= 0.0F)) &&
      (rtb_IMAPve_d_TCU_Actual_Gear == ((uint8)3U))) && (((((rtb_L0_Q > ((uint8)
      2U)) && (rtb_R0_Q > ((uint8)2U))) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <=
      rtb_Abs1) && (rtb_Abs1 <= rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <=
      rtb_Abs) && (rtb_Abs <= rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) &&
      (rtb_IMAPve_g_ESC_LatAcc <= 0.025F))) && (((((rtb_TLft < x10) &&
      (rtb_LogicalOperator3_b_tmp < x20)) && (rtb_LKA_Veh2CamW_C < rtb_L0_TLC_a))
      && (rtb_LogicalOperator3_b_tmp_0 < x1)) && ((rtb_UnaryMinus <
      rtb_IMAPve_g_ESC_LonAcc) && (rtb_IMAPve_g_ESC_LonAcc <
      rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* Sum: '<S494>/Add1' incorporates:
     *  Constant: '<S494>/Constant1'
     *  Gain: '<S494>/Gain'
     *  Sum: '<S476>/Add1'
     */
    x1 = (0.5F * rtb_LaneWidth) - 1.5F;
    rtb_Add1_k = x1;

    /* Switch: '<S495>/Switch' incorporates:
     *  Constant: '<S494>/Constant'
     *  RelationalOperator: '<S495>/UpperRelop'
     */
    if (rtb_Add1_k < 0.0F) {
      rtb_Switch_m = 0.0F;
    } else {
      rtb_Switch_m = rtb_Add1_k;
    }

    /* End of Switch: '<S495>/Switch' */

    /* Switch: '<S495>/Switch2' incorporates:
     *  RelationalOperator: '<S495>/LowerRelop1'
     */
    if (rtb_Add1_k > rtb_LL_LKA_EarliestWarnLine_C) {
      rtb_Switch2 = rtb_LL_LKA_EarliestWarnLine_C;
    } else {
      rtb_Switch2 = rtb_Switch_m;
    }

    /* End of Switch: '<S495>/Switch2' */

    /* Abs: '<S481>/Abs1' incorporates:
     *  Abs: '<S393>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S481>/Abs2' incorporates:
     *  Abs: '<S393>/Abs1'
     */
    x20 = fabsf(rtb_L0_TLC);

    /* If: '<S462>/If1' incorporates:
     *  Abs: '<S481>/Abs1'
     *  Abs: '<S481>/Abs2'
     *  Constant: '<S469>/Constant'
     *  Constant: '<S483>/Constant'
     *  Constant: '<S484>/Constant'
     *  Constant: '<S489>/Constant'
     *  Constant: '<S490>/Constant'
     *  Constant: '<S491>/Constant'
     *  Constant: '<S492>/Constant'
     *  DataTypeConversion: '<S462>/Cast To Single'
     *  Logic: '<S462>/Logical Operator1'
     *  Logic: '<S478>/Logical Operator'
     *  Logic: '<S480>/Logical Operator'
     *  Logic: '<S481>/Logical Operator'
     *  Logic: '<S482>/Logical Operator'
     *  RelationalOperator: '<S481>/Relational Operator2'
     *  RelationalOperator: '<S481>/Relational Operator3'
     *  RelationalOperator: '<S482>/Relational Operator1'
     *  RelationalOperator: '<S482>/Relational Operator2'
     *  RelationalOperator: '<S483>/Compare'
     *  RelationalOperator: '<S484>/Compare'
     *  RelationalOperator: '<S489>/Compare'
     *  RelationalOperator: '<S490>/Compare'
     *  RelationalOperator: '<S491>/Compare'
     *  RelationalOperator: '<S492>/Compare'
     */
    if ((((sint32)LKAS_DW.Divide) == 2) && (rtb_LogicalOperator3_d &&
         ((((LKAS_DW.Divide == ((uint8)2U)) && (((sint32)
              (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
                (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) ? 1 : 0)) ==
             ((sint32)(true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1 >= rtb_Switch2) && (rtb_Add5_k
               >= rtb_Switch2)) ? 1 : 0)) == ((sint32)(true ? 1 : 0)))))) {
      /* Outputs for IfAction SubSystem: '<S462>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S469>/Action Port'
       */
      LKAS_DW.Merge1_p = true;

      /* End of Outputs for SubSystem: '<S462>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S462>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S471>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_p);

      /* End of Outputs for SubSystem: '<S462>/If Action Subsystem4' */
    }

    /* End of If: '<S462>/If1' */

    /* Switch: '<S453>/Switch' incorporates:
     *  Constant: '<S536>/Constant'
     *  Constant: '<S541>/Constant'
     *  Gain: '<S536>/Gain'
     *  Gain: '<S541>/Gain'
     *  Sum: '<S536>/Add'
     *  Sum: '<S541>/Add'
     *  Switch: '<S535>/Switch67'
     */
    if (LKAS_DW.Divide >= ((uint8)2U)) {
      /* Switch: '<S535>/Switch80' incorporates:
       *  Constant: '<S535>/LLSMConClb21'
       *
       * Block description for '<S535>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_L0_TLC_a = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_L0_TLC_a = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S535>/Switch80' */
      rtb_Switch_e = (rtb_L0_TLC_a - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S535>/Switch67' */
        rtb_L0_TLC_a = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S535>/Switch67' incorporates:
         *  Constant: '<S535>/LLSMConClb20'
         *
         * Block description for '<S535>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_L0_TLC_a = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_e = (rtb_L0_TLC_a - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S453>/Switch' */

    /* Logic: '<S453>/Logical Operator' incorporates:
     *  Logic: '<S460>/FixPt Logical Operator'
     *  RelationalOperator: '<S460>/Lower Test'
     *  RelationalOperator: '<S460>/Upper Test'
     */
    rtb_LogicalOperator_kn = ((rtb_Gain_kz >= rtb_IMAPve_g_ESC_VehSpd) ||
      (rtb_IMAPve_g_ESC_VehSpd >= rtb_Switch_e));

    /* Switch: '<S451>/Switch' incorporates:
     *  Constant: '<S451>/Constant'
     *  Constant: '<S451>/Constant1'
     *  Constant: '<S456>/Constant'
     *  Constant: '<S457>/Constant'
     *  Constant: '<S458>/Constant'
     *  Logic: '<S451>/Logical Operator'
     *  RelationalOperator: '<S456>/Compare'
     *  RelationalOperator: '<S457>/Compare'
     *  RelationalOperator: '<S458>/Compare'
     */
    if (((rtb_IMAPve_d_BCM_HazardLamp > ((uint8)0U)) ||
         (rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U))) ||
        (rtb_IMAPve_d_BCM_Right_Light > ((uint8)0U))) {
      rtb_L0_TLC_a = 3.0F;
    } else {
      rtb_L0_TLC_a = (-1.0F);
    }

    /* End of Switch: '<S451>/Switch' */

    /* Sum: '<S451>/Add' incorporates:
     *  Memory: '<S451>/Memory'
     */
    rtb_L0_TLC_a += LKAS_DW.Memory_PreviousInput_k;

    /* Saturate: '<S451>/Saturation' */
    if (rtb_L0_TLC_a > 200.0F) {
      rtb_Saturation_h = 200.0F;
    } else if (rtb_L0_TLC_a < (-1.0F)) {
      rtb_Saturation_h = (-1.0F);
    } else {
      rtb_Saturation_h = rtb_L0_TLC_a;
    }

    /* End of Saturate: '<S451>/Saturation' */

    /* RelationalOperator: '<S455>/Compare' incorporates:
     *  Constant: '<S455>/Constant'
     */
    rtb_Compare_oi = (rtb_Saturation_h > 1.0F);

    /* RelationalOperator: '<S459>/Compare' incorporates:
     *  Constant: '<S459>/Constant'
     */
    rtb_Compare_mc4 = (rtb_IMAPve_d_TCU_Actual_Gear != ((uint8)3U));

    /* Logic: '<S406>/Logical Operator' incorporates:
     *  Constant: '<S410>/Constant'
     *  Constant: '<S411>/Constant'
     *  RelationalOperator: '<S410>/Compare'
     *  RelationalOperator: '<S411>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_LogicalOperator_bm = ((rtb_L0_Q < ((uint8)3U)) && (rtb_R0_Q < ((uint8)3U)));

    /* Abs: '<S407>/Abs1' */
    rtb_Abs1_m = rtb_Saturation6;

    /* RelationalOperator: '<S412>/Compare' incorporates:
     *  Constant: '<S412>/Constant'
     *  Logic: '<S413>/FixPt Logical Operator'
     *  RelationalOperator: '<S413>/Lower Test'
     *  RelationalOperator: '<S413>/Upper Test'
     */
    rtb_Compare_jv = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_m) &&
      (rtb_Abs1_m <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S405>/Abs' */
    rtb_Abs_p = rtb_TTLC;

    /* Logic: '<S405>/Logical Operator' incorporates:
     *  Constant: '<S405>/Constant'
     *  Logic: '<S409>/FixPt Logical Operator'
     *  RelationalOperator: '<S409>/Lower Test'
     *  RelationalOperator: '<S409>/Upper Test'
     */
    rtb_LogicalOperator_d = ((0.0F > rtb_Abs_p) || (rtb_Abs_p >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S408>/Compare' incorporates:
     *  Constant: '<S408>/Constant'
     */
    rtb_Compare_e0 = (rtb_IMAPve_g_ESC_LatAcc > 0.04F);

    /* Switch: '<S535>/Switch72' incorporates:
     *  Constant: '<S535>/LLSMConClb26'
     *
     * Block description for '<S535>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_L0_TLC_a = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_L0_TLC_a = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S535>/Switch72' */

    /* RelationalOperator: '<S367>/Relational Operator1' */
    rtb_phiSWA_Thres = (rtb_TLft >= rtb_L0_TLC_a);

    /* Switch: '<S535>/Switch74' incorporates:
     *  Constant: '<S535>/LLSMConClb28'
     *
     * Block description for '<S535>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_L0_TLC_a = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_L0_TLC_a = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S535>/Switch74' */

    /* RelationalOperator: '<S367>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_LogicalOperator3_b_tmp >= rtb_L0_TLC_a);

    /* Switch: '<S535>/Switch79' incorporates:
     *  Constant: '<S535>/LLSMConClb29'
     *
     * Block description for '<S535>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_L0_TLC_a = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_L0_TLC_a = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S535>/Switch79' */

    /* Logic: '<S367>/Logical Operator1' incorporates:
     *  Constant: '<S370>/Constant'
     *  RelationalOperator: '<S367>/Relational Operator3'
     *  RelationalOperator: '<S370>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_b_tmp_0 >= rtb_L0_TLC_a) &&
                       (rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)));

    /* Switch: '<S535>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S367>/Unary Minus' */
      rtb_UnaryMinus_p = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S367>/Unary Minus' incorporates:
       *  Constant: '<S535>/LLSMConClb30'
       *
       * Block description for '<S535>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_p = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S535>/Switch61' */

    /* RelationalOperator: '<S371>/Compare' incorporates:
     *  Constant: '<S371>/Constant'
     *  Logic: '<S372>/FixPt Logical Operator'
     *  RelationalOperator: '<S372>/Lower Test'
     *  RelationalOperator: '<S372>/Upper Test'
     */
    rtb_Compare_mb = (((sint32)(((rtb_UnaryMinus_p < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                      ((sint32)(false ? 1 : 0)));

    /* Switch: '<S368>/Switch' incorporates:
     *  Constant: '<S373>/Constant'
     *  Constant: '<S535>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
     *  RelationalOperator: '<S373>/Compare'
     *  Switch: '<S535>/Switch38'
     *
     * Block description for '<S535>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
     *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      /* Switch: '<S535>/Switch44' incorporates:
       *  Constant: '<S535>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
       *
       * Block description for '<S535>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
       *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
       */
      if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
        rtb_L0_TLC = LKAS_ConstB.DataTypeConversion8;
      } else {
        rtb_L0_TLC = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
      }

      /* End of Switch: '<S535>/Switch44' */
    } else if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
      /* Switch: '<S535>/Switch38' */
      rtb_L0_TLC = LKAS_ConstB.DataTypeConversion6;
    } else {
      rtb_L0_TLC = LL_RlsDet_tiTrqChkT_DISABLE;
    }

    /* End of Switch: '<S368>/Switch' */

    /* Outputs for Enabled SubSystem: '<S368>/Count 20s' incorporates:
     *  EnablePort: '<S376>/Enable'
     */
    /* Logic: '<S368>/Logical Operator1' incorporates:
     *  Constant: '<S374>/Constant'
     *  Constant: '<S375>/Constant'
     *  Logic: '<S368>/Logical Operator2'
     *  RelationalOperator: '<S368>/Relational Operator'
     *  RelationalOperator: '<S374>/Compare'
     *  RelationalOperator: '<S375>/Compare'
     */
    if (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
         (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) && (rtb_LKA_Veh2CamW_C <=
         rtb_L0_TLC)) {
      if (!LKAS_DW.Count20s_MODE) {
        /* InitializeConditions for Memory: '<S376>/Memory' */
        LKAS_DW.Memory_PreviousInput_nq = 0.0F;
        LKAS_DW.Count20s_MODE = true;
      }

      /* Sum: '<S376>/Add' incorporates:
       *  Memory: '<S376>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_nq;

      /* Saturate: '<S376>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 50.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 50.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S376>/Saturation' */

      /* RelationalOperator: '<S376>/Relational Operator' incorporates:
       *  Constant: '<S376>/Constant'
       */
      LKAS_DW.RelationalOperator_k = (rtb_IMAPve_g_ESC_LatAcc >= 20.0F);

      /* Update for Memory: '<S376>/Memory' */
      LKAS_DW.Memory_PreviousInput_nq = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S376>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Count20s_MODE = false;
      }
    }

    /* End of Logic: '<S368>/Logical Operator1' */
    /* End of Outputs for SubSystem: '<S368>/Count 20s' */

    /* Saturate: '<S369>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S377>:1' */
    /* '<S377>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S377>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S377>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S377>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_IMAPve_g_ESC_VehSpd > 80.0F) {
      rtb_L0_TLC_a = 80.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      rtb_L0_TLC_a = 60.0F;
    } else {
      rtb_L0_TLC_a = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S369>/Saturation' */

    /* MATLAB Function: '<S369>/MATLAB Function' */
    if (rtb_LKA_Veh2CamW_C >= fminf(fmaxf(1.5F, ((1.5F *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL) - ((rtb_L0_TLC_a / 180.0F) *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL)) + (rtb_TTLC / 0.005F)), 2.75F)) {
      /* Outputs for Enabled SubSystem: '<S369>/Sum Condition1' incorporates:
       *  EnablePort: '<S378>/state = reset'
       */
      /* '<S377>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_m) {
        /* InitializeConditions for Memory: '<S378>/Memory' */
        LKAS_DW.Memory_PreviousInput_n = 0.0F;
        LKAS_DW.SumCondition1_MODE_m = true;
      }

      /* Sum: '<S378>/Add1' incorporates:
       *  Memory: '<S378>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_n;

      /* Saturate: '<S378>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 5000.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 5000.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S378>/Saturation' */
      /* End of Outputs for SubSystem: '<S369>/Sum Condition1' */

      /* Switch: '<S535>/Switch65' incorporates:
       *  Constant: '<S535>/LLSMConClb34'
       *
       * Block description for '<S535>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_L0_TLC_a = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_L0_TLC_a = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S535>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S369>/Sum Condition1' incorporates:
       *  EnablePort: '<S378>/state = reset'
       */
      /* RelationalOperator: '<S378>/Relational Operator' */
      LKAS_DW.RelationalOperator_im = (rtb_IMAPve_g_ESC_LatAcc >= rtb_L0_TLC_a);

      /* Update for Memory: '<S378>/Memory' */
      LKAS_DW.Memory_PreviousInput_n = rtb_IMAPve_g_ESC_LatAcc;

      /* End of Outputs for SubSystem: '<S369>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S369>/Sum Condition1' incorporates:
       *  EnablePort: '<S378>/state = reset'
       */
      /* '<S377>:1:7' else */
      /* '<S377>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S378>/Out' */
        LKAS_DW.RelationalOperator_im = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }

      /* End of Outputs for SubSystem: '<S369>/Sum Condition1' */
    }

    /* RelationalOperator: '<S387>/Compare' incorporates:
     *  Constant: '<S387>/Constant'
     */
    rtb_Compare_b2 = (((sint32)(LKAS_DW.RelationalOperator_im ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S379>/Unit Delay' */
    rtb_UnitDelay_o = LKAS_DW.UnitDelay_DSTATE_b;

    /* RelationalOperator: '<S386>/Compare' incorporates:
     *  Constant: '<S386>/Constant'
     */
    rtb_Compare_f5 = (((sint32)(rtb_UnitDelay_o ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S379>/If' incorporates:
     *  Constant: '<S382>/Constant'
     *  Constant: '<S383>/Constant'
     *  RelationalOperator: '<S380>/FixPt Relational Operator'
     *  RelationalOperator: '<S381>/FixPt Relational Operator'
     *  UnitDelay: '<S380>/Delay Input1'
     *  UnitDelay: '<S381>/Delay Input1'
     *
     * Block description for '<S380>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S381>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_im) && (((sint32)(rtb_Compare_b2 ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S379>/If Action Subsystem' incorporates:
       *  ActionPort: '<S382>/Action Port'
       */
      rtb_Merge_d = true;

      /* End of Outputs for SubSystem: '<S379>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_o) && (((sint32)(rtb_Compare_f5 ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_a ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S379>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S383>/Action Port'
       */
      rtb_Merge_d = false;

      /* End of Outputs for SubSystem: '<S379>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S379>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S384>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_o, &rtb_Merge_d);

      /* End of Outputs for SubSystem: '<S379>/If Action Subsystem3' */
    }

    /* End of If: '<S379>/If' */

    /* Outputs for Enabled SubSystem: '<S379>/Sum Condition1' incorporates:
     *  EnablePort: '<S385>/state = reset'
     */
    if (rtb_Merge_d) {
      if (!LKAS_DW.SumCondition1_MODE_d) {
        /* InitializeConditions for Memory: '<S385>/Memory' */
        LKAS_DW.Memory_PreviousInput_l = 0.0F;
        LKAS_DW.SumCondition1_MODE_d = true;
      }

      /* Sum: '<S385>/Add1' incorporates:
       *  Memory: '<S385>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_l;

      /* Saturate: '<S385>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 10.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 10.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S385>/Saturation' */

      /* RelationalOperator: '<S385>/Relational Operator' */
      LKAS_DW.RelationalOperator_b = (rtb_IMAPve_g_ESC_LatAcc <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S385>/Memory' */
      LKAS_DW.Memory_PreviousInput_l = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.SumCondition1_MODE_d) {
        /* Disable for Outport: '<S385>/Out' */
        LKAS_DW.RelationalOperator_b = false;
        LKAS_DW.SumCondition1_MODE_d = false;
      }
    }

    /* End of Outputs for SubSystem: '<S379>/Sum Condition1' */

    /* Logic: '<S353>/Logical Operator2' incorporates:
     *  Logic: '<S366>/Logical Operator1'
     *  Logic: '<S367>/Logical Operator'
     *  Logic: '<S404>/Logical Operator3'
     *  Logic: '<S454>/Logical Operator3'
     */
    rtb_LogicalOperator3_a = ((((rtb_LogicalOperator_kn || rtb_Compare_oi) ||
      rtb_Compare_mc4) || (((rtb_LogicalOperator_bm || rtb_Compare_jv) ||
      rtb_LogicalOperator_d) || rtb_Compare_e0)) || (((((rtb_phiSWA_Thres ||
      rtb_dphiSWARate_Thres) || rtb_aLAcc_Thres) || rtb_Compare_mb) ||
      (LKAS_DW.RelationalOperator_k)) || (LKAS_DW.RelationalOperator_b)));

    /* Logic: '<S393>/Logical Operator' incorporates:
     *  RelationalOperator: '<S393>/Relational Operator1'
     *  RelationalOperator: '<S393>/Relational Operator2'
     */
    rtb_stDvrTkConFlg_h = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S394>/Logical Operator' incorporates:
     *  RelationalOperator: '<S394>/Relational Operator1'
     *  RelationalOperator: '<S394>/Relational Operator2'
     */
    rtb_LogicalOperator_ar = ((rtb_Gain1 <= rtb_Abs_kj) || (rtb_Add5_k <=
      rtb_Abs_kj));

    /* If: '<S391>/If' incorporates:
     *  Constant: '<S397>/Constant'
     *  Delay: '<S76>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_IMAPve_d_EPS_LKA_State) != 1)) {
      /* Outputs for IfAction SubSystem: '<S391>/If Action Subsystem' incorporates:
       *  ActionPort: '<S395>/Action Port'
       */
      LKAS_IfActionSubsystem_ei(&rtb_Merge_g);

      /* End of Outputs for SubSystem: '<S391>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_IMAPve_d_EPS_LKA_State) != 3)) {
      /* Outputs for IfAction SubSystem: '<S391>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S396>/Action Port'
       */
      LKAS_IfActionSubsystem_ei(&rtb_Merge_g);

      /* End of Outputs for SubSystem: '<S391>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S391>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S397>/Action Port'
       */
      rtb_Merge_g = false;

      /* End of Outputs for SubSystem: '<S391>/If Action Subsystem3' */
    }

    /* End of If: '<S391>/If' */

    /* Outputs for Enabled SubSystem: '<S391>/Sum Condition1' incorporates:
     *  EnablePort: '<S398>/state = reset'
     */
    if (rtb_Merge_g) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S398>/Memory' */
        LKAS_DW.Memory_PreviousInput_b5 = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S398>/Add1' incorporates:
       *  Memory: '<S398>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_b5;

      /* Saturate: '<S398>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 60.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 60.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S398>/Saturation' */

      /* Switch: '<S535>/Switch63' incorporates:
       *  Constant: '<S535>/LLSMConClb32'
       *
       * Block description for '<S535>/LLSMConClb32':
       *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion78;
      } else {
        x10 = LL_MAX_DELAY_EPSSTAR_TIME;
      }

      /* End of Switch: '<S535>/Switch63' */

      /* RelationalOperator: '<S398>/Relational Operator' */
      LKAS_DW.RelationalOperator_d = (rtb_IMAPve_g_ESC_LatAcc >= x10);

      /* Update for Memory: '<S398>/Memory' */
      LKAS_DW.Memory_PreviousInput_b5 = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S398>/Out' */
        LKAS_DW.RelationalOperator_d = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S391>/Sum Condition1' */

    /* If: '<S353>/If2' incorporates:
     *  Constant: '<S362>/Constant'
     *  Constant: '<S399>/Constant'
     *  Constant: '<S400>/Constant'
     *  Constant: '<S401>/Constant'
     *  Constant: '<S402>/Constant'
     *  DataTypeConversion: '<S353>/Cast To Single'
     *  Logic: '<S353>/Logical Operator1'
     *  Logic: '<S392>/Logical Operator'
     *  Logic: '<S392>/Logical Operator1'
     *  RelationalOperator: '<S399>/Compare'
     *  RelationalOperator: '<S400>/Compare'
     *  RelationalOperator: '<S401>/Compare'
     *  RelationalOperator: '<S402>/Compare'
     */
    if ((((sint32)LKAS_DW.Divide) == 2) && (rtb_LogicalOperator3_a ||
         ((LKAS_DW.Divide == ((uint8)2U)) && (((rtb_stDvrTkConFlg_h == true) ||
            (rtb_LogicalOperator_ar == true)) || (LKAS_DW.RelationalOperator_d ==
            true))))) {
      /* Outputs for IfAction SubSystem: '<S353>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S362>/Action Port'
       */
      LKAS_DW.Merge2_l = true;

      /* End of Outputs for SubSystem: '<S353>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S353>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S364>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2_l);

      /* End of Outputs for SubSystem: '<S353>/If Action Subsystem3' */
    }

    /* End of If: '<S353>/If2' */

    /* Product: '<S269>/Divide' */
    rtb_LKA_Veh2CamL_C = rtb_L0_C1_k * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S269>/Divide1' */
    rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* If: '<S291>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_IMAPve_g_ESC_LatAcc >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S291>/Ph1SWA' incorporates:
       *  ActionPort: '<S295>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S291>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_IMAPve_g_ESC_LatAcc <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S291>/Ph2SWA' incorporates:
       *  ActionPort: '<S296>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S291>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S291>/Ph3SWA' incorporates:
       *  ActionPort: '<S297>/Action Port'
       */
      LKAS_Ph3SWA_l(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S291>/Ph3SWA' */
    }

    /* End of If: '<S291>/If' */

    /* Saturate: '<S269>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      x20 = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      x20 = (-2.0F);
    } else {
      x20 = rtb_Gain1;
    }

    /* End of Saturate: '<S269>/Saturation5' */

    /* MATLAB Function: '<S278>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LaneWidth, rtb_LKA_CarWidth,
                        rtb_LL_ThresDet_lDvtThresUprLDW,
                        &rtb_ThresDet_coefficient_c);

    /* Product: '<S278>/Divide5' */
    rtb_Saturation6 = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S278>/Divide6' */
    rtb_L0_TLC_a = rtb_ThresDet_coefficient_c * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S293>/Abs' incorporates:
     *  Abs: '<S284>/Abs'
     */
    rtb_LogicalOperator3_b_tmp = fabsf(rtb_LKA_Veh2CamL_C);

    /* Product: '<S293>/Divide' incorporates:
     *  Abs: '<S293>/Abs'
     */
    rtb_Divide_h = rtb_L0_TLC_a * rtb_LogicalOperator3_b_tmp;

    /* Product: '<S278>/Divide4' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S298>/Switch' incorporates:
     *  RelationalOperator: '<S298>/UpperRelop'
     */
    if (rtb_Divide_h < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_n = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_n = rtb_Divide_h;
    }

    /* End of Switch: '<S298>/Switch' */

    /* Switch: '<S298>/Switch2' incorporates:
     *  RelationalOperator: '<S298>/LowerRelop1'
     */
    if (rtb_Divide_h > rtb_Saturation6) {
      rtb_Switch2_j = rtb_Saturation6;
    } else {
      rtb_Switch2_j = rtb_Switch_n;
    }

    /* End of Switch: '<S298>/Switch2' */

    /* Saturate: '<S269>/Saturation1' */
    if (rtb_Add5_k > 2.0F) {
      rtb_LL_LKA_EarliestWarnLine_C = 2.0F;
    } else if (rtb_Add5_k < (-2.0F)) {
      rtb_LL_LKA_EarliestWarnLine_C = (-2.0F);
    } else {
      rtb_LL_LKA_EarliestWarnLine_C = rtb_Add5_k;
    }

    /* End of Saturate: '<S269>/Saturation1' */

    /* Abs: '<S294>/Abs' incorporates:
     *  Abs: '<S285>/Abs'
     */
    rtb_LogicalOperator3_b_tmp_0 = fabsf(rtb_IMAPve_g_ESC_LatAcc);

    /* Product: '<S294>/Divide' incorporates:
     *  Abs: '<S294>/Abs'
     */
    rtb_Divide_i = rtb_L0_TLC_a * rtb_LogicalOperator3_b_tmp_0;

    /* Switch: '<S299>/Switch' incorporates:
     *  RelationalOperator: '<S299>/UpperRelop'
     */
    if (rtb_Divide_i < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_ki = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_ki = rtb_Divide_i;
    }

    /* End of Switch: '<S299>/Switch' */

    /* Switch: '<S299>/Switch2' incorporates:
     *  RelationalOperator: '<S299>/LowerRelop1'
     */
    if (rtb_Divide_i > rtb_Saturation6) {
      rtb_Switch2_n = rtb_Saturation6;
    } else {
      rtb_Switch2_n = rtb_Switch_ki;
    }

    /* End of Switch: '<S299>/Switch2' */

    /* Switch: '<S292>/Switch3' incorporates:
     *  Constant: '<S294>/Constant'
     *  Gain: '<S292>/Gain1'
     *  Logic: '<S294>/Logical Operator'
     *  RelationalOperator: '<S294>/Relational Operator1'
     *  RelationalOperator: '<S294>/Relational Operator2'
     */
    if (rtb_Merge1_j >= 0.0F) {
      /* Switch: '<S292>/Switch2' incorporates:
       *  Constant: '<S292>/Constant2'
       *  Constant: '<S293>/Constant'
       *  DataTypeConversion: '<S292>/Cast To Single'
       *  Logic: '<S293>/Logical Operator'
       *  RelationalOperator: '<S293>/Relational Operator1'
       *  RelationalOperator: '<S293>/Relational Operator3'
       */
      if (rtb_Merge1_j > 0.0F) {
        rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((0.0F < x20) && (x20 <=
          rtb_Switch2_j)) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_HazardLamp = ((uint8)0U);
      }

      /* End of Switch: '<S292>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((((uint32)(((0.0F <
        rtb_LL_LKA_EarliestWarnLine_C) && (rtb_LL_LKA_EarliestWarnLine_C <=
        rtb_Switch2_n)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S292>/Switch3' */

    /* DataTypeConversion: '<S271>/Data Type Conversion' incorporates:
     *  Constant: '<S302>/Constant'
     *  Constant: '<S303>/Constant'
     *  Constant: '<S304>/Constant'
     *  Constant: '<S305>/Constant'
     *  Logic: '<S271>/Logical Operator'
     *  Logic: '<S271>/Logical Operator1'
     *  Logic: '<S271>/Logical Operator2'
     *  RelationalOperator: '<S302>/Compare'
     *  RelationalOperator: '<S303>/Compare'
     *  RelationalOperator: '<S304>/Compare'
     *  RelationalOperator: '<S305>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_EPS_LKA_Control = (UInt8)((((rtb_R0_Q > ((uint8)2U)) &&
      (rtb_IMAPve_d_BCM_HazardLamp == ((uint8)2U))) ||
      ((rtb_IMAPve_d_BCM_HazardLamp == ((uint8)1U)) && (rtb_L0_Q > ((uint8)2U))))
      ? 1 : 0);

    /* DataTypeConversion: '<S270>/Data Type Conversion' incorporates:
     *  Constant: '<S300>/Constant'
     *  Constant: '<S301>/Constant'
     *  Logic: '<S270>/Logical Operator'
     *  RelationalOperator: '<S300>/Compare'
     *  RelationalOperator: '<S301>/Compare'
     */
    rtb_IMAPve_d_BCM_Left_Light = (uint8)(((rtb_IMAPve_d_EPS_LKA_State ==
      ((uint8)1U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? 1 : 0);

    /* If: '<S268>/If1' incorporates:
     *  Constant: '<S273>/Constant'
     *  Constant: '<S276>/Constant'
     *  Constant: '<S277>/Constant'
     */
    if ((((((sint32)LKAS_DW.Divide) == 2) && (((sint32)
            rtb_IMAPve_d_BCM_HazardLamp) == 1)) && (((sint32)
           rtb_IMAPve_d_BCM_Left_Light) == 1)) && (((sint32)rtb_EPS_LKA_Control)
         == 1)) {
      /* Outputs for IfAction SubSystem: '<S268>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S276>/Action Port'
       */
      LKAS_DW.Merge2 = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S268>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.Divide) == 2) && (((sint32)
        rtb_IMAPve_d_BCM_HazardLamp) == 2)) && (((sint32)
                  rtb_IMAPve_d_BCM_Left_Light) == 1)) && (((sint32)
                 rtb_EPS_LKA_Control) == 1)) {
      /* Outputs for IfAction SubSystem: '<S268>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S277>/Action Port'
       */
      LKAS_DW.Merge2 = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S268>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S268>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S273>/Action Port'
       */
      LKAS_DW.Merge2 = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S268>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S268>/If1' */

    /* Product: '<S307>/Divide' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_L0_C1_k * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S307>/Divide1' */
    rtb_LKA_Veh2CamW_C = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* If: '<S327>/If' */
    if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) ||
        (rtb_LKA_Veh2CamW_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S327>/Ph1SWA' incorporates:
       *  ActionPort: '<S331>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_m);

      /* End of Outputs for SubSystem: '<S327>/Ph1SWA' */
    } else if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_LKA_Veh2CamW_C <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S327>/Ph2SWA' incorporates:
       *  ActionPort: '<S332>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_m);

      /* End of Outputs for SubSystem: '<S327>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S327>/Ph3SWA' incorporates:
       *  ActionPort: '<S333>/Action Port'
       */
      LKAS_Ph3SWA_l(&rtb_Merge1_m);

      /* End of Outputs for SubSystem: '<S327>/Ph3SWA' */
    }

    /* End of If: '<S327>/If' */

    /* Saturate: '<S307>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_L0_TLC = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_L0_TLC = (-2.0F);
    } else {
      rtb_L0_TLC = rtb_Gain1;
    }

    /* End of Saturate: '<S307>/Saturation5' */

    /* MATLAB Function: '<S314>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LaneWidth, rtb_LKA_CarWidth,
                        rtb_LL_ThresDet_lDvtThresUprLDW,
                        &rtb_ThresDet_coefficient);

    /* Product: '<S314>/Divide5' */
    rtb_L0_TLC_a = rtb_ThresDet_coefficient * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S314>/Divide6' */
    rtb_Saturation6 = rtb_ThresDet_coefficient * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S329>/Divide' incorporates:
     *  Abs: '<S329>/Abs'
     */
    rtb_Divide_j = rtb_Saturation6 * fabsf(rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Product: '<S314>/Divide4' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S334>/Switch' incorporates:
     *  RelationalOperator: '<S334>/UpperRelop'
     */
    if (rtb_Divide_j < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_d = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_d = rtb_Divide_j;
    }

    /* End of Switch: '<S334>/Switch' */

    /* Switch: '<S334>/Switch2' incorporates:
     *  RelationalOperator: '<S334>/LowerRelop1'
     */
    if (rtb_Divide_j > rtb_L0_TLC_a) {
      rtb_Switch2_m = rtb_L0_TLC_a;
    } else {
      rtb_Switch2_m = rtb_Switch_d;
    }

    /* End of Switch: '<S334>/Switch2' */

    /* Saturate: '<S307>/Saturation1' */
    if (rtb_Add5_k > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_k < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_k;
    }

    /* End of Saturate: '<S307>/Saturation1' */

    /* Product: '<S330>/Divide' incorporates:
     *  Abs: '<S330>/Abs'
     */
    rtb_Divide_m = rtb_Saturation6 * fabsf(rtb_LKA_Veh2CamW_C);

    /* Switch: '<S335>/Switch' incorporates:
     *  RelationalOperator: '<S335>/UpperRelop'
     */
    if (rtb_Divide_m < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_g = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_g = rtb_Divide_m;
    }

    /* End of Switch: '<S335>/Switch' */

    /* Switch: '<S335>/Switch2' incorporates:
     *  RelationalOperator: '<S335>/LowerRelop1'
     */
    if (rtb_Divide_m > rtb_L0_TLC_a) {
      rtb_Switch2_i = rtb_L0_TLC_a;
    } else {
      rtb_Switch2_i = rtb_Switch_g;
    }

    /* End of Switch: '<S335>/Switch2' */

    /* Switch: '<S328>/Switch3' incorporates:
     *  Constant: '<S330>/Constant'
     *  Gain: '<S328>/Gain1'
     *  Logic: '<S330>/Logical Operator'
     *  RelationalOperator: '<S330>/Relational Operator1'
     *  RelationalOperator: '<S330>/Relational Operator2'
     */
    if (rtb_Merge1_m >= 0.0F) {
      /* Switch: '<S328>/Switch2' incorporates:
       *  Constant: '<S328>/Constant2'
       *  Constant: '<S329>/Constant'
       *  DataTypeConversion: '<S328>/Cast To Single'
       *  Logic: '<S329>/Logical Operator'
       *  RelationalOperator: '<S329>/Relational Operator1'
       *  RelationalOperator: '<S329>/Relational Operator3'
       */
      if (rtb_Merge1_m > 0.0F) {
        rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((0.0F < rtb_L0_TLC) &&
          (rtb_L0_TLC <= rtb_Switch2_m)) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_HazardLamp = ((uint8)0U);
      }

      /* End of Switch: '<S328>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((((uint32)(((0.0F <
        rtb_LL_ThresDet_lDvtThresLwrLKA) && (rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_i)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S328>/Switch3' */

    /* MATLAB Function: '<S308>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S339>:1' */
    /* '<S339>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S339>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S339>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S339>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_IMAPve_g_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge_i), 0.005F)) / 0.005F);

    /* '<S339>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_IMAPve_d_BCM_HazardLamp) == 2) &&
         (rtb_IMAPve_g_EPS_SW_Trq > rtb_LL_MAX_DRIVER_TORQUE_DISABL)) ||
        ((((sint32)rtb_IMAPve_d_BCM_HazardLamp) == 1) &&
         (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL)))) {
      /* Outputs for Enabled SubSystem: '<S308>/Count 0.2s' incorporates:
       *  EnablePort: '<S338>/Enable'
       */
      /* '<S339>:1:7' stDvrTkConFlg=1; */
      /* '<S339>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S339>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S338>/Memory' */
        LKAS_DW.Memory_PreviousInput_bt = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S338>/Add' incorporates:
       *  Memory: '<S338>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_bt;

      /* Saturate: '<S338>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S338>/Saturation' */
      /* End of Outputs for SubSystem: '<S308>/Count 0.2s' */

      /* Switch: '<S535>/Switch16' incorporates:
       *  Constant: '<S535>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S535>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S535>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S308>/Count 0.2s' incorporates:
       *  EnablePort: '<S338>/Enable'
       */
      /* RelationalOperator: '<S338>/Relational Operator' */
      LKAS_DW.RelationalOperator_os = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S338>/Memory' */
      LKAS_DW.Memory_PreviousInput_bt = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S308>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S308>/Count 0.2s' incorporates:
       *  EnablePort: '<S338>/Enable'
       */
      /* '<S339>:1:10' else */
      /* '<S339>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S338>/Out' */
        LKAS_DW.RelationalOperator_os = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S308>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S308>/MATLAB Function' */

    /* RelationalOperator: '<S348>/Compare' incorporates:
     *  Constant: '<S348>/Constant'
     */
    rtb_Compare_md = (((sint32)(LKAS_DW.RelationalOperator_os ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S340>/Unit Delay' */
    rtb_UnitDelay_e = LKAS_DW.UnitDelay_DSTATE_lt;

    /* RelationalOperator: '<S347>/Compare' incorporates:
     *  Constant: '<S347>/Constant'
     */
    rtb_Compare_pf = (((sint32)(rtb_UnitDelay_e ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S340>/If' incorporates:
     *  Constant: '<S343>/Constant'
     *  Constant: '<S344>/Constant'
     *  RelationalOperator: '<S341>/FixPt Relational Operator'
     *  RelationalOperator: '<S342>/FixPt Relational Operator'
     *  UnitDelay: '<S341>/Delay Input1'
     *  UnitDelay: '<S342>/Delay Input1'
     *
     * Block description for '<S341>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S342>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_os) && (((sint32)(rtb_Compare_md ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_e ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S340>/If Action Subsystem' incorporates:
       *  ActionPort: '<S343>/Action Port'
       */
      rtb_Merge_o = true;

      /* End of Outputs for SubSystem: '<S340>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_e) && (((sint32)(rtb_Compare_pf ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_n ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S340>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S344>/Action Port'
       */
      rtb_Merge_o = false;

      /* End of Outputs for SubSystem: '<S340>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S340>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S345>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_e, &rtb_Merge_o);

      /* End of Outputs for SubSystem: '<S340>/If Action Subsystem3' */
    }

    /* End of If: '<S340>/If' */

    /* Outputs for Enabled SubSystem: '<S308>/Count' incorporates:
     *  EnablePort: '<S337>/Enable'
     */
    /* Logic: '<S308>/Logical Operator' incorporates:
     *  Constant: '<S336>/Constant'
     *  Memory: '<S308>/Memory'
     *  RelationalOperator: '<S336>/Compare'
     */
    if ((rtb_IMAPve_d_BCM_HazardLamp > ((uint8)0U)) &&
        (LKAS_DW.Memory_PreviousInput_i2)) {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S337>/Memory' */
        LKAS_DW.Memory_PreviousInput_nx = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S337>/Add' incorporates:
       *  Memory: '<S337>/Memory'
       */
      rtb_L0_TLC_a = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_nx;

      /* Saturate: '<S337>/Saturation' */
      if (rtb_L0_TLC_a > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_L0_TLC_a < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S337>/Saturation' */

      /* Update for Memory: '<S337>/Memory' */
      LKAS_DW.Memory_PreviousInput_nx = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S337>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S308>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S308>/Count' */

    /* Outputs for Enabled SubSystem: '<S340>/Sum Condition1' incorporates:
     *  EnablePort: '<S346>/state = reset'
     */
    if (rtb_Merge_o) {
      if (!LKAS_DW.SumCondition1_MODE_h) {
        /* InitializeConditions for Memory: '<S346>/Memory' */
        LKAS_DW.Memory_PreviousInput_f = 0.0F;
        LKAS_DW.SumCondition1_MODE_h = true;
      }

      /* Sum: '<S346>/Add1' incorporates:
       *  Memory: '<S346>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_f;

      /* Saturate: '<S346>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S346>/Saturation' */

      /* Switch: '<S535>/Switch40' incorporates:
       *  Constant: '<S535>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S535>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S535>/Switch40' */

      /* RelationalOperator: '<S346>/Relational Operator' incorporates:
       *  Sum: '<S308>/Add'
       */
      LKAS_DW.RelationalOperator_n = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S346>/Memory' */
      LKAS_DW.Memory_PreviousInput_f = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_h) {
        /* Disable for Outport: '<S346>/Out' */
        LKAS_DW.RelationalOperator_n = false;
        LKAS_DW.SumCondition1_MODE_h = false;
      }
    }

    /* End of Outputs for SubSystem: '<S340>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S309>/Sum Condition1' incorporates:
     *  EnablePort: '<S352>/state = reset'
     */
    /* Logic: '<S309>/Logical Operator' incorporates:
     *  Constant: '<S350>/Constant'
     *  Constant: '<S351>/Constant'
     *  Delay: '<S76>/Delay1'
     *  RelationalOperator: '<S350>/Compare'
     *  RelationalOperator: '<S351>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_c) {
        /* InitializeConditions for Memory: '<S352>/Memory' */
        LKAS_DW.Memory_PreviousInput_ht = 0.0F;
        LKAS_DW.SumCondition1_MODE_c = true;
      }

      /* Sum: '<S352>/Add1' incorporates:
       *  Memory: '<S352>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_ht;

      /* Saturate: '<S352>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S352>/Saturation' */

      /* RelationalOperator: '<S352>/Relational Operator' */
      LKAS_DW.RelationalOperator_p = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S352>/Memory' */
      LKAS_DW.Memory_PreviousInput_ht = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_c) {
        /* Disable for Outport: '<S352>/Out' */
        LKAS_DW.RelationalOperator_p = false;
        LKAS_DW.SumCondition1_MODE_c = false;
      }
    }

    /* End of Logic: '<S309>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S309>/Sum Condition1' */

    /* If: '<S306>/If1' incorporates:
     *  Constant: '<S311>/Constant'
     *  Constant: '<S313>/Constant'
     *  Constant: '<S349>/Constant'
     *  Delay: '<S76>/Delay'
     *  Logic: '<S306>/Logical Operator'
     *  Logic: '<S309>/Logical Operator1'
     *  RelationalOperator: '<S349>/Compare'
     */
    if ((((sint32)LKAS_DW.Divide) == 2) && (((LKAS_DW.RelationalOperator_n) ||
          ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_p))) || (LKAS_DW.Delay_DSTATE_l))) {
      /* Outputs for IfAction SubSystem: '<S306>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S313>/Action Port'
       */
      LKAS_DW.Merge1_g = true;

      /* End of Outputs for SubSystem: '<S306>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S306>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S311>/Action Port'
       */
      LKAS_DW.Merge1_g = false;

      /* End of Outputs for SubSystem: '<S306>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S306>/If1' */

    /* Sum: '<S476>/Add1' */
    rtb_Add1_j = x1;

    /* Switch: '<S477>/Switch' incorporates:
     *  Constant: '<S476>/Constant'
     *  RelationalOperator: '<S477>/UpperRelop'
     */
    if (rtb_Add1_j < 0.0F) {
      rtb_Switch_o = 0.0F;
    } else {
      rtb_Switch_o = rtb_Add1_j;
    }

    /* End of Switch: '<S477>/Switch' */

    /* Switch: '<S477>/Switch2' incorporates:
     *  RelationalOperator: '<S477>/LowerRelop1'
     */
    if (rtb_Add1_j > rtb_LL_LDW_EarliestWarnLine_C) {
      rtb_Switch2_p = rtb_LL_LDW_EarliestWarnLine_C;
    } else {
      rtb_Switch2_p = rtb_Switch_o;
    }

    /* End of Switch: '<S477>/Switch2' */

    /* Logic: '<S462>/Logical Operator3' incorporates:
     *  Constant: '<S474>/Constant'
     *  Constant: '<S475>/Constant'
     *  Logic: '<S472>/Logical Operator'
     *  Logic: '<S473>/Logical Operator'
     *  RelationalOperator: '<S473>/Relational Operator1'
     *  RelationalOperator: '<S473>/Relational Operator2'
     *  RelationalOperator: '<S474>/Compare'
     *  RelationalOperator: '<S475>/Compare'
     */
    rtb_LogicalOperator3_d = (((LKAS_DW.Divide >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1 >= rtb_Switch2_p) && (rtb_Add5_k >= rtb_Switch2_p)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_d);

    /* If: '<S462>/If' incorporates:
     *  Constant: '<S468>/Constant'
     *  DataTypeConversion: '<S462>/Cast To Single'
     *  DataTypeConversion: '<S462>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
        rtb_LogicalOperator3_d) {
      /* Outputs for IfAction SubSystem: '<S462>/If Action Subsystem' incorporates:
       *  ActionPort: '<S468>/Action Port'
       */
      LKAS_DW.Merge_d = true;

      /* End of Outputs for SubSystem: '<S462>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S462>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S470>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_d);

      /* End of Outputs for SubSystem: '<S462>/If Action Subsystem3' */
    }

    /* End of If: '<S462>/If' */

    /* Delay: '<S76>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S355>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S355>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_mz != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S355>/If Action Subsystem' incorporates:
         *  ActionPort: '<S388>/Action Port'
         */
        /* InitializeConditions for If: '<S355>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S388>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_h = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S355>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S355>/If Action Subsystem' incorporates:
       *  ActionPort: '<S388>/Action Port'
       */
      /* Sum: '<S388>/Add1' incorporates:
       *  Memory: '<S388>/Memory'
       */
      rtb_LL_LDW_EarliestWarnLine_C = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_h;

      /* Saturate: '<S388>/Saturation' */
      if (rtb_LL_LDW_EarliestWarnLine_C > 10.0F) {
        rtb_LL_LDW_EarliestWarnLine_C = 10.0F;
      } else {
        if (rtb_LL_LDW_EarliestWarnLine_C < 0.0F) {
          rtb_LL_LDW_EarliestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S388>/Saturation' */
      /* End of Outputs for SubSystem: '<S355>/If Action Subsystem' */

      /* Switch: '<S535>/Switch64' incorporates:
       *  Constant: '<S535>/LLSMConClb33'
       *
       * Block description for '<S535>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S535>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S355>/If Action Subsystem' incorporates:
       *  ActionPort: '<S388>/Action Port'
       */
      /* RelationalOperator: '<S388>/Relational Operator' */
      rtb_Merge = (rtb_LL_LDW_EarliestWarnLine_C >= x10);

      /* Update for Memory: '<S388>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = rtb_LL_LDW_EarliestWarnLine_C;

      /* End of Outputs for SubSystem: '<S355>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S355>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S389>/Action Port'
       */
      /* SignalConversion: '<S389>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S389>/Constant'
       */
      rtb_Merge = false;

      /* End of Outputs for SubSystem: '<S355>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S355>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S356>/Logical Operator1' incorporates:
     *  Constant: '<S390>/Constant'
     *  Logic: '<S356>/Logical Operator'
     *  RelationalOperator: '<S356>/Relational Operator1'
     *  RelationalOperator: '<S356>/Relational Operator2'
     *  RelationalOperator: '<S390>/Compare'
     */
    rtb_LogicalOperator3_d = ((LKAS_DW.Divide >= ((uint8)1U)) && ((rtb_Gain1 <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_k <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S353>/Logical Operator3' */
    rtb_LogicalOperator3_a = ((rtb_LogicalOperator3_d || rtb_Merge) ||
      rtb_LogicalOperator3_a);

    /* If: '<S353>/If1' incorporates:
     *  Constant: '<S363>/Constant'
     *  DataTypeConversion: '<S353>/Cast To Single'
     *  DataTypeConversion: '<S353>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
        rtb_LogicalOperator3_a) {
      /* Outputs for IfAction SubSystem: '<S353>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S363>/Action Port'
       */
      LKAS_DW.Merge1_n = true;

      /* End of Outputs for SubSystem: '<S353>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S353>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S365>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_n);

      /* End of Outputs for SubSystem: '<S353>/If Action Subsystem4' */
    }

    /* End of If: '<S353>/If1' */

    /* Memory: '<S282>/Memory' */
    rtb_Memory_g = LKAS_DW.Memory_PreviousInput_a;

    /* If: '<S282>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_IMAPve_g_ESC_LatAcc >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S282>/Ph1SWA' incorporates:
       *  ActionPort: '<S286>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_e);

      /* End of Outputs for SubSystem: '<S282>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_IMAPve_g_ESC_LatAcc <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S282>/Ph2SWA' incorporates:
       *  ActionPort: '<S287>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_e);

      /* End of Outputs for SubSystem: '<S282>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S282>/Ph3SWA' incorporates:
       *  ActionPort: '<S288>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_g, &rtb_Merge1_e);

      /* End of Outputs for SubSystem: '<S282>/Ph3SWA' */
    }

    /* End of If: '<S282>/If' */

    /* Product: '<S278>/Divide2' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S278>/Divide3' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient_c *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S284>/Divide' */
    rtb_Divide_it = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LogicalOperator3_b_tmp;

    /* Product: '<S278>/Divide1' */
    rtb_L0_TLC_a = rtb_ThresDet_coefficient_c * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S289>/Switch' incorporates:
     *  RelationalOperator: '<S289>/UpperRelop'
     */
    if (rtb_Divide_it < rtb_L0_TLC_a) {
      rtb_Switch_on = rtb_L0_TLC_a;
    } else {
      rtb_Switch_on = rtb_Divide_it;
    }

    /* End of Switch: '<S289>/Switch' */

    /* Switch: '<S289>/Switch2' incorporates:
     *  RelationalOperator: '<S289>/LowerRelop1'
     */
    if (rtb_Divide_it > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_f = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_f = rtb_Switch_on;
    }

    /* End of Switch: '<S289>/Switch2' */

    /* Product: '<S285>/Divide' */
    rtb_Divide_pg = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LogicalOperator3_b_tmp_0;

    /* Switch: '<S290>/Switch' incorporates:
     *  RelationalOperator: '<S290>/UpperRelop'
     */
    if (rtb_Divide_pg < rtb_L0_TLC_a) {
      rtb_Switch_gf = rtb_L0_TLC_a;
    } else {
      rtb_Switch_gf = rtb_Divide_pg;
    }

    /* End of Switch: '<S290>/Switch' */

    /* Switch: '<S290>/Switch2' incorporates:
     *  RelationalOperator: '<S290>/LowerRelop1'
     */
    if (rtb_Divide_pg > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_l = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_l = rtb_Switch_gf;
    }

    /* End of Switch: '<S290>/Switch2' */

    /* Switch: '<S283>/Switch3' incorporates:
     *  Gain: '<S283>/Gain1'
     *  RelationalOperator: '<S285>/Relational Operator2'
     */
    if (rtb_Merge1_e >= 0.0F) {
      /* Switch: '<S283>/Switch2' incorporates:
       *  Constant: '<S283>/Constant2'
       *  DataTypeConversion: '<S283>/Cast To Single'
       *  RelationalOperator: '<S284>/Relational Operator2'
       */
      if (rtb_Merge1_e > 0.0F) {
        rtb_IMAPve_d_BCM_Left_Light = (uint8)((x20 <= rtb_Switch2_f) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_Left_Light = ((uint8)0U);
      }

      /* End of Switch: '<S283>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Left_Light = (uint8)((((uint32)
        ((rtb_LL_LKA_EarliestWarnLine_C <= rtb_Switch2_l) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S283>/Switch3' */

    /* If: '<S268>/If' incorporates:
     *  Constant: '<S272>/Constant'
     *  Constant: '<S274>/Constant'
     *  Constant: '<S275>/Constant'
     */
    if ((((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
         (((sint32)rtb_IMAPve_d_BCM_Left_Light) == 1)) && (((sint32)
          rtb_EPS_LKA_Control) == 1)) {
      /* Outputs for IfAction SubSystem: '<S268>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S274>/Action Port'
       */
      LKAS_DW.Merge_k = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S268>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) ==
      2)) && (((sint32)rtb_IMAPve_d_BCM_Left_Light) == 2)) && (((sint32)
                 rtb_EPS_LKA_Control) == 1)) {
      /* Outputs for IfAction SubSystem: '<S268>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S275>/Action Port'
       */
      LKAS_DW.Merge_k = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S268>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S268>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S272>/Action Port'
       */
      LKAS_DW.Merge_k = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S268>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S268>/If' */

    /* Memory: '<S318>/Memory' */
    rtb_Memory_b = LKAS_DW.Memory_PreviousInput_b;

    /* If: '<S318>/If' */
    if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_LKA_Veh2CamW_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S318>/Ph1SWA' incorporates:
       *  ActionPort: '<S322>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_bm);

      /* End of Outputs for SubSystem: '<S318>/Ph1SWA' */
    } else if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_LKA_Veh2CamW_C <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S318>/Ph2SWA' incorporates:
       *  ActionPort: '<S323>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_bm);

      /* End of Outputs for SubSystem: '<S318>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S318>/Ph3SWA' incorporates:
       *  ActionPort: '<S324>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_b, &rtb_Merge1_bm);

      /* End of Outputs for SubSystem: '<S318>/Ph3SWA' */
    }

    /* End of If: '<S318>/If' */

    /* Product: '<S314>/Divide2' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S314>/Divide3' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Abs: '<S320>/Abs' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = fabsf(rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Product: '<S320>/Divide' */
    rtb_Divide_c = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;

    /* Product: '<S314>/Divide1' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S325>/Switch' incorporates:
     *  RelationalOperator: '<S325>/UpperRelop'
     */
    if (rtb_Divide_c < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_g0 = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_g0 = rtb_Divide_c;
    }

    /* End of Switch: '<S325>/Switch' */

    /* Switch: '<S325>/Switch2' incorporates:
     *  RelationalOperator: '<S325>/LowerRelop1'
     */
    if (rtb_Divide_c > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_ni = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_ni = rtb_Switch_g0;
    }

    /* End of Switch: '<S325>/Switch2' */

    /* Abs: '<S321>/Abs' */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_LKA_Veh2CamW_C);

    /* Product: '<S321>/Divide' */
    rtb_Divide_g = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LKA_Veh2CamW_C;

    /* Switch: '<S326>/Switch' incorporates:
     *  RelationalOperator: '<S326>/UpperRelop'
     */
    if (rtb_Divide_g < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_kp = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_kp = rtb_Divide_g;
    }

    /* End of Switch: '<S326>/Switch' */

    /* Switch: '<S326>/Switch2' incorporates:
     *  RelationalOperator: '<S326>/LowerRelop1'
     */
    if (rtb_Divide_g > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_ll = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_ll = rtb_Switch_kp;
    }

    /* End of Switch: '<S326>/Switch2' */

    /* Switch: '<S319>/Switch3' incorporates:
     *  Gain: '<S319>/Gain1'
     *  RelationalOperator: '<S321>/Relational Operator2'
     */
    if (rtb_Merge1_bm >= 0.0F) {
      /* Switch: '<S319>/Switch2' incorporates:
       *  Constant: '<S319>/Constant2'
       *  DataTypeConversion: '<S319>/Cast To Single'
       *  RelationalOperator: '<S320>/Relational Operator2'
       */
      if (rtb_Merge1_bm > 0.0F) {
        rtb_IMAPve_d_BCM_HazardLamp = (uint8)((rtb_L0_TLC <= rtb_Switch2_ni) ? 1
          : 0);
      } else {
        rtb_IMAPve_d_BCM_HazardLamp = ((uint8)0U);
      }

      /* End of Switch: '<S319>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((((uint32)
        ((rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_ll) ? 1 : 0)) *
        ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S319>/Switch3' */

    /* If: '<S306>/If' incorporates:
     *  Constant: '<S310>/Constant'
     *  Constant: '<S312>/Constant'
     */
    if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
        (((sint32)rtb_IMAPve_d_BCM_HazardLamp) == 0)) {
      /* Outputs for IfAction SubSystem: '<S306>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S312>/Action Port'
       */
      LKAS_DW.Merge_o = true;

      /* End of Outputs for SubSystem: '<S306>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S306>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S310>/Action Port'
       */
      LKAS_DW.Merge_o = false;

      /* End of Outputs for SubSystem: '<S306>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S306>/If' */

    /* Outputs for Enabled SubSystem: '<S267>/Count_5s3' incorporates:
     *  EnablePort: '<S531>/Enable'
     */
    /* RelationalOperator: '<S516>/Compare' incorporates:
     *  Constant: '<S516>/Constant'
     *  Constant: '<S542>/Constant'
     */
    if (((uint8)0U) == ((uint8)1U)) {
      if (!LKAS_DW.Count_5s3_MODE) {
        /* InitializeConditions for Memory: '<S531>/Memory' */
        LKAS_DW.Memory_PreviousInput_a3 = 0.0F;
        LKAS_DW.Count_5s3_MODE = true;
      }

      /* Sum: '<S531>/Add' incorporates:
       *  Memory: '<S531>/Memory'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_DW.Memory_PreviousInput_a3 +
        rtb_LKA_SampleTime;

      /* Saturate: '<S531>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 11.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 11.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S531>/Saturation' */

      /* RelationalOperator: '<S531>/Relational Operator' incorporates:
       *  Constant: '<S531>/Constant1'
       */
      LKAS_DW.RelationalOperator = (rtb_LL_ThresDet_lDvtThresLwrLDW >= ((float32)
        ((uint16)5U)));

      /* Update for Memory: '<S531>/Memory' */
      LKAS_DW.Memory_PreviousInput_a3 = rtb_LL_ThresDet_lDvtThresLwrLDW;
    } else {
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S531>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S516>/Compare' */
    /* End of Outputs for SubSystem: '<S267>/Count_5s3' */

    /* RelationalOperator: '<S521>/Compare' incorporates:
     *  Constant: '<S521>/Constant'
     */
    rtb_Compare_jf = (rtb_IMAPve_d_Camera_Status == ((uint8)3U));

    /* Outputs for Enabled SubSystem: '<S267>/Count_5s2' */
    LKAS_Count_5s1(rtb_Compare_jf, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_o, &LKAS_DW.Count_5s2);

    /* End of Outputs for SubSystem: '<S267>/Count_5s2' */

    /* Logic: '<S267>/Logical Operator10' */
    LKAS_DW.LKA_Fault = ((LKAS_DW.RelationalOperator) ||
                         (LKAS_DW.RelationalOperator_o));

    /* Chart: '<S76>/LDW_State_Machine'
     *
     * Block description for '<S76>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* RelationalOperator: '<S520>/Compare' incorporates:
     *  Constant: '<S520>/Constant'
     */
    rtb_Compare_fqp = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

    /* Outputs for Enabled SubSystem: '<S267>/Count_5s1' */
    LKAS_Count_5s1(rtb_Compare_fqp, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_i, &LKAS_DW.Count_5s1);

    /* End of Outputs for SubSystem: '<S267>/Count_5s1' */

    /* Logic: '<S267>/Logical Operator8' */
    LKAS_DW.LKA_Fault = (((LKAS_DW.RelationalOperator) ||
                          (LKAS_DW.RelationalOperator_o)) ||
                         (LKAS_DW.RelationalOperator_i));

    /* Chart: '<S76>/LKA_State_Machine'
     *
     * Block description for '<S76>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S244>/Subsystem' incorporates:
     *  EnablePort: '<S248>/Enable'
     */
    /* Logic: '<S244>/Logical Operator3' incorporates:
     *  Abs: '<S244>/Abs4'
     *  Abs: '<S244>/Abs5'
     *  Abs: '<S244>/Abs6'
     *  Abs: '<S244>/Abs7'
     *  Constant: '<S244>/Constant'
     *  Constant: '<S244>/Constant1'
     *  Constant: '<S244>/Constant4'
     *  Constant: '<S244>/Constant5'
     *  Constant: '<S246>/Constant'
     *  Constant: '<S247>/Constant'
     *  Logic: '<S244>/Logical Operator'
     *  Logic: '<S244>/Logical Operator1'
     *  Logic: '<S244>/Logical Operator4'
     *  RelationalOperator: '<S244>/Relational Operator'
     *  RelationalOperator: '<S244>/Relational Operator1'
     *  RelationalOperator: '<S244>/Relational Operator2'
     *  RelationalOperator: '<S244>/Relational Operator3'
     *  RelationalOperator: '<S244>/Relational Operator6'
     *  RelationalOperator: '<S244>/Relational Operator7'
     *  RelationalOperator: '<S246>/Compare'
     *  RelationalOperator: '<S247>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_k) <= 0.005F) && (fabsf(rtb_L0_C1) <= 0.005F)) &&
           ((fabsf(rtb_L0_C2_o) <= 0.0001F) && (fabsf(rtb_L0_C2) <= 0.0001F))) &&
          ((rtb_L0_Q == ((uint8)3U)) && (rtb_R0_Q == ((uint8)3U)))) &&
         (rtb_IMAPve_g_ESC_VehSpd >= 50.0F)) && (rtb_TLft <= 1.0F)) {
      if (!LKAS_DW.Subsystem_MODE) {
        /* InitializeConditions for Memory: '<S248>/Memory' */
        LKAS_DW.Memory_PreviousInput_c = ((uint16)0U);
        LKAS_DW.Subsystem_MODE = true;
      }

      /* Sum: '<S248>/Add1' incorporates:
       *  Memory: '<S248>/Memory'
       */
      rtb_Saturation_pw = (uint16)(1U + ((uint32)LKAS_DW.Memory_PreviousInput_c));

      /* Saturate: '<S248>/Saturation' */
      if (rtb_Saturation_pw >= ((uint16)3000U)) {
        rtb_Saturation_pw = ((uint16)3000U);
      }

      /* End of Saturate: '<S248>/Saturation' */

      /* RelationalOperator: '<S248>/Relational Operator' incorporates:
       *  Constant: '<S244>/Constant3'
       *  DataTypeConversion: '<S248>/Cast To Single1'
       *  Product: '<S244>/Divide'
       */
      LKAS_DW.RelationalOperator_iy = (rtb_Saturation_pw >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S248>/Memory' */
      LKAS_DW.Memory_PreviousInput_c = rtb_Saturation_pw;
    } else {
      if (LKAS_DW.Subsystem_MODE) {
        /* Disable for Outport: '<S248>/Out' */
        LKAS_DW.RelationalOperator_iy = false;
        LKAS_DW.Subsystem_MODE = false;
      }
    }

    /* End of Logic: '<S244>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S244>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S222>/Subsystem' incorporates:
     *  EnablePort: '<S243>/Enable'
     */
    if (LKAS_DW.RelationalOperator_iy) {
      /* Sum: '<S245>/Add2' incorporates:
       *  Constant: '<S245>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S245>/Memory3'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S245>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 50.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 50.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S245>/Saturation' */

      /* Switch: '<S245>/Switch' incorporates:
       *  Constant: '<S243>/Constant'
       *  Product: '<S245>/Divide'
       *  Product: '<S245>/Divide1'
       *  Sum: '<S245>/Add'
       *  Sum: '<S245>/Add1'
       *  UnitDelay: '<S245>/Unit Delay'
       */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 1.0F) {
        rtb_LL_ThresDet_tiTTLCThresLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_IMAPve_g_SW_Angle - LKAS_DW.UnitDelay_DSTATE)) +
          LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_tiTTLCThresLDW = rtb_IMAPve_g_SW_Angle;
      }

      /* End of Switch: '<S245>/Switch' */

      /* Saturate: '<S243>/Saturation' */
      if (rtb_LL_ThresDet_tiTTLCThresLDW > 3.0F) {
        LKAS_DW.Saturation_n = 3.0F;
      } else if (rtb_LL_ThresDet_tiTTLCThresLDW < (-3.0F)) {
        LKAS_DW.Saturation_n = (-3.0F);
      } else {
        LKAS_DW.Saturation_n = rtb_LL_ThresDet_tiTTLCThresLDW;
      }

      /* End of Saturate: '<S243>/Saturation' */

      /* Update for UnitDelay: '<S245>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_tiTTLCThresLDW;

      /* Update for Memory: '<S245>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_ThresDet_lDvtThresLwrLDW;
    }

    /* End of Outputs for SubSystem: '<S222>/Subsystem' */

    /* Saturate: '<S224>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 0.001F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.001F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S224>/Saturation' */

    /* Gain: '<S256>/kph To mps' incorporates:
     *  Gain: '<S257>/kph To mps'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = 0.277777791F * rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S256>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S258>:1' */
    /* '<S258>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 150.0F;
    } else if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 60.0F;
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Saturate: '<S256>/Saturation3' */

    /* Product: '<S256>/Divide1' incorporates:
     *  Constant: '<S256>/Constant'
     */
    rtb_L0_TLC_a = 0.09F / rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Saturate: '<S256>/Saturation1' */
    if (rtb_L0_TLC_a > 0.0117F) {
      rtb_L0_TLC_a = 0.0117F;
    } else {
      if (rtb_L0_TLC_a < 0.00237F) {
        rtb_L0_TLC_a = 0.00237F;
      }
    }

    /* End of Saturate: '<S256>/Saturation1' */

    /* Switch: '<S534>/Switch7' incorporates:
     *  Constant: '<S534>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_c != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_c;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S534>/Switch7' */

    /* MATLAB Function: '<S256>/MATLAB Function' incorporates:
     *  Gain: '<S256>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_L0_TLC_a *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_e) * LKAS_DW.LKA_WhlBaseL_C_f) /
      (rtb_LL_ThresDet_tiTTLCThresLDW * rtb_LL_ThresDet_tiTTLCThresLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S257>/Saturation3' */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 60.0F;
      }
    }

    /* End of Saturate: '<S257>/Saturation3' */

    /* Product: '<S257>/Divide1' incorporates:
     *  Constant: '<S257>/Constant'
     */
    rtb_LL_LDW_LatestWarnLine_C = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S257>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S259>:1' */
    /* '<S259>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_LDW_LatestWarnLine_C > 0.0117F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.0117F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 0.00237F) {
        rtb_LL_LDW_LatestWarnLine_C = 0.00237F;
      }
    }

    /* End of Saturate: '<S257>/Saturation1' */

    /* Switch: '<S534>/Switch4' incorporates:
     *  Constant: '<S534>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_j != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_j;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S534>/Switch4' */

    /* MATLAB Function: '<S257>/MATLAB Function' */
    LKAS_DW.SWARmax = ((((((((rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_e) * LKAS_DW.LKA_WhlBaseL_C_f) /
                        (rtb_LL_ThresDet_tiTTLCThresLDW *
                         rtb_LL_ThresDet_tiTTLCThresLDW)) * 180.0F) / 3.14F;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S74>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Sum: '<S217>/Add' incorporates:
     *  Sum: '<S176>/Add1'
     */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_L0_C1_k + rtb_L0_C1;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Gain: '<S217>/Gain' incorporates:
     *  Sum: '<S217>/Add'
     */
    rtb_phiHdAg = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * 0.5F;

    /* Gain: '<S219>/Gain1' incorporates:
     *  Sum: '<S219>/Add1'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = (rtb_Add_hf + rtb_Add_g5) * 0.5F;

    /* Switch: '<S221>/Switch' incorporates:
     *  Constant: '<S237>/Constant'
     *  RelationalOperator: '<S237>/Compare'
     */
    if (rtb_LFTTTLC <= 1.9F) {
      rtb_L0_TLC_a = rtb_LFTTTLC;
    } else {
      rtb_L0_TLC_a = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S221>/Switch' */

    /* Saturate: '<S221>/Saturation' */
    if (rtb_L0_TLC_a > 2.0F) {
      rtb_L0_TLC_a = 2.0F;
    } else {
      if (rtb_L0_TLC_a < 0.5F) {
        rtb_L0_TLC_a = 0.5F;
      }
    }

    /* End of Saturate: '<S221>/Saturation' */

    /* Product: '<S241>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_TLC_a;

    /* Sum: '<S240>/Add' incorporates:
     *  Gain: '<S240>/Gain1'
     *  Product: '<S240>/Product3'
     *  Product: '<S240>/Product4'
     *  Product: '<S240>/Z*Z'
     */
    rtb_Add_p = ((rtb_Add_hf_tmp * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C1_k) +
      ((3.0F * rtb_L0_C3_k) * (rtb_LL_LDW_LatestWarnLine_C *
        rtb_LL_LDW_LatestWarnLine_C));

    /* Switch: '<S221>/Switch1' incorporates:
     *  Constant: '<S238>/Constant'
     *  RelationalOperator: '<S238>/Compare'
     */
    if (rtb_RGTTTLC <= 1.9F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S221>/Switch1' */

    /* Saturate: '<S221>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S221>/Saturation1' */

    /* Product: '<S242>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * rtb_LL_HdAgPrvwT_C;

    /* Sum: '<S239>/Add' incorporates:
     *  Gain: '<S239>/Gain1'
     *  Product: '<S239>/Product3'
     *  Product: '<S239>/Product4'
     *  Product: '<S239>/Z*Z'
     */
    rtb_Add_mw = ((rtb_Add_g5_tmp * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C1) +
      ((3.0F * rtb_L0_C3) * (rtb_LL_LDW_LatestWarnLine_C *
        rtb_LL_LDW_LatestWarnLine_C));

    /* Switch: '<S534>/Switch8' incorporates:
     *  Constant: '<S534>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_j != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_j;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S534>/Switch8' */

    /* Product: '<S236>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Product: '<S234>/Z*Z' incorporates:
     *  Product: '<S235>/Z*Z'
     */
    rtb_LL_HdAgPrvwT_C = rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_LDW_LatestWarnLine_C;

    /* Sum: '<S234>/Add' incorporates:
     *  Product: '<S234>/Product'
     *  Product: '<S234>/Product3'
     *  Product: '<S234>/Product4'
     *  Product: '<S234>/Z*Z'
     *  Product: '<S234>/Z*Z*Z'
     */
    rtb_Add_ns = (((rtb_L0_C1_k * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C0_o) +
                  (rtb_L0_C2_o * rtb_LL_HdAgPrvwT_C)) +
      ((rtb_LL_LDW_LatestWarnLine_C * rtb_LL_HdAgPrvwT_C) * rtb_L0_C3_k);

    /* Sum: '<S235>/Add' incorporates:
     *  Product: '<S235>/Product'
     *  Product: '<S235>/Product3'
     *  Product: '<S235>/Product4'
     *  Product: '<S235>/Z*Z*Z'
     */
    rtb_Add_f = (((rtb_L0_C1 * rtb_LL_LDW_LatestWarnLine_C) + rtb_Saturation_mn)
                 + (rtb_L0_C2 * rtb_LL_HdAgPrvwT_C)) +
      ((rtb_LL_LDW_LatestWarnLine_C * rtb_LL_HdAgPrvwT_C) * rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S74>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S102>/Memory' */
        LKAS_DW.Memory_PreviousInput_i = 0.0F;

        /* InitializeConditions for Memory: '<S139>/Memory' */
        LKAS_DW.Memory_PreviousInput_e3 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S85>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_am = ((uint8)0U);

        /* InitializeConditions for Memory: '<S138>/Memory' */
        LKAS_DW.Memory_PreviousInput_id = ((uint16)0U);

        /* InitializeConditions for Memory: '<S140>/Memory' */
        LKAS_DW.Memory_PreviousInput_bp = ((uint16)0U);

        /* InitializeConditions for Memory: '<S134>/Memory' */
        LKAS_DW.Memory_PreviousInput_gv = ((uint16)0U);

        /* InitializeConditions for Memory: '<S137>/Memory' */
        LKAS_DW.Memory_PreviousInput_mn = ((uint16)0U);

        /* InitializeConditions for Memory: '<S136>/Memory' */
        LKAS_DW.Memory_PreviousInput_ei = ((uint16)0U);

        /* InitializeConditions for Memory: '<S135>/Memory' */
        LKAS_DW.Memory_PreviousInput_as = ((uint16)0U);

        /* InitializeConditions for Memory: '<S112>/Memory' */
        LKAS_DW.Memory_PreviousInput_hx = 0.0F;

        /* InitializeConditions for Memory: '<S103>/Memory' */
        LKAS_DW.Memory_PreviousInput_ge = 0.0F;

        /* InitializeConditions for Memory: '<S104>/Memory' */
        LKAS_DW.Memory_PreviousInput_aj = 0.0F;

        /* InitializeConditions for Memory: '<S101>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_b = 0.0F;

        /* InitializeConditions for Memory: '<S192>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_p = 0.0F;

        /* InitializeConditions for Memory: '<S178>/Memory' */
        LKAS_DW.Memory_PreviousInput_en = 0.0F;

        /* InitializeConditions for UnitDelay: '<S176>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

        /* InitializeConditions for Memory: '<S183>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_l = 0.0F;

        /* InitializeConditions for Memory: '<S187>/Memory' */
        LKAS_DW.Memory_PreviousInput_o = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S191>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_j = 0.0F;

        /* InitializeConditions for Memory: '<S191>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_d = 0.0F;

        /* InitializeConditions for UnitDelay: '<S171>/Delay Input2'
         *
         * Block description for '<S171>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE = 0.0F;

        /* InitializeConditions for Memory: '<S171>/Memory' */
        LKAS_DW.Memory_PreviousInput_c0 = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S92>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S92>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S104>/Moving Standard Deviation1' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S104>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S104>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2_d);

        /* End of SystemReset for SubSystem: '<S104>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Sum: '<S102>/Add2' incorporates:
       *  Memory: '<S102>/Memory'
       */
      rtb_L0_TLC_a = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_i;

      /* Saturate: '<S102>/Saturation2' */
      if (rtb_L0_TLC_a > 20.0F) {
        rtb_Saturation2 = 20.0F;
      } else if (rtb_L0_TLC_a < 0.0F) {
        rtb_Saturation2 = 0.0F;
      } else {
        rtb_Saturation2 = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S102>/Saturation2' */

      /* Saturate: '<S102>/Saturation' */
      if (rtb_TTLC > 0.004F) {
        rtb_L0_TLC_a = 0.004F;
      } else if (rtb_TTLC < 0.0F) {
        rtb_L0_TLC_a = 0.0F;
      } else {
        rtb_L0_TLC_a = rtb_TTLC;
      }

      /* End of Saturate: '<S102>/Saturation' */

      /* RelationalOperator: '<S102>/Relational Operator4' incorporates:
       *  Constant: '<S102>/Constant'
       *  Constant: '<S102>/Constant1'
       *  Product: '<S102>/Divide'
       *  Sum: '<S102>/Add'
       */
      rtb_LogicalOperator3_a = (rtb_Saturation2 >=
        ((((rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F) * rtb_L0_TLC_a) / 0.004F) +
         rtb_LL_LKAExPrcs_tiExitTime1));

      /* Sum: '<S139>/Add' incorporates:
       *  Constant: '<S139>/Constant'
       *  Memory: '<S139>/Memory'
       */
      rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_e3));

      /* Saturate: '<S139>/Saturation1' */
      if (rtb_Saturation_pw < ((uint16)10000U)) {
        rtb_Saturation1_p = rtb_Saturation_pw;
      } else {
        rtb_Saturation1_p = ((uint16)10000U);
      }

      /* End of Saturate: '<S139>/Saturation1' */

      /* If: '<S139>/If' incorporates:
       *  Constant: '<S139>/Constant2'
       */
      if (rtb_Saturation1_p == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S139>/if action ' incorporates:
         *  ActionPort: '<S156>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_SW_Angle, &LKAS_DW.In_as);

        /* End of Outputs for SubSystem: '<S139>/if action ' */
      }

      /* End of If: '<S139>/If' */

      /* Sum: '<S85>/Add' incorporates:
       *  Constant: '<S85>/Constant'
       *  Memory: '<S85>/Memory1'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_am));

      /* Saturate: '<S85>/Saturation1' */
      if (rtb_IMAPve_d_BCM_HazardLamp < ((uint8)5U)) {
        rtb_Saturation1_m = rtb_IMAPve_d_BCM_HazardLamp;
      } else {
        rtb_Saturation1_m = ((uint8)5U);
      }

      /* End of Saturate: '<S85>/Saturation1' */

      /* Saturate: '<S111>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S111>/Saturation3' */

      /* Product: '<S111>/Divide1' incorporates:
       *  Constant: '<S111>/Constant'
       */
      rtb_L0_TLC_a = 0.09F / x10;

      /* Saturate: '<S111>/Saturation1' */
      if (rtb_L0_TLC_a > 0.0117F) {
        LKAS_DW.StbFacm_SY = 0.0117F;
      } else if (rtb_L0_TLC_a < 0.00237F) {
        LKAS_DW.StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.StbFacm_SY = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S111>/Saturation1' */

      /* Sum: '<S138>/Add' incorporates:
       *  Constant: '<S138>/Constant'
       *  Memory: '<S138>/Memory'
       */
      rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_id));

      /* Saturate: '<S138>/Saturation1' */
      if (rtb_Saturation_pw < ((uint16)10000U)) {
        rtb_Saturation1_c = rtb_Saturation_pw;
      } else {
        rtb_Saturation1_c = ((uint16)10000U);
      }

      /* End of Saturate: '<S138>/Saturation1' */

      /* If: '<S131>/If' incorporates:
       *  DataTypeConversion: '<S74>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S143>/Action Port'
         */
        LKAS_ifaction3(rtb_LFTTTLC, &rtb_Merge_j);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S142>/Action Port'
         */
        LKAS_ifaction3(rtb_RGTTTLC, &rtb_Merge_j);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S144>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_j);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem3' */
      }

      /* End of If: '<S131>/If' */

      /* If: '<S138>/If' incorporates:
       *  Constant: '<S138>/Constant2'
       */
      if (rtb_Saturation1_c == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S138>/if action ' incorporates:
         *  ActionPort: '<S155>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_j, &LKAS_DW.In_d);

        /* End of Outputs for SubSystem: '<S138>/if action ' */
      }

      /* End of If: '<S138>/If' */

      /* Saturate: '<S111>/Saturation2' */
      if (LKAS_DW.In_d > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_d < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_d;
      }

      /* End of Saturate: '<S111>/Saturation2' */

      /* Sum: '<S140>/Add' incorporates:
       *  Constant: '<S140>/Constant'
       *  Memory: '<S140>/Memory'
       */
      rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_bp));

      /* Saturate: '<S140>/Saturation1' */
      if (rtb_Saturation_pw < ((uint16)10000U)) {
        rtb_Saturation1_g = rtb_Saturation_pw;
      } else {
        rtb_Saturation1_g = ((uint16)10000U);
      }

      /* End of Saturate: '<S140>/Saturation1' */

      /* If: '<S140>/If' incorporates:
       *  Constant: '<S140>/Constant2'
       */
      if (rtb_Saturation1_g == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S140>/if action ' incorporates:
         *  ActionPort: '<S157>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_ESC_VehSpd, &LKAS_DW.In_m);

        /* End of Outputs for SubSystem: '<S140>/if action ' */
      }

      /* End of If: '<S140>/If' */

      /* Sum: '<S134>/Add' incorporates:
       *  Constant: '<S134>/Constant'
       *  Memory: '<S134>/Memory'
       */
      rtb_Add_iy = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_gv));

      /* DataTypeConversion: '<S166>/Data Type Conversion' incorporates:
       *  Constant: '<S167>/Constant'
       *  RelationalOperator: '<S167>/Compare'
       */
      rtb_EPS_LKA_Control = (UInt8)((rtb_Merge_i <= 0.0F) ? 1 : 0);

      /* Switch: '<S534>/Switch5' incorporates:
       *  Constant: '<S534>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_n != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_n;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S534>/Switch5' */

      /* Product: '<S166>/Divide' */
      rtb_Saturation4 = (rtb_Merge_i * rtb_LKA_Veh2CamL_C_tmp) * x10;

      /* Abs: '<S166>/Abs1' incorporates:
       *  Abs: '<S166>/Abs'
       */
      rtb_L0_C3 = fabsf(rtb_Saturation4);
      rtb_Abs1_d = rtb_L0_C3;

      /* Abs: '<S166>/Abs' */
      rtb_Abs_f = rtb_L0_C3;

      /* If: '<S166>/If' incorporates:
       *  DataTypeConversion: '<S74>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) && (((sint32)
            rtb_EPS_LKA_Control) == 0)) {
        /* Outputs for IfAction SubSystem: '<S166>/If Action Subsystem' incorporates:
         *  ActionPort: '<S168>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_f, &rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S166>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) && (((sint32)
                   rtb_EPS_LKA_Control) == 1)) {
        /* Outputs for IfAction SubSystem: '<S166>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S170>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_d, &rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S166>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S166>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S169>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S166>/If Action Subsystem2' */
      }

      /* End of If: '<S166>/If' */

      /* Switch: '<S534>/Switch6' incorporates:
       *  Constant: '<S534>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_n != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_n;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S534>/Switch6' */

      /* Sum: '<S162>/Add' incorporates:
       *  Sum: '<S103>/Add3'
       *  Sum: '<S104>/Add'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Sum: '<S162>/Add1' incorporates:
       *  Product: '<S162>/Divide'
       *  Product: '<S162>/Divide1'
       *  Sum: '<S162>/Add'
       */
      rtb_Add1_h = (((1.0F / x10) * rtb_LL_LKAExPrcs_tiExitTime1) /
                    rtb_LKA_Veh2CamL_C_tmp) + rtb_Saturation4;

      /* If: '<S114>/If' incorporates:
       *  Constant: '<S165>/Constant2'
       *  DataTypeConversion: '<S74>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S114>/If Action Subsystem' incorporates:
         *  ActionPort: '<S163>/Action Port'
         */
        /* Gain: '<S163>/Gain2' */
        rtb_Merge_m = (-1.0F) * rtb_Add1_h;

        /* End of Outputs for SubSystem: '<S114>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S114>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S164>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_h, &rtb_Merge_m);

        /* End of Outputs for SubSystem: '<S114>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S114>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S165>/Action Port'
         */
        rtb_Merge_m = 0.0F;

        /* End of Outputs for SubSystem: '<S114>/If Action Subsystem2' */
      }

      /* End of If: '<S114>/If' */

      /* Saturate: '<S134>/Saturation1' */
      if (rtb_Add_iy < ((uint16)10000U)) {
        rtb_Saturation_pw = rtb_Add_iy;
      } else {
        rtb_Saturation_pw = ((uint16)10000U);
      }

      /* End of Saturate: '<S134>/Saturation1' */

      /* If: '<S134>/If' incorporates:
       *  Constant: '<S134>/Constant2'
       */
      if (rtb_Saturation_pw == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S134>/if action ' incorporates:
         *  ActionPort: '<S151>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_m, &LKAS_DW.In_p);

        /* End of Outputs for SubSystem: '<S134>/if action ' */
      }

      /* End of If: '<S134>/If' */

      /* Sum: '<S137>/Add' incorporates:
       *  Constant: '<S137>/Constant'
       *  Memory: '<S137>/Memory'
       */
      rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_mn));

      /* Saturate: '<S137>/Saturation1' */
      if (rtb_Saturation_pw < ((uint16)10000U)) {
        rtb_Saturation1_f = rtb_Saturation_pw;
      } else {
        rtb_Saturation1_f = ((uint16)10000U);
      }

      /* End of Saturate: '<S137>/Saturation1' */

      /* If: '<S137>/If' incorporates:
       *  Constant: '<S137>/Constant2'
       */
      if (rtb_Saturation1_f == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S137>/if action ' incorporates:
         *  ActionPort: '<S154>/Action Port'
         */
        LKAS_ifaction(rtb_phiHdAg, &LKAS_DW.In_o5);

        /* End of Outputs for SubSystem: '<S137>/if action ' */
      }

      /* End of If: '<S137>/If' */

      /* Sum: '<S136>/Add' incorporates:
       *  Constant: '<S136>/Constant'
       *  Memory: '<S136>/Memory'
       */
      rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ei));

      /* Saturate: '<S136>/Saturation1' */
      if (rtb_Saturation_pw < ((uint16)10000U)) {
        rtb_Saturation1_p2 = rtb_Saturation_pw;
      } else {
        rtb_Saturation1_p2 = ((uint16)10000U);
      }

      /* End of Saturate: '<S136>/Saturation1' */

      /* If: '<S133>/If' incorporates:
       *  DataTypeConversion: '<S74>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S149>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_ns, &rtb_Merge_me);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_f, &rtb_Merge_me);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S150>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_me);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem3' */
      }

      /* End of If: '<S133>/If' */

      /* If: '<S136>/If' incorporates:
       *  Constant: '<S136>/Constant2'
       */
      if (rtb_Saturation1_p2 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S136>/if action ' incorporates:
         *  ActionPort: '<S153>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_me, &LKAS_DW.In_g);

        /* End of Outputs for SubSystem: '<S136>/if action ' */
      }

      /* End of If: '<S136>/If' */

      /* Sum: '<S135>/Add' incorporates:
       *  Constant: '<S135>/Constant'
       *  Memory: '<S135>/Memory'
       */
      rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_as));

      /* Saturate: '<S135>/Saturation1' */
      if (rtb_Saturation_pw < ((uint16)10000U)) {
        rtb_Saturation1_fd = rtb_Saturation_pw;
      } else {
        rtb_Saturation1_fd = ((uint16)10000U);
      }

      /* End of Saturate: '<S135>/Saturation1' */

      /* If: '<S132>/If' incorporates:
       *  DataTypeConversion: '<S74>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S132>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_p, &rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S132>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S132>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S145>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_mw, &rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S132>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S132>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S132>/If Action Subsystem3' */
      }

      /* End of If: '<S132>/If' */

      /* If: '<S135>/If' incorporates:
       *  Constant: '<S135>/Constant2'
       */
      if (rtb_Saturation1_fd == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S135>/if action ' incorporates:
         *  ActionPort: '<S152>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_n, &LKAS_DW.In_j);

        /* End of Outputs for SubSystem: '<S135>/if action ' */
      }

      /* End of If: '<S135>/If' */

      /* If: '<S141>/If' incorporates:
       *  DataTypeConversion: '<S74>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S141>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S159>/Action Port'
         */
        /* SignalConversion: '<S159>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S159>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S141>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S141>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S158>/Action Port'
         */
        /* SignalConversion: '<S158>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S158>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S141>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S141>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S160>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S141>/If Action Subsystem3' */
      }

      /* End of If: '<S141>/If' */

      /* If: '<S85>/If' incorporates:
       *  Constant: '<S85>/Constant19'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem;
      rtAction = -1;
      if (rtb_Saturation1_m == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        if (0 != rtPrevAction) {
          /* SystemReset for IfAction SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
           *  ActionPort: '<S110>/Action Port'
           *
           * Block description for '<S85>/LKA Motion Planning Calculation (LKAMPCal)':
           *  Block Name: LKA Motion Planning Calculation
           *  Ab.: LKAMPCal
           *  No.: 1.2.3.2
           *  Rev: 0.0.1
           *  Update Date: 19-3-26
           */
          /* SystemReset for If: '<S85>/If' */
          LKAMotionPlanningCalculat_Reset();

          /* End of SystemReset for SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */
        }

        /* Outputs for IfAction SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S110>/Action Port'
         *
         * Block description for '<S85>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S85>/If' */

      /* Memory: '<S112>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_hx;

      /* Sum: '<S112>/Add' incorporates:
       *  Gain: '<S112>/Gain1'
       *  Product: '<S112>/Divide'
       *  Product: '<S112>/Product'
       */
      rtb_Add_fh = ((rtb_LKA_Veh2CamL_C_tmp * rtb_LKA_SampleTime) /
                    (0.277777791F * LKAS_DW.In_m)) + rtb_Saturation4;

      /* MATLAB Function: '<S113>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S161>:1' */
      /* '<S161>:1:20' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S161>:1:21' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S161>:1:22' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S161>:1:23' Delte2PhSWGrad = SWACmd_dphi2PhSWAGrad; */
      /* '<S161>:1:24' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S161>:1:25' NomT = SWACmd_tiNomT; */
      /* '<S161>:1:26' T1 = (DelteSW1-DelteSW0)/Delte1PhSWGrad; */
      rtb_L0_C3 = (LKAS_DW.K1K2Det_phi2PhSWAIni - LKAS_DW.In_as) /
        LKAS_DW.K1K2Det_dphi1PhSWAGrad;

      /* '<S161>:1:27' T2 = (0-DelteSW1)/Delte2PhSWGrad+T1; */
      rtb_L0_C3_k = ((0.0F - LKAS_DW.K1K2Det_phi2PhSWAIni) /
                     LKAS_DW.K1K2Det_dphi2PhSWAGrad1) + rtb_L0_C3;

      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S161>:1:35' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_fh < rtb_L0_C3) && (rtb_Add_fh >= 0.0F)) {
        /* '<S161>:1:36' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_fh) +
          LKAS_DW.In_as;
      } else if ((rtb_Add_fh <= rtb_L0_C3_k) && (rtb_Add_fh >= rtb_L0_C3)) {
        /* '<S161>:1:37' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S161>:1:39' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_L0_C3) +
          LKAS_DW.In_as;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_fh >= rtb_L0_C3_k) {
          /* '<S161>:1:41' elseif(NomT >= T2) */
          /* '<S161>:1:42' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_L0_C3) +
            LKAS_DW.In_as;

          /*    DelteSWCmd = single(0); */
        }
      }

      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S161>:1:48' SWACmd_phiSWACmd = DelteSWCmd; */
      rtb_T2 = rtb_L0_C3_k;

      /* Saturate: '<S85>/Saturation6' incorporates:
       *  MATLAB Function: '<S113>/SWACmd'
       */
      if (rtb_L0_C3 > 2.0F) {
        rtb_Saturation6_g = 2.0F;
      } else if (rtb_L0_C3 < 0.2F) {
        rtb_Saturation6_g = 0.2F;
      } else {
        rtb_Saturation6_g = rtb_L0_C3;
      }

      /* End of Saturate: '<S85>/Saturation6' */

      /* Memory: '<S103>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_ge;

      /* Sum: '<S103>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S103>/Saturation2' */
      if (rtb_Saturation4 > 12.0F) {
        rtb_Saturation2_f = 12.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation2_f = 0.0F;
      } else {
        rtb_Saturation2_f = rtb_Saturation4;
      }

      /* End of Saturate: '<S103>/Saturation2' */

      /* Abs: '<S103>/Abs2' */
      rtb_Saturation4 = fabsf(rtb_Gain1);

      /* Gain: '<S103>/Gain' */
      rtb_L0_C3 = rtb_LL_LKAExPrcs_tiExitTime1 * 0.166666672F;

      /* RelationalOperator: '<S103>/Relational Operator2' */
      rtb_Compare_d3 = (rtb_Saturation4 >= rtb_L0_C3);

      /* Abs: '<S103>/Abs3' */
      rtb_Saturation4 = fabsf(rtb_Add5_k);

      /* Outputs for Enabled SubSystem: '<S103>/Sum Condition1' incorporates:
       *  EnablePort: '<S105>/Enable'
       */
      /* Logic: '<S103>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S103>/Relational Operator3'
       *  RelationalOperator: '<S103>/Relational Operator4'
       */
      if (((rtb_Saturation2_f >= rtb_Saturation6_g) && rtb_Compare_d3) &&
          (rtb_Saturation4 >= rtb_L0_C3)) {
        if (!LKAS_DW.SumCondition1_MODE_o) {
          /* InitializeConditions for Memory: '<S105>/Memory' */
          LKAS_DW.Memory_PreviousInput_es = 0.0F;
          LKAS_DW.SumCondition1_MODE_o = true;
        }

        /* Sum: '<S105>/Add1' incorporates:
         *  Memory: '<S105>/Memory'
         */
        rtb_L0_C3 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_es;

        /* Saturate: '<S105>/Saturation' */
        if (rtb_L0_C3 > 10.0F) {
          rtb_L0_C3 = 10.0F;
        } else {
          if (rtb_L0_C3 < 0.0F) {
            rtb_L0_C3 = 0.0F;
          }
        }

        /* End of Saturate: '<S105>/Saturation' */

        /* Saturate: '<S103>/Saturation' */
        if (rtb_TTLC > 0.004F) {
          rtb_L0_TLC_a = 0.004F;
        } else if (rtb_TTLC < 0.0F) {
          rtb_L0_TLC_a = 0.0F;
        } else {
          rtb_L0_TLC_a = rtb_TTLC;
        }

        /* End of Saturate: '<S103>/Saturation' */

        /* RelationalOperator: '<S105>/Relational Operator' incorporates:
         *  Constant: '<S103>/Constant'
         *  Constant: '<S103>/Constant1'
         *  Product: '<S103>/Divide'
         *  Sum: '<S103>/Add1'
         */
        LKAS_DW.RelationalOperator_p5 = (rtb_L0_C3 >=
          ((((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) * rtb_L0_TLC_a) / 0.004F) +
           rtb_LL_LKAExPrcs_tiExitTime2));

        /* Update for Memory: '<S105>/Memory' */
        LKAS_DW.Memory_PreviousInput_es = rtb_L0_C3;
      } else {
        if (LKAS_DW.SumCondition1_MODE_o) {
          /* Disable for Outport: '<S105>/Out' */
          LKAS_DW.RelationalOperator_p5 = false;
          LKAS_DW.SumCondition1_MODE_o = false;
        }
      }

      /* End of Logic: '<S103>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S103>/Sum Condition1' */

      /* Memory: '<S104>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_aj;

      /* Sum: '<S104>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S104>/Saturation2' */
      if (rtb_Saturation4 > 10.0F) {
        rtb_Saturation2_k = 10.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation2_k = 0.0F;
      } else {
        rtb_Saturation2_k = rtb_Saturation4;
      }

      /* End of Saturate: '<S104>/Saturation2' */

      /* Gain: '<S104>/Gain' */
      rtb_Saturation4 = rtb_LL_LKAExPrcs_tiExitTime1 * 0.333333343F;

      /* RelationalOperator: '<S104>/Relational Operator2' */
      rtb_Compare_d3 = (rtb_Gain1 >= rtb_Saturation4);

      /* RelationalOperator: '<S104>/Relational Operator3' */
      rtb_Compare_dmy = (rtb_Gain1 >= rtb_Saturation4);

      /* Abs: '<S104>/Abs4' */
      rtb_Saturation4 = rtb_TTLC;

      /* Saturate: '<S104>/Saturation' */
      if (rtb_Saturation4 > 0.004F) {
        rtb_Saturation4 = 0.004F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S104>/Saturation' */

      /* Switch: '<S534>/Switch45' incorporates:
       *  Constant: '<S534>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S534>/Switch45' */

      /* Sum: '<S104>/Add6' incorporates:
       *  Constant: '<S104>/Constant'
       *  Constant: '<S104>/Constant7'
       *  Product: '<S104>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Saturation4) / 0.004F) + x10;

      /* Outputs for Enabled SubSystem: '<S83>/Subsystem' incorporates:
       *  EnablePort: '<S91>/Enable'
       */
      /* RelationalOperator: '<S90>/Compare' incorporates:
       *  Constant: '<S90>/Constant'
       */
      if (rtb_LL_LKASWASyn_TrqSwaAddSwt > 0.0F) {
        if (!LKAS_DW.Subsystem_MODE_m) {
          LKAS_DW.Subsystem_MODE_m = true;
        }

        /* MATLAB Function: '<S91>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S93>:1' */
        /* '<S93>:1:2' Swaadd=single(0); */
        /* '<S93>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S93>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S93>:1:5' l0c0=abs(l0c0); */
        /* '<S93>:1:6' r0c0=abs(r0c0); */
        /* '<S93>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_L0_C3_k = fmaxf(fminf(rtb_LftTTLC + rtb_TTLC_n, 5.4F), 2.5F);

        /* '<S93>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_L0_C3_k > 2.5F) && (rtb_L0_C3_k < 5.4F)) {
          /* '<S93>:1:9' leftlane=l0c0/lanewidth; */
          rtb_LL_LKAExPrcs_tiExitTime2 = rtb_LftTTLC / rtb_L0_C3_k;

          /* '<S93>:1:10' rightlane=r0c0/lanewidth; */
          rtb_L0_C3 = rtb_TTLC_n / rtb_L0_C3_k;
        } else {
          /* '<S93>:1:11' else */
          /* '<S93>:1:12' leftlane=single(0.5); */
          rtb_LL_LKAExPrcs_tiExitTime2 = 0.5F;

          /* '<S93>:1:13' rightlane=single(0.5); */
          rtb_L0_C3 = 0.5F;
        }

        /* '<S93>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S93>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S93>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S534>/Switch42' incorporates:
           *  Constant: '<S534>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S93>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S534>/Switch43' incorporates:
           *  Constant: '<S534>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_L0_C3 = (((((180.0F - fmaxf(fminf(rtb_IMAPve_g_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_LL_LKAExPrcs_tiExitTime2) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S534>/Switch42' incorporates:
           *  Constant: '<S534>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S93>:1:19' else */
          /* '<S93>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S534>/Switch43' incorporates:
           *  Constant: '<S534>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_L0_C3 = (((((180.0F - fmaxf(fminf(rtb_IMAPve_g_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_L0_C3) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S94>/Add2' incorporates:
         *  Constant: '<S94>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S94>/Memory3'
         */
        rtb_L0_C3_k = 1.0F + LKAS_DW.Memory3_PreviousInput_h;

        /* Saturate: '<S94>/Saturation' */
        if (rtb_L0_C3_k > 50.0F) {
          rtb_L0_C3_k = 50.0F;
        } else {
          if (rtb_L0_C3_k < 0.0F) {
            rtb_L0_C3_k = 0.0F;
          }
        }

        /* End of Saturate: '<S94>/Saturation' */

        /* Switch: '<S94>/Switch' incorporates:
         *  Product: '<S94>/Divide'
         *  Product: '<S94>/Divide1'
         *  Sum: '<S94>/Add'
         *  Sum: '<S94>/Add1'
         *  UnitDelay: '<S94>/Unit Delay'
         */
        if (rtb_L0_C3_k > 1.0F) {
          /* Switch: '<S534>/Switch50' incorporates:
           *  Constant: '<S534>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S534>/Switch50' */
          rtb_L0_C3 = ((rtb_LKA_SampleTime / x10) * (rtb_L0_C3 -
            LKAS_DW.UnitDelay_DSTATE_d)) + LKAS_DW.UnitDelay_DSTATE_d;
        }

        /* End of Switch: '<S94>/Switch' */

        /* SampleTimeMath: '<S97>/TSamp'
         *
         * About '<S97>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_L0_C3 * 100.0F;

        /* Sum: '<S95>/Add2' incorporates:
         *  Constant: '<S95>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S95>/Memory3'
         */
        rtb_LL_HdAgPrvwT_C = 1.0F + LKAS_DW.Memory3_PreviousInput_i;

        /* Saturate: '<S95>/Saturation' */
        if (rtb_LL_HdAgPrvwT_C > 50.0F) {
          rtb_LL_HdAgPrvwT_C = 50.0F;
        } else {
          if (rtb_LL_HdAgPrvwT_C < 0.0F) {
            rtb_LL_HdAgPrvwT_C = 0.0F;
          }
        }

        /* End of Saturate: '<S95>/Saturation' */

        /* Switch: '<S95>/Switch' incorporates:
         *  Product: '<S95>/Divide'
         *  Product: '<S95>/Divide1'
         *  Sum: '<S95>/Add'
         *  Sum: '<S95>/Add1'
         *  Sum: '<S97>/Diff'
         *  UnitDelay: '<S95>/Unit Delay'
         *  UnitDelay: '<S97>/UD'
         *
         * Block description for '<S97>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S97>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_HdAgPrvwT_C > 2.0F) {
          /* Switch: '<S534>/Switch52' incorporates:
           *  Constant: '<S534>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S534>/Switch52' */
          rtb_LL_LKAExPrcs_tiExitTime1 = (((rtb_LL_LKAExPrcs_tiExitTime2 -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_l) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_l;
        } else {
          rtb_LL_LKAExPrcs_tiExitTime1 = rtb_LL_LKAExPrcs_tiExitTime2 -
            LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S95>/Switch' */

        /* Saturate: '<S91>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime1 > 30.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 30.0F;
        } else if (rtb_LL_LKAExPrcs_tiExitTime1 < (-30.0F)) {
          rtb_LL_LDW_LatestWarnLine_C = (-30.0F);
        } else {
          rtb_LL_LDW_LatestWarnLine_C = rtb_LL_LKAExPrcs_tiExitTime1;
        }

        /* End of Saturate: '<S91>/Saturation' */

        /* Switch: '<S534>/Switch53' incorporates:
         *  Constant: '<S534>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S534>/Switch53' */

        /* Sum: '<S96>/Difference Inputs1' incorporates:
         *  Product: '<S91>/Divide1'
         *  Product: '<S91>/Divide3'
         *  Sum: '<S91>/Add'
         *  UnitDelay: '<S96>/Delay Input2'
         *
         * Block description for '<S96>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S96>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_LKASWASyn_TrqSwaAddSwt = (((rtb_LL_LKASWASyn_TrqSwaAddSwt *
          rtb_LL_LDW_LatestWarnLine_C) * x10) + (rtb_LL_LKASWASyn_TrqSwaAddSwt *
          rtb_L0_C3)) - LKAS_DW.DelayInput2_DSTATE_c;

        /* Product: '<S96>/delta rise limit' incorporates:
         *  Constant: '<S91>/Constant1'
         *  SampleTimeMath: '<S96>/sample time'
         *
         * About '<S96>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = 5.0F * 0.01F;

        /* Product: '<S96>/delta fall limit' incorporates:
         *  Constant: '<S91>/Constant2'
         *  SampleTimeMath: '<S96>/sample time'
         *
         * About '<S96>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_LDW_LatestWarnLine_C = (-5.0F) * 0.01F;

        /* Switch: '<S98>/Switch2' incorporates:
         *  RelationalOperator: '<S98>/LowerRelop1'
         *  RelationalOperator: '<S98>/UpperRelop'
         *  Switch: '<S98>/Switch'
         */
        if (rtb_LL_LKASWASyn_TrqSwaAddSwt > rtb_LL_DvtSpdDet_vDvtSpdMin_C) {
          rtb_LL_LKASWASyn_TrqSwaAddSwt = rtb_LL_DvtSpdDet_vDvtSpdMin_C;
        } else {
          if (rtb_LL_LKASWASyn_TrqSwaAddSwt < rtb_LL_LDW_LatestWarnLine_C) {
            /* Switch: '<S98>/Switch' */
            rtb_LL_LKASWASyn_TrqSwaAddSwt = rtb_LL_LDW_LatestWarnLine_C;
          }
        }

        /* End of Switch: '<S98>/Switch2' */

        /* Sum: '<S96>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S96>/Delay Input2'
         *
         * Block description for '<S96>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S96>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_b = rtb_LL_LKASWASyn_TrqSwaAddSwt +
          LKAS_DW.DelayInput2_DSTATE_c;

        /* Update for UnitDelay: '<S94>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_d = rtb_L0_C3;

        /* Update for Memory: '<S94>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_h = rtb_L0_C3_k;

        /* Update for UnitDelay: '<S97>/UD'
         *
         * Block description for '<S97>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for UnitDelay: '<S95>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_l = rtb_LL_LKAExPrcs_tiExitTime1;

        /* Update for Memory: '<S95>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_i = rtb_LL_HdAgPrvwT_C;

        /* Update for UnitDelay: '<S96>/Delay Input2'
         *
         * Block description for '<S96>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_c = LKAS_DW.DifferenceInputs2_b;
      } else {
        if (LKAS_DW.Subsystem_MODE_m) {
          /* Disable for Outport: '<S91>/Out1' */
          LKAS_DW.DifferenceInputs2_b = 0.0F;
          LKAS_DW.Subsystem_MODE_m = false;
        }
      }

      /* End of RelationalOperator: '<S90>/Compare' */
      /* End of Outputs for SubSystem: '<S83>/Subsystem' */

      /* Outputs for Atomic SubSystem: '<S92>/Moving Standard Deviation2' */
      rtb_deltafalllimit_j = (float32) LKAS_MovingStandardDeviation2
        (rtb_IMAPve_g_EPS_SW_Trq, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S92>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S104>/Moving Standard Deviation1' */
      rtb_Yk1_f = (float32) LKAS_MovingStandardDeviation2(rtb_Add5_k,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S104>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S104>/Relational Operator6' */
      rtb_RelationalOperator6_p = (rtb_Yk1_f <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S104>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_p, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_g, &LKAS_DW.SumCondition1_c);

      /* End of Outputs for SubSystem: '<S104>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S104>/Moving Standard Deviation2' */
      rtb_Yk1_f = (float32) LKAS_MovingStandardDeviation2(rtb_Gain1,
        &LKAS_DW.MovingStandardDeviation2_d);

      /* End of Outputs for SubSystem: '<S104>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S104>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Yk1_f <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S104>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_da, &LKAS_DW.SumCondition_e);

      /* End of Outputs for SubSystem: '<S104>/Sum Condition' */

      /* Switch: '<S534>/Switch46' incorporates:
       *  Constant: '<S534>/LL_LKAExPrcs_ExitC0Swt=1'
       */
      if (LKAS_ConstB.DataTypeConversion35) {
        i = LKAS_ConstB.DataTypeConversion35 ? 1 : 0;
      } else {
        i = LL_LKAExPrcs_ExitC0Swt ? 1 : 0;
      }

      /* End of Switch: '<S534>/Switch46' */

      /* Logic: '<S104>/Logical Operator2' incorporates:
       *  Logic: '<S104>/Logical Operator1'
       *  RelationalOperator: '<S104>/Relational Operator4'
       */
      rtb_Compare_d3 = ((((((rtb_Saturation2_k >= rtb_Saturation6_g) &&
                            rtb_Compare_d3) && rtb_Compare_dmy) &&
                          (LKAS_DW.RelationalOperator_g)) &&
                         (LKAS_DW.RelationalOperator_da)) && (i != 0));

      /* Fcn: '<S84>/Fcn' incorporates:
       *  DataTypeConversion: '<S84>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((rtb_Compare_d3 ? 1 : 0) *
        (rtb_Compare_d3 ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!rtb_Compare_d3) ? 1 : 0)) * (LKAS_DW.RelationalOperator_p5 ? 1 : 0)) *
        ((sint32)2.0F))) + (((sint32)(((!LKAS_DW.RelationalOperator_p5) &&
        (!rtb_Compare_d3)) ? 1 : 0)) * (rtb_LogicalOperator3_a ? 1 : 0))));

      /* Logic: '<S84>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_LogicalOperator3_a ||
        (LKAS_DW.RelationalOperator_p5)) || rtb_Compare_d3);

      /* DataTypeConversion: '<S87>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Switch: '<S534>/Switch18' incorporates:
       *  Constant: '<S534>/LL_LKASWASyn_M3K=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion25;
      } else {
        x10 = LL_LKASWASyn_M3K;
      }

      /* End of Switch: '<S534>/Switch18' */

      /* Product: '<S92>/Divide' */
      rtb_Saturation4 = rtb_deltafalllimit_j * x10;

      /* Saturate: '<S92>/Saturation1' */
      if (rtb_Saturation4 > 0.2F) {
        rtb_Saturation4 = 0.2F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S92>/Saturation1' */

      /* Sum: '<S101>/Add2' incorporates:
       *  Memory: '<S101>/Memory3'
       */
      rtb_L0_TLC_a = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_b;

      /* Saturate: '<S101>/Saturation' */
      if (rtb_L0_TLC_a > 50.0F) {
        rtb_Saturation_g = 50.0F;
      } else if (rtb_L0_TLC_a < 0.0F) {
        rtb_Saturation_g = 0.0F;
      } else {
        rtb_Saturation_g = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S101>/Saturation' */

      /* MATLAB Function: '<S92>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem1/MATLAB Function': '<S99>:1' */
      /* '<S99>:1:2' if T<T1 */
      if (rtb_Saturation_g < rtb_Saturation6_g) {
        /* '<S99>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_LL_LKASWASyn_M0 += ((rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6_g) * rtb_Saturation_g;
      } else if ((rtb_Saturation_g >= rtb_Saturation6_g) && (rtb_Saturation_g <=
                  (rtb_Saturation6_g + rtb_LL_LKASWASyn_T2))) {
        /* Switch: '<S534>/Switch14' incorporates:
         *  Constant: '<S534>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S99>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S99>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_a != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_a;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (((x10 - rtb_LL_LKASWASyn_M1) /
          rtb_LL_LKASWASyn_T2) * (rtb_Saturation_g - rtb_Saturation6_g)) +
          rtb_LL_LKASWASyn_M1;
      } else {
        /* Switch: '<S534>/Switch14' incorporates:
         *  Constant: '<S534>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S99>:1:6' else */
        /* '<S99>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_a != 0.0F) {
          rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20_a;
        } else {
          rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S92>/MATLAB Function' */

      /* Sum: '<S92>/Add1' */
      rtb_Saturation4 = rtb_LL_LKASWASyn_M0 - rtb_Saturation4;

      /* Saturate: '<S92>/Saturation2' */
      if (rtb_Saturation4 > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        LKAS_DW.Saturation2 = 0.0F;
      } else {
        LKAS_DW.Saturation2 = rtb_Saturation4;
      }

      /* End of Saturate: '<S92>/Saturation2' */

      /* Memory: '<S192>/Memory3' */
      rtb_Saturation4 = LKAS_DW.Memory3_PreviousInput_p;

      /* Sum: '<S192>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S192>/Saturation' */
      if (rtb_Saturation4 > 50.0F) {
        rtb_Saturation_d = 50.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation_d = 0.0F;
      } else {
        rtb_Saturation_d = rtb_Saturation4;
      }

      /* End of Saturate: '<S192>/Saturation' */

      /* If: '<S190>/If' incorporates:
       *  DataTypeConversion: '<S74>/Cast To Single'
       *  Inport: '<S198>/Plan'
       *  Inport: '<S198>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_g;
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_g = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S190>/If Action Subsystem' incorporates:
           *  ActionPort: '<S196>/Action Port'
           */
          /* InitializeConditions for If: '<S190>/If' incorporates:
           *  Memory: '<S196>/Memory'
           *  UnitDelay: '<S200>/Delay Input1'
           *
           * Block description for '<S200>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_ef = false;
          LKAS_DW.Memory_PreviousInput_d5 = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S190>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S190>/If Action Subsystem' incorporates:
         *  ActionPort: '<S196>/Action Port'
         */
        /* RelationalOperator: '<S199>/Compare' incorporates:
         *  Constant: '<S199>/Constant'
         */
        rtb_LogicalOperator3_a = (rtb_L0_C1_k >= 0.0F);

        /* Memory: '<S196>/Memory' */
        rtb_Plan_b = LKAS_DW.Memory_PreviousInput_d5;

        /* Sum: '<S196>/Add' incorporates:
         *  Logic: '<S196>/Logical Operator'
         *  RelationalOperator: '<S196>/Relational Operator'
         *  RelationalOperator: '<S200>/FixPt Relational Operator'
         *  UnitDelay: '<S200>/Delay Input1'
         *
         * Block description for '<S200>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_n = ((float32)(((((sint32)(rtb_LogicalOperator3_a ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_ef ? 1 : 0))) &&
          (rtb_Saturation6_g >= rtb_Saturation_d)) ? 1 : 0)) + rtb_Plan_b;

        /* Saturate: '<S196>/Saturation' */
        if (rtb_T1_n > 5.0F) {
          rtb_Saturation_i = 5.0F;
        } else if (rtb_T1_n < 0.0F) {
          rtb_Saturation_i = 0.0F;
        } else {
          rtb_Saturation_i = rtb_T1_n;
        }

        /* End of Saturate: '<S196>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S196>/If Action Subsystem' */
        LKAS_IfActionSubsystem_j(rtb_Saturation_i, rtb_Saturation_d,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_o, &LKAS_DW.In_a,
          &LKAS_DW.IfActionSubsystem_j);

        /* End of Outputs for SubSystem: '<S196>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S196>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_l(rtb_Saturation6_g, rtb_SWACmd_phiSWACmd,
          &rtb_T1_n, &rtb_Plan_b);

        /* End of Outputs for SubSystem: '<S196>/If Action Subsystem2' */

        /* Switch: '<S196>/Switch' incorporates:
         *  Switch: '<S196>/Switch1'
         */
        if (rtb_Saturation_i > 0.0F) {
          LKAS_DW.Merge_f = LKAS_DW.In_o;
          LKAS_DW.Merge1 = LKAS_DW.In_a;
        } else {
          LKAS_DW.Merge_f = rtb_T1_n;
          LKAS_DW.Merge1 = rtb_Plan_b;
        }

        /* End of Switch: '<S196>/Switch' */

        /* Update for UnitDelay: '<S200>/Delay Input1'
         *
         * Block description for '<S200>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_ef = rtb_LogicalOperator3_a;

        /* Update for Memory: '<S196>/Memory' */
        LKAS_DW.Memory_PreviousInput_d5 = rtb_Saturation_i;

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S190>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S197>/Action Port'
           */
          /* InitializeConditions for If: '<S190>/If' incorporates:
           *  Memory: '<S197>/Memory'
           *  UnitDelay: '<S208>/Delay Input1'
           *
           * Block description for '<S208>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_f = false;
          LKAS_DW.Memory_PreviousInput_m = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S190>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S190>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S197>/Action Port'
         */
        /* RelationalOperator: '<S207>/Compare' incorporates:
         *  Constant: '<S207>/Constant'
         */
        rtb_LogicalOperator3_a = (rtb_L0_C1 <= 0.0F);

        /* Memory: '<S197>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_m;

        /* Sum: '<S197>/Add' incorporates:
         *  Logic: '<S197>/Logical Operator'
         *  RelationalOperator: '<S197>/Relational Operator'
         *  RelationalOperator: '<S208>/FixPt Relational Operator'
         *  UnitDelay: '<S208>/Delay Input1'
         *
         * Block description for '<S208>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_j = ((float32)(((((sint32)(rtb_LogicalOperator3_a ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_f ? 1 : 0))) &&
          (rtb_Saturation6_g >= rtb_Saturation_d)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S197>/Saturation' */
        if (rtb_T1_j > 5.0F) {
          rtb_Saturation_j4 = 5.0F;
        } else if (rtb_T1_j < 0.0F) {
          rtb_Saturation_j4 = 0.0F;
        } else {
          rtb_Saturation_j4 = rtb_T1_j;
        }

        /* End of Saturate: '<S197>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S197>/If Action Subsystem' */
        LKAS_IfActionSubsystem_j(rtb_Saturation_j4, rtb_Saturation_d,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_h, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_c5);

        /* End of Outputs for SubSystem: '<S197>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S197>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_l(rtb_Saturation6_g, rtb_SWACmd_phiSWACmd,
          &rtb_T1_j, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S197>/If Action Subsystem2' */

        /* Switch: '<S197>/Switch' incorporates:
         *  Switch: '<S197>/Switch1'
         */
        if (rtb_Saturation_j4 > 0.0F) {
          LKAS_DW.Merge_f = LKAS_DW.In_h;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_f = rtb_T1_j;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S197>/Switch' */

        /* Update for UnitDelay: '<S208>/Delay Input1'
         *
         * Block description for '<S208>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_f = rtb_LogicalOperator3_a;

        /* Update for Memory: '<S197>/Memory' */
        LKAS_DW.Memory_PreviousInput_m = rtb_Saturation_j4;

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S190>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S198>/Action Port'
         */
        LKAS_DW.Merge_f = rtb_Saturation6_g;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S190>/If' */

      /* Product: '<S89>/Divide3' */
      rtb_Saturation4 = rtb_Saturation_d / LKAS_DW.Merge_f;

      /* Saturate: '<S89>/Saturation' */
      if (rtb_Saturation4 > 1.0F) {
        rtb_Saturation4 = 1.0F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S89>/Saturation' */

      /* Product: '<S89>/Divide6' */
      rtb_LL_LKASWASyn_M0 = LKAS_DW.DifferenceInputs2_b * rtb_Saturation4;

      /* Saturate: '<S89>/Saturation6' */
      if (LKAS_DW.Merge_f > 0.5F) {
        rtb_Saturation4 = 0.5F;
      } else if (LKAS_DW.Merge_f < 0.2F) {
        rtb_Saturation4 = 0.2F;
      } else {
        rtb_Saturation4 = LKAS_DW.Merge_f;
      }

      /* End of Saturate: '<S89>/Saturation6' */

      /* Product: '<S89>/Divide' incorporates:
       *  Product: '<S193>/Divide'
       *  Product: '<S89>/Divide4'
       *  Sum: '<S89>/Add2'
       */
      rtb_LftTTLC = (rtb_Saturation_d - LKAS_DW.Merge_f) / rtb_Saturation4;

      /* Saturate: '<S89>/Saturation2' incorporates:
       *  Product: '<S89>/Divide'
       */
      if (rtb_LftTTLC > 1.0F) {
        rtb_L0_C3 = 1.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_L0_C3 = 0.0F;
      } else {
        rtb_L0_C3 = rtb_LftTTLC;
      }

      /* End of Saturate: '<S89>/Saturation2' */

      /* Sum: '<S178>/Add1' incorporates:
       *  Gain: '<S221>/Gain2'
       *  Memory: '<S178>/Memory'
       *  Product: '<S178>/Divide'
       *  Product: '<S178>/Divide1'
       *  Sum: '<S221>/Add2'
       */
      rtb_Add1_m = (((rtb_Add_p + rtb_Add_mw) * 0.5F) * LKAS_ConstB.Divide2_m) +
        (LKAS_ConstB.Add2_b * LKAS_DW.Memory_PreviousInput_en);

      /* MATLAB Function: '<S176>/Saturable Gain Lut (SatGainLut)' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S179>:1' */
      /*  Function Name: Saturable Gain Lut */
      /*  */
      /*  Description:  */
      /*    Saturable Gain Lookup Table. */
      /*  */
      /*  Assumptions and Limitation: */
      /*    The data type of all inputs and output is single. */
      /*  */
      /*  Inputs: */
      /*    Input: */
      /*    InputLimLwr: */
      /*    InputLimUpr: */
      /*    GainLimLwr: */
      /*    GainLimUpr: */
      /*  */
      /*  Outputs: */
      /*    Gain: The result of Looking up table. */
      /*  $Revision: 1.0$ */
      /*  $Author: Zhang Jianwei$ */
      /*  $Date: January 27, 2019$ */
      /*  ________________________________________ */
      /* '<S179>:1:25' if Input <= InputLimLwr */
      if (rtb_IMAPve_g_ESC_VehSpd > rtb_R0_C2) {
        if (rtb_IMAPve_g_ESC_VehSpd >= rtb_R0_C1) {
          /* Switch: '<S534>/Switch35' incorporates:
           *  Constant: '<S534>/LL_LFClb_TFC_facmGainLutGain2_C=40'
           */
          /* '<S179>:1:27' elseif Input >= InputLimUpr */
          /* '<S179>:1:28' Gain = GainLimUpr; */
          if (LKAS_ConstB.DataTypeConversion17_o != 0.0F) {
            rtb_R0_C3 = LKAS_ConstB.DataTypeConversion17_o;
          } else {
            rtb_R0_C3 = LL_LFClb_TFC_facmGainLutGain2_C;
          }
        } else {
          /* Switch: '<S534>/Switch35' incorporates:
           *  Constant: '<S534>/LL_LFClb_TFC_facmGainLutGain2_C=40'
           */
          /* '<S179>:1:29' else */
          /* '<S179>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
          /* '<S179>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
          if (LKAS_ConstB.DataTypeConversion17_o != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion17_o;
          } else {
            x10 = LL_LFClb_TFC_facmGainLutGain2_C;
          }

          rtb_R0_C3 += ((rtb_IMAPve_g_ESC_VehSpd - rtb_R0_C2) / (rtb_R0_C1 -
            rtb_R0_C2)) * (x10 - rtb_R0_C3);
        }
      } else {
        /* '<S179>:1:26' Gain = GainLimLwr; */
      }

      /* End of MATLAB Function: '<S176>/Saturable Gain Lut (SatGainLut)' */

      /* Switch: '<S534>/Switch32' incorporates:
       *  Constant: '<S534>/LL_LFClb_TFC_tiKlatPrvwT_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion15_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_h;
      } else {
        x10 = LL_LFClb_TFC_tiKlatPrvwT_C;
      }

      /* End of Switch: '<S534>/Switch32' */

      /* Product: '<S176>/Divide1' */
      rtb_L0_TLC_a = x10 * rtb_LKA_Veh2CamL_C_tmp;

      /* Switch: '<S534>/Switch30' incorporates:
       *  Constant: '<S534>/LL_LFClb_TFC_facmKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_o != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_o;
      } else {
        x10 = LL_LFClb_TFC_facmKlat_C;
      }

      /* End of Switch: '<S534>/Switch30' */

      /* Saturate: '<S176>/Saturation' */
      if (rtb_L0_TLC_a > 40.0F) {
        rtb_L0_TLC_a = 40.0F;
      } else {
        if (rtb_L0_TLC_a < 5.0F) {
          rtb_L0_TLC_a = 5.0F;
        }
      }

      /* End of Saturate: '<S176>/Saturation' */

      /* Product: '<S176>/Product4' incorporates:
       *  Gain: '<S220>/Gain1'
       *  Product: '<S176>/Divide'
       *  Product: '<S176>/Product1'
       *  Sum: '<S176>/Subtract1'
       *  Sum: '<S220>/Add1'
       */
      rtb_R0_C1 = (((((rtb_Add_ns + rtb_Add_f) * 0.5F) / rtb_L0_TLC_a) * x10) -
                   rtb_Add1_m) * rtb_R0_C3;

      /* Saturate: '<S176>/Saturation2' */
      if (rtb_R0_C1 > 360.0F) {
        rtb_deltafalllimit_j = 360.0F;
      } else if (rtb_R0_C1 < (-360.0F)) {
        rtb_deltafalllimit_j = (-360.0F);
      } else {
        rtb_deltafalllimit_j = rtb_R0_C1;
      }

      /* End of Saturate: '<S176>/Saturation2' */

      /* Abs: '<S176>/Abs' incorporates:
       *  Gain: '<S219>/Gain1'
       */
      rtb_Yk1_f = fabsf(rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Saturate: '<S176>/Saturation1' */
      rtb_L0_TLC_a = rtb_Yk1_f;
      if (rtb_L0_TLC_a > 0.004F) {
        rtb_Yk1_f = 0.004F;
      } else if (rtb_L0_TLC_a < 1.0E-5F) {
        rtb_Yk1_f = 1.0E-5F;
      } else {
        rtb_Yk1_f = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S176>/Saturation1' */

      /* Switch: '<S534>/Switch39' incorporates:
       *  Constant: '<S534>/LL_LFClb_TFC_phiIntegCtlMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_phiIntegCtlMaxSWA_C;
      }

      /* End of Switch: '<S534>/Switch39' */

      /* Sum: '<S176>/Add3' incorporates:
       *  Constant: '<S176>/Constant3'
       *  Constant: '<S176>/Constant4'
       *  Product: '<S176>/Divide4'
       *  Sum: '<S176>/Add5'
       */
      rtb_Yk1_f = (((x10 - 1.0F) * rtb_Yk1_f) / 0.004F) + 1.0F;

      /* Sum: '<S183>/Add2' incorporates:
       *  Memory: '<S183>/Memory3'
       */
      rtb_L0_TLC_a = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_l;

      /* Saturate: '<S183>/Saturation' */
      if (rtb_L0_TLC_a > 50.0F) {
        rtb_Saturation_n = 50.0F;
      } else if (rtb_L0_TLC_a < 0.0F) {
        rtb_Saturation_n = 0.0F;
      } else {
        rtb_Saturation_n = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S183>/Saturation' */

      /* Switch: '<S176>/Switch2' incorporates:
       *  Product: '<S176>/Divide2'
       *  Sum: '<S176>/Add'
       *  Sum: '<S176>/Add2'
       *  Switch: '<S534>/Switch40'
       *  UnitDelay: '<S176>/Unit Delay'
       */
      if ((rtb_Saturation_n - rtb_Saturation6_g) >= 0.0F) {
        /* Switch: '<S534>/Switch40' incorporates:
         *  Constant: '<S534>/LL_LFClb_TFC_facmIntegRatio=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_facmIntegRatio;
        }

        rtb_Switch2_o = (rtb_R0_C1 * x10) + LKAS_DW.UnitDelay_DSTATE_g;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S534>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S534>/Switch40' incorporates:
           *  Constant: '<S534>/LL_LFClb_TFC_facmIntegRatio=0.01'
           */
          x10 = LL_LFClb_TFC_facmIntegRatio;
        }

        rtb_Switch2_o = rtb_R0_C1 * x10;
      }

      /* End of Switch: '<S176>/Switch2' */

      /* Gain: '<S176>/Gain' */
      rtb_R0_C1 = (-1.0F) * rtb_Yk1_f;

      /* Switch: '<S180>/Switch' incorporates:
       *  RelationalOperator: '<S180>/UpperRelop'
       */
      if (rtb_Switch2_o < rtb_R0_C1) {
        rtb_Switch_i = rtb_R0_C1;
      } else {
        rtb_Switch_i = rtb_Switch2_o;
      }

      /* End of Switch: '<S180>/Switch' */

      /* Switch: '<S180>/Switch2' incorporates:
       *  RelationalOperator: '<S180>/LowerRelop1'
       */
      if (rtb_Switch2_o > rtb_Yk1_f) {
        rtb_Switch2_b = rtb_Yk1_f;
      } else {
        rtb_Switch2_b = rtb_Switch_i;
      }

      /* End of Switch: '<S180>/Switch2' */

      /* Sum: '<S89>/Add3' */
      rtb_R0_C2 = rtb_deltafalllimit_j + rtb_Switch2_b;

      /* Switch: '<S534>/Switch49' incorporates:
       *  Constant: '<S534>/LL_LFClb_TFC_DiffCtrlMaxSWA=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_DiffCtrlMaxSWA;
      }

      /* End of Switch: '<S534>/Switch49' */

      /* Product: '<S176>/Divide8' incorporates:
       *  Constant: '<S176>/Constant7'
       *  Constant: '<S176>/Constant8'
       *  Sum: '<S176>/Add4'
       */
      rtb_Yk1_f = ((180.0F - rtb_LKA_Veh2CamL_C_tmp) * x10) / 120.0F;

      /* Sum: '<S182>/Add2' */
      rtb_deltafalllimit_j = rtb_L0_C0_o + rtb_Saturation_mn;

      /* Saturate: '<S182>/Saturation' */
      rtb_L0_TLC_a = rtb_deltafalllimit_j;
      if (rtb_L0_TLC_a > 2.0F) {
        rtb_deltafalllimit_j = 2.0F;
      } else if (rtb_L0_TLC_a < (-2.0F)) {
        rtb_deltafalllimit_j = (-2.0F);
      } else {
        rtb_deltafalllimit_j = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S182>/Saturation' */

      /* Switch: '<S534>/Switch9' incorporates:
       *  Constant: '<S534>/LL_LFClb_TFC_DiffCtlBalance=1.2'
       */
      if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion9;
      } else {
        x10 = LL_LFClb_TFC_DiffCtlBalance;
      }

      /* End of Switch: '<S534>/Switch9' */

      /* Sum: '<S182>/Add6' */
      rtb_R0_C1 = rtb_Add5_k_tmp - x10;

      /* Product: '<S182>/Divide5' incorporates:
       *  Constant: '<S182>/Constant3'
       *  Product: '<S182>/Divide4'
       *  Sum: '<S182>/Add5'
       */
      rtb_Divide5 = ((rtb_deltafalllimit_j / rtb_R0_C1) + 1.0F) *
        rtb_LL_LFClb_TFC_DiffCtrlRatio;

      /* Product: '<S182>/Divide2' incorporates:
       *  Constant: '<S182>/Constant2'
       *  Product: '<S182>/Divide1'
       *  Sum: '<S182>/Add1'
       *  UnaryMinus: '<S182>/Unary Minus'
       */
      rtb_Divide2_n = (((-rtb_deltafalllimit_j) / rtb_R0_C1) + 1.0F) *
        rtb_LL_LFClb_TFC_DiffCtrlRatio;

      /* Sum: '<S187>/Add' incorporates:
       *  Constant: '<S187>/Constant'
       *  Memory: '<S187>/Memory'
       */
      rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_o));

      /* Saturate: '<S187>/Saturation1' */
      if (rtb_Saturation_pw < ((uint16)10000U)) {
        rtb_Saturation1_nn = rtb_Saturation_pw;
      } else {
        rtb_Saturation1_nn = ((uint16)10000U);
      }

      /* End of Saturate: '<S187>/Saturation1' */

      /* If: '<S187>/If' incorporates:
       *  Constant: '<S187>/Constant2'
       *  DataTypeConversion: '<S74>/Cast To Single'
       *  Inport: '<S188>/In'
       */
      if (rtb_Saturation1_nn == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S187>/if action ' incorporates:
         *  ActionPort: '<S188>/Action Port'
         */
        LKAS_DW.In_p0 = LKAS_DW.LKASM_stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S187>/if action ' */
      }

      /* End of If: '<S187>/If' */

      /* If: '<S182>/If' */
      if (((sint32)LKAS_DW.In_p0) == 1) {
        /* Outputs for IfAction SubSystem: '<S182>/If Action Subsystem' incorporates:
         *  ActionPort: '<S184>/Action Port'
         */
        LKAS_IfActionSubsystem_e(rtb_Divide2_n, &rtb_deltafalllimit_j);

        /* End of Outputs for SubSystem: '<S182>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_p0) == 2) {
        /* Outputs for IfAction SubSystem: '<S182>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S185>/Action Port'
         */
        LKAS_IfActionSubsystem_e(rtb_Divide5, &rtb_deltafalllimit_j);

        /* End of Outputs for SubSystem: '<S182>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S182>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S186>/Action Port'
         */
        LKAS_IfActionSubsystem_e(rtb_LL_LFClb_TFC_DiffCtrlRatio,
          &rtb_deltafalllimit_j);

        /* End of Outputs for SubSystem: '<S182>/If Action Subsystem2' */
      }

      /* End of If: '<S182>/If' */

      /* Saturate: '<S182>/Saturation1' */
      rtb_L0_TLC_a = rtb_deltafalllimit_j;
      if (rtb_L0_TLC_a > 1000.0F) {
        rtb_deltafalllimit_j = 1000.0F;
      } else if (rtb_L0_TLC_a < 0.0F) {
        rtb_deltafalllimit_j = 0.0F;
      } else {
        rtb_deltafalllimit_j = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S182>/Saturation1' */

      /* Product: '<S176>/Divide7' incorporates:
       *  Gain: '<S176>/Gain2'
       */
      rtb_Divide7 = (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * (-0.5F)) *
        rtb_deltafalllimit_j;

      /* Gain: '<S176>/Gain3' */
      rtb_deltafalllimit_j = (-1.0F) * rtb_Yk1_f;

      /* Switch: '<S181>/Switch' incorporates:
       *  RelationalOperator: '<S181>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_deltafalllimit_j) {
        rtb_Switch_ns = rtb_deltafalllimit_j;
      } else {
        rtb_Switch_ns = rtb_Divide7;
      }

      /* End of Switch: '<S181>/Switch' */

      /* Switch: '<S181>/Switch2' incorporates:
       *  RelationalOperator: '<S181>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_Yk1_f) {
        rtb_Switch2_e = rtb_Yk1_f;
      } else {
        rtb_Switch2_e = rtb_Switch_ns;
      }

      /* End of Switch: '<S181>/Switch2' */

      /* Product: '<S89>/Divide4' */
      rtb_Yk1_f = rtb_LftTTLC;

      /* Saturate: '<S89>/Saturation1' */
      rtb_L0_TLC_a = rtb_Yk1_f;
      if (rtb_L0_TLC_a > 1.0F) {
        rtb_Yk1_f = 1.0F;
      } else if (rtb_L0_TLC_a < 0.0F) {
        rtb_Yk1_f = 0.0F;
      } else {
        rtb_Yk1_f = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S89>/Saturation1' */

      /* Product: '<S89>/Divide2' */
      rtb_L0_C0_o = rtb_Switch2_e * rtb_Yk1_f;

      /* Product: '<S193>/Divide' */
      rtb_Saturation4 = rtb_LftTTLC;

      /* Saturate: '<S193>/Saturation4' */
      if (rtb_Saturation4 > 1.0F) {
        rtb_Saturation4 = 1.0F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S193>/Saturation4' */

      /* Gain: '<S177>/kph to mps' */
      rtb_Yk1_f = rtb_LKA_Veh2CamL_C_tmp;

      /* Saturate: '<S177>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        rtb_deltafalllimit_j = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        rtb_deltafalllimit_j = 60.0F;
      } else {
        rtb_deltafalllimit_j = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S177>/Saturation3' */

      /* Product: '<S177>/Divide2' incorporates:
       *  Constant: '<S177>/Constant'
       */
      rtb_deltafalllimit_j = 0.09F / rtb_deltafalllimit_j;

      /* Saturate: '<S177>/Saturation1' */
      rtb_L0_TLC_a = rtb_deltafalllimit_j;
      if (rtb_L0_TLC_a > 0.01F) {
        rtb_deltafalllimit_j = 0.01F;
      } else if (rtb_L0_TLC_a < 0.0F) {
        rtb_deltafalllimit_j = 0.0F;
      } else {
        rtb_deltafalllimit_j = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S177>/Saturation1' */

      /* Switch: '<S534>/Switch36' incorporates:
       *  Constant: '<S534>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_l != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_l;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S534>/Switch36' */

      /* Gain: '<S177>/Gain2' incorporates:
       *  Constant: '<S177>/Constant1'
       *  Gain: '<S177>/rad to deg'
       *  Gain: '<S219>/Gain1'
       *  Math: '<S177>/Math Function'
       *  Product: '<S177>/Divide'
       *  Product: '<S177>/Divide1'
       *  Product: '<S177>/Product'
       *  Product: '<S177>/Product1'
       *  Product: '<S177>/Product2'
       *  Product: '<S177>/Product3'
       *  Sum: '<S177>/Add'
       *
       * About '<S177>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_Yk1_f = (((((((rtb_Yk1_f * rtb_Yk1_f) * rtb_deltafalllimit_j) + 1.0F) /
                      (rtb_Yk1_f / LKAS_DW.LKA_WhlBaseL_C_f)) * ((rtb_Yk1_f *
        rtb_LL_ThresDet_tiTTLCThresLDW) * 57.2957802F)) * x10) *
                   LKAS_DW.LKA_StrRatio_C_e) * (-1.0F);

      /* Product: '<S89>/Divide5' incorporates:
       *  Constant: '<S193>/Constant1'
       *  Product: '<S193>/Divide8'
       *  Sum: '<S193>/Add1'
       */
      rtb_deltafalllimit_j = ((LKAS_ConstB.Add3 * rtb_Saturation4) + 0.0F) *
        rtb_Yk1_f;

      /* Sum: '<S89>/Add4' incorporates:
       *  Constant: '<S89>/Constant2'
       *  Product: '<S89>/Divide1'
       *  Product: '<S89>/Divide7'
       *  Sum: '<S89>/Add5'
       */
      rtb_L0_C0_o = (((((1.0F - rtb_L0_C3) * LKAS_DW.Merge1) + (rtb_L0_C3 *
        rtb_R0_C2)) + rtb_L0_C0_o) + rtb_deltafalllimit_j) + rtb_LL_LKASWASyn_M0;

      /* Memory: '<S191>/Memory3' */
      rtb_deltafalllimit_j = LKAS_DW.Memory3_PreviousInput_d;

      /* Sum: '<S191>/Add2' incorporates:
       *  Constant: '<S191>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_deltafalllimit_j += 1.0F;

      /* Saturate: '<S191>/Saturation' */
      rtb_L0_TLC_a = rtb_deltafalllimit_j;
      if (rtb_L0_TLC_a > 50.0F) {
        rtb_Saturation_oq = 50.0F;
      } else if (rtb_L0_TLC_a < 0.0F) {
        rtb_Saturation_oq = 0.0F;
      } else {
        rtb_Saturation_oq = rtb_L0_TLC_a;
      }

      /* End of Saturate: '<S191>/Saturation' */

      /* Switch: '<S191>/Switch' incorporates:
       *  Constant: '<S89>/Constant1'
       *  Product: '<S191>/Divide'
       *  Product: '<S191>/Divide1'
       *  Sum: '<S191>/Add'
       *  Sum: '<S191>/Add1'
       *  UnitDelay: '<S191>/Unit Delay'
       */
      if (rtb_Saturation_oq > 30.0F) {
        rtb_Switch_j = ((rtb_LKA_SampleTime / 0.1F) * (rtb_L0_C0_o -
          LKAS_DW.UnitDelay_DSTATE_j)) + LKAS_DW.UnitDelay_DSTATE_j;
      } else {
        rtb_Switch_j = rtb_L0_C0_o;
      }

      /* End of Switch: '<S191>/Switch' */

      /* Switch: '<S534>/Switch17' incorporates:
       *  Constant: '<S534>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S534>/Switch17' */

      /* Sum: '<S86>/Add' */
      rtb_Add_i = (rtb_Switch_j - x10) + LKAS_DW.Saturation_n;

      /* Sum: '<S86>/Add1' */
      rtb_deltafalllimit_j = rtb_Yk1_f + rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S86>/Add2' incorporates:
       *  Gain: '<S86>/Gain2'
       */
      rtb_Yk1_f += (-1.0F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S172>/Switch' incorporates:
       *  RelationalOperator: '<S172>/UpperRelop'
       */
      if (rtb_Add_i < rtb_Yk1_f) {
        rtb_Switch_gr = rtb_Yk1_f;
      } else {
        rtb_Switch_gr = rtb_Add_i;
      }

      /* End of Switch: '<S172>/Switch' */

      /* Switch: '<S172>/Switch2' incorporates:
       *  RelationalOperator: '<S172>/LowerRelop1'
       */
      if (rtb_Add_i > rtb_deltafalllimit_j) {
        rtb_Switch2_k = rtb_deltafalllimit_j;
      } else {
        rtb_Switch2_k = rtb_Switch_gr;
      }

      /* End of Switch: '<S172>/Switch2' */

      /* Sum: '<S171>/Add1' incorporates:
       *  Constant: '<S171>/Constant'
       *  Memory: '<S171>/Memory'
       */
      rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_c0));

      /* Switch: '<S171>/Switch' incorporates:
       *  Constant: '<S171>/LatchTime_SY'
       *  RelationalOperator: '<S171>/Relational Operator'
       *  UnitDelay: '<S171>/Delay Input2'
       *
       * Block description for '<S171>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_pw <= ((uint16)1U)) {
        rtb_Yk1_f = rtb_Switch2_k;
      } else {
        rtb_Yk1_f = LKAS_DW.DelayInput2_DSTATE;
      }

      /* End of Switch: '<S171>/Switch' */

      /* Sum: '<S171>/Difference Inputs1'
       *
       * Block description for '<S171>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1 = rtb_Switch2_k - rtb_Yk1_f;

      /* SampleTimeMath: '<S171>/sample time'
       *
       * About '<S171>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_deltafalllimit_j = 0.01F;

      /* Product: '<S171>/delta rise limit' incorporates:
       *  Gain: '<S86>/Gain3'
       */
      rtb_R0_C1 = (1.4F * LKAS_DW.SWARmax) * rtb_deltafalllimit_j;

      /* Product: '<S171>/delta fall limit' incorporates:
       *  Gain: '<S86>/Gain1'
       */
      rtb_deltafalllimit_j *= (-1.4F) * LKAS_DW.SWARmax;

      /* Switch: '<S173>/Switch' incorporates:
       *  RelationalOperator: '<S173>/UpperRelop'
       */
      if (rtb_UkYk1 < rtb_deltafalllimit_j) {
        rtb_Switch_mh = rtb_deltafalllimit_j;
      } else {
        rtb_Switch_mh = rtb_UkYk1;
      }

      /* End of Switch: '<S173>/Switch' */

      /* Switch: '<S173>/Switch2' incorporates:
       *  RelationalOperator: '<S173>/LowerRelop1'
       */
      if (rtb_UkYk1 > rtb_R0_C1) {
        rtb_Switch2_ll4 = rtb_R0_C1;
      } else {
        rtb_Switch2_ll4 = rtb_Switch_mh;
      }

      /* End of Switch: '<S173>/Switch2' */

      /* Sum: '<S171>/Difference Inputs2'
       *
       * Block description for '<S171>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_ll4 + rtb_Yk1_f;

      /* Saturate: '<S171>/Saturation2' */
      if (rtb_Saturation_pw < ((uint16)10000U)) {
        rtb_Saturation2_n = rtb_Saturation_pw;
      } else {
        rtb_Saturation2_n = ((uint16)10000U);
      }

      /* End of Saturate: '<S171>/Saturation2' */

      /* DataTypeConversion: '<S87>/CastLKA3' */
      LKAS_DW.T1_Mon = LKAS_DW.Merge_f;

      /* DataTypeConversion: '<S111>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_IMAPve_g_ESC_VehSpd;

      /* DataTypeConversion: '<S87>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S85>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S103>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_o) {
          /* Disable for Outport: '<S105>/Out' */
          LKAS_DW.RelationalOperator_p5 = false;
          LKAS_DW.SumCondition1_MODE_o = false;
        }

        /* End of Disable for SubSystem: '<S103>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S83>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_m) {
          /* Disable for Outport: '<S91>/Out1' */
          LKAS_DW.DifferenceInputs2_b = 0.0F;
          LKAS_DW.Subsystem_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S83>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S104>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_g,
            &LKAS_DW.SumCondition1_c);
        }

        /* End of Disable for SubSystem: '<S104>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S104>/Sum Condition' */
        if (LKAS_DW.SumCondition_e.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_da,
            &LKAS_DW.SumCondition_e);
        }

        /* End of Disable for SubSystem: '<S104>/Sum Condition' */

        /* Disable for If: '<S190>/If' */
        LKAS_DW.If_ActiveSubsystem_g = -1;

        /* Disable for Outport: '<S74>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S74>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S74>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S74>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon = 0.0F;
        LKAS_DW.T1_Mon = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_T1_Mon = LKAS_DW.T1_Mon;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_State_Mon = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LDW_State_Mon = LKAS_DW.LDWSM_stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.LDWSM_stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S73>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S78>/If' */
      if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S78>/If Action Subsystem' incorporates:
         *  ActionPort: '<S79>/Action Port'
         */
        /* Gain: '<S79>/rad to deg' incorporates:
         *  Gain: '<S79>/Gain'
         */
        LKAS_DW.Merge_fq = ((-1.0F) * rtb_L0_C1_k) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S78>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S78>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S80>/Action Port'
         */
        /* Gain: '<S80>/rad to deg' */
        LKAS_DW.Merge_fq = 57.2957802F * rtb_L0_C1;

        /* End of Outputs for SubSystem: '<S78>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S78>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S81>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_fq);

        /* End of Outputs for SubSystem: '<S78>/If Action Subsystem2' */
      }

      /* End of If: '<S78>/If' */

      /* Switch: '<S533>/Switch2' incorporates:
       *  Constant: '<S533>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_f != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_f;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S533>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S78>/Sum Condition' incorporates:
       *  EnablePort: '<S82>/Enable'
       */
      /* RelationalOperator: '<S78>/Relational Operator' */
      if (LKAS_DW.Merge_fq >= x10) {
        if (!LKAS_DW.SumCondition_MODE) {
          /* InitializeConditions for Memory: '<S82>/Memory' */
          LKAS_DW.Memory_PreviousInput_dg = 0.0F;
          LKAS_DW.SumCondition_MODE = true;
        }

        /* Sum: '<S82>/Add1' incorporates:
         *  Memory: '<S82>/Memory'
         */
        rtb_L0_C1 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_dg;

        /* Saturate: '<S82>/Saturation' */
        if (rtb_L0_C1 > 0.6F) {
          rtb_L0_C1 = 0.6F;
        } else {
          if (rtb_L0_C1 < 0.0F) {
            rtb_L0_C1 = 0.0F;
          }
        }

        /* End of Saturate: '<S82>/Saturation' */

        /* RelationalOperator: '<S82>/Relational Operator' incorporates:
         *  Constant: '<S78>/Constant'
         */
        LKAS_DW.RelationalOperator_f = (rtb_L0_C1 >= 0.05F);

        /* Update for Memory: '<S82>/Memory' */
        LKAS_DW.Memory_PreviousInput_dg = rtb_L0_C1;
      } else {
        if (LKAS_DW.SumCondition_MODE) {
          /* Disable for Outport: '<S82>/Out' */
          LKAS_DW.RelationalOperator_f = false;
          LKAS_DW.SumCondition_MODE = false;
        }
      }

      /* End of RelationalOperator: '<S78>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S78>/Sum Condition' */

      /* Product: '<S73>/Product' incorporates:
       *  Logic: '<S73>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.LDWSM_stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_f) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S78>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE) {
          /* Disable for Outport: '<S82>/Out' */
          LKAS_DW.RelationalOperator_f = false;
          LKAS_DW.SumCondition_MODE = false;
        }

        /* End of Disable for SubSystem: '<S78>/Sum Condition' */

        /* Disable for Outport: '<S73>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* SignalConversion: '<S450>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S360>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LogicalOperator_kn;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_Compare_oi;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_Compare_mc4;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_bm;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_jv;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_d;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_e0;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_mb;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_k;
    rtb_TmpSignalConversionAtSFunct[12] = LKAS_DW.RelationalOperator_b;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_stDvrTkConFlg_h;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_ar;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator_d;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_LogicalOperator3_d;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge;

    /* MATLAB Function: '<S360>/Disable Reason' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S450>:1' */
    /* '<S450>:1:2' y = single(0); */
    LKAS_DW.y = 0.0F;

    /* '<S450>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S450>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S450>:1:5' y = single(i); */
        LKAS_DW.y = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LFTTTLC_Mon = rtb_LFTTTLC;

    /* Logic: '<S482>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S482>/Relational Operator3'
     *  RelationalOperator: '<S482>/Relational Operator4'
     */
    rtb_LogicalOperator1_p = ((rtb_Gain1 <= rtb_Abs_kj) || (rtb_Add5_k <=
      rtb_Abs_kj));

    /* Gain: '<S216>/Gain' incorporates:
     *  Sum: '<S216>/Add'
     */
    rtb_lDvt = (rtb_Gain1 + rtb_Add5_k) * 0.5F;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.DACMode = LKAS_DW.Divide;

    /* Gain: '<S215>/Gain' incorporates:
     *  Sum: '<S215>/Add'
     */
    rtb_crCrvt = (rtb_L0_C2_o + rtb_L0_C2) * 0.5F;

    /* Delay: '<S76>/Delay1' */
    rtb_DACMode = LKAS_DW.Delay1_2_DSTATE;

    /* RelationalOperator: '<S517>/Compare' incorporates:
     *  Constant: '<S517>/Constant'
     *  Constant: '<S542>/Constant14'
     */
    rtb_Compare_l1 = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S526>/Compare' incorporates:
     *  Constant: '<S526>/Constant'
     *  Constant: '<S542>/Constant11'
     */
    rtb_Compare_lb = (((uint8)0U) == ((uint8)1U));
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S368>/Count 20s' */
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S376>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Count20s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S368>/Count 20s' */

      /* Disable for Enabled SubSystem: '<S369>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S378>/Out' */
        LKAS_DW.RelationalOperator_im = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }

      /* End of Disable for SubSystem: '<S369>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S379>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_d) {
        /* Disable for Outport: '<S385>/Out' */
        LKAS_DW.RelationalOperator_b = false;
        LKAS_DW.SumCondition1_MODE_d = false;
      }

      /* End of Disable for SubSystem: '<S379>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S391>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S398>/Out' */
        LKAS_DW.RelationalOperator_d = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S391>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S308>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S338>/Out' */
        LKAS_DW.RelationalOperator_os = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S308>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S308>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S337>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S308>/Count' */

      /* Disable for Enabled SubSystem: '<S340>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_h) {
        /* Disable for Outport: '<S346>/Out' */
        LKAS_DW.RelationalOperator_n = false;
        LKAS_DW.SumCondition1_MODE_h = false;
      }

      /* End of Disable for SubSystem: '<S340>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S309>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_c) {
        /* Disable for Outport: '<S352>/Out' */
        LKAS_DW.RelationalOperator_p = false;
        LKAS_DW.SumCondition1_MODE_c = false;
      }

      /* End of Disable for SubSystem: '<S309>/Sum Condition1' */

      /* Disable for If: '<S355>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S267>/Count_5s3' */
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S531>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }

      /* End of Disable for SubSystem: '<S267>/Count_5s3' */

      /* Disable for Enabled SubSystem: '<S267>/Count_5s2' */
      if (LKAS_DW.Count_5s2.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_o, &LKAS_DW.Count_5s2);
      }

      /* End of Disable for SubSystem: '<S267>/Count_5s2' */

      /* Disable for Enabled SubSystem: '<S267>/Count_5s1' */
      if (LKAS_DW.Count_5s1.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_i, &LKAS_DW.Count_5s1);
      }

      /* End of Disable for SubSystem: '<S267>/Count_5s1' */

      /* Disable for Enabled SubSystem: '<S244>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE) {
        /* Disable for Outport: '<S248>/Out' */
        LKAS_DW.RelationalOperator_iy = false;
        LKAS_DW.Subsystem_MODE = false;
      }

      /* End of Disable for SubSystem: '<S244>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S85>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S103>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_o) {
          /* Disable for Outport: '<S105>/Out' */
          LKAS_DW.RelationalOperator_p5 = false;
          LKAS_DW.SumCondition1_MODE_o = false;
        }

        /* End of Disable for SubSystem: '<S103>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S83>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_m) {
          /* Disable for Outport: '<S91>/Out1' */
          LKAS_DW.DifferenceInputs2_b = 0.0F;
          LKAS_DW.Subsystem_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S83>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S104>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_g,
            &LKAS_DW.SumCondition1_c);
        }

        /* End of Disable for SubSystem: '<S104>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S104>/Sum Condition' */
        if (LKAS_DW.SumCondition_e.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_da,
            &LKAS_DW.SumCondition_e);
        }

        /* End of Disable for SubSystem: '<S104>/Sum Condition' */

        /* Disable for If: '<S190>/If' */
        LKAS_DW.If_ActiveSubsystem_g = -1;

        /* Disable for Outport: '<S74>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S74>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S74>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S74>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon = 0.0F;
        LKAS_DW.T1_Mon = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S78>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE) {
          /* Disable for Outport: '<S82>/Out' */
          LKAS_DW.RelationalOperator_f = false;
          LKAS_DW.SumCondition_MODE = false;
        }

        /* End of Disable for SubSystem: '<S78>/Sum Condition' */

        /* Disable for Outport: '<S73>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.DACMode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;

      /* Disable for Outport: '<S10>/Disable_Reason' */
      LKAS_DW.y = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MultiPortSwitch: '<S9>/Multiport Switch' incorporates:
   *  Constant: '<S9>/Constant'
   *  Constant: '<S9>/Constant1'
   *  Constant: '<S9>/Constant2'
   *  Constant: '<S9>/Constant3'
   *  Constant: '<S9>/Constant4'
   *  Constant: '<S9>/Constant5'
   *  Constant: '<S9>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_EPS_LKA_Control = (UInt8)((uint8)0U);
    break;

   case 1:
    rtb_EPS_LKA_Control = (UInt8)((uint8)1U);
    break;

   case 2:
    rtb_EPS_LKA_Control = (UInt8)((uint8)2U);
    break;

   case 3:
    rtb_EPS_LKA_Control = (UInt8)((uint8)3U);
    break;

   case 4:
    rtb_EPS_LKA_Control = (UInt8)((uint8)4U);
    break;

   case 5:
    rtb_EPS_LKA_Control = (UInt8)((uint8)4U);
    break;

   default:
    rtb_EPS_LKA_Control = (UInt8)((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S9>/Multiport Switch' */

  /* Switch: '<S9>/Switch' incorporates:
   *  Constant: '<S71>/Constant'
   *  Gain: '<S9>/Gain'
   *  RelationalOperator: '<S71>/Compare'
   */
  if (rtb_EPS_LKA_Control == ((UInt8)((uint8)4U))) {
    rtb_Abs_kj = LKAS_DW.OutputM;
  } else {
    rtb_Abs_kj = 0.05F * LKAS_DW.y;
  }

  /* End of Switch: '<S9>/Switch' */

  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_y_EPS_State_Control_1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control
    (rtb_EPS_LKA_Control);

  /* Switch: '<S31>/Switch' incorporates:
   *  Constant: '<S31>/Constant'
   *  Constant: '<S31>/Constant1'
   *  Constant: '<S33>/Constant'
   *  RelationalOperator: '<S33>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_L0_TLC = 0.5F;
  } else {
    rtb_L0_TLC = 0.25F;
  }

  /* End of Switch: '<S31>/Switch' */

  /* Logic: '<S31>/Logical Operator2' incorporates:
   *  Abs: '<S31>/Abs'
   *  Constant: '<S34>/Constant'
   *  Constant: '<S35>/Constant'
   *  Constant: '<S36>/Constant'
   *  Constant: '<S37>/Constant'
   *  Constant: '<S38>/Constant'
   *  Logic: '<S31>/Logical Operator3'
   *  RelationalOperator: '<S31>/Relational Operator'
   *  RelationalOperator: '<S34>/Compare'
   *  RelationalOperator: '<S35>/Compare'
   *  RelationalOperator: '<S36>/Compare'
   *  RelationalOperator: '<S37>/Compare'
   *  RelationalOperator: '<S38>/Compare'
   */
  rtb_LogicalOperator_kn = ((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) || (rtb_IMAPve_d_EPS_LKA_State ==
    ((uint8)1U))) && (fabsf(rtb_IMAPve_g_EPS_SW_Trq) <= rtb_L0_TLC));

  /* Outputs for Enabled SubSystem: '<S31>/Count 10s' incorporates:
   *  EnablePort: '<S39>/Enable'
   */
  if (rtb_LogicalOperator_kn) {
    if (!LKAS_DW.Count10s_MODE) {
      /* InitializeConditions for Memory: '<S39>/Memory' */
      LKAS_DW.Memory_PreviousInput_im = ((uint16)0U);
      LKAS_DW.Count10s_MODE = true;
    }

    /* Sum: '<S39>/Add' incorporates:
     *  Constant: '<S39>/Constant'
     *  Memory: '<S39>/Memory'
     */
    rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      LKAS_DW.Memory_PreviousInput_im));

    /* Saturate: '<S39>/Saturation' */
    if (rtb_Saturation_pw >= ((uint16)2100U)) {
      rtb_Saturation_pw = ((uint16)2100U);
    }

    /* End of Saturate: '<S39>/Saturation' */

    /* RelationalOperator: '<S41>/Compare' incorporates:
     *  Constant: '<S41>/Constant'
     */
    LKAS_DW.Compare_p = (rtb_Saturation_pw >= ((uint16)1000U));

    /* Update for Memory: '<S39>/Memory' */
    LKAS_DW.Memory_PreviousInput_im = rtb_Saturation_pw;
  } else {
    if (LKAS_DW.Count10s_MODE) {
      /* Disable for Outport: '<S39>/Out' */
      LKAS_DW.Compare_p = false;
      LKAS_DW.Count10s_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S31>/Count 10s' */

  /* MATLAB Function: '<S7>/HMI_Popup_Status' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S25>:1' */
  /* '<S25>:1:2' if stDACmode==2&&LKA_STATE==6 */
  if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) == 6)) {
    /* �������ָ������� */
    /* '<S25>:1:3' HMI_Popup_Status=uint8(6); */
    rtb_IMAPve_d_Camera_Status = 6U;
  } else if (((((sint32)LKAS_DW.Divide) == 2) || (((sint32)LKAS_DW.Divide) == 1))
             && (((sint32)rtb_IMAPve_d_Camera_Status) == 5)) {
    /* '<S25>:1:6' elseif (stDACmode==2||stDACmode==1)&&(Front_Camera_Blocked==5) */
    /* ����ͷ���ڵ� */
    /* '<S25>:1:7' HMI_Popup_Status=uint8(4); */
    rtb_IMAPve_d_Camera_Status = 4U;
  } else if (((((sint32)LKAS_DW.Divide) == 2) || (((sint32)LKAS_DW.Divide) == 1))
             && (LKAS_DW.Compare_p)) {
    /* '<S25>:1:8' elseif (stDACmode==2||stDACmode==1)&&HandsOff==1 */
    /* ���շ����� */
    /* '<S25>:1:9' HMI_Popup_Status=uint8(2); */
    rtb_IMAPve_d_Camera_Status = 2U;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              2)) {
    /* '<S25>:1:10' elseif stDACmode==2&&(LKA_STATE==2) */
    /* '<S25>:1:11' HMI_Popup_Status=uint8(1); */
    rtb_IMAPve_d_Camera_Status = 1U;
  } else if (((sint32)LKAS_DW.Divide) != 2) {
    /* '<S25>:1:12' elseif stDACmode~=2&&stFaultCSyn==0 */
    /* '<S25>:1:13' HMI_Popup_Status=uint8(8); */
    rtb_IMAPve_d_Camera_Status = 8U;
  } else {
    /* '<S25>:1:14' elseif stFaultCSyn==0 */
    /* '<S25>:1:15' HMI_Popup_Status=uint8(7); */
    rtb_IMAPve_d_Camera_Status = 7U;
  }

  /* End of MATLAB Function: '<S7>/HMI_Popup_Status' */

  /* Outputs for Enabled SubSystem: '<S31>/Count 15s' incorporates:
   *  EnablePort: '<S40>/Enable'
   */
  if (rtb_LogicalOperator_kn) {
    if (!LKAS_DW.Count15s_MODE) {
      /* InitializeConditions for Memory: '<S40>/Memory' */
      LKAS_DW.Memory_PreviousInput_bh = ((uint16)0U);
      LKAS_DW.Count15s_MODE = true;
    }

    /* Sum: '<S40>/Add' incorporates:
     *  Constant: '<S40>/Constant'
     *  Memory: '<S40>/Memory'
     */
    rtb_Saturation_pw = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      LKAS_DW.Memory_PreviousInput_bh));

    /* Saturate: '<S40>/Saturation' */
    if (rtb_Saturation_pw >= ((uint16)2100U)) {
      rtb_Saturation_pw = ((uint16)2100U);
    }

    /* End of Saturate: '<S40>/Saturation' */

    /* RelationalOperator: '<S42>/Compare' incorporates:
     *  Constant: '<S42>/Constant'
     */
    LKAS_DW.Compare = (rtb_Saturation_pw >= ((uint16)1500U));

    /* Update for Memory: '<S40>/Memory' */
    LKAS_DW.Memory_PreviousInput_bh = rtb_Saturation_pw;
  } else {
    if (LKAS_DW.Count15s_MODE) {
      /* Disable for Outport: '<S40>/Out' */
      LKAS_DW.Compare = false;
      LKAS_DW.Count15s_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S31>/Count 15s' */

  /* MATLAB Function: '<S7>/Hands_off_warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_off_warning': '<S26>:1' */
  /* '<S26>:1:2' if HandsOff==0 */
  if (!LKAS_DW.Compare) {
    /* '<S26>:1:3' Hands_off_warning= uint8(0); */
    rtb_IMAPve_d_BCM_HazardLamp = 0U;
  } else {
    /* '<S26>:1:4' elseif HandsOff==1 */
    /* '<S26>:1:5' Hands_off_warning= uint8(1); */
    rtb_IMAPve_d_BCM_HazardLamp = 1U;
  }

  /* End of MATLAB Function: '<S7>/Hands_off_warning' */

  /* MATLAB Function: '<S7>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S27>:1' */
  /* '<S27>:1:2' if HMI_stDACmode==1 */
  switch (LKAS_DW.Divide) {
   case 1:
    /* '<S27>:1:3' if HMI_LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S27>:1:4' LDW_Flag=uint8(1); */
      rtb_IMAPve_d_BCM_Left_Light = 1U;
      break;

     case 2:
      /* '<S27>:1:5' elseif HMI_LDWWarnInfo==2 */
      /* '<S27>:1:6' LDW_Flag=uint8(2); */
      rtb_IMAPve_d_BCM_Left_Light = 2U;
      break;

     default:
      /* '<S27>:1:7' else */
      /* '<S27>:1:8' LDW_Flag=uint8(0); */
      rtb_IMAPve_d_BCM_Left_Light = 0U;
      break;
    }
    break;

   case 2:
    /* '<S27>:1:10' elseif HMI_stDACmode==2 */
    /* '<S27>:1:11' if HMI_LDWWarnInfo==1 && HMI_LKA_STATE==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S27>:1:12' LDW_Flag=uint8(1); */
      rtb_IMAPve_d_BCM_Left_Light = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S27>:1:13' elseif HMI_LDWWarnInfo==2 && HMI_LKA_STATE==5 */
      /* '<S27>:1:14' LDW_Flag=uint8(2); */
      rtb_IMAPve_d_BCM_Left_Light = 2U;
    } else {
      /* '<S27>:1:15' else */
      /* '<S27>:1:16' LDW_Flag=uint8(0); */
      rtb_IMAPve_d_BCM_Left_Light = 0U;
    }
    break;

   default:
    /* '<S27>:1:18' else */
    /* '<S27>:1:19' LDW_Flag=uint8(0); */
    rtb_IMAPve_d_BCM_Left_Light = 0U;
    break;
  }

  /* End of MATLAB Function: '<S7>/LDW_Flag' */

  /* MATLAB Function: '<S7>/LDW_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Status_Display': '<S28>:1' */
  /* '<S28>:1:2' if (stDACmode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.Divide) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S28>:1:3' LDW_Status_Display=uint8(1); */
    rtb_IMAPve_d_BCM_Right_Light = 1U;
  } else if ((((sint32)LKAS_DW.Divide) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S28>:1:4' elseif (stDACmode==1)&&LDW_STATE==6 */
    /* '<S28>:1:5' LDW_Status_Display=uint8(2); */
    rtb_IMAPve_d_BCM_Right_Light = 2U;
  } else {
    /* '<S28>:1:6' else */
    /* '<S28>:1:7' LDW_Status_Display=uint8(0); */
    rtb_IMAPve_d_BCM_Right_Light = 0U;
  }

  /* End of MATLAB Function: '<S7>/LDW_Status_Display' */

  /* MATLAB Function: '<S7>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S30>:1' */
  /* '<S30>:1:2' if stDACmode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S30>:1:3' LKA_action_indication=uint8(1); */
    rtb_LKA_action_indication = 1U;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S30>:1:4' elseif stDACmode==2&&LKA_STATE==3 */
    /* '<S30>:1:5' LKA_action_indication=uint8(2); */
    rtb_LKA_action_indication = 2U;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S30>:1:6' elseif stDACmode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S30>:1:7' LKA_action_indication=uint8(3); */
    rtb_LKA_action_indication = 3U;
  } else {
    /* '<S30>:1:8' else */
    /* '<S30>:1:9' LKA_action_indication=uint8(0); */
    rtb_LKA_action_indication = 0U;
  }

  /* End of MATLAB Function: '<S7>/LKA_action_indication' */

  /* MATLAB Function: '<S7>/LKA_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_Status_Display': '<S29>:1' */
  /* '<S29>:1:3' if stDACmode==2&&LKA_STATE~=6 */
  if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) != 6)) {
    /* '<S29>:1:4' LKA_Status_Display=single(1); */
    rtb_L0_C2 = 1.0F;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S29>:1:5' elseif stDACmode==2&&LKA_STATE==6 */
    /* '<S29>:1:6' LKA_Status_Display=single(2); */
    rtb_L0_C2 = 2.0F;
  } else {
    /* '<S29>:1:7' else */
    /* '<S29>:1:8' LKA_Status_Display=single(0); */
    rtb_L0_C2 = 0.0F;
  }

  /* End of MATLAB Function: '<S7>/LKA_Status_Display' */

  /* MATLAB Function: '<S7>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S51>/Switch'
   *  Switch: '<S51>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S32>:1' */
  /* '<S32>:1:2' if stDACmode==1 */
  switch (LKAS_DW.Divide) {
   case 1:
    /* '<S32>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S32>:1:6' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S32>:1:8' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S32>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S32>:1:10' Vehicle_Lane_Display=uint8(6); */
        rtb_L0_Q = 6U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S32>:1:12' Vehicle_Lane_Display=uint8(7); */
        rtb_L0_Q = 7U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S32>:1:14' Vehicle_Lane_Display=uint8(8); */
        rtb_L0_Q = 8U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S32>:1:16' Vehicle_Lane_Display=uint8(9); */
        rtb_L0_Q = 9U;
      } else {
        /* '<S32>:1:17' else */
        /* '<S32>:1:18' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S32>:1:4' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   case 2:
    /* '<S32>:1:20' elseif stDACmode==2 */
    /* '<S32>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S32>:1:24' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S32>:1:26' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S32>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S32>:1:28' Vehicle_Lane_Display=uint8(6); */
        rtb_L0_Q = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S32>:1:30' Vehicle_Lane_Display=uint8(7); */
        rtb_L0_Q = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S32>:1:32' Vehicle_Lane_Display=uint8(8); */
        rtb_L0_Q = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S32>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S32>:1:34' Vehicle_Lane_Display=uint8(9); */
        rtb_L0_Q = 9U;
      } else {
        /* '<S32>:1:35' else */
        /* '<S32>:1:36' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S32>:1:22' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   default:
    /* '<S32>:1:38' else */
    /* '<S32>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_L0_Q = 0U;
    break;
  }

  /* End of MATLAB Function: '<S7>/Vehicle_Lane_Display' */

  /* DataTypeConversion: '<S9>/Cast To Single10' incorporates:
   *  Constant: '<S72>/Constant'
   *  RelationalOperator: '<S72>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.DACMode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S9>/Cast To Single13' */
  rtb_LKA_Mode_from_Camera = LKAS_DW.DACMode;

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S60>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_e = rtb_R0_Type;
  } else {
    rtb_R0_Type_e = rtb_L0_Type;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  Constant: '<S57>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_Q_1'
   *  DataTypeConversion: '<S58>/Cast To Single5'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_Q'
   *  Switch: '<S57>/Switch3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_h = rtb_L0_Type;
    rtb_L1_Q = (uint16)((uint8)
                        Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L1_Q_IMAPve_d_ORI_L1_Q
                        ());
  } else {
    rtb_L0_Type_h = rtb_R0_Type;
    rtb_L1_Q = ((uint16)0U);
  }

  /* DataTypeConversion: '<S50>/Cast To Single19' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_LC_1'
   *  Inport: '<Root>/IMAPve_d_ORI_R0_LC'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R0_LC_IMAPve_d_ORI_R0_LC();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_LC_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_L0_LC'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L0_LC_IMAPve_d_ORI_L0_LC();

  /* Switch: '<S59>/Switch3' incorporates:
   *  Constant: '<S59>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_Q_1'
   *  DataTypeConversion: '<S50>/Cast To Single9'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_Q'
   *  Switch: '<S51>/Switch'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R1_Q = (uint16)((uint8)
                        Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R1_Q_IMAPve_d_ORI_R1_Q
                        ());
    rtb_R0_LC_b = rtb_L0_Type;
  } else {
    rtb_R1_Q = ((uint16)0U);
    rtb_R0_LC_b = (uint8)rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S59>/Switch3' */

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single9'
   *  DataTypeConversion: '<S58>/Cast To Single8'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_LC_o = (uint8)rtb_EPS_LKA_Control;
  } else {
    rtb_L0_LC_o = rtb_L0_Type;
  }

  /* DataTypeConversion: '<S50>/Cast To Single24' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_VR_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_VR'
   */
  rtb_L0_C1 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_VR_IMAPve_g_ORI_R0_VR();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_VR_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_L0_VR'
   */
  rtb_L0_C2_o = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_VR_IMAPve_g_ORI_L0_VR();

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single32'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_VR_h = rtb_L0_C1;
  } else {
    rtb_R0_VR_h = rtb_L0_C2_o;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single32'
   *  DataTypeConversion: '<S58>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_m = rtb_L0_C2_o;
  } else {
    rtb_L0_VR_m = rtb_L0_C1;
  }

  /* DataTypeConversion: '<S50>/Cast To Single40' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_W'
   */
  rtb_L0_C1 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R0_W_IMAPve_g_ORI_R0_W();

  /* DataTypeConversion: '<S1>/IMAPve_g_ORI_L0_W_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ORI_L0_W'
   */
  rtb_L0_C2_o = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L0_W_IMAPve_g_ORI_L0_W();

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single37'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_p = rtb_L0_C1;
  } else {
    rtb_R0_W_p = rtb_L0_C2_o;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single37'
   *  DataTypeConversion: '<S58>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_k = rtb_L0_C2_o;
  } else {
    rtb_L0_W_k = rtb_L0_C1;
  }

  /* RelationalOperator: '<S19>/Compare' incorporates:
   *  Constant: '<S19>/Constant'
   */
  rtb_Compare_g = (rtb_IMAPve_d_TCU_Actual_Gear > ((uint8)3U));

  /* RelationalOperator: '<S12>/Compare' incorporates:
   *  Constant: '<S12>/Constant'
   */
  rtb_Compare_bb = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch'
   */
  rtb_IMAPve_d_BCM_LeftTurn_Switc = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch'
   */
  rtb_IMAPve_d_BCM_RightTurn_Swit = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Signal_Fault_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Camera_Signal_Fault'
   */
  rtb_IMAPve_d_Camera_Signal_Faul = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Signal_Fault_IMAPve_d_Camera_Signal_Fault
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ConsArea_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ConsArea'
   */
  rtb_IMAPve_d_ConsArea = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ConsArea_IMAPve_d_ConsArea();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Active_ESA_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Active_ESA'
   */
  rtb_IMAPve_d_EPS_Driver_Active_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Active_ESA_IMAPve_d_EPS_Driver_Active_ESA
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Override'
   */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_ESA_State'
   */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Error_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Error_State'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Error_State_IMAPve_d_EPS_Error_State
    ();

  /* Logic: '<S6>/Logical Operator5' incorporates:
   *  Constant: '<S13>/Constant'
   *  Constant: '<S16>/Constant'
   *  RelationalOperator: '<S13>/Compare'
   *  RelationalOperator: '<S16>/Compare'
   */
  rtb_Event_FaulETATDA = ((rtb_EPS_LKA_Control == ((UInt8)((uint8)1U))) ||
    (rtb_EPS_LKA_Control == ((UInt8)((uint8)2U))));

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State'
   */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag'
   */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    ();

  /* RelationalOperator: '<S20>/Compare' incorporates:
   *  Constant: '<S20>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_TrqLim_State'
   */
  rtb_Compare_di = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State
                     ()) == ((uint8)0U));

  /* RelationalOperator: '<S21>/Compare' incorporates:
   *  Constant: '<S21>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_Trq_State'
   */
  rtb_Compare_p = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State
                    ()) == ((uint8)1U));

  /* RelationalOperator: '<S22>/Compare' incorporates:
   *  Constant: '<S22>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid'
   */
  rtb_Compare_pg = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S24>/Compare' incorporates:
   *  Constant: '<S24>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid'
   */
  rtb_Compare_l = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid
                    ()) == ((uint8)1U));

  /* RelationalOperator: '<S11>/Compare' incorporates:
   *  Constant: '<S11>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid'
   */
  rtb_Compare_hs = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid
                     ()) != ((uint8)1U));

  /* RelationalOperator: '<S23>/Compare' incorporates:
   *  Constant: '<S23>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid'
   */
  rtb_Compare_i = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid
                    ()) == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Fusion_Status'
   */
  rtb_IMAPve_d_Fusion_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status();

  /* DataTypeConversion: '<S50>/Cast To Single80' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_LC_1'
   *  Inport: '<Root>/IMAPve_d_L0_LC'
   */
  rtb_L0_LC_c = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_LC_IMAPve_d_L0_LC();

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Q'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q();

  /* Switch: '<S55>/Switch' incorporates:
   *  Constant: '<S55>/Constant'
   */
  if (rtb_EPS_LKA_Control >= ((UInt8)((uint8)2U))) {
    rtb_L0_Q_ku = ((uint8)3U);
  } else {
    rtb_L0_Q_ku = (uint8)rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S55>/Switch' */

  /* DataTypeConversion: '<S50>/Cast To Single77' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1'
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   */
  rtb_L0_Type_l = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type();

  /* DataTypeConversion: '<S50>/Cast To Single62' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_LC_1'
   *  Inport: '<Root>/IMAPve_d_L1_LC'
   */
  rtb_L1_LC = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_LC_IMAPve_d_L1_LC();

  /* DataTypeConversion: '<S50>/Cast To Single58' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1'
   *  Inport: '<Root>/IMAPve_d_L1_Q'
   */
  rtb_L1_Q_p = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q();

  /* DataTypeConversion: '<S50>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   */
  rtb_L1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LDW_Warn_Mode'
   */
  rtb_IMAPve_d_LDW_Warn_Mode = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode();

  /* DataTypeConversion: '<S1>/IMAPve_d_Lane_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Lane_Valid'
   */
  rtb_IMAPve_d_Lane_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Lane_Valid_IMAPve_d_Lane_Valid();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_AutoPilot_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_AutoPilot_Switch'
   */
  rtb_IMAPve_d_MP5_AutoPilot_Swit = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_AutoPilot_Switch_IMAPve_d_MP5_AutoPilot_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_Work_State'
   */
  rtb_IMAPve_d_MP5_Work_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State
    ();

  /* DataTypeConversion: '<S50>/Cast To Single29' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_LC_1'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_LC'
   */
  rtb_L1_LC_p = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L1_LC_IMAPve_d_ORI_L1_LC();

  /* DataTypeConversion: '<S50>/Cast To Single26' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_Type'
   */
  rtb_L1_Type_m = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_L1_Type_IMAPve_d_ORI_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_ConsArea_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_Lane_ConsArea'
   */
  rtb_IMAPve_d_ORI_Lane_ConsArea = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_Lane_ConsArea_IMAPve_d_ORI_Lane_ConsArea
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_RoadType_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_Lane_RoadType'
   */
  rtb_IMAPve_d_ORI_Lane_RoadType = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_Lane_RoadType_IMAPve_d_ORI_Lane_RoadType
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_Valid_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_ORI_Lane_Valid'
   */
  rtb_IMAPve_d_ORI_Lane_Valid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_Lane_Valid_IMAPve_d_ORI_Lane_Valid
    ();

  /* DataTypeConversion: '<S50>/Cast To Single39' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_LC_1'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_LC'
   */
  rtb_R1_LC = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R1_LC_IMAPve_d_ORI_R1_LC();

  /* DataTypeConversion: '<S50>/Cast To Single36' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_LT_1'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_LT'
   */
  rtb_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ORI_R1_LT_IMAPve_d_ORI_R1_LT();

  /* DataTypeConversion: '<S50>/Cast To Single51' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_LC_1'
   *  Inport: '<Root>/IMAPve_d_R0_LC'
   */
  rtb_R0_LC_j = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_LC_IMAPve_d_R0_LC();

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Q'
   */
  rtb_EPS_LKA_Control = (UInt8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q();

  /* Switch: '<S52>/Switch1' incorporates:
   *  Constant: '<S52>/Constant1'
   */
  if (rtb_EPS_LKA_Control >= ((UInt8)((uint8)2U))) {
    rtb_R0_Q_j = ((uint8)3U);
  } else {
    rtb_R0_Q_j = (uint8)rtb_EPS_LKA_Control;
  }

  /* End of Switch: '<S52>/Switch1' */

  /* DataTypeConversion: '<S50>/Cast To Single48' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1'
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   */
  rtb_R0_Type_j = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type();

  /* DataTypeConversion: '<S50>/Cast To Single73' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_LC_1'
   *  Inport: '<Root>/IMAPve_d_R1_LC'
   */
  rtb_R1_LC_a = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_LC_IMAPve_d_R1_LC();

  /* DataTypeConversion: '<S50>/Cast To Single69' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1'
   *  Inport: '<Root>/IMAPve_d_R1_Q'
   */
  rtb_R1_Q_j = (uint8)Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q();

  /* DataTypeConversion: '<S50>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   */
  rtb_R1_Type_o = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_Road_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Road_Type'
   */
  rtb_IMAPve_d_Road_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Road_Type_IMAPve_d_Road_Type();

  /* RelationalOperator: '<S14>/Compare' incorporates:
   *  Constant: '<S14>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Clb_State'
   */
  rtb_Compare_g3 = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State
                     ()) == ((uint8)0U));

  /* RelationalOperator: '<S15>/Compare' incorporates:
   *  Constant: '<S15>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Trim_State'
   */
  rtb_Compare_lf = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State
                     ()) == ((uint8)1U));

  /* Logic: '<S6>/Logical Operator6' incorporates:
   *  Constant: '<S17>/Constant'
   *  Constant: '<S18>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_SWS_Fault_Code_1'
   *  Inport: '<Root>/IMAPve_d_SWS_Failure_Status'
   *  Inport: '<Root>/IMAPve_d_SWS_Fault_Code'
   *  RelationalOperator: '<S17>/Compare'
   *  RelationalOperator: '<S18>/Compare'
   */
  rtb_Event_FaulSWS = ((((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Fault_Code_IMAPve_d_SWS_Fault_Code
    ()) != ((uint8)0U)) || (((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status
    ()) != ((uint8)1U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Sensor_Status'
   */
  rtb_IMAPve_d_Sensor_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_TCU_Available'
   */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  rtb_IMAPve_g_EMS_RealPedal = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  rtb_IMAPve_g_EPS_LKA_Current = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SteeringAngle'
   */
  rtb_IMAPve_g_EPS_SteeringAngle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  rtb_IMAPve_g_ESC_Brake_Press = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  rtb_IMAPve_g_ESC_UnYawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  rtb_IMAPve_g_ESC_YawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate();

  /* DataTypeConversion: '<S50>/Cast To Single64' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   *  UnaryMinus: '<S50>/Unary Minus'
   */
  rtb_L0_C0_lb = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0()));

  /* DataTypeConversion: '<S50>/Cast To Single61' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
   *  Inport: '<Root>/IMAPve_g_L0_C1'
   *  UnaryMinus: '<S50>/Unary Minus1'
   */
  rtb_L0_C1_n = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1()));

  /* DataTypeConversion: '<S50>/Cast To Single65' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  UnaryMinus: '<S50>/Unary Minus2'
   */
  rtb_L0_C2_k = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2()));

  /* DataTypeConversion: '<S50>/Cast To Single67' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  UnaryMinus: '<S50>/Unary Minus3'
   */
  rtb_L0_C3_d = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3()));

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_Confidence'
   */
  rtb_IMAPve_g_L0_Confidence = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_Confidence_IMAPve_g_L0_Confidence();

  /* DataTypeConversion: '<S50>/Cast To Single68' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_TLC_1'
   *  Inport: '<Root>/IMAPve_g_L0_TLC'
   */
  rtb_L0_TLC_h = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_TLC_IMAPve_g_L0_TLC();

  /* DataTypeConversion: '<S50>/Cast To Single66' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1'
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   */
  rtb_L0_VR_o = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR();

  /* DataTypeConversion: '<S50>/Cast To Single71' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_W_1'
   *  Inport: '<Root>/IMAPve_g_L0_W'
   */
  rtb_L0_W_j = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W
    ();

  /* DataTypeConversion: '<S50>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   *  UnaryMinus: '<S50>/Unary Minus8'
   */
  rtb_L1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   *  UnaryMinus: '<S50>/Unary Minus9'
   */
  rtb_L1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   *  UnaryMinus: '<S50>/Unary Minus10'
   */
  rtb_L1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   *  UnaryMinus: '<S50>/Unary Minus11'
   */
  rtb_L1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3
    ()));

  /* DataTypeConversion: '<S1>/IMAPve_g_L1_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L1_Confidence'
   */
  rtb_IMAPve_g_L1_Confidence = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_Confidence_IMAPve_g_L1_Confidence();

  /* DataTypeConversion: '<S50>/Cast To Single63' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_TLC_1'
   *  Inport: '<Root>/IMAPve_g_L1_TLC'
   */
  rtb_L1_TLC = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_TLC_IMAPve_g_L1_TLC();

  /* DataTypeConversion: '<S50>/Cast To Single78' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  rtb_L1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR();

  /* DataTypeConversion: '<S50>/Cast To Single74' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  rtb_L1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W();

  /* DataTypeConversion: '<S50>/Cast To Single11' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C0'
   */
  rtb_L1_C0_a = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C0_IMAPve_g_ORI_L1_C0();

  /* DataTypeConversion: '<S50>/Cast To Single10' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C1'
   */
  rtb_L1_C1_h = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C1_IMAPve_g_ORI_L1_C1();

  /* DataTypeConversion: '<S50>/Cast To Single12' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C2'
   */
  rtb_L1_C2_e = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C2_IMAPve_g_ORI_L1_C2();

  /* DataTypeConversion: '<S50>/Cast To Single8' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C3'
   */
  rtb_L1_C3_g = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_C3_IMAPve_g_ORI_L1_C3();

  /* DataTypeConversion: '<S50>/Cast To Single3' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_TLC_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_TLC'
   */
  rtb_L1_TLC_e = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_TLC_IMAPve_g_ORI_L1_TLC();

  /* DataTypeConversion: '<S50>/Cast To Single7' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_VR'
   */
  rtb_L1_VR_b = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_VR_IMAPve_g_ORI_L1_VR();

  /* DataTypeConversion: '<S50>/Cast To Single4' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_W'
   */
  rtb_L1_W_m = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_L1_W_IMAPve_g_ORI_L1_W();

  /* DataTypeConversion: '<S50>/Cast To Single14' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C0'
   */
  rtb_R1_C0 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C0_IMAPve_g_ORI_R1_C0();

  /* DataTypeConversion: '<S50>/Cast To Single13' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C1'
   */
  rtb_R1_C1 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C1_IMAPve_g_ORI_R1_C1();

  /* DataTypeConversion: '<S50>/Cast To Single17' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C2'
   */
  rtb_R1_C2 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C2_IMAPve_g_ORI_R1_C2();

  /* DataTypeConversion: '<S50>/Cast To Single20' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C3'
   */
  rtb_R1_C3 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_C3_IMAPve_g_ORI_R1_C3();

  /* DataTypeConversion: '<S50>/Cast To Single1' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_TLC_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_TLC'
   */
  rtb_R1_TLC = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_TLC_IMAPve_g_ORI_R1_TLC();

  /* DataTypeConversion: '<S50>/Cast To Single18' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_VR'
   */
  rtb_R1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_VR_IMAPve_g_ORI_R1_VR();

  /* DataTypeConversion: '<S50>/Cast To Single2' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_ORI_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_W'
   */
  rtb_R1_W = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ORI_R1_W_IMAPve_g_ORI_R1_W();

  /* DataTypeConversion: '<S50>/Cast To Single55' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   *  UnaryMinus: '<S50>/Unary Minus4'
   */
  rtb_R0_C0_o = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0()));

  /* DataTypeConversion: '<S50>/Cast To Single54' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
   *  Inport: '<Root>/IMAPve_g_R0_C1'
   *  UnaryMinus: '<S50>/Unary Minus5'
   */
  rtb_R0_C1_c = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1()));

  /* DataTypeConversion: '<S50>/Cast To Single56' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   *  UnaryMinus: '<S50>/Unary Minus6'
   */
  rtb_R0_C2_l = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2()));

  /* DataTypeConversion: '<S50>/Cast To Single60' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   *  UnaryMinus: '<S50>/Unary Minus7'
   */
  rtb_R0_C3_d = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3()));

  /* DataTypeConversion: '<S1>/IMAPve_g_R0_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_R0_Confidence'
   */
  rtb_IMAPve_g_R0_Confidence = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_Confidence_IMAPve_g_R0_Confidence();

  /* DataTypeConversion: '<S50>/Cast To Single72' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_TLC_1'
   *  Inport: '<Root>/IMAPve_g_R0_TLC'
   */
  rtb_R0_TLC_d = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_TLC_IMAPve_g_R0_TLC();

  /* DataTypeConversion: '<S50>/Cast To Single57' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   */
  rtb_R0_VR_g = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR();

  /* DataTypeConversion: '<S50>/Cast To Single75' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  rtb_R0_W_c = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W
    ();

  /* DataTypeConversion: '<S50>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   *  UnaryMinus: '<S50>/Unary Minus14'
   */
  rtb_R1_C0_e = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0()));

  /* DataTypeConversion: '<S50>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   *  UnaryMinus: '<S50>/Unary Minus15'
   */
  rtb_R1_C1_l = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1()));

  /* DataTypeConversion: '<S50>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   *  UnaryMinus: '<S50>/Unary Minus12'
   */
  rtb_R1_C2_h = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2()));

  /* DataTypeConversion: '<S50>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   *  UnaryMinus: '<S50>/Unary Minus13'
   */
  rtb_R1_C3_m = (float32)((T_M_Nm_Float32)
    (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3()));

  /* DataTypeConversion: '<S1>/IMAPve_g_R1_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_R1_Confidence'
   */
  rtb_IMAPve_g_R1_Confidence = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_Confidence_IMAPve_g_R1_Confidence();

  /* DataTypeConversion: '<S50>/Cast To Single41' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_TLC_1'
   *  Inport: '<Root>/IMAPve_g_R1_TLC'
   */
  rtb_R1_TLC_f = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_TLC_IMAPve_g_R1_TLC();

  /* DataTypeConversion: '<S50>/Cast To Single50' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  rtb_R1_VR_e = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR();

  /* DataTypeConversion: '<S50>/Cast To Single52' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  rtb_R1_W_d = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W
    ();

  /* Switch: '<S534>/Switch1' incorporates:
   *  Constant: '<S534>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S534>/Switch1' */

  /* Switch: '<S534>/Switch12' incorporates:
   *  Constant: '<S534>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S534>/Switch12' */

  /* Switch: '<S535>/Switch56' incorporates:
   *  Constant: '<S535>/LLSMConClb14'
   *
   * Block description for '<S535>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_i != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_i;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S535>/Switch56' */

  /* Switch: '<S535>/Switch51' incorporates:
   *  Constant: '<S535>/LLSMConClb15'
   *
   * Block description for '<S535>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_d != 0.0F) {
    rtb_LL_DvtComp_C_e = LKAS_ConstB.DataTypeConversion25_d;
  } else {
    rtb_LL_DvtComp_C_e = LL_DvtComp_C;
  }

  /* End of Switch: '<S535>/Switch51' */

  /* Switch: '<S535>/Switch46' incorporates:
   *  Constant: '<S535>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S535>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_j != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_j;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S535>/Switch46' */

  /* Update for Memory: '<S70>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Add1;

  /* Update for Memory: '<S62>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = rtb_L0_C0;

  /* Update for Memory: '<S62>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = rtb_Saturation;

  /* Update for Memory: '<S63>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_l = rtb_offset;

  /* Update for Memory: '<S63>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = rtb_Switch_dp;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S75>/Delay' */
    LKAS_DW.Delay_DSTATE = LKAS_DW.LKASM_stLKAActvFlg;

    /* Update for Memory: '<S506>/Memory' */
    LKAS_DW.Memory_PreviousInput_e = rtb_Saturation_j;

    /* Update for Memory: '<S451>/Memory' */
    LKAS_DW.Memory_PreviousInput_k = rtb_Saturation_h;

    /* Update for UnitDelay: '<S381>/Delay Input1'
     *
     * Block description for '<S381>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_b2;

    /* Update for UnitDelay: '<S379>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_b = LKAS_DW.RelationalOperator_b;

    /* Update for UnitDelay: '<S380>/Delay Input1'
     *
     * Block description for '<S380>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_a = rtb_Compare_f5;

    /* Update for Delay: '<S76>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.LKASM_stLKAState;

    /* Update for UnitDelay: '<S342>/Delay Input1'
     *
     * Block description for '<S342>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_e = rtb_Compare_md;

    /* Update for UnitDelay: '<S340>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_lt = LKAS_DW.RelationalOperator_n;

    /* Update for UnitDelay: '<S341>/Delay Input1'
     *
     * Block description for '<S341>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_n = rtb_Compare_pf;

    /* Update for Memory: '<S308>/Memory' */
    LKAS_DW.Memory_PreviousInput_i2 = LKAS_DW.RelationalOperator_n;

    /* Update for Delay: '<S76>/Delay' */
    LKAS_DW.Delay_DSTATE_l = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S76>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.LDWSM_stLDWState;

    /* Update for Memory: '<S355>/Memory' */
    LKAS_DW.Memory_PreviousInput_mz = rtb_LDW_State;

    /* Update for Memory: '<S282>/Memory' */
    LKAS_DW.Memory_PreviousInput_a = rtb_Merge1_e;

    /* Update for Memory: '<S318>/Memory' */
    LKAS_DW.Memory_PreviousInput_b = rtb_Merge1_bm;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S74>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S102>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = rtb_Saturation2;

      /* Update for Memory: '<S139>/Memory' */
      LKAS_DW.Memory_PreviousInput_e3 = rtb_Saturation1_p;

      /* Update for Memory: '<S85>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_am = rtb_Saturation1_m;

      /* Update for Memory: '<S138>/Memory' */
      LKAS_DW.Memory_PreviousInput_id = rtb_Saturation1_c;

      /* Update for Memory: '<S140>/Memory' */
      LKAS_DW.Memory_PreviousInput_bp = rtb_Saturation1_g;

      /* Update for Memory: '<S134>/Memory' */
      LKAS_DW.Memory_PreviousInput_gv = rtb_Add_iy;

      /* Update for Memory: '<S137>/Memory' */
      LKAS_DW.Memory_PreviousInput_mn = rtb_Saturation1_f;

      /* Update for Memory: '<S136>/Memory' */
      LKAS_DW.Memory_PreviousInput_ei = rtb_Saturation1_p2;

      /* Update for Memory: '<S135>/Memory' */
      LKAS_DW.Memory_PreviousInput_as = rtb_Saturation1_fd;

      /* Update for Memory: '<S112>/Memory' */
      LKAS_DW.Memory_PreviousInput_hx = rtb_Add_fh;

      /* Update for Memory: '<S103>/Memory' */
      LKAS_DW.Memory_PreviousInput_ge = rtb_Saturation2_f;

      /* Update for Memory: '<S104>/Memory' */
      LKAS_DW.Memory_PreviousInput_aj = rtb_Saturation2_k;

      /* Update for Memory: '<S101>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_b = rtb_Saturation_g;

      /* Update for Memory: '<S192>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_p = rtb_Saturation_d;

      /* Update for Memory: '<S178>/Memory' */
      LKAS_DW.Memory_PreviousInput_en = rtb_Add1_m;

      /* Update for UnitDelay: '<S176>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_g = rtb_Switch2_b;

      /* Update for Memory: '<S183>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_l = rtb_Saturation_n;

      /* Update for Memory: '<S187>/Memory' */
      LKAS_DW.Memory_PreviousInput_o = rtb_Saturation1_nn;

      /* Update for UnitDelay: '<S191>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_j = rtb_Switch_j;

      /* Update for Memory: '<S191>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_d = rtb_Saturation_oq;

      /* Update for UnitDelay: '<S171>/Delay Input2'
       *
       * Block description for '<S171>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S171>/Memory' */
      LKAS_DW.Memory_PreviousInput_c0 = rtb_Saturation2_n;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S76>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.Divide;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_L0_Q);

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_IMAPve_d_BCM_Right_Light);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single2'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)((uint8)rtb_L0_C2));

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single3'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    rtb_IMAPve_d_BCM_Left_Light);

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single4'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning
    ((UInt8)rtb_IMAPve_d_BCM_HazardLamp);

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single5'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_LKA_action_indication);

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S7>/Cast To Single6'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status
    ((UInt8)rtb_IMAPve_d_Camera_Status);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S9>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' incorporates:
   *  DataTypeConversion: '<S1>/LKASve_g_EPS_Factor_Control_1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_Abs_kj);

  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single9'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    ((UInt8)LKAS_ConstB.Permit_to_know_if_LKA_or_LP);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S355>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S85>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S190>/If' */
  LKAS_DW.If_ActiveSubsystem_g = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S70>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* InitializeConditions for Memory: '<S62>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = (-1.75F);

  /* InitializeConditions for Memory: '<S62>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = (-1.75F);

  /* InitializeConditions for Memory: '<S63>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_l = 1.75F;

  /* InitializeConditions for Memory: '<S63>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 1.75F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S75>/Delay' */
  LKAS_DW.Delay_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S506>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = 0.0F;

  /* InitializeConditions for Memory: '<S451>/Memory' */
  LKAS_DW.Memory_PreviousInput_k = 0.0F;

  /* InitializeConditions for UnitDelay: '<S381>/Delay Input1'
   *
   * Block description for '<S381>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S379>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_b = false;

  /* InitializeConditions for UnitDelay: '<S380>/Delay Input1'
   *
   * Block description for '<S380>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_a = false;

  /* InitializeConditions for Delay: '<S76>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for UnitDelay: '<S342>/Delay Input1'
   *
   * Block description for '<S342>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_e = false;

  /* InitializeConditions for UnitDelay: '<S340>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_lt = false;

  /* InitializeConditions for UnitDelay: '<S341>/Delay Input1'
   *
   * Block description for '<S341>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_n = false;

  /* InitializeConditions for Memory: '<S308>/Memory' */
  LKAS_DW.Memory_PreviousInput_i2 = false;

  /* InitializeConditions for Delay: '<S76>/Delay' */
  LKAS_DW.Delay_DSTATE_l = false;

  /* InitializeConditions for Delay: '<S76>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S355>/Memory' */
  LKAS_DW.Memory_PreviousInput_mz = ((uint8)0U);

  /* InitializeConditions for Memory: '<S282>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S318>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = 0.0F;

  /* InitializeConditions for Delay: '<S76>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S368>/Count 20s' */
  /* InitializeConditions for Memory: '<S376>/Memory' */
  LKAS_DW.Memory_PreviousInput_nq = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S368>/Count 20s' */

  /* SystemInitialize for Enabled SubSystem: '<S369>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S378>/Memory' */
  LKAS_DW.Memory_PreviousInput_n = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S369>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S379>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S385>/Memory' */
  LKAS_DW.Memory_PreviousInput_l = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S379>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S391>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S398>/Memory' */
  LKAS_DW.Memory_PreviousInput_b5 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S391>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S308>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S338>/Memory' */
  LKAS_DW.Memory_PreviousInput_bt = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S308>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S308>/Count' */
  /* InitializeConditions for Memory: '<S337>/Memory' */
  LKAS_DW.Memory_PreviousInput_nx = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S308>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S340>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S346>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S340>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S309>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S352>/Memory' */
  LKAS_DW.Memory_PreviousInput_ht = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S309>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S355>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S388>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S355>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S267>/Count_5s3' */
  /* InitializeConditions for Memory: '<S531>/Memory' */
  LKAS_DW.Memory_PreviousInput_a3 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S267>/Count_5s3' */

  /* SystemInitialize for Enabled SubSystem: '<S267>/Count_5s2' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s2);

  /* End of SystemInitialize for SubSystem: '<S267>/Count_5s2' */

  /* SystemInitialize for Enabled SubSystem: '<S267>/Count_5s1' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s1);

  /* End of SystemInitialize for SubSystem: '<S267>/Count_5s1' */

  /* SystemInitialize for Enabled SubSystem: '<S244>/Subsystem' */
  /* InitializeConditions for Memory: '<S248>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S244>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S102>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = 0.0F;

  /* InitializeConditions for Memory: '<S139>/Memory' */
  LKAS_DW.Memory_PreviousInput_e3 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S85>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_am = ((uint8)0U);

  /* InitializeConditions for Memory: '<S138>/Memory' */
  LKAS_DW.Memory_PreviousInput_id = ((uint16)0U);

  /* InitializeConditions for Memory: '<S140>/Memory' */
  LKAS_DW.Memory_PreviousInput_bp = ((uint16)0U);

  /* InitializeConditions for Memory: '<S134>/Memory' */
  LKAS_DW.Memory_PreviousInput_gv = ((uint16)0U);

  /* InitializeConditions for Memory: '<S137>/Memory' */
  LKAS_DW.Memory_PreviousInput_mn = ((uint16)0U);

  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput_ei = ((uint16)0U);

  /* InitializeConditions for Memory: '<S135>/Memory' */
  LKAS_DW.Memory_PreviousInput_as = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory' */
  LKAS_DW.Memory_PreviousInput_hx = 0.0F;

  /* InitializeConditions for Memory: '<S103>/Memory' */
  LKAS_DW.Memory_PreviousInput_ge = 0.0F;

  /* InitializeConditions for Memory: '<S104>/Memory' */
  LKAS_DW.Memory_PreviousInput_aj = 0.0F;

  /* InitializeConditions for Memory: '<S101>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_b = 0.0F;

  /* InitializeConditions for Memory: '<S192>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_p = 0.0F;

  /* InitializeConditions for Memory: '<S178>/Memory' */
  LKAS_DW.Memory_PreviousInput_en = 0.0F;

  /* InitializeConditions for UnitDelay: '<S176>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

  /* InitializeConditions for Memory: '<S183>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_l = 0.0F;

  /* InitializeConditions for Memory: '<S187>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S191>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_j = 0.0F;

  /* InitializeConditions for Memory: '<S191>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_d = 0.0F;

  /* InitializeConditions for UnitDelay: '<S171>/Delay Input2'
   *
   * Block description for '<S171>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S171>/Memory' */
  LKAS_DW.Memory_PreviousInput_c0 = ((uint16)0U);

  /* SystemInitialize for IfAction SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)'
   *
   * Block description for '<S85>/LKA Motion Planning Calculation (LKAMPCal)':
   *  Block Name: LKA Motion Planning Calculation
   *  Ab.: LKAMPCal
   *  No.: 1.2.3.2
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  LKAMotionPlanningCalculati_Init();

  /* End of SystemInitialize for SubSystem: '<S85>/LKA Motion Planning Calculation (LKAMPCal)' */

  /* SystemInitialize for Enabled SubSystem: '<S103>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S105>/Memory' */
  LKAS_DW.Memory_PreviousInput_es = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S103>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S92>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S92>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S104>/Moving Standard Deviation1' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S104>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S104>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_c);

  /* End of SystemInitialize for SubSystem: '<S104>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S104>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2_d);

  /* End of SystemInitialize for SubSystem: '<S104>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S104>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_e);

  /* End of SystemInitialize for SubSystem: '<S104>/Sum Condition' */

  /* SystemInitialize for IfAction SubSystem: '<S190>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S200>/Delay Input1'
   *
   * Block description for '<S200>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_ef = false;

  /* InitializeConditions for Memory: '<S196>/Memory' */
  LKAS_DW.Memory_PreviousInput_d5 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S190>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S190>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S208>/Delay Input1'
   *
   * Block description for '<S208>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_f = false;

  /* InitializeConditions for Memory: '<S197>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S190>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S190>/Merge' */
  LKAS_DW.Merge_f = 1.0F;

  /* SystemInitialize for Merge: '<S190>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S78>/Merge' */
  LKAS_DW.Merge_fq = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S78>/Sum Condition' */
  /* InitializeConditions for Memory: '<S82>/Memory' */
  LKAS_DW.Memory_PreviousInput_dg = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S78>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S31>/Count 10s' */
  /* InitializeConditions for Memory: '<S39>/Memory' */
  LKAS_DW.Memory_PreviousInput_im = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S31>/Count 10s' */

  /* SystemInitialize for Enabled SubSystem: '<S31>/Count 15s' */
  /* InitializeConditions for Memory: '<S40>/Memory' */
  LKAS_DW.Memory_PreviousInput_bh = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S31>/Count 15s' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
