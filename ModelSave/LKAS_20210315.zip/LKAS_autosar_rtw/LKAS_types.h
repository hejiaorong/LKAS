/*
 * File: LKAS_types.h
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.7
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Mon Mar 15 16:23:27 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#ifndef RTW_HEADER_LKAS_types_h_
#define RTW_HEADER_LKAS_types_h_
#endif                                 /* RTW_HEADER_LKAS_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
