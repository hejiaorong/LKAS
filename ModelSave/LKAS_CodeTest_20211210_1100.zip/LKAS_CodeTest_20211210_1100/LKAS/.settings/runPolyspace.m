polyspaceBugFinderNoDesktop('-options-file', 'D:\LKAS\bin\LKAS_CodeTest_20211210_1100\LKAS\.settings\options_command.txt', '-results-dir', 'D:\LKAS\bin\LKAS_CodeTest_20211210_1100\LKAS');
