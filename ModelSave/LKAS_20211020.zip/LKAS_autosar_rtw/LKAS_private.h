/*
 * File: LKAS_private.h
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.78
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Wed Oct 20 19:20:38 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#ifndef RTW_HEADER_LKAS_private_h_
#define RTW_HEADER_LKAS_private_h_
#include "rtwtypes.h"
#include "LKAS.h"
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFFFFFU) ) || ( INT_MAX != (0x7FFFFFFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFU) ) || ( LONG_MAX != (0x7FFFFFFF) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

/* Skipping ulong_long/long_long check: insufficient preprocessor integer range. */
extern void LKAS_IfActionSubsystem2(float32 *rty_Out1);
extern void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T
  *localDW);
extern void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T
  *localDW);
extern float32 LKAS_MovingStandardDeviation2(float32 rtu_In1,
  DW_MovingStandardDeviation2_L_T *localDW);
extern void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW);
extern void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW);
extern void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T
  *localDW);
extern void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32
  rtu_In1, boolean *rty_Out, DW_SumCondition_LKAS_T *localDW);
extern void LKAS_ifaction3(float32 rtu_In1, float32 *rty_Out1);
extern void LKAS_ifaction(float32 rtu_In, float32 *rty_Out);
extern void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1);
extern void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32
  rtu_InputLimLwr, float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32
  rtu_GainLimUpr, float32 *rty_Gain);
extern void LKAS_IfActionSubsystem_b(float32 rtu_In1, float32 *rty_Out1);
extern void LKAS_ifaction_p(float32 rtu_In, float32 *rty_Out);
extern void LKAS_IfActionSubsystem_m(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_i_T *localDW);
extern void LKAS_IfActionSubsystem2_f(float32 rtu_T1, float32 rtu_Plan, float32 *
  rty_T1_1, float32 *rty_Plan_1);
extern void LKAS_MATLABFunction(float32 rtu_LaneWidth, float32 rtu_LKA_CarWidth,
  float32 rtu_DvtThresUprLDW, float32 *rty_ThresDet_coefficient);
extern void LKAS_Ph1SWA(float32 *rty_Out);
extern void LKAS_Ph2SWA(float32 *rty_Out);
extern void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out);
extern void LKAS_Ph3SWA_c(float32 *rty_Out);
extern void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out);
extern void LKAS_IfActionSubsystem4(boolean *rty_Out);
extern void LKAS_IfActionSubsystem_e(boolean *rty_Out);
extern void LKAS_Count_5s1_Init(DW_Count_5s1_LKAS_T *localDW);
extern void LKAS_Count_5s1_Reset(DW_Count_5s1_LKAS_T *localDW);
extern void LKAS_Count_5s1_Disable(boolean *rty_Out, DW_Count_5s1_LKAS_T
  *localDW);
extern void LKAS_Count_5s1(boolean rtu_Enable, float32 rtu_SampleTime, boolean
  *rty_Out, DW_Count_5s1_LKAS_T *localDW);
extern void LKAMotionPlanningCalculati_Init(void);
extern void LKAMotionPlanningCalculat_Reset(void);
extern void LKAMotionPlanningCalculationLKA(void);
extern void LKAS_LDW_State_Machine_Reset(void);
extern void LKAS_LDW_State_Machine(void);
extern void LKAS_LKA_State_Machine_Reset(void);
extern void LKAS_LKA_State_Machine(void);

#endif                                 /* RTW_HEADER_LKAS_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
