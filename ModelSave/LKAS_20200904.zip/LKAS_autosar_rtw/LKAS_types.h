/*
 * File: LKAS_types.h
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.30
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Sep  4 08:59:35 2020
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_LKAS_types_h_
#define RTW_HEADER_LKAS_types_h_
#endif                                 /* RTW_HEADER_LKAS_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
