/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.55
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Mon Jul 26 11:01:06 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S75>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S75>/LKA_State_Machine' */
#define LKAS_IN_Fault_n                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_g      ((uint8)0U)
#define LKAS_IN_Normal_l               ((uint8)2U)
#define LKAS_IN_SysOff_n               ((uint8)2U)
#define LKAS_IN_SysOn_i                ((uint8)3U)
#define LKAS_IN_Unavailable_p          ((uint8)1U)
#define LKAS_IN_Unselected_c           ((uint8)2U)

/* Named constants for Chart: '<S51>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * Output and update for action system:
 *    '<S77>/If Action Subsystem2'
 *    '<S116>/if action 4'
 *    '<S117>/if action 4'
 *    '<S118>/if action 4'
 *    '<S119>/if action 4'
 *    '<S130>/If Action Subsystem3'
 *    '<S131>/If Action Subsystem3'
 *    '<S132>/If Action Subsystem3'
 *    '<S140>/If Action Subsystem3'
 *    '<S165>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S80>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S80>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/*
 * System initialize for atomic system:
 *    '<S91>/Moving Standard Deviation2'
 *    '<S103>/Moving Standard Deviation1'
 *    '<S103>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S99>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S91>/Moving Standard Deviation2'
 *    '<S103>/Moving Standard Deviation1'
 *    '<S103>/Moving Standard Deviation2'
 */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S99>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S99>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S91>/Moving Standard Deviation2'
 *    '<S103>/Moving Standard Deviation1'
 *    '<S103>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation2(float32 rtu_In1,
  DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_e;
  float32 rtb_Delay1_m;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S99>/Delay' */
  rtb_Delay_e = localDW->Delay_DSTATE;

  /* Delay: '<S99>/Delay1' */
  rtb_Delay1_m = localDW->Delay1_DSTATE;

  /* Delay: '<S99>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S99>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S99>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S99>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S99>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S99>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S99>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S99>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S99>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S99>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S99>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S99>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S99>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S99>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S99>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S99>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S99>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S99>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S99>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S99>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S99>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S99>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S99>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S99>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S99>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S99>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S99>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S99>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S99>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S99>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S99>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S99>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S99>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S99>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S99>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S99>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S99>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S99>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S99>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S99>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S99>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S99>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S99>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S99>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S99>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S99>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S99>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S99>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_e;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_m;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S99>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S99>/Standard Deviation' */

  /* Update for Delay: '<S99>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S99>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_e;

  /* Update for Delay: '<S99>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S99>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S99>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S99>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S99>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S99>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S99>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S99>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S99>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S99>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S99>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_m;

  /* Update for Delay: '<S99>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S99>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S99>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S99>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S99>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S99>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S99>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S99>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S99>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S99>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S99>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S99>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S99>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S99>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S99>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S99>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S99>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S99>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S99>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S99>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S99>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S99>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S99>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S99>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S99>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S99>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S99>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S99>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S99>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S99>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S99>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S99>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S99>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S99>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S99>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S99>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S103>/Sum Condition'
 *    '<S103>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S107>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S103>/Sum Condition'
 *    '<S103>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S107>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S103>/Sum Condition'
 *    '<S103>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S103>/Sum Condition' incorporates:
   *  EnablePort: '<S107>/Enable'
   */
  /* Disable for Outport: '<S107>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S103>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S103>/Sum Condition'
 *    '<S103>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_op;

  /* Outputs for Enabled SubSystem: '<S103>/Sum Condition' incorporates:
   *  EnablePort: '<S107>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S107>/Add1' incorporates:
     *  Memory: '<S107>/Memory'
     */
    rtb_Saturation_op = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S107>/Saturation' */
    if (rtb_Saturation_op > 100.0F) {
      rtb_Saturation_op = 100.0F;
    } else {
      if (rtb_Saturation_op < 0.0F) {
        rtb_Saturation_op = 0.0F;
      }
    }

    /* End of Saturate: '<S107>/Saturation' */

    /* RelationalOperator: '<S107>/Relational Operator' */
    *rty_Out = (rtb_Saturation_op >= rtu_In1);

    /* Update for Memory: '<S107>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_op;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S103>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S116>/if action 3'
 *    '<S117>/if action 3'
 *    '<S118>/if action 3'
 *    '<S119>/if action 3'
 *    '<S130>/If Action Subsystem2'
 *    '<S130>/If Action Subsystem1'
 *    '<S131>/If Action Subsystem2'
 *    '<S131>/If Action Subsystem1'
 *    '<S132>/If Action Subsystem2'
 *    '<S132>/If Action Subsystem1'
 *    ...
 */
void LKAS_ifaction3(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S122>/In1' */
  *rty_Out1 = rtu_In1;
}

/* System initialize for action system: '<S84>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculati_Init(void)
{
  /* InitializeConditions for Memory: '<S115>/Memory' */
  LKAS_DW.Memory_PreviousInput_he = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory' */
  LKAS_DW.Memory_PreviousInput_os = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory' */
  LKAS_DW.Memory_PreviousInput_bh = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_n = 0.0F;

  /* InitializeConditions for Memory: '<S117>/Memory' */
  LKAS_DW.Memory_PreviousInput_d2 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_fi = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_ia = 0.0F;

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_b2 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/* System reset for action system: '<S84>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculat_Reset(void)
{
  /* InitializeConditions for Memory: '<S115>/Memory' */
  LKAS_DW.Memory_PreviousInput_he = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory' */
  LKAS_DW.Memory_PreviousInput_os = ((uint16)0U);

  /* InitializeConditions for Memory: '<S116>/Memory' */
  LKAS_DW.Memory_PreviousInput_bh = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_n = 0.0F;

  /* InitializeConditions for Memory: '<S117>/Memory' */
  LKAS_DW.Memory_PreviousInput_d2 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_fi = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_ia = 0.0F;

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_b2 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S109>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/*
 * Output and update for action system: '<S84>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S84>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  /* local block i/o variables */
  float32 rtb_Memory1;
  float32 rtb_Memory2;
  float32 rtb_Memory3;
  float32 rtb_Memory4;
  float32 rtb_Merge1;
  float32 rtb_Merge1_l;
  float32 rtb_Merge1_m;
  float32 rtb_Merge1_mz;
  float32 rtb_K1K2Det_dphi2PhSWAGrad2;
  float32 rtb_K1K2Det_stReplFlag;
  float32 rtb_K1K2Det_dphi1PhHdAgIni;
  float32 DelteSW0;
  float32 u;
  float32 Kw;
  float32 StpLngth;
  float32 Mode1Num;
  float32 Mode2Num;
  float32 D2_End;
  float32 DelteSW1;
  float32 K1;
  float32 K2_2;
  float32 T2;
  sint32 a;
  float32 K2;
  float32 c_T1;
  float32 c_T2;
  float32 K1_0;
  uint16 rtb_Add;
  uint16 rtb_Add_cy;
  uint16 rtb_Add_cs;
  uint16 rtb_Add_ey;
  uint16 rtb_Add_hi;
  uint16 rtb_Merge;
  uint16 rtb_Add_f;

  /* Sum: '<S115>/Add' incorporates:
   *  Constant: '<S115>/Constant'
   *  Memory: '<S115>/Memory'
   */
  rtb_Add = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_he));

  /* Saturate: '<S115>/Saturation1' */
  if (rtb_Add < ((uint16)100U)) {
    rtb_Merge = rtb_Add;
  } else {
    rtb_Merge = ((uint16)100U);
  }

  /* End of Saturate: '<S115>/Saturation1' */

  /* If: '<S115>/If' incorporates:
   *  Constant: '<S115>/Constant19'
   *  Inport: '<S120>/In1'
   *  Memory: '<S109>/Memory'
   */
  if (rtb_Merge == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S115>/if action 2' incorporates:
     *  ActionPort: '<S121>/Action Port'
     */
    /* SignalConversion: '<S121>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
     *  Constant: '<S121>/Constant'
     */
    rtb_Merge = ((uint16)0U);

    /* End of Outputs for SubSystem: '<S115>/if action 2' */
  } else {
    /* Outputs for IfAction SubSystem: '<S115>/if action 1' incorporates:
     *  ActionPort: '<S120>/Action Port'
     */
    rtb_Merge = LKAS_DW.Memory_PreviousInput_os;

    /* End of Outputs for SubSystem: '<S115>/if action 1' */
  }

  /* End of If: '<S115>/If' */

  /* Sum: '<S116>/Add' incorporates:
   *  Constant: '<S116>/Constant'
   *  Memory: '<S116>/Memory'
   */
  rtb_Add_cy = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_bh));

  /* Memory: '<S109>/Memory1' */
  rtb_Memory1 = LKAS_DW.Memory1_PreviousInput_n;

  /* Saturate: '<S116>/Saturation1' */
  if (rtb_Add_cy < ((uint16)100U)) {
    rtb_Add_cs = rtb_Add_cy;
  } else {
    rtb_Add_cs = ((uint16)100U);
  }

  /* End of Saturate: '<S116>/Saturation1' */

  /* If: '<S116>/If' incorporates:
   *  Constant: '<S116>/Constant19'
   */
  if (rtb_Add_cs == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S116>/if action 4' incorporates:
     *  ActionPort: '<S123>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1);

    /* End of Outputs for SubSystem: '<S116>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S116>/if action 3' incorporates:
     *  ActionPort: '<S122>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory1, &rtb_Merge1);

    /* End of Outputs for SubSystem: '<S116>/if action 3' */
  }

  /* End of If: '<S116>/If' */

  /* Sum: '<S117>/Add' incorporates:
   *  Constant: '<S117>/Constant'
   *  Memory: '<S117>/Memory'
   */
  rtb_Add_cs = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_d2));

  /* Memory: '<S109>/Memory2' */
  rtb_Memory2 = LKAS_DW.Memory2_PreviousInput;

  /* Saturate: '<S117>/Saturation1' */
  if (rtb_Add_cs < ((uint16)100U)) {
    rtb_Add_ey = rtb_Add_cs;
  } else {
    rtb_Add_ey = ((uint16)100U);
  }

  /* End of Saturate: '<S117>/Saturation1' */

  /* If: '<S117>/If' incorporates:
   *  Constant: '<S117>/Constant19'
   */
  if (rtb_Add_ey == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S117>/if action 4' incorporates:
     *  ActionPort: '<S125>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_l);

    /* End of Outputs for SubSystem: '<S117>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S117>/if action 3' incorporates:
     *  ActionPort: '<S124>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory2, &rtb_Merge1_l);

    /* End of Outputs for SubSystem: '<S117>/if action 3' */
  }

  /* End of If: '<S117>/If' */

  /* Sum: '<S118>/Add' incorporates:
   *  Constant: '<S118>/Constant'
   *  Memory: '<S118>/Memory'
   */
  rtb_Add_ey = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_fi));

  /* Memory: '<S109>/Memory3' */
  rtb_Memory3 = LKAS_DW.Memory3_PreviousInput_ia;

  /* Saturate: '<S118>/Saturation1' */
  if (rtb_Add_ey < ((uint16)100U)) {
    rtb_Add_hi = rtb_Add_ey;
  } else {
    rtb_Add_hi = ((uint16)100U);
  }

  /* End of Saturate: '<S118>/Saturation1' */

  /* If: '<S118>/If' incorporates:
   *  Constant: '<S118>/Constant19'
   */
  if (rtb_Add_hi == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S118>/if action 4' incorporates:
     *  ActionPort: '<S127>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_m);

    /* End of Outputs for SubSystem: '<S118>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S118>/if action 3' incorporates:
     *  ActionPort: '<S126>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory3, &rtb_Merge1_m);

    /* End of Outputs for SubSystem: '<S118>/if action 3' */
  }

  /* End of If: '<S118>/If' */

  /* Sum: '<S119>/Add' incorporates:
   *  Constant: '<S119>/Constant'
   *  Memory: '<S119>/Memory'
   */
  rtb_Add_hi = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_b2));

  /* Memory: '<S109>/Memory4' */
  rtb_Memory4 = LKAS_DW.Memory4_PreviousInput;

  /* Saturate: '<S119>/Saturation1' */
  if (rtb_Add_hi < ((uint16)100U)) {
    rtb_Add_f = rtb_Add_hi;
  } else {
    rtb_Add_f = ((uint16)100U);
  }

  /* End of Saturate: '<S119>/Saturation1' */

  /* If: '<S119>/If' incorporates:
   *  Constant: '<S119>/Constant19'
   */
  if (rtb_Add_f == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S119>/if action 4' incorporates:
     *  ActionPort: '<S129>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_mz);

    /* End of Outputs for SubSystem: '<S119>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S119>/if action 3' incorporates:
     *  ActionPort: '<S128>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory4, &rtb_Merge1_mz);

    /* End of Outputs for SubSystem: '<S119>/if action 3' */
  }

  /* End of If: '<S119>/If' */

  /* MATLAB Function: '<S109>/MATLAB Function' */
  DelteSW0 = LKAS_DW.In_pt * 0.0174532924F;
  u = LKAS_DW.In_p / 3.6F;
  Kw = u / (((((LKAS_DW.StbFacm_SY * u) * u) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_p)
            * LKAS_DW.LKA_StrRatio_C_i);
  rtb_K1K2Det_stReplFlag = 0.0F;
  StpLngth = LKAS_DW.LL_lStpLngth_C_h * 0.0174532924F;
  Mode1Num = rtb_Merge1;
  Mode2Num = rtb_Merge1_l;
  D2_End = rtb_Merge1_m;
  DelteSW1 = rtb_Merge1_mz;
  K1 = 0.0F;
  K2 = 0.0F;
  K2_2 = 0.0F;
  if (((sint32)rtb_Merge) == 0) {
    K1 = ((-2.0F * LKAS_DW.In_nm) / ((Kw * LKAS_DW.MPInP_tiTTLCIni) *
           LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F * DelteSW0) /
      LKAS_DW.MPInP_tiTTLCIni);
    DelteSW1 = (K1 * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;
    D2_End = ((((DelteSW0 + DelteSW1) * 0.5F) * LKAS_DW.MPInP_tiTTLCIni) * Kw) +
      LKAS_DW.In_b;
    K2 = (((-DelteSW1) * DelteSW1) * Kw) / ((LKAS_DW.In_o - D2_End) * 2.0F);
    c_T1 = (DelteSW1 - DelteSW0) / K1;
    c_T2 = (0.0F - DelteSW1) / K2;
    K2_2 = K2;
    D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) * c_T1) *
                c_T1) + (LKAS_DW.In_b * c_T1)) * u) + ((((((0.333333343F * Kw) *
      c_T2) * c_T2) * DelteSW1) + (D2_End * c_T2)) * u);
  }

  c_T1 = D2_End * LKAS_DW.Merge;
  if (((0.0F < c_T1) && (c_T1 <= LKAS_DW.LL_DesDvt_C_p)) && (((sint32)rtb_Merge)
       == 0)) {
    rtb_K1K2Det_stReplFlag = 0.0F;
  } else {
    if ((c_T1 > LKAS_DW.LL_DesDvt_C_p) || (((sint32)rtb_Merge) != 0)) {
      rtb_K1K2Det_stReplFlag = 1.0F;
      for (a = 0; a < 8; a++) {
        c_T1 = D2_End * LKAS_DW.Merge;
        if ((c_T1 > LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 0)) {
          rtb_Merge = 1U;
        }

        if ((c_T1 > LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 1)) {
          DelteSW1 += LKAS_DW.Merge * StpLngth;
          Mode1Num++;
        }

        if ((c_T1 <= LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 1)) {
          rtb_Merge = 2U;
        }

        if ((c_T1 < LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 2)) {
          DelteSW1 -= (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);
          Mode2Num++;
        }

        if ((c_T1 >= LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 2)) {
          DelteSW1 += (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);
          Mode2Num++;
        }

        K1_0 = (((DelteSW1 * DelteSW1) - (DelteSW0 * DelteSW0)) * Kw) / (-2.0F *
          LKAS_DW.In_nm);
        if ((LKAS_DW.Merge * K1_0) > LKAS_DW.SWARmax) {
          K1_0 = LKAS_DW.Merge * LKAS_DW.SWARmax;
        }

        K1_0 = (DelteSW1 - DelteSW0) / K1_0;
        K1 = ((((DelteSW0 + DelteSW1) * 0.5F) * K1_0) * Kw) + LKAS_DW.In_b;
        T2 = ((LKAS_DW.In_o - K1) * 2.0F) / (DelteSW1 * Kw);
        D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) *
                     K1_0) * K1_0) + (LKAS_DW.In_b * K1_0)) * u) +
          ((((((0.333333343F * Kw) * T2) * T2) * DelteSW1) + (K1 * T2)) * u);
      }

      K1 = (DelteSW1 - DelteSW0) / K1_0;
      K2 = (0.0F - DelteSW1) / T2;
      K2_2 = K2;
    }
  }

  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = K1 * 57.2957802F;
  LKAS_DW.K1K2Det_dphi2PhSWAGrad1 = K2 * 57.2957802F;
  rtb_K1K2Det_dphi2PhSWAGrad2 = K2_2 * 57.2957802F;
  rtb_K1K2Det_dphi1PhHdAgIni = LKAS_DW.In_nm;

  /* Update for Memory: '<S115>/Memory' */
  LKAS_DW.Memory_PreviousInput_he = rtb_Add;

  /* Update for Memory: '<S109>/Memory' incorporates:
   *  MATLAB Function: '<S109>/MATLAB Function'
   */
  LKAS_DW.Memory_PreviousInput_os = rtb_Merge;

  /* Update for Memory: '<S116>/Memory' */
  LKAS_DW.Memory_PreviousInput_bh = rtb_Add_cy;

  /* Update for Memory: '<S109>/Memory1' incorporates:
   *  MATLAB Function: '<S109>/MATLAB Function'
   */
  LKAS_DW.Memory1_PreviousInput_n = Mode1Num;

  /* Update for Memory: '<S117>/Memory' */
  LKAS_DW.Memory_PreviousInput_d2 = rtb_Add_cs;

  /* Update for Memory: '<S109>/Memory2' incorporates:
   *  MATLAB Function: '<S109>/MATLAB Function'
   */
  LKAS_DW.Memory2_PreviousInput = Mode2Num;

  /* Update for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_fi = rtb_Add_ey;

  /* Update for Memory: '<S109>/Memory3' incorporates:
   *  MATLAB Function: '<S109>/MATLAB Function'
   */
  LKAS_DW.Memory3_PreviousInput_ia = D2_End;

  /* Update for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_b2 = rtb_Add_hi;

  /* Update for Memory: '<S109>/Memory4' incorporates:
   *  MATLAB Function: '<S109>/MATLAB Function'
   */
  LKAS_DW.Memory4_PreviousInput = DelteSW1;
}

/*
 * Output and update for action system:
 *    '<S133>/if action '
 *    '<S134>/if action '
 *    '<S135>/if action '
 *    '<S136>/if action '
 *    '<S137>/if action '
 *    '<S138>/if action '
 *    '<S139>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S150>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S165>/If Action Subsystem'
 *    '<S165>/If Action Subsystem4'
 *    '<S113>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S167>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S199>/if action '
 *    '<S200>/if action '
 *    '<S207>/if action '
 *    '<S208>/if action '
 */
void LKAS_ifaction_l(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S201>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S192>/If Action Subsystem'
 *    '<S193>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_h(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_i_T *localDW)
{
  uint16 rtb_Saturation1_pv;
  uint16 rtb_Saturation1_cg;

  /* Outputs for Enabled SubSystem: '<S192>/If Action Subsystem' incorporates:
   *  EnablePort: '<S197>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S199>/Add' incorporates:
     *  Constant: '<S199>/Constant'
     *  Memory: '<S199>/Memory'
     */
    rtb_Saturation1_pv = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S199>/Saturation1' */
    if (rtb_Saturation1_pv >= ((uint16)10000U)) {
      rtb_Saturation1_pv = ((uint16)10000U);
    }

    /* End of Saturate: '<S199>/Saturation1' */

    /* If: '<S199>/If' incorporates:
     *  Constant: '<S199>/Constant2'
     */
    if (rtb_Saturation1_pv <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S199>/if action ' incorporates:
       *  ActionPort: '<S201>/Action Port'
       */
      LKAS_ifaction_l(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S199>/if action ' */
    }

    /* End of If: '<S199>/If' */

    /* Sum: '<S200>/Add' incorporates:
     *  Constant: '<S200>/Constant'
     *  Memory: '<S200>/Memory'
     */
    rtb_Saturation1_cg = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_f));

    /* Saturate: '<S200>/Saturation1' */
    if (rtb_Saturation1_cg >= ((uint16)10000U)) {
      rtb_Saturation1_cg = ((uint16)10000U);
    }

    /* End of Saturate: '<S200>/Saturation1' */

    /* If: '<S200>/If' incorporates:
     *  Constant: '<S200>/Constant2'
     */
    if (rtb_Saturation1_cg == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S200>/if action ' incorporates:
       *  ActionPort: '<S202>/Action Port'
       */
      LKAS_ifaction_l(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S200>/if action ' */
    }

    /* End of If: '<S200>/If' */

    /* Update for Memory: '<S199>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_pv;

    /* Update for Memory: '<S200>/Memory' */
    localDW->Memory_PreviousInput_f = rtb_Saturation1_cg;
  }

  /* End of Outputs for SubSystem: '<S192>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S192>/If Action Subsystem2'
 *    '<S193>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_k(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S198>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S198>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S75>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_d = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_d = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c69_LKAS = 0U;
  LKAS_DW.is_c69_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.LDWSM_stLDWActvFlg = 0U;
  LKAS_DW.LDWSM_stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S75>/LDW_State_Machine'
 * Block description for: '<S75>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S75>/LDW_State_Machine'
   *
   * Block description for '<S75>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  if (((uint32)LKAS_DW.is_active_c69_LKAS) == 0U) {
    LKAS_DW.is_active_c69_LKAS = 1U;
    LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
    LKAS_DW.is_SysOff_d = LKAS_IN_Unavailable;
    LKAS_DW.LDWSM_stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c69_LKAS) {
     case LKAS_IN_Fault:
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && ((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) ==
            2))) {
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;
        LKAS_DW.is_SysOn_d = LKAS_IN_LDWSelected;
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.Divide) == 0) && tmp) {
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_d = LKAS_IN_Unselected;
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else {
        LKAS_DW.LDWSM_stLDWState = 6U;
      }
      break;

     case LKAS_IN_SysOff:
      if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
          (LKAS_DW.LKA_Fault)) {
        LKAS_DW.is_SysOff_d = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) ==
                  2)) {
        LKAS_DW.is_SysOff_d = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;
        LKAS_DW.is_SysOn_d = LKAS_IN_LDWSelected;
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_d) == LKAS_IN_Unavailable) {
        LKAS_DW.LDWSM_stLDWState = 0U;
        if (((sint32)LKAS_DW.Divide) == 0) {
          LKAS_DW.is_SysOff_d = LKAS_IN_Unselected;
          LKAS_DW.LDWSM_stLDWState = 1U;
        }
      } else {
        LKAS_DW.LDWSM_stLDWState = 1U;
      }
      break;

     default:
      if (LKAS_DW.LKA_Fault) {
        if (((uint32)LKAS_DW.is_SysOn_d) == LKAS_IN_Normal) {
          switch (LKAS_DW.is_Normal_j) {
           case LKAS_IN_LDWLeftActive:
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_d = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_d = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.Divide) != 1) && (((sint32)LKAS_DW.Divide) !=
                  2)) {
        if (((uint32)LKAS_DW.is_SysOn_d) == LKAS_IN_Normal) {
          switch (LKAS_DW.is_Normal_j) {
           case LKAS_IN_LDWLeftActive:
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_d = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_d = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_d = LKAS_IN_Unselected;
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_d) == LKAS_IN_LDWSelected) {
        LKAS_DW.LDWSM_stLDWState = 2U;
        if ((LKAS_DW.Merge_e) && (!LKAS_DW.Merge1_j)) {
          LKAS_DW.is_SysOn_d = LKAS_IN_Normal;
          LKAS_DW.is_Normal_j = LKAS_IN_LDWEnable;
          LKAS_DW.LDWSM_stLDWState = 3U;
        }
      } else if (LKAS_DW.Merge1_j) {
        switch (LKAS_DW.is_Normal_j) {
         case LKAS_IN_LDWLeftActive:
          LKAS_DW.LDWSM_stLDWActvFlg = 0U;
          LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
          break;

         case LKAS_IN_LDWRightActive:
          LKAS_DW.LDWSM_stLDWActvFlg = 0U;
          LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
          break;

         default:
          LKAS_DW.is_Normal_j = LKAS_IN_NO_ACTIVE_CHILD;
          break;
        }

        LKAS_DW.is_SysOn_d = LKAS_IN_LDWSelected;
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else {
        switch (LKAS_DW.is_Normal_j) {
         case LKAS_IN_LDWEnable:
          LKAS_DW.LDWSM_stLDWState = 3U;
          if ((((sint32)LKAS_DW.Merge_p) == 1) && (!LKAS_DW.Merge_f)) {
            LKAS_DW.is_Normal_j = LKAS_IN_LDWLeftActive;
            LKAS_DW.LDWSM_stLDWState = 4U;
            LKAS_DW.LDWSM_stLDWActvFlg = 1U;
          } else {
            if ((((sint32)LKAS_DW.Merge_p) == 2) && (!LKAS_DW.Merge_f)) {
              LKAS_DW.is_Normal_j = LKAS_IN_LDWRightActive;
              LKAS_DW.LDWSM_stLDWState = 5U;
              LKAS_DW.LDWSM_stLDWActvFlg = 2U;
            }
          }
          break;

         case LKAS_IN_LDWLeftActive:
          LKAS_DW.LDWSM_stLDWState = 4U;
          if (LKAS_DW.Merge_f) {
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_LDWEnable;
            LKAS_DW.LDWSM_stLDWState = 3U;
          } else {
            if ((((sint32)LKAS_DW.Merge_p) == 2) && (!LKAS_DW.Merge_f)) {
              LKAS_DW.is_Normal_j = LKAS_IN_LDWRightActive;
              LKAS_DW.LDWSM_stLDWState = 5U;
              LKAS_DW.LDWSM_stLDWActvFlg = 2U;
            }
          }
          break;

         default:
          LKAS_DW.LDWSM_stLDWState = 5U;
          if (LKAS_DW.Merge_f) {
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_j = LKAS_IN_LDWEnable;
            LKAS_DW.LDWSM_stLDWState = 3U;
          } else {
            if ((((sint32)LKAS_DW.Merge_p) == 1) && (!LKAS_DW.Merge_f)) {
              LKAS_DW.is_Normal_j = LKAS_IN_LDWLeftActive;
              LKAS_DW.LDWSM_stLDWState = 4U;
              LKAS_DW.LDWSM_stLDWActvFlg = 1U;
            }
          }
          break;
        }
      }
      break;
    }
  }

  /* End of Chart: '<S75>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S75>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.is_active_c70_LKAS = 0U;
  LKAS_DW.is_c70_LKAS = LKAS_IN_NO_ACTIVE_CHILD_g;
  LKAS_DW.LKASM_stLKAActvFlg = 0U;
  LKAS_DW.LKASM_stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S75>/LKA_State_Machine'
 * Block description for: '<S75>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S75>/LKA_State_Machine'
   *
   * Block description for '<S75>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  if (((uint32)LKAS_DW.is_active_c70_LKAS) == 0U) {
    LKAS_DW.is_active_c70_LKAS = 1U;
    LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_n;
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_p;
    LKAS_DW.LKASM_stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c70_LKAS) {
     case LKAS_IN_Fault_n:
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.Divide) == 2)) {
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOn_i;
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.Divide) == 0) || (((sint32)LKAS_DW.Divide) ==
        1)) && tmp) {
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_n;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_c;
        LKAS_DW.LKASM_stLKAState = 1U;
      } else {
        LKAS_DW.LKASM_stLKAState = 6U;
      }
      break;

     case LKAS_IN_SysOff_n:
      if ((((sint32)LKAS_DW.Divide) == 2) && (LKAS_DW.LKA_Fault)) {
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_g;
        LKAS_DW.is_c70_LKAS = LKAS_IN_Fault_n;
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.Divide) == 2) {
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_g;
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOn_i;
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_p) {
        LKAS_DW.LKASM_stLKAState = 0U;
        if ((((sint32)LKAS_DW.Divide) == 0) || (((sint32)LKAS_DW.Divide) == 1))
        {
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_c;
          LKAS_DW.LKASM_stLKAState = 1U;
        }
      } else {
        LKAS_DW.LKASM_stLKAState = 1U;
      }
      break;

     default:
      if (LKAS_DW.LKA_Fault) {
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_l) {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
            break;

           case LKAS_IN_LKARightActive:
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
        }

        LKAS_DW.is_c70_LKAS = LKAS_IN_Fault_n;
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.Divide) != 2) {
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_l) {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
            break;

           case LKAS_IN_LKARightActive:
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_g;
        }

        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_n;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_c;
        LKAS_DW.LKASM_stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.LKASM_stLKAState = 2U;
        if ((LKAS_DW.Merge1_o) && (!LKAS_DW.Merge2_m)) {
          LKAS_DW.is_SysOn = LKAS_IN_Normal_l;
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;
          LKAS_DW.LKASM_stLKAState = 3U;
        }
      } else if (LKAS_DW.Merge2_m) {
        switch (LKAS_DW.is_Normal) {
         case LKAS_IN_LKALeftActive:
          LKAS_DW.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
          break;

         case LKAS_IN_LKARightActive:
          LKAS_DW.LKASM_stLKAActvFlg = 0U;
          LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
          break;

         default:
          LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_g;
          break;
        }

        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;
        LKAS_DW.LKASM_stLKAState = 2U;
      } else {
        switch (LKAS_DW.is_Normal) {
         case LKAS_IN_LKAEnable:
          LKAS_DW.LKASM_stLKAState = 3U;
          if ((((sint32)LKAS_DW.Merge2) == 1) && (!LKAS_DW.Merge1_b)) {
            LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;
            LKAS_DW.LKASM_stLKAState = 4U;
            LKAS_DW.LKASM_stLKAActvFlg = 1U;
          } else {
            if ((((sint32)LKAS_DW.Merge2) == 2) && (!LKAS_DW.Merge1_b)) {
              LKAS_DW.is_Normal = LKAS_IN_LKARightActive;
              LKAS_DW.LKASM_stLKAState = 5U;
              LKAS_DW.LKASM_stLKAActvFlg = 2U;
            }
          }
          break;

         case LKAS_IN_LKALeftActive:
          LKAS_DW.LKASM_stLKAState = 4U;
          if (LKAS_DW.Merge1_b) {
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_LKAEnable;
            LKAS_DW.LKASM_stLKAState = 3U;
          } else {
            if ((((sint32)LKAS_DW.Merge2) == 2) && (!LKAS_DW.Merge1_b)) {
              LKAS_DW.is_Normal = LKAS_IN_LKARightActive;
              LKAS_DW.LKASM_stLKAState = 5U;
              LKAS_DW.LKASM_stLKAActvFlg = 2U;
            }
          }
          break;

         default:
          LKAS_DW.LKASM_stLKAState = 5U;
          if (LKAS_DW.Merge1_b) {
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_LKAEnable;
            LKAS_DW.LKASM_stLKAState = 3U;
          } else {
            if ((((sint32)LKAS_DW.Merge2) == 1) && (!LKAS_DW.Merge1_b)) {
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;
              LKAS_DW.LKASM_stLKAState = 4U;
              LKAS_DW.LKASM_stLKAActvFlg = 1U;
            }
          }
          break;
        }
      }
      break;
    }
  }

  /* End of Chart: '<S75>/LKA_State_Machine' */
}

/*
 * Output and update for atomic system:
 *    '<S274>/MATLAB Function'
 *    '<S310>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_LaneWidth, float32 rtu_LKA_CarWidth,
  float32 rtu_DvtThresUprLDW, float32 *rty_ThresDet_coefficient)
{
  *rty_ThresDet_coefficient = fminf(fmaxf(0.0F, (fminf(fmaxf(2.4F, rtu_LaneWidth),
    3.6F) - ((2.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth)) / (4.0F *
    rtu_DvtThresUprLDW)), 1.0F);
}

/*
 * Output and update for action system:
 *    '<S278>/Ph1SWA'
 *    '<S287>/Ph1SWA'
 *    '<S314>/Ph1SWA'
 *    '<S323>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S282>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S282>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S278>/Ph2SWA'
 *    '<S287>/Ph2SWA'
 *    '<S314>/Ph2SWA'
 *    '<S323>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S283>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S283>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S278>/Ph3SWA'
 *    '<S314>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S284>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S287>/Ph3SWA'
 *    '<S323>/Ph3SWA'
 */
void LKAS_Ph3SWA_k(float32 *rty_Out)
{
  /* SignalConversion: '<S293>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S293>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S336>/If Action Subsystem3'
 *    '<S375>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S341>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S349>/If Action Subsystem4'
 *    '<S349>/If Action Subsystem3'
 *    '<S458>/If Action Subsystem3'
 *    '<S458>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S361>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S361>/Constant'
   */
  *rty_Out = false;
}

/*
 * Output and update for action system:
 *    '<S387>/If Action Subsystem'
 *    '<S387>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_m(boolean *rty_Out)
{
  /* SignalConversion: '<S391>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S391>/Constant'
   */
  *rty_Out = true;
}

/*
 * Output and update for atomic system:
 *    '<S448>/MATLAB Function'
 *    '<S503>/MATLAB Function'
 */
void LKAS_MATLABFunction_i(uint8 rtu_u, boolean *rty_y)
{
  *rty_y = (((((((((sint32)rtu_u) == 1) || (((sint32)rtu_u) == 2)) || (((sint32)
    rtu_u) == 3)) || (((sint32)rtu_u) == 4)) || (((sint32)rtu_u) == 5)) ||
             (((sint32)rtu_u) == 6)) || (((sint32)rtu_u) == 7));
}

/*
 * System initialize for enable system:
 *    '<S263>/Count_5s1'
 *    '<S263>/Count_5s2'
 */
void LKAS_Count_5s1_Init(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S525>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S263>/Count_5s1'
 *    '<S263>/Count_5s2'
 */
void LKAS_Count_5s1_Reset(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S525>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S263>/Count_5s1'
 *    '<S263>/Count_5s2'
 */
void LKAS_Count_5s1_Disable(boolean *rty_Out, DW_Count_5s1_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S263>/Count_5s1' incorporates:
   *  EnablePort: '<S525>/Enable'
   */
  /* Disable for Outport: '<S525>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S263>/Count_5s1' */
  localDW->Count_5s1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S263>/Count_5s1'
 *    '<S263>/Count_5s2'
 */
void LKAS_Count_5s1(boolean rtu_Enable, float32 rtu_SampleTime, boolean *rty_Out,
                    DW_Count_5s1_LKAS_T *localDW)
{
  float32 rtb_Saturation_by;

  /* Outputs for Enabled SubSystem: '<S263>/Count_5s1' incorporates:
   *  EnablePort: '<S525>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Reset(localDW);
      localDW->Count_5s1_MODE = true;
    }

    /* Sum: '<S525>/Add' incorporates:
     *  Memory: '<S525>/Memory'
     */
    rtb_Saturation_by = localDW->Memory_PreviousInput + rtu_SampleTime;

    /* Saturate: '<S525>/Saturation' */
    if (rtb_Saturation_by > 11.0F) {
      rtb_Saturation_by = 11.0F;
    } else {
      if (rtb_Saturation_by < 0.0F) {
        rtb_Saturation_by = 0.0F;
      }
    }

    /* End of Saturate: '<S525>/Saturation' */

    /* RelationalOperator: '<S525>/Relational Operator' incorporates:
     *  Constant: '<S525>/Constant1'
     */
    *rty_Out = (rtb_Saturation_by >= ((float32)((uint16)5U)));

    /* Update for Memory: '<S525>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_by;
  } else {
    if (localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S263>/Count_5s1' */
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_IMAPve_g_ESC_VehSpd;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_Gain_e;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_Gain_a;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_R0_VR_l;
  float32 rtb_L0_VR_l;
  float32 rtb_R0_W_h;
  float32 rtb_L0_W_b;
  float32 rtb_R0_TLC_a;
  float32 rtb_L0_TLC_k;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_L1_TLC;
  float32 rtb_R1_VR;
  float32 rtb_R1_W;
  float32 rtb_R1_TLC;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_EPS_SteeringAngle;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_IMAPve_g_L0_Confidence;
  float32 rtb_IMAPve_g_L1_Confidence;
  float32 rtb_IMAPve_g_R0_Confidence;
  float32 rtb_IMAPve_g_R1_Confidence;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_b;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1;
  float32 rtb_Add5_h;
  float32 rtb_Add_d;
  float32 rtb_Add_h;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge_p;
  float32 rtb_Switch_h;
  float32 rtb_Saturation_g;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Add1_g;
  float32 rtb_Switch_e;
  float32 rtb_Switch2_k;
  float32 rtb_Switch_b1;
  float32 rtb_Saturation_l;
  float32 rtb_Abs1_o;
  float32 rtb_Abs_g;
  float32 rtb_UnaryMinus_c;
  float32 rtb_Merge1_e;
  float32 rtb_Divide_jr;
  float32 rtb_Switch_g;
  float32 rtb_Switch2_d;
  float32 rtb_Divide_c;
  float32 rtb_Switch_l;
  float32 rtb_Switch2_o;
  float32 rtb_Merge1_e3;
  float32 rtb_Divide_i;
  float32 rtb_Switch_i1;
  float32 rtb_Switch2_e;
  float32 rtb_Divide_b;
  float32 rtb_Switch_j;
  float32 rtb_Switch2_ex;
  float32 rtb_Add1_f;
  float32 rtb_Switch_a3;
  float32 rtb_Switch2_n;
  float32 rtb_Memory_m;
  float32 rtb_Merge1_j;
  float32 rtb_Divide_p;
  float32 rtb_Switch_bb;
  float32 rtb_Switch2_kb;
  float32 rtb_Divide_jg;
  float32 rtb_Switch_m;
  float32 rtb_Switch2_nt;
  float32 rtb_Memory_i;
  float32 rtb_Merge1_a;
  float32 rtb_Divide_nw;
  float32 rtb_Switch_n;
  float32 rtb_Switch2_g;
  float32 rtb_Divide_d;
  float32 rtb_Switch_af;
  float32 rtb_Switch2_p;
  float32 rtb_phiHdAg;
  float32 rtb_Add_em;
  float32 rtb_Add_fq;
  float32 rtb_Add_oy;
  float32 rtb_Add_jt;
  float32 rtb_LKA_ExitFlg_Mon;
  float32 rtb_LKA_SampleTime_Mon;
  float32 rtb_T1_Mon;
  float32 rtb_RGTTTLC_Mon;
  float32 rtb_LFTTTLC_Mon;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_ThresDet_coefficient;
  float32 rtb_ThresDet_coefficient_f;
  float32 rtb_Saturation2;
  float32 rtb_Merge_m;
  float32 rtb_Abs1_oh;
  float32 rtb_Abs_o;
  float32 rtb_Add1_e;
  float32 rtb_Merge_px;
  float32 rtb_Merge_k;
  float32 rtb_Merge_o;
  float32 rtb_Add_l3;
  float32 rtb_Saturation6;
  float32 rtb_Saturation2_l;
  float32 rtb_Saturation2_e;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_ka;
  float32 rtb_Saturation_kz;
  float32 rtb_Add1_m;
  float32 rtb_Saturation_h;
  float32 rtb_Switch2_gw;
  float32 rtb_Switch_p;
  float32 rtb_Switch2_f;
  float32 rtb_Divide7;
  float32 rtb_Switch_e1;
  float32 rtb_Switch2_h;
  float32 rtb_Saturation_hf;
  float32 rtb_Switch_gi;
  float32 rtb_Add_j1;
  float32 rtb_Switch_er;
  float32 rtb_Switch2_nw;
  float32 rtb_UkYk1_e;
  float32 rtb_Switch_ap;
  float32 rtb_Switch2_c;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_p1;
  float32 rtb_Saturation_ph;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_T2;
  float32 rtb_Plan;
  float32 rtb_T1_n;
  float32 rtb_Plan_l;
  float32 rtb_T1_f;
  float32 rtb_Yk1_o;
  float32 rtb_deltafalllimit_j;
  float32 rtb_Saturation4;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_b;
  uint16 rtb_Saturation1_ja;
  uint16 rtb_Saturation1_a;
  uint16 rtb_Add_ba;
  uint16 rtb_Saturation1_p;
  uint16 rtb_Saturation1_af;
  uint16 rtb_Saturation1_eh;
  uint16 rtb_Saturation1_kk;
  uint16 rtb_Saturation2_a;
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_o;
  uint8 rtb_L0_Type_c;
  uint8 rtb_R0_LC_n;
  uint8 rtb_L0_LC_n;
  uint8 rtb_L1_Type;
  uint8 rtb_L1_LC;
  uint8 rtb_R1_Type;
  uint8 rtb_R1_LC;
  uint8 rtb_IMAPve_d_BCM_LeftTurn_Switc;
  uint8 rtb_IMAPve_d_BCM_RightTurn_Swit;
  uint8 rtb_IMAPve_d_Camera_Signal_Faul;
  uint8 rtb_IMAPve_d_ConsArea;
  uint8 rtb_IMAPve_d_EPS_Driver_Active_;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_IMAPve_d_LDW_Warn_Mode;
  uint8 rtb_IMAPve_d_Lane_Valid;
  uint8 rtb_IMAPve_d_MP5_AutoPilot_Swit;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_IMAPve_d_ORI_Lane_ConsArea;
  uint8 rtb_IMAPve_d_ORI_Lane_RoadType;
  uint8 rtb_IMAPve_d_ORI_Lane_Valid;
  uint8 rtb_IMAPve_d_Road_Type;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_LDW_State;
  uint8 rtb_LKA_State_Mon;
  uint8 rtb_LDW_State_Mon;
  uint8 rtb_DACMode;
  uint8 rtb_Saturation1_h;
  uint8 rtb_y;
  boolean rtb_Compare_l;
  boolean rtb_Compare_a;
  boolean rtb_Event_FaulETATDA;
  boolean rtb_Compare_on;
  boolean rtb_Compare_eq;
  boolean rtb_Compare_l2;
  boolean rtb_Compare_h;
  boolean rtb_Compare_c;
  boolean rtb_Compare_fk;
  boolean rtb_Compare_a4;
  boolean rtb_Compare_g2;
  boolean rtb_Event_FaulSWS;
  boolean rtb_Compare_n;
  boolean rtb_UnitDelay_e4;
  boolean rtb_Compare_cmd;
  boolean rtb_Merge_e;
  boolean rtb_Merge_l;
  boolean rtb_Compare_fc;
  boolean rtb_UnitDelay_om;
  boolean rtb_Compare_lp;
  boolean rtb_Merge_o4;
  boolean rtb_Compare_a2;
  boolean rtb_Compare_mi;
  boolean rtb_LogicalOperator1_e;
  boolean rtb_Compare_fo;
  boolean rtb_Compare_n3;
  boolean rtb_y_o;
  boolean rtb_RelationalOperator6_m;
  boolean rtb_RelationalOperator5;
  boolean rtb_LogicalOperator3_l;
  float32 x10;
  float32 x20;
  float32 x1;
  UInt16 tmpRead;
  UInt16 tmpRead_0;
  UInt16 tmpRead_1;
  UInt16 tmpRead_2;
  UInt16 tmpRead_3;
  UInt16 tmpRead_4;
  UInt16 tmpRead_5;
  UInt16 tmpRead_6;
  UInt16 tmpRead_7;
  UInt16 tmpRead_8;
  UInt16 tmpRead_9;
  UInt16 tmpRead_a;
  UInt16 tmpRead_b;
  UInt16 tmpRead_c;
  UInt16 tmpRead_d;
  UInt16 tmpRead_e;
  UInt16 tmpRead_f;
  UInt16 tmpRead_g;
  UInt16 tmpRead_h;
  UInt16 tmpRead_i;
  UInt16 tmpRead_j;
  UInt16 tmpRead_k;
  UInt16 tmpRead_l;
  UInt16 tmpRead_m;
  UInt16 tmpRead_n;
  UInt16 tmpRead_o;
  UInt16 tmpRead_p;
  UInt16 tmpRead_q;
  UInt16 tmpRead_r;
  UInt16 tmpRead_s;
  UInt16 tmpRead_t;
  UInt16 tmpRead_u;
  UInt16 tmpRead_v;
  UInt16 tmpRead_w;
  UInt16 tmpRead_x;
  UInt16 tmpRead_y;
  UInt16 tmpRead_z;
  UInt16 tmpRead_10;
  UInt16 tmpRead_11;
  UInt16 tmpRead_12;
  UInt16 tmpRead_13;
  UInt16 tmpRead_14;
  UInt16 tmpRead_15;
  UInt16 tmpRead_16;
  UInt16 tmpRead_17;
  UInt16 tmpRead_18;
  UInt16 tmpRead_19;
  UInt16 tmpRead_1a;
  UInt16 tmpRead_1b;
  T_M_Nm_Float32 tmpRead_1c;
  T_M_Nm_Float32 tmpRead_1d;
  T_M_Nm_Float32 tmpRead_1e;
  T_M_Nm_Float32 tmpRead_1f;
  T_M_Nm_Float32 tmpRead_1g;
  T_M_Nm_Float32 tmpRead_1h;
  T_M_Nm_Float32 tmpRead_1i;
  T_M_Nm_Float32 tmpRead_1j;
  UInt16 tmpRead_1k;
  uint8 rtb_IMAPve_d_BCM_HazardLamp;
  uint8 rtb_IMAPve_d_BCM_Left_Light;
  uint8 rtb_IMAPve_d_BCM_Right_Light;
  uint8 rtb_IMAPve_d_Camera_Status;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  float32 rtb_L0_C2;
  float32 rtb_R0_C2;
  float32 rtb_L0_C0;
  float32 rtb_R0_C0;
  float32 rtb_Add1;
  float32 rtb_Saturation_mg;
  uint8 rtb_R0_Type;
  uint8 rtb_IMAPve_d_TCU_Actual_Gear;
  float32 rtb_Switch_a4;
  uint8 rtb_L0_Q;
  uint8 rtb_R0_Q;
  float32 rtb_L0_C0_mb;
  float32 rtb_L0_C1;
  float32 rtb_R0_C1;
  float32 rtb_L0_C1_k;
  float32 rtb_L0_C2_h4;
  float32 rtb_L0_C3;
  float32 rtb_R0_C3;
  float32 rtb_L0_C3_e1;
  float32 rtb_R0_C0_c;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LFClb_TFC_facmGainLutGai;
  float32 rtb_LL_LKASWASyn_TrqSwaAddSwt;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_TTLC_pk;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_h;
  boolean rtb_LogicalOperator3_i;
  boolean rtb_LogicalOperator_lm;
  boolean rtb_Compare_k1;
  boolean rtb_LogicalOperator_nr;
  boolean rtb_LogicalOperator_ji;
  boolean rtb_Compare_ok;
  boolean rtb_LogicalOperator_iv;
  boolean rtb_Compare_bg;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_ge2;
  boolean rtb_LogicalOperator_ij;
  boolean rtb_LogicalOperator_j1;
  float32 rtb_Saturation5;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge;
  boolean rtb_Compare_mt;
  boolean rtb_Compare_jo;
  boolean rtb_Compare_pf;
  float32 rtb_R0_VR;
  float32 rtb_L0_VR;
  float32 rtb_R0_W;
  float32 rtb_L0_W;
  float32 rtb_R0_TLC;
  float32 rtb_L0_TLC;
  float32 rtb_offset;
  float32 rtb_Saturation_eo;
  uint16 rtb_Saturation_j;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  uint8 rtb_L0_Q_a;
  float32 rtb_TTLC;
  float32 rtb_TLft;
  float32 tmp;
  sint32 rtb_IMAPve_d_BCM_Left_Light_0;
  float32 rtb_LKA_Veh2CamL_C_tmp;
  float32 rtb_Add5_h_tmp;
  float32 rtb_LogicalOperator3_f_tmp;
  float32 rtb_Add_d_tmp;
  float32 rtb_Add_h_tmp;
  boolean exitg1;

  /* Inport: '<Root>/IMAPve_d_Camera_Status' */
  Rte_Read_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status(&rtb_Saturation_j);

  /* Inport: '<Root>/IMAPve_d_BCM_Right_Light' */
  Rte_Read_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light(&tmpRead_e);

  /* Inport: '<Root>/IMAPve_d_BCM_Left_Light' */
  Rte_Read_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light(&tmpRead_d);

  /* Inport: '<Root>/IMAPve_d_BCM_HazardLamp' */
  Rte_Read_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp(&tmpRead_c);

  /* Inport: '<Root>/IMAPve_g_SW_Angle_Speed' */
  Rte_Read_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed(&rtb_Saturation_eo);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  Rte_Read_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle(&rtb_IMAPve_g_SW_Angle);

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  Rte_Read_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc(&rtb_IMAPve_g_ESC_LonAcc);

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  Rte_Read_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd(&rtb_IMAPve_g_ESC_VehSpd);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_g_ESC_LatAcc' */
  Rte_Read_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc(&rtb_Saturation5);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  Rte_Read_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq(&rtb_IMAPve_g_EPS_SW_Trq);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_EPS_LKA_State' */
  Rte_Read_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State(&tmpRead_2);

  /* Inport: '<Root>/IMAPve_d_LKA_Mode' */
  Rte_Read_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode(&tmpRead_0);

  /* Inport: '<Root>/IMAPve_d_LKA_Main_Switch' */
  Rte_Read_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch(&tmpRead);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' */
  rtb_IMAPve_d_BCM_HazardLamp = (uint8)tmpRead_c;

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1' */
  rtb_IMAPve_d_BCM_Left_Light = (uint8)tmpRead_d;

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1' */
  rtb_IMAPve_d_BCM_Right_Light = (uint8)tmpRead_e;

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1' */
  rtb_IMAPve_d_Camera_Status = (uint8)rtb_Saturation_j;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)tmpRead_2;

  /* Product: '<S46>/Divide' incorporates:
   *  Constant: '<S46>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1'
   *  Sum: '<S46>/Add'
   */
  LKAS_DW.Divide = (uint8)(((uint32)((uint8)(((uint32)((uint8)tmpRead_0)) +
    ((uint32)((uint8)1U))))) * ((uint32)((uint8)tmpRead)));

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  Inport: '<Root>/IMAPve_d_L0_Q'
   *  Inport: '<Root>/IMAPve_d_ORI_L0_Q'
   *  Inport: '<Root>/IMAPve_d_ORI_R0_Q'
   *  Inport: '<Root>/IMAPve_d_R0_Q'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_d_L0_Q_IMAPve_d_L0_Q(&tmpRead_v);

    /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L0_Q'
     */
    rtb_L0_Q_a = (uint8)tmpRead_v;

    /* Switch: '<S55>/Switch' incorporates:
     *  Constant: '<S55>/Constant'
     */
    if (rtb_L0_Q_a >= ((uint8)1U)) {
      rtb_L0_Q = ((uint8)3U);
    } else {
      rtb_L0_Q = rtb_L0_Q_a;
    }

    /* End of Switch: '<S55>/Switch' */
    Rte_Read_IMAPve_d_R0_Q_IMAPve_d_R0_Q(&tmpRead_11);

    /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R0_Q'
     */
    rtb_L0_Q_a = (uint8)tmpRead_11;

    /* Switch: '<S52>/Switch1' incorporates:
     *  Constant: '<S52>/Constant1'
     */
    if (rtb_L0_Q_a >= ((uint8)1U)) {
      rtb_R0_Q = ((uint8)3U);
    } else {
      rtb_R0_Q = rtb_L0_Q_a;
    }

    /* End of Switch: '<S52>/Switch1' */
  } else {
    Rte_Read_IMAPve_d_ORI_L0_Q_IMAPve_d_ORI_L0_Q(&tmpRead_v);

    /* DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_ORI_L0_Q'
     */
    rtb_L0_Q_a = (uint8)tmpRead_v;

    /* Switch: '<S54>/Switch' incorporates:
     *  Constant: '<S54>/Constant'
     */
    if (rtb_L0_Q_a >= ((uint8)1U)) {
      rtb_L0_Q = ((uint8)3U);
    } else {
      rtb_L0_Q = rtb_L0_Q_a;
    }

    /* End of Switch: '<S54>/Switch' */
    Rte_Read_IMAPve_d_ORI_R0_Q_IMAPve_d_ORI_R0_Q(&tmpRead_11);

    /* DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_ORI_R0_Q'
     */
    rtb_L0_Q_a = (uint8)tmpRead_11;

    /* Switch: '<S53>/Switch1' incorporates:
     *  Constant: '<S53>/Constant1'
     */
    if (rtb_L0_Q_a >= ((uint8)1U)) {
      rtb_R0_Q = ((uint8)3U);
    } else {
      rtb_R0_Q = rtb_L0_Q_a;
    }

    /* End of Switch: '<S53>/Switch1' */
  }

  /* Chart: '<S51>/LaneReconstructSM' */
  if (((uint32)LKAS_DW.is_active_c34_LKAS) == 0U) {
    LKAS_DW.is_active_c34_LKAS = 1U;
    LKAS_DW.is_c34_LKAS = LKAS_IN_NoLaneLost;
    LKAS_DW.LaneRSM_stLftFlg = 1U;
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c34_LKAS) {
     case LKAS_IN_DoubleLost:
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        LKAS_DW.is_c34_LKAS = LKAS_IN_NoLaneLost;
        LKAS_DW.LaneRSM_stLftFlg = 1U;
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
        LKAS_DW.is_c34_LKAS = LKAS_IN_RightLost;
        LKAS_DW.LaneRSM_stLftFlg = 1U;
        LKAS_DW.LaneRSM_stRgtFlg = 0U;
      } else {
        if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
          LKAS_DW.is_c34_LKAS = LKAS_IN_LeftLost;
          LKAS_DW.LaneRSM_stLftFlg = 0U;
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        LKAS_DW.is_c34_LKAS = LKAS_IN_NoLaneLost;
        LKAS_DW.LaneRSM_stLftFlg = 1U;
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
        LKAS_DW.is_c34_LKAS = LKAS_IN_RightLost;
        LKAS_DW.LaneRSM_stLftFlg = 1U;
        LKAS_DW.LaneRSM_stRgtFlg = 0U;
      } else {
        if (((sint32)rtb_R0_Q) < 3) {
          LKAS_DW.is_c34_LKAS = LKAS_IN_DoubleLost;
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;
      if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
        LKAS_DW.is_c34_LKAS = LKAS_IN_LeftLost;
        LKAS_DW.LaneRSM_stLftFlg = 0U;
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
        LKAS_DW.is_c34_LKAS = LKAS_IN_RightLost;
        LKAS_DW.LaneRSM_stLftFlg = 1U;
        LKAS_DW.LaneRSM_stRgtFlg = 0U;
      } else {
        if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) < 3)) {
          LKAS_DW.is_c34_LKAS = LKAS_IN_DoubleLost;
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        LKAS_DW.is_c34_LKAS = LKAS_IN_NoLaneLost;
        LKAS_DW.LaneRSM_stLftFlg = 1U;
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
        LKAS_DW.is_c34_LKAS = LKAS_IN_LeftLost;
        LKAS_DW.LaneRSM_stLftFlg = 0U;
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        if (((sint32)rtb_L0_Q) < 3) {
          LKAS_DW.is_c34_LKAS = LKAS_IN_DoubleLost;
        }
      }
      break;
    }
  }

  /* End of Chart: '<S51>/LaneReconstructSM' */

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C0'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C2'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C0'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C2'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   *  UnaryMinus: '<S50>/Unary Minus'
   *  UnaryMinus: '<S50>/Unary Minus2'
   *  UnaryMinus: '<S50>/Unary Minus4'
   *  UnaryMinus: '<S50>/Unary Minus6'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_g_L0_C0_IMAPve_g_L0_C0(&rtb_L0_C0);
    rtb_L0_C0 = -rtb_L0_C0;
    Rte_Read_IMAPve_g_L0_C2_IMAPve_g_L0_C2(&rtb_Switch_a4);
    rtb_L0_C2 = -rtb_Switch_a4;
    Rte_Read_IMAPve_g_R0_C2_IMAPve_g_R0_C2(&rtb_Add1);
    rtb_R0_C2 = -rtb_Add1;
    Rte_Read_IMAPve_g_R0_C0_IMAPve_g_R0_C0(&rtb_R0_C0);
    rtb_R0_C0 = -rtb_R0_C0;
  } else {
    Rte_Read_IMAPve_g_ORI_L0_C0_IMAPve_g_ORI_L0_C0(&rtb_L0_C0);
    Rte_Read_IMAPve_g_ORI_L0_C2_IMAPve_g_ORI_L0_C2(&rtb_L0_C2);
    Rte_Read_IMAPve_g_ORI_R0_C2_IMAPve_g_ORI_R0_C2(&rtb_R0_C2);
    Rte_Read_IMAPve_g_ORI_R0_C0_IMAPve_g_ORI_R0_C0(&rtb_R0_C0);
  }

  /* Sum: '<S70>/Add1' incorporates:
   *  Gain: '<S66>/Gain'
   *  Memory: '<S70>/Memory'
   *  Product: '<S70>/Divide'
   *  Product: '<S70>/Divide1'
   *  Sum: '<S66>/Add'
   */
  rtb_Add1 = ((((-1.0F) * rtb_L0_C0) + rtb_R0_C0) * LKAS_ConstB.Divide2) +
    (LKAS_ConstB.Add2 * LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S66>/Saturation' */
  if (rtb_Add1 > 5.5F) {
    rtb_Saturation_mg = 5.5F;
  } else if (rtb_Add1 < 2.5F) {
    rtb_Saturation_mg = 2.5F;
  } else {
    rtb_Saturation_mg = rtb_Add1;
  }

  /* End of Saturate: '<S66>/Saturation' */

  /* Abs: '<S61>/Abs' incorporates:
   *  Sum: '<S61>/Add2'
   */
  rtb_LftTTLC = fabsf(rtb_L0_C2 + rtb_R0_C2);

  /* Saturate: '<S61>/Saturation' */
  if (rtb_LftTTLC > 0.004F) {
    rtb_LftTTLC = 0.004F;
  } else {
    if (rtb_LftTTLC < 0.0F) {
      rtb_LftTTLC = 0.0F;
    }
  }

  /* End of Saturate: '<S61>/Saturation' */

  /* MATLAB Function: '<S61>/get_roadside_offset' */
  rtb_offset = fminf(0.5F, (((fminf(0.004F, rtb_LftTTLC) / 0.004F) + 1.0F) *
    0.2F) * (fminf(4.0F, rtb_Saturation_mg) - 2.0F));

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_Type_1'
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   *  Inport: '<Root>/IMAPve_d_ORI_L0_Type'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_d_L0_Type_IMAPve_d_L0_Type(&tmpRead_w);
    rtb_L0_Q_a = (uint8)tmpRead_w;
  } else {
    Rte_Read_IMAPve_d_ORI_L0_Type_IMAPve_d_ORI_L0_Type(&tmpRead_w);
    rtb_L0_Q_a = (uint8)tmpRead_w;
  }

  /* Switch: '<S61>/Switch' incorporates:
   *  Constant: '<S64>/Constant'
   *  RelationalOperator: '<S64>/Compare'
   *  Sum: '<S61>/Add'
   */
  if (rtb_L0_Q_a == ((uint8)10U)) {
    rtb_L0_C0 += rtb_offset;
  }

  /* End of Switch: '<S61>/Switch' */

  /* Switch: '<S62>/Switch' incorporates:
   *  Abs: '<S62>/Abs'
   *  Constant: '<S68>/Constant'
   *  Memory: '<S62>/Memory'
   *  Memory: '<S62>/Memory1'
   *  Product: '<S62>/Divide'
   *  Product: '<S62>/Divide1'
   *  RelationalOperator: '<S68>/Compare'
   *  Sum: '<S62>/Add1'
   *  Sum: '<S62>/Add3'
   */
  if (fabsf(rtb_L0_C0 - LKAS_DW.Memory1_PreviousInput) > 0.5F) {
    rtb_Switch_a4 = rtb_L0_C0;
  } else {
    rtb_Switch_a4 = (rtb_L0_C0 * LKAS_ConstB.Divide2_f) + (LKAS_ConstB.Add2_f *
      LKAS_DW.Memory_PreviousInput_a);
  }

  /* End of Switch: '<S62>/Switch' */

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_LT_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1'
   *  Inport: '<Root>/IMAPve_d_ORI_R0_LT'
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_d_R0_Type_IMAPve_d_R0_Type(&tmpRead_12);
    rtb_R0_Type = (uint8)tmpRead_12;
  } else {
    Rte_Read_IMAPve_d_ORI_R0_LT_IMAPve_d_ORI_R0_LT(&tmpRead_12);
    rtb_R0_Type = (uint8)tmpRead_12;
  }

  /* Switch: '<S61>/Switch1' incorporates:
   *  Constant: '<S65>/Constant'
   *  RelationalOperator: '<S65>/Compare'
   *  Sum: '<S61>/Add1'
   */
  if (rtb_R0_Type == ((uint8)10U)) {
    rtb_R0_C0 -= rtb_offset;
  }

  /* End of Switch: '<S61>/Switch1' */

  /* Switch: '<S63>/Switch' incorporates:
   *  Abs: '<S63>/Abs'
   *  Constant: '<S69>/Constant'
   *  Memory: '<S63>/Memory'
   *  Memory: '<S63>/Memory1'
   *  Product: '<S63>/Divide'
   *  Product: '<S63>/Divide1'
   *  RelationalOperator: '<S69>/Compare'
   *  Sum: '<S63>/Add1'
   *  Sum: '<S63>/Add3'
   */
  if (fabsf(rtb_R0_C0 - LKAS_DW.Memory1_PreviousInput_a) > 0.5F) {
    rtb_offset = rtb_R0_C0;
  } else {
    rtb_offset = (rtb_R0_C0 * LKAS_ConstB.Divide2_i) + (LKAS_ConstB.Add2_l *
      LKAS_DW.Memory_PreviousInput_c);
  }

  /* End of Switch: '<S63>/Switch' */

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
   *  Inport: '<Root>/IMAPve_g_L0_C1'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C1'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C1'
   *  Inport: '<Root>/IMAPve_g_R0_C1'
   *  UnaryMinus: '<S50>/Unary Minus1'
   *  UnaryMinus: '<S50>/Unary Minus5'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_g_L0_C1_IMAPve_g_L0_C1(&rtb_L0_C1);
    rtb_L0_C1 = -rtb_L0_C1;
    Rte_Read_IMAPve_g_R0_C1_IMAPve_g_R0_C1(&rtb_L0_C2_h4);
    rtb_R0_C1 = -rtb_L0_C2_h4;
  } else {
    Rte_Read_IMAPve_g_ORI_L0_C1_IMAPve_g_ORI_L0_C1(&rtb_L0_C1);
    Rte_Read_IMAPve_g_ORI_R0_C1_IMAPve_g_ORI_R0_C1(&rtb_R0_C1);
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  Gain: '<S58>/Gain'
   *  Sum: '<S58>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_mb = rtb_Switch_a4;
  } else {
    rtb_L0_C0_mb = (rtb_Saturation_mg - rtb_offset) * (-1.0F);
  }

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_C3'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_C3'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   *  UnaryMinus: '<S50>/Unary Minus3'
   *  UnaryMinus: '<S50>/Unary Minus7'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_g_L0_C3_IMAPve_g_L0_C3(&rtb_R0_C3);
    rtb_L0_C3 = -rtb_R0_C3;
    Rte_Read_IMAPve_g_R0_C3_IMAPve_g_R0_C3(&rtb_R0_C0_c);
    rtb_R0_C3 = -rtb_R0_C0_c;
  } else {
    Rte_Read_IMAPve_g_ORI_L0_C3_IMAPve_g_ORI_L0_C3(&rtb_L0_C3);
    Rte_Read_IMAPve_g_ORI_R0_C3_IMAPve_g_ORI_R0_C3(&rtb_R0_C3);
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S58>/Cast To Single1'
   *  DataTypeConversion: '<S58>/Cast To Single2'
   *  DataTypeConversion: '<S58>/Cast To Single3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C1_k = rtb_L0_C1;
    rtb_L0_C2_h4 = rtb_L0_C2;
    rtb_L0_C3_e1 = rtb_L0_C3;
  } else {
    rtb_L0_C1_k = rtb_R0_C1;
    rtb_L0_C2_h4 = rtb_R0_C2;
    rtb_L0_C3_e1 = rtb_R0_C3;
  }

  /* Switch: '<S51>/Switch' incorporates:
   *  Sum: '<S60>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_C0_c = rtb_offset;
    rtb_L0_C1 = rtb_R0_C1;
    rtb_L0_C2 = rtb_R0_C2;
    rtb_L0_C3 = rtb_R0_C3;
  } else {
    rtb_R0_C0_c = rtb_Saturation_mg + rtb_Switch_a4;
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_TCU_Actual_Gear' */
  Rte_Read_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear(&tmpRead_h);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1' */
  rtb_IMAPve_d_TCU_Actual_Gear = (uint8)tmpRead_h;

  /* MATLAB Function: '<S47>/MATLAB Function' */
  if (((((((((sint32)rtb_IMAPve_d_TCU_Actual_Gear) == 1) || (((sint32)
             rtb_IMAPve_d_TCU_Actual_Gear) == 2)) || (((sint32)
            rtb_IMAPve_d_TCU_Actual_Gear) == 3)) || (((sint32)
           rtb_IMAPve_d_TCU_Actual_Gear) == 4)) || (((sint32)
          rtb_IMAPve_d_TCU_Actual_Gear) == 5)) || (((sint32)
         rtb_IMAPve_d_TCU_Actual_Gear) == 6)) || (((sint32)
        rtb_IMAPve_d_TCU_Actual_Gear) == 7)) {
    rtb_y = 3U;
  } else {
    rtb_y = 0U;
  }

  /* End of MATLAB Function: '<S47>/MATLAB Function' */

  /* Switch: '<S543>/Switch58' incorporates:
   *  Constant: '<S543>/LLSMConClb4'
   *
   * Block description for '<S543>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S543>/Switch58' */

  /* Gain: '<S548>/Gain' incorporates:
   *  Constant: '<S548>/Constant'
   *  Sum: '<S548>/Add'
   */
  rtb_Gain_e = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S543>/Switch84' incorporates:
   *  Constant: '<S543>/LLSMConClb5'
   *
   * Block description for '<S543>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S543>/Switch84' */

  /* Switch: '<S543>/Switch85' incorporates:
   *  Constant: '<S543>/LLSMConClb6'
   *
   * Block description for '<S543>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S543>/Switch85' */

  /* Switch: '<S543>/Switch86' incorporates:
   *  Constant: '<S543>/LLSMConClb7'
   *
   * Block description for '<S543>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S543>/Switch86' */

  /* Switch: '<S543>/Switch54' incorporates:
   *  Constant: '<S543>/LLSMConClb12'
   *
   * Block description for '<S543>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S543>/Switch54' */

  /* Switch: '<S543>/Switch55' incorporates:
   *  Constant: '<S543>/LLSMConClb13'
   *
   * Block description for '<S543>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S543>/Switch55' */

  /* Switch: '<S543>/Switch52' incorporates:
   *  Constant: '<S543>/LLSMConClb16'
   *
   * Block description for '<S543>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S543>/Switch52' */

  /* Switch: '<S543>/Switch60' incorporates:
   *  Constant: '<S543>/LLSMConClb17'
   *
   * Block description for '<S543>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S543>/Switch60' */

  /* Switch: '<S543>/Switch57' incorporates:
   *  Constant: '<S543>/LLSMConClb18'
   *
   * Block description for '<S543>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S543>/Switch57' */

  /* Switch: '<S543>/Switch59' incorporates:
   *  Constant: '<S543>/LLSMConClb19'
   *
   * Block description for '<S543>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_R0_C1 = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_R0_C1 = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S543>/Switch59' */

  /* Switch: '<S543>/Switch69' incorporates:
   *  Constant: '<S543>/LLSMConClb22'
   *
   * Block description for '<S543>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S543>/Switch69' */

  /* Gain: '<S545>/Gain' incorporates:
   *  Constant: '<S545>/Constant'
   *  Sum: '<S545>/Add'
   */
  rtb_Gain_a = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S543>/Switch68' incorporates:
   *  Constant: '<S543>/LLSMConClb23'
   *
   * Block description for '<S543>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S543>/Switch68' */

  /* Switch: '<S543>/Switch70' incorporates:
   *  Constant: '<S543>/LLSMConClb24'
   *
   * Block description for '<S543>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S543>/Switch70' */

  /* Switch: '<S543>/Switch71' incorporates:
   *  Constant: '<S543>/LLSMConClb25'
   *
   * Block description for '<S543>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S543>/Switch71' */

  /* Switch: '<S543>/Switch73' incorporates:
   *  Constant: '<S543>/LLSMConClb27'
   *
   * Block description for '<S543>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S543>/Switch73' */

  /* Switch: '<S543>/Switch62' incorporates:
   *  Constant: '<S543>/LLSMConClb31'
   *
   * Block description for '<S543>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S543>/Switch62' */

  /* Switch: '<S543>/Switch66' incorporates:
   *  Constant: '<S543>/LLSMConClb35'
   *
   * Block description for '<S543>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S543>/Switch66' */

  /* Switch: '<S543>/Switch81' incorporates:
   *  Constant: '<S543>/LLSMConClb36'
   *
   * Block description for '<S543>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S543>/Switch81' */

  /* Switch: '<S543>/Switch82' incorporates:
   *  Constant: '<S543>/LLSMConClb37'
   *
   * Block description for '<S543>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S543>/Switch82' */

  /* Switch: '<S543>/Switch83' incorporates:
   *  Constant: '<S543>/LLSMConClb38'
   *
   * Block description for '<S543>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S543>/Switch83' */

  /* Switch: '<S543>/Switch75' incorporates:
   *  Constant: '<S543>/LLSMConClb39'
   *
   * Block description for '<S543>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S543>/Switch75' */

  /* Switch: '<S543>/Switch76' incorporates:
   *  Constant: '<S543>/LLSMConClb40'
   *
   * Block description for '<S543>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S543>/Switch76' */

  /* Switch: '<S543>/Switch77' incorporates:
   *  Constant: '<S543>/LLSMConClb41'
   *
   * Block description for '<S543>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S543>/Switch77' */

  /* Switch: '<S543>/Switch78' incorporates:
   *  Constant: '<S543>/LLSMConClb42'
   *
   * Block description for '<S543>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S543>/Switch78' */

  /* Switch: '<S542>/Switch3' incorporates:
   *  Constant: '<S542>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S542>/Switch3' */

  /* Switch: '<S542>/Switch10' incorporates:
   *  Constant: '<S542>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    LKAS_DW.LL_DesDvt_C_p = LKAS_ConstB.DataTypeConversion22;
  } else {
    LKAS_DW.LL_DesDvt_C_p = LL_DesDvt_C;
  }

  /* End of Switch: '<S542>/Switch10' */

  /* Switch: '<S542>/Switch15' incorporates:
   *  Constant: '<S542>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    LKAS_DW.LL_lStpLngth_C_h = LKAS_ConstB.DataTypeConversion21;
  } else {
    LKAS_DW.LL_lStpLngth_C_h = LL_lStpLngth_C;
  }

  /* End of Switch: '<S542>/Switch15' */

  /* Switch: '<S542>/Switch31' incorporates:
   *  Constant: '<S542>/LL_LFClb_TFC_vGainLutVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_k != 0.0F) {
    rtb_R0_C2 = LKAS_ConstB.DataTypeConversion14_k;
  } else {
    rtb_R0_C2 = LL_LFClb_TFC_vGainLutVehSpdLwr_C;
  }

  /* End of Switch: '<S542>/Switch31' */

  /* Switch: '<S542>/Switch34' incorporates:
   *  Constant: '<S542>/LL_LFClb_TFC_vGainLutVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_Saturation_mg = LKAS_ConstB.DataTypeConversion4;
  } else {
    rtb_Saturation_mg = LL_LFClb_TFC_vGainLutVehSpdUpr_C;
  }

  /* End of Switch: '<S542>/Switch34' */

  /* Switch: '<S542>/Switch33' incorporates:
   *  Constant: '<S542>/LL_LFClb_TFC_facmGainLutGain1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_e != 0.0F) {
    rtb_LL_LFClb_TFC_facmGainLutGai = LKAS_ConstB.DataTypeConversion7_e;
  } else {
    rtb_LL_LFClb_TFC_facmGainLutGai = LL_LFClb_TFC_facmGainLutGain1_C;
  }

  /* End of Switch: '<S542>/Switch33' */

  /* Switch: '<S542>/Switch48' incorporates:
   *  Constant: '<S542>/LL_LFClb_TFC_DiffCtrlRatio=600'
   */
  if (LKAS_ConstB.DataTypeConversion48 != 0.0F) {
    rtb_R0_C3 = LKAS_ConstB.DataTypeConversion48;
  } else {
    rtb_R0_C3 = LL_LFClb_TFC_DiffCtrlRatio;
  }

  /* End of Switch: '<S542>/Switch48' */

  /* Switch: '<S542>/Switch47' incorporates:
   *  Constant: '<S542>/LL_LKASWASyn_TrqSwaAddSwt=1'
   */
  if (LKAS_ConstB.DataTypeConversion47_e) {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LKAS_ConstB.DataTypeConversion47_e ? 1.0F :
      0.0F;
  } else {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LL_LKASWASyn_TrqSwaAddSwt ? 1.0F : 0.0F;
  }

  /* End of Switch: '<S542>/Switch47' */

  /* Switch: '<S542>/Switch11' incorporates:
   *  Constant: '<S542>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_k != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12_k;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S542>/Switch11' */

  /* Switch: '<S542>/Switch13' incorporates:
   *  Constant: '<S542>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_n != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_n;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S542>/Switch13' */

  /* Switch: '<S542>/Switch16' incorporates:
   *  Constant: '<S542>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S542>/Switch16' */

  /* Switch: '<S542>/Switch55' incorporates:
   *  Constant: '<S542>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S542>/Switch55' */

  /* Switch: '<S542>/Switch54' incorporates:
   *  Constant: '<S542>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S542>/Switch54' */

  /* Switch: '<S542>/Switch44' incorporates:
   *  Constant: '<S542>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S542>/Switch44' */

  /* Switch: '<S540>/Switch19' incorporates:
   *  Constant: '<S540>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_f != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_f;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S540>/Switch19' */

  /* Switch: '<S540>/Switch' incorporates:
   *  Constant: '<S540>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_c != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_c;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S540>/Switch' */

  /* Switch: '<S540>/Switch1' incorporates:
   *  Constant: '<S540>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_j != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_j;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S540>/Switch1' */

  /* Switch: '<S540>/Switch2' incorporates:
   *  Constant: '<S540>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_f != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_p = LKAS_ConstB.DataTypeConversion4_f;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_p = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S540>/Switch2' */

  /* Switch: '<S540>/Switch3' incorporates:
   *  Constant: '<S540>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_g != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_i = LKAS_ConstB.DataTypeConversion6_g;
  } else {
    LKAS_DW.LKA_StrRatio_C_i = LKA_StrRatio_C;
  }

  /* End of Switch: '<S540>/Switch3' */

  /* Switch: '<S540>/Switch11' incorporates:
   *  Constant: '<S540>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22_m != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22_m;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S540>/Switch11' */

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S9>/Enable'
   */
  if (((sint32)LKAS_DW.Divide) > 0) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S74>/Delay' */
      LKAS_DW.Delay_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S502>/Memory' */
      LKAS_DW.Memory_PreviousInput_n = 0.0F;

      /* InitializeConditions for Memory: '<S447>/Memory' */
      LKAS_DW.Memory_PreviousInput_f = 0.0F;

      /* InitializeConditions for UnitDelay: '<S377>/Delay Input1'
       *
       * Block description for '<S377>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S375>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_c = false;

      /* InitializeConditions for UnitDelay: '<S376>/Delay Input1'
       *
       * Block description for '<S376>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_k = false;

      /* InitializeConditions for Delay: '<S75>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for UnitDelay: '<S338>/Delay Input1'
       *
       * Block description for '<S338>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_g = false;

      /* InitializeConditions for UnitDelay: '<S336>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_jl = false;

      /* InitializeConditions for UnitDelay: '<S337>/Delay Input1'
       *
       * Block description for '<S337>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_d = false;

      /* InitializeConditions for Memory: '<S304>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = false;

      /* InitializeConditions for Delay: '<S75>/Delay' */
      LKAS_DW.Delay_DSTATE_c = false;

      /* InitializeConditions for Delay: '<S75>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S351>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = ((uint8)0U);

      /* InitializeConditions for Memory: '<S278>/Memory' */
      LKAS_DW.Memory_PreviousInput_fe = 0.0F;

      /* InitializeConditions for Memory: '<S314>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = 0.0F;

      /* InitializeConditions for Delay: '<S75>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S75>/LDW_State_Machine'
       *
       * Block description for '<S75>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S75>/LKA_State_Machine'
       *
       * Block description for '<S75>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S221>/Add1' incorporates:
     *  MATLAB Function: '<S219>/MATLAB Function3'
     */
    rtb_TLft = rtb_L0_C0_mb + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S221>/Gain1' incorporates:
     *  Product: '<S221>/Divide'
     *  Product: '<S221>/Divide1'
     *  Sum: '<S221>/Add1'
     *  Sum: '<S221>/Add5'
     *  Trigonometry: '<S221>/Cos2'
     *  Trigonometry: '<S221>/Sin'
     */
    rtb_Gain1 = ((rtb_TLft * cosf(rtb_L0_C1_k)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_k))) * (-1.0F);

    /* Sum: '<S222>/Add1' incorporates:
     *  MATLAB Function: '<S219>/MATLAB Function4'
     */
    rtb_Add5_h_tmp = rtb_R0_C0_c - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S222>/Add5' incorporates:
     *  Product: '<S222>/Divide'
     *  Product: '<S222>/Divide1'
     *  Sum: '<S222>/Add1'
     *  Trigonometry: '<S222>/Cos2'
     *  Trigonometry: '<S222>/Sin'
     */
    rtb_Add5_h = (rtb_Add5_h_tmp * cosf(rtb_L0_C1)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1));

    /* Switch: '<S542>/Switch2' incorporates:
     *  Constant: '<S542>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_b != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_b;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S542>/Switch2' */

    /* Outputs for Enabled SubSystem: '<S9>/LKA' incorporates:
     *  EnablePort: '<S73>/Enable'
     *
     * Block description for '<S9>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S226>/kph to mps' incorporates:
     *  Gain: '<S111>/Gain'
     *  Gain: '<S161>/kph To mps'
     *  Gain: '<S175>/kph to mps'
     *  Gain: '<S176>/kph to mps'
     *  Gain: '<S219>/Gain2'
     *  Gain: '<S232>/kph to mps'
     *  Gain: '<S237>/kph to mps'
     *  Gain: '<S238>/kph to mps'
     *  Gain: '<S265>/Gain'
     *  Gain: '<S303>/Gain'
     */
    rtb_LKA_Veh2CamL_C_tmp = 0.277777791F * rtb_IMAPve_g_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S9>/LKA' */

    /* Product: '<S226>/Divide' incorporates:
     *  Gain: '<S226>/kph to mps'
     */
    rtb_LKA_Veh2CamL_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Gain: '<S223>/Gain' incorporates:
     *  Gain: '<S236>/Gain'
     */
    rtb_Add_d_tmp = 2.0F * rtb_L0_C2_h4;

    /* Sum: '<S223>/Add' incorporates:
     *  Gain: '<S223>/Gain'
     *  Gain: '<S223>/Gain1'
     *  Product: '<S223>/Product'
     */
    rtb_Add_d = ((6.0F * rtb_L0_C3_e1) * rtb_LKA_Veh2CamL_C) + rtb_Add_d_tmp;

    /* Gain: '<S224>/Gain' incorporates:
     *  Gain: '<S235>/Gain'
     */
    rtb_Add_h_tmp = 2.0F * rtb_L0_C2;

    /* Sum: '<S224>/Add' incorporates:
     *  Gain: '<S224>/Gain'
     *  Gain: '<S224>/Gain1'
     *  Product: '<S224>/Product'
     */
    rtb_Add_h = ((6.0F * rtb_L0_C3) * rtb_LKA_Veh2CamL_C) + rtb_Add_h_tmp;

    /* UnaryMinus: '<S219>/Unary Minus' incorporates:
     *  Product: '<S219>/Product'
     */
    rtb_LKA_Veh2CamL_C = -(rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1_k);

    /* Saturate: '<S219>/Saturation9' */
    if (rtb_LKA_Veh2CamL_C > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else {
      if (rtb_LKA_Veh2CamL_C < (-2.0F)) {
        rtb_LKA_Veh2CamL_C = (-2.0F);
      }
    }

    /* End of Saturate: '<S219>/Saturation9' */

    /* MATLAB Function: '<S219>/MATLAB Function' */
    if ((((rtb_Gain1 > 0.0F) && (rtb_Gain1 < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      rtb_TTLC_pk = (-rtb_Gain1) / rtb_LKA_Veh2CamL_C;
    } else {
      rtb_TTLC_pk = 3.0F;
    }

    /* End of MATLAB Function: '<S219>/MATLAB Function' */

    /* Saturate: '<S219>/Saturation' */
    if (rtb_TTLC_pk > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_TTLC_pk < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_TTLC_pk;
    }

    /* End of Saturate: '<S219>/Saturation' */

    /* Product: '<S219>/Product3' */
    rtb_TTLC_pk = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* Saturate: '<S219>/Saturation10' */
    if (rtb_TTLC_pk > 2.0F) {
      rtb_TTLC_pk = 2.0F;
    } else {
      if (rtb_TTLC_pk < (-2.0F)) {
        rtb_TTLC_pk = (-2.0F);
      }
    }

    /* End of Saturate: '<S219>/Saturation10' */

    /* MATLAB Function: '<S219>/MATLAB Function1' */
    if ((((rtb_Add5_h > 0.0F) && (rtb_Add5_h < 2.0F)) && (rtb_TTLC_pk < 0.0F)) &&
        (rtb_TTLC_pk > -1.5F)) {
      rtb_TTLC_h = (-rtb_Add5_h) / rtb_TTLC_pk;
    } else {
      rtb_TTLC_h = 3.0F;
    }

    /* End of MATLAB Function: '<S219>/MATLAB Function1' */

    /* Saturate: '<S219>/Saturation1' */
    if (rtb_TTLC_h > 2.0F) {
      rtb_TTLC_h = 2.0F;
    } else {
      if (rtb_TTLC_h < 0.6F) {
        rtb_TTLC_h = 0.6F;
      }
    }

    /* End of Saturate: '<S219>/Saturation1' */

    /* MATLAB Function: '<S219>/MATLAB Function5' incorporates:
     *  Gain: '<S245>/Gain1'
     */
    rtb_TTLC = (0.0174532924F * rtb_IMAPve_g_SW_Angle) / (((((((0.09F /
      rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp)
      + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_p) * LKAS_DW.LKA_StrRatio_C_i) * 2.0F);

    /* MATLAB Function: '<S219>/MATLAB Function3' */
    x10 = rtb_L0_C2_h4 - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_k > 0.0F) || (rtb_L0_C1_k < 0.0F))) {
      x10 = ((-rtb_L0_C0_mb) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_k;
      if (x10 > 0.0F) {
        rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_k * rtb_L0_C1_k) - ((x10 * 4.0F) * rtb_TLft);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_k)) / x1;
        x20 = ((-rtb_L0_C1_k) - x20) / x1;
        x1 = fmaxf(x10, x20);
        x10 = fminf(x10, x20);
        if (x10 > 0.0F) {
          rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          rtb_TLft = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          rtb_TLft = 3.0F;
        }
      } else {
        rtb_TLft = 3.0F;
      }
    }

    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S219>/MATLAB Function4' */
    x10 = rtb_L0_C2 - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1 > 0.0F) || (rtb_L0_C1 < 0.0F))) {
      x10 = ((-rtb_R0_C0_c) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1;
      if (x10 > 0.0F) {
        rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1 * rtb_L0_C1) - ((x10 * 4.0F) * rtb_Add5_h_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1)) / x1;
        x20 = ((-rtb_L0_C1) - x20) / x1;
        x1 = fmaxf(x10, x20);
        x10 = fminf(x10, x20);
        if (x10 > 0.0F) {
          rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          rtb_LKA_Veh2CamW_C = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S219>/MATLAB Function2' */
    if (((fabsf(rtb_Add_d) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    if (((fabsf(rtb_Add_h) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_h)
           / rtb_TTLC_h) <= 0.7F)) && (rtb_TTLC_h <= 1.95F)) {
      rtb_TTLC_h = (rtb_TTLC_h + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* End of MATLAB Function: '<S219>/MATLAB Function2' */

    /* Saturate: '<S219>/Saturation7' */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S219>/Saturation7' */

    /* Saturate: '<S219>/Saturation8' */
    if (rtb_TTLC_h > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_h < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_h;
    }

    /* End of Saturate: '<S219>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S9>/LKA' incorporates:
     *  EnablePort: '<S73>/Enable'
     *
     * Block description for '<S9>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S82>/Subsystem' incorporates:
     *  EnablePort: '<S90>/Enable'
     */
    /* Abs: '<S214>/Abs' incorporates:
     *  Abs: '<S181>/Abs5'
     *  MATLAB Function: '<S90>/DriverSwaTrqAdd'
     */
    rtb_Add5_h_tmp = fabsf(rtb_L0_C0_mb);

    /* Abs: '<S214>/Abs1' incorporates:
     *  MATLAB Function: '<S90>/DriverSwaTrqAdd'
     */
    rtb_TTLC_h = fabsf(rtb_R0_C0_c);

    /* End of Outputs for SubSystem: '<S82>/Subsystem' */
    /* End of Outputs for SubSystem: '<S9>/LKA' */

    /* Sum: '<S214>/Add' incorporates:
     *  Abs: '<S214>/Abs'
     *  Abs: '<S214>/Abs1'
     */
    rtb_LftTTLC = rtb_Add5_h_tmp + rtb_TTLC_h;

    /* Saturate: '<S214>/Saturation' */
    if (rtb_LftTTLC > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_LftTTLC < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_LftTTLC;
    }

    /* End of Saturate: '<S214>/Saturation' */

    /* If: '<S225>/If' incorporates:
     *  Delay: '<S74>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE) == 1) {
      /* Outputs for IfAction SubSystem: '<S225>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S228>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_d, &rtb_Merge_p);

      /* End of Outputs for SubSystem: '<S225>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE) == 2) {
      /* Outputs for IfAction SubSystem: '<S225>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S227>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_h, &rtb_Merge_p);

      /* End of Outputs for SubSystem: '<S225>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S225>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S229>/Action Port'
       */
      /* Gain: '<S229>/Gain' incorporates:
       *  Sum: '<S229>/Add'
       */
      rtb_Merge_p = (rtb_Add_d + rtb_Add_h) * 0.5F;

      /* End of Outputs for SubSystem: '<S225>/If Action Subsystem3' */
    }

    /* End of If: '<S225>/If' */

    /* Switch: '<S504>/Switch' incorporates:
     *  Constant: '<S546>/Constant'
     *  Constant: '<S547>/Constant'
     *  Gain: '<S546>/Gain'
     *  Gain: '<S547>/Gain'
     *  Sum: '<S546>/Add'
     *  Sum: '<S547>/Add'
     *  Switch: '<S543>/Switch47'
     */
    if (LKAS_DW.Divide >= ((uint8)2U)) {
      /* Switch: '<S543>/Switch48' incorporates:
       *  Constant: '<S543>/LLSMConClb3'
       *
       * Block description for '<S543>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S543>/Switch48' */
      rtb_Switch_h = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S543>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S543>/Switch47' incorporates:
         *  Constant: '<S543>/LLSMConClb2'
         *
         * Block description for '<S543>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_h = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S504>/Switch' */

    /* Switch: '<S502>/Switch' incorporates:
     *  Constant: '<S502>/Constant'
     *  Constant: '<S502>/Constant1'
     *  Constant: '<S507>/Constant'
     *  Constant: '<S508>/Constant'
     *  Constant: '<S509>/Constant'
     *  Logic: '<S502>/Logical Operator'
     *  RelationalOperator: '<S507>/Compare'
     *  RelationalOperator: '<S508>/Compare'
     *  RelationalOperator: '<S509>/Compare'
     */
    if (((rtb_IMAPve_d_BCM_HazardLamp > ((uint8)0U)) ||
         (rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U))) ||
        (rtb_IMAPve_d_BCM_Right_Light > ((uint8)0U))) {
      x10 = 3.0F;
    } else {
      x10 = (-1.0F);
    }

    /* End of Switch: '<S502>/Switch' */

    /* Sum: '<S502>/Add' incorporates:
     *  Memory: '<S502>/Memory'
     */
    rtb_LftTTLC = x10 + LKAS_DW.Memory_PreviousInput_n;

    /* Saturate: '<S502>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_g = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_g = (-1.0F);
    } else {
      rtb_Saturation_g = rtb_LftTTLC;
    }

    /* End of Saturate: '<S502>/Saturation' */

    /* MATLAB Function: '<S503>/MATLAB Function' */
    LKAS_MATLABFunction_i(rtb_y, &rtb_LogicalOperator3_l);

    /* Abs: '<S496>/Abs1' incorporates:
     *  Abs: '<S403>/Abs1'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_LaneWidth);
    rtb_Abs1 = rtb_LKA_Veh2CamW_C;

    /* Outputs for Enabled SubSystem: '<S9>/LKA' incorporates:
     *  EnablePort: '<S73>/Enable'
     *
     * Block description for '<S9>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S494>/Abs' incorporates:
     *  Abs: '<S101>/Abs'
     *  Abs: '<S102>/Abs'
     *  Abs: '<S103>/Abs4'
     *  Abs: '<S401>/Abs'
     *  MATLAB Function: '<S365>/MATLAB Function'
     */
    rtb_TTLC = fabsf(rtb_Merge_p);

    /* End of Outputs for SubSystem: '<S9>/LKA' */
    rtb_Abs = rtb_TTLC;

    /* Switch: '<S543>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S457>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S457>/Unary Minus' incorporates:
       *  Constant: '<S543>/LLSMConClb11'
       *
       * Block description for '<S543>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S543>/Switch53' */

    /* Switch: '<S543>/Switch87' incorporates:
     *  Constant: '<S543>/LLSMConClb8'
     *
     * Block description for '<S543>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S543>/Switch87' */

    /* Switch: '<S543>/Switch49' incorporates:
     *  Constant: '<S543>/LLSMConClb43'
     *
     * Block description for '<S543>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S543>/Switch49' */

    /* Switch: '<S543>/Switch88' incorporates:
     *  Constant: '<S543>/LLSMConClb9'
     *
     * Block description for '<S543>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_LftTTLC = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S543>/Switch88' */

    /* Switch: '<S543>/Switch50' incorporates:
     *  Constant: '<S543>/LLSMConClb10'
     *
     * Block description for '<S543>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      tmp = LKAS_ConstB.DataTypeConversion17;
    } else {
      tmp = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S543>/Switch50' */

    /* Abs: '<S492>/Abs' incorporates:
     *  Abs: '<S399>/Abs'
     *  Sum: '<S492>/Add'
     */
    x1 = fabsf(rtb_L0_C1_k - rtb_L0_C1);

    /* Abs: '<S457>/Abs2' incorporates:
     *  Abs: '<S240>/Abs2'
     *  Abs: '<S363>/Abs2'
     */
    rtb_TLft = fabsf(rtb_IMAPve_g_SW_Angle);

    /* Abs: '<S457>/Abs3' incorporates:
     *  Abs: '<S363>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     */
    rtb_Saturation_eo = fabsf(rtb_Saturation_eo);

    /* Abs: '<S457>/Abs4' incorporates:
     *  Abs: '<S363>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     */
    rtb_LogicalOperator3_f_tmp = fabsf(rtb_Saturation5);

    /* Abs: '<S457>/Abs1' incorporates:
     *  Abs: '<S364>/Abs'
     *  Abs: '<S365>/Abs'
     */
    rtb_Saturation5 = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S458>/Logical Operator2' incorporates:
     *  Abs: '<S457>/Abs1'
     *  Abs: '<S457>/Abs2'
     *  Abs: '<S457>/Abs3'
     *  Abs: '<S457>/Abs4'
     *  Abs: '<S492>/Abs'
     *  Constant: '<S494>/Constant'
     *  Constant: '<S497>/Constant'
     *  Constant: '<S499>/Constant'
     *  Constant: '<S500>/Constant'
     *  Constant: '<S506>/Constant'
     *  Logic: '<S457>/Logical Operator3'
     *  Logic: '<S463>/FixPt Logical Operator'
     *  Logic: '<S493>/Logical Operator3'
     *  Logic: '<S495>/Logical Operator'
     *  Logic: '<S498>/FixPt Logical Operator'
     *  Logic: '<S501>/FixPt Logical Operator'
     *  Logic: '<S505>/Logical Operator'
     *  Logic: '<S511>/FixPt Logical Operator'
     *  RelationalOperator: '<S457>/Relational Operator'
     *  RelationalOperator: '<S457>/Relational Operator1'
     *  RelationalOperator: '<S457>/Relational Operator2'
     *  RelationalOperator: '<S457>/Relational Operator3'
     *  RelationalOperator: '<S463>/Lower Test'
     *  RelationalOperator: '<S463>/Upper Test'
     *  RelationalOperator: '<S497>/Compare'
     *  RelationalOperator: '<S498>/Lower Test'
     *  RelationalOperator: '<S498>/Upper Test'
     *  RelationalOperator: '<S499>/Compare'
     *  RelationalOperator: '<S500>/Compare'
     *  RelationalOperator: '<S501>/Lower Test'
     *  RelationalOperator: '<S501>/Upper Test'
     *  RelationalOperator: '<S506>/Compare'
     *  RelationalOperator: '<S511>/Lower Test'
     *  RelationalOperator: '<S511>/Upper Test'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_LogicalOperator3_i = ((((((rtb_Gain_e <= rtb_IMAPve_g_ESC_VehSpd) &&
      (rtb_IMAPve_g_ESC_VehSpd <= rtb_Switch_h)) && (rtb_Saturation_g <= 0.0F)) &&
      rtb_LogicalOperator3_l) && (((((rtb_L0_Q > ((uint8)2U)) && (rtb_R0_Q >
      ((uint8)2U))) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) && (rtb_Abs1 <=
      rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) && (rtb_Abs <=
      rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) && (x1 <= 0.025F))) && (((((rtb_TLft <
      x10) && (rtb_Saturation_eo < x20)) && (rtb_Saturation5 < rtb_LftTTLC)) &&
      (rtb_LogicalOperator3_f_tmp < tmp)) && ((rtb_UnaryMinus <
      rtb_IMAPve_g_ESC_LonAcc) && (rtb_IMAPve_g_ESC_LonAcc <
      rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* RelationalOperator: '<S480>/Compare' incorporates:
     *  Constant: '<S480>/Constant'
     */
    rtb_LogicalOperator3_l = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U));

    /* Sum: '<S490>/Add1' incorporates:
     *  Constant: '<S490>/Constant1'
     *  Gain: '<S490>/Gain'
     *  Sum: '<S472>/Add1'
     */
    x20 = (0.5F * rtb_LaneWidth) - 1.5F;
    rtb_Add1_g = x20;

    /* Switch: '<S491>/Switch' incorporates:
     *  Constant: '<S490>/Constant'
     *  RelationalOperator: '<S491>/UpperRelop'
     */
    if (rtb_Add1_g < 0.0F) {
      rtb_Switch_e = 0.0F;
    } else {
      rtb_Switch_e = rtb_Add1_g;
    }

    /* End of Switch: '<S491>/Switch' */

    /* Switch: '<S491>/Switch2' incorporates:
     *  RelationalOperator: '<S491>/LowerRelop1'
     */
    if (rtb_Add1_g > rtb_LL_LKA_EarliestWarnLine_C) {
      rtb_Switch2_k = rtb_LL_LKA_EarliestWarnLine_C;
    } else {
      rtb_Switch2_k = rtb_Switch_e;
    }

    /* End of Switch: '<S491>/Switch2' */

    /* Abs: '<S477>/Abs1' incorporates:
     *  Abs: '<S389>/Abs'
     */
    rtb_LL_LKA_EarliestWarnLine_C = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S477>/Abs2' incorporates:
     *  Abs: '<S389>/Abs1'
     */
    rtb_TTLC_pk = fabsf(rtb_TTLC_pk);

    /* Logic: '<S458>/Logical Operator1' incorporates:
     *  Abs: '<S477>/Abs1'
     *  Abs: '<S477>/Abs2'
     *  Constant: '<S479>/Constant'
     *  Constant: '<S485>/Constant'
     *  Constant: '<S486>/Constant'
     *  Constant: '<S487>/Constant'
     *  Constant: '<S488>/Constant'
     *  Logic: '<S474>/Logical Operator'
     *  Logic: '<S476>/Logical Operator'
     *  Logic: '<S477>/Logical Operator'
     *  Logic: '<S478>/Logical Operator'
     *  RelationalOperator: '<S477>/Relational Operator2'
     *  RelationalOperator: '<S477>/Relational Operator3'
     *  RelationalOperator: '<S478>/Relational Operator1'
     *  RelationalOperator: '<S478>/Relational Operator2'
     *  RelationalOperator: '<S479>/Compare'
     *  RelationalOperator: '<S485>/Compare'
     *  RelationalOperator: '<S486>/Compare'
     *  RelationalOperator: '<S487>/Compare'
     *  RelationalOperator: '<S488>/Compare'
     */
    rtb_LogicalOperator3_l = (rtb_LogicalOperator3_i && ((((LKAS_DW.Divide ==
      ((uint8)2U)) && (((sint32)(((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
      rtb_LogicalOperator3_l) ? 1 : 0)) == ((sint32)(true ? 1 : 0)))) &&
      (((sint32)(((rtb_LL_LKA_EarliestWarnLine_C <=
                   rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (rtb_TTLC_pk <=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ? 1 : 0)))) &&
      (((sint32)(((rtb_Gain1 >= rtb_Switch2_k) && (rtb_Add5_h >= rtb_Switch2_k))
                 ? 1 : 0)) == ((sint32)(true ? 1 : 0)))));

    /* If: '<S458>/If1' incorporates:
     *  Constant: '<S465>/Constant'
     *  DataTypeConversion: '<S458>/Cast To Single'
     *  DataTypeConversion: '<S458>/Cast To Single2'
     */
    if ((((sint32)LKAS_DW.Divide) == 2) && rtb_LogicalOperator3_l) {
      /* Outputs for IfAction SubSystem: '<S458>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S465>/Action Port'
       */
      LKAS_DW.Merge1_o = true;

      /* End of Outputs for SubSystem: '<S458>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S458>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S467>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_o);

      /* End of Outputs for SubSystem: '<S458>/If Action Subsystem4' */
    }

    /* End of If: '<S458>/If1' */

    /* Switch: '<S449>/Switch' incorporates:
     *  Constant: '<S544>/Constant'
     *  Constant: '<S549>/Constant'
     *  Gain: '<S544>/Gain'
     *  Gain: '<S549>/Gain'
     *  Sum: '<S544>/Add'
     *  Sum: '<S549>/Add'
     *  Switch: '<S543>/Switch67'
     */
    if (LKAS_DW.Divide >= ((uint8)2U)) {
      /* Switch: '<S543>/Switch80' incorporates:
       *  Constant: '<S543>/LLSMConClb21'
       *
       * Block description for '<S543>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion58;
      } else {
        x10 = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S543>/Switch80' */
      rtb_Switch_b1 = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S543>/Switch67' */
        x10 = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S543>/Switch67' incorporates:
         *  Constant: '<S543>/LLSMConClb20'
         *
         * Block description for '<S543>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        x10 = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_b1 = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S449>/Switch' */

    /* Logic: '<S449>/Logical Operator' incorporates:
     *  Logic: '<S456>/FixPt Logical Operator'
     *  RelationalOperator: '<S456>/Lower Test'
     *  RelationalOperator: '<S456>/Upper Test'
     */
    rtb_LogicalOperator_lm = ((rtb_Gain_a >= rtb_IMAPve_g_ESC_VehSpd) ||
      (rtb_IMAPve_g_ESC_VehSpd >= rtb_Switch_b1));

    /* Switch: '<S447>/Switch' incorporates:
     *  Constant: '<S447>/Constant'
     *  Constant: '<S447>/Constant1'
     *  Constant: '<S452>/Constant'
     *  Constant: '<S453>/Constant'
     *  Constant: '<S454>/Constant'
     *  Logic: '<S447>/Logical Operator'
     *  RelationalOperator: '<S452>/Compare'
     *  RelationalOperator: '<S453>/Compare'
     *  RelationalOperator: '<S454>/Compare'
     */
    if (((rtb_IMAPve_d_BCM_HazardLamp > ((uint8)0U)) ||
         (rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U))) ||
        (rtb_IMAPve_d_BCM_Right_Light > ((uint8)0U))) {
      x10 = 3.0F;
    } else {
      x10 = (-1.0F);
    }

    /* End of Switch: '<S447>/Switch' */

    /* Sum: '<S447>/Add' incorporates:
     *  Memory: '<S447>/Memory'
     */
    rtb_LftTTLC = x10 + LKAS_DW.Memory_PreviousInput_f;

    /* Saturate: '<S447>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_l = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_l = (-1.0F);
    } else {
      rtb_Saturation_l = rtb_LftTTLC;
    }

    /* End of Saturate: '<S447>/Saturation' */

    /* RelationalOperator: '<S451>/Compare' incorporates:
     *  Constant: '<S451>/Constant'
     */
    rtb_Compare_k1 = (rtb_Saturation_l > 1.0F);

    /* MATLAB Function: '<S448>/MATLAB Function' */
    LKAS_MATLABFunction_i(rtb_y, &rtb_y_o);

    /* Logic: '<S448>/Logical Operator' */
    rtb_LogicalOperator_nr = !rtb_y_o;

    /* Logic: '<S402>/Logical Operator' incorporates:
     *  Constant: '<S406>/Constant'
     *  Constant: '<S407>/Constant'
     *  RelationalOperator: '<S406>/Compare'
     *  RelationalOperator: '<S407>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_LogicalOperator_ji = ((rtb_L0_Q < ((uint8)3U)) && (rtb_R0_Q < ((uint8)3U)));

    /* Abs: '<S403>/Abs1' */
    rtb_Abs1_o = rtb_LKA_Veh2CamW_C;

    /* RelationalOperator: '<S408>/Compare' incorporates:
     *  Constant: '<S408>/Constant'
     *  Logic: '<S409>/FixPt Logical Operator'
     *  RelationalOperator: '<S409>/Lower Test'
     *  RelationalOperator: '<S409>/Upper Test'
     */
    rtb_Compare_ok = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_o) &&
      (rtb_Abs1_o <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S401>/Abs' */
    rtb_Abs_g = rtb_TTLC;

    /* Logic: '<S401>/Logical Operator' incorporates:
     *  Constant: '<S401>/Constant'
     *  Logic: '<S405>/FixPt Logical Operator'
     *  RelationalOperator: '<S405>/Lower Test'
     *  RelationalOperator: '<S405>/Upper Test'
     */
    rtb_LogicalOperator_iv = ((0.0F > rtb_Abs_g) || (rtb_Abs_g >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S404>/Compare' incorporates:
     *  Constant: '<S404>/Constant'
     */
    rtb_Compare_bg = (x1 > 0.04F);

    /* Switch: '<S543>/Switch72' incorporates:
     *  Constant: '<S543>/LLSMConClb26'
     *
     * Block description for '<S543>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion68;
    } else {
      x10 = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S543>/Switch72' */

    /* RelationalOperator: '<S363>/Relational Operator1' */
    rtb_phiSWA_Thres = (rtb_TLft >= x10);

    /* Switch: '<S543>/Switch74' incorporates:
     *  Constant: '<S543>/LLSMConClb28'
     *
     * Block description for '<S543>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion72;
    } else {
      x10 = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S543>/Switch74' */

    /* RelationalOperator: '<S363>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_Saturation_eo >= x10);

    /* Switch: '<S543>/Switch79' incorporates:
     *  Constant: '<S543>/LLSMConClb29'
     *
     * Block description for '<S543>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion75;
    } else {
      x10 = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S543>/Switch79' */

    /* Logic: '<S363>/Logical Operator1' incorporates:
     *  Constant: '<S366>/Constant'
     *  RelationalOperator: '<S363>/Relational Operator3'
     *  RelationalOperator: '<S366>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_f_tmp >= x10) &&
                       (rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)));

    /* Switch: '<S543>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S363>/Unary Minus' */
      rtb_UnaryMinus_c = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S363>/Unary Minus' incorporates:
       *  Constant: '<S543>/LLSMConClb30'
       *
       * Block description for '<S543>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_c = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S543>/Switch61' */

    /* RelationalOperator: '<S367>/Compare' incorporates:
     *  Constant: '<S367>/Constant'
     *  Logic: '<S368>/FixPt Logical Operator'
     *  RelationalOperator: '<S368>/Lower Test'
     *  RelationalOperator: '<S368>/Upper Test'
     */
    rtb_Compare_ge2 = (((sint32)(((rtb_UnaryMinus_c < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                       ((sint32)(false ? 1 : 0)));

    /* Switch: '<S364>/Switch' incorporates:
     *  Constant: '<S369>/Constant'
     *  Constant: '<S543>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
     *  RelationalOperator: '<S369>/Compare'
     *  Switch: '<S543>/Switch38'
     *
     * Block description for '<S543>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
     *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      /* Switch: '<S543>/Switch44' incorporates:
       *  Constant: '<S543>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
       *
       * Block description for '<S543>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
       *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
       */
      if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
        rtb_Saturation_eo = LKAS_ConstB.DataTypeConversion8;
      } else {
        rtb_Saturation_eo = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
      }

      /* End of Switch: '<S543>/Switch44' */
    } else if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
      /* Switch: '<S543>/Switch38' */
      rtb_Saturation_eo = LKAS_ConstB.DataTypeConversion6;
    } else {
      rtb_Saturation_eo = LL_RlsDet_tiTrqChkT_DISABLE;
    }

    /* End of Switch: '<S364>/Switch' */

    /* Outputs for Enabled SubSystem: '<S364>/Count 20s' incorporates:
     *  EnablePort: '<S372>/Enable'
     */
    /* Logic: '<S364>/Logical Operator1' incorporates:
     *  Constant: '<S370>/Constant'
     *  Constant: '<S371>/Constant'
     *  Logic: '<S364>/Logical Operator2'
     *  RelationalOperator: '<S364>/Relational Operator'
     *  RelationalOperator: '<S370>/Compare'
     *  RelationalOperator: '<S371>/Compare'
     */
    if (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
         (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) && (rtb_Saturation5 <=
         rtb_Saturation_eo)) {
      if (!LKAS_DW.Count20s_MODE) {
        /* InitializeConditions for Memory: '<S372>/Memory' */
        LKAS_DW.Memory_PreviousInput_ay = 0.0F;
        LKAS_DW.Count20s_MODE = true;
      }

      /* Sum: '<S372>/Add' incorporates:
       *  Memory: '<S372>/Memory'
       */
      rtb_Saturation_eo = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_ay;

      /* Saturate: '<S372>/Saturation' */
      if (rtb_Saturation_eo > 50.0F) {
        rtb_Saturation_eo = 50.0F;
      } else {
        if (rtb_Saturation_eo < 0.0F) {
          rtb_Saturation_eo = 0.0F;
        }
      }

      /* End of Saturate: '<S372>/Saturation' */

      /* RelationalOperator: '<S372>/Relational Operator' incorporates:
       *  Constant: '<S372>/Constant'
       */
      LKAS_DW.RelationalOperator_b = (rtb_Saturation_eo >= 20.0F);

      /* Update for Memory: '<S372>/Memory' */
      LKAS_DW.Memory_PreviousInput_ay = rtb_Saturation_eo;
    } else {
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S372>/Out' */
        LKAS_DW.RelationalOperator_b = false;
        LKAS_DW.Count20s_MODE = false;
      }
    }

    /* End of Logic: '<S364>/Logical Operator1' */
    /* End of Outputs for SubSystem: '<S364>/Count 20s' */

    /* Saturate: '<S365>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 80.0F) {
      x10 = 80.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      x10 = 60.0F;
    } else {
      x10 = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S365>/Saturation' */

    /* Outputs for Enabled SubSystem: '<S365>/Sum Condition1' incorporates:
     *  EnablePort: '<S374>/state = reset'
     */
    /* MATLAB Function: '<S365>/MATLAB Function' */
    if (rtb_Saturation5 >= fminf(fmaxf(1.5F, ((1.5F *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL) - ((x10 / 180.0F) *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL)) + (rtb_TTLC / 0.005F)), 2.75F)) {
      if (!LKAS_DW.SumCondition1_MODE_m) {
        /* InitializeConditions for Memory: '<S374>/Memory' */
        LKAS_DW.Memory_PreviousInput_ab = 0.0F;
        LKAS_DW.SumCondition1_MODE_m = true;
      }

      /* Sum: '<S374>/Add1' incorporates:
       *  Memory: '<S374>/Memory'
       */
      rtb_Saturation_eo = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_ab;

      /* Saturate: '<S374>/Saturation' */
      if (rtb_Saturation_eo > 5000.0F) {
        rtb_Saturation_eo = 5000.0F;
      } else {
        if (rtb_Saturation_eo < 0.0F) {
          rtb_Saturation_eo = 0.0F;
        }
      }

      /* End of Saturate: '<S374>/Saturation' */

      /* Switch: '<S543>/Switch65' incorporates:
       *  Constant: '<S543>/LLSMConClb34'
       *
       * Block description for '<S543>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion82;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S543>/Switch65' */

      /* RelationalOperator: '<S374>/Relational Operator' */
      LKAS_DW.RelationalOperator_l = (rtb_Saturation_eo >= x10);

      /* Update for Memory: '<S374>/Memory' */
      LKAS_DW.Memory_PreviousInput_ab = rtb_Saturation_eo;
    } else {
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S374>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }
    }

    /* End of Outputs for SubSystem: '<S365>/Sum Condition1' */

    /* RelationalOperator: '<S383>/Compare' incorporates:
     *  Constant: '<S383>/Constant'
     */
    rtb_Compare_n = (((sint32)(LKAS_DW.RelationalOperator_l ? 1 : 0)) > ((sint32)
      (false ? 1 : 0)));

    /* UnitDelay: '<S375>/Unit Delay' */
    rtb_UnitDelay_e4 = LKAS_DW.UnitDelay_DSTATE_c;

    /* RelationalOperator: '<S382>/Compare' incorporates:
     *  Constant: '<S382>/Constant'
     */
    rtb_Compare_cmd = (((sint32)(rtb_UnitDelay_e4 ? 1 : 0)) <= ((sint32)(false ?
      1 : 0)));

    /* If: '<S375>/If' incorporates:
     *  Constant: '<S378>/Constant'
     *  Constant: '<S379>/Constant'
     *  RelationalOperator: '<S376>/FixPt Relational Operator'
     *  RelationalOperator: '<S377>/FixPt Relational Operator'
     *  UnitDelay: '<S376>/Delay Input1'
     *  UnitDelay: '<S377>/Delay Input1'
     *
     * Block description for '<S376>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S377>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_l) && (((sint32)(rtb_Compare_n ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S375>/If Action Subsystem' incorporates:
       *  ActionPort: '<S378>/Action Port'
       */
      rtb_Merge_e = true;

      /* End of Outputs for SubSystem: '<S375>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_e4) && (((sint32)(rtb_Compare_cmd ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_k ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S375>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S379>/Action Port'
       */
      rtb_Merge_e = false;

      /* End of Outputs for SubSystem: '<S375>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S375>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S380>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_e4, &rtb_Merge_e);

      /* End of Outputs for SubSystem: '<S375>/If Action Subsystem3' */
    }

    /* End of If: '<S375>/If' */

    /* Outputs for Enabled SubSystem: '<S375>/Sum Condition1' incorporates:
     *  EnablePort: '<S381>/state = reset'
     */
    if (rtb_Merge_e) {
      if (!LKAS_DW.SumCondition1_MODE_f) {
        /* InitializeConditions for Memory: '<S381>/Memory' */
        LKAS_DW.Memory_PreviousInput_b = 0.0F;
        LKAS_DW.SumCondition1_MODE_f = true;
      }

      /* Sum: '<S381>/Add1' incorporates:
       *  Memory: '<S381>/Memory'
       */
      rtb_Saturation_eo = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_b;

      /* Saturate: '<S381>/Saturation' */
      if (rtb_Saturation_eo > 10.0F) {
        rtb_Saturation_eo = 10.0F;
      } else {
        if (rtb_Saturation_eo < 0.0F) {
          rtb_Saturation_eo = 0.0F;
        }
      }

      /* End of Saturate: '<S381>/Saturation' */

      /* RelationalOperator: '<S381>/Relational Operator' */
      LKAS_DW.RelationalOperator_h = (rtb_Saturation_eo <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S381>/Memory' */
      LKAS_DW.Memory_PreviousInput_b = rtb_Saturation_eo;
    } else {
      if (LKAS_DW.SumCondition1_MODE_f) {
        /* Disable for Outport: '<S381>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.SumCondition1_MODE_f = false;
      }
    }

    /* End of Outputs for SubSystem: '<S375>/Sum Condition1' */

    /* Logic: '<S349>/Logical Operator2' incorporates:
     *  Logic: '<S362>/Logical Operator1'
     *  Logic: '<S363>/Logical Operator'
     *  Logic: '<S400>/Logical Operator3'
     *  Logic: '<S450>/Logical Operator3'
     */
    rtb_LogicalOperator3_l = ((((rtb_LogicalOperator_lm || rtb_Compare_k1) ||
      rtb_LogicalOperator_nr) || (((rtb_LogicalOperator_ji || rtb_Compare_ok) ||
      rtb_LogicalOperator_iv) || rtb_Compare_bg)) || (((((rtb_phiSWA_Thres ||
      rtb_dphiSWARate_Thres) || rtb_aLAcc_Thres) || rtb_Compare_ge2) ||
      (LKAS_DW.RelationalOperator_b)) || (LKAS_DW.RelationalOperator_h)));

    /* Logic: '<S389>/Logical Operator' incorporates:
     *  RelationalOperator: '<S389>/Relational Operator1'
     *  RelationalOperator: '<S389>/Relational Operator2'
     */
    rtb_LogicalOperator_ij = ((rtb_LL_LKA_EarliestWarnLine_C >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (rtb_TTLC_pk >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S390>/Logical Operator' incorporates:
     *  RelationalOperator: '<S390>/Relational Operator1'
     *  RelationalOperator: '<S390>/Relational Operator2'
     */
    rtb_LogicalOperator_j1 = ((rtb_Gain1 <= rtb_R0_C1) || (rtb_Add5_h <=
      rtb_R0_C1));

    /* If: '<S387>/If' incorporates:
     *  Constant: '<S393>/Constant'
     *  Delay: '<S75>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_IMAPve_d_EPS_LKA_State) != 2)) {
      /* Outputs for IfAction SubSystem: '<S387>/If Action Subsystem' incorporates:
       *  ActionPort: '<S391>/Action Port'
       */
      LKAS_IfActionSubsystem_m(&rtb_Merge_l);

      /* End of Outputs for SubSystem: '<S387>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_IMAPve_d_EPS_LKA_State) != 3)) {
      /* Outputs for IfAction SubSystem: '<S387>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S392>/Action Port'
       */
      LKAS_IfActionSubsystem_m(&rtb_Merge_l);

      /* End of Outputs for SubSystem: '<S387>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S387>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S393>/Action Port'
       */
      rtb_Merge_l = false;

      /* End of Outputs for SubSystem: '<S387>/If Action Subsystem3' */
    }

    /* End of If: '<S387>/If' */

    /* Outputs for Enabled SubSystem: '<S387>/Sum Condition1' incorporates:
     *  EnablePort: '<S394>/state = reset'
     */
    if (rtb_Merge_l) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S394>/Memory' */
        LKAS_DW.Memory_PreviousInput_j = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S394>/Add1' incorporates:
       *  Memory: '<S394>/Memory'
       */
      rtb_Saturation_eo = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_j;

      /* Saturate: '<S394>/Saturation' */
      if (rtb_Saturation_eo > 60.0F) {
        rtb_Saturation_eo = 60.0F;
      } else {
        if (rtb_Saturation_eo < 0.0F) {
          rtb_Saturation_eo = 0.0F;
        }
      }

      /* End of Saturate: '<S394>/Saturation' */

      /* Switch: '<S543>/Switch63' incorporates:
       *  Constant: '<S543>/LLSMConClb32'
       *
       * Block description for '<S543>/LLSMConClb32':
       *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion78;
      } else {
        x10 = LL_MAX_DELAY_EPSSTAR_TIME;
      }

      /* End of Switch: '<S543>/Switch63' */

      /* RelationalOperator: '<S394>/Relational Operator' */
      LKAS_DW.RelationalOperator_k = (rtb_Saturation_eo >= x10);

      /* Update for Memory: '<S394>/Memory' */
      LKAS_DW.Memory_PreviousInput_j = rtb_Saturation_eo;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S394>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S387>/Sum Condition1' */

    /* If: '<S349>/If2' incorporates:
     *  Constant: '<S358>/Constant'
     *  Constant: '<S395>/Constant'
     *  Constant: '<S396>/Constant'
     *  Constant: '<S397>/Constant'
     *  Constant: '<S398>/Constant'
     *  DataTypeConversion: '<S349>/Cast To Single'
     *  Logic: '<S349>/Logical Operator1'
     *  Logic: '<S388>/Logical Operator'
     *  Logic: '<S388>/Logical Operator1'
     *  RelationalOperator: '<S395>/Compare'
     *  RelationalOperator: '<S396>/Compare'
     *  RelationalOperator: '<S397>/Compare'
     *  RelationalOperator: '<S398>/Compare'
     */
    if ((((sint32)LKAS_DW.Divide) == 2) && (rtb_LogicalOperator3_l ||
         ((LKAS_DW.Divide == ((uint8)2U)) && (((rtb_LogicalOperator_ij == true) ||
            (rtb_LogicalOperator_j1 == true)) || (LKAS_DW.RelationalOperator_k ==
            true))))) {
      /* Outputs for IfAction SubSystem: '<S349>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S358>/Action Port'
       */
      LKAS_DW.Merge2_m = true;

      /* End of Outputs for SubSystem: '<S349>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S349>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S360>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2_m);

      /* End of Outputs for SubSystem: '<S349>/If Action Subsystem3' */
    }

    /* End of If: '<S349>/If2' */

    /* Product: '<S265>/Divide' */
    rtb_LKA_Veh2CamL_C = rtb_L0_C1_k * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S265>/Divide1' */
    rtb_Saturation_eo = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* If: '<S287>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_Saturation_eo >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S287>/Ph1SWA' incorporates:
       *  ActionPort: '<S291>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_e);

      /* End of Outputs for SubSystem: '<S287>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_Saturation_eo <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S287>/Ph2SWA' incorporates:
       *  ActionPort: '<S292>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_e);

      /* End of Outputs for SubSystem: '<S287>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S287>/Ph3SWA' incorporates:
       *  ActionPort: '<S293>/Action Port'
       */
      LKAS_Ph3SWA_k(&rtb_Merge1_e);

      /* End of Outputs for SubSystem: '<S287>/Ph3SWA' */
    }

    /* End of If: '<S287>/If' */

    /* Saturate: '<S265>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_Saturation5 = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_Saturation5 = (-2.0F);
    } else {
      rtb_Saturation5 = rtb_Gain1;
    }

    /* End of Saturate: '<S265>/Saturation5' */

    /* MATLAB Function: '<S274>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LaneWidth, rtb_LKA_CarWidth,
                        rtb_LL_ThresDet_lDvtThresUprLDW,
                        &rtb_ThresDet_coefficient_f);

    /* Product: '<S274>/Divide5' */
    rtb_LftTTLC = rtb_ThresDet_coefficient_f * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S274>/Divide6' */
    x10 = rtb_ThresDet_coefficient_f * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S289>/Abs' incorporates:
     *  Abs: '<S280>/Abs'
     */
    x1 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Product: '<S289>/Divide' incorporates:
     *  Abs: '<S289>/Abs'
     */
    rtb_Divide_jr = x10 * x1;

    /* Product: '<S274>/Divide4' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_ThresDet_coefficient_f *
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S294>/Switch' incorporates:
     *  RelationalOperator: '<S294>/UpperRelop'
     */
    if (rtb_Divide_jr < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_g = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_g = rtb_Divide_jr;
    }

    /* End of Switch: '<S294>/Switch' */

    /* Switch: '<S294>/Switch2' incorporates:
     *  RelationalOperator: '<S294>/LowerRelop1'
     */
    if (rtb_Divide_jr > rtb_LftTTLC) {
      rtb_Switch2_d = rtb_LftTTLC;
    } else {
      rtb_Switch2_d = rtb_Switch_g;
    }

    /* End of Switch: '<S294>/Switch2' */

    /* Saturate: '<S265>/Saturation1' */
    if (rtb_Add5_h > 2.0F) {
      rtb_LL_LKA_EarliestWarnLine_C = 2.0F;
    } else if (rtb_Add5_h < (-2.0F)) {
      rtb_LL_LKA_EarliestWarnLine_C = (-2.0F);
    } else {
      rtb_LL_LKA_EarliestWarnLine_C = rtb_Add5_h;
    }

    /* End of Saturate: '<S265>/Saturation1' */

    /* Abs: '<S290>/Abs' incorporates:
     *  Abs: '<S281>/Abs'
     */
    rtb_LogicalOperator3_f_tmp = fabsf(rtb_Saturation_eo);

    /* Product: '<S290>/Divide' incorporates:
     *  Abs: '<S290>/Abs'
     */
    rtb_Divide_c = x10 * rtb_LogicalOperator3_f_tmp;

    /* Switch: '<S295>/Switch' incorporates:
     *  RelationalOperator: '<S295>/UpperRelop'
     */
    if (rtb_Divide_c < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_l = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_l = rtb_Divide_c;
    }

    /* End of Switch: '<S295>/Switch' */

    /* Switch: '<S295>/Switch2' incorporates:
     *  RelationalOperator: '<S295>/LowerRelop1'
     */
    if (rtb_Divide_c > rtb_LftTTLC) {
      rtb_Switch2_o = rtb_LftTTLC;
    } else {
      rtb_Switch2_o = rtb_Switch_l;
    }

    /* End of Switch: '<S295>/Switch2' */

    /* Switch: '<S288>/Switch3' incorporates:
     *  Constant: '<S290>/Constant'
     *  Gain: '<S288>/Gain1'
     *  Logic: '<S290>/Logical Operator'
     *  RelationalOperator: '<S290>/Relational Operator1'
     *  RelationalOperator: '<S290>/Relational Operator2'
     */
    if (rtb_Merge1_e >= 0.0F) {
      /* Switch: '<S288>/Switch2' incorporates:
       *  Constant: '<S288>/Constant2'
       *  Constant: '<S289>/Constant'
       *  DataTypeConversion: '<S288>/Cast To Single'
       *  Logic: '<S289>/Logical Operator'
       *  RelationalOperator: '<S289>/Relational Operator1'
       *  RelationalOperator: '<S289>/Relational Operator3'
       */
      if (rtb_Merge1_e > 0.0F) {
        rtb_IMAPve_d_BCM_Left_Light = (uint8)(((0.0F < rtb_Saturation5) &&
          (rtb_Saturation5 <= rtb_Switch2_d)) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_Left_Light = ((uint8)0U);
      }

      /* End of Switch: '<S288>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Left_Light = (uint8)((((uint32)(((0.0F <
        rtb_LL_LKA_EarliestWarnLine_C) && (rtb_LL_LKA_EarliestWarnLine_C <=
        rtb_Switch2_o)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S288>/Switch3' */

    /* DataTypeConversion: '<S267>/Data Type Conversion' incorporates:
     *  Constant: '<S298>/Constant'
     *  Constant: '<S299>/Constant'
     *  Constant: '<S300>/Constant'
     *  Constant: '<S301>/Constant'
     *  Logic: '<S267>/Logical Operator'
     *  Logic: '<S267>/Logical Operator1'
     *  Logic: '<S267>/Logical Operator2'
     *  RelationalOperator: '<S298>/Compare'
     *  RelationalOperator: '<S299>/Compare'
     *  RelationalOperator: '<S300>/Compare'
     *  RelationalOperator: '<S301>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_IMAPve_d_BCM_HazardLamp = (uint8)((((rtb_R0_Q > ((uint8)2U)) &&
      (rtb_IMAPve_d_BCM_Left_Light == ((uint8)2U))) ||
      ((rtb_IMAPve_d_BCM_Left_Light == ((uint8)1U)) && (rtb_L0_Q > ((uint8)2U))))
      ? 1 : 0);

    /* DataTypeConversion: '<S266>/Data Type Conversion' incorporates:
     *  Constant: '<S296>/Constant'
     *  Constant: '<S297>/Constant'
     *  Logic: '<S266>/Logical Operator'
     *  RelationalOperator: '<S296>/Compare'
     *  RelationalOperator: '<S297>/Compare'
     */
    rtb_IMAPve_d_BCM_Right_Light = (uint8)(((rtb_IMAPve_d_EPS_LKA_State ==
      ((uint8)3U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U))) ? 1 : 0);

    /* If: '<S264>/If1' incorporates:
     *  Constant: '<S269>/Constant'
     *  Constant: '<S272>/Constant'
     *  Constant: '<S273>/Constant'
     */
    if ((((((sint32)LKAS_DW.Divide) == 2) && (((sint32)
            rtb_IMAPve_d_BCM_Left_Light) == 1)) && (((sint32)
           rtb_IMAPve_d_BCM_Right_Light) == 1)) && (((sint32)
          rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S264>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S272>/Action Port'
       */
      LKAS_DW.Merge2 = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S264>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.Divide) == 2) && (((sint32)
        rtb_IMAPve_d_BCM_Left_Light) == 2)) && (((sint32)
                  rtb_IMAPve_d_BCM_Right_Light) == 1)) && (((sint32)
                 rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S264>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S273>/Action Port'
       */
      LKAS_DW.Merge2 = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S264>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S264>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S269>/Action Port'
       */
      LKAS_DW.Merge2 = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S264>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S264>/If1' */

    /* Product: '<S303>/Divide' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_L0_C1_k * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S303>/Divide1' */
    rtb_TTLC_pk = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* If: '<S323>/If' */
    if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) ||
        (rtb_TTLC_pk >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S323>/Ph1SWA' incorporates:
       *  ActionPort: '<S327>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_e3);

      /* End of Outputs for SubSystem: '<S323>/Ph1SWA' */
    } else if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_TTLC_pk <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S323>/Ph2SWA' incorporates:
       *  ActionPort: '<S328>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_e3);

      /* End of Outputs for SubSystem: '<S323>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S323>/Ph3SWA' incorporates:
       *  ActionPort: '<S329>/Action Port'
       */
      LKAS_Ph3SWA_k(&rtb_Merge1_e3);

      /* End of Outputs for SubSystem: '<S323>/Ph3SWA' */
    }

    /* End of If: '<S323>/If' */

    /* Saturate: '<S303>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_LKA_Veh2CamW_C = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_LKA_Veh2CamW_C = (-2.0F);
    } else {
      rtb_LKA_Veh2CamW_C = rtb_Gain1;
    }

    /* End of Saturate: '<S303>/Saturation5' */

    /* MATLAB Function: '<S310>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LaneWidth, rtb_LKA_CarWidth,
                        rtb_LL_ThresDet_lDvtThresUprLDW,
                        &rtb_ThresDet_coefficient);

    /* Product: '<S310>/Divide5' */
    x10 = rtb_ThresDet_coefficient * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S310>/Divide6' */
    rtb_LftTTLC = rtb_ThresDet_coefficient * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S325>/Divide' incorporates:
     *  Abs: '<S325>/Abs'
     */
    rtb_Divide_i = rtb_LftTTLC * fabsf(rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Product: '<S310>/Divide4' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S330>/Switch' incorporates:
     *  RelationalOperator: '<S330>/UpperRelop'
     */
    if (rtb_Divide_i < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_i1 = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_i1 = rtb_Divide_i;
    }

    /* End of Switch: '<S330>/Switch' */

    /* Switch: '<S330>/Switch2' incorporates:
     *  RelationalOperator: '<S330>/LowerRelop1'
     */
    if (rtb_Divide_i > x10) {
      rtb_Switch2_e = x10;
    } else {
      rtb_Switch2_e = rtb_Switch_i1;
    }

    /* End of Switch: '<S330>/Switch2' */

    /* Saturate: '<S303>/Saturation1' */
    if (rtb_Add5_h > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_h < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_h;
    }

    /* End of Saturate: '<S303>/Saturation1' */

    /* Product: '<S326>/Divide' incorporates:
     *  Abs: '<S326>/Abs'
     */
    rtb_Divide_b = rtb_LftTTLC * fabsf(rtb_TTLC_pk);

    /* Switch: '<S331>/Switch' incorporates:
     *  RelationalOperator: '<S331>/UpperRelop'
     */
    if (rtb_Divide_b < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_j = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_j = rtb_Divide_b;
    }

    /* End of Switch: '<S331>/Switch' */

    /* Switch: '<S331>/Switch2' incorporates:
     *  RelationalOperator: '<S331>/LowerRelop1'
     */
    if (rtb_Divide_b > x10) {
      rtb_Switch2_ex = x10;
    } else {
      rtb_Switch2_ex = rtb_Switch_j;
    }

    /* End of Switch: '<S331>/Switch2' */

    /* Switch: '<S324>/Switch3' incorporates:
     *  Constant: '<S326>/Constant'
     *  Gain: '<S324>/Gain1'
     *  Logic: '<S326>/Logical Operator'
     *  RelationalOperator: '<S326>/Relational Operator1'
     *  RelationalOperator: '<S326>/Relational Operator2'
     */
    if (rtb_Merge1_e3 >= 0.0F) {
      /* Switch: '<S324>/Switch2' incorporates:
       *  Constant: '<S324>/Constant2'
       *  Constant: '<S325>/Constant'
       *  DataTypeConversion: '<S324>/Cast To Single'
       *  Logic: '<S325>/Logical Operator'
       *  RelationalOperator: '<S325>/Relational Operator1'
       *  RelationalOperator: '<S325>/Relational Operator3'
       */
      if (rtb_Merge1_e3 > 0.0F) {
        rtb_IMAPve_d_BCM_Left_Light = (uint8)(((0.0F < rtb_LKA_Veh2CamW_C) &&
          (rtb_LKA_Veh2CamW_C <= rtb_Switch2_e)) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_Left_Light = ((uint8)0U);
      }

      /* End of Switch: '<S324>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Left_Light = (uint8)((((uint32)(((0.0F <
        rtb_LL_ThresDet_lDvtThresLwrLKA) && (rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_ex)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S324>/Switch3' */

    /* MATLAB Function: '<S304>/MATLAB Function' */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_IMAPve_g_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge_p), 0.005F)) / 0.005F);
    if ((((sint32)rtb_IMAPve_d_BCM_Left_Light) == 2) && (rtb_IMAPve_g_EPS_SW_Trq
         > rtb_LL_MAX_DRIVER_TORQUE_DISABL)) {
      rtb_IMAPve_d_BCM_Left_Light_0 = 1;
    } else {
      rtb_IMAPve_d_BCM_Left_Light_0 = (sint32)(((((sint32)
        rtb_IMAPve_d_BCM_Left_Light) == 1) && (rtb_IMAPve_g_EPS_SW_Trq <
        (-rtb_LL_MAX_DRIVER_TORQUE_DISABL))) ? 1 : 0);
    }

    /* End of MATLAB Function: '<S304>/MATLAB Function' */

    /* Outputs for Enabled SubSystem: '<S304>/Count 0.2s' incorporates:
     *  EnablePort: '<S334>/Enable'
     */
    if (rtb_IMAPve_d_BCM_Left_Light_0 > 0) {
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S334>/Memory' */
        LKAS_DW.Memory_PreviousInput_go = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S334>/Add' incorporates:
       *  Memory: '<S334>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_go;

      /* Saturate: '<S334>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S334>/Saturation' */

      /* Switch: '<S543>/Switch16' incorporates:
       *  Constant: '<S543>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S543>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S543>/Switch16' */

      /* RelationalOperator: '<S334>/Relational Operator' */
      LKAS_DW.RelationalOperator_c = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S334>/Memory' */
      LKAS_DW.Memory_PreviousInput_go = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S334>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.Count02s_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S304>/Count 0.2s' */

    /* RelationalOperator: '<S344>/Compare' incorporates:
     *  Constant: '<S344>/Constant'
     */
    rtb_Compare_fc = (((sint32)(LKAS_DW.RelationalOperator_c ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S336>/Unit Delay' */
    rtb_UnitDelay_om = LKAS_DW.UnitDelay_DSTATE_jl;

    /* RelationalOperator: '<S343>/Compare' incorporates:
     *  Constant: '<S343>/Constant'
     */
    rtb_Compare_lp = (((sint32)(rtb_UnitDelay_om ? 1 : 0)) <= ((sint32)(false ?
      1 : 0)));

    /* If: '<S336>/If' incorporates:
     *  Constant: '<S339>/Constant'
     *  Constant: '<S340>/Constant'
     *  RelationalOperator: '<S337>/FixPt Relational Operator'
     *  RelationalOperator: '<S338>/FixPt Relational Operator'
     *  UnitDelay: '<S337>/Delay Input1'
     *  UnitDelay: '<S338>/Delay Input1'
     *
     * Block description for '<S337>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S338>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_c) && (((sint32)(rtb_Compare_fc ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_g ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S336>/If Action Subsystem' incorporates:
       *  ActionPort: '<S339>/Action Port'
       */
      rtb_Merge_o4 = true;

      /* End of Outputs for SubSystem: '<S336>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_om) && (((sint32)(rtb_Compare_lp ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_d ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S336>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S340>/Action Port'
       */
      rtb_Merge_o4 = false;

      /* End of Outputs for SubSystem: '<S336>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S336>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S341>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_om, &rtb_Merge_o4);

      /* End of Outputs for SubSystem: '<S336>/If Action Subsystem3' */
    }

    /* End of If: '<S336>/If' */

    /* Outputs for Enabled SubSystem: '<S304>/Count' incorporates:
     *  EnablePort: '<S333>/Enable'
     */
    /* Logic: '<S304>/Logical Operator' incorporates:
     *  Constant: '<S332>/Constant'
     *  Memory: '<S304>/Memory'
     *  RelationalOperator: '<S332>/Compare'
     */
    if ((rtb_IMAPve_d_BCM_Left_Light > ((uint8)0U)) &&
        (LKAS_DW.Memory_PreviousInput_i)) {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S333>/Memory' */
        LKAS_DW.Memory_PreviousInput_n1 = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S333>/Add' incorporates:
       *  Memory: '<S333>/Memory'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_n1;

      /* Saturate: '<S333>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_LftTTLC;
      }

      /* End of Saturate: '<S333>/Saturation' */

      /* Update for Memory: '<S333>/Memory' */
      LKAS_DW.Memory_PreviousInput_n1 = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S333>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S304>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S304>/Count' */

    /* Outputs for Enabled SubSystem: '<S336>/Sum Condition1' incorporates:
     *  EnablePort: '<S342>/state = reset'
     */
    if (rtb_Merge_o4) {
      if (!LKAS_DW.SumCondition1_MODE_p) {
        /* InitializeConditions for Memory: '<S342>/Memory' */
        LKAS_DW.Memory_PreviousInput_hn = 0.0F;
        LKAS_DW.SumCondition1_MODE_p = true;
      }

      /* Sum: '<S342>/Add1' incorporates:
       *  Memory: '<S342>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_hn;

      /* Saturate: '<S342>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 2.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 2.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S342>/Saturation' */

      /* Switch: '<S543>/Switch40' incorporates:
       *  Constant: '<S543>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S543>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S543>/Switch40' */

      /* RelationalOperator: '<S342>/Relational Operator' incorporates:
       *  Sum: '<S304>/Add'
       */
      LKAS_DW.RelationalOperator_a = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S342>/Memory' */
      LKAS_DW.Memory_PreviousInput_hn = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_p) {
        /* Disable for Outport: '<S342>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE_p = false;
      }
    }

    /* End of Outputs for SubSystem: '<S336>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S305>/Sum Condition1' incorporates:
     *  EnablePort: '<S348>/state = reset'
     */
    /* Logic: '<S305>/Logical Operator' incorporates:
     *  Constant: '<S346>/Constant'
     *  Constant: '<S347>/Constant'
     *  Delay: '<S75>/Delay1'
     *  RelationalOperator: '<S346>/Compare'
     *  RelationalOperator: '<S347>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_o) {
        /* InitializeConditions for Memory: '<S348>/Memory' */
        LKAS_DW.Memory_PreviousInput_h = 0.0F;
        LKAS_DW.SumCondition1_MODE_o = true;
      }

      /* Sum: '<S348>/Add1' incorporates:
       *  Memory: '<S348>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_h;

      /* Saturate: '<S348>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S348>/Saturation' */

      /* RelationalOperator: '<S348>/Relational Operator' */
      LKAS_DW.RelationalOperator_p = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S348>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S348>/Out' */
        LKAS_DW.RelationalOperator_p = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }
    }

    /* End of Logic: '<S305>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S305>/Sum Condition1' */

    /* If: '<S302>/If1' incorporates:
     *  Constant: '<S307>/Constant'
     *  Constant: '<S309>/Constant'
     *  Constant: '<S345>/Constant'
     *  Delay: '<S75>/Delay'
     *  Logic: '<S302>/Logical Operator'
     *  Logic: '<S305>/Logical Operator1'
     *  RelationalOperator: '<S345>/Compare'
     */
    if ((((sint32)LKAS_DW.Divide) == 2) && (((LKAS_DW.RelationalOperator_a) ||
          ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_p))) || (LKAS_DW.Delay_DSTATE_c))) {
      /* Outputs for IfAction SubSystem: '<S302>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S309>/Action Port'
       */
      LKAS_DW.Merge1_b = true;

      /* End of Outputs for SubSystem: '<S302>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S302>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S307>/Action Port'
       */
      LKAS_DW.Merge1_b = false;

      /* End of Outputs for SubSystem: '<S302>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S302>/If1' */

    /* Sum: '<S472>/Add1' */
    rtb_Add1_f = x20;

    /* Switch: '<S473>/Switch' incorporates:
     *  Constant: '<S472>/Constant'
     *  RelationalOperator: '<S473>/UpperRelop'
     */
    if (rtb_Add1_f < 0.0F) {
      rtb_Switch_a3 = 0.0F;
    } else {
      rtb_Switch_a3 = rtb_Add1_f;
    }

    /* End of Switch: '<S473>/Switch' */

    /* Switch: '<S473>/Switch2' incorporates:
     *  RelationalOperator: '<S473>/LowerRelop1'
     */
    if (rtb_Add1_f > rtb_LL_LDW_EarliestWarnLine_C) {
      rtb_Switch2_n = rtb_LL_LDW_EarliestWarnLine_C;
    } else {
      rtb_Switch2_n = rtb_Switch_a3;
    }

    /* End of Switch: '<S473>/Switch2' */

    /* Logic: '<S458>/Logical Operator3' incorporates:
     *  Constant: '<S470>/Constant'
     *  Constant: '<S471>/Constant'
     *  Logic: '<S468>/Logical Operator'
     *  Logic: '<S469>/Logical Operator'
     *  RelationalOperator: '<S469>/Relational Operator1'
     *  RelationalOperator: '<S469>/Relational Operator2'
     *  RelationalOperator: '<S470>/Compare'
     *  RelationalOperator: '<S471>/Compare'
     */
    rtb_LogicalOperator3_i = (((LKAS_DW.Divide >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1 >= rtb_Switch2_n) && (rtb_Add5_h >= rtb_Switch2_n)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_i);

    /* If: '<S458>/If' incorporates:
     *  Constant: '<S464>/Constant'
     *  DataTypeConversion: '<S458>/Cast To Single'
     *  DataTypeConversion: '<S458>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
        rtb_LogicalOperator3_i) {
      /* Outputs for IfAction SubSystem: '<S458>/If Action Subsystem' incorporates:
       *  ActionPort: '<S464>/Action Port'
       */
      LKAS_DW.Merge_e = true;

      /* End of Outputs for SubSystem: '<S458>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S458>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S466>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_e);

      /* End of Outputs for SubSystem: '<S458>/If Action Subsystem3' */
    }

    /* End of If: '<S458>/If' */

    /* Delay: '<S75>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S351>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S351>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_p != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S351>/If Action Subsystem' incorporates:
         *  ActionPort: '<S384>/Action Port'
         */
        /* InitializeConditions for If: '<S351>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S384>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_nm = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S351>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S351>/If Action Subsystem' incorporates:
       *  ActionPort: '<S384>/Action Port'
       */
      /* Sum: '<S384>/Add1' incorporates:
       *  Memory: '<S384>/Memory'
       */
      rtb_LL_LDW_EarliestWarnLine_C = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_nm;

      /* Saturate: '<S384>/Saturation' */
      if (rtb_LL_LDW_EarliestWarnLine_C > 10.0F) {
        rtb_LL_LDW_EarliestWarnLine_C = 10.0F;
      } else {
        if (rtb_LL_LDW_EarliestWarnLine_C < 0.0F) {
          rtb_LL_LDW_EarliestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S384>/Saturation' */
      /* End of Outputs for SubSystem: '<S351>/If Action Subsystem' */

      /* Switch: '<S543>/Switch64' incorporates:
       *  Constant: '<S543>/LLSMConClb33'
       *
       * Block description for '<S543>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S543>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S351>/If Action Subsystem' incorporates:
       *  ActionPort: '<S384>/Action Port'
       */
      /* RelationalOperator: '<S384>/Relational Operator' */
      rtb_Merge = (rtb_LL_LDW_EarliestWarnLine_C >= x10);

      /* Update for Memory: '<S384>/Memory' */
      LKAS_DW.Memory_PreviousInput_nm = rtb_LL_LDW_EarliestWarnLine_C;

      /* End of Outputs for SubSystem: '<S351>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S351>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S385>/Action Port'
       */
      /* SignalConversion: '<S385>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S385>/Constant'
       */
      rtb_Merge = false;

      /* End of Outputs for SubSystem: '<S351>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S351>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S352>/Logical Operator1' incorporates:
     *  Constant: '<S386>/Constant'
     *  Logic: '<S352>/Logical Operator'
     *  RelationalOperator: '<S352>/Relational Operator1'
     *  RelationalOperator: '<S352>/Relational Operator2'
     *  RelationalOperator: '<S386>/Compare'
     */
    rtb_LogicalOperator3_i = ((LKAS_DW.Divide >= ((uint8)1U)) && ((rtb_Gain1 <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_h <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S349>/Logical Operator3' */
    rtb_LogicalOperator3_l = ((rtb_LogicalOperator3_i || rtb_Merge) ||
      rtb_LogicalOperator3_l);

    /* If: '<S349>/If1' incorporates:
     *  Constant: '<S359>/Constant'
     *  DataTypeConversion: '<S349>/Cast To Single'
     *  DataTypeConversion: '<S349>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
        rtb_LogicalOperator3_l) {
      /* Outputs for IfAction SubSystem: '<S349>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S359>/Action Port'
       */
      LKAS_DW.Merge1_j = true;

      /* End of Outputs for SubSystem: '<S349>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S349>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S361>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_j);

      /* End of Outputs for SubSystem: '<S349>/If Action Subsystem4' */
    }

    /* End of If: '<S349>/If1' */

    /* Memory: '<S278>/Memory' */
    rtb_Memory_m = LKAS_DW.Memory_PreviousInput_fe;

    /* If: '<S278>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_Saturation_eo >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S278>/Ph1SWA' incorporates:
       *  ActionPort: '<S282>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S278>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_Saturation_eo <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S278>/Ph2SWA' incorporates:
       *  ActionPort: '<S283>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S278>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S278>/Ph3SWA' incorporates:
       *  ActionPort: '<S284>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_m, &rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S278>/Ph3SWA' */
    }

    /* End of If: '<S278>/If' */

    /* Product: '<S274>/Divide2' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_ThresDet_coefficient_f *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S274>/Divide3' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient_f *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S280>/Divide' */
    rtb_Divide_p = rtb_LL_ThresDet_lDvtThresUprLKA * x1;

    /* Product: '<S274>/Divide1' */
    x10 = rtb_ThresDet_coefficient_f * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S285>/Switch' incorporates:
     *  RelationalOperator: '<S285>/UpperRelop'
     */
    if (rtb_Divide_p < x10) {
      rtb_Switch_bb = x10;
    } else {
      rtb_Switch_bb = rtb_Divide_p;
    }

    /* End of Switch: '<S285>/Switch' */

    /* Switch: '<S285>/Switch2' incorporates:
     *  RelationalOperator: '<S285>/LowerRelop1'
     */
    if (rtb_Divide_p > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_kb = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_kb = rtb_Switch_bb;
    }

    /* End of Switch: '<S285>/Switch2' */

    /* Product: '<S281>/Divide' */
    rtb_Divide_jg = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LogicalOperator3_f_tmp;

    /* Switch: '<S286>/Switch' incorporates:
     *  RelationalOperator: '<S286>/UpperRelop'
     */
    if (rtb_Divide_jg < x10) {
      rtb_Switch_m = x10;
    } else {
      rtb_Switch_m = rtb_Divide_jg;
    }

    /* End of Switch: '<S286>/Switch' */

    /* Switch: '<S286>/Switch2' incorporates:
     *  RelationalOperator: '<S286>/LowerRelop1'
     */
    if (rtb_Divide_jg > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_nt = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_nt = rtb_Switch_m;
    }

    /* End of Switch: '<S286>/Switch2' */

    /* Switch: '<S279>/Switch3' incorporates:
     *  Gain: '<S279>/Gain1'
     *  RelationalOperator: '<S281>/Relational Operator2'
     */
    if (rtb_Merge1_j >= 0.0F) {
      /* Switch: '<S279>/Switch2' incorporates:
       *  Constant: '<S279>/Constant2'
       *  DataTypeConversion: '<S279>/Cast To Single'
       *  RelationalOperator: '<S280>/Relational Operator2'
       */
      if (rtb_Merge1_j > 0.0F) {
        rtb_IMAPve_d_BCM_Right_Light = (uint8)((rtb_Saturation5 <=
          rtb_Switch2_kb) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_Right_Light = ((uint8)0U);
      }

      /* End of Switch: '<S279>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_Right_Light = (uint8)((((uint32)
        ((rtb_LL_LKA_EarliestWarnLine_C <= rtb_Switch2_nt) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S279>/Switch3' */

    /* If: '<S264>/If' incorporates:
     *  Constant: '<S268>/Constant'
     *  Constant: '<S270>/Constant'
     *  Constant: '<S271>/Constant'
     */
    if ((((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
         (((sint32)rtb_IMAPve_d_BCM_Right_Light) == 1)) && (((sint32)
          rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S264>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S270>/Action Port'
       */
      LKAS_DW.Merge_p = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S264>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) ==
      2)) && (((sint32)rtb_IMAPve_d_BCM_Right_Light) == 2)) && (((sint32)
                 rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
      /* Outputs for IfAction SubSystem: '<S264>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S271>/Action Port'
       */
      LKAS_DW.Merge_p = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S264>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S264>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S268>/Action Port'
       */
      LKAS_DW.Merge_p = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S264>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S264>/If' */

    /* Memory: '<S314>/Memory' */
    rtb_Memory_i = LKAS_DW.Memory_PreviousInput_g;

    /* If: '<S314>/If' */
    if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_TTLC_pk >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S314>/Ph1SWA' incorporates:
       *  ActionPort: '<S318>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S314>/Ph1SWA' */
    } else if ((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_TTLC_pk <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S314>/Ph2SWA' incorporates:
       *  ActionPort: '<S319>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S314>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S314>/Ph3SWA' incorporates:
       *  ActionPort: '<S320>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_i, &rtb_Merge1_a);

      /* End of Outputs for SubSystem: '<S314>/Ph3SWA' */
    }

    /* End of If: '<S314>/If' */

    /* Product: '<S310>/Divide2' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S310>/Divide3' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Abs: '<S316>/Abs' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = fabsf(rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Product: '<S316>/Divide' */
    rtb_Divide_nw = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;

    /* Product: '<S310>/Divide1' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_ThresDet_coefficient *
      rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S321>/Switch' incorporates:
     *  RelationalOperator: '<S321>/UpperRelop'
     */
    if (rtb_Divide_nw < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_n = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_n = rtb_Divide_nw;
    }

    /* End of Switch: '<S321>/Switch' */

    /* Switch: '<S321>/Switch2' incorporates:
     *  RelationalOperator: '<S321>/LowerRelop1'
     */
    if (rtb_Divide_nw > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_g = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_g = rtb_Switch_n;
    }

    /* End of Switch: '<S321>/Switch2' */

    /* Abs: '<S317>/Abs' */
    rtb_TTLC_pk = fabsf(rtb_TTLC_pk);

    /* Product: '<S317>/Divide' */
    rtb_Divide_d = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_TTLC_pk;

    /* Switch: '<S322>/Switch' incorporates:
     *  RelationalOperator: '<S322>/UpperRelop'
     */
    if (rtb_Divide_d < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) {
      rtb_Switch_af = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      rtb_Switch_af = rtb_Divide_d;
    }

    /* End of Switch: '<S322>/Switch' */

    /* Switch: '<S322>/Switch2' incorporates:
     *  RelationalOperator: '<S322>/LowerRelop1'
     */
    if (rtb_Divide_d > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_p = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_p = rtb_Switch_af;
    }

    /* End of Switch: '<S322>/Switch2' */

    /* Switch: '<S315>/Switch3' incorporates:
     *  Gain: '<S315>/Gain1'
     *  RelationalOperator: '<S317>/Relational Operator2'
     */
    if (rtb_Merge1_a >= 0.0F) {
      /* Switch: '<S315>/Switch2' incorporates:
       *  Constant: '<S315>/Constant2'
       *  DataTypeConversion: '<S315>/Cast To Single'
       *  RelationalOperator: '<S316>/Relational Operator2'
       */
      if (rtb_Merge1_a > 0.0F) {
        rtb_IMAPve_d_BCM_HazardLamp = (uint8)((rtb_LKA_Veh2CamW_C <=
          rtb_Switch2_g) ? 1 : 0);
      } else {
        rtb_IMAPve_d_BCM_HazardLamp = ((uint8)0U);
      }

      /* End of Switch: '<S315>/Switch2' */
    } else {
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((((uint32)
        ((rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_p) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S315>/Switch3' */

    /* If: '<S302>/If' incorporates:
     *  Constant: '<S306>/Constant'
     *  Constant: '<S308>/Constant'
     */
    if (((((sint32)LKAS_DW.Divide) == 1) || (((sint32)LKAS_DW.Divide) == 2)) &&
        (((sint32)rtb_IMAPve_d_BCM_HazardLamp) == 0)) {
      /* Outputs for IfAction SubSystem: '<S302>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S308>/Action Port'
       */
      LKAS_DW.Merge_f = true;

      /* End of Outputs for SubSystem: '<S302>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S302>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S306>/Action Port'
       */
      LKAS_DW.Merge_f = false;

      /* End of Outputs for SubSystem: '<S302>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S302>/If' */

    /* Outputs for Enabled SubSystem: '<S263>/Count_5s3' incorporates:
     *  EnablePort: '<S527>/Enable'
     */
    /* RelationalOperator: '<S512>/Compare' incorporates:
     *  Constant: '<S512>/Constant'
     *  Constant: '<S550>/Constant'
     */
    if (((uint8)0U) == ((uint8)1U)) {
      if (!LKAS_DW.Count_5s3_MODE) {
        /* InitializeConditions for Memory: '<S527>/Memory' */
        LKAS_DW.Memory_PreviousInput_k = 0.0F;
        LKAS_DW.Count_5s3_MODE = true;
      }

      /* Sum: '<S527>/Add' incorporates:
       *  Memory: '<S527>/Memory'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_DW.Memory_PreviousInput_k +
        rtb_LKA_SampleTime;

      /* Saturate: '<S527>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 11.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 11.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S527>/Saturation' */

      /* RelationalOperator: '<S527>/Relational Operator' incorporates:
       *  Constant: '<S527>/Constant1'
       */
      LKAS_DW.RelationalOperator = (rtb_LL_ThresDet_lDvtThresLwrLDW >= ((float32)
        ((uint16)5U)));

      /* Update for Memory: '<S527>/Memory' */
      LKAS_DW.Memory_PreviousInput_k = rtb_LL_ThresDet_lDvtThresLwrLDW;
    } else {
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S527>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S512>/Compare' */
    /* End of Outputs for SubSystem: '<S263>/Count_5s3' */

    /* RelationalOperator: '<S517>/Compare' incorporates:
     *  Constant: '<S517>/Constant'
     */
    rtb_Compare_a2 = (rtb_IMAPve_d_Camera_Status == ((uint8)3U));

    /* Outputs for Enabled SubSystem: '<S263>/Count_5s2' */
    LKAS_Count_5s1(rtb_Compare_a2, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_e, &LKAS_DW.Count_5s2);

    /* End of Outputs for SubSystem: '<S263>/Count_5s2' */

    /* Logic: '<S263>/Logical Operator10' */
    LKAS_DW.LKA_Fault = ((LKAS_DW.RelationalOperator) ||
                         (LKAS_DW.RelationalOperator_e));

    /* Chart: '<S75>/LDW_State_Machine'
     *
     * Block description for '<S75>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* RelationalOperator: '<S516>/Compare' incorporates:
     *  Constant: '<S516>/Constant'
     */
    rtb_Compare_mi = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

    /* Outputs for Enabled SubSystem: '<S263>/Count_5s1' */
    LKAS_Count_5s1(rtb_Compare_mi, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_g, &LKAS_DW.Count_5s1);

    /* End of Outputs for SubSystem: '<S263>/Count_5s1' */

    /* Logic: '<S263>/Logical Operator8' */
    LKAS_DW.LKA_Fault = (((LKAS_DW.RelationalOperator) ||
                          (LKAS_DW.RelationalOperator_e)) ||
                         (LKAS_DW.RelationalOperator_g));

    /* Chart: '<S75>/LKA_State_Machine'
     *
     * Block description for '<S75>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S240>/Subsystem' incorporates:
     *  EnablePort: '<S244>/Enable'
     */
    /* Logic: '<S240>/Logical Operator3' incorporates:
     *  Abs: '<S240>/Abs4'
     *  Abs: '<S240>/Abs5'
     *  Abs: '<S240>/Abs6'
     *  Abs: '<S240>/Abs7'
     *  Constant: '<S240>/Constant'
     *  Constant: '<S240>/Constant1'
     *  Constant: '<S240>/Constant4'
     *  Constant: '<S240>/Constant5'
     *  Constant: '<S242>/Constant'
     *  Constant: '<S243>/Constant'
     *  Logic: '<S240>/Logical Operator'
     *  Logic: '<S240>/Logical Operator1'
     *  Logic: '<S240>/Logical Operator4'
     *  RelationalOperator: '<S240>/Relational Operator'
     *  RelationalOperator: '<S240>/Relational Operator1'
     *  RelationalOperator: '<S240>/Relational Operator2'
     *  RelationalOperator: '<S240>/Relational Operator3'
     *  RelationalOperator: '<S240>/Relational Operator6'
     *  RelationalOperator: '<S240>/Relational Operator7'
     *  RelationalOperator: '<S242>/Compare'
     *  RelationalOperator: '<S243>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_k) <= 0.005F) && (fabsf(rtb_L0_C1) <= 0.005F)) &&
           ((fabsf(rtb_L0_C2_h4) <= 0.0001F) && (fabsf(rtb_L0_C2) <= 0.0001F))) &&
          ((rtb_L0_Q == ((uint8)3U)) && (rtb_R0_Q == ((uint8)3U)))) &&
         (rtb_IMAPve_g_ESC_VehSpd >= 50.0F)) && (rtb_TLft <= 1.0F)) {
      if (!LKAS_DW.Subsystem_MODE_d) {
        /* InitializeConditions for Memory: '<S244>/Memory' */
        LKAS_DW.Memory_PreviousInput_nq = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_d = true;
      }

      /* Sum: '<S244>/Add1' incorporates:
       *  Memory: '<S244>/Memory'
       */
      rtb_Saturation_j = (uint16)(1U + ((uint32)LKAS_DW.Memory_PreviousInput_nq));

      /* Saturate: '<S244>/Saturation' */
      if (rtb_Saturation_j >= ((uint16)3000U)) {
        rtb_Saturation_j = ((uint16)3000U);
      }

      /* End of Saturate: '<S244>/Saturation' */

      /* RelationalOperator: '<S244>/Relational Operator' incorporates:
       *  Constant: '<S240>/Constant3'
       *  DataTypeConversion: '<S244>/Cast To Single1'
       *  Product: '<S240>/Divide'
       */
      LKAS_DW.RelationalOperator_d = (rtb_Saturation_j >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S244>/Memory' */
      LKAS_DW.Memory_PreviousInput_nq = rtb_Saturation_j;
    } else {
      if (LKAS_DW.Subsystem_MODE_d) {
        /* Disable for Outport: '<S244>/Out' */
        LKAS_DW.RelationalOperator_d = false;
        LKAS_DW.Subsystem_MODE_d = false;
      }
    }

    /* End of Logic: '<S240>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S240>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S218>/Subsystem' incorporates:
     *  EnablePort: '<S239>/Enable'
     */
    if (LKAS_DW.RelationalOperator_d) {
      /* Sum: '<S241>/Add2' incorporates:
       *  Constant: '<S241>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S241>/Memory3'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S241>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 50.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 50.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S241>/Saturation' */

      /* Switch: '<S241>/Switch' incorporates:
       *  Constant: '<S239>/Constant'
       *  Product: '<S241>/Divide'
       *  Product: '<S241>/Divide1'
       *  Sum: '<S241>/Add'
       *  Sum: '<S241>/Add1'
       *  UnitDelay: '<S241>/Unit Delay'
       */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 1.0F) {
        rtb_LL_ThresDet_tiTTLCThresLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_IMAPve_g_SW_Angle - LKAS_DW.UnitDelay_DSTATE)) +
          LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_tiTTLCThresLDW = rtb_IMAPve_g_SW_Angle;
      }

      /* End of Switch: '<S241>/Switch' */

      /* Saturate: '<S239>/Saturation' */
      if (rtb_LL_ThresDet_tiTTLCThresLDW > 3.0F) {
        LKAS_DW.Saturation_b = 3.0F;
      } else if (rtb_LL_ThresDet_tiTTLCThresLDW < (-3.0F)) {
        LKAS_DW.Saturation_b = (-3.0F);
      } else {
        LKAS_DW.Saturation_b = rtb_LL_ThresDet_tiTTLCThresLDW;
      }

      /* End of Saturate: '<S239>/Saturation' */

      /* Update for UnitDelay: '<S241>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_tiTTLCThresLDW;

      /* Update for Memory: '<S241>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_ThresDet_lDvtThresLwrLDW;
    }

    /* End of Outputs for SubSystem: '<S218>/Subsystem' */

    /* Saturate: '<S220>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 0.001F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.001F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S220>/Saturation' */

    /* Gain: '<S252>/kph To mps' incorporates:
     *  Gain: '<S253>/kph To mps'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = 0.277777791F * rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S252>/Saturation3' */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 150.0F;
    } else if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 60.0F;
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Saturate: '<S252>/Saturation3' */

    /* Product: '<S252>/Divide1' incorporates:
     *  Constant: '<S252>/Constant'
     */
    rtb_LftTTLC = 0.09F / rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Saturate: '<S252>/Saturation1' */
    if (rtb_LftTTLC > 0.0117F) {
      rtb_LftTTLC = 0.0117F;
    } else {
      if (rtb_LftTTLC < 0.00237F) {
        rtb_LftTTLC = 0.00237F;
      }
    }

    /* End of Saturate: '<S252>/Saturation1' */

    /* Switch: '<S542>/Switch7' incorporates:
     *  Constant: '<S542>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_i != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_i;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S542>/Switch7' */

    /* MATLAB Function: '<S252>/MATLAB Function' incorporates:
     *  Gain: '<S252>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_LftTTLC *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_i) * LKAS_DW.LKA_WhlBaseL_C_p) /
      (rtb_LL_ThresDet_tiTTLCThresLDW * rtb_LL_ThresDet_tiTTLCThresLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S253>/Saturation3' */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 60.0F;
      }
    }

    /* End of Saturate: '<S253>/Saturation3' */

    /* Product: '<S253>/Divide1' incorporates:
     *  Constant: '<S253>/Constant'
     */
    rtb_LL_LDW_LatestWarnLine_C = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S253>/Saturation1' */
    if (rtb_LL_LDW_LatestWarnLine_C > 0.0117F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.0117F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 0.00237F) {
        rtb_LL_LDW_LatestWarnLine_C = 0.00237F;
      }
    }

    /* End of Saturate: '<S253>/Saturation1' */

    /* Switch: '<S542>/Switch4' incorporates:
     *  Constant: '<S542>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_o != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_o;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S542>/Switch4' */

    /* MATLAB Function: '<S253>/MATLAB Function' */
    LKAS_DW.SWARmax = ((((((((rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_i) * LKAS_DW.LKA_WhlBaseL_C_p) /
                        (rtb_LL_ThresDet_tiTTLCThresLDW *
                         rtb_LL_ThresDet_tiTTLCThresLDW)) * 180.0F) / 3.14F;

    /* Outputs for Enabled SubSystem: '<S9>/LKA' incorporates:
     *  EnablePort: '<S73>/Enable'
     *
     * Block description for '<S9>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Sum: '<S213>/Add' incorporates:
     *  Sum: '<S175>/Add1'
     */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_L0_C1_k + rtb_L0_C1;

    /* End of Outputs for SubSystem: '<S9>/LKA' */

    /* Gain: '<S213>/Gain' incorporates:
     *  Sum: '<S213>/Add'
     */
    rtb_phiHdAg = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * 0.5F;

    /* Gain: '<S215>/Gain1' incorporates:
     *  Sum: '<S215>/Add1'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = (rtb_Add_d + rtb_Add_h) * 0.5F;

    /* Switch: '<S217>/Switch' incorporates:
     *  Constant: '<S233>/Constant'
     *  RelationalOperator: '<S233>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_LftTTLC = rtb_LFTTTLC;
    } else {
      rtb_LftTTLC = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S217>/Switch' */

    /* Saturate: '<S217>/Saturation' */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else {
      if (rtb_LftTTLC < 0.5F) {
        rtb_LftTTLC = 0.5F;
      }
    }

    /* End of Saturate: '<S217>/Saturation' */

    /* Product: '<S237>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * rtb_LftTTLC;

    /* Sum: '<S236>/Add' incorporates:
     *  Gain: '<S236>/Gain1'
     *  Product: '<S236>/Product3'
     *  Product: '<S236>/Product4'
     *  Product: '<S236>/Z*Z'
     */
    rtb_Add_em = ((rtb_Add_d_tmp * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C1_k) +
      ((3.0F * rtb_L0_C3_e1) * (rtb_LL_LDW_LatestWarnLine_C *
        rtb_LL_LDW_LatestWarnLine_C));

    /* Switch: '<S217>/Switch1' incorporates:
     *  Constant: '<S234>/Constant'
     *  RelationalOperator: '<S234>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S217>/Switch1' */

    /* Saturate: '<S217>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S217>/Saturation1' */

    /* Product: '<S238>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * rtb_LL_HdAgPrvwT_C;

    /* Sum: '<S235>/Add' incorporates:
     *  Gain: '<S235>/Gain1'
     *  Product: '<S235>/Product3'
     *  Product: '<S235>/Product4'
     *  Product: '<S235>/Z*Z'
     */
    rtb_Add_fq = ((rtb_Add_h_tmp * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C1) +
      ((3.0F * rtb_L0_C3) * (rtb_LL_LDW_LatestWarnLine_C *
        rtb_LL_LDW_LatestWarnLine_C));

    /* Switch: '<S542>/Switch8' incorporates:
     *  Constant: '<S542>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_j != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_j;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S542>/Switch8' */

    /* Product: '<S232>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Product: '<S230>/Z*Z' incorporates:
     *  Product: '<S231>/Z*Z'
     */
    rtb_LL_HdAgPrvwT_C = rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_LDW_LatestWarnLine_C;

    /* Sum: '<S230>/Add' incorporates:
     *  Product: '<S230>/Product'
     *  Product: '<S230>/Product3'
     *  Product: '<S230>/Product4'
     *  Product: '<S230>/Z*Z'
     *  Product: '<S230>/Z*Z*Z'
     */
    rtb_Add_oy = (((rtb_L0_C1_k * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C0_mb) +
                  (rtb_L0_C2_h4 * rtb_LL_HdAgPrvwT_C)) +
      ((rtb_LL_LDW_LatestWarnLine_C * rtb_LL_HdAgPrvwT_C) * rtb_L0_C3_e1);

    /* Sum: '<S231>/Add' incorporates:
     *  Product: '<S231>/Product'
     *  Product: '<S231>/Product3'
     *  Product: '<S231>/Product4'
     *  Product: '<S231>/Z*Z*Z'
     */
    rtb_Add_jt = (((rtb_L0_C1 * rtb_LL_LDW_LatestWarnLine_C) + rtb_R0_C0_c) +
                  (rtb_L0_C2 * rtb_LL_HdAgPrvwT_C)) +
      ((rtb_LL_LDW_LatestWarnLine_C * rtb_LL_HdAgPrvwT_C) * rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S9>/LKA' incorporates:
     *  EnablePort: '<S73>/Enable'
     *
     * Block description for '<S9>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S101>/Memory' */
        LKAS_DW.Memory_PreviousInput_be = 0.0F;

        /* InitializeConditions for Memory: '<S138>/Memory' */
        LKAS_DW.Memory_PreviousInput_mq = ((uint16)0U);

        /* InitializeConditions for Memory: '<S84>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_h = ((uint8)0U);

        /* InitializeConditions for Memory: '<S137>/Memory' */
        LKAS_DW.Memory_PreviousInput_o = ((uint16)0U);

        /* InitializeConditions for Memory: '<S139>/Memory' */
        LKAS_DW.Memory_PreviousInput_h5 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S133>/Memory' */
        LKAS_DW.Memory_PreviousInput_gj = ((uint16)0U);

        /* InitializeConditions for Memory: '<S136>/Memory' */
        LKAS_DW.Memory_PreviousInput_g5 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S135>/Memory' */
        LKAS_DW.Memory_PreviousInput_jr = ((uint16)0U);

        /* InitializeConditions for Memory: '<S134>/Memory' */
        LKAS_DW.Memory_PreviousInput_f1 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S111>/Memory' */
        LKAS_DW.Memory_PreviousInput_fet = 0.0F;

        /* InitializeConditions for Memory: '<S102>/Memory' */
        LKAS_DW.Memory_PreviousInput_m = 0.0F;

        /* InitializeConditions for Memory: '<S103>/Memory' */
        LKAS_DW.Memory_PreviousInput_mv = 0.0F;

        /* InitializeConditions for Memory: '<S100>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_k = 0.0F;

        /* InitializeConditions for Memory: '<S188>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_f = 0.0F;

        /* InitializeConditions for Memory: '<S177>/Memory' */
        LKAS_DW.Memory_PreviousInput_hw = 0.0F;

        /* InitializeConditions for UnitDelay: '<S175>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_m = 0.0F;

        /* InitializeConditions for Memory: '<S182>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_i = 0.0F;

        /* InitializeConditions for Memory: '<S183>/Memory' */
        LKAS_DW.Memory_PreviousInput_oo = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S187>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_j = 0.0F;

        /* InitializeConditions for Memory: '<S187>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_b = 0.0F;

        /* InitializeConditions for UnitDelay: '<S170>/Delay Input2'
         *
         * Block description for '<S170>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_h = 0.0F;

        /* InitializeConditions for Memory: '<S170>/Memory' */
        LKAS_DW.Memory_PreviousInput_mk = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S91>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S91>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S103>/Moving Standard Deviation1' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S103>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S103>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2_g);

        /* End of SystemReset for SubSystem: '<S103>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Sum: '<S101>/Add2' incorporates:
       *  Memory: '<S101>/Memory'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_be;

      /* Saturate: '<S101>/Saturation2' */
      if (rtb_LftTTLC > 20.0F) {
        rtb_Saturation2 = 20.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation2 = 0.0F;
      } else {
        rtb_Saturation2 = rtb_LftTTLC;
      }

      /* End of Saturate: '<S101>/Saturation2' */

      /* Saturate: '<S101>/Saturation' */
      if (rtb_TTLC > 0.004F) {
        rtb_LftTTLC = 0.004F;
      } else if (rtb_TTLC < 0.0F) {
        rtb_LftTTLC = 0.0F;
      } else {
        rtb_LftTTLC = rtb_TTLC;
      }

      /* End of Saturate: '<S101>/Saturation' */

      /* RelationalOperator: '<S101>/Relational Operator4' incorporates:
       *  Constant: '<S101>/Constant'
       *  Constant: '<S101>/Constant1'
       *  Product: '<S101>/Divide'
       *  Sum: '<S101>/Add'
       */
      rtb_Compare_mt = (rtb_Saturation2 >= ((((rtb_LL_LKAExPrcs_tiExitTime1 *
        0.5F) * rtb_LftTTLC) / 0.004F) + rtb_LL_LKAExPrcs_tiExitTime1));

      /* Sum: '<S138>/Add' incorporates:
       *  Constant: '<S138>/Constant'
       *  Memory: '<S138>/Memory'
       */
      rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_mq));

      /* Saturate: '<S138>/Saturation1' */
      if (rtb_Saturation_j < ((uint16)10000U)) {
        rtb_Saturation1_b = rtb_Saturation_j;
      } else {
        rtb_Saturation1_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S138>/Saturation1' */

      /* If: '<S138>/If' incorporates:
       *  Constant: '<S138>/Constant2'
       */
      if (rtb_Saturation1_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S138>/if action ' incorporates:
         *  ActionPort: '<S155>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_SW_Angle, &LKAS_DW.In_pt);

        /* End of Outputs for SubSystem: '<S138>/if action ' */
      }

      /* End of If: '<S138>/If' */

      /* Sum: '<S84>/Add' incorporates:
       *  Constant: '<S84>/Constant'
       *  Memory: '<S84>/Memory1'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_h));

      /* Saturate: '<S84>/Saturation1' */
      if (rtb_IMAPve_d_BCM_HazardLamp < ((uint8)5U)) {
        rtb_Saturation1_h = rtb_IMAPve_d_BCM_HazardLamp;
      } else {
        rtb_Saturation1_h = ((uint8)5U);
      }

      /* End of Saturate: '<S84>/Saturation1' */

      /* Saturate: '<S110>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S110>/Saturation3' */

      /* Product: '<S110>/Divide1' incorporates:
       *  Constant: '<S110>/Constant'
       */
      rtb_LftTTLC = 0.09F / x10;

      /* Saturate: '<S110>/Saturation1' */
      if (rtb_LftTTLC > 0.0117F) {
        LKAS_DW.StbFacm_SY = 0.0117F;
      } else if (rtb_LftTTLC < 0.00237F) {
        LKAS_DW.StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.StbFacm_SY = rtb_LftTTLC;
      }

      /* End of Saturate: '<S110>/Saturation1' */

      /* Sum: '<S137>/Add' incorporates:
       *  Constant: '<S137>/Constant'
       *  Memory: '<S137>/Memory'
       */
      rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_o));

      /* Saturate: '<S137>/Saturation1' */
      if (rtb_Saturation_j < ((uint16)10000U)) {
        rtb_Saturation1_ja = rtb_Saturation_j;
      } else {
        rtb_Saturation1_ja = ((uint16)10000U);
      }

      /* End of Saturate: '<S137>/Saturation1' */

      /* If: '<S130>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S130>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S142>/Action Port'
         */
        LKAS_ifaction3(rtb_LFTTTLC, &rtb_Merge_m);

        /* End of Outputs for SubSystem: '<S130>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S130>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S141>/Action Port'
         */
        LKAS_ifaction3(rtb_RGTTTLC, &rtb_Merge_m);

        /* End of Outputs for SubSystem: '<S130>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S130>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S143>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_m);

        /* End of Outputs for SubSystem: '<S130>/If Action Subsystem3' */
      }

      /* End of If: '<S130>/If' */

      /* If: '<S137>/If' incorporates:
       *  Constant: '<S137>/Constant2'
       */
      if (rtb_Saturation1_ja == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S137>/if action ' incorporates:
         *  ActionPort: '<S154>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_m, &LKAS_DW.In_i);

        /* End of Outputs for SubSystem: '<S137>/if action ' */
      }

      /* End of If: '<S137>/If' */

      /* Saturate: '<S110>/Saturation2' */
      if (LKAS_DW.In_i > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_i < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_i;
      }

      /* End of Saturate: '<S110>/Saturation2' */

      /* Sum: '<S139>/Add' incorporates:
       *  Constant: '<S139>/Constant'
       *  Memory: '<S139>/Memory'
       */
      rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_h5));

      /* Saturate: '<S139>/Saturation1' */
      if (rtb_Saturation_j < ((uint16)10000U)) {
        rtb_Saturation1_a = rtb_Saturation_j;
      } else {
        rtb_Saturation1_a = ((uint16)10000U);
      }

      /* End of Saturate: '<S139>/Saturation1' */

      /* If: '<S139>/If' incorporates:
       *  Constant: '<S139>/Constant2'
       */
      if (rtb_Saturation1_a == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S139>/if action ' incorporates:
         *  ActionPort: '<S156>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_ESC_VehSpd, &LKAS_DW.In_p);

        /* End of Outputs for SubSystem: '<S139>/if action ' */
      }

      /* End of If: '<S139>/If' */

      /* Sum: '<S133>/Add' incorporates:
       *  Constant: '<S133>/Constant'
       *  Memory: '<S133>/Memory'
       */
      rtb_Add_ba = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_gj));

      /* DataTypeConversion: '<S165>/Data Type Conversion' incorporates:
       *  Constant: '<S166>/Constant'
       *  RelationalOperator: '<S166>/Compare'
       */
      rtb_IMAPve_d_BCM_HazardLamp = (uint8)((rtb_Merge_p <= 0.0F) ? 1 : 0);

      /* Switch: '<S542>/Switch5' incorporates:
       *  Constant: '<S542>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_h;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S542>/Switch5' */

      /* Product: '<S165>/Divide' */
      rtb_Saturation4 = (rtb_Merge_p * rtb_LKA_Veh2CamL_C_tmp) * x10;

      /* Abs: '<S165>/Abs1' incorporates:
       *  Abs: '<S165>/Abs'
       */
      rtb_L0_C3 = fabsf(rtb_Saturation4);
      rtb_Abs1_oh = rtb_L0_C3;

      /* Abs: '<S165>/Abs' */
      rtb_Abs_o = rtb_L0_C3;

      /* If: '<S165>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) && (((sint32)
            rtb_IMAPve_d_BCM_HazardLamp) == 0)) {
        /* Outputs for IfAction SubSystem: '<S165>/If Action Subsystem' incorporates:
         *  ActionPort: '<S167>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_o, &rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S165>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) && (((sint32)
                   rtb_IMAPve_d_BCM_HazardLamp) == 1)) {
        /* Outputs for IfAction SubSystem: '<S165>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S169>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_oh, &rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S165>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S165>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S168>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S165>/If Action Subsystem2' */
      }

      /* End of If: '<S165>/If' */

      /* Switch: '<S542>/Switch6' incorporates:
       *  Constant: '<S542>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_l != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_l;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S542>/Switch6' */

      /* Sum: '<S161>/Add' incorporates:
       *  Sum: '<S102>/Add3'
       *  Sum: '<S103>/Add'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Sum: '<S161>/Add1' incorporates:
       *  Product: '<S161>/Divide'
       *  Product: '<S161>/Divide1'
       *  Sum: '<S161>/Add'
       */
      rtb_Add1_e = (((1.0F / x10) * rtb_LL_LKAExPrcs_tiExitTime1) /
                    rtb_LKA_Veh2CamL_C_tmp) + rtb_Saturation4;

      /* If: '<S113>/If' incorporates:
       *  Constant: '<S164>/Constant2'
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S113>/If Action Subsystem' incorporates:
         *  ActionPort: '<S162>/Action Port'
         */
        /* Gain: '<S162>/Gain2' */
        rtb_Merge_px = (-1.0F) * rtb_Add1_e;

        /* End of Outputs for SubSystem: '<S113>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S113>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S163>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_e, &rtb_Merge_px);

        /* End of Outputs for SubSystem: '<S113>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S113>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S164>/Action Port'
         */
        rtb_Merge_px = 0.0F;

        /* End of Outputs for SubSystem: '<S113>/If Action Subsystem2' */
      }

      /* End of If: '<S113>/If' */

      /* Saturate: '<S133>/Saturation1' */
      if (rtb_Add_ba < ((uint16)10000U)) {
        rtb_Saturation_j = rtb_Add_ba;
      } else {
        rtb_Saturation_j = ((uint16)10000U);
      }

      /* End of Saturate: '<S133>/Saturation1' */

      /* If: '<S133>/If' incorporates:
       *  Constant: '<S133>/Constant2'
       */
      if (rtb_Saturation_j == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S133>/if action ' incorporates:
         *  ActionPort: '<S150>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_px, &LKAS_DW.In_o);

        /* End of Outputs for SubSystem: '<S133>/if action ' */
      }

      /* End of If: '<S133>/If' */

      /* Sum: '<S136>/Add' incorporates:
       *  Constant: '<S136>/Constant'
       *  Memory: '<S136>/Memory'
       */
      rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_g5));

      /* Saturate: '<S136>/Saturation1' */
      if (rtb_Saturation_j < ((uint16)10000U)) {
        rtb_Saturation1_p = rtb_Saturation_j;
      } else {
        rtb_Saturation1_p = ((uint16)10000U);
      }

      /* End of Saturate: '<S136>/Saturation1' */

      /* If: '<S136>/If' incorporates:
       *  Constant: '<S136>/Constant2'
       */
      if (rtb_Saturation1_p == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S136>/if action ' incorporates:
         *  ActionPort: '<S153>/Action Port'
         */
        LKAS_ifaction(rtb_phiHdAg, &LKAS_DW.In_b);

        /* End of Outputs for SubSystem: '<S136>/if action ' */
      }

      /* End of If: '<S136>/If' */

      /* Sum: '<S135>/Add' incorporates:
       *  Constant: '<S135>/Constant'
       *  Memory: '<S135>/Memory'
       */
      rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_jr));

      /* Saturate: '<S135>/Saturation1' */
      if (rtb_Saturation_j < ((uint16)10000U)) {
        rtb_Saturation1_af = rtb_Saturation_j;
      } else {
        rtb_Saturation1_af = ((uint16)10000U);
      }

      /* End of Saturate: '<S135>/Saturation1' */

      /* If: '<S132>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S132>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_oy, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S132>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S132>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_jt, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S132>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S132>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S149>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S132>/If Action Subsystem3' */
      }

      /* End of If: '<S132>/If' */

      /* If: '<S135>/If' incorporates:
       *  Constant: '<S135>/Constant2'
       */
      if (rtb_Saturation1_af == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S135>/if action ' incorporates:
         *  ActionPort: '<S152>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_k, &LKAS_DW.In_bk);

        /* End of Outputs for SubSystem: '<S135>/if action ' */
      }

      /* End of If: '<S135>/If' */

      /* Sum: '<S134>/Add' incorporates:
       *  Constant: '<S134>/Constant'
       *  Memory: '<S134>/Memory'
       */
      rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_f1));

      /* Saturate: '<S134>/Saturation1' */
      if (rtb_Saturation_j < ((uint16)10000U)) {
        rtb_Saturation1_eh = rtb_Saturation_j;
      } else {
        rtb_Saturation1_eh = ((uint16)10000U);
      }

      /* End of Saturate: '<S134>/Saturation1' */

      /* If: '<S131>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S145>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_em, &rtb_Merge_o);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S144>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_fq, &rtb_Merge_o);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_o);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem3' */
      }

      /* End of If: '<S131>/If' */

      /* If: '<S134>/If' incorporates:
       *  Constant: '<S134>/Constant2'
       */
      if (rtb_Saturation1_eh == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S134>/if action ' incorporates:
         *  ActionPort: '<S151>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_o, &LKAS_DW.In_nm);

        /* End of Outputs for SubSystem: '<S134>/if action ' */
      }

      /* End of If: '<S134>/If' */

      /* If: '<S140>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S140>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S158>/Action Port'
         */
        /* SignalConversion: '<S158>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S158>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S140>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S140>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S157>/Action Port'
         */
        /* SignalConversion: '<S157>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S157>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S140>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S140>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S159>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S140>/If Action Subsystem3' */
      }

      /* End of If: '<S140>/If' */

      /* If: '<S84>/If' incorporates:
       *  Constant: '<S84>/Constant19'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem;
      rtAction = -1;
      if (rtb_Saturation1_h == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        if (0 != rtPrevAction) {
          /* SystemReset for IfAction SubSystem: '<S84>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
           *  ActionPort: '<S109>/Action Port'
           *
           * Block description for '<S84>/LKA Motion Planning Calculation (LKAMPCal)':
           *  Block Name: LKA Motion Planning Calculation
           *  Ab.: LKAMPCal
           *  No.: 1.2.3.2
           *  Rev: 0.0.1
           *  Update Date: 19-3-26
           */
          /* SystemReset for If: '<S84>/If' */
          LKAMotionPlanningCalculat_Reset();

          /* End of SystemReset for SubSystem: '<S84>/LKA Motion Planning Calculation (LKAMPCal)' */
        }

        /* Outputs for IfAction SubSystem: '<S84>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S109>/Action Port'
         *
         * Block description for '<S84>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S84>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S84>/If' */

      /* Memory: '<S111>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_fet;

      /* Sum: '<S111>/Add' incorporates:
       *  Gain: '<S111>/Gain1'
       *  Product: '<S111>/Divide'
       *  Product: '<S111>/Product'
       */
      rtb_Add_l3 = ((rtb_LKA_Veh2CamL_C_tmp * rtb_LKA_SampleTime) /
                    (0.277777791F * LKAS_DW.In_p)) + rtb_Saturation4;

      /* MATLAB Function: '<S112>/SWACmd' */
      rtb_SWACmd_phiSWACmd = 0.0F;
      rtb_L0_C3 = (LKAS_DW.K1K2Det_phi2PhSWAIni - LKAS_DW.In_pt) /
        LKAS_DW.K1K2Det_dphi1PhSWAGrad;
      rtb_L0_C3_e1 = ((0.0F - LKAS_DW.K1K2Det_phi2PhSWAIni) /
                      LKAS_DW.K1K2Det_dphi2PhSWAGrad1) + rtb_L0_C3;
      if ((rtb_Add_l3 < rtb_L0_C3) && (rtb_Add_l3 >= 0.0F)) {
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_l3) +
          LKAS_DW.In_pt;
      } else if ((rtb_Add_l3 <= rtb_L0_C3_e1) && (rtb_Add_l3 >= rtb_L0_C3)) {
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_L0_C3) +
          LKAS_DW.In_pt;
      } else {
        if (rtb_Add_l3 >= rtb_L0_C3_e1) {
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_L0_C3) +
            LKAS_DW.In_pt;
        }
      }

      rtb_T2 = rtb_L0_C3_e1;

      /* Saturate: '<S84>/Saturation6' incorporates:
       *  MATLAB Function: '<S112>/SWACmd'
       */
      if (rtb_L0_C3 > 2.0F) {
        rtb_Saturation6 = 2.0F;
      } else if (rtb_L0_C3 < 0.2F) {
        rtb_Saturation6 = 0.2F;
      } else {
        rtb_Saturation6 = rtb_L0_C3;
      }

      /* End of Saturate: '<S84>/Saturation6' */

      /* Memory: '<S102>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_m;

      /* Sum: '<S102>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S102>/Saturation2' */
      if (rtb_Saturation4 > 12.0F) {
        rtb_Saturation2_l = 12.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation2_l = 0.0F;
      } else {
        rtb_Saturation2_l = rtb_Saturation4;
      }

      /* End of Saturate: '<S102>/Saturation2' */

      /* Abs: '<S102>/Abs2' */
      rtb_Saturation4 = fabsf(rtb_Gain1);

      /* Gain: '<S102>/Gain' */
      rtb_L0_C3 = rtb_LL_LKAExPrcs_tiExitTime1 * 0.166666672F;

      /* RelationalOperator: '<S102>/Relational Operator2' */
      rtb_Compare_jo = (rtb_Saturation4 >= rtb_L0_C3);

      /* Abs: '<S102>/Abs3' */
      rtb_Saturation4 = fabsf(rtb_Add5_h);

      /* Outputs for Enabled SubSystem: '<S102>/Sum Condition1' incorporates:
       *  EnablePort: '<S104>/Enable'
       */
      /* Logic: '<S102>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S102>/Relational Operator3'
       *  RelationalOperator: '<S102>/Relational Operator4'
       */
      if (((rtb_Saturation2_l >= rtb_Saturation6) && rtb_Compare_jo) &&
          (rtb_Saturation4 >= rtb_L0_C3)) {
        if (!LKAS_DW.SumCondition1_MODE_a) {
          /* InitializeConditions for Memory: '<S104>/Memory' */
          LKAS_DW.Memory_PreviousInput_e = 0.0F;
          LKAS_DW.SumCondition1_MODE_a = true;
        }

        /* Sum: '<S104>/Add1' incorporates:
         *  Memory: '<S104>/Memory'
         */
        rtb_L0_C3 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_e;

        /* Saturate: '<S104>/Saturation' */
        if (rtb_L0_C3 > 10.0F) {
          rtb_L0_C3 = 10.0F;
        } else {
          if (rtb_L0_C3 < 0.0F) {
            rtb_L0_C3 = 0.0F;
          }
        }

        /* End of Saturate: '<S104>/Saturation' */

        /* Saturate: '<S102>/Saturation' */
        if (rtb_TTLC > 0.004F) {
          rtb_LftTTLC = 0.004F;
        } else if (rtb_TTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        } else {
          rtb_LftTTLC = rtb_TTLC;
        }

        /* End of Saturate: '<S102>/Saturation' */

        /* RelationalOperator: '<S104>/Relational Operator' incorporates:
         *  Constant: '<S102>/Constant'
         *  Constant: '<S102>/Constant1'
         *  Product: '<S102>/Divide'
         *  Sum: '<S102>/Add1'
         */
        LKAS_DW.RelationalOperator_j = (rtb_L0_C3 >=
          ((((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) * rtb_LftTTLC) / 0.004F) +
           rtb_LL_LKAExPrcs_tiExitTime2));

        /* Update for Memory: '<S104>/Memory' */
        LKAS_DW.Memory_PreviousInput_e = rtb_L0_C3;
      } else {
        if (LKAS_DW.SumCondition1_MODE_a) {
          /* Disable for Outport: '<S104>/Out' */
          LKAS_DW.RelationalOperator_j = false;
          LKAS_DW.SumCondition1_MODE_a = false;
        }
      }

      /* End of Logic: '<S102>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S102>/Sum Condition1' */

      /* Memory: '<S103>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_mv;

      /* Sum: '<S103>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S103>/Saturation2' */
      if (rtb_Saturation4 > 10.0F) {
        rtb_Saturation2_e = 10.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation2_e = 0.0F;
      } else {
        rtb_Saturation2_e = rtb_Saturation4;
      }

      /* End of Saturate: '<S103>/Saturation2' */

      /* Gain: '<S103>/Gain' */
      rtb_Saturation4 = rtb_LL_LKAExPrcs_tiExitTime1 * 0.333333343F;

      /* RelationalOperator: '<S103>/Relational Operator2' */
      rtb_Compare_jo = (rtb_Gain1 >= rtb_Saturation4);

      /* RelationalOperator: '<S103>/Relational Operator3' */
      rtb_Compare_pf = (rtb_Add5_h >= rtb_Saturation4);

      /* Abs: '<S103>/Abs4' */
      rtb_Saturation4 = rtb_TTLC;

      /* Saturate: '<S103>/Saturation' */
      if (rtb_Saturation4 > 0.004F) {
        rtb_Saturation4 = 0.004F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S103>/Saturation' */

      /* Switch: '<S542>/Switch45' incorporates:
       *  Constant: '<S542>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S542>/Switch45' */

      /* Sum: '<S103>/Add6' incorporates:
       *  Constant: '<S103>/Constant'
       *  Constant: '<S103>/Constant7'
       *  Product: '<S103>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Saturation4) / 0.004F) + x10;

      /* Outputs for Enabled SubSystem: '<S82>/Subsystem' incorporates:
       *  EnablePort: '<S90>/Enable'
       */
      /* RelationalOperator: '<S89>/Compare' incorporates:
       *  Constant: '<S89>/Constant'
       */
      if (rtb_LL_LKASWASyn_TrqSwaAddSwt > 0.0F) {
        if (!LKAS_DW.Subsystem_MODE_m) {
          LKAS_DW.Subsystem_MODE_m = true;
        }

        /* MATLAB Function: '<S90>/DriverSwaTrqAdd' incorporates:
         *  Switch: '<S542>/Switch42'
         */
        rtb_L0_C3_e1 = fmaxf(fminf(rtb_Add5_h_tmp + rtb_TTLC_h, 5.4F), 2.5F);
        if ((rtb_L0_C3_e1 > 2.5F) && (rtb_L0_C3_e1 < 5.4F)) {
          rtb_LL_LKAExPrcs_tiExitTime2 = rtb_Add5_h_tmp / rtb_L0_C3_e1;
          rtb_L0_C3 = rtb_TTLC_h / rtb_L0_C3_e1;
        } else {
          rtb_LL_LKAExPrcs_tiExitTime2 = 0.5F;
          rtb_L0_C3 = 0.5F;
        }

        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S542>/Switch42' incorporates:
           *  Constant: '<S542>/LL_LKASWASyn_TrqMax=1.5'
           */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S542>/Switch43' incorporates:
           *  Constant: '<S542>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_L0_C3 = (((((180.0F - fmaxf(fminf(rtb_IMAPve_g_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_LL_LKAExPrcs_tiExitTime2) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            /* Switch: '<S542>/Switch42' */
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            /* Switch: '<S542>/Switch42' incorporates:
             *  Constant: '<S542>/LL_LKASWASyn_TrqMax=1.5'
             */
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S542>/Switch43' incorporates:
           *  Constant: '<S542>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_L0_C3 = (((((180.0F - fmaxf(fminf(rtb_IMAPve_g_ESC_VehSpd, 120.0F),
            60.0F)) / 120.0F) * x20) * 2.0F) * rtb_L0_C3) *
            (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S93>/Add2' incorporates:
         *  Constant: '<S93>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S93>/Memory3'
         */
        rtb_L0_C3_e1 = 1.0F + LKAS_DW.Memory3_PreviousInput_kl;

        /* Saturate: '<S93>/Saturation' */
        if (rtb_L0_C3_e1 > 50.0F) {
          rtb_L0_C3_e1 = 50.0F;
        } else {
          if (rtb_L0_C3_e1 < 0.0F) {
            rtb_L0_C3_e1 = 0.0F;
          }
        }

        /* End of Saturate: '<S93>/Saturation' */

        /* Switch: '<S93>/Switch' incorporates:
         *  Product: '<S93>/Divide'
         *  Product: '<S93>/Divide1'
         *  Sum: '<S93>/Add'
         *  Sum: '<S93>/Add1'
         *  UnitDelay: '<S93>/Unit Delay'
         */
        if (rtb_L0_C3_e1 > 1.0F) {
          /* Switch: '<S542>/Switch50' incorporates:
           *  Constant: '<S542>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S542>/Switch50' */
          rtb_L0_C3 = ((rtb_LKA_SampleTime / x10) * (rtb_L0_C3 -
            LKAS_DW.UnitDelay_DSTATE_e)) + LKAS_DW.UnitDelay_DSTATE_e;
        }

        /* End of Switch: '<S93>/Switch' */

        /* SampleTimeMath: '<S96>/TSamp'
         *
         * About '<S96>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_LKAExPrcs_tiExitTime2 = rtb_L0_C3 * 100.0F;

        /* Sum: '<S94>/Add2' incorporates:
         *  Constant: '<S94>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S94>/Memory3'
         */
        rtb_LL_HdAgPrvwT_C = 1.0F + LKAS_DW.Memory3_PreviousInput_p;

        /* Saturate: '<S94>/Saturation' */
        if (rtb_LL_HdAgPrvwT_C > 50.0F) {
          rtb_LL_HdAgPrvwT_C = 50.0F;
        } else {
          if (rtb_LL_HdAgPrvwT_C < 0.0F) {
            rtb_LL_HdAgPrvwT_C = 0.0F;
          }
        }

        /* End of Saturate: '<S94>/Saturation' */

        /* Switch: '<S94>/Switch' incorporates:
         *  Product: '<S94>/Divide'
         *  Product: '<S94>/Divide1'
         *  Sum: '<S94>/Add'
         *  Sum: '<S94>/Add1'
         *  Sum: '<S96>/Diff'
         *  UnitDelay: '<S94>/Unit Delay'
         *  UnitDelay: '<S96>/UD'
         *
         * Block description for '<S96>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S96>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_HdAgPrvwT_C > 2.0F) {
          /* Switch: '<S542>/Switch52' incorporates:
           *  Constant: '<S542>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S542>/Switch52' */
          rtb_LL_LKAExPrcs_tiExitTime1 = (((rtb_LL_LKAExPrcs_tiExitTime2 -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_e4) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_e4;
        } else {
          rtb_LL_LKAExPrcs_tiExitTime1 = rtb_LL_LKAExPrcs_tiExitTime2 -
            LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S94>/Switch' */

        /* Saturate: '<S90>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime1 > 30.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 30.0F;
        } else if (rtb_LL_LKAExPrcs_tiExitTime1 < (-30.0F)) {
          rtb_LL_LDW_LatestWarnLine_C = (-30.0F);
        } else {
          rtb_LL_LDW_LatestWarnLine_C = rtb_LL_LKAExPrcs_tiExitTime1;
        }

        /* End of Saturate: '<S90>/Saturation' */

        /* Switch: '<S542>/Switch53' incorporates:
         *  Constant: '<S542>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S542>/Switch53' */

        /* Sum: '<S95>/Difference Inputs1' incorporates:
         *  Product: '<S90>/Divide1'
         *  Product: '<S90>/Divide3'
         *  Sum: '<S90>/Add'
         *  UnitDelay: '<S95>/Delay Input2'
         *
         * Block description for '<S95>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S95>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_LKASWASyn_TrqSwaAddSwt = (((rtb_LL_LKASWASyn_TrqSwaAddSwt *
          rtb_LL_LDW_LatestWarnLine_C) * x10) + (rtb_LL_LKASWASyn_TrqSwaAddSwt *
          rtb_L0_C3)) - LKAS_DW.DelayInput2_DSTATE_d;

        /* Product: '<S95>/delta rise limit' incorporates:
         *  Constant: '<S90>/Constant1'
         *  SampleTimeMath: '<S95>/sample time'
         *
         * About '<S95>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_LDW_LatestWarnLine_C = 5.0F * 0.01F;

        /* Product: '<S95>/delta fall limit' incorporates:
         *  Constant: '<S90>/Constant2'
         *  SampleTimeMath: '<S95>/sample time'
         *
         * About '<S95>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_Add_d_tmp = (-5.0F) * 0.01F;

        /* Switch: '<S97>/Switch2' incorporates:
         *  Product: '<S95>/delta fall limit'
         *  Product: '<S95>/delta rise limit'
         *  RelationalOperator: '<S97>/LowerRelop1'
         *  RelationalOperator: '<S97>/UpperRelop'
         *  Switch: '<S97>/Switch'
         */
        if (rtb_LL_LKASWASyn_TrqSwaAddSwt > rtb_LL_LDW_LatestWarnLine_C) {
          rtb_LL_LKASWASyn_TrqSwaAddSwt = rtb_LL_LDW_LatestWarnLine_C;
        } else {
          if (rtb_LL_LKASWASyn_TrqSwaAddSwt < rtb_Add_d_tmp) {
            /* Switch: '<S97>/Switch' incorporates:
             *  Product: '<S95>/delta fall limit'
             */
            rtb_LL_LKASWASyn_TrqSwaAddSwt = rtb_Add_d_tmp;
          }
        }

        /* End of Switch: '<S97>/Switch2' */

        /* Sum: '<S95>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S95>/Delay Input2'
         *
         * Block description for '<S95>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S95>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_b = rtb_LL_LKASWASyn_TrqSwaAddSwt +
          LKAS_DW.DelayInput2_DSTATE_d;

        /* Update for UnitDelay: '<S93>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_e = rtb_L0_C3;

        /* Update for Memory: '<S93>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_kl = rtb_L0_C3_e1;

        /* Update for UnitDelay: '<S96>/UD'
         *
         * Block description for '<S96>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for UnitDelay: '<S94>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_e4 = rtb_LL_LKAExPrcs_tiExitTime1;

        /* Update for Memory: '<S94>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_p = rtb_LL_HdAgPrvwT_C;

        /* Update for UnitDelay: '<S95>/Delay Input2'
         *
         * Block description for '<S95>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_d = LKAS_DW.DifferenceInputs2_b;
      } else {
        if (LKAS_DW.Subsystem_MODE_m) {
          /* Disable for Outport: '<S90>/Out1' */
          LKAS_DW.DifferenceInputs2_b = 0.0F;
          LKAS_DW.Subsystem_MODE_m = false;
        }
      }

      /* End of RelationalOperator: '<S89>/Compare' */
      /* End of Outputs for SubSystem: '<S82>/Subsystem' */

      /* Outputs for Atomic SubSystem: '<S91>/Moving Standard Deviation2' */
      rtb_deltafalllimit_j = (float32) LKAS_MovingStandardDeviation2
        (rtb_IMAPve_g_EPS_SW_Trq, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S91>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S103>/Moving Standard Deviation1' */
      rtb_Yk1_o = (float32) LKAS_MovingStandardDeviation2(rtb_Add5_h,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S103>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S103>/Relational Operator6' */
      rtb_RelationalOperator6_m = (rtb_Yk1_o <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S103>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_m, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_k4, &LKAS_DW.SumCondition1_p);

      /* End of Outputs for SubSystem: '<S103>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S103>/Moving Standard Deviation2' */
      rtb_Yk1_o = (float32) LKAS_MovingStandardDeviation2(rtb_Gain1,
        &LKAS_DW.MovingStandardDeviation2_g);

      /* End of Outputs for SubSystem: '<S103>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S103>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Yk1_o <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S103>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_pr, &LKAS_DW.SumCondition_d);

      /* End of Outputs for SubSystem: '<S103>/Sum Condition' */

      /* Switch: '<S542>/Switch46' incorporates:
       *  Constant: '<S542>/LL_LKAExPrcs_ExitC0Swt=1'
       */
      if (LKAS_ConstB.DataTypeConversion35) {
        rtb_IMAPve_d_BCM_Left_Light_0 = LKAS_ConstB.DataTypeConversion35 ? 1 : 0;
      } else {
        rtb_IMAPve_d_BCM_Left_Light_0 = LL_LKAExPrcs_ExitC0Swt ? 1 : 0;
      }

      /* End of Switch: '<S542>/Switch46' */

      /* Logic: '<S103>/Logical Operator2' incorporates:
       *  Logic: '<S103>/Logical Operator1'
       *  RelationalOperator: '<S103>/Relational Operator4'
       */
      rtb_Compare_jo = ((((((rtb_Saturation2_e >= rtb_Saturation6) &&
                            rtb_Compare_jo) && rtb_Compare_pf) &&
                          (LKAS_DW.RelationalOperator_k4)) &&
                         (LKAS_DW.RelationalOperator_pr)) &&
                        (rtb_IMAPve_d_BCM_Left_Light_0 != 0));

      /* Fcn: '<S83>/Fcn' incorporates:
       *  DataTypeConversion: '<S83>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((rtb_Compare_jo ? 1 : 0) *
        (rtb_Compare_jo ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!rtb_Compare_jo) ? 1 : 0)) * (LKAS_DW.RelationalOperator_j ? 1 : 0)) *
        ((sint32)2.0F))) + (((sint32)(((!LKAS_DW.RelationalOperator_j) &&
        (!rtb_Compare_jo)) ? 1 : 0)) * (rtb_Compare_mt ? 1 : 0))));

      /* Logic: '<S83>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_Compare_mt ||
        (LKAS_DW.RelationalOperator_j)) || rtb_Compare_jo);

      /* DataTypeConversion: '<S86>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Switch: '<S542>/Switch18' incorporates:
       *  Constant: '<S542>/LL_LKASWASyn_M3K=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion25;
      } else {
        x10 = LL_LKASWASyn_M3K;
      }

      /* End of Switch: '<S542>/Switch18' */

      /* Product: '<S91>/Divide' */
      rtb_Saturation4 = rtb_deltafalllimit_j * x10;

      /* Saturate: '<S91>/Saturation1' */
      if (rtb_Saturation4 > 0.2F) {
        rtb_Saturation4 = 0.2F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S91>/Saturation1' */

      /* Sum: '<S100>/Add2' incorporates:
       *  Memory: '<S100>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_k;

      /* Saturate: '<S100>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_ka = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_ka = 0.0F;
      } else {
        rtb_Saturation_ka = rtb_LftTTLC;
      }

      /* End of Saturate: '<S100>/Saturation' */

      /* MATLAB Function: '<S91>/MATLAB Function' incorporates:
       *  Constant: '<S542>/LL_LKASWASyn_M2=0.3'
       *  Switch: '<S542>/Switch14'
       */
      if (rtb_Saturation_ka < rtb_Saturation6) {
        rtb_LL_LKASWASyn_M0 += ((rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6) * rtb_Saturation_ka;
      } else if ((rtb_Saturation_ka >= rtb_Saturation6) && (rtb_Saturation_ka <=
                  (rtb_Saturation6 + rtb_LL_LKASWASyn_T2))) {
        /* Switch: '<S542>/Switch14' incorporates:
         *  Constant: '<S542>/LL_LKASWASyn_M2=0.3'
         */
        if (LKAS_ConstB.DataTypeConversion20_b != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_b;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (((x10 - rtb_LL_LKASWASyn_M1) /
          rtb_LL_LKASWASyn_T2) * (rtb_Saturation_ka - rtb_Saturation6)) +
          rtb_LL_LKASWASyn_M1;
      } else if (LKAS_ConstB.DataTypeConversion20_b != 0.0F) {
        /* Switch: '<S542>/Switch14' */
        rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20_b;
      } else {
        rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
      }

      /* End of MATLAB Function: '<S91>/MATLAB Function' */

      /* Sum: '<S91>/Add1' */
      rtb_Saturation4 = rtb_LL_LKASWASyn_M0 - rtb_Saturation4;

      /* Saturate: '<S91>/Saturation2' */
      if (rtb_Saturation4 > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        LKAS_DW.Saturation2 = 0.0F;
      } else {
        LKAS_DW.Saturation2 = rtb_Saturation4;
      }

      /* End of Saturate: '<S91>/Saturation2' */

      /* Memory: '<S188>/Memory3' */
      rtb_Saturation4 = LKAS_DW.Memory3_PreviousInput_f;

      /* Sum: '<S188>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S188>/Saturation' */
      if (rtb_Saturation4 > 50.0F) {
        rtb_Saturation_kz = 50.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation_kz = 0.0F;
      } else {
        rtb_Saturation_kz = rtb_Saturation4;
      }

      /* End of Saturate: '<S188>/Saturation' */

      /* If: '<S186>/If' incorporates:
       *  DataTypeConversion: '<S73>/Cast To Single'
       *  Inport: '<S194>/Plan'
       *  Inport: '<S194>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_o;
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_o = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S186>/If Action Subsystem' incorporates:
           *  ActionPort: '<S192>/Action Port'
           */
          /* InitializeConditions for If: '<S186>/If' incorporates:
           *  Memory: '<S192>/Memory'
           *  UnitDelay: '<S196>/Delay Input1'
           *
           * Block description for '<S196>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_a = false;
          LKAS_DW.Memory_PreviousInput_g0 = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S186>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S186>/If Action Subsystem' incorporates:
         *  ActionPort: '<S192>/Action Port'
         */
        /* RelationalOperator: '<S195>/Compare' incorporates:
         *  Constant: '<S195>/Constant'
         */
        rtb_Compare_mt = (rtb_L0_C1_k >= 0.0F);

        /* Memory: '<S192>/Memory' */
        rtb_Plan_l = LKAS_DW.Memory_PreviousInput_g0;

        /* Sum: '<S192>/Add' incorporates:
         *  Logic: '<S192>/Logical Operator'
         *  RelationalOperator: '<S192>/Relational Operator'
         *  RelationalOperator: '<S196>/FixPt Relational Operator'
         *  UnitDelay: '<S196>/Delay Input1'
         *
         * Block description for '<S196>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_f = ((float32)(((((sint32)(rtb_Compare_mt ? 1 : 0)) < ((sint32)
          (LKAS_DW.DelayInput1_DSTATE_a ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_kz)) ? 1 : 0)) + rtb_Plan_l;

        /* Saturate: '<S192>/Saturation' */
        if (rtb_T1_f > 5.0F) {
          rtb_Saturation_ph = 5.0F;
        } else if (rtb_T1_f < 0.0F) {
          rtb_Saturation_ph = 0.0F;
        } else {
          rtb_Saturation_ph = rtb_T1_f;
        }

        /* End of Saturate: '<S192>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S192>/If Action Subsystem' */
        LKAS_IfActionSubsystem_h(rtb_Saturation_ph, rtb_Saturation_kz,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_c, &LKAS_DW.In_l,
          &LKAS_DW.IfActionSubsystem_h);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S192>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_k(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_f, &rtb_Plan_l);

        /* End of Outputs for SubSystem: '<S192>/If Action Subsystem2' */

        /* Switch: '<S192>/Switch' incorporates:
         *  Switch: '<S192>/Switch1'
         */
        if (rtb_Saturation_ph > 0.0F) {
          LKAS_DW.Merge_j = LKAS_DW.In_c;
          LKAS_DW.Merge1 = LKAS_DW.In_l;
        } else {
          LKAS_DW.Merge_j = rtb_T1_f;
          LKAS_DW.Merge1 = rtb_Plan_l;
        }

        /* End of Switch: '<S192>/Switch' */

        /* Update for UnitDelay: '<S196>/Delay Input1'
         *
         * Block description for '<S196>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_a = rtb_Compare_mt;

        /* Update for Memory: '<S192>/Memory' */
        LKAS_DW.Memory_PreviousInput_g0 = rtb_Saturation_ph;

        /* End of Outputs for SubSystem: '<S186>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S186>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S193>/Action Port'
           */
          /* InitializeConditions for If: '<S186>/If' incorporates:
           *  Memory: '<S193>/Memory'
           *  UnitDelay: '<S204>/Delay Input1'
           *
           * Block description for '<S204>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_i = false;
          LKAS_DW.Memory_PreviousInput_aa = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S186>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S186>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S193>/Action Port'
         */
        /* RelationalOperator: '<S203>/Compare' incorporates:
         *  Constant: '<S203>/Constant'
         */
        rtb_Compare_mt = (rtb_L0_C1 <= 0.0F);

        /* Memory: '<S193>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_aa;

        /* Sum: '<S193>/Add' incorporates:
         *  Logic: '<S193>/Logical Operator'
         *  RelationalOperator: '<S193>/Relational Operator'
         *  RelationalOperator: '<S204>/FixPt Relational Operator'
         *  UnitDelay: '<S204>/Delay Input1'
         *
         * Block description for '<S204>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_n = ((float32)(((((sint32)(rtb_Compare_mt ? 1 : 0)) < ((sint32)
          (LKAS_DW.DelayInput1_DSTATE_i ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_kz)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S193>/Saturation' */
        if (rtb_T1_n > 5.0F) {
          rtb_Saturation_p1 = 5.0F;
        } else if (rtb_T1_n < 0.0F) {
          rtb_Saturation_p1 = 0.0F;
        } else {
          rtb_Saturation_p1 = rtb_T1_n;
        }

        /* End of Saturate: '<S193>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S193>/If Action Subsystem' */
        LKAS_IfActionSubsystem_h(rtb_Saturation_p1, rtb_Saturation_kz,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_n, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_a);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S193>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_k(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_n, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S193>/If Action Subsystem2' */

        /* Switch: '<S193>/Switch' incorporates:
         *  Switch: '<S193>/Switch1'
         */
        if (rtb_Saturation_p1 > 0.0F) {
          LKAS_DW.Merge_j = LKAS_DW.In_n;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_j = rtb_T1_n;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S193>/Switch' */

        /* Update for UnitDelay: '<S204>/Delay Input1'
         *
         * Block description for '<S204>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_i = rtb_Compare_mt;

        /* Update for Memory: '<S193>/Memory' */
        LKAS_DW.Memory_PreviousInput_aa = rtb_Saturation_p1;

        /* End of Outputs for SubSystem: '<S186>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S186>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S194>/Action Port'
         */
        LKAS_DW.Merge_j = rtb_Saturation6;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S186>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S186>/If' */

      /* Product: '<S88>/Divide3' */
      rtb_Saturation4 = rtb_Saturation_kz / LKAS_DW.Merge_j;

      /* Saturate: '<S88>/Saturation' */
      if (rtb_Saturation4 > 1.0F) {
        rtb_Saturation4 = 1.0F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S88>/Saturation' */

      /* Product: '<S88>/Divide6' */
      rtb_LL_LKASWASyn_M0 = LKAS_DW.DifferenceInputs2_b * rtb_Saturation4;

      /* Saturate: '<S88>/Saturation6' */
      if (LKAS_DW.Merge_j > 0.5F) {
        rtb_Saturation4 = 0.5F;
      } else if (LKAS_DW.Merge_j < 0.2F) {
        rtb_Saturation4 = 0.2F;
      } else {
        rtb_Saturation4 = LKAS_DW.Merge_j;
      }

      /* End of Saturate: '<S88>/Saturation6' */

      /* Product: '<S88>/Divide' incorporates:
       *  Product: '<S189>/Divide'
       *  Product: '<S88>/Divide4'
       *  Sum: '<S88>/Add2'
       */
      rtb_TTLC_h = (rtb_Saturation_kz - LKAS_DW.Merge_j) / rtb_Saturation4;

      /* Saturate: '<S88>/Saturation2' incorporates:
       *  Product: '<S88>/Divide'
       */
      if (rtb_TTLC_h > 1.0F) {
        rtb_L0_C3 = 1.0F;
      } else if (rtb_TTLC_h < 0.0F) {
        rtb_L0_C3 = 0.0F;
      } else {
        rtb_L0_C3 = rtb_TTLC_h;
      }

      /* End of Saturate: '<S88>/Saturation2' */

      /* Sum: '<S177>/Add1' incorporates:
       *  Gain: '<S217>/Gain2'
       *  Memory: '<S177>/Memory'
       *  Product: '<S177>/Divide'
       *  Product: '<S177>/Divide1'
       *  Sum: '<S217>/Add2'
       */
      rtb_Add1_m = (((rtb_Add_em + rtb_Add_fq) * 0.5F) * LKAS_ConstB.Divide2_l)
        + (LKAS_ConstB.Add2_fv * LKAS_DW.Memory_PreviousInput_hw);

      /* MATLAB Function: '<S175>/Saturable Gain Lut (SatGainLut)' incorporates:
       *  Switch: '<S542>/Switch35'
       */
      if (rtb_IMAPve_g_ESC_VehSpd > rtb_R0_C2) {
        if (rtb_IMAPve_g_ESC_VehSpd >= rtb_Saturation_mg) {
          /* Switch: '<S542>/Switch35' incorporates:
           *  Constant: '<S542>/LL_LFClb_TFC_facmGainLutGain2_C=40'
           */
          if (LKAS_ConstB.DataTypeConversion17_o != 0.0F) {
            rtb_LL_LFClb_TFC_facmGainLutGai = LKAS_ConstB.DataTypeConversion17_o;
          } else {
            rtb_LL_LFClb_TFC_facmGainLutGai = LL_LFClb_TFC_facmGainLutGain2_C;
          }
        } else {
          if (LKAS_ConstB.DataTypeConversion17_o != 0.0F) {
            /* Switch: '<S542>/Switch35' */
            x10 = LKAS_ConstB.DataTypeConversion17_o;
          } else {
            /* Switch: '<S542>/Switch35' incorporates:
             *  Constant: '<S542>/LL_LFClb_TFC_facmGainLutGain2_C=40'
             */
            x10 = LL_LFClb_TFC_facmGainLutGain2_C;
          }

          rtb_LL_LFClb_TFC_facmGainLutGai += ((rtb_IMAPve_g_ESC_VehSpd -
            rtb_R0_C2) / (rtb_Saturation_mg - rtb_R0_C2)) * (x10 -
            rtb_LL_LFClb_TFC_facmGainLutGai);
        }
      }

      /* End of MATLAB Function: '<S175>/Saturable Gain Lut (SatGainLut)' */

      /* Switch: '<S542>/Switch32' incorporates:
       *  Constant: '<S542>/LL_LFClb_TFC_tiKlatPrvwT_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion15_a != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_a;
      } else {
        x10 = LL_LFClb_TFC_tiKlatPrvwT_C;
      }

      /* End of Switch: '<S542>/Switch32' */

      /* Product: '<S175>/Divide1' */
      rtb_LftTTLC = x10 * rtb_LKA_Veh2CamL_C_tmp;

      /* Switch: '<S542>/Switch30' incorporates:
       *  Constant: '<S542>/LL_LFClb_TFC_facmKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_g != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_g;
      } else {
        x10 = LL_LFClb_TFC_facmKlat_C;
      }

      /* End of Switch: '<S542>/Switch30' */

      /* Saturate: '<S175>/Saturation' */
      if (rtb_LftTTLC > 40.0F) {
        rtb_LftTTLC = 40.0F;
      } else {
        if (rtb_LftTTLC < 5.0F) {
          rtb_LftTTLC = 5.0F;
        }
      }

      /* End of Saturate: '<S175>/Saturation' */

      /* Product: '<S175>/Product4' incorporates:
       *  Gain: '<S216>/Gain1'
       *  Product: '<S175>/Divide'
       *  Product: '<S175>/Product1'
       *  Sum: '<S175>/Subtract1'
       *  Sum: '<S216>/Add1'
       */
      rtb_R0_C2 = (((((rtb_Add_oy + rtb_Add_jt) * 0.5F) / rtb_LftTTLC) * x10) -
                   rtb_Add1_m) * rtb_LL_LFClb_TFC_facmGainLutGai;

      /* Saturate: '<S175>/Saturation2' */
      if (rtb_R0_C2 > 360.0F) {
        rtb_deltafalllimit_j = 360.0F;
      } else if (rtb_R0_C2 < (-360.0F)) {
        rtb_deltafalllimit_j = (-360.0F);
      } else {
        rtb_deltafalllimit_j = rtb_R0_C2;
      }

      /* End of Saturate: '<S175>/Saturation2' */

      /* Abs: '<S175>/Abs' incorporates:
       *  Gain: '<S215>/Gain1'
       */
      rtb_Yk1_o = fabsf(rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Saturate: '<S175>/Saturation1' */
      rtb_LftTTLC = rtb_Yk1_o;
      if (rtb_LftTTLC > 0.004F) {
        rtb_Yk1_o = 0.004F;
      } else if (rtb_LftTTLC < 1.0E-5F) {
        rtb_Yk1_o = 1.0E-5F;
      } else {
        rtb_Yk1_o = rtb_LftTTLC;
      }

      /* End of Saturate: '<S175>/Saturation1' */

      /* Switch: '<S542>/Switch39' incorporates:
       *  Constant: '<S542>/LL_LFClb_TFC_phiIntegCtlMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_phiIntegCtlMaxSWA_C;
      }

      /* End of Switch: '<S542>/Switch39' */

      /* Sum: '<S175>/Add3' incorporates:
       *  Constant: '<S175>/Constant3'
       *  Constant: '<S175>/Constant4'
       *  Product: '<S175>/Divide4'
       *  Sum: '<S175>/Add5'
       */
      rtb_Yk1_o = (((x10 - 1.0F) * rtb_Yk1_o) / 0.004F) + 1.0F;

      /* Sum: '<S182>/Add2' incorporates:
       *  Memory: '<S182>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_i;

      /* Saturate: '<S182>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_h = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_h = 0.0F;
      } else {
        rtb_Saturation_h = rtb_LftTTLC;
      }

      /* End of Saturate: '<S182>/Saturation' */

      /* Switch: '<S175>/Switch2' incorporates:
       *  Product: '<S175>/Divide2'
       *  Sum: '<S175>/Add'
       *  Sum: '<S175>/Add2'
       *  Switch: '<S542>/Switch40'
       *  UnitDelay: '<S175>/Unit Delay'
       */
      if ((rtb_Saturation_h - rtb_Saturation6) >= 0.0F) {
        /* Switch: '<S542>/Switch40' incorporates:
         *  Constant: '<S542>/LL_LFClb_TFC_facmIntegRatio=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_facmIntegRatio;
        }

        rtb_Switch2_gw = (rtb_R0_C2 * x10) + LKAS_DW.UnitDelay_DSTATE_m;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S542>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S542>/Switch40' incorporates:
           *  Constant: '<S542>/LL_LFClb_TFC_facmIntegRatio=0.01'
           */
          x10 = LL_LFClb_TFC_facmIntegRatio;
        }

        rtb_Switch2_gw = rtb_R0_C2 * x10;
      }

      /* End of Switch: '<S175>/Switch2' */

      /* Gain: '<S175>/Gain' */
      rtb_R0_C2 = (-1.0F) * rtb_Yk1_o;

      /* Switch: '<S179>/Switch' incorporates:
       *  RelationalOperator: '<S179>/UpperRelop'
       */
      if (rtb_Switch2_gw < rtb_R0_C2) {
        rtb_Switch_p = rtb_R0_C2;
      } else {
        rtb_Switch_p = rtb_Switch2_gw;
      }

      /* End of Switch: '<S179>/Switch' */

      /* Switch: '<S179>/Switch2' incorporates:
       *  RelationalOperator: '<S179>/LowerRelop1'
       */
      if (rtb_Switch2_gw > rtb_Yk1_o) {
        rtb_Switch2_f = rtb_Yk1_o;
      } else {
        rtb_Switch2_f = rtb_Switch_p;
      }

      /* End of Switch: '<S179>/Switch2' */

      /* Sum: '<S88>/Add3' */
      rtb_R0_C2 = rtb_deltafalllimit_j + rtb_Switch2_f;

      /* Switch: '<S542>/Switch49' incorporates:
       *  Constant: '<S542>/LL_LFClb_TFC_DiffCtrlMaxSWA=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_DiffCtrlMaxSWA;
      }

      /* End of Switch: '<S542>/Switch49' */

      /* Product: '<S175>/Divide8' incorporates:
       *  Constant: '<S175>/Constant7'
       *  Constant: '<S175>/Constant8'
       *  Sum: '<S175>/Add4'
       */
      rtb_Yk1_o = ((180.0F - rtb_LKA_Veh2CamL_C_tmp) * x10) / 120.0F;

      /* Sum: '<S183>/Add' incorporates:
       *  Constant: '<S183>/Constant'
       *  Memory: '<S183>/Memory'
       */
      rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_oo));

      /* Saturate: '<S183>/Saturation1' */
      if (rtb_Saturation_j < ((uint16)10000U)) {
        rtb_Saturation1_kk = rtb_Saturation_j;
      } else {
        rtb_Saturation1_kk = ((uint16)10000U);
      }

      /* End of Saturate: '<S183>/Saturation1' */

      /* If: '<S183>/If' incorporates:
       *  Constant: '<S183>/Constant2'
       *  DataTypeConversion: '<S73>/Cast To Single'
       *  Inport: '<S184>/In'
       */
      if (rtb_Saturation1_kk == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S183>/if action ' incorporates:
         *  ActionPort: '<S184>/Action Port'
         */
        LKAS_DW.In_e = LKAS_DW.LKASM_stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S183>/if action ' */
      }

      /* End of If: '<S183>/If' */

      /* Sum: '<S181>/Add2' */
      rtb_deltafalllimit_j = rtb_L0_C0_mb + rtb_R0_C0_c;

      /* Saturate: '<S181>/Saturation' */
      rtb_Saturation_mg = rtb_deltafalllimit_j;
      if (rtb_Saturation_mg > 2.0F) {
        rtb_Saturation_mg = 2.0F;
      } else {
        if (rtb_Saturation_mg < (-2.0F)) {
          rtb_Saturation_mg = (-2.0F);
        }
      }

      /* End of Saturate: '<S181>/Saturation' */

      /* Abs: '<S181>/Abs5' */
      rtb_deltafalllimit_j = rtb_Add5_h_tmp;

      /* Switch: '<S542>/Switch9' incorporates:
       *  Constant: '<S542>/LL_LFClb_TFC_DiffCtlBalance=1.2'
       */
      if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion9;
      } else {
        x10 = LL_LFClb_TFC_DiffCtlBalance;
      }

      /* End of Switch: '<S542>/Switch9' */

      /* Sum: '<S181>/Add6' incorporates:
       *  Abs: '<S181>/Abs7'
       */
      rtb_L0_C0_mb = (rtb_deltafalllimit_j + fabsf(rtb_R0_C0_c)) - x10;

      /* Switch: '<S181>/Switch1' incorporates:
       *  Constant: '<S181>/Constant3'
       *  Product: '<S181>/Divide4'
       *  Product: '<S181>/Divide5'
       *  Sum: '<S181>/Add5'
       *  Switch: '<S181>/Switch'
       */
      if (LKAS_DW.In_e > ((uint8)1U)) {
        rtb_deltafalllimit_j = ((rtb_Saturation_mg / rtb_L0_C0_mb) + 1.0F) *
          rtb_R0_C3;
      } else if (LKAS_DW.In_e >= ((uint8)1U)) {
        /* Switch: '<S181>/Switch' incorporates:
         *  Constant: '<S181>/Constant2'
         *  Product: '<S181>/Divide1'
         *  Product: '<S181>/Divide2'
         *  Sum: '<S181>/Add1'
         *  UnaryMinus: '<S181>/Unary Minus'
         */
        rtb_deltafalllimit_j = (((-rtb_Saturation_mg) / rtb_L0_C0_mb) + 1.0F) *
          rtb_R0_C3;
      } else {
        /* Switch: '<S181>/Switch' */
        rtb_deltafalllimit_j = rtb_R0_C3;
      }

      /* End of Switch: '<S181>/Switch1' */

      /* Saturate: '<S181>/Saturation1' */
      rtb_LftTTLC = rtb_deltafalllimit_j;
      if (rtb_LftTTLC > 1000.0F) {
        rtb_deltafalllimit_j = 1000.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_deltafalllimit_j = 0.0F;
      } else {
        rtb_deltafalllimit_j = rtb_LftTTLC;
      }

      /* End of Saturate: '<S181>/Saturation1' */

      /* Product: '<S175>/Divide7' incorporates:
       *  Gain: '<S175>/Gain2'
       */
      rtb_Divide7 = (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * (-0.5F)) *
        rtb_deltafalllimit_j;

      /* Gain: '<S175>/Gain3' */
      rtb_deltafalllimit_j = (-1.0F) * rtb_Yk1_o;

      /* Switch: '<S180>/Switch' incorporates:
       *  RelationalOperator: '<S180>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_deltafalllimit_j) {
        rtb_Switch_e1 = rtb_deltafalllimit_j;
      } else {
        rtb_Switch_e1 = rtb_Divide7;
      }

      /* End of Switch: '<S180>/Switch' */

      /* Switch: '<S180>/Switch2' incorporates:
       *  RelationalOperator: '<S180>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_Yk1_o) {
        rtb_Switch2_h = rtb_Yk1_o;
      } else {
        rtb_Switch2_h = rtb_Switch_e1;
      }

      /* End of Switch: '<S180>/Switch2' */

      /* Product: '<S88>/Divide4' */
      rtb_Yk1_o = rtb_TTLC_h;

      /* Saturate: '<S88>/Saturation1' */
      rtb_LftTTLC = rtb_Yk1_o;
      if (rtb_LftTTLC > 1.0F) {
        rtb_Yk1_o = 1.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Yk1_o = 0.0F;
      } else {
        rtb_Yk1_o = rtb_LftTTLC;
      }

      /* End of Saturate: '<S88>/Saturation1' */

      /* Product: '<S88>/Divide2' */
      rtb_L0_C0_mb = rtb_Switch2_h * rtb_Yk1_o;

      /* Product: '<S189>/Divide' */
      rtb_Saturation4 = rtb_TTLC_h;

      /* Saturate: '<S189>/Saturation4' */
      if (rtb_Saturation4 > 1.0F) {
        rtb_Saturation4 = 1.0F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S189>/Saturation4' */

      /* Gain: '<S176>/kph to mps' */
      rtb_Yk1_o = rtb_LKA_Veh2CamL_C_tmp;

      /* Saturate: '<S176>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        rtb_deltafalllimit_j = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        rtb_deltafalllimit_j = 60.0F;
      } else {
        rtb_deltafalllimit_j = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S176>/Saturation3' */

      /* Product: '<S176>/Divide2' incorporates:
       *  Constant: '<S176>/Constant'
       */
      rtb_deltafalllimit_j = 0.09F / rtb_deltafalllimit_j;

      /* Saturate: '<S176>/Saturation1' */
      rtb_LftTTLC = rtb_deltafalllimit_j;
      if (rtb_LftTTLC > 0.01F) {
        rtb_deltafalllimit_j = 0.01F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_deltafalllimit_j = 0.0F;
      } else {
        rtb_deltafalllimit_j = rtb_LftTTLC;
      }

      /* End of Saturate: '<S176>/Saturation1' */

      /* Switch: '<S542>/Switch36' incorporates:
       *  Constant: '<S542>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_d != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_d;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S542>/Switch36' */

      /* Gain: '<S176>/Gain2' incorporates:
       *  Constant: '<S176>/Constant1'
       *  Gain: '<S176>/rad to deg'
       *  Gain: '<S215>/Gain1'
       *  Math: '<S176>/Math Function'
       *  Product: '<S176>/Divide'
       *  Product: '<S176>/Divide1'
       *  Product: '<S176>/Product'
       *  Product: '<S176>/Product1'
       *  Product: '<S176>/Product2'
       *  Product: '<S176>/Product3'
       *  Sum: '<S176>/Add'
       *
       * About '<S176>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_Yk1_o = (((((((rtb_Yk1_o * rtb_Yk1_o) * rtb_deltafalllimit_j) + 1.0F) /
                      (rtb_Yk1_o / LKAS_DW.LKA_WhlBaseL_C_p)) * ((rtb_Yk1_o *
        rtb_LL_ThresDet_tiTTLCThresLDW) * 57.2957802F)) * x10) *
                   LKAS_DW.LKA_StrRatio_C_i) * (-1.0F);

      /* Product: '<S88>/Divide5' incorporates:
       *  Constant: '<S189>/Constant1'
       *  Product: '<S189>/Divide8'
       *  Sum: '<S189>/Add1'
       */
      rtb_deltafalllimit_j = ((LKAS_ConstB.Add3 * rtb_Saturation4) + 0.0F) *
        rtb_Yk1_o;

      /* Sum: '<S88>/Add4' incorporates:
       *  Constant: '<S88>/Constant2'
       *  Product: '<S88>/Divide1'
       *  Product: '<S88>/Divide7'
       *  Sum: '<S88>/Add5'
       */
      rtb_L0_C0_mb = (((((1.0F - rtb_L0_C3) * LKAS_DW.Merge1) + (rtb_L0_C3 *
        rtb_R0_C2)) + rtb_L0_C0_mb) + rtb_deltafalllimit_j) +
        rtb_LL_LKASWASyn_M0;

      /* Memory: '<S187>/Memory3' */
      rtb_deltafalllimit_j = LKAS_DW.Memory3_PreviousInput_b;

      /* Sum: '<S187>/Add2' incorporates:
       *  Constant: '<S187>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_deltafalllimit_j += 1.0F;

      /* Saturate: '<S187>/Saturation' */
      rtb_LftTTLC = rtb_deltafalllimit_j;
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_hf = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_hf = 0.0F;
      } else {
        rtb_Saturation_hf = rtb_LftTTLC;
      }

      /* End of Saturate: '<S187>/Saturation' */

      /* Switch: '<S187>/Switch' incorporates:
       *  Constant: '<S88>/Constant1'
       *  Product: '<S187>/Divide'
       *  Product: '<S187>/Divide1'
       *  Sum: '<S187>/Add'
       *  Sum: '<S187>/Add1'
       *  UnitDelay: '<S187>/Unit Delay'
       */
      if (rtb_Saturation_hf > 30.0F) {
        rtb_Switch_gi = ((rtb_LKA_SampleTime / 0.1F) * (rtb_L0_C0_mb -
          LKAS_DW.UnitDelay_DSTATE_j)) + LKAS_DW.UnitDelay_DSTATE_j;
      } else {
        rtb_Switch_gi = rtb_L0_C0_mb;
      }

      /* End of Switch: '<S187>/Switch' */

      /* Switch: '<S542>/Switch17' incorporates:
       *  Constant: '<S542>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S542>/Switch17' */

      /* Sum: '<S85>/Add' */
      rtb_Add_j1 = (rtb_Switch_gi - x10) + LKAS_DW.Saturation_b;

      /* Sum: '<S85>/Add1' */
      rtb_deltafalllimit_j = rtb_Yk1_o + rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S85>/Add2' incorporates:
       *  Gain: '<S85>/Gain2'
       */
      rtb_Yk1_o += (-1.0F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S171>/Switch' incorporates:
       *  RelationalOperator: '<S171>/UpperRelop'
       */
      if (rtb_Add_j1 < rtb_Yk1_o) {
        rtb_Switch_er = rtb_Yk1_o;
      } else {
        rtb_Switch_er = rtb_Add_j1;
      }

      /* End of Switch: '<S171>/Switch' */

      /* Switch: '<S171>/Switch2' incorporates:
       *  RelationalOperator: '<S171>/LowerRelop1'
       */
      if (rtb_Add_j1 > rtb_deltafalllimit_j) {
        rtb_Switch2_nw = rtb_deltafalllimit_j;
      } else {
        rtb_Switch2_nw = rtb_Switch_er;
      }

      /* End of Switch: '<S171>/Switch2' */

      /* Sum: '<S170>/Add1' incorporates:
       *  Constant: '<S170>/Constant'
       *  Memory: '<S170>/Memory'
       */
      rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_mk));

      /* Switch: '<S170>/Switch' incorporates:
       *  Constant: '<S170>/LatchTime_SY'
       *  RelationalOperator: '<S170>/Relational Operator'
       *  UnitDelay: '<S170>/Delay Input2'
       *
       * Block description for '<S170>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_j <= ((uint16)1U)) {
        rtb_Yk1_o = rtb_Switch2_nw;
      } else {
        rtb_Yk1_o = LKAS_DW.DelayInput2_DSTATE_h;
      }

      /* End of Switch: '<S170>/Switch' */

      /* Sum: '<S170>/Difference Inputs1'
       *
       * Block description for '<S170>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_e = rtb_Switch2_nw - rtb_Yk1_o;

      /* SampleTimeMath: '<S170>/sample time'
       *
       * About '<S170>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_deltafalllimit_j = 0.01F;

      /* Product: '<S170>/delta rise limit' incorporates:
       *  Gain: '<S85>/Gain3'
       */
      rtb_R0_C2 = (1.4F * LKAS_DW.SWARmax) * rtb_deltafalllimit_j;

      /* Product: '<S170>/delta fall limit' incorporates:
       *  Gain: '<S85>/Gain1'
       */
      rtb_deltafalllimit_j *= (-1.4F) * LKAS_DW.SWARmax;

      /* Switch: '<S172>/Switch' incorporates:
       *  RelationalOperator: '<S172>/UpperRelop'
       */
      if (rtb_UkYk1_e < rtb_deltafalllimit_j) {
        rtb_Switch_ap = rtb_deltafalllimit_j;
      } else {
        rtb_Switch_ap = rtb_UkYk1_e;
      }

      /* End of Switch: '<S172>/Switch' */

      /* Switch: '<S172>/Switch2' incorporates:
       *  RelationalOperator: '<S172>/LowerRelop1'
       */
      if (rtb_UkYk1_e > rtb_R0_C2) {
        rtb_Switch2_c = rtb_R0_C2;
      } else {
        rtb_Switch2_c = rtb_Switch_ap;
      }

      /* End of Switch: '<S172>/Switch2' */

      /* Sum: '<S170>/Difference Inputs2'
       *
       * Block description for '<S170>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_c + rtb_Yk1_o;

      /* Saturate: '<S170>/Saturation2' */
      if (rtb_Saturation_j < ((uint16)10000U)) {
        rtb_Saturation2_a = rtb_Saturation_j;
      } else {
        rtb_Saturation2_a = ((uint16)10000U);
      }

      /* End of Saturate: '<S170>/Saturation2' */

      /* DataTypeConversion: '<S86>/CastLKA3' */
      LKAS_DW.T1_Mon = LKAS_DW.Merge_j;

      /* DataTypeConversion: '<S110>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_IMAPve_g_ESC_VehSpd;

      /* DataTypeConversion: '<S86>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S84>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S102>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_a) {
          /* Disable for Outport: '<S104>/Out' */
          LKAS_DW.RelationalOperator_j = false;
          LKAS_DW.SumCondition1_MODE_a = false;
        }

        /* End of Disable for SubSystem: '<S102>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S82>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_m) {
          /* Disable for Outport: '<S90>/Out1' */
          LKAS_DW.DifferenceInputs2_b = 0.0F;
          LKAS_DW.Subsystem_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S82>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S103>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_p.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_k4,
            &LKAS_DW.SumCondition1_p);
        }

        /* End of Disable for SubSystem: '<S103>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S103>/Sum Condition' */
        if (LKAS_DW.SumCondition_d.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_pr,
            &LKAS_DW.SumCondition_d);
        }

        /* End of Disable for SubSystem: '<S103>/Sum Condition' */

        /* Disable for If: '<S186>/If' */
        LKAS_DW.If_ActiveSubsystem_o = -1;

        /* Disable for Outport: '<S73>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S73>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S73>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S73>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon = 0.0F;
        LKAS_DW.T1_Mon = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S9>/LKA' */

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon;

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon;

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_T1_Mon = LKAS_DW.T1_Mon;

    /* SignalConversion: '<S9>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S9>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LKA_State_Mon = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LDW_State_Mon = LKAS_DW.LDWSM_stLDWState;

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.LDWSM_stLDWState;

    /* Outputs for Enabled SubSystem: '<S9>/LDW' incorporates:
     *  EnablePort: '<S72>/Enable'
     *
     * Block description for '<S9>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S77>/If' */
      if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem' incorporates:
         *  ActionPort: '<S78>/Action Port'
         */
        /* Gain: '<S78>/rad to deg' incorporates:
         *  Gain: '<S78>/Gain'
         */
        LKAS_DW.Merge_k = ((-1.0F) * rtb_L0_C1_k) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S77>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S79>/Action Port'
         */
        /* Gain: '<S79>/rad to deg' */
        LKAS_DW.Merge_k = 57.2957802F * rtb_L0_C1;

        /* End of Outputs for SubSystem: '<S77>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S80>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_k);

        /* End of Outputs for SubSystem: '<S77>/If Action Subsystem2' */
      }

      /* End of If: '<S77>/If' */

      /* Switch: '<S541>/Switch2' incorporates:
       *  Constant: '<S541>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_m != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_m;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S541>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S77>/Sum Condition' incorporates:
       *  EnablePort: '<S81>/Enable'
       */
      /* RelationalOperator: '<S77>/Relational Operator' */
      if (LKAS_DW.Merge_k >= x10) {
        if (!LKAS_DW.SumCondition_MODE) {
          /* InitializeConditions for Memory: '<S81>/Memory' */
          LKAS_DW.Memory_PreviousInput_d = 0.0F;
          LKAS_DW.SumCondition_MODE = true;
        }

        /* Sum: '<S81>/Add1' incorporates:
         *  Memory: '<S81>/Memory'
         */
        rtb_L0_C1 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_d;

        /* Saturate: '<S81>/Saturation' */
        if (rtb_L0_C1 > 0.6F) {
          rtb_L0_C1 = 0.6F;
        } else {
          if (rtb_L0_C1 < 0.0F) {
            rtb_L0_C1 = 0.0F;
          }
        }

        /* End of Saturate: '<S81>/Saturation' */

        /* RelationalOperator: '<S81>/Relational Operator' incorporates:
         *  Constant: '<S77>/Constant'
         */
        LKAS_DW.RelationalOperator_m = (rtb_L0_C1 >= 0.05F);

        /* Update for Memory: '<S81>/Memory' */
        LKAS_DW.Memory_PreviousInput_d = rtb_L0_C1;
      } else {
        if (LKAS_DW.SumCondition_MODE) {
          /* Disable for Outport: '<S81>/Out' */
          LKAS_DW.RelationalOperator_m = false;
          LKAS_DW.SumCondition_MODE = false;
        }
      }

      /* End of RelationalOperator: '<S77>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S77>/Sum Condition' */

      /* Product: '<S72>/Product' incorporates:
       *  Logic: '<S72>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.LDWSM_stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_m) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S77>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE) {
          /* Disable for Outport: '<S81>/Out' */
          LKAS_DW.RelationalOperator_m = false;
          LKAS_DW.SumCondition_MODE = false;
        }

        /* End of Disable for SubSystem: '<S77>/Sum Condition' */

        /* Disable for Outport: '<S72>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S9>/LDW' */

    /* SignalConversion: '<S9>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* SignalConversion: '<S446>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S356>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LogicalOperator_lm;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_Compare_k1;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_LogicalOperator_nr;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_ji;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_ok;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_iv;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_bg;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_ge2;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_b;
    rtb_TmpSignalConversionAtSFunct[12] = LKAS_DW.RelationalOperator_h;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_LogicalOperator_ij;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_j1;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator_k;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_LogicalOperator3_i;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge;

    /* MATLAB Function: '<S356>/Disable Reason' */
    LKAS_DW.y = 0.0F;
    rtb_IMAPve_d_BCM_Left_Light_0 = 0;
    exitg1 = false;
    while ((!exitg1) && (rtb_IMAPve_d_BCM_Left_Light_0 < 18)) {
      if (rtb_TmpSignalConversionAtSFunct[rtb_IMAPve_d_BCM_Left_Light_0]) {
        LKAS_DW.y = 1.0F + ((float32)rtb_IMAPve_d_BCM_Left_Light_0);
        exitg1 = true;
      } else {
        rtb_IMAPve_d_BCM_Left_Light_0++;
      }
    }

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    rtb_LFTTTLC_Mon = rtb_LFTTTLC;

    /* Logic: '<S478>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S478>/Relational Operator3'
     *  RelationalOperator: '<S478>/Relational Operator4'
     */
    rtb_LogicalOperator1_e = ((rtb_Gain1 <= rtb_R0_C1) || (rtb_Add5_h <=
      rtb_R0_C1));

    /* Gain: '<S212>/Gain' incorporates:
     *  Sum: '<S212>/Add'
     */
    rtb_lDvt = (rtb_Gain1 + rtb_Add5_h) * 0.5F;

    /* SignalConversion: '<S9>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.DACMode = LKAS_DW.Divide;

    /* Sum: '<S211>/Add' */
    rtb_crCrvt = rtb_L0_C2_h4 + rtb_L0_C2;

    /* Delay: '<S75>/Delay1' */
    rtb_DACMode = LKAS_DW.Delay1_2_DSTATE;

    /* RelationalOperator: '<S513>/Compare' incorporates:
     *  Constant: '<S513>/Constant'
     *  Constant: '<S550>/Constant14'
     */
    rtb_Compare_fo = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S522>/Compare' incorporates:
     *  Constant: '<S522>/Constant'
     *  Constant: '<S550>/Constant11'
     */
    rtb_Compare_n3 = (((uint8)0U) == ((uint8)1U));
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S364>/Count 20s' */
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S372>/Out' */
        LKAS_DW.RelationalOperator_b = false;
        LKAS_DW.Count20s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S364>/Count 20s' */

      /* Disable for Enabled SubSystem: '<S365>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S374>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }

      /* End of Disable for SubSystem: '<S365>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S375>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_f) {
        /* Disable for Outport: '<S381>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.SumCondition1_MODE_f = false;
      }

      /* End of Disable for SubSystem: '<S375>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S387>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S394>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S387>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S304>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S334>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S304>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S304>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S333>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S304>/Count' */

      /* Disable for Enabled SubSystem: '<S336>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_p) {
        /* Disable for Outport: '<S342>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE_p = false;
      }

      /* End of Disable for SubSystem: '<S336>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S305>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_o) {
        /* Disable for Outport: '<S348>/Out' */
        LKAS_DW.RelationalOperator_p = false;
        LKAS_DW.SumCondition1_MODE_o = false;
      }

      /* End of Disable for SubSystem: '<S305>/Sum Condition1' */

      /* Disable for If: '<S351>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S263>/Count_5s3' */
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S527>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }

      /* End of Disable for SubSystem: '<S263>/Count_5s3' */

      /* Disable for Enabled SubSystem: '<S263>/Count_5s2' */
      if (LKAS_DW.Count_5s2.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_e, &LKAS_DW.Count_5s2);
      }

      /* End of Disable for SubSystem: '<S263>/Count_5s2' */

      /* Disable for Enabled SubSystem: '<S263>/Count_5s1' */
      if (LKAS_DW.Count_5s1.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_g, &LKAS_DW.Count_5s1);
      }

      /* End of Disable for SubSystem: '<S263>/Count_5s1' */

      /* Disable for Enabled SubSystem: '<S240>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_d) {
        /* Disable for Outport: '<S244>/Out' */
        LKAS_DW.RelationalOperator_d = false;
        LKAS_DW.Subsystem_MODE_d = false;
      }

      /* End of Disable for SubSystem: '<S240>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S9>/LKA'
       *
       * Block description for '<S9>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S84>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S102>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_a) {
          /* Disable for Outport: '<S104>/Out' */
          LKAS_DW.RelationalOperator_j = false;
          LKAS_DW.SumCondition1_MODE_a = false;
        }

        /* End of Disable for SubSystem: '<S102>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S82>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_m) {
          /* Disable for Outport: '<S90>/Out1' */
          LKAS_DW.DifferenceInputs2_b = 0.0F;
          LKAS_DW.Subsystem_MODE_m = false;
        }

        /* End of Disable for SubSystem: '<S82>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S103>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_p.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_k4,
            &LKAS_DW.SumCondition1_p);
        }

        /* End of Disable for SubSystem: '<S103>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S103>/Sum Condition' */
        if (LKAS_DW.SumCondition_d.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_pr,
            &LKAS_DW.SumCondition_d);
        }

        /* End of Disable for SubSystem: '<S103>/Sum Condition' */

        /* Disable for If: '<S186>/If' */
        LKAS_DW.If_ActiveSubsystem_o = -1;

        /* Disable for Outport: '<S73>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S73>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S73>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S73>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon = 0.0F;
        LKAS_DW.T1_Mon = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S9>/LKA' */

      /* Disable for Enabled SubSystem: '<S9>/LDW'
       *
       * Block description for '<S9>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S77>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE) {
          /* Disable for Outport: '<S81>/Out' */
          LKAS_DW.RelationalOperator_m = false;
          LKAS_DW.SumCondition_MODE = false;
        }

        /* End of Disable for SubSystem: '<S77>/Sum Condition' */

        /* Disable for Outport: '<S72>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S9>/LDW' */

      /* Disable for Outport: '<S9>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.DACMode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S9>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S9>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S9>/M' */
      LKAS_DW.OutputM = 0.0F;

      /* Disable for Outport: '<S9>/Disable_Reason' */
      LKAS_DW.y = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MATLAB Function: '<S7>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S51>/Switch'
   *  Switch: '<S51>/Switch1'
   */
  switch (LKAS_DW.Divide) {
   case 1:
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        rtb_L0_Q = 6U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 7U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 8U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 9U;
      } else {
        rtb_L0_Q = 1U;
      }
    }
    break;

   case 2:
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        rtb_L0_Q = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        rtb_L0_Q = 9U;
      } else {
        rtb_L0_Q = 1U;
      }
    }
    break;

   default:
    rtb_L0_Q = 0U;
    break;
  }

  /* End of MATLAB Function: '<S7>/Vehicle_Lane_Display' */

  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single1'
   *  DataTypeConversion: '<S7>/Cast To Single'
   */
  (void) Rte_Write_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_L0_Q);

  /* MATLAB Function: '<S7>/LDW_Status_Display' */
  if ((((sint32)LKAS_DW.Divide) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    rtb_IMAPve_d_BCM_HazardLamp = 1U;
  } else if ((((sint32)LKAS_DW.Divide) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    rtb_IMAPve_d_BCM_HazardLamp = 2U;
  } else {
    rtb_IMAPve_d_BCM_HazardLamp = 0U;
  }

  /* End of MATLAB Function: '<S7>/LDW_Status_Display' */

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single2'
   */
  (void) Rte_Write_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_IMAPve_d_BCM_HazardLamp);

  /* MATLAB Function: '<S7>/LKA_Status_Display' */
  if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) != 6)) {
    rtb_IMAPve_d_BCM_Left_Light_0 = 1;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    rtb_IMAPve_d_BCM_Left_Light_0 = 2;
  } else {
    rtb_IMAPve_d_BCM_Left_Light_0 = 0;
  }

  /* End of MATLAB Function: '<S7>/LKA_Status_Display' */

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single3'
   */
  (void) Rte_Write_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)((uint8)rtb_IMAPve_d_BCM_Left_Light_0));

  /* MATLAB Function: '<S7>/LDW_Flag' */
  switch (LKAS_DW.Divide) {
   case 1:
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      rtb_L0_Q = 1U;
      break;

     case 2:
      rtb_L0_Q = 2U;
      break;

     default:
      rtb_L0_Q = 0U;
      break;
    }
    break;

   case 2:
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      rtb_L0_Q = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      rtb_L0_Q = 2U;
    } else {
      rtb_L0_Q = 0U;
    }
    break;

   default:
    rtb_L0_Q = 0U;
    break;
  }

  /* End of MATLAB Function: '<S7>/LDW_Flag' */

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single4'
   *  DataTypeConversion: '<S7>/Cast To Single3'
   */
  (void) Rte_Write_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)rtb_L0_Q);

  /* Switch: '<S31>/Switch' incorporates:
   *  Constant: '<S31>/Constant'
   *  Constant: '<S31>/Constant1'
   *  Constant: '<S33>/Constant'
   *  RelationalOperator: '<S33>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_Saturation_eo = 0.5F;
  } else {
    rtb_Saturation_eo = 0.25F;
  }

  /* End of Switch: '<S31>/Switch' */

  /* Logic: '<S31>/Logical Operator2' incorporates:
   *  Abs: '<S31>/Abs'
   *  Constant: '<S34>/Constant'
   *  Constant: '<S35>/Constant'
   *  Constant: '<S36>/Constant'
   *  Constant: '<S37>/Constant'
   *  Constant: '<S38>/Constant'
   *  Logic: '<S31>/Logical Operator3'
   *  RelationalOperator: '<S31>/Relational Operator'
   *  RelationalOperator: '<S34>/Compare'
   *  RelationalOperator: '<S35>/Compare'
   *  RelationalOperator: '<S36>/Compare'
   *  RelationalOperator: '<S37>/Compare'
   *  RelationalOperator: '<S38>/Compare'
   */
  rtb_LogicalOperator_lm = ((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) || (rtb_IMAPve_d_EPS_LKA_State ==
    ((uint8)1U))) && (fabsf(rtb_IMAPve_g_EPS_SW_Trq) <= rtb_Saturation_eo));

  /* Outputs for Enabled SubSystem: '<S31>/Count 15s' incorporates:
   *  EnablePort: '<S40>/Enable'
   */
  if (rtb_LogicalOperator_lm) {
    if (!LKAS_DW.Count15s_MODE) {
      /* InitializeConditions for Memory: '<S40>/Memory' */
      LKAS_DW.Memory_PreviousInput_oo5 = ((uint16)0U);
      LKAS_DW.Count15s_MODE = true;
    }

    /* Sum: '<S40>/Add' incorporates:
     *  Constant: '<S40>/Constant'
     *  Memory: '<S40>/Memory'
     */
    rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      LKAS_DW.Memory_PreviousInput_oo5));

    /* Saturate: '<S40>/Saturation' */
    if (rtb_Saturation_j >= ((uint16)2100U)) {
      rtb_Saturation_j = ((uint16)2100U);
    }

    /* End of Saturate: '<S40>/Saturation' */

    /* RelationalOperator: '<S42>/Compare' incorporates:
     *  Constant: '<S42>/Constant'
     */
    LKAS_DW.Compare = (rtb_Saturation_j >= ((uint16)1500U));

    /* Update for Memory: '<S40>/Memory' */
    LKAS_DW.Memory_PreviousInput_oo5 = rtb_Saturation_j;
  } else {
    if (LKAS_DW.Count15s_MODE) {
      /* Disable for Outport: '<S40>/Out' */
      LKAS_DW.Compare = false;
      LKAS_DW.Count15s_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S31>/Count 15s' */

  /* MATLAB Function: '<S7>/Hands_Off_Warning' */
  if (!LKAS_DW.Compare) {
    rtb_IMAPve_d_BCM_HazardLamp = 0U;
  } else {
    rtb_IMAPve_d_BCM_HazardLamp = LKAS_DW.Compare ? 1U : 0U;
  }

  /* End of MATLAB Function: '<S7>/Hands_Off_Warning' */

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single5'
   */
  (void) Rte_Write_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning((UInt8)
    rtb_IMAPve_d_BCM_HazardLamp);

  /* Outputs for Enabled SubSystem: '<S31>/Count 10s' incorporates:
   *  EnablePort: '<S39>/Enable'
   */
  if (rtb_LogicalOperator_lm) {
    if (!LKAS_DW.Count10s_MODE) {
      /* InitializeConditions for Memory: '<S39>/Memory' */
      LKAS_DW.Memory_PreviousInput_js = ((uint16)0U);
      LKAS_DW.Count10s_MODE = true;
    }

    /* Sum: '<S39>/Add' incorporates:
     *  Constant: '<S39>/Constant'
     *  Memory: '<S39>/Memory'
     */
    rtb_Saturation_j = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      LKAS_DW.Memory_PreviousInput_js));

    /* Saturate: '<S39>/Saturation' */
    if (rtb_Saturation_j >= ((uint16)2100U)) {
      rtb_Saturation_j = ((uint16)2100U);
    }

    /* End of Saturate: '<S39>/Saturation' */

    /* RelationalOperator: '<S41>/Compare' incorporates:
     *  Constant: '<S41>/Constant'
     */
    LKAS_DW.Compare_p = (rtb_Saturation_j >= ((uint16)1000U));

    /* Update for Memory: '<S39>/Memory' */
    LKAS_DW.Memory_PreviousInput_js = rtb_Saturation_j;
  } else {
    if (LKAS_DW.Count10s_MODE) {
      /* Disable for Outport: '<S39>/Out' */
      LKAS_DW.Compare_p = false;
      LKAS_DW.Count10s_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S31>/Count 10s' */

  /* MATLAB Function: '<S7>/HMI_Popup_Status' */
  if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) == 6)) {
    rtb_IMAPve_d_BCM_HazardLamp = 6U;
  } else if (((((sint32)LKAS_DW.Divide) == 2) || (((sint32)LKAS_DW.Divide) == 1))
             && (((sint32)rtb_IMAPve_d_Camera_Status) == 5)) {
    rtb_IMAPve_d_BCM_HazardLamp = 4U;
  } else if (((((sint32)LKAS_DW.Divide) == 2) || (((sint32)LKAS_DW.Divide) == 1))
             && (LKAS_DW.Compare_p)) {
    rtb_IMAPve_d_BCM_HazardLamp = 2U;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              2)) {
    rtb_IMAPve_d_BCM_HazardLamp = 1U;
  } else if (((sint32)LKAS_DW.Divide) != 2) {
    rtb_IMAPve_d_BCM_HazardLamp = 8U;
  } else {
    rtb_IMAPve_d_BCM_HazardLamp = 7U;
  }

  /* End of MATLAB Function: '<S7>/HMI_Popup_Status' */

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single7'
   */
  (void) Rte_Write_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status((UInt8)
    rtb_IMAPve_d_BCM_HazardLamp);

  /* MATLAB Function: '<S7>/LKA_action_indication' */
  if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    rtb_IMAPve_d_BCM_HazardLamp = 1U;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    rtb_IMAPve_d_BCM_HazardLamp = 2U;
  } else if ((((sint32)LKAS_DW.Divide) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    rtb_IMAPve_d_BCM_HazardLamp = 3U;
  } else {
    rtb_IMAPve_d_BCM_HazardLamp = 0U;
  }

  /* End of MATLAB Function: '<S7>/LKA_action_indication' */

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single6'
   */
  (void) Rte_Write_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_IMAPve_d_BCM_HazardLamp);

  /* MultiPortSwitch: '<S10>/Multiport Switch' incorporates:
   *  Constant: '<S10>/Constant'
   *  Constant: '<S10>/Constant1'
   *  Constant: '<S10>/Constant2'
   *  Constant: '<S10>/Constant3'
   *  Constant: '<S10>/Constant4'
   *  Constant: '<S10>/Constant5'
   *  Constant: '<S10>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_IMAPve_d_Camera_Status = ((uint8)0U);
    break;

   case 1:
    rtb_IMAPve_d_Camera_Status = ((uint8)1U);
    break;

   case 2:
    rtb_IMAPve_d_Camera_Status = ((uint8)2U);
    break;

   case 3:
    rtb_IMAPve_d_Camera_Status = ((uint8)3U);
    break;

   case 4:
    rtb_IMAPve_d_Camera_Status = ((uint8)4U);
    break;

   case 5:
    rtb_IMAPve_d_Camera_Status = ((uint8)4U);
    break;

   default:
    rtb_IMAPve_d_Camera_Status = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S10>/Multiport Switch' */

  /* RelationalOperator: '<S529>/Compare' incorporates:
   *  Constant: '<S529>/Constant'
   */
  rtb_LogicalOperator_lm = (rtb_IMAPve_d_Camera_Status == ((uint8)4U));

  /* Switch: '<S10>/Switch1' incorporates:
   *  Constant: '<S10>/1'
   *  Constant: '<S10>/x0'
   */
  if (rtb_LogicalOperator_lm) {
    rtb_L0_Q = ((uint8)1U);
  } else {
    rtb_L0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S10>/Switch1' */

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S10>/Cast To Single1'
   *  DataTypeConversion: '<S4>/Cast To Single12'
   */
  (void) Rte_Write_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq((UInt8)rtb_L0_Q);

  /* Outputs for Enabled SubSystem: '<S528>/Subsystem' incorporates:
   *  EnablePort: '<S533>/Enable'
   */
  if (((sint32)rtb_L0_Q) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S533>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S533>/Add' incorporates:
     *  DataTypeConversion: '<S10>/Cast'
     */
    rtb_L0_C2 = LKAS_DW.OutputSWACmd - rtb_IMAPve_g_SW_Angle;

    /* Switch: '<S533>/Switch' incorporates:
     *  Constant: '<S533>/LL_LKA_SWATrq_KiA'
     *  Constant: '<S533>/LL_LKA_SWATrq_KiB'
     *  Constant: '<S535>/Constant'
     *  Constant: '<S536>/Constant'
     *  Constant: '<S537>/Constant'
     *  Constant: '<S538>/Constant'
     *  DataTypeConversion: '<S10>/Cast'
     *  Logic: '<S533>/Logical Operator'
     *  Logic: '<S533>/Logical Operator1'
     *  Logic: '<S533>/Logical Operator2'
     *  RelationalOperator: '<S535>/Compare'
     *  RelationalOperator: '<S536>/Compare'
     *  RelationalOperator: '<S537>/Compare'
     *  RelationalOperator: '<S538>/Compare'
     */
    if (((rtb_L0_C2 <= 0.0F) && (LKAS_DW.OutputSWACmd < 0.0F)) || ((rtb_L0_C2 >=
          0.0F) && (LKAS_DW.OutputSWACmd > 0.0F))) {
      rtb_R0_C2 = LL_LKA_SWATrq_KiA;
    } else {
      rtb_R0_C2 = LL_LKA_SWATrq_KiB;
    }

    /* End of Switch: '<S533>/Switch' */

    /* Sum: '<S533>/Add1' incorporates:
     *  Delay: '<S533>/Delay1'
     *  Gain: '<S533>/Gain'
     *  Product: '<S533>/Product2'
     */
    rtb_L0_C2_h4 = ((LKA_SampleTime * rtb_L0_C2) * rtb_R0_C2) +
      LKAS_DW.Delay1_DSTATE;

    /* Gain: '<S533>/Gain1' incorporates:
     *  Constant: '<S533>/LL_LKA_SWATrq_KiMax'
     */
    rtb_L0_C1 = (-1.0F) * LL_LKA_SWATrq_KiMax;

    /* Switch: '<S539>/Switch2' incorporates:
     *  Constant: '<S533>/LL_LKA_SWATrq_KiMax'
     *  RelationalOperator: '<S539>/LowerRelop1'
     *  RelationalOperator: '<S539>/UpperRelop'
     *  Switch: '<S539>/Switch'
     */
    if (rtb_L0_C2_h4 > LL_LKA_SWATrq_KiMax) {
      rtb_L0_C2_h4 = LL_LKA_SWATrq_KiMax;
    } else {
      if (rtb_L0_C2_h4 < rtb_L0_C1) {
        /* Switch: '<S539>/Switch' */
        rtb_L0_C2_h4 = rtb_L0_C1;
      }
    }

    /* End of Switch: '<S539>/Switch2' */

    /* Switch: '<S533>/Switch1' incorporates:
     *  Constant: '<S533>/LL_LKA_SWATrq_KfA'
     *  Constant: '<S533>/LL_LKA_SWATrq_KfB'
     *  Constant: '<S533>/LL_LKA_SWATrq_Kf_Switch'
     *  DataTypeConversion: '<S10>/Cast'
     *  Product: '<S533>/Divide'
     *  Product: '<S533>/Product3'
     *  Sqrt: '<S533>/Sqrt'
     */
    if (LL_LKA_SWATrq_Kf_Switch > 0.0F) {
      x10 = LKAS_DW.OutputSWACmd * LL_LKA_SWATrq_KfA;
    } else {
      x10 = sqrtf(LKAS_DW.OutputSWACmd) * LL_LKA_SWATrq_KfB;
    }

    /* End of Switch: '<S533>/Switch1' */

    /* Sum: '<S533>/Add2' incorporates:
     *  Constant: '<S533>/LL_LKA_SWATrq_Kp'
     *  Product: '<S533>/Product1'
     */
    LKAS_DW.in_trq = ((rtb_L0_C2 * LL_LKA_SWATrq_Kp) + x10) + rtb_L0_C2_h4;

    /* Update for Delay: '<S533>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_L0_C2_h4;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S533>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S528>/Subsystem' */

  /* Sum: '<S531>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S531>/Delay Input2'
   *
   * Block description for '<S531>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S531>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S531>/delta rise limit' incorporates:
   *  Constant: '<S528>/Constant'
   *  SampleTimeMath: '<S531>/sample time'
   *
   * About '<S531>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C1 = 5.0F * 0.01F;

  /* Product: '<S531>/delta fall limit' incorporates:
   *  Constant: '<S528>/Constant1'
   *  SampleTimeMath: '<S531>/sample time'
   *
   * About '<S531>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C2_h4 = (-5.0F) * 0.01F;

  /* Switch: '<S534>/Switch2' incorporates:
   *  Product: '<S531>/delta fall limit'
   *  Product: '<S531>/delta rise limit'
   *  RelationalOperator: '<S534>/LowerRelop1'
   *  RelationalOperator: '<S534>/UpperRelop'
   *  Switch: '<S534>/Switch'
   */
  if (rtb_L0_C2 > rtb_L0_C1) {
    rtb_L0_C2 = rtb_L0_C1;
  } else {
    if (rtb_L0_C2 < rtb_L0_C2_h4) {
      /* Switch: '<S534>/Switch' incorporates:
       *  Product: '<S531>/delta fall limit'
       */
      rtb_L0_C2 = rtb_L0_C2_h4;
    }
  }

  /* End of Switch: '<S534>/Switch2' */

  /* Sum: '<S531>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S531>/Delay Input2'
   *
   * Block description for '<S531>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S531>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 += LKAS_DW.DelayInput2_DSTATE;

  /* Switch: '<S532>/Switch2' incorporates:
   *  Constant: '<S528>/Constant3'
   *  Constant: '<S528>/Constant4'
   *  RelationalOperator: '<S532>/LowerRelop1'
   *  RelationalOperator: '<S532>/UpperRelop'
   *  Switch: '<S532>/Switch'
   */
  if (rtb_L0_C2 > 5.0F) {
    rtb_R0_C2 = 5.0F;
  } else if (rtb_L0_C2 < (-5.0F)) {
    /* Switch: '<S532>/Switch' incorporates:
     *  Constant: '<S528>/Constant4'
     */
    rtb_R0_C2 = (-5.0F);
  } else {
    rtb_R0_C2 = rtb_L0_C2;
  }

  /* End of Switch: '<S532>/Switch2' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single13'
   */
  (void) Rte_Write_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_R0_C2);

  /* Switch: '<S10>/Switch' incorporates:
   *  Gain: '<S10>/Gain'
   */
  if (rtb_LogicalOperator_lm) {
    rtb_R0_C2 = LKAS_DW.OutputM;
  } else {
    rtb_R0_C2 = 0.05F * LKAS_DW.y;
  }

  /* End of Switch: '<S10>/Switch' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single10'
   */
  (void) Rte_Write_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_R0_C2);

  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single8'
   */
  (void) Rte_Write_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control((UInt8)
    rtb_IMAPve_d_Camera_Status);

  /* DataTypeConversion: '<S10>/Cast To Single10' incorporates:
   *  Constant: '<S530>/Constant'
   *  RelationalOperator: '<S530>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.DACMode > ((uint8)0U)) ? 1 : 0);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S10>/Cast To Single'
   *  DataTypeConversion: '<S4>/Cast To Single11'
   */
  (void) Rte_Write_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* RelationalOperator: '<S19>/Compare' incorporates:
   *  Constant: '<S19>/Constant'
   */
  rtb_Compare_l = (rtb_IMAPve_d_TCU_Actual_Gear > ((uint8)3U));

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S60>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_o = rtb_R0_Type;
  } else {
    rtb_R0_Type_o = rtb_L0_Q_a;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  Constant: '<S57>/Constant'
   *  DataTypeConversion: '<S58>/Cast To Single5'
   *  Switch: '<S57>/Switch3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_c = rtb_L0_Q_a;

    /* Switch: '<S50>/Switch' incorporates:
     *  Constant: '<S50>/Constant'
     *  DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1'
     *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_Q_1'
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     *  Inport: '<Root>/IMAPve_d_ORI_L1_Q'
     */
    if (LL_Laneline_Select > 0.0F) {
      Rte_Read_IMAPve_d_L1_Q_IMAPve_d_L1_Q(&tmpRead_y);
      rtb_IMAPve_d_Camera_Status = (uint8)tmpRead_y;
    } else {
      Rte_Read_IMAPve_d_ORI_L1_Q_IMAPve_d_ORI_L1_Q(&tmpRead_y);
      rtb_IMAPve_d_Camera_Status = (uint8)tmpRead_y;
    }

    rtb_L1_Q = (uint16)rtb_IMAPve_d_Camera_Status;
  } else {
    rtb_L0_Type_c = rtb_R0_Type;
    rtb_L1_Q = ((uint16)0U);
  }

  /* Switch: '<S59>/Switch3' incorporates:
   *  Constant: '<S59>/Constant'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    /* Switch: '<S50>/Switch' incorporates:
     *  Constant: '<S50>/Constant'
     *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_Q_1'
     *  DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1'
     *  Inport: '<Root>/IMAPve_d_ORI_R1_Q'
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    if (LL_Laneline_Select > 0.0F) {
      Rte_Read_IMAPve_d_R1_Q_IMAPve_d_R1_Q(&tmpRead_14);
      rtb_IMAPve_d_Camera_Status = (uint8)tmpRead_14;
    } else {
      Rte_Read_IMAPve_d_ORI_R1_Q_IMAPve_d_ORI_R1_Q(&tmpRead_14);
      rtb_IMAPve_d_Camera_Status = (uint8)tmpRead_14;
    }

    rtb_R1_Q = (uint16)rtb_IMAPve_d_Camera_Status;
  } else {
    rtb_R1_Q = ((uint16)0U);
  }

  /* End of Switch: '<S59>/Switch3' */

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_L0_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L0_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R0_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_R0_LC_1'
   *  Inport: '<Root>/IMAPve_d_L0_LC'
   *  Inport: '<Root>/IMAPve_d_ORI_L0_LC'
   *  Inport: '<Root>/IMAPve_d_ORI_R0_LC'
   *  Inport: '<Root>/IMAPve_d_R0_LC'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_d_R0_LC_IMAPve_d_R0_LC(&tmpRead_13);
    rtb_IMAPve_d_Camera_Status = (uint8)tmpRead_13;
    Rte_Read_IMAPve_d_L0_LC_IMAPve_d_L0_LC(&tmpRead_x);
    rtb_L0_Q_a = (uint8)tmpRead_x;
  } else {
    Rte_Read_IMAPve_d_ORI_R0_LC_IMAPve_d_ORI_R0_LC(&tmpRead_13);
    rtb_IMAPve_d_Camera_Status = (uint8)tmpRead_13;
    Rte_Read_IMAPve_d_ORI_L0_LC_IMAPve_d_ORI_L0_LC(&tmpRead_x);
    rtb_L0_Q_a = (uint8)tmpRead_x;
  }

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S60>/Cast To Single8'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_LC_n = rtb_IMAPve_d_Camera_Status;
  } else {
    rtb_R0_LC_n = rtb_L0_Q_a;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S58>/Cast To Single8'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_LC_n = rtb_L0_Q_a;
  } else {
    rtb_L0_LC_n = rtb_IMAPve_d_Camera_Status;
  }

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_VR'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_VR'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_g_R0_VR_IMAPve_g_R0_VR(&rtb_R0_VR);
    Rte_Read_IMAPve_g_L0_VR_IMAPve_g_L0_VR(&rtb_L0_VR);
  } else {
    Rte_Read_IMAPve_g_ORI_R0_VR_IMAPve_g_ORI_R0_VR(&rtb_R0_VR);
    Rte_Read_IMAPve_g_ORI_L0_VR_IMAPve_g_ORI_L0_VR(&rtb_L0_VR);
  }

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S60>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_VR_l = rtb_R0_VR;
  } else {
    rtb_R0_VR_l = rtb_L0_VR;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S58>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_l = rtb_L0_VR;
  } else {
    rtb_L0_VR_l = rtb_R0_VR;
  }

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  Inport: '<Root>/IMAPve_g_L0_W'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_W'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_W'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_g_R0_W_IMAPve_g_R0_W(&rtb_R0_W);
    Rte_Read_IMAPve_g_L0_W_IMAPve_g_L0_W(&rtb_L0_W);
  } else {
    Rte_Read_IMAPve_g_ORI_R0_W_IMAPve_g_ORI_R0_W(&rtb_R0_W);
    Rte_Read_IMAPve_g_ORI_L0_W_IMAPve_g_ORI_L0_W(&rtb_L0_W);
  }

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S60>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_h = rtb_R0_W;
  } else {
    rtb_R0_W_h = rtb_L0_W;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S58>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_b = rtb_L0_W;
  } else {
    rtb_L0_W_b = rtb_R0_W;
  }

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  Inport: '<Root>/IMAPve_g_L0_TLC'
   *  Inport: '<Root>/IMAPve_g_ORI_L0_TLC'
   *  Inport: '<Root>/IMAPve_g_ORI_R0_TLC'
   *  Inport: '<Root>/IMAPve_g_R0_TLC'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_g_R0_TLC_IMAPve_g_R0_TLC(&rtb_R0_TLC);
    Rte_Read_IMAPve_g_L0_TLC_IMAPve_g_L0_TLC(&rtb_L0_TLC);
  } else {
    Rte_Read_IMAPve_g_ORI_R0_TLC_IMAPve_g_ORI_R0_TLC(&rtb_R0_TLC);
    Rte_Read_IMAPve_g_ORI_L0_TLC_IMAPve_g_ORI_L0_TLC(&rtb_L0_TLC);
  }

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S60>/Cast To Single7'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_TLC_a = rtb_R0_TLC;
  } else {
    rtb_R0_TLC_a = rtb_L0_TLC;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S58>/Cast To Single7'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_TLC_k = rtb_L0_TLC;
  } else {
    rtb_L0_TLC_k = rtb_R0_TLC;
  }

  /* Switch: '<S50>/Switch' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_L1_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_ORI_R1_LT_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_LC_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  Inport: '<Root>/IMAPve_d_L1_LC'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_LC'
   *  Inport: '<Root>/IMAPve_d_ORI_L1_Type'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_LC'
   *  Inport: '<Root>/IMAPve_d_ORI_R1_LT'
   *  Inport: '<Root>/IMAPve_d_R1_LC'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   *  Inport: '<Root>/IMAPve_g_L1_TLC'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C0'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C1'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C2'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_C3'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_TLC'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_VR'
   *  Inport: '<Root>/IMAPve_g_ORI_L1_W'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C0'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C1'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C2'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_C3'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_TLC'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_VR'
   *  Inport: '<Root>/IMAPve_g_ORI_R1_W'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   *  Inport: '<Root>/IMAPve_g_R1_TLC'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   *  UnaryMinus: '<S50>/Unary Minus10'
   *  UnaryMinus: '<S50>/Unary Minus11'
   *  UnaryMinus: '<S50>/Unary Minus12'
   *  UnaryMinus: '<S50>/Unary Minus13'
   *  UnaryMinus: '<S50>/Unary Minus14'
   *  UnaryMinus: '<S50>/Unary Minus15'
   *  UnaryMinus: '<S50>/Unary Minus8'
   *  UnaryMinus: '<S50>/Unary Minus9'
   */
  if (LL_Laneline_Select > 0.0F) {
    Rte_Read_IMAPve_g_L1_VR_IMAPve_g_L1_VR(&rtb_L1_VR);
    Rte_Read_IMAPve_d_L1_Type_IMAPve_d_L1_Type(&tmpRead_z);
    rtb_L1_Type = (uint8)tmpRead_z;
    Rte_Read_IMAPve_g_L1_W_IMAPve_g_L1_W(&rtb_L1_W);
    Rte_Read_IMAPve_g_L1_TLC_IMAPve_g_L1_TLC(&rtb_L1_TLC);
    Rte_Read_IMAPve_d_L1_LC_IMAPve_d_L1_LC(&tmpRead_10);
    rtb_L1_LC = (uint8)tmpRead_10;
    Rte_Read_IMAPve_g_R1_VR_IMAPve_g_R1_VR(&rtb_R1_VR);
    Rte_Read_IMAPve_d_R1_Type_IMAPve_d_R1_Type(&tmpRead_15);
    rtb_R1_Type = (uint8)tmpRead_15;
    Rte_Read_IMAPve_g_R1_W_IMAPve_g_R1_W(&rtb_R1_W);
    Rte_Read_IMAPve_g_R1_TLC_IMAPve_g_R1_TLC(&rtb_R1_TLC);
    Rte_Read_IMAPve_d_R1_LC_IMAPve_d_R1_LC(&tmpRead_16);
    rtb_R1_LC = (uint8)tmpRead_16;
    Rte_Read_IMAPve_g_L1_C0_IMAPve_g_L1_C0(&tmpRead_1c);
    rtb_L1_C0 = (float32)((T_M_Nm_Float32)(-tmpRead_1c));
    Rte_Read_IMAPve_g_L1_C1_IMAPve_g_L1_C1(&tmpRead_1d);
    rtb_L1_C1 = (float32)((T_M_Nm_Float32)(-tmpRead_1d));
    Rte_Read_IMAPve_g_L1_C2_IMAPve_g_L1_C2(&tmpRead_1e);
    rtb_L1_C2 = (float32)((T_M_Nm_Float32)(-tmpRead_1e));
    Rte_Read_IMAPve_g_L1_C3_IMAPve_g_L1_C3(&tmpRead_1f);
    rtb_L1_C3 = (float32)((T_M_Nm_Float32)(-tmpRead_1f));
    Rte_Read_IMAPve_g_R1_C0_IMAPve_g_R1_C0(&tmpRead_1g);
    rtb_R1_C0 = (float32)((T_M_Nm_Float32)(-tmpRead_1g));
    Rte_Read_IMAPve_g_R1_C1_IMAPve_g_R1_C1(&tmpRead_1h);
    rtb_R1_C1 = (float32)((T_M_Nm_Float32)(-tmpRead_1h));
    Rte_Read_IMAPve_g_R1_C2_IMAPve_g_R1_C2(&tmpRead_1i);
    rtb_R1_C2 = (float32)((T_M_Nm_Float32)(-tmpRead_1i));
    Rte_Read_IMAPve_g_R1_C3_IMAPve_g_R1_C3(&tmpRead_1j);
    rtb_R1_C3 = (float32)((T_M_Nm_Float32)(-tmpRead_1j));
  } else {
    Rte_Read_IMAPve_g_ORI_L1_VR_IMAPve_g_ORI_L1_VR(&rtb_L1_VR);
    Rte_Read_IMAPve_d_ORI_L1_Type_IMAPve_d_ORI_L1_Type(&tmpRead_z);
    rtb_L1_Type = (uint8)tmpRead_z;
    Rte_Read_IMAPve_g_ORI_L1_W_IMAPve_g_ORI_L1_W(&rtb_L1_W);
    Rte_Read_IMAPve_g_ORI_L1_TLC_IMAPve_g_ORI_L1_TLC(&rtb_L1_TLC);
    Rte_Read_IMAPve_d_ORI_L1_LC_IMAPve_d_ORI_L1_LC(&tmpRead_10);
    rtb_L1_LC = (uint8)tmpRead_10;
    Rte_Read_IMAPve_g_ORI_R1_VR_IMAPve_g_ORI_R1_VR(&rtb_R1_VR);
    Rte_Read_IMAPve_d_ORI_R1_LT_IMAPve_d_ORI_R1_LT(&tmpRead_15);
    rtb_R1_Type = (uint8)tmpRead_15;
    Rte_Read_IMAPve_g_ORI_R1_W_IMAPve_g_ORI_R1_W(&rtb_R1_W);
    Rte_Read_IMAPve_g_ORI_R1_TLC_IMAPve_g_ORI_R1_TLC(&rtb_R1_TLC);
    Rte_Read_IMAPve_d_ORI_R1_LC_IMAPve_d_ORI_R1_LC(&tmpRead_16);
    rtb_R1_LC = (uint8)tmpRead_16;
    Rte_Read_IMAPve_g_ORI_L1_C0_IMAPve_g_ORI_L1_C0(&rtb_L1_C0);
    Rte_Read_IMAPve_g_ORI_L1_C1_IMAPve_g_ORI_L1_C1(&rtb_L1_C1);
    Rte_Read_IMAPve_g_ORI_L1_C2_IMAPve_g_ORI_L1_C2(&rtb_L1_C2);
    Rte_Read_IMAPve_g_ORI_L1_C3_IMAPve_g_ORI_L1_C3(&rtb_L1_C3);
    Rte_Read_IMAPve_g_ORI_R1_C0_IMAPve_g_ORI_R1_C0(&rtb_R1_C0);
    Rte_Read_IMAPve_g_ORI_R1_C1_IMAPve_g_ORI_R1_C1(&rtb_R1_C1);
    Rte_Read_IMAPve_g_ORI_R1_C2_IMAPve_g_ORI_R1_C2(&rtb_R1_C2);
    Rte_Read_IMAPve_g_ORI_R1_C3_IMAPve_g_ORI_R1_C3(&rtb_R1_C3);
  }

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_Camera_Signal_Fault' */
  Rte_Read_IMAPve_d_Camera_Signal_Fault_IMAPve_d_Camera_Signal_Fault(&tmpRead_1k);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_R1_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_R1_Confidence'
   */
  Rte_Read_IMAPve_g_R1_Confidence_IMAPve_g_R1_Confidence
    (&rtb_IMAPve_g_R1_Confidence);

  /* DataTypeConversion: '<S1>/IMAPve_g_L1_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L1_Confidence'
   */
  Rte_Read_IMAPve_g_L1_Confidence_IMAPve_g_L1_Confidence
    (&rtb_IMAPve_g_L1_Confidence);

  /* DataTypeConversion: '<S1>/IMAPve_g_R0_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_R0_Confidence'
   */
  Rte_Read_IMAPve_g_R0_Confidence_IMAPve_g_R0_Confidence
    (&rtb_IMAPve_g_R0_Confidence);

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_Confidence_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_Confidence'
   */
  Rte_Read_IMAPve_g_L0_Confidence_IMAPve_g_L0_Confidence
    (&rtb_IMAPve_g_L0_Confidence);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ConsArea' */
  Rte_Read_IMAPve_d_ConsArea_IMAPve_d_ConsArea(&tmpRead_1b);

  /* Inport: '<Root>/IMAPve_d_Road_Type' */
  Rte_Read_IMAPve_d_Road_Type_IMAPve_d_Road_Type(&tmpRead_1a);

  /* Inport: '<Root>/IMAPve_d_Lane_Valid' */
  Rte_Read_IMAPve_d_Lane_Valid_IMAPve_d_Lane_Valid(&tmpRead_19);

  /* Inport: '<Root>/IMAPve_d_Fusion_Status' */
  Rte_Read_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status(&tmpRead_18);

  /* Inport: '<Root>/IMAPve_d_Sensor_Status' */
  Rte_Read_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status(&tmpRead_17);

  /* Inport: '<Root>/IMAPve_d_ORI_Lane_RoadType' */
  Rte_Read_IMAPve_d_ORI_Lane_RoadType_IMAPve_d_ORI_Lane_RoadType(&tmpRead_u);

  /* Inport: '<Root>/IMAPve_d_ORI_Lane_ConsArea' */
  Rte_Read_IMAPve_d_ORI_Lane_ConsArea_IMAPve_d_ORI_Lane_ConsArea(&tmpRead_t);

  /* Inport: '<Root>/IMAPve_d_ORI_Lane_Valid' */
  Rte_Read_IMAPve_d_ORI_Lane_Valid_IMAPve_d_ORI_Lane_Valid(&tmpRead_s);

  /* Inport: '<Root>/IMAPve_d_MP5_AutoPilot_Switch' */
  Rte_Read_IMAPve_d_MP5_AutoPilot_Switch_IMAPve_d_MP5_AutoPilot_Switch
    (&tmpRead_r);

  /* Inport: '<Root>/IMAPve_d_MP5_Work_State' */
  Rte_Read_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State(&tmpRead_q);

  /* Inport: '<Root>/IMAPve_d_EPS_ESA_State' */
  Rte_Read_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State(&tmpRead_p);

  /* Inport: '<Root>/IMAPve_d_EPS_Driver_Active_ESA' */
  Rte_Read_IMAPve_d_EPS_Driver_Active_ESA_IMAPve_d_EPS_Driver_Active_ESA
    (&tmpRead_o);

  /* Inport: '<Root>/IMAPve_d_EPS_Driver_Override' */
  Rte_Read_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override(&tmpRead_n);

  /* Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State' */
  Rte_Read_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    (&tmpRead_m);

  /* Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid' */
  Rte_Read_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid(&tmpRead_l);

  /* Inport: '<Root>/IMAPve_d_SWS_Failure_Status' */
  Rte_Read_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status(&tmpRead_k);

  /* Inport: '<Root>/IMAPve_d_SWS_Fault_Code' */
  Rte_Read_IMAPve_d_SWS_Fault_Code_IMAPve_d_SWS_Fault_Code(&tmpRead_j);

  /* Inport: '<Root>/IMAPve_d_TCU_TCU_Available' */
  Rte_Read_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available(&tmpRead_i);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  Rte_Read_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal
    (&rtb_IMAPve_g_EMS_RealPedal);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch' */
  Rte_Read_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
    (&tmpRead_g);

  /* Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch' */
  Rte_Read_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch(&tmpRead_f);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SteeringAngle'
   */
  Rte_Read_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
    (&rtb_IMAPve_g_EPS_SteeringAngle);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag' */
  Rte_Read_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    (&tmpRead_b);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  Rte_Read_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    (&rtb_IMAPve_g_ESC_Brake_Press);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid' */
  Rte_Read_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid(&tmpRead_a);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  Rte_Read_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate
    (&rtb_IMAPve_g_ESC_UnYawRate);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid' */
  Rte_Read_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid(&tmpRead_9);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  Rte_Read_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate(&rtb_IMAPve_g_ESC_YawRate);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid' */
  Rte_Read_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid(&tmpRead_8);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  Rte_Read_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    (&rtb_IMAPve_g_EPS_LKA_Current);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Inport: '<Root>/IMAPve_d_EPS_TrqLim_State' */
  Rte_Read_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State(&tmpRead_7);

  /* Inport: '<Root>/IMAPve_d_SAS_Trim_State' */
  Rte_Read_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State(&tmpRead_6);

  /* Inport: '<Root>/IMAPve_d_SAS_Clb_State' */
  Rte_Read_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State(&tmpRead_5);

  /* Inport: '<Root>/IMAPve_d_EPS_Trq_State' */
  Rte_Read_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State(&tmpRead_4);

  /* Inport: '<Root>/IMAPve_d_EPS_Error_State' */
  Rte_Read_IMAPve_d_EPS_Error_State_IMAPve_d_EPS_Error_State(&tmpRead_3);

  /* Inport: '<Root>/IMAPve_d_LDW_Warn_Mode' */
  Rte_Read_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode(&tmpRead_1);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* RelationalOperator: '<S12>/Compare' incorporates:
   *  Constant: '<S12>/Constant'
   */
  rtb_Compare_a = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1' */
  rtb_IMAPve_d_BCM_LeftTurn_Switc = (uint8)tmpRead_f;

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1' */
  rtb_IMAPve_d_BCM_RightTurn_Swit = (uint8)tmpRead_g;

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Signal_Fault_1' */
  rtb_IMAPve_d_Camera_Signal_Faul = (uint8)tmpRead_1k;

  /* DataTypeConversion: '<S1>/IMAPve_d_ConsArea_1' */
  rtb_IMAPve_d_ConsArea = (uint8)tmpRead_1b;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Active_ESA_1' */
  rtb_IMAPve_d_EPS_Driver_Active_ = (uint8)tmpRead_o;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)tmpRead_n;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)tmpRead_p;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Error_State_1' */
  rtb_IMAPve_d_Camera_Status = (uint8)tmpRead_3;

  /* Logic: '<S6>/Logical Operator5' incorporates:
   *  Constant: '<S13>/Constant'
   *  Constant: '<S16>/Constant'
   *  RelationalOperator: '<S13>/Compare'
   *  RelationalOperator: '<S16>/Compare'
   */
  rtb_Event_FaulETATDA = ((rtb_IMAPve_d_Camera_Status == ((uint8)1U)) ||
    (rtb_IMAPve_d_Camera_Status == ((uint8)2U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)tmpRead_m;

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)tmpRead_b;

  /* RelationalOperator: '<S20>/Compare' incorporates:
   *  Constant: '<S20>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1'
   */
  rtb_Compare_on = (((uint8)tmpRead_7) == ((uint8)0U));

  /* RelationalOperator: '<S21>/Compare' incorporates:
   *  Constant: '<S21>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1'
   */
  rtb_Compare_eq = (((uint8)tmpRead_4) == ((uint8)1U));

  /* RelationalOperator: '<S22>/Compare' incorporates:
   *  Constant: '<S22>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1'
   */
  rtb_Compare_l2 = (((uint8)tmpRead_8) == ((uint8)1U));

  /* RelationalOperator: '<S24>/Compare' incorporates:
   *  Constant: '<S24>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1'
   */
  rtb_Compare_h = (((uint8)tmpRead_a) == ((uint8)1U));

  /* RelationalOperator: '<S11>/Compare' incorporates:
   *  Constant: '<S11>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1'
   */
  rtb_Compare_c = (((uint8)tmpRead_l) != ((uint8)1U));

  /* RelationalOperator: '<S23>/Compare' incorporates:
   *  Constant: '<S23>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1'
   */
  rtb_Compare_fk = (((uint8)tmpRead_9) == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' */
  rtb_IMAPve_d_Fusion_Status = (uint8)tmpRead_18;

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' */
  rtb_IMAPve_d_LDW_Warn_Mode = (uint8)tmpRead_1;

  /* DataTypeConversion: '<S1>/IMAPve_d_Lane_Valid_1' */
  rtb_IMAPve_d_Lane_Valid = (uint8)tmpRead_19;

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_AutoPilot_Switch_1' */
  rtb_IMAPve_d_MP5_AutoPilot_Swit = (uint8)tmpRead_r;

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' */
  rtb_IMAPve_d_MP5_Work_State = (uint8)tmpRead_q;

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_ConsArea_1' */
  rtb_IMAPve_d_ORI_Lane_ConsArea = (uint8)tmpRead_t;

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_RoadType_1' */
  rtb_IMAPve_d_ORI_Lane_RoadType = (uint8)tmpRead_u;

  /* DataTypeConversion: '<S1>/IMAPve_d_ORI_Lane_Valid_1' */
  rtb_IMAPve_d_ORI_Lane_Valid = (uint8)tmpRead_s;

  /* DataTypeConversion: '<S1>/IMAPve_d_Road_Type_1' */
  rtb_IMAPve_d_Road_Type = (uint8)tmpRead_1a;

  /* RelationalOperator: '<S14>/Compare' incorporates:
   *  Constant: '<S14>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1'
   */
  rtb_Compare_a4 = (((uint8)tmpRead_5) == ((uint8)0U));

  /* RelationalOperator: '<S15>/Compare' incorporates:
   *  Constant: '<S15>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1'
   */
  rtb_Compare_g2 = (((uint8)tmpRead_6) == ((uint8)1U));

  /* Logic: '<S6>/Logical Operator6' incorporates:
   *  Constant: '<S17>/Constant'
   *  Constant: '<S18>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_SWS_Fault_Code_1'
   *  RelationalOperator: '<S17>/Compare'
   *  RelationalOperator: '<S18>/Compare'
   */
  rtb_Event_FaulSWS = ((((uint8)tmpRead_j) != ((uint8)0U)) || (((uint8)tmpRead_k)
    != ((uint8)1U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' */
  rtb_IMAPve_d_Sensor_Status = (uint8)tmpRead_17;

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)tmpRead_i;

  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' incorporates:
   *  DataTypeConversion: '<S4>/Cast To Single9'
   */
  (void) Rte_Write_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control((UInt8)
    LKAS_ConstB.EPS_LKA_Control);

  /* Switch: '<S542>/Switch1' incorporates:
   *  Constant: '<S542>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S542>/Switch1' */

  /* Switch: '<S542>/Switch12' incorporates:
   *  Constant: '<S542>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S542>/Switch12' */

  /* Switch: '<S543>/Switch56' incorporates:
   *  Constant: '<S543>/LLSMConClb14'
   *
   * Block description for '<S543>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_f != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_f;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S543>/Switch56' */

  /* Switch: '<S543>/Switch51' incorporates:
   *  Constant: '<S543>/LLSMConClb15'
   *
   * Block description for '<S543>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_o != 0.0F) {
    rtb_LL_DvtComp_C_b = LKAS_ConstB.DataTypeConversion25_o;
  } else {
    rtb_LL_DvtComp_C_b = LL_DvtComp_C;
  }

  /* End of Switch: '<S543>/Switch51' */

  /* Switch: '<S543>/Switch46' incorporates:
   *  Constant: '<S543>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S543>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_m != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_m;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S543>/Switch46' */

  /* Update for Memory: '<S70>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Add1;

  /* Update for Memory: '<S62>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = rtb_L0_C0;

  /* Update for Memory: '<S62>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = rtb_Switch_a4;

  /* Update for Memory: '<S63>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_a = rtb_R0_C0;

  /* Update for Memory: '<S63>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = rtb_offset;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S9>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S74>/Delay' */
    LKAS_DW.Delay_DSTATE = LKAS_DW.LKASM_stLKAActvFlg;

    /* Update for Memory: '<S502>/Memory' */
    LKAS_DW.Memory_PreviousInput_n = rtb_Saturation_g;

    /* Update for Memory: '<S447>/Memory' */
    LKAS_DW.Memory_PreviousInput_f = rtb_Saturation_l;

    /* Update for UnitDelay: '<S377>/Delay Input1'
     *
     * Block description for '<S377>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_n;

    /* Update for UnitDelay: '<S375>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_c = LKAS_DW.RelationalOperator_h;

    /* Update for UnitDelay: '<S376>/Delay Input1'
     *
     * Block description for '<S376>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_k = rtb_Compare_cmd;

    /* Update for Delay: '<S75>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.LKASM_stLKAState;

    /* Update for UnitDelay: '<S338>/Delay Input1'
     *
     * Block description for '<S338>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_g = rtb_Compare_fc;

    /* Update for UnitDelay: '<S336>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_jl = LKAS_DW.RelationalOperator_a;

    /* Update for UnitDelay: '<S337>/Delay Input1'
     *
     * Block description for '<S337>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_d = rtb_Compare_lp;

    /* Update for Memory: '<S304>/Memory' */
    LKAS_DW.Memory_PreviousInput_i = LKAS_DW.RelationalOperator_a;

    /* Update for Delay: '<S75>/Delay' */
    LKAS_DW.Delay_DSTATE_c = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S75>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.LDWSM_stLDWState;

    /* Update for Memory: '<S351>/Memory' */
    LKAS_DW.Memory_PreviousInput_p = rtb_LDW_State;

    /* Update for Memory: '<S278>/Memory' */
    LKAS_DW.Memory_PreviousInput_fe = rtb_Merge1_j;

    /* Update for Memory: '<S314>/Memory' */
    LKAS_DW.Memory_PreviousInput_g = rtb_Merge1_a;

    /* Update for Enabled SubSystem: '<S9>/LKA' incorporates:
     *  EnablePort: '<S73>/Enable'
     *
     * Block description for '<S9>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S101>/Memory' */
      LKAS_DW.Memory_PreviousInput_be = rtb_Saturation2;

      /* Update for Memory: '<S138>/Memory' */
      LKAS_DW.Memory_PreviousInput_mq = rtb_Saturation1_b;

      /* Update for Memory: '<S84>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_h = rtb_Saturation1_h;

      /* Update for Memory: '<S137>/Memory' */
      LKAS_DW.Memory_PreviousInput_o = rtb_Saturation1_ja;

      /* Update for Memory: '<S139>/Memory' */
      LKAS_DW.Memory_PreviousInput_h5 = rtb_Saturation1_a;

      /* Update for Memory: '<S133>/Memory' */
      LKAS_DW.Memory_PreviousInput_gj = rtb_Add_ba;

      /* Update for Memory: '<S136>/Memory' */
      LKAS_DW.Memory_PreviousInput_g5 = rtb_Saturation1_p;

      /* Update for Memory: '<S135>/Memory' */
      LKAS_DW.Memory_PreviousInput_jr = rtb_Saturation1_af;

      /* Update for Memory: '<S134>/Memory' */
      LKAS_DW.Memory_PreviousInput_f1 = rtb_Saturation1_eh;

      /* Update for Memory: '<S111>/Memory' */
      LKAS_DW.Memory_PreviousInput_fet = rtb_Add_l3;

      /* Update for Memory: '<S102>/Memory' */
      LKAS_DW.Memory_PreviousInput_m = rtb_Saturation2_l;

      /* Update for Memory: '<S103>/Memory' */
      LKAS_DW.Memory_PreviousInput_mv = rtb_Saturation2_e;

      /* Update for Memory: '<S100>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_k = rtb_Saturation_ka;

      /* Update for Memory: '<S188>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_f = rtb_Saturation_kz;

      /* Update for Memory: '<S177>/Memory' */
      LKAS_DW.Memory_PreviousInput_hw = rtb_Add1_m;

      /* Update for UnitDelay: '<S175>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_m = rtb_Switch2_f;

      /* Update for Memory: '<S182>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_i = rtb_Saturation_h;

      /* Update for Memory: '<S183>/Memory' */
      LKAS_DW.Memory_PreviousInput_oo = rtb_Saturation1_kk;

      /* Update for UnitDelay: '<S187>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_j = rtb_Switch_gi;

      /* Update for Memory: '<S187>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_b = rtb_Saturation_hf;

      /* Update for UnitDelay: '<S170>/Delay Input2'
       *
       * Block description for '<S170>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_h = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S170>/Memory' */
      LKAS_DW.Memory_PreviousInput_mk = rtb_Saturation2_a;
    }

    /* End of Update for SubSystem: '<S9>/LKA' */

    /* Update for Delay: '<S75>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.Divide;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S531>/Delay Input2'
   *
   * Block description for '<S531>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_L0_C2;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S351>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S9>/LKA'
   *
   * Block description for '<S9>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S84>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S186>/If' */
  LKAS_DW.If_ActiveSubsystem_o = -1;

  /* End of Start for SubSystem: '<S9>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S70>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* InitializeConditions for Memory: '<S62>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = (-1.75F);

  /* InitializeConditions for Memory: '<S62>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = (-1.75F);

  /* InitializeConditions for Memory: '<S63>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_a = 1.75F;

  /* InitializeConditions for Memory: '<S63>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 1.75F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S74>/Delay' */
  LKAS_DW.Delay_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S502>/Memory' */
  LKAS_DW.Memory_PreviousInput_n = 0.0F;

  /* InitializeConditions for Memory: '<S447>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = 0.0F;

  /* InitializeConditions for UnitDelay: '<S377>/Delay Input1'
   *
   * Block description for '<S377>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S375>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_c = false;

  /* InitializeConditions for UnitDelay: '<S376>/Delay Input1'
   *
   * Block description for '<S376>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_k = false;

  /* InitializeConditions for Delay: '<S75>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for UnitDelay: '<S338>/Delay Input1'
   *
   * Block description for '<S338>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_g = false;

  /* InitializeConditions for UnitDelay: '<S336>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_jl = false;

  /* InitializeConditions for UnitDelay: '<S337>/Delay Input1'
   *
   * Block description for '<S337>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_d = false;

  /* InitializeConditions for Memory: '<S304>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = false;

  /* InitializeConditions for Delay: '<S75>/Delay' */
  LKAS_DW.Delay_DSTATE_c = false;

  /* InitializeConditions for Delay: '<S75>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S351>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = ((uint8)0U);

  /* InitializeConditions for Memory: '<S278>/Memory' */
  LKAS_DW.Memory_PreviousInput_fe = 0.0F;

  /* InitializeConditions for Memory: '<S314>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 0.0F;

  /* InitializeConditions for Delay: '<S75>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S364>/Count 20s' */
  /* InitializeConditions for Memory: '<S372>/Memory' */
  LKAS_DW.Memory_PreviousInput_ay = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S364>/Count 20s' */

  /* SystemInitialize for Enabled SubSystem: '<S365>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S374>/Memory' */
  LKAS_DW.Memory_PreviousInput_ab = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S365>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S375>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S381>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S375>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S387>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S394>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S387>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S304>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S334>/Memory' */
  LKAS_DW.Memory_PreviousInput_go = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S304>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S304>/Count' */
  /* InitializeConditions for Memory: '<S333>/Memory' */
  LKAS_DW.Memory_PreviousInput_n1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S304>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S336>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S342>/Memory' */
  LKAS_DW.Memory_PreviousInput_hn = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S336>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S305>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S348>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S305>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S351>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S384>/Memory' */
  LKAS_DW.Memory_PreviousInput_nm = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S351>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S263>/Count_5s3' */
  /* InitializeConditions for Memory: '<S527>/Memory' */
  LKAS_DW.Memory_PreviousInput_k = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S263>/Count_5s3' */

  /* SystemInitialize for Enabled SubSystem: '<S263>/Count_5s2' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s2);

  /* End of SystemInitialize for SubSystem: '<S263>/Count_5s2' */

  /* SystemInitialize for Enabled SubSystem: '<S263>/Count_5s1' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s1);

  /* End of SystemInitialize for SubSystem: '<S263>/Count_5s1' */

  /* SystemInitialize for Enabled SubSystem: '<S240>/Subsystem' */
  /* InitializeConditions for Memory: '<S244>/Memory' */
  LKAS_DW.Memory_PreviousInput_nq = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S240>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S9>/LKA'
   *
   * Block description for '<S9>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S101>/Memory' */
  LKAS_DW.Memory_PreviousInput_be = 0.0F;

  /* InitializeConditions for Memory: '<S138>/Memory' */
  LKAS_DW.Memory_PreviousInput_mq = ((uint16)0U);

  /* InitializeConditions for Memory: '<S84>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_h = ((uint8)0U);

  /* InitializeConditions for Memory: '<S137>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = ((uint16)0U);

  /* InitializeConditions for Memory: '<S139>/Memory' */
  LKAS_DW.Memory_PreviousInput_h5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S133>/Memory' */
  LKAS_DW.Memory_PreviousInput_gj = ((uint16)0U);

  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput_g5 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S135>/Memory' */
  LKAS_DW.Memory_PreviousInput_jr = ((uint16)0U);

  /* InitializeConditions for Memory: '<S134>/Memory' */
  LKAS_DW.Memory_PreviousInput_f1 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S111>/Memory' */
  LKAS_DW.Memory_PreviousInput_fet = 0.0F;

  /* InitializeConditions for Memory: '<S102>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = 0.0F;

  /* InitializeConditions for Memory: '<S103>/Memory' */
  LKAS_DW.Memory_PreviousInput_mv = 0.0F;

  /* InitializeConditions for Memory: '<S100>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_k = 0.0F;

  /* InitializeConditions for Memory: '<S188>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_f = 0.0F;

  /* InitializeConditions for Memory: '<S177>/Memory' */
  LKAS_DW.Memory_PreviousInput_hw = 0.0F;

  /* InitializeConditions for UnitDelay: '<S175>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_m = 0.0F;

  /* InitializeConditions for Memory: '<S182>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_i = 0.0F;

  /* InitializeConditions for Memory: '<S183>/Memory' */
  LKAS_DW.Memory_PreviousInput_oo = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S187>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_j = 0.0F;

  /* InitializeConditions for Memory: '<S187>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_b = 0.0F;

  /* InitializeConditions for UnitDelay: '<S170>/Delay Input2'
   *
   * Block description for '<S170>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_h = 0.0F;

  /* InitializeConditions for Memory: '<S170>/Memory' */
  LKAS_DW.Memory_PreviousInput_mk = ((uint16)0U);

  /* SystemInitialize for IfAction SubSystem: '<S84>/LKA Motion Planning Calculation (LKAMPCal)'
   *
   * Block description for '<S84>/LKA Motion Planning Calculation (LKAMPCal)':
   *  Block Name: LKA Motion Planning Calculation
   *  Ab.: LKAMPCal
   *  No.: 1.2.3.2
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  LKAMotionPlanningCalculati_Init();

  /* End of SystemInitialize for SubSystem: '<S84>/LKA Motion Planning Calculation (LKAMPCal)' */

  /* SystemInitialize for Enabled SubSystem: '<S102>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S104>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S102>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S91>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S91>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S103>/Moving Standard Deviation1' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S103>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S103>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_p);

  /* End of SystemInitialize for SubSystem: '<S103>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S103>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2_g);

  /* End of SystemInitialize for SubSystem: '<S103>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S103>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_d);

  /* End of SystemInitialize for SubSystem: '<S103>/Sum Condition' */

  /* SystemInitialize for IfAction SubSystem: '<S186>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S196>/Delay Input1'
   *
   * Block description for '<S196>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_a = false;

  /* InitializeConditions for Memory: '<S192>/Memory' */
  LKAS_DW.Memory_PreviousInput_g0 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S186>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S186>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S204>/Delay Input1'
   *
   * Block description for '<S204>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_i = false;

  /* InitializeConditions for Memory: '<S193>/Memory' */
  LKAS_DW.Memory_PreviousInput_aa = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S186>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S186>/Merge' */
  LKAS_DW.Merge_j = 1.0F;

  /* SystemInitialize for Merge: '<S186>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S9>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S9>/LDW'
   *
   * Block description for '<S9>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S77>/Merge' */
  LKAS_DW.Merge_k = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S77>/Sum Condition' */
  /* InitializeConditions for Memory: '<S81>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S77>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S9>/LDW' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S31>/Count 15s' */
  /* InitializeConditions for Memory: '<S40>/Memory' */
  LKAS_DW.Memory_PreviousInput_oo5 = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S31>/Count 15s' */

  /* SystemInitialize for Enabled SubSystem: '<S31>/Count 10s' */
  /* InitializeConditions for Memory: '<S39>/Memory' */
  LKAS_DW.Memory_PreviousInput_js = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S31>/Count 10s' */

  /* SystemInitialize for Enabled SubSystem: '<S528>/Subsystem' */
  /* InitializeConditions for Delay: '<S533>/Delay1' */
  LKAS_DW.Delay1_DSTATE = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S528>/Subsystem' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
