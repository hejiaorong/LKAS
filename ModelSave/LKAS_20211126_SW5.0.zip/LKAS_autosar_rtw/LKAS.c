/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Nov 26 13:38:28 2021
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S78>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S78>/LKA_State_Machine' */
#define LKAS_IN_Fault_l                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_h      ((uint8)0U)
#define LKAS_IN_Normal_m               ((uint8)2U)
#define LKAS_IN_SysOff_e               ((uint8)2U)
#define LKAS_IN_SysOn_m                ((uint8)3U)
#define LKAS_IN_Unavailable_o          ((uint8)1U)
#define LKAS_IN_Unselected_d           ((uint8)2U)

/* Named constants for Chart: '<S53>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Exported data definition */

/* Definition for custom storage class: Default */
float32 ob_LKA_Disable_Reason;
float32 ob_LKA_LKADeactvCSyn;
float32 ob_LKA_Version;

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * Output and update for action system:
 *    '<S80>/If Action Subsystem2'
 *    '<S119>/if action 4'
 *    '<S120>/if action 4'
 *    '<S121>/if action 4'
 *    '<S122>/if action 4'
 *    '<S133>/If Action Subsystem3'
 *    '<S134>/If Action Subsystem3'
 *    '<S135>/If Action Subsystem3'
 *    '<S143>/If Action Subsystem3'
 *    '<S168>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S83>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S83>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/*
 * System initialize for atomic system:
 *    '<S94>/Moving Standard Deviation2'
 *    '<S106>/Moving Standard Deviation1'
 *    '<S106>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S102>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S94>/Moving Standard Deviation2'
 *    '<S106>/Moving Standard Deviation1'
 *    '<S106>/Moving Standard Deviation2'
 */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S102>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S102>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S94>/Moving Standard Deviation2'
 *    '<S106>/Moving Standard Deviation1'
 *    '<S106>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation2(float32 rtu_In1,
  DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_n;
  float32 rtb_Delay1_n;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S102>/Delay' */
  rtb_Delay_n = localDW->Delay_DSTATE;

  /* Delay: '<S102>/Delay1' */
  rtb_Delay1_n = localDW->Delay1_DSTATE;

  /* Delay: '<S102>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S102>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S102>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S102>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S102>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S102>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S102>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S102>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S102>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S102>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S102>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S102>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S102>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S102>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S102>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S102>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S102>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S102>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S102>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S102>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S102>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S102>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S102>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S102>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S102>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S102>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S102>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S102>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S102>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S102>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S102>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S102>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S102>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S102>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S102>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S102>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S102>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S102>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S102>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S102>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S102>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S102>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S102>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S102>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S102>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S102>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S102>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S102>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_n;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_n;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S102>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S102>/Standard Deviation' */

  /* Update for Delay: '<S102>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S102>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_n;

  /* Update for Delay: '<S102>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S102>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S102>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S102>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S102>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S102>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S102>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S102>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S102>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S102>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S102>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_n;

  /* Update for Delay: '<S102>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S102>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S102>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S102>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S102>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S102>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S102>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S102>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S102>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S102>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S102>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S102>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S102>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S102>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S102>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S102>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S102>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S102>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S102>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S102>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S102>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S102>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S102>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S102>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S102>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S102>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S102>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S102>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S102>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S102>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S102>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S102>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S102>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S102>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S102>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S102>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S106>/Sum Condition'
 *    '<S106>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S110>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S106>/Sum Condition'
 *    '<S106>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S110>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S106>/Sum Condition'
 *    '<S106>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S106>/Sum Condition' incorporates:
   *  EnablePort: '<S110>/Enable'
   */
  /* Disable for Outport: '<S110>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S106>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S106>/Sum Condition'
 *    '<S106>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_h3;

  /* Outputs for Enabled SubSystem: '<S106>/Sum Condition' incorporates:
   *  EnablePort: '<S110>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S110>/Add1' incorporates:
     *  Memory: '<S110>/Memory'
     */
    rtb_Saturation_h3 = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S110>/Saturation' */
    if (rtb_Saturation_h3 > 100.0F) {
      rtb_Saturation_h3 = 100.0F;
    } else {
      if (rtb_Saturation_h3 < 0.0F) {
        rtb_Saturation_h3 = 0.0F;
      }
    }

    /* End of Saturate: '<S110>/Saturation' */

    /* RelationalOperator: '<S110>/Relational Operator' */
    *rty_Out = (rtb_Saturation_h3 >= rtu_In1);

    /* Update for Memory: '<S110>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_h3;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S106>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S119>/if action 3'
 *    '<S120>/if action 3'
 *    '<S121>/if action 3'
 *    '<S122>/if action 3'
 *    '<S133>/If Action Subsystem2'
 *    '<S133>/If Action Subsystem1'
 *    '<S134>/If Action Subsystem2'
 *    '<S134>/If Action Subsystem1'
 *    '<S135>/If Action Subsystem2'
 *    '<S135>/If Action Subsystem1'
 *    ...
 */
void LKAS_ifaction3(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S125>/In1' */
  *rty_Out1 = rtu_In1;
}

/* System initialize for action system: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculati_Init(void)
{
  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_lr = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory' */
  LKAS_DW.Memory_PreviousInput_dh = ((uint16)0U);

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_m = 0.0F;

  /* InitializeConditions for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_jo = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S121>/Memory' */
  LKAS_DW.Memory_PreviousInput_hd = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_b = 0.0F;

  /* InitializeConditions for Memory: '<S122>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/* System reset for action system: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */
void LKAMotionPlanningCalculat_Reset(void)
{
  /* InitializeConditions for Memory: '<S118>/Memory' */
  LKAS_DW.Memory_PreviousInput_lr = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory' */
  LKAS_DW.Memory_PreviousInput_dh = ((uint16)0U);

  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_m = 0.0F;

  /* InitializeConditions for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_jo = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory2' */
  LKAS_DW.Memory2_PreviousInput = 0.0F;

  /* InitializeConditions for Memory: '<S121>/Memory' */
  LKAS_DW.Memory_PreviousInput_hd = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_b = 0.0F;

  /* InitializeConditions for Memory: '<S122>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = ((uint16)0U);

  /* InitializeConditions for Memory: '<S112>/Memory4' */
  LKAS_DW.Memory4_PreviousInput = 0.0F;
}

/*
 * Output and update for action system: '<S87>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S87>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  /* local block i/o variables */
  float32 rtb_Memory1;
  float32 rtb_Memory2;
  float32 rtb_Memory3;
  float32 rtb_Memory4;
  float32 rtb_Merge1;
  float32 rtb_Merge1_a;
  float32 rtb_Merge1_m;
  float32 rtb_Merge1_g;
  float32 rtb_K1K2Det_dphi2PhSWAGrad2;
  float32 rtb_K1K2Det_stReplFlag;
  float32 rtb_K1K2Det_dphi1PhHdAgIni;
  float32 DelteSW0;
  float32 u;
  float32 Kw;
  float32 StpLngth;
  float32 Mode1Num;
  float32 Mode2Num;
  float32 D2_End;
  float32 DelteSW1;
  float32 K1;
  float32 K2_2;
  float32 T2;
  sint32 a;
  float32 K2;
  float32 c_T1;
  float32 c_T2;
  float32 K1_0;
  uint16 rtb_Add;
  uint16 rtb_Add_oi;
  uint16 rtb_Add_ig;
  uint16 rtb_Add_cy;
  uint16 rtb_Add_e2;
  uint16 rtb_Merge;
  uint16 rtb_Add_p;

  /* Sum: '<S118>/Add' incorporates:
   *  Constant: '<S118>/Constant'
   *  Memory: '<S118>/Memory'
   */
  rtb_Add = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_lr));

  /* Saturate: '<S118>/Saturation1' */
  if (rtb_Add < ((uint16)100U)) {
    rtb_Merge = rtb_Add;
  } else {
    rtb_Merge = ((uint16)100U);
  }

  /* End of Saturate: '<S118>/Saturation1' */

  /* If: '<S118>/If' incorporates:
   *  Constant: '<S118>/Constant19'
   *  Inport: '<S123>/In1'
   *  Memory: '<S112>/Memory'
   */
  if (rtb_Merge == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S118>/if action 2' incorporates:
     *  ActionPort: '<S124>/Action Port'
     */
    /* SignalConversion: '<S124>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
     *  Constant: '<S124>/Constant'
     */
    rtb_Merge = ((uint16)0U);

    /* End of Outputs for SubSystem: '<S118>/if action 2' */
  } else {
    /* Outputs for IfAction SubSystem: '<S118>/if action 1' incorporates:
     *  ActionPort: '<S123>/Action Port'
     */
    rtb_Merge = LKAS_DW.Memory_PreviousInput_dh;

    /* End of Outputs for SubSystem: '<S118>/if action 1' */
  }

  /* End of If: '<S118>/If' */

  /* Sum: '<S119>/Add' incorporates:
   *  Constant: '<S119>/Constant'
   *  Memory: '<S119>/Memory'
   */
  rtb_Add_oi = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_b));

  /* Memory: '<S112>/Memory1' */
  rtb_Memory1 = LKAS_DW.Memory1_PreviousInput_m;

  /* Saturate: '<S119>/Saturation1' */
  if (rtb_Add_oi < ((uint16)100U)) {
    rtb_Add_ig = rtb_Add_oi;
  } else {
    rtb_Add_ig = ((uint16)100U);
  }

  /* End of Saturate: '<S119>/Saturation1' */

  /* If: '<S119>/If' incorporates:
   *  Constant: '<S119>/Constant19'
   */
  if (rtb_Add_ig == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S119>/if action 4' incorporates:
     *  ActionPort: '<S126>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1);

    /* End of Outputs for SubSystem: '<S119>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S119>/if action 3' incorporates:
     *  ActionPort: '<S125>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory1, &rtb_Merge1);

    /* End of Outputs for SubSystem: '<S119>/if action 3' */
  }

  /* End of If: '<S119>/If' */

  /* Sum: '<S120>/Add' incorporates:
   *  Constant: '<S120>/Constant'
   *  Memory: '<S120>/Memory'
   */
  rtb_Add_ig = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_jo));

  /* Memory: '<S112>/Memory2' */
  rtb_Memory2 = LKAS_DW.Memory2_PreviousInput;

  /* Saturate: '<S120>/Saturation1' */
  if (rtb_Add_ig < ((uint16)100U)) {
    rtb_Add_cy = rtb_Add_ig;
  } else {
    rtb_Add_cy = ((uint16)100U);
  }

  /* End of Saturate: '<S120>/Saturation1' */

  /* If: '<S120>/If' incorporates:
   *  Constant: '<S120>/Constant19'
   */
  if (rtb_Add_cy == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S120>/if action 4' incorporates:
     *  ActionPort: '<S128>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_a);

    /* End of Outputs for SubSystem: '<S120>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S120>/if action 3' incorporates:
     *  ActionPort: '<S127>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory2, &rtb_Merge1_a);

    /* End of Outputs for SubSystem: '<S120>/if action 3' */
  }

  /* End of If: '<S120>/If' */

  /* Sum: '<S121>/Add' incorporates:
   *  Constant: '<S121>/Constant'
   *  Memory: '<S121>/Memory'
   */
  rtb_Add_cy = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_hd));

  /* Memory: '<S112>/Memory3' */
  rtb_Memory3 = LKAS_DW.Memory3_PreviousInput_b;

  /* Saturate: '<S121>/Saturation1' */
  if (rtb_Add_cy < ((uint16)100U)) {
    rtb_Add_e2 = rtb_Add_cy;
  } else {
    rtb_Add_e2 = ((uint16)100U);
  }

  /* End of Saturate: '<S121>/Saturation1' */

  /* If: '<S121>/If' incorporates:
   *  Constant: '<S121>/Constant19'
   */
  if (rtb_Add_e2 == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S121>/if action 4' incorporates:
     *  ActionPort: '<S130>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_m);

    /* End of Outputs for SubSystem: '<S121>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S121>/if action 3' incorporates:
     *  ActionPort: '<S129>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory3, &rtb_Merge1_m);

    /* End of Outputs for SubSystem: '<S121>/if action 3' */
  }

  /* End of If: '<S121>/If' */

  /* Sum: '<S122>/Add' incorporates:
   *  Constant: '<S122>/Constant'
   *  Memory: '<S122>/Memory'
   */
  rtb_Add_e2 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
    LKAS_DW.Memory_PreviousInput_i));

  /* Memory: '<S112>/Memory4' */
  rtb_Memory4 = LKAS_DW.Memory4_PreviousInput;

  /* Saturate: '<S122>/Saturation1' */
  if (rtb_Add_e2 < ((uint16)100U)) {
    rtb_Add_p = rtb_Add_e2;
  } else {
    rtb_Add_p = ((uint16)100U);
  }

  /* End of Saturate: '<S122>/Saturation1' */

  /* If: '<S122>/If' incorporates:
   *  Constant: '<S122>/Constant19'
   */
  if (rtb_Add_p == ((uint16)1U)) {
    /* Outputs for IfAction SubSystem: '<S122>/if action 4' incorporates:
     *  ActionPort: '<S132>/Action Port'
     */
    LKAS_IfActionSubsystem2(&rtb_Merge1_g);

    /* End of Outputs for SubSystem: '<S122>/if action 4' */
  } else {
    /* Outputs for IfAction SubSystem: '<S122>/if action 3' incorporates:
     *  ActionPort: '<S131>/Action Port'
     */
    LKAS_ifaction3(rtb_Memory4, &rtb_Merge1_g);

    /* End of Outputs for SubSystem: '<S122>/if action 3' */
  }

  /* End of If: '<S122>/If' */

  /* MATLAB Function: '<S112>/MATLAB Function' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLAB Function': '<S117>:1' */
  /* '<S117>:1:55' LDDir = K1K2Det_stLDDir; */
  /* '<S117>:1:56' D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S117>:1:57' D2_des = K1K2Det_lDesDvt; */
  /* '<S117>:1:58' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_h * 0.0174532924F;

  /* '<S117>:1:59' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S117>:1:60' TTLCHdAg = K1K2Det_phiTTLCHdAgIni; */
  /* '<S117>:1:61' Delte_Psi2 = K1K2Det_phi2PhDesHdAg; */
  /* '<S117>:1:62' Delte_Psi1Ini = K1K2Det_phi1PhDesHdAgIni; */
  /* '<S117>:1:63' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S117>:1:64' TTLCCrvt = K1K2Det_crPrvwTTLCCrvt; */
  /* '<S117>:1:65' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S117>:1:66' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S117>:1:67' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S117>:1:68' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_an / 3.6F;

  /* '<S117>:1:69' Kw=u/(L*(1+K*u*u)*i); */
  Kw = u / (((((LKAS_DW.StbFacm_SY * u) * u) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_b)
            * LKAS_DW.LKA_StrRatio_C_m);

  /*      DelteSW1 = single(0); */
  /* '<S117>:1:71' K1K2Det_stReplFlag = single(0); */
  rtb_K1K2Det_stReplFlag = 0.0F;

  /* '<S117>:1:72' StpLngth = K1K2Det_lStpLngth*(pi/180); */
  StpLngth = LKAS_DW.LL_lStpLngth_C_n * 0.0174532924F;

  /* '<S117>:1:73' ModeFlg = K1K2Det_bsTDivInfo_ModeFlg; */
  /* '<S117>:1:74' Mode1Num = K1K2Det_bsTDivInfo_Mode1Num; */
  Mode1Num = rtb_Merge1;

  /* '<S117>:1:75' Mode2Num = K1K2Det_bsTDivInfo_Mode2Num; */
  Mode2Num = rtb_Merge1_a;

  /* '<S117>:1:76' D2_End =  K1K2Det_bsTDivInfo_Ph2DvtEnd; */
  D2_End = rtb_Merge1_m;

  /* '<S117>:1:77' DelteSW1 = K1K2Det_bsTDivInfo_Ph2SWAIni; */
  DelteSW1 = rtb_Merge1_g;

  /* '<S117>:1:78' K1 = single(0); */
  K1 = 0.0F;

  /* '<S117>:1:79' K2_1 = single(0); */
  K2 = 0.0F;

  /* '<S117>:1:80' K2_2 = single(0); */
  K2_2 = 0.0F;

  /* '<S117>:1:81' KMax = K1K2Det_dphiSWARMax; */
  /* ************************************************************************** */
  /*  */
  /*  if (LDDir*PrvwHdAg < LDDir*TTLCHdAg) */
  /*      Delte_Psi1 = PrvwHdAg; */
  /*  else */
  /*      Delte_Psi1 = TTLCHdAg; */
  /*  end */
  /* '<S117>:1:89' Delte_Psi1 = PrvwHdAg; */
  /* '<S117>:1:90' if (ModeFlg == 0) */
  if (((sint32)rtb_Merge) == 0) {
    /* '<S117>:1:91' [K1,K2_1,K2_2,D2_End,DelteSW1]= func1(Delte_Psi1,TTLC,Kw,DelteSW0,Delte_Psi2,u,D1_Ini,Delte_Psi1Ini); */
    /*     ���ܣ� */
    /*     ��֪����ʼת����ת�ǣ�TTLC��һ����������Ǳ������뿪����ʱ����������� */
    /*     Լ����1��һ������ʱ����TTLCʱ��ʵ�������ĺ���Ǳ仯�� */
    /*           2����������ʱ��ת����ת��Ϊ�㣻 */
    /*           3����������ʱ��ʵ�������ĺ���ǵĺ���ǡ� */
    /*      */
    /*     ����� һ��ת����ת�Ǳ仯��K1������ת����ת�Ǳ仯��K2_1��K2_2����������ʱ��ƫ��������ֵD2 */
    /* ************************************************************************** */
    /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
    /*  end of function K1K2Det */
    /*  */
    /* ***************************************** */
    /*  1������func1�������������ʱ��ƫ��������ֵƫ����D2_0; */
    /*      */
    /*  2����D2_0<=D2_des������ú���func2�����������k1��k2_1��k2_2��ͬ���ڶ�������ʱ�� */
    /*     Ӧ��ͬʱʵ����������Ǻ�����ƫ������ */
    /*  3����D2_0>D2_des_max������ú���F,2�����������k1��k2_1��k2_2������k2_1 = k2_2�� */
    /*     �ڶ�������ʱ��Ӧ��ͬʱʵ����������Ǻ�����ƫ������ */
    /*  */
    /* '<S117>:1:168' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
    K1 = ((-2.0F * LKAS_DW.In_if) / ((Kw * LKAS_DW.MPInP_tiTTLCIni) *
           LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F * DelteSW0) /
      LKAS_DW.MPInP_tiTTLCIni);

    /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
    /* '<S117>:1:171' DelteSW1 = DelteSW0+K1*TTLC; */
    DelteSW1 = (K1 * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

    /* '<S117>:1:172' Delte_Psi = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1)*TTLC*Kw; */
    D2_End = ((((DelteSW0 + DelteSW1) * 0.5F) * LKAS_DW.MPInP_tiTTLCIni) * Kw) +
      LKAS_DW.In_g;

    /* ����Լ��2��3���������K2�� */
    /* '<S117>:1:174' K2 = -DelteSW1*DelteSW1*Kw/(2*(Delte_Psi2-Delte_Psi)); */
    K2 = (((-DelteSW1) * DelteSW1) * Kw) / ((LKAS_DW.In_jb - D2_End) * 2.0F);

    /* ����K2��DelteSW1�ͳ��٣����Լ��������������ƫ�����ı仯��D2�Ͷ�������ʱ��T2�� */
    /* '<S117>:1:176' T1 = (DelteSW1-DelteSW0)/K1; */
    c_T1 = (DelteSW1 - DelteSW0) / K1;

    /* '<S117>:1:177' T2 = (0-DelteSW1)/K2; */
    c_T2 = (0.0F - DelteSW1) / K2;

    /*      D1 = u*((1/6)*Kw*(2*DelteSW0+DelteSW1)*T1^2+Delte_Psi1*T1); */
    /*      D2 = u*((1/3)*Kw*T2^2*DelteSW1); */
    /* '<S117>:1:180' D1 = u*((1/6)*Kw*(DelteSW1+2*DelteSW0)*T1*T1+Delte_Psi1Ini*T1); */
    /* '<S117>:1:181' D2 = u*((1/3)*Kw*T2*T2*DelteSW1+Delte_Psi*T2); */
    /* '<S117>:1:182' D2_End = D1+D2; */
    /*  */
    /* ************************************************************************** */
    /* ����� */
    /*    K1 = K1; */
    /* '<S117>:1:187' K2_1 = K2; */
    /* '<S117>:1:188' K2_2 = K2; */
    K2_2 = K2;
    D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) * c_T1) *
                c_T1) + (LKAS_DW.In_g * c_T1)) * u) + ((((((0.333333343F * Kw) *
      c_T2) * c_T2) * DelteSW1) + (D2_End * c_T2)) * u);
  }

  /* '<S117>:1:93' if(0< D2_End*LDDir && D2_End*LDDir <= D2_des && ModeFlg == 0) */
  c_T1 = D2_End * LKAS_DW.Merge;
  if (((0.0F < c_T1) && (c_T1 <= LKAS_DW.LL_DesDvt_C_p)) && (((sint32)rtb_Merge)
       == 0)) {
    /* '<S117>:1:95' K1K2Det_stReplFlag = single(0); */
    rtb_K1K2Det_stReplFlag = 0.0F;
  } else {
    if ((c_T1 > LKAS_DW.LL_DesDvt_C_p) || (((sint32)rtb_Merge) != 0)) {
      /* '<S117>:1:97' elseif(D2_End*LDDir > D2_des || ModeFlg ~= 0 ) */
      /* '<S117>:1:99' K1K2Det_stReplFlag = single(1); */
      rtb_K1K2Det_stReplFlag = 1.0F;

      /* '<S117>:1:101' for a = 1:8 */
      for (a = 0; a < 8; a++) {
        /* '<S117>:1:103' if (D2_End*LDDir>D2_des && ModeFlg==0) */
        c_T1 = D2_End * LKAS_DW.Merge;
        if ((c_T1 > LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 0)) {
          /* '<S117>:1:104' ModeFlg = uint16(1); */
          rtb_Merge = 1U;
        }

        /* '<S117>:1:106' if (D2_End*LDDir>D2_des && ModeFlg==1) */
        if ((c_T1 > LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 1)) {
          /* '<S117>:1:107' DelteSW1 =  LDDir*StpLngth+DelteSW1; */
          DelteSW1 += LKAS_DW.Merge * StpLngth;

          /* '<S117>:1:108' Mode1Num = Mode1Num+1; */
          Mode1Num++;
        }

        /* '<S117>:1:110' if (D2_End*LDDir <= D2_des && ModeFlg==1) */
        if ((c_T1 <= LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 1)) {
          /* '<S117>:1:111' ModeFlg = uint16(2); */
          rtb_Merge = 2U;
        }

        /* '<S117>:1:113' if (D2_End*LDDir<D2_des && ModeFlg==2) */
        if ((c_T1 < LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 2)) {
          /* '<S117>:1:114' DelteSW1 =  DelteSW1-LDDir*StpLngth*((1/2)^(Mode2Num+1)); */
          DelteSW1 -= (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);

          /* '<S117>:1:115' Mode2Num = Mode2Num+1; */
          Mode2Num++;
        }

        /* '<S117>:1:117' if (D2_End*LDDir>=D2_des && ModeFlg==2) */
        if ((c_T1 >= LKAS_DW.LL_DesDvt_C_p) && (((sint32)rtb_Merge) == 2)) {
          /* '<S117>:1:118' DelteSW1 =  DelteSW1+LDDir*StpLngth*((1/2)^(Mode2Num+1)); */
          DelteSW1 += (LKAS_DW.Merge * StpLngth) * powf(0.5F, Mode2Num + 1.0F);

          /* '<S117>:1:119' Mode2Num = Mode2Num+1; */
          Mode2Num++;
        }

        /* '<S117>:1:121' [T1,T2,D2_End] = func3(Delte_Psi1Ini,Delte_Psi2,DelteSW1,KMax,Delte_Psi1,... */
        /* '<S117>:1:122'                                 DelteSW0,u,Kw,LDDir); */
        /*     ���ܣ� */
        /*     ��֪������һ��ʱ��ʼ����ǣ��뿪����ʱ����������ǣ�����һ��ʱ��ƫ�����ĳ�ʼֵ */
        /*           �������ʱ��ת����ת�ǳ�ʼֵ����ʼת����ת�ǣ����١� */
        /*     ���裺1������һ������ʱ��ת����ת�ǣ�ʵ��һ���������ĺ���Ǳ仯�� */
        /*           2������һ������ʱ��ת����ת�ǣ�ʵ�ֶ����������ĺ���Ǳ仯�� */
        /*           3������ʵ��һ���������ĺ���Ǳ仯����������һ��ƫ�����仯��D1�� */
        /*           4������ʵ�ֶ����������ĺ���Ǳ仯���������Ķ���ƫ�����仯��D2�� */
        /*           5) ���ݽ���һ��ʱ��ƫ�����ĳ�ʼֵ��D1��D2���õ���������ʱ��ƫ����D2_End */
        /*      */
        /*     ����� һ��ʹ��ʱ��T1������ʹ��ʱ��T2����������ʱ��ƫ����D2_End */
        /* ************************************************************************** */
        /*  end of function func1 */
        /*  function [K1,K2_1,K2_2,DelteSW1]= func2(Delte_Psi1,Delte_Psi2,D1_Ini,T1,... */
        /*                                          D2_des,LDDir,DelteSW0,u,Kw) */
        /*  %    ���ܣ� */
        /*  %    ��֪��һ����������Ǳ仯�����뿪����ʱ����������ǣ���������ʱ������ƫ�����ľ���ֵ */
        /*  %          �����ĳ���ƫ��ķ��򣬳�ʼת����ת�ǣ����١� */
        /*  %    Լ����1������һ������ʱ��ת����ת�ǣ�ʵ�������ĺ���Ǳ仯�� */
        /*  %          2����������ʱ��ƫ����ʵ������ƫ������ */
        /*  %          3����������ʱ��ʵ�������ĺ���ǵĺ���ǣ� */
        /*  %          4����������ʱ��ת����ת��Ϊ�㡣 */
        /*  %     */
        /*  %    ����� һ��ת����ת�Ǳ仯��K1������ת����ת�Ǳ仯��K2_1��K2_2�� */
        /*  %           �������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
        /*  %************************************************************************** */
        /*  %   ����Լ��2��3��4���������DelteSW1�Ͷ���ת����ת�Ǳ仯�ʡ� */
        /*  Delte_D = LDDir*D2_des-D1_Ini; */
        /*  Delte_Psi = Delte_Psi2-Delte_Psi1; */
        /*  DelteSW1 = ((4/3)*(Delte_Psi/Kw)*(Delte_Psi/Kw)-(1/3)*(Delte_Psi/Kw)*DelteSW0*T1-(1/6)*DelteSW0*DelteSW0*T1*T1... */
        /*              +2*(Delte_Psi/Kw)*Delte_Psi1-Delte_Psi1*DelteSW0*T1)/(Delte_D/(Kw*u)+(1/3)*(Delte_Psi/Kw)*T1); */
        /*  T2 = (2*(Delte_Psi/Kw)-(DelteSW1+DelteSW0)*T1)/DelteSW1; */
        /*  K2 = -DelteSW1/T2; */
        /*  %   ����Լ��1�ͽ������ʱ��ת����ת�ǳ�ʼֵDelteSW1���������һ��ת����ת�Ǳ仯�ʡ� */
        /*  K1 = (DelteSW1-DelteSW0)/T1; */
        /*  % */
        /*  %************************************************************************** */
        /*  %   ����� */
        /*  K2_1 = K2; */
        /*  K2_2 = K2; */
        /*   */
        /*  end % end of function func1 */
        /* '<S117>:1:233' K1_0 = (DelteSW1*DelteSW1-DelteSW0*DelteSW0)*Kw/(-2*Delte_Psi1); */
        K1_0 = (((DelteSW1 * DelteSW1) - (DelteSW0 * DelteSW0)) * Kw) / (-2.0F *
          LKAS_DW.In_if);

        /* '<S117>:1:234' if (LDDir*K1_0 > KMax) */
        if ((LKAS_DW.Merge * K1_0) > LKAS_DW.SWARmax) {
          /* '<S117>:1:235' K1_1 = single(LDDir*KMax); */
          K1_0 = LKAS_DW.Merge * LKAS_DW.SWARmax;
        } else {
          /* '<S117>:1:236' else */
          /* '<S117>:1:237' K1_1 = K1_0; */
        }

        /*  */
        /* '<S117>:1:240' T1 = (DelteSW1-DelteSW0)/K1_1; */
        K1_0 = (DelteSW1 - DelteSW0) / K1_0;

        /* '<S117>:1:243' Delte_Psi = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1)*T1*Kw; */
        K1 = ((((DelteSW0 + DelteSW1) * 0.5F) * K1_0) * Kw) + LKAS_DW.In_g;

        /*  DelteSW1_0 = 2*(Delte_Psi2-Delte_Psi1Ini)/(T1*Kw)-DelteSW0; */
        /*  if (-1*Delte_Psi >= -1*Delte_Psi2) */
        /*     DelteSW1_1 = DelteSW1_0; */
        /*  else */
        /*     DelteSW1_1 = DelteSW1; */
        /*  end */
        /*  Delte_Psi_1 = Delte_Psi1Ini+0.5*(DelteSW0+DelteSW1_1)*T1*Kw; */
        /* '<S117>:1:251' T2 = 2*(Delte_Psi2-Delte_Psi)/(DelteSW1*Kw); */
        T2 = ((LKAS_DW.In_jb - K1) * 2.0F) / (DelteSW1 * Kw);

        /*      T1 = 2*(Delte_Psi-Delte_Psi1)/((DelteSW0+DelteSW1)*Kw); */
        /*      T1 = TTLC; */
        /*      T2 = 2*(Delte_Psi2-Delte_Psi)/(DelteSW1*Kw); */
        /* '<S117>:1:256' D1 = u*((1/6)*Kw*(DelteSW1+2*DelteSW0)*T1*T1+Delte_Psi1Ini*T1); */
        /* '<S117>:1:257' D2 = u*((1/3)*Kw*T2*T2*DelteSW1+Delte_Psi*T2); */
        /* '<S117>:1:258' D2_End = D2+D1; */
        D2_End = (((((((2.0F * DelteSW0) + DelteSW1) * (0.166666672F * Kw)) *
                     K1_0) * K1_0) + (LKAS_DW.In_g * K1_0)) * u) +
          ((((((0.333333343F * Kw) * T2) * T2) * DelteSW1) + (K1 * T2)) * u);
      }

      /* '<S117>:1:124' K1 = (DelteSW1-DelteSW0)/T1; */
      K1 = (DelteSW1 - DelteSW0) / K1_0;

      /* '<S117>:1:125' K2_1 = (0-DelteSW1)/T2; */
      K2 = (0.0F - DelteSW1) / T2;

      /* '<S117>:1:126' K2_2 = K2_1; */
      K2_2 = K2;
    }
  }

  /*  */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S117>:1:130' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S117>:1:132' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = K1 * 57.2957802F;

  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /* '<S117>:1:134' K1K2Det_dphi2PhSWAGrad1 = K2_1*(180/pi); */
  LKAS_DW.K1K2Det_dphi2PhSWAGrad1 = K2 * 57.2957802F;

  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /* '<S117>:1:136' K1K2Det_dphi2PhSWAGrad2 = K2_2*(180/pi); */
  rtb_K1K2Det_dphi2PhSWAGrad2 = K2_2 * 57.2957802F;

  /*  */
  /* '<S117>:1:138' K1K2Det_dphi1PhHdAgIni = Delte_Psi1; */
  rtb_K1K2Det_dphi1PhHdAgIni = LKAS_DW.In_if;

  /* Update for Memory: '<S118>/Memory' */
  /*  */
  /* '<S117>:1:140' K1K2Det_bsTDivInfoOut_ModeFlg = ModeFlg; */
  /* '<S117>:1:141' K1K2Det_bsTDivInfoOut_Mode1Num = Mode1Num; */
  /* '<S117>:1:142' K1K2Det_bsTDivInfoOut_Mode2Num = Mode2Num; */
  /* '<S117>:1:143' K1K2Det_bsTDivInfoOut_Ph2DvtEnd = D2_End; */
  /* '<S117>:1:144' K1K2Det_bsTDivInfoOut_Ph2SWAIni = DelteSW1; */
  LKAS_DW.Memory_PreviousInput_lr = rtb_Add;

  /* Update for Memory: '<S112>/Memory' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory_PreviousInput_dh = rtb_Merge;

  /* Update for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = rtb_Add_oi;

  /* Update for Memory: '<S112>/Memory1' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory1_PreviousInput_m = Mode1Num;

  /* Update for Memory: '<S120>/Memory' */
  LKAS_DW.Memory_PreviousInput_jo = rtb_Add_ig;

  /* Update for Memory: '<S112>/Memory2' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory2_PreviousInput = Mode2Num;

  /* Update for Memory: '<S121>/Memory' */
  LKAS_DW.Memory_PreviousInput_hd = rtb_Add_cy;

  /* Update for Memory: '<S112>/Memory3' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory3_PreviousInput_b = D2_End;

  /* Update for Memory: '<S122>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = rtb_Add_e2;

  /* Update for Memory: '<S112>/Memory4' incorporates:
   *  MATLAB Function: '<S112>/MATLAB Function'
   */
  LKAS_DW.Memory4_PreviousInput = DelteSW1;
}

/*
 * Output and update for action system:
 *    '<S136>/if action '
 *    '<S137>/if action '
 *    '<S138>/if action '
 *    '<S139>/if action '
 *    '<S140>/if action '
 *    '<S141>/if action '
 *    '<S142>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S153>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S168>/If Action Subsystem'
 *    '<S168>/If Action Subsystem4'
 *    '<S116>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S170>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for atomic system:
 *    '<S178>/Saturable Gain Lut (SatGainLut)'
 *    '<S178>/Saturable Gain Lut (SatGainLut)1'
 */
void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32 rtu_InputLimLwr,
  float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32 rtu_GainLimUpr,
  float32 *rty_Gain)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S181>:1' */
  /*  Function Name: Saturable Gain Lut */
  /*  */
  /*  Description:  */
  /*    Saturable Gain Lookup Table. */
  /*  */
  /*  Assumptions and Limitation: */
  /*    The data type of all inputs and output is single. */
  /*  */
  /*  Inputs: */
  /*    Input: */
  /*    InputLimLwr: */
  /*    InputLimUpr: */
  /*    GainLimLwr: */
  /*    GainLimUpr: */
  /*  */
  /*  Outputs: */
  /*    Gain: The result of Looking up table. */
  /*  $Revision: 1.0$ */
  /*  $Author: Zhang Jianwei$ */
  /*  $Date: January 27, 2019$ */
  /*  ________________________________________ */
  /* '<S181>:1:25' if Input <= InputLimLwr */
  if (rtu_Input <= rtu_InputLimLwr) {
    /* '<S181>:1:26' Gain = GainLimLwr; */
    *rty_Gain = rtu_GainLimLwr;
  } else if (rtu_Input >= rtu_InputLimUpr) {
    /* '<S181>:1:27' elseif Input >= InputLimUpr */
    /* '<S181>:1:28' Gain = GainLimUpr; */
    *rty_Gain = rtu_GainLimUpr;
  } else {
    /* '<S181>:1:29' else */
    /* '<S181>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
    /* '<S181>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
    *rty_Gain = (((rtu_Input - rtu_InputLimLwr) / (rtu_InputLimUpr -
      rtu_InputLimLwr)) * (rtu_GainLimUpr - rtu_GainLimLwr)) + rtu_GainLimLwr;
  }
}

/*
 * Output and update for action system:
 *    '<S185>/If Action Subsystem'
 *    '<S185>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_b(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S187>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S208>/if action '
 *    '<S209>/if action '
 *    '<S216>/if action '
 *    '<S217>/if action '
 */
void LKAS_ifaction_f(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S210>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S201>/If Action Subsystem'
 *    '<S202>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_g(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_n_T *localDW)
{
  uint16 rtb_Saturation1_gi;
  uint16 rtb_Saturation1_lh;

  /* Outputs for Enabled SubSystem: '<S201>/If Action Subsystem' incorporates:
   *  EnablePort: '<S206>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S208>/Add' incorporates:
     *  Constant: '<S208>/Constant'
     *  Memory: '<S208>/Memory'
     */
    rtb_Saturation1_gi = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S208>/Saturation1' */
    if (rtb_Saturation1_gi >= ((uint16)10000U)) {
      rtb_Saturation1_gi = ((uint16)10000U);
    }

    /* End of Saturate: '<S208>/Saturation1' */

    /* If: '<S208>/If' incorporates:
     *  Constant: '<S208>/Constant2'
     */
    if (rtb_Saturation1_gi <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S208>/if action ' incorporates:
       *  ActionPort: '<S210>/Action Port'
       */
      LKAS_ifaction_f(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S208>/if action ' */
    }

    /* End of If: '<S208>/If' */

    /* Sum: '<S209>/Add' incorporates:
     *  Constant: '<S209>/Constant'
     *  Memory: '<S209>/Memory'
     */
    rtb_Saturation1_lh = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_l));

    /* Saturate: '<S209>/Saturation1' */
    if (rtb_Saturation1_lh >= ((uint16)10000U)) {
      rtb_Saturation1_lh = ((uint16)10000U);
    }

    /* End of Saturate: '<S209>/Saturation1' */

    /* If: '<S209>/If' incorporates:
     *  Constant: '<S209>/Constant2'
     */
    if (rtb_Saturation1_lh == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S209>/if action ' incorporates:
       *  ActionPort: '<S211>/Action Port'
       */
      LKAS_ifaction_f(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S209>/if action ' */
    }

    /* End of If: '<S209>/If' */

    /* Update for Memory: '<S208>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_gi;

    /* Update for Memory: '<S209>/Memory' */
    localDW->Memory_PreviousInput_l = rtb_Saturation1_lh;
  }

  /* End of Outputs for SubSystem: '<S201>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S201>/If Action Subsystem2'
 *    '<S202>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_c(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S207>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S207>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S78>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_f = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c31_LKAS = 0U;
  LKAS_DW.is_c31_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.LDWSM_stLDWActvFlg = 0U;
  LKAS_DW.LDWSM_stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S78>/LDW_State_Machine'
 * Block description for: '<S78>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S78>/LDW_State_Machine'
   *
   * Block description for '<S78>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c31_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c31_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S267>:2' */
    LKAS_DW.is_c31_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S267>:1' */
    /* Transition: '<S267>:31' */
    LKAS_DW.is_SysOff_f = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S267>:30' */
    LKAS_DW.LDWSM_stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c31_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S267>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)
             LKAS_DW.LKA_Mode) == 2))) {
        /* Transition: '<S267>:38' */
        /* Exit Internal 'Fault': '<S267>:36' */
        LKAS_DW.is_c31_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S267>:3' */
        /* Transition: '<S267>:77' */
        LKAS_DW.is_SysOn_n = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S267>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 0) && tmp) {
        /* Transition: '<S267>:40' */
        /* Exit Internal 'Fault': '<S267>:36' */
        LKAS_DW.is_c31_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_f = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S267>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else {
        LKAS_DW.LDWSM_stLDWState = 6U;

        /* During 'LDWFault': '<S267>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S267>:1' */
      if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
          && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S267>:39' */
        /* Exit Internal 'SysOff': '<S267>:1' */
        LKAS_DW.is_SysOff_f = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c31_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S267>:36' */
        /* Transition: '<S267>:75' */
        /* Entry 'LDWFault': '<S267>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
                  == 2)) {
        /* Transition: '<S267>:41' */
        /* Exit Internal 'SysOff': '<S267>:1' */
        LKAS_DW.is_SysOff_f = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c31_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S267>:3' */
        /* Transition: '<S267>:77' */
        LKAS_DW.is_SysOn_n = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S267>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_f) == LKAS_IN_Unavailable) {
        LKAS_DW.LDWSM_stLDWState = 0U;

        /* During 'Unavailable': '<S267>:30' */
        if (((sint32)LKAS_DW.LKA_Mode) == 0) {
          /* Transition: '<S267>:35' */
          LKAS_DW.is_SysOff_f = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S267>:32' */
          LKAS_DW.LDWSM_stLDWState = 1U;
        }
      } else {
        LKAS_DW.LDWSM_stLDWState = 1U;

        /* During 'Unselected': '<S267>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S267>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S267>:37' */
        /* Exit Internal 'SysOn': '<S267>:3' */
        if (((uint32)LKAS_DW.is_SysOn_n) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S267>:102' */
          switch (LKAS_DW.is_Normal_g) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S267>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S267>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c31_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S267>:36' */
        /* Transition: '<S267>:75' */
        /* Entry 'LDWFault': '<S267>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) != 1) && (((sint32)LKAS_DW.LKA_Mode)
                  != 2)) {
        /* Transition: '<S267>:42' */
        /* Exit Internal 'SysOn': '<S267>:3' */
        if (((uint32)LKAS_DW.is_SysOn_n) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S267>:102' */
          switch (LKAS_DW.is_Normal_g) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S267>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S267>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_n = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c31_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_f = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S267>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_n) == LKAS_IN_LDWSelected) {
        LKAS_DW.LDWSM_stLDWState = 2U;

        /* During 'LDWSelected': '<S267>:47' */
        if ((LKAS_DW.Merge_e) && (!LKAS_DW.Merge1_p)) {
          /* Transition: '<S267>:50' */
          LKAS_DW.is_SysOn_n = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S267>:102' */
          /* Transition: '<S267>:113' */
          LKAS_DW.is_Normal_g = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S267>:112' */
          LKAS_DW.LDWSM_stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S267>:102' */
        if (LKAS_DW.Merge1_p) {
          /* Transition: '<S267>:44' */
          /* Exit Internal 'Normal': '<S267>:102' */
          switch (LKAS_DW.is_Normal_g) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S267>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S267>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_g = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_n = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S267>:47' */
          LKAS_DW.LDWSM_stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_g) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.LDWSM_stLDWState = 3U;

            /* During 'LDWEnable': '<S267>:112' */
            if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_cf)) {
              /* Transition: '<S267>:118' */
              LKAS_DW.is_Normal_g = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S267>:114' */
              LKAS_DW.LDWSM_stLDWState = 4U;
              LKAS_DW.LDWSM_stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_cf))
              {
                /* Transition: '<S267>:119' */
                LKAS_DW.is_Normal_g = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S267>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.LDWSM_stLDWState = 4U;

            /* During 'LDWLeftActive': '<S267>:114' */
            if (LKAS_DW.Merge_cf) {
              /* Transition: '<S267>:116' */
              /* Exit 'LDWLeftActive': '<S267>:114' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_g = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S267>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_cf))
              {
                /* Transition: '<S267>:120' */
                /* Exit 'LDWLeftActive': '<S267>:114' */
                LKAS_DW.is_Normal_g = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S267>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LDWSM_stLDWState = 5U;

            /* During 'LDWRightActive': '<S267>:115' */
            if (LKAS_DW.Merge_cf) {
              /* Transition: '<S267>:117' */
              /* Exit 'LDWRightActive': '<S267>:115' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_g = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S267>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_cf))
              {
                /* Transition: '<S267>:121' */
                /* Exit 'LDWRightActive': '<S267>:115' */
                LKAS_DW.is_Normal_g = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S267>:114' */
                LKAS_DW.LDWSM_stLDWState = 4U;
                LKAS_DW.LDWSM_stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S78>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S78>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_h;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
  LKAS_DW.is_active_c32_LKAS = 0U;
  LKAS_DW.is_c32_LKAS = LKAS_IN_NO_ACTIVE_CHILD_h;
  LKAS_DW.LKASM_stLKAActvFlg = 0U;
  LKAS_DW.LKASM_stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S78>/LKA_State_Machine'
 * Block description for: '<S78>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S78>/LKA_State_Machine'
   *
   * Block description for '<S78>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  if (((uint32)LKAS_DW.is_active_c32_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    LKAS_DW.is_active_c32_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    /* Transition: '<S268>:2' */
    LKAS_DW.is_c32_LKAS = LKAS_IN_SysOff_e;

    /* Entry Internal 'SysOff': '<S268>:1' */
    /* Transition: '<S268>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_o;

    /* Entry 'Unavailable': '<S268>:30' */
    LKAS_DW.LKASM_stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c32_LKAS) {
     case LKAS_IN_Fault_l:
      /* During 'Fault': '<S268>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.LKA_Mode) == 2)) {
        /* Transition: '<S268>:38' */
        /* Exit Internal 'Fault': '<S268>:36' */
        LKAS_DW.is_c32_LKAS = LKAS_IN_SysOn_m;

        /* Entry Internal 'SysOn': '<S268>:3' */
        /* Transition: '<S268>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S268>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)
                    LKAS_DW.LKA_Mode) == 1)) && tmp) {
        /* Transition: '<S268>:40' */
        /* Exit Internal 'Fault': '<S268>:36' */
        LKAS_DW.is_c32_LKAS = LKAS_IN_SysOff_e;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_d;

        /* Entry 'Unselected': '<S268>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else {
        LKAS_DW.LKASM_stLKAState = 6U;

        /* During 'LKAFault': '<S268>:72' */
      }
      break;

     case LKAS_IN_SysOff_e:
      /* During 'SysOff': '<S268>:1' */
      if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S268>:39' */
        /* Exit Internal 'SysOff': '<S268>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_h;
        LKAS_DW.is_c32_LKAS = LKAS_IN_Fault_l;

        /* Entry Internal 'Fault': '<S268>:36' */
        /* Transition: '<S268>:74' */
        /* Entry 'LKAFault': '<S268>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode) == 2) {
        /* Transition: '<S268>:41' */
        /* Exit Internal 'SysOff': '<S268>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_h;
        LKAS_DW.is_c32_LKAS = LKAS_IN_SysOn_m;

        /* Entry Internal 'SysOn': '<S268>:3' */
        /* Transition: '<S268>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S268>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_o) {
        LKAS_DW.LKASM_stLKAState = 0U;

        /* During 'Unavailable': '<S268>:30' */
        if ((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)LKAS_DW.LKA_Mode) ==
             1)) {
          /* Transition: '<S268>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_d;

          /* Entry 'Unselected': '<S268>:32' */
          LKAS_DW.LKASM_stLKAState = 1U;
        }
      } else {
        LKAS_DW.LKASM_stLKAState = 1U;

        /* During 'Unselected': '<S268>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S268>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S268>:37' */
        /* Exit Internal 'SysOn': '<S268>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_m) {
          /* Exit Internal 'Normal': '<S268>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S268>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S268>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
        }

        LKAS_DW.is_c32_LKAS = LKAS_IN_Fault_l;

        /* Entry Internal 'Fault': '<S268>:36' */
        /* Transition: '<S268>:74' */
        /* Entry 'LKAFault': '<S268>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode) != 2) {
        /* Transition: '<S268>:42' */
        /* Exit Internal 'SysOn': '<S268>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_m) {
          /* Exit Internal 'Normal': '<S268>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S268>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S268>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_h;
        }

        LKAS_DW.is_c32_LKAS = LKAS_IN_SysOff_e;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_d;

        /* Entry 'Unselected': '<S268>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.LKASM_stLKAState = 2U;

        /* During 'LKASelected': '<S268>:19' */
        if ((LKAS_DW.Merge1_a) && (!LKAS_DW.Merge2)) {
          /* Transition: '<S268>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_m;

          /* Entry Internal 'Normal': '<S268>:102' */
          /* Transition: '<S268>:103' */
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S268>:108' */
          LKAS_DW.LKASM_stLKAState = 3U;
        }
      } else {
        /* During 'Normal': '<S268>:102' */
        if (LKAS_DW.Merge2) {
          /* Transition: '<S268>:25' */
          /* Exit Internal 'Normal': '<S268>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S268>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S268>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_h;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

          /* Entry 'LKASelected': '<S268>:19' */
          LKAS_DW.LKASM_stLKAState = 2U;
        } else {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKAEnable:
            LKAS_DW.LKASM_stLKAState = 3U;

            /* During 'LKAEnable': '<S268>:108' */
            if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_l)) {
              /* Transition: '<S268>:105' */
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

              /* Entry 'LKALeftActive': '<S268>:109' */
              LKAS_DW.LKASM_stLKAState = 4U;
              LKAS_DW.LKASM_stLKAActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_l))
              {
                /* Transition: '<S268>:104' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S268>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LKALeftActive:
            LKAS_DW.LKASM_stLKAState = 4U;

            /* During 'LKALeftActive': '<S268>:109' */
            if (LKAS_DW.Merge1_l) {
              /* Transition: '<S268>:106' */
              /* Exit 'LKALeftActive': '<S268>:109' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S268>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_l))
              {
                /* Transition: '<S268>:111' */
                /* Exit 'LKALeftActive': '<S268>:109' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S268>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LKASM_stLKAState = 5U;

            /* During 'LKARightActive': '<S268>:110' */
            if (LKAS_DW.Merge1_l) {
              /* Transition: '<S268>:107' */
              /* Exit 'LKARightActive': '<S268>:110' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S268>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_l))
              {
                /* Transition: '<S268>:112' */
                /* Exit 'LKARightActive': '<S268>:110' */
                LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

                /* Entry 'LKALeftActive': '<S268>:109' */
                LKAS_DW.LKASM_stLKAState = 4U;
                LKAS_DW.LKASM_stLKAActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S78>/LKA_State_Machine' */
}

/*
 * Output and update for action system:
 *    '<S289>/Ph1SWA'
 *    '<S298>/Ph1SWA'
 *    '<S325>/Ph1SWA'
 *    '<S335>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S293>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S293>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S289>/Ph2SWA'
 *    '<S298>/Ph2SWA'
 *    '<S325>/Ph2SWA'
 *    '<S335>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S294>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S294>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S289>/Ph3SWA'
 *    '<S325>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S295>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S298>/Ph3SWA'
 *    '<S335>/Ph3SWA'
 */
void LKAS_Ph3SWA_g(float32 *rty_Out)
{
  /* SignalConversion: '<S304>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S304>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S348>/If Action Subsystem3'
 *    '<S387>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S353>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S361>/If Action Subsystem4'
 *    '<S361>/If Action Subsystem3'
 *    '<S470>/If Action Subsystem3'
 *    '<S470>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S373>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S373>/Constant'
   */
  *rty_Out = false;
}

/*
 * Output and update for action system:
 *    '<S399>/If Action Subsystem'
 *    '<S399>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_j(boolean *rty_Out)
{
  /* SignalConversion: '<S403>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S403>/Constant'
   */
  *rty_Out = true;
}

/*
 * Output and update for atomic system:
 *    '<S484>/MATLAB Function'
 *    '<S503>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_DvtThresUprLDW, float32 rtu_LaneWidth,
  float32 rtu_LKA_CarWidth, float32 *rty_ThresDet_coefficient)
{
  float32 tmp;

  /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Enable Condition  (EnaC)/LDW Own Condition (LDWOwnC)/Vehicle Position Check (VehPosChk)/Subsystem/MATLAB Function': '<S485>:1' */
  /* '<S485>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
  /* '<S485>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
  /* '<S485>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
  /* '<S485>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
  /* '<S485>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
  tmp = (2.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth;
  *rty_ThresDet_coefficient = fminf(fmaxf(0.0F, (fminf(fmaxf(tmp, rtu_LaneWidth),
    (6.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth) - tmp) / (4.0F *
    rtu_DvtThresUprLDW)), 1.0F);
}

/*
 * System initialize for enable system:
 *    '<S274>/Count_5s1'
 *    '<S274>/Count_5s2'
 */
void LKAS_Count_5s1_Init(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S539>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S274>/Count_5s1'
 *    '<S274>/Count_5s2'
 */
void LKAS_Count_5s1_Reset(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S539>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S274>/Count_5s1'
 *    '<S274>/Count_5s2'
 */
void LKAS_Count_5s1_Disable(boolean *rty_Out, DW_Count_5s1_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S274>/Count_5s1' incorporates:
   *  EnablePort: '<S539>/Enable'
   */
  /* Disable for Outport: '<S539>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S274>/Count_5s1' */
  localDW->Count_5s1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S274>/Count_5s1'
 *    '<S274>/Count_5s2'
 */
void LKAS_Count_5s1(boolean rtu_Enable, float32 rtu_SampleTime, boolean *rty_Out,
                    DW_Count_5s1_LKAS_T *localDW)
{
  float32 rtb_Saturation_g0;

  /* Outputs for Enabled SubSystem: '<S274>/Count_5s1' incorporates:
   *  EnablePort: '<S539>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Reset(localDW);
      localDW->Count_5s1_MODE = true;
    }

    /* Sum: '<S539>/Add' incorporates:
     *  Memory: '<S539>/Memory'
     */
    rtb_Saturation_g0 = localDW->Memory_PreviousInput + rtu_SampleTime;

    /* Saturate: '<S539>/Saturation' */
    if (rtb_Saturation_g0 > 11.0F) {
      rtb_Saturation_g0 = 11.0F;
    } else {
      if (rtb_Saturation_g0 < 0.0F) {
        rtb_Saturation_g0 = 0.0F;
      }
    }

    /* End of Saturate: '<S539>/Saturation' */

    /* RelationalOperator: '<S539>/Relational Operator' incorporates:
     *  Constant: '<S539>/Constant1'
     */
    *rty_Out = (rtb_Saturation_g0 >= ((float32)((uint16)5U)));

    /* Update for Memory: '<S539>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_g0;
  } else {
    if (localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S274>/Count_5s1' */
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_VehSpd;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_IMAPve_g_SW_Angle;
  float32 rtb_Gain_g;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_Gain_c;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_LFClb_TFC_KpVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KpVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KpV1_C;
  float32 rtb_LL_LFClb_TFC_KpV2_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KdV1_C;
  float32 rtb_LL_LFClb_TFC_KdV2_C;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_R0_VR_a;
  float32 rtb_L0_VR_g;
  float32 rtb_R0_W_f;
  float32 rtb_L0_W_e;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_EPS_SteeringAngle;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_VR;
  float32 rtb_R1_W;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_p;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1;
  float32 rtb_Add5_n;
  float32 rtb_Add_fk;
  float32 rtb_Add_nk;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge_a;
  float32 rtb_Switch_gp;
  float32 rtb_Saturation_d;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Multiply;
  float32 rtb_Switch_nw;
  float32 rtb_Switch2_o;
  float32 rtb_Switch_h;
  float32 rtb_Saturation_k;
  float32 rtb_Abs1_c;
  float32 rtb_Abs_g;
  float32 rtb_UnaryMinus_k;
  float32 rtb_Merge1_j;
  float32 rtb_Divide_m;
  float32 rtb_Switch_o2;
  float32 rtb_Switch2_f;
  float32 rtb_Divide_k;
  float32 rtb_Switch_h1;
  float32 rtb_Switch2_l;
  float32 rtb_Merge1_d;
  float32 rtb_Divide_j;
  float32 rtb_Switch_d;
  float32 rtb_Switch2_ol;
  float32 rtb_Divide_gn;
  float32 rtb_Switch_b;
  float32 rtb_Switch2_b;
  float32 rtb_Multiply_m;
  float32 rtb_Switch_m;
  float32 rtb_Switch2_cx;
  float32 rtb_Memory_h;
  float32 rtb_Merge1_p;
  float32 rtb_Divide_p;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_e;
  float32 rtb_Divide_gx;
  float32 rtb_Switch_k;
  float32 rtb_Switch2_j;
  float32 rtb_Memory_ev;
  float32 rtb_Merge1_c;
  float32 rtb_Divide_e;
  float32 rtb_Switch_a0;
  float32 rtb_Switch2_d;
  float32 rtb_Divide_l;
  float32 rtb_Switch_c;
  float32 rtb_Switch2_da;
  float32 rtb_phiHdAg;
  float32 rtb_Add_k;
  float32 rtb_Add_py;
  float32 rtb_Add_ij;
  float32 rtb_Add_j;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_ThresDet_coefficient;
  float32 rtb_Saturation2;
  float32 rtb_Merge_b;
  float32 rtb_Abs1_k;
  float32 rtb_Abs_d;
  float32 rtb_Add1_j4;
  float32 rtb_Merge_c;
  float32 rtb_Merge_n;
  float32 rtb_Merge_ag;
  float32 rtb_Add_mb;
  float32 rtb_Saturation6;
  float32 rtb_Saturation2_b;
  float32 rtb_Saturation2_c;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_go;
  float32 rtb_Saturation_j;
  float32 rtb_Add1_o;
  float32 rtb_kphtomps_k;
  float32 rtb_Saturation_gq;
  float32 rtb_Switch2_a;
  float32 rtb_Switch_jt;
  float32 rtb_Switch2_dt;
  float32 rtb_Gain1_e;
  float32 rtb_Switch_p;
  float32 rtb_Switch2_g;
  float32 rtb_Divide5;
  float32 rtb_Divide2_h;
  float32 rtb_Merge_ah;
  float32 rtb_Switch_gl;
  float32 rtb_Switch2_dd;
  float32 rtb_Divide7;
  float32 rtb_Switch_pg;
  float32 rtb_Switch2_k;
  float32 rtb_Saturation_bs;
  float32 rtb_Switch_gc;
  float32 rtb_Add_np;
  float32 rtb_Switch_bz;
  float32 rtb_Switch2_oj;
  float32 rtb_UkYk1_g;
  float32 rtb_Switch_ac;
  float32 rtb_Switch2_om;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_h;
  float32 rtb_Saturation_m;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_T2;
  float32 rtb_Plan;
  float32 rtb_T1_i;
  float32 rtb_Plan_b;
  float32 rtb_T1_g;
  float32 rtb_ThresDet_coefficient_n;
  float32 rtb_Gain_ji;
  float32 rtb_Yk1_i;
  float32 rtb_Saturation4;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_m;
  uint16 rtb_Saturation1_h;
  uint16 rtb_Saturation1_o;
  uint16 rtb_Add_js;
  uint16 rtb_Saturation1_hi;
  uint16 rtb_Saturation1_ip;
  uint16 rtb_Saturation1_c;
  uint16 rtb_Saturation1_g;
  uint16 rtb_Saturation2_p;
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_o;
  uint8 rtb_L0_Type_h;
  uint8 rtb_LDW_Warn_Mode;
  uint8 rtb_IMAPve_d_APA_AutoPark_WorkS;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L1_Type;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_R1_Type;
  uint8 rtb_IMAPve_d_SWS_Failure_Status;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_LDW_State;
  uint8 rtb_DACMode;
  uint8 rtb_Saturation1_ln;
  boolean rtb_Compare_ap;
  boolean rtb_Compare_cc;
  boolean rtb_Compare_i4c;
  boolean rtb_Compare_d;
  boolean rtb_Compare_d2;
  boolean rtb_Compare_b4;
  boolean rtb_Compare_js;
  boolean rtb_Compare_fa;
  boolean rtb_Compare_h;
  boolean rtb_Compare_nl;
  boolean rtb_Compare_ds;
  boolean rtb_UnitDelay_l;
  boolean rtb_Compare_e3;
  boolean rtb_Merge_i;
  boolean rtb_Merge_j;
  boolean rtb_Compare_ik;
  boolean rtb_UnitDelay_m;
  boolean rtb_Compare_pr;
  boolean rtb_Merge_iy;
  boolean rtb_Compare_ac;
  boolean rtb_Compare_br;
  boolean rtb_LogicalOperator1_j;
  boolean rtb_Compare_oi;
  boolean rtb_Compare_hm;
  boolean rtb_RelationalOperator6_b;
  boolean rtb_RelationalOperator5;
  float32 x10;
  float32 x20;
  float32 x1;
  sint32 i;
  uint8 rtb_Mod1;
  uint8 rtb_IMAPve_d_SAS_Trim_State;
  boolean rtb_LKA_Main_Switch;
  float32 rtb_Abs_c;
  float32 rtb_L0_C0;
  float32 rtb_L0_C2;
  float32 rtb_R0_C2;
  float32 rtb_Saturation;
  float32 rtb_R0_C0;
  uint8 rtb_L0_Q;
  uint8 rtb_R0_Q;
  float32 rtb_Add1;
  float32 rtb_Saturation1_p1;
  uint8 rtb_L0_Type;
  uint8 rtb_R0_Type;
  float32 rtb_L0_C1;
  float32 rtb_R0_C1;
  float32 rtb_L0_C3;
  uint8 rtb_IMAPve_d_Camera_Status;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  float32 rtb_IMAPve_g_ESC_LatAcc;
  boolean rtb_BCM_Left_Light;
  boolean rtb_BCM_Right_Light;
  uint8 rtb_IMAPve_d_TCU_Actual_Gear;
  uint8 rtb_TCU_ActualGear;
  uint8 rtb_Hands_Off_Warning_j;
  uint8 rtb_LKA_Action_Indication_j;
  float32 rtb_L0_C0_a;
  float32 rtb_L0_C1_p;
  float32 rtb_L0_C2_j;
  float32 rtb_L0_C3_k;
  float32 rtb_R0_C0_e;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LKASWASyn_TrqSwaAddSwt;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_TTLC_m;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_l;
  boolean rtb_LogicalOperator3_e;
  boolean rtb_LogicalOperator3_a;
  boolean rtb_LogicalOperator_i4;
  boolean rtb_Compare_jl;
  boolean rtb_LogicalOperator_no;
  boolean rtb_Compare_dq;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_k0f;
  boolean rtb_stDvrTkConFlg_p;
  boolean rtb_LogicalOperator_ee;
  uint8 rtb_CastToSingle3;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge;
  boolean rtb_Compare_gz;
  boolean rtb_Compare_mc;
  float32 rtb_offset;
  uint16 rtb_Saturation_pd;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  float32 rtb_TTLC;
  float32 rtb_TLft;
  float32 rtb_LKA_Veh2CamL_C_tmp;
  float32 rtb_Add5_n_tmp;
  float32 rtb_LogicalOperator3_ls_tmp;
  float32 rtb_LogicalOperator3_ls_tmp_0;
  float32 rtb_Gain2_0;
  float32 rtb_Add_fk_tmp;
  float32 rtb_Add_nk_tmp;
  boolean exitg1;

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/FDMMve_d_LkaFcnConf_1' incorporates:
   *  Inport: '<Root>/FDMMve_d_LkaFcnConf'
   */
  rtb_Mod1 = (uint8)
    Rte_IRead_Runnable_LKAS_Step_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf();

  /* Switch: '<S46>/Switch' incorporates:
   *  Constant: '<S46>/Constant3'
   *  Constant: '<S46>/Constant4'
   */
  if (rtb_Mod1 > ((uint8)0U)) {
    rtb_L0_Q = ((uint8)1U);
  } else {
    rtb_L0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S46>/Switch' */

  /* Saturate: '<S46>/Saturation1' */
  if (rtb_Mod1 > ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  } else {
    if (rtb_Mod1 < ((uint8)1U)) {
      rtb_Mod1 = ((uint8)1U);
    }
  }

  /* End of Saturate: '<S46>/Saturation1' */

  /* Sum: '<S46>/Add1' incorporates:
   *  Constant: '<S46>/Constant1'
   */
  rtb_Mod1 -= ((uint8)1U);

  /* Saturate: '<S46>/Saturation' */
  if (rtb_Mod1 >= ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  }

  /* End of Saturate: '<S46>/Saturation' */

  /* Math: '<S46>/Mod' incorporates:
   *  Constant: '<S46>/Constant2'
   */
  if (((sint32)((uint8)6U)) == 0) {
    rtb_R0_Q = rtb_Mod1;
  } else {
    rtb_R0_Q = (uint8)(rtb_Mod1 % ((uint8)6U));
  }

  /* End of Math: '<S46>/Mod' */

  /* Product: '<S46>/Divide1' incorporates:
   *  Constant: '<S46>/Constant5'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)(((uint32)rtb_R0_Q) / ((uint32)((uint8)3U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LKA_Mode'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode();

  /* MinMax: '<S46>/Max' */
  if (rtb_IMAPve_d_SAS_Trim_State > rtb_L0_Type) {
    rtb_L0_Type = rtb_IMAPve_d_SAS_Trim_State;
  }

  /* End of MinMax: '<S46>/Max' */

  /* Product: '<S46>/Divide' incorporates:
   *  Constant: '<S46>/Constant6'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  Inport: '<Root>/IMAPve_d_LKA_Main_Switch'
   *  Logic: '<S46>/Logical Operator'
   *  Sum: '<S46>/Add'
   */
  LKAS_DW.LKA_Mode = (uint8)((sint32)(((((sint32)rtb_L0_Q) != 0) || (((sint32)
    ((uint8)
     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch
     ())) != 0)) ? ((sint32)((uint8)(((uint32)rtb_L0_Type) + ((uint32)((uint8)1U)))))
    : 0));

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Q'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q();

  /* Switch: '<S57>/Switch' incorporates:
   *  Constant: '<S57>/Constant'
   */
  if (rtb_IMAPve_d_SAS_Trim_State >= ((uint8)2U)) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = rtb_IMAPve_d_SAS_Trim_State;
  }

  /* End of Switch: '<S57>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Q'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q();

  /* Switch: '<S54>/Switch1' incorporates:
   *  Constant: '<S54>/Constant1'
   */
  if (rtb_IMAPve_d_SAS_Trim_State >= ((uint8)2U)) {
    rtb_R0_Q = ((uint8)3U);
  } else {
    rtb_R0_Q = rtb_IMAPve_d_SAS_Trim_State;
  }

  /* End of Switch: '<S54>/Switch1' */

  /* Chart: '<S53>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c8_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c8_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S58>:4' */
    LKAS_DW.is_c8_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S58>:3' */
    /* '<S58>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S58>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S58>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c8_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S58>:9' */
      /* '<S58>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S58>:13' */
        LKAS_DW.is_c8_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S58>:3' */
        /* '<S58>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S58>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S58>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S58>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S58>:14' */
          LKAS_DW.is_c8_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S58>:7' */
          /* '<S58>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S58>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S58>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S58>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
            /* Transition: '<S58>:23' */
            LKAS_DW.is_c8_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S58>:5' */
            /* '<S58>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S58>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S58>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S58>:5' */
      /* '<S58>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S58>:16' */
        LKAS_DW.is_c8_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S58>:3' */
        /* '<S58>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S58>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S58>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S58>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S58>:18' */
          LKAS_DW.is_c8_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S58>:7' */
          /* '<S58>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S58>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S58>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S58>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_R0_Q) < 3) {
            /* Transition: '<S58>:11' */
            LKAS_DW.is_c8_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S58>:3' */
      /* '<S58>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S58>:6' */
        LKAS_DW.is_c8_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S58>:5' */
        /* '<S58>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S58>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S58>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S58>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S58>:8' */
          LKAS_DW.is_c8_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S58>:7' */
          /* '<S58>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S58>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S58>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S58>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) < 3)) {
            /* Transition: '<S58>:10' */
            /* '<S58>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c8_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S58>:7' */
      /* '<S58>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S58>:17' */
        LKAS_DW.is_c8_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S58>:3' */
        /* '<S58>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S58>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S58>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S58>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
          /* Transition: '<S58>:19' */
          LKAS_DW.is_c8_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S58>:5' */
          /* '<S58>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S58>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S58>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S58>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_L0_Q) < 3) {
            /* Transition: '<S58>:12' */
            LKAS_DW.is_c8_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S53>/LaneReconstructSM' */

  /* DataTypeConversion: '<S52>/Cast To Single64' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   *  UnaryMinus: '<S52>/Unary Minus'
   */
  rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single65' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  UnaryMinus: '<S52>/Unary Minus2'
   */
  rtb_L0_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2
    ()));

  /* UnaryMinus: '<S52>/Unary Minus6' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   */
  rtb_Abs_c = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single56' */
  rtb_R0_C2 = rtb_Abs_c;

  /* Sum: '<S63>/Add2' incorporates:
   *  DataTypeConversion: '<S52>/Cast To Single56'
   */
  rtb_Abs_c += rtb_L0_C2;

  /* Abs: '<S63>/Abs' */
  rtb_Abs_c = fabsf(rtb_Abs_c);

  /* Saturate: '<S63>/Saturation' */
  if (rtb_Abs_c > 0.004F) {
    rtb_Saturation = 0.004F;
  } else if (rtb_Abs_c < 0.0F) {
    rtb_Saturation = 0.0F;
  } else {
    rtb_Saturation = rtb_Abs_c;
  }

  /* End of Saturate: '<S63>/Saturation' */

  /* UnaryMinus: '<S52>/Unary Minus4' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   */
  rtb_Abs_c = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single55' */
  rtb_R0_C0 = rtb_Abs_c;

  /* Switch: '<S68>/Switch' incorporates:
   *  Constant: '<S73>/Constant'
   *  Constant: '<S74>/Constant'
   *  DataTypeConversion: '<S52>/Cast To Single55'
   *  Delay: '<S68>/Delay'
   *  Gain: '<S68>/Gain'
   *  Logic: '<S68>/Logical Operator'
   *  RelationalOperator: '<S73>/Compare'
   *  RelationalOperator: '<S74>/Compare'
   *  Sum: '<S68>/Add'
   */
  if ((rtb_L0_Q >= ((uint8)2U)) && (rtb_R0_Q >= ((uint8)2U))) {
    rtb_Abs_c += (-1.0F) * rtb_L0_C0;
  } else {
    rtb_Abs_c = LKAS_DW.Delay_DSTATE;
  }

  /* End of Switch: '<S68>/Switch' */

  /* Sum: '<S72>/Add1' incorporates:
   *  Memory: '<S72>/Memory'
   *  Product: '<S72>/Divide'
   *  Product: '<S72>/Divide1'
   */
  rtb_Add1 = (rtb_Abs_c * LKAS_ConstB.Divide2) + (LKAS_ConstB.Add2 *
    LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S68>/Saturation1' */
  if (rtb_Add1 > 5.5F) {
    rtb_Saturation1_p1 = 5.5F;
  } else if (rtb_Add1 < 2.5F) {
    rtb_Saturation1_p1 = 2.5F;
  } else {
    rtb_Saturation1_p1 = rtb_Add1;
  }

  /* End of Saturate: '<S68>/Saturation1' */

  /* MATLAB Function: '<S63>/get_roadside_offset' */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S69>:1' */
  /* '<S69>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S69>:1:3' cur=min(single(0.004),cur); */
  /* '<S69>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S69>:1:5' offset=min(single(0.5),offset); */
  rtb_offset = fminf(0.5F, (((fminf(0.004F, rtb_Saturation) / 0.004F) + 1.0F) *
    0.2F) * (fminf(4.0F, rtb_Saturation1_p1) - 2.0F));

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type();

  /* DataTypeConversion: '<S52>/Cast To Single77' */
  rtb_L0_Type = rtb_IMAPve_d_SAS_Trim_State;

  /* Switch: '<S63>/Switch' incorporates:
   *  Constant: '<S66>/Constant'
   *  DataTypeConversion: '<S52>/Cast To Single77'
   *  RelationalOperator: '<S66>/Compare'
   *  Sum: '<S63>/Add'
   */
  if (rtb_IMAPve_d_SAS_Trim_State == ((uint8)10U)) {
    rtb_L0_C0 += rtb_offset;
  }

  /* End of Switch: '<S63>/Switch' */

  /* Switch: '<S64>/Switch' incorporates:
   *  Abs: '<S64>/Abs'
   *  Constant: '<S70>/Constant'
   *  Memory: '<S64>/Memory'
   *  Memory: '<S64>/Memory1'
   *  Product: '<S64>/Divide'
   *  Product: '<S64>/Divide1'
   *  RelationalOperator: '<S70>/Compare'
   *  Sum: '<S64>/Add1'
   *  Sum: '<S64>/Add3'
   */
  if (fabsf(rtb_L0_C0 - LKAS_DW.Memory1_PreviousInput) > 0.5F) {
    rtb_Saturation = rtb_L0_C0;
  } else {
    rtb_Saturation = (rtb_L0_C0 * LKAS_ConstB.Divide2_a) + (LKAS_ConstB.Add2_o *
      LKAS_DW.Memory_PreviousInput_o);
  }

  /* End of Switch: '<S64>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type();

  /* DataTypeConversion: '<S52>/Cast To Single48' */
  rtb_R0_Type = rtb_IMAPve_d_SAS_Trim_State;

  /* Switch: '<S63>/Switch1' incorporates:
   *  Constant: '<S67>/Constant'
   *  DataTypeConversion: '<S52>/Cast To Single48'
   *  RelationalOperator: '<S67>/Compare'
   *  Sum: '<S63>/Add1'
   */
  if (rtb_IMAPve_d_SAS_Trim_State == ((uint8)10U)) {
    rtb_R0_C0 -= rtb_offset;
  }

  /* End of Switch: '<S63>/Switch1' */

  /* Switch: '<S65>/Switch' incorporates:
   *  Abs: '<S65>/Abs'
   *  Constant: '<S71>/Constant'
   *  Memory: '<S65>/Memory'
   *  Memory: '<S65>/Memory1'
   *  Product: '<S65>/Divide'
   *  Product: '<S65>/Divide1'
   *  RelationalOperator: '<S71>/Compare'
   *  Sum: '<S65>/Add1'
   *  Sum: '<S65>/Add3'
   */
  if (fabsf(rtb_R0_C0 - LKAS_DW.Memory1_PreviousInput_b) > 0.5F) {
    rtb_offset = rtb_R0_C0;
  } else {
    rtb_offset = (rtb_R0_C0 * LKAS_ConstB.Divide2_p) + (LKAS_ConstB.Add2_p *
      LKAS_DW.Memory_PreviousInput_op);
  }

  /* End of Switch: '<S65>/Switch' */

  /* DataTypeConversion: '<S52>/Cast To Single61' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
   *  Inport: '<Root>/IMAPve_g_L0_C1'
   *  UnaryMinus: '<S52>/Unary Minus1'
   */
  rtb_L0_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1
    ()));

  /* UnaryMinus: '<S52>/Unary Minus5' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
   *  Inport: '<Root>/IMAPve_g_R0_C1'
   */
  rtb_Abs_c = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single54' */
  rtb_R0_C1 = rtb_Abs_c;

  /* Switch: '<S53>/Switch1' incorporates:
   *  DataTypeConversion: '<S52>/Cast To Single54'
   *  DataTypeConversion: '<S60>/Cast To Single2'
   *  Gain: '<S60>/Gain'
   *  Sum: '<S60>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_a = rtb_Saturation;
    rtb_L0_C1_p = rtb_L0_C1;
    rtb_L0_C2_j = rtb_L0_C2;
  } else {
    rtb_L0_C0_a = (rtb_Saturation1_p1 - rtb_offset) * (-1.0F);
    rtb_L0_C1_p = rtb_Abs_c;
    rtb_L0_C2_j = rtb_R0_C2;
  }

  /* DataTypeConversion: '<S52>/Cast To Single67' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  UnaryMinus: '<S52>/Unary Minus3'
   */
  rtb_L0_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3
    ()));

  /* UnaryMinus: '<S52>/Unary Minus7' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   */
  rtb_Abs_c = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3
    ()));

  /* Switch: '<S53>/Switch1' incorporates:
   *  DataTypeConversion: '<S52>/Cast To Single60'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C3_k = rtb_L0_C3;
  } else {
    rtb_L0_C3_k = rtb_Abs_c;
  }

  /* Switch: '<S53>/Switch' incorporates:
   *  DataTypeConversion: '<S52>/Cast To Single60'
   *  Sum: '<S62>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_C0_e = rtb_offset;
    rtb_L0_C1 = rtb_R0_C1;
    rtb_L0_C2 = rtb_R0_C2;
    rtb_L0_C3 = rtb_Abs_c;
  } else {
    rtb_R0_C0_e = rtb_Saturation1_p1 + rtb_Saturation;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Camera_Status'
   */
  rtb_IMAPve_d_Camera_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_LKA_State'
   */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  rtb_IMAPve_g_EPS_SW_Trq = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  rtb_IMAPve_g_ESC_VehSpd = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  rtb_IMAPve_g_ESC_LonAcc = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  rtb_IMAPve_g_SW_Angle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp
    ();

  /* Logic: '<S43>/Logical Operator' incorporates:
   *  Constant: '<S50>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Left_Light'
   *  RelationalOperator: '<S50>/Compare'
   */
  rtb_BCM_Left_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch
                    ()) == ((uint8)1U)));

  /* Logic: '<S43>/Logical Operator1' incorporates:
   *  Constant: '<S51>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Right_Light'
   *  RelationalOperator: '<S51>/Compare'
   */
  rtb_BCM_Right_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
                    ()) == ((uint8)1U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_Actual_Gear'
   */
  rtb_IMAPve_d_TCU_Actual_Gear = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear
    ();

  /* MultiPortSwitch: '<S47>/Multiport Switch' incorporates:
   *  Constant: '<S47>/Constant1'
   *  Constant: '<S47>/Constant3'
   */
  switch (rtb_IMAPve_d_TCU_Actual_Gear) {
   case 0:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 1:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 2:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 3:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 4:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 5:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 6:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 7:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 8:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 9:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   default:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;
  }

  /* End of MultiPortSwitch: '<S47>/Multiport Switch' */

  /* Switch: '<S552>/Switch58' incorporates:
   *  Constant: '<S552>/LLSMConClb4'
   *
   * Block description for '<S552>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S552>/Switch58' */

  /* Gain: '<S557>/Gain' incorporates:
   *  Constant: '<S557>/Constant'
   *  Sum: '<S557>/Add'
   */
  rtb_Gain_g = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S552>/Switch84' incorporates:
   *  Constant: '<S552>/LLSMConClb5'
   *
   * Block description for '<S552>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S552>/Switch84' */

  /* Switch: '<S552>/Switch85' incorporates:
   *  Constant: '<S552>/LLSMConClb6'
   *
   * Block description for '<S552>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S552>/Switch85' */

  /* Switch: '<S552>/Switch86' incorporates:
   *  Constant: '<S552>/LLSMConClb7'
   *
   * Block description for '<S552>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S552>/Switch86' */

  /* Switch: '<S552>/Switch54' incorporates:
   *  Constant: '<S552>/LLSMConClb12'
   *
   * Block description for '<S552>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S552>/Switch54' */

  /* Switch: '<S552>/Switch55' incorporates:
   *  Constant: '<S552>/LLSMConClb13'
   *
   * Block description for '<S552>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S552>/Switch55' */

  /* Switch: '<S552>/Switch60' incorporates:
   *  Constant: '<S552>/LLSMConClb17'
   *
   * Block description for '<S552>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S552>/Switch60' */

  /* Switch: '<S552>/Switch57' incorporates:
   *  Constant: '<S552>/LLSMConClb18'
   *
   * Block description for '<S552>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S552>/Switch57' */

  /* Switch: '<S552>/Switch59' incorporates:
   *  Constant: '<S552>/LLSMConClb19'
   *
   * Block description for '<S552>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_R0_C2 = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_R0_C2 = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S552>/Switch59' */

  /* Switch: '<S552>/Switch69' incorporates:
   *  Constant: '<S552>/LLSMConClb22'
   *
   * Block description for '<S552>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S552>/Switch69' */

  /* Gain: '<S554>/Gain' incorporates:
   *  Constant: '<S554>/Constant'
   *  Sum: '<S554>/Add'
   */
  rtb_Gain_c = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S552>/Switch68' incorporates:
   *  Constant: '<S552>/LLSMConClb23'
   *
   * Block description for '<S552>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S552>/Switch68' */

  /* Switch: '<S552>/Switch70' incorporates:
   *  Constant: '<S552>/LLSMConClb24'
   *
   * Block description for '<S552>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S552>/Switch70' */

  /* Switch: '<S552>/Switch71' incorporates:
   *  Constant: '<S552>/LLSMConClb25'
   *
   * Block description for '<S552>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S552>/Switch71' */

  /* Switch: '<S552>/Switch73' incorporates:
   *  Constant: '<S552>/LLSMConClb27'
   *
   * Block description for '<S552>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S552>/Switch73' */

  /* Switch: '<S552>/Switch62' incorporates:
   *  Constant: '<S552>/LLSMConClb31'
   *
   * Block description for '<S552>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S552>/Switch62' */

  /* Switch: '<S552>/Switch66' incorporates:
   *  Constant: '<S552>/LLSMConClb35'
   *
   * Block description for '<S552>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S552>/Switch66' */

  /* Switch: '<S552>/Switch81' incorporates:
   *  Constant: '<S552>/LLSMConClb36'
   *
   * Block description for '<S552>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S552>/Switch81' */

  /* Switch: '<S552>/Switch82' incorporates:
   *  Constant: '<S552>/LLSMConClb37'
   *
   * Block description for '<S552>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S552>/Switch82' */

  /* Switch: '<S552>/Switch83' incorporates:
   *  Constant: '<S552>/LLSMConClb38'
   *
   * Block description for '<S552>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S552>/Switch83' */

  /* Switch: '<S552>/Switch75' incorporates:
   *  Constant: '<S552>/LLSMConClb39'
   *
   * Block description for '<S552>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S552>/Switch75' */

  /* Switch: '<S552>/Switch76' incorporates:
   *  Constant: '<S552>/LLSMConClb40'
   *
   * Block description for '<S552>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S552>/Switch76' */

  /* Switch: '<S552>/Switch77' incorporates:
   *  Constant: '<S552>/LLSMConClb41'
   *
   * Block description for '<S552>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S552>/Switch77' */

  /* Switch: '<S552>/Switch78' incorporates:
   *  Constant: '<S552>/LLSMConClb42'
   *
   * Block description for '<S552>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S552>/Switch78' */

  /* Switch: '<S551>/Switch3' incorporates:
   *  Constant: '<S551>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S551>/Switch3' */

  /* Switch: '<S551>/Switch10' incorporates:
   *  Constant: '<S551>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    LKAS_DW.LL_DesDvt_C_p = LKAS_ConstB.DataTypeConversion22;
  } else {
    LKAS_DW.LL_DesDvt_C_p = LL_DesDvt_C;
  }

  /* End of Switch: '<S551>/Switch10' */

  /* Switch: '<S551>/Switch15' incorporates:
   *  Constant: '<S551>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    LKAS_DW.LL_lStpLngth_C_n = LKAS_ConstB.DataTypeConversion21;
  } else {
    LKAS_DW.LL_lStpLngth_C_n = LL_lStpLngth_C;
  }

  /* End of Switch: '<S551>/Switch15' */

  /* Switch: '<S551>/Switch31' incorporates:
   *  Constant: '<S551>/LL_LFClb_TFC_KpVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_g != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LKAS_ConstB.DataTypeConversion14_g;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S551>/Switch31' */

  /* Switch: '<S551>/Switch34' incorporates:
   *  Constant: '<S551>/LL_LFClb_TFC_KpVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LKAS_ConstB.DataTypeConversion4;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S551>/Switch34' */

  /* Switch: '<S551>/Switch33' incorporates:
   *  Constant: '<S551>/LL_LFClb_TFC_KpV1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_p != 0.0F) {
    rtb_LL_LFClb_TFC_KpV1_C = LKAS_ConstB.DataTypeConversion7_p;
  } else {
    rtb_LL_LFClb_TFC_KpV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S551>/Switch33' */

  /* Switch: '<S551>/Switch35' incorporates:
   *  Constant: '<S551>/LL_LFClb_TFC_KpV2_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion17_o != 0.0F) {
    rtb_LL_LFClb_TFC_KpV2_C = LKAS_ConstB.DataTypeConversion17_o;
  } else {
    rtb_LL_LFClb_TFC_KpV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S551>/Switch35' */

  /* Switch: '<S551>/Switch20' incorporates:
   *  Constant: '<S551>/LL_LFClb_TFC_KdVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LL_LFClb_TFC_KdVehSpdLwr_C;
  }

  /* End of Switch: '<S551>/Switch20' */

  /* Switch: '<S551>/Switch22' incorporates:
   *  Constant: '<S551>/LL_LFClb_TFC_KdVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LL_LFClb_TFC_KdVehSpdUpr_C;
  }

  /* End of Switch: '<S551>/Switch22' */

  /* Switch: '<S551>/Switch21' incorporates:
   *  Constant: '<S551>/LL_LFClb_TFC_KdV1_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV1_C = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LFClb_TFC_KdV1_C = LL_LFClb_TFC_KdV1_C;
  }

  /* End of Switch: '<S551>/Switch21' */

  /* Switch: '<S551>/Switch23' incorporates:
   *  Constant: '<S551>/LL_LFClb_TFC_KdV2_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV2_C = LKAS_ConstB.DataTypeConversion30;
  } else {
    rtb_LL_LFClb_TFC_KdV2_C = LL_LFClb_TFC_KdV2_C;
  }

  /* End of Switch: '<S551>/Switch23' */

  /* Switch: '<S551>/Switch9' incorporates:
   *  Constant: '<S551>/LL_LFClb_TFC_KdBalance_C=1.2'
   */
  if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
    rtb_Abs_c = LKAS_ConstB.DataTypeConversion9;
  } else {
    rtb_Abs_c = LL_LFClb_TFC_KdBalance_C;
  }

  /* End of Switch: '<S551>/Switch9' */

  /* Switch: '<S551>/Switch47' incorporates:
   *  Constant: '<S551>/LL_LKASWASyn_TrqSwaAddSwt=1'
   */
  if (LKAS_ConstB.DataTypeConversion47_l) {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LKAS_ConstB.DataTypeConversion47_l ? 1.0F :
      0.0F;
  } else {
    rtb_LL_LKASWASyn_TrqSwaAddSwt = LL_LKASWASyn_TrqSwaAddSwt ? 1.0F : 0.0F;
  }

  /* End of Switch: '<S551>/Switch47' */

  /* Switch: '<S551>/Switch11' incorporates:
   *  Constant: '<S551>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_l != 0.0F) {
    rtb_R0_C1 = LKAS_ConstB.DataTypeConversion12_l;
  } else {
    rtb_R0_C1 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S551>/Switch11' */

  /* Switch: '<S551>/Switch13' incorporates:
   *  Constant: '<S551>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_l != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_l;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S551>/Switch13' */

  /* Switch: '<S551>/Switch16' incorporates:
   *  Constant: '<S551>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S551>/Switch16' */

  /* Switch: '<S551>/Switch55' incorporates:
   *  Constant: '<S551>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S551>/Switch55' */

  /* Switch: '<S551>/Switch54' incorporates:
   *  Constant: '<S551>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S551>/Switch54' */

  /* Switch: '<S551>/Switch44' incorporates:
   *  Constant: '<S551>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S551>/Switch44' */

  /* Switch: '<S549>/Switch19' incorporates:
   *  Constant: '<S549>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_e != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_e;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S549>/Switch19' */

  /* Switch: '<S549>/Switch' incorporates:
   *  Constant: '<S549>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_d != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_d;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S549>/Switch' */

  /* Switch: '<S549>/Switch1' incorporates:
   *  Constant: '<S549>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_b != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_b;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S549>/Switch1' */

  /* Switch: '<S549>/Switch2' incorporates:
   *  Constant: '<S549>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_i != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_b = LKAS_ConstB.DataTypeConversion4_i;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_b = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S549>/Switch2' */

  /* Switch: '<S549>/Switch3' incorporates:
   *  Constant: '<S549>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_a != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_m = LKAS_ConstB.DataTypeConversion6_a;
  } else {
    LKAS_DW.LKA_StrRatio_C_m = LKA_StrRatio_C;
  }

  /* End of Switch: '<S549>/Switch3' */

  /* Switch: '<S549>/Switch11' incorporates:
   *  Constant: '<S549>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22_m != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22_m;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S549>/Switch11' */

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (((sint32)LKAS_DW.LKA_Mode) > 0) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S77>/Delay' */
      LKAS_DW.Delay_DSTATE_l = ((uint8)0U);

      /* InitializeConditions for Memory: '<S516>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = 0.0F;

      /* InitializeConditions for Memory: '<S459>/Memory' */
      LKAS_DW.Memory_PreviousInput_e = 0.0F;

      /* InitializeConditions for UnitDelay: '<S389>/Delay Input1'
       *
       * Block description for '<S389>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S387>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_e = false;

      /* InitializeConditions for UnitDelay: '<S388>/Delay Input1'
       *
       * Block description for '<S388>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_a = false;

      /* InitializeConditions for Delay: '<S78>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for UnitDelay: '<S350>/Delay Input1'
       *
       * Block description for '<S350>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_d = false;

      /* InitializeConditions for UnitDelay: '<S348>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_pg = false;

      /* InitializeConditions for UnitDelay: '<S349>/Delay Input1'
       *
       * Block description for '<S349>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_p = false;

      /* InitializeConditions for Memory: '<S315>/Memory' */
      LKAS_DW.Memory_PreviousInput_c0 = false;

      /* InitializeConditions for Delay: '<S78>/Delay' */
      LKAS_DW.Delay_DSTATE_e = false;

      /* InitializeConditions for Delay: '<S78>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S363>/Memory' */
      LKAS_DW.Memory_PreviousInput_hq = ((uint8)0U);

      /* InitializeConditions for Memory: '<S289>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = 0.0F;

      /* InitializeConditions for Memory: '<S325>/Memory' */
      LKAS_DW.Memory_PreviousInput_d = 0.0F;

      /* InitializeConditions for Delay: '<S78>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S78>/LDW_State_Machine'
       *
       * Block description for '<S78>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S78>/LKA_State_Machine'
       *
       * Block description for '<S78>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S230>/Add1' incorporates:
     *  MATLAB Function: '<S228>/MATLAB Function3'
     */
    x20 = rtb_L0_C0_a + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S230>/Gain1' incorporates:
     *  Product: '<S230>/Divide'
     *  Product: '<S230>/Divide1'
     *  Sum: '<S230>/Add1'
     *  Sum: '<S230>/Add5'
     *  Trigonometry: '<S230>/Cos2'
     *  Trigonometry: '<S230>/Sin'
     */
    rtb_Gain1 = ((x20 * cosf(rtb_L0_C1_p)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_p))) * (-1.0F);

    /* Sum: '<S231>/Add1' incorporates:
     *  MATLAB Function: '<S228>/MATLAB Function4'
     */
    rtb_Add5_n_tmp = rtb_R0_C0_e - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S231>/Add5' incorporates:
     *  Product: '<S231>/Divide'
     *  Product: '<S231>/Divide1'
     *  Sum: '<S231>/Add1'
     *  Trigonometry: '<S231>/Cos2'
     *  Trigonometry: '<S231>/Sin'
     */
    rtb_Add5_n = (rtb_Add5_n_tmp * cosf(rtb_L0_C1)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1));

    /* Switch: '<S551>/Switch2' incorporates:
     *  Constant: '<S551>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_f != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_f;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S551>/Switch2' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S235>/kph to mps' incorporates:
     *  Gain: '<S114>/Gain'
     *  Gain: '<S164>/kph To mps'
     *  Gain: '<S178>/kph to mps'
     *  Gain: '<S179>/kph to mps'
     *  Gain: '<S228>/Gain2'
     *  Gain: '<S241>/kph to mps'
     *  Gain: '<S248>/kph to mps'
     *  Gain: '<S249>/kph to mps'
     *  Gain: '<S276>/Gain'
     *  Gain: '<S314>/Gain'
     */
    rtb_LKA_Veh2CamL_C_tmp = 0.277777791F * rtb_IMAPve_g_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S235>/Divide' incorporates:
     *  Gain: '<S235>/kph to mps'
     */
    rtb_LKA_Veh2CamL_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Gain: '<S232>/Gain' incorporates:
     *  Gain: '<S246>/Gain'
     *  Gain: '<S247>/Gain'
     */
    rtb_Add_fk_tmp = 2.0F * rtb_L0_C2_j;

    /* Sum: '<S232>/Add' incorporates:
     *  Gain: '<S232>/Gain'
     *  Gain: '<S232>/Gain1'
     *  Product: '<S232>/Product'
     */
    rtb_Add_fk = ((6.0F * rtb_L0_C3_k) * rtb_LKA_Veh2CamL_C) + rtb_Add_fk_tmp;

    /* Gain: '<S233>/Gain' incorporates:
     *  Gain: '<S244>/Gain'
     *  Gain: '<S245>/Gain'
     */
    rtb_Add_nk_tmp = 2.0F * rtb_L0_C2;

    /* Sum: '<S233>/Add' incorporates:
     *  Gain: '<S233>/Gain'
     *  Gain: '<S233>/Gain1'
     *  Product: '<S233>/Product'
     */
    rtb_Add_nk = ((6.0F * rtb_L0_C3) * rtb_LKA_Veh2CamL_C) + rtb_Add_nk_tmp;

    /* UnaryMinus: '<S228>/Unary Minus' incorporates:
     *  Product: '<S228>/Product'
     */
    rtb_LKA_Veh2CamL_C = -(rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1_p);

    /* Saturate: '<S228>/Saturation9' */
    if (rtb_LKA_Veh2CamL_C > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else {
      if (rtb_LKA_Veh2CamL_C < (-2.0F)) {
        rtb_LKA_Veh2CamL_C = (-2.0F);
      }
    }

    /* End of Saturate: '<S228>/Saturation9' */

    /* MATLAB Function: '<S228>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function': '<S257>:1' */
    /* '<S257>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1 > 0.0F) && (rtb_Gain1 < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S257>:1:3' TTLC = -dvt/vy; */
      rtb_TTLC_m = (-rtb_Gain1) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S257>:1:4' else */
      /* '<S257>:1:5' TTLC = single(3); */
      rtb_TTLC_m = 3.0F;
    }

    /* End of MATLAB Function: '<S228>/MATLAB Function' */

    /* Saturate: '<S228>/Saturation' */
    if (rtb_TTLC_m > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_TTLC_m < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_TTLC_m;
    }

    /* End of Saturate: '<S228>/Saturation' */

    /* Product: '<S228>/Product3' */
    rtb_TTLC_m = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* Saturate: '<S228>/Saturation10' incorporates:
     *  Product: '<S228>/Product3'
     */
    if (rtb_TTLC_m > 2.0F) {
      rtb_TTLC_m = 2.0F;
    } else {
      if (rtb_TTLC_m < (-2.0F)) {
        rtb_TTLC_m = (-2.0F);
      }
    }

    /* End of Saturate: '<S228>/Saturation10' */

    /* MATLAB Function: '<S228>/MATLAB Function1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function1': '<S258>:1' */
    /* '<S258>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_n > 0.0F) && (rtb_Add5_n < 2.0F)) && (rtb_TTLC_m < 0.0F)) &&
        (rtb_TTLC_m > -1.5F)) {
      /* '<S258>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_l = (-rtb_Add5_n) / rtb_TTLC_m;
    } else {
      /* '<S258>:1:4' else */
      /* '<S258>:1:5' TTLC = single(3); */
      rtb_TTLC_l = 3.0F;
    }

    /* End of MATLAB Function: '<S228>/MATLAB Function1' */

    /* Saturate: '<S228>/Saturation1' */
    if (rtb_TTLC_l > 2.0F) {
      rtb_TTLC_l = 2.0F;
    } else {
      if (rtb_TTLC_l < 0.6F) {
        rtb_TTLC_l = 0.6F;
      }
    }

    /* End of Saturate: '<S228>/Saturation1' */

    /* MATLAB Function: '<S228>/MATLAB Function5' incorporates:
     *  Gain: '<S256>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function5': '<S262>:1' */
    /* '<S262>:1:2' K = 0.09/vx; */
    /* '<S262>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_IMAPve_g_SW_Angle) / (((((((0.09F /
      rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp) * rtb_LKA_Veh2CamL_C_tmp)
      + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_b) * LKAS_DW.LKA_StrRatio_C_m) * 2.0F);

    /* MATLAB Function: '<S228>/MATLAB Function3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function3': '<S260>:1' */
    /* '<S260>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2_j - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_p > 0.0F) || (rtb_L0_C1_p < 0.0F))) {
      /* '<S260>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_a) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_p;
      if (x10 > 0.0F) {
        /* '<S260>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        /* '<S260>:1:9' else */
        /* '<S260>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_p * rtb_L0_C1_p) - ((x10 * 4.0F) * x20);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S260>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S260>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_p)) / x1;

        /* '<S260>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_p) - x20) / x1;

        /* '<S260>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S260>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S260>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S260>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          /* '<S260>:1:19' elseif x1>0 */
          /* '<S260>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          /* '<S260>:1:21' else */
          /* '<S260>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S260>:1:24' else */
        /* '<S260>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S260>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S228>/MATLAB Function4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function4': '<S261>:1' */
    /* '<S261>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2 - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1 > 0.0F) || (rtb_L0_C1 < 0.0F))) {
      /* '<S261>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_R0_C0_e) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1;
      if (x10 > 0.0F) {
        /* '<S261>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
      } else {
        /* '<S261>:1:9' else */
        /* '<S261>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1 * rtb_L0_C1) - ((x10 * 4.0F) * rtb_Add5_n_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S261>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S261>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1)) / x1;

        /* '<S261>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1) - x20) / x1;

        /* '<S261>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S261>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S261>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S261>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_LKA_Veh2CamL_C_tmp;
        } else if (x1 > 0.0F) {
          /* '<S261>:1:19' elseif x1>0 */
          /* '<S261>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_LKA_Veh2CamL_C_tmp;
        } else {
          /* '<S261>:1:21' else */
          /* '<S261>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S261>:1:24' else */
        /* '<S261>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S261>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S228>/MATLAB Function2' incorporates:
     *  Constant: '<S228>/Constant'
     *  Constant: '<S228>/Constant1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLAB Function2': '<S259>:1' */
    /* '<S259>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - 2.0F) / rtb_LftTTLC) <= 0.2F) {
      /* '<S259>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, 2.0F);
    } else {
      /* '<S259>:1:4' else */
      /* '<S259>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S259>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_l - 2.0F) / rtb_TTLC_l) <= 0.2F) {
      /* '<S259>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_l = fminf(rtb_TTLC_l, 2.0F);
    } else {
      /* '<S259>:1:10' else */
      /* '<S259>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S259>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_fk) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S259>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S259>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_nk) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_l)
           / rtb_TTLC_l) <= 0.7F)) && (rtb_TTLC_l <= 1.95F)) {
      /* '<S259>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_l = (rtb_TTLC_l + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S228>/Saturation7' incorporates:
     *  MATLAB Function: '<S228>/MATLAB Function2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S228>/Saturation7' */

    /* Saturate: '<S228>/Saturation8' incorporates:
     *  MATLAB Function: '<S228>/MATLAB Function2'
     */
    if (rtb_TTLC_l > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_l < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_l;
    }

    /* End of Saturate: '<S228>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S85>/Subsystem' incorporates:
     *  EnablePort: '<S93>/Enable'
     */
    /* Abs: '<S223>/Abs' incorporates:
     *  MATLAB Function: '<S93>/DriverSwaTrqAdd'
     */
    rtb_Add5_n_tmp = fabsf(rtb_L0_C0_a);

    /* Abs: '<S223>/Abs1' incorporates:
     *  MATLAB Function: '<S93>/DriverSwaTrqAdd'
     */
    rtb_TTLC_l = fabsf(rtb_R0_C0_e);

    /* End of Outputs for SubSystem: '<S85>/Subsystem' */
    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Sum: '<S223>/Add' incorporates:
     *  Abs: '<S223>/Abs'
     *  Abs: '<S223>/Abs1'
     */
    rtb_TLft = rtb_Add5_n_tmp + rtb_TTLC_l;

    /* Saturate: '<S223>/Saturation' */
    if (rtb_TLft > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_TLft < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_TLft;
    }

    /* End of Saturate: '<S223>/Saturation' */

    /* If: '<S234>/If' incorporates:
     *  Delay: '<S77>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE_l) == 1) {
      /* Outputs for IfAction SubSystem: '<S234>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S237>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_fk, &rtb_Merge_a);

      /* End of Outputs for SubSystem: '<S234>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE_l) == 2) {
      /* Outputs for IfAction SubSystem: '<S234>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S236>/Action Port'
       */
      LKAS_ifaction3(rtb_Add_nk, &rtb_Merge_a);

      /* End of Outputs for SubSystem: '<S234>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S234>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S238>/Action Port'
       */
      /* Gain: '<S238>/Gain' incorporates:
       *  Sum: '<S238>/Add'
       */
      rtb_Merge_a = (rtb_Add_fk + rtb_Add_nk) * 0.5F;

      /* End of Outputs for SubSystem: '<S234>/If Action Subsystem3' */
    }

    /* End of If: '<S234>/If' */

    /* Switch: '<S518>/Switch' incorporates:
     *  Constant: '<S555>/Constant'
     *  Constant: '<S556>/Constant'
     *  Gain: '<S555>/Gain'
     *  Gain: '<S556>/Gain'
     *  Sum: '<S555>/Add'
     *  Sum: '<S556>/Add'
     *  Switch: '<S552>/Switch47'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S552>/Switch48' incorporates:
       *  Constant: '<S552>/LLSMConClb3'
       *
       * Block description for '<S552>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S552>/Switch48' */
      rtb_Switch_gp = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S552>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S552>/Switch47' incorporates:
         *  Constant: '<S552>/LLSMConClb2'
         *
         * Block description for '<S552>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_gp = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S518>/Switch' */

    /* Switch: '<S516>/Switch' incorporates:
     *  Constant: '<S516>/Constant'
     *  Constant: '<S516>/Constant1'
     *  Constant: '<S521>/Constant'
     *  Constant: '<S522>/Constant'
     *  Constant: '<S523>/Constant'
     *  Logic: '<S516>/Logical Operator'
     *  RelationalOperator: '<S521>/Compare'
     *  RelationalOperator: '<S522>/Compare'
     *  RelationalOperator: '<S523>/Compare'
     */
    if (((rtb_IMAPve_d_SAS_Trim_State > ((uint8)0U)) || (((sint32)
           (rtb_BCM_Left_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) ||
        (((sint32)(rtb_BCM_Right_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) {
      rtb_TLft = 3.0F;
    } else {
      rtb_TLft = (-1.0F);
    }

    /* End of Switch: '<S516>/Switch' */

    /* Sum: '<S516>/Add' incorporates:
     *  Memory: '<S516>/Memory'
     */
    rtb_TLft += LKAS_DW.Memory_PreviousInput_a;

    /* Saturate: '<S516>/Saturation' */
    if (rtb_TLft > 200.0F) {
      rtb_Saturation_d = 200.0F;
    } else if (rtb_TLft < (-1.0F)) {
      rtb_Saturation_d = (-1.0F);
    } else {
      rtb_Saturation_d = rtb_TLft;
    }

    /* End of Saturate: '<S516>/Saturation' */

    /* Abs: '<S510>/Abs1' incorporates:
     *  Abs: '<S415>/Abs1'
     */
    rtb_LftTTLC = fabsf(rtb_LaneWidth);
    rtb_Abs1 = rtb_LftTTLC;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S508>/Abs' incorporates:
     *  Abs: '<S104>/Abs'
     *  Abs: '<S105>/Abs'
     *  Abs: '<S106>/Abs4'
     *  Abs: '<S413>/Abs'
     *  MATLAB Function: '<S377>/MATLAB Function'
     */
    rtb_TTLC = fabsf(rtb_Merge_a);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC;

    /* Switch: '<S552>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S469>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S469>/Unary Minus' incorporates:
       *  Constant: '<S552>/LLSMConClb11'
       *
       * Block description for '<S552>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S552>/Switch53' */

    /* Switch: '<S552>/Switch87' incorporates:
     *  Constant: '<S552>/LLSMConClb8'
     *
     * Block description for '<S552>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S552>/Switch87' */

    /* Switch: '<S552>/Switch49' incorporates:
     *  Constant: '<S552>/LLSMConClb43'
     *
     * Block description for '<S552>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S552>/Switch49' */

    /* Switch: '<S552>/Switch88' incorporates:
     *  Constant: '<S552>/LLSMConClb9'
     *
     * Block description for '<S552>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_TLft = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S552>/Switch88' */

    /* Switch: '<S552>/Switch50' incorporates:
     *  Constant: '<S552>/LLSMConClb10'
     *
     * Block description for '<S552>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      rtb_Gain2_0 = LKAS_ConstB.DataTypeConversion17;
    } else {
      rtb_Gain2_0 = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S552>/Switch50' */

    /* Abs: '<S506>/Abs' incorporates:
     *  Abs: '<S411>/Abs'
     *  Sum: '<S506>/Add'
     */
    rtb_IMAPve_g_ESC_LatAcc = fabsf(rtb_L0_C1_p - rtb_L0_C1);

    /* Abs: '<S469>/Abs2' incorporates:
     *  Abs: '<S251>/Abs2'
     *  Abs: '<S375>/Abs2'
     */
    x1 = fabsf(rtb_IMAPve_g_SW_Angle);

    /* Abs: '<S469>/Abs3' incorporates:
     *  Abs: '<S375>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     *  Inport: '<Root>/IMAPve_g_SW_Angle_Speed'
     */
    rtb_LogicalOperator3_ls_tmp = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
      ());

    /* Abs: '<S469>/Abs4' incorporates:
     *  Abs: '<S375>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     *  Inport: '<Root>/IMAPve_g_ESC_LatAcc'
     */
    rtb_LogicalOperator3_ls_tmp_0 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc());

    /* Abs: '<S469>/Abs1' incorporates:
     *  Abs: '<S376>/Abs'
     *  Abs: '<S377>/Abs'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S470>/Logical Operator2' incorporates:
     *  Abs: '<S469>/Abs1'
     *  Abs: '<S469>/Abs2'
     *  Abs: '<S469>/Abs3'
     *  Abs: '<S469>/Abs4'
     *  Abs: '<S506>/Abs'
     *  Constant: '<S508>/Constant'
     *  Constant: '<S511>/Constant'
     *  Constant: '<S513>/Constant'
     *  Constant: '<S514>/Constant'
     *  Constant: '<S520>/Constant'
     *  Constant: '<S524>/Constant'
     *  Logic: '<S469>/Logical Operator3'
     *  Logic: '<S475>/FixPt Logical Operator'
     *  Logic: '<S507>/Logical Operator3'
     *  Logic: '<S509>/Logical Operator'
     *  Logic: '<S512>/FixPt Logical Operator'
     *  Logic: '<S515>/FixPt Logical Operator'
     *  Logic: '<S519>/Logical Operator'
     *  Logic: '<S525>/FixPt Logical Operator'
     *  RelationalOperator: '<S469>/Relational Operator'
     *  RelationalOperator: '<S469>/Relational Operator1'
     *  RelationalOperator: '<S469>/Relational Operator2'
     *  RelationalOperator: '<S469>/Relational Operator3'
     *  RelationalOperator: '<S475>/Lower Test'
     *  RelationalOperator: '<S475>/Upper Test'
     *  RelationalOperator: '<S511>/Compare'
     *  RelationalOperator: '<S512>/Lower Test'
     *  RelationalOperator: '<S512>/Upper Test'
     *  RelationalOperator: '<S513>/Compare'
     *  RelationalOperator: '<S514>/Compare'
     *  RelationalOperator: '<S515>/Lower Test'
     *  RelationalOperator: '<S515>/Upper Test'
     *  RelationalOperator: '<S520>/Compare'
     *  RelationalOperator: '<S524>/Compare'
     *  RelationalOperator: '<S525>/Lower Test'
     *  RelationalOperator: '<S525>/Upper Test'
     *  Switch: '<S53>/Switch'
     *  Switch: '<S53>/Switch1'
     */
    rtb_LogicalOperator3_e = ((((((rtb_Gain_g <= rtb_IMAPve_g_ESC_VehSpd) &&
      (rtb_IMAPve_g_ESC_VehSpd <= rtb_Switch_gp)) && (rtb_Saturation_d <= 0.0F))
      && (rtb_TCU_ActualGear == ((uint8)3U))) && (((((rtb_L0_Q > ((uint8)2U)) &&
      (rtb_R0_Q > ((uint8)2U))) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) &&
      (rtb_Abs1 <= rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) &&
      (rtb_Abs <= rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) && (rtb_IMAPve_g_ESC_LatAcc
      <= 0.025F))) && (((((x1 < x10) && (rtb_LogicalOperator3_ls_tmp < x20)) &&
                         (rtb_LKA_Veh2CamW_C < rtb_TLft)) &&
                        (rtb_LogicalOperator3_ls_tmp_0 < rtb_Gain2_0)) &&
                       ((rtb_UnaryMinus < rtb_IMAPve_g_ESC_LonAcc) &&
                        (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* MATLAB Function: '<S503>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_LKA_EarliestWarnLine_C, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient);

    /* Product: '<S503>/Multiply' */
    rtb_Multiply = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_ThresDet_coefficient;

    /* Switch: '<S505>/Switch' incorporates:
     *  Constant: '<S503>/Constant'
     *  RelationalOperator: '<S505>/UpperRelop'
     */
    if (rtb_Multiply < 0.0F) {
      rtb_Switch_nw = 0.0F;
    } else {
      rtb_Switch_nw = rtb_Multiply;
    }

    /* End of Switch: '<S505>/Switch' */

    /* Switch: '<S505>/Switch2' incorporates:
     *  RelationalOperator: '<S505>/LowerRelop1'
     */
    if (rtb_Multiply > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_o = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_o = rtb_Switch_nw;
    }

    /* End of Switch: '<S505>/Switch2' */

    /* Abs: '<S490>/Abs1' incorporates:
     *  Abs: '<S401>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S490>/Abs2' incorporates:
     *  Abs: '<S401>/Abs1'
     */
    x20 = fabsf(rtb_TTLC_m);

    /* If: '<S470>/If1' incorporates:
     *  Abs: '<S490>/Abs1'
     *  Abs: '<S490>/Abs2'
     *  Constant: '<S477>/Constant'
     *  Constant: '<S492>/Constant'
     *  Constant: '<S493>/Constant'
     *  Constant: '<S498>/Constant'
     *  Constant: '<S499>/Constant'
     *  Constant: '<S500>/Constant'
     *  Constant: '<S501>/Constant'
     *  DataTypeConversion: '<S470>/Cast To Single'
     *  Logic: '<S470>/Logical Operator1'
     *  Logic: '<S487>/Logical Operator'
     *  Logic: '<S489>/Logical Operator'
     *  Logic: '<S490>/Logical Operator'
     *  Logic: '<S491>/Logical Operator'
     *  RelationalOperator: '<S490>/Relational Operator2'
     *  RelationalOperator: '<S490>/Relational Operator3'
     *  RelationalOperator: '<S491>/Relational Operator1'
     *  RelationalOperator: '<S491>/Relational Operator2'
     *  RelationalOperator: '<S492>/Compare'
     *  RelationalOperator: '<S493>/Compare'
     *  RelationalOperator: '<S498>/Compare'
     *  RelationalOperator: '<S499>/Compare'
     *  RelationalOperator: '<S500>/Compare'
     *  RelationalOperator: '<S501>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_LogicalOperator3_e &&
         ((((LKAS_DW.LKA_Mode == ((uint8)2U)) && (((sint32)
              (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
                (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) ? 1 : 0)) ==
             ((sint32)(true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1 >= rtb_Switch2_o) &&
              (rtb_Add5_n >= rtb_Switch2_o)) ? 1 : 0)) == ((sint32)(true ? 1 : 0))))))
    {
      /* Outputs for IfAction SubSystem: '<S470>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S477>/Action Port'
       */
      LKAS_DW.Merge1_a = true;

      /* End of Outputs for SubSystem: '<S470>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S470>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S479>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_a);

      /* End of Outputs for SubSystem: '<S470>/If Action Subsystem4' */
    }

    /* End of If: '<S470>/If1' */

    /* Switch: '<S461>/Switch' incorporates:
     *  Constant: '<S553>/Constant'
     *  Constant: '<S558>/Constant'
     *  Gain: '<S553>/Gain'
     *  Gain: '<S558>/Gain'
     *  Sum: '<S553>/Add'
     *  Sum: '<S558>/Add'
     *  Switch: '<S552>/Switch67'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S552>/Switch80' incorporates:
       *  Constant: '<S552>/LLSMConClb21'
       *
       * Block description for '<S552>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_TLft = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_TLft = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S552>/Switch80' */
      rtb_Switch_h = (rtb_TLft - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S552>/Switch67' */
        rtb_TLft = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S552>/Switch67' incorporates:
         *  Constant: '<S552>/LLSMConClb20'
         *
         * Block description for '<S552>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_TLft = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_h = (rtb_TLft - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S461>/Switch' */

    /* Logic: '<S461>/Logical Operator' incorporates:
     *  Logic: '<S468>/FixPt Logical Operator'
     *  RelationalOperator: '<S468>/Lower Test'
     *  RelationalOperator: '<S468>/Upper Test'
     */
    rtb_LKA_Main_Switch = ((rtb_Gain_c >= rtb_IMAPve_g_ESC_VehSpd) ||
      (rtb_IMAPve_g_ESC_VehSpd >= rtb_Switch_h));

    /* Switch: '<S459>/Switch' incorporates:
     *  Constant: '<S459>/Constant'
     *  Constant: '<S459>/Constant1'
     *  Constant: '<S464>/Constant'
     *  Constant: '<S465>/Constant'
     *  Constant: '<S466>/Constant'
     *  Logic: '<S459>/Logical Operator'
     *  RelationalOperator: '<S464>/Compare'
     *  RelationalOperator: '<S465>/Compare'
     *  RelationalOperator: '<S466>/Compare'
     */
    if (((rtb_IMAPve_d_SAS_Trim_State > ((uint8)0U)) || (((sint32)
           (rtb_BCM_Left_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) ||
        (((sint32)(rtb_BCM_Right_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) {
      rtb_TLft = 3.0F;
    } else {
      rtb_TLft = (-1.0F);
    }

    /* End of Switch: '<S459>/Switch' */

    /* Sum: '<S459>/Add' incorporates:
     *  Memory: '<S459>/Memory'
     */
    rtb_TLft += LKAS_DW.Memory_PreviousInput_e;

    /* Saturate: '<S459>/Saturation' */
    if (rtb_TLft > 200.0F) {
      rtb_Saturation_k = 200.0F;
    } else if (rtb_TLft < (-1.0F)) {
      rtb_Saturation_k = (-1.0F);
    } else {
      rtb_Saturation_k = rtb_TLft;
    }

    /* End of Saturate: '<S459>/Saturation' */

    /* RelationalOperator: '<S463>/Compare' incorporates:
     *  Constant: '<S463>/Constant'
     */
    rtb_BCM_Left_Light = (rtb_Saturation_k > 1.0F);

    /* RelationalOperator: '<S467>/Compare' incorporates:
     *  Constant: '<S467>/Constant'
     */
    rtb_BCM_Right_Light = (rtb_TCU_ActualGear != ((uint8)3U));

    /* Logic: '<S414>/Logical Operator' incorporates:
     *  Constant: '<S418>/Constant'
     *  Constant: '<S419>/Constant'
     *  RelationalOperator: '<S418>/Compare'
     *  RelationalOperator: '<S419>/Compare'
     *  Switch: '<S53>/Switch'
     *  Switch: '<S53>/Switch1'
     */
    rtb_LogicalOperator_i4 = ((rtb_L0_Q < ((uint8)3U)) && (rtb_R0_Q < ((uint8)3U)));

    /* Abs: '<S415>/Abs1' */
    rtb_Abs1_c = rtb_LftTTLC;

    /* RelationalOperator: '<S420>/Compare' incorporates:
     *  Constant: '<S420>/Constant'
     *  Logic: '<S421>/FixPt Logical Operator'
     *  RelationalOperator: '<S421>/Lower Test'
     *  RelationalOperator: '<S421>/Upper Test'
     */
    rtb_Compare_jl = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_c) &&
      (rtb_Abs1_c <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S413>/Abs' */
    rtb_Abs_g = rtb_TTLC;

    /* Logic: '<S413>/Logical Operator' incorporates:
     *  Constant: '<S413>/Constant'
     *  Logic: '<S417>/FixPt Logical Operator'
     *  RelationalOperator: '<S417>/Lower Test'
     *  RelationalOperator: '<S417>/Upper Test'
     */
    rtb_LogicalOperator_no = ((0.0F > rtb_Abs_g) || (rtb_Abs_g >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S416>/Compare' incorporates:
     *  Constant: '<S416>/Constant'
     */
    rtb_Compare_dq = (rtb_IMAPve_g_ESC_LatAcc > 0.04F);

    /* Switch: '<S552>/Switch72' incorporates:
     *  Constant: '<S552>/LLSMConClb26'
     *
     * Block description for '<S552>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_TLft = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S552>/Switch72' */

    /* RelationalOperator: '<S375>/Relational Operator1' */
    rtb_phiSWA_Thres = (x1 >= rtb_TLft);

    /* Switch: '<S552>/Switch74' incorporates:
     *  Constant: '<S552>/LLSMConClb28'
     *
     * Block description for '<S552>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_TLft = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S552>/Switch74' */

    /* RelationalOperator: '<S375>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_LogicalOperator3_ls_tmp >= rtb_TLft);

    /* Switch: '<S552>/Switch79' incorporates:
     *  Constant: '<S552>/LLSMConClb29'
     *
     * Block description for '<S552>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_TLft = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_TLft = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S552>/Switch79' */

    /* Logic: '<S375>/Logical Operator1' incorporates:
     *  Constant: '<S378>/Constant'
     *  RelationalOperator: '<S375>/Relational Operator3'
     *  RelationalOperator: '<S378>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_ls_tmp_0 >= rtb_TLft) &&
                       (rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)));

    /* Switch: '<S552>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S375>/Unary Minus' */
      rtb_UnaryMinus_k = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S375>/Unary Minus' incorporates:
       *  Constant: '<S552>/LLSMConClb30'
       *
       * Block description for '<S552>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_k = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S552>/Switch61' */

    /* RelationalOperator: '<S379>/Compare' incorporates:
     *  Constant: '<S379>/Constant'
     *  Logic: '<S380>/FixPt Logical Operator'
     *  RelationalOperator: '<S380>/Lower Test'
     *  RelationalOperator: '<S380>/Upper Test'
     */
    rtb_Compare_k0f = (((sint32)(((rtb_UnaryMinus_k < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                       ((sint32)(false ? 1 : 0)));

    /* Switch: '<S376>/Switch' incorporates:
     *  Constant: '<S381>/Constant'
     *  Constant: '<S552>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
     *  RelationalOperator: '<S381>/Compare'
     *  Switch: '<S552>/Switch38'
     *
     * Block description for '<S552>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
     *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      /* Switch: '<S552>/Switch44' incorporates:
       *  Constant: '<S552>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
       *
       * Block description for '<S552>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
       *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
       */
      if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
        rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion8;
      } else {
        rtb_LKA_Veh2CamL_C = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
      }

      /* End of Switch: '<S552>/Switch44' */
    } else if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
      /* Switch: '<S552>/Switch38' */
      rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion6;
    } else {
      rtb_LKA_Veh2CamL_C = LL_RlsDet_tiTrqChkT_DISABLE;
    }

    /* End of Switch: '<S376>/Switch' */

    /* Outputs for Enabled SubSystem: '<S376>/Count 20s' incorporates:
     *  EnablePort: '<S384>/Enable'
     */
    /* Logic: '<S376>/Logical Operator1' incorporates:
     *  Constant: '<S382>/Constant'
     *  Constant: '<S383>/Constant'
     *  Logic: '<S376>/Logical Operator2'
     *  RelationalOperator: '<S376>/Relational Operator'
     *  RelationalOperator: '<S382>/Compare'
     *  RelationalOperator: '<S383>/Compare'
     */
    if (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
         (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) && (rtb_LKA_Veh2CamW_C <=
         rtb_LKA_Veh2CamL_C)) {
      if (!LKAS_DW.Count20s_MODE) {
        /* InitializeConditions for Memory: '<S384>/Memory' */
        LKAS_DW.Memory_PreviousInput_dy = 0.0F;
        LKAS_DW.Count20s_MODE = true;
      }

      /* Sum: '<S384>/Add' incorporates:
       *  Memory: '<S384>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_dy;

      /* Saturate: '<S384>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 50.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 50.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S384>/Saturation' */

      /* RelationalOperator: '<S384>/Relational Operator' incorporates:
       *  Constant: '<S384>/Constant'
       */
      LKAS_DW.RelationalOperator_c = (rtb_IMAPve_g_ESC_LatAcc >= 20.0F);

      /* Update for Memory: '<S384>/Memory' */
      LKAS_DW.Memory_PreviousInput_dy = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S384>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.Count20s_MODE = false;
      }
    }

    /* End of Logic: '<S376>/Logical Operator1' */
    /* End of Outputs for SubSystem: '<S376>/Count 20s' */

    /* Saturate: '<S377>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S385>:1' */
    /* '<S385>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S385>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S385>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S385>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_IMAPve_g_ESC_VehSpd > 80.0F) {
      rtb_TLft = 80.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      rtb_TLft = 60.0F;
    } else {
      rtb_TLft = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S377>/Saturation' */

    /* MATLAB Function: '<S377>/MATLAB Function' */
    if (rtb_LKA_Veh2CamW_C >= fminf(fmaxf(1.5F, ((1.5F *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL) - ((rtb_TLft / 180.0F) *
            rtb_LL_MAX_DRIVER_TORQUE_DISABL)) + (rtb_TTLC / 0.005F)), 2.75F)) {
      /* Outputs for Enabled SubSystem: '<S377>/Sum Condition1' incorporates:
       *  EnablePort: '<S386>/state = reset'
       */
      /* '<S385>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_i) {
        /* InitializeConditions for Memory: '<S386>/Memory' */
        LKAS_DW.Memory_PreviousInput_k = 0.0F;
        LKAS_DW.SumCondition1_MODE_i = true;
      }

      /* Sum: '<S386>/Add1' incorporates:
       *  Memory: '<S386>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_k;

      /* Saturate: '<S386>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 5000.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 5000.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S386>/Saturation' */
      /* End of Outputs for SubSystem: '<S377>/Sum Condition1' */

      /* Switch: '<S552>/Switch65' incorporates:
       *  Constant: '<S552>/LLSMConClb34'
       *
       * Block description for '<S552>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_TLft = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_TLft = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S552>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S377>/Sum Condition1' incorporates:
       *  EnablePort: '<S386>/state = reset'
       */
      /* RelationalOperator: '<S386>/Relational Operator' */
      LKAS_DW.RelationalOperator_e = (rtb_IMAPve_g_ESC_LatAcc >= rtb_TLft);

      /* Update for Memory: '<S386>/Memory' */
      LKAS_DW.Memory_PreviousInput_k = rtb_IMAPve_g_ESC_LatAcc;

      /* End of Outputs for SubSystem: '<S377>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S377>/Sum Condition1' incorporates:
       *  EnablePort: '<S386>/state = reset'
       */
      /* '<S385>:1:7' else */
      /* '<S385>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S386>/Out' */
        LKAS_DW.RelationalOperator_e = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Outputs for SubSystem: '<S377>/Sum Condition1' */
    }

    /* RelationalOperator: '<S395>/Compare' incorporates:
     *  Constant: '<S395>/Constant'
     */
    rtb_Compare_ds = (((sint32)(LKAS_DW.RelationalOperator_e ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S387>/Unit Delay' */
    rtb_UnitDelay_l = LKAS_DW.UnitDelay_DSTATE_e;

    /* RelationalOperator: '<S394>/Compare' incorporates:
     *  Constant: '<S394>/Constant'
     */
    rtb_Compare_e3 = (((sint32)(rtb_UnitDelay_l ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S387>/If' incorporates:
     *  Constant: '<S390>/Constant'
     *  Constant: '<S391>/Constant'
     *  RelationalOperator: '<S388>/FixPt Relational Operator'
     *  RelationalOperator: '<S389>/FixPt Relational Operator'
     *  UnitDelay: '<S388>/Delay Input1'
     *  UnitDelay: '<S389>/Delay Input1'
     *
     * Block description for '<S388>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S389>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_e) && (((sint32)(rtb_Compare_ds ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S387>/If Action Subsystem' incorporates:
       *  ActionPort: '<S390>/Action Port'
       */
      rtb_Merge_i = true;

      /* End of Outputs for SubSystem: '<S387>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_l) && (((sint32)(rtb_Compare_e3 ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_a ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S387>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S391>/Action Port'
       */
      rtb_Merge_i = false;

      /* End of Outputs for SubSystem: '<S387>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S387>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S392>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_l, &rtb_Merge_i);

      /* End of Outputs for SubSystem: '<S387>/If Action Subsystem3' */
    }

    /* End of If: '<S387>/If' */

    /* Outputs for Enabled SubSystem: '<S387>/Sum Condition1' incorporates:
     *  EnablePort: '<S393>/state = reset'
     */
    if (rtb_Merge_i) {
      if (!LKAS_DW.SumCondition1_MODE_j) {
        /* InitializeConditions for Memory: '<S393>/Memory' */
        LKAS_DW.Memory_PreviousInput_c = 0.0F;
        LKAS_DW.SumCondition1_MODE_j = true;
      }

      /* Sum: '<S393>/Add1' incorporates:
       *  Memory: '<S393>/Memory'
       */
      rtb_IMAPve_g_ESC_LatAcc = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_c;

      /* Saturate: '<S393>/Saturation' */
      if (rtb_IMAPve_g_ESC_LatAcc > 10.0F) {
        rtb_IMAPve_g_ESC_LatAcc = 10.0F;
      } else {
        if (rtb_IMAPve_g_ESC_LatAcc < 0.0F) {
          rtb_IMAPve_g_ESC_LatAcc = 0.0F;
        }
      }

      /* End of Saturate: '<S393>/Saturation' */

      /* RelationalOperator: '<S393>/Relational Operator' */
      LKAS_DW.RelationalOperator_h = (rtb_IMAPve_g_ESC_LatAcc <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S393>/Memory' */
      LKAS_DW.Memory_PreviousInput_c = rtb_IMAPve_g_ESC_LatAcc;
    } else {
      if (LKAS_DW.SumCondition1_MODE_j) {
        /* Disable for Outport: '<S393>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.SumCondition1_MODE_j = false;
      }
    }

    /* End of Outputs for SubSystem: '<S387>/Sum Condition1' */

    /* Logic: '<S361>/Logical Operator2' incorporates:
     *  Logic: '<S374>/Logical Operator1'
     *  Logic: '<S375>/Logical Operator'
     *  Logic: '<S412>/Logical Operator3'
     *  Logic: '<S462>/Logical Operator3'
     */
    rtb_LogicalOperator3_a = ((((rtb_LKA_Main_Switch || rtb_BCM_Left_Light) ||
      rtb_BCM_Right_Light) || (((rtb_LogicalOperator_i4 || rtb_Compare_jl) ||
      rtb_LogicalOperator_no) || rtb_Compare_dq)) || (((((rtb_phiSWA_Thres ||
      rtb_dphiSWARate_Thres) || rtb_aLAcc_Thres) || rtb_Compare_k0f) ||
      (LKAS_DW.RelationalOperator_c)) || (LKAS_DW.RelationalOperator_h)));

    /* Logic: '<S401>/Logical Operator' incorporates:
     *  RelationalOperator: '<S401>/Relational Operator1'
     *  RelationalOperator: '<S401>/Relational Operator2'
     */
    rtb_stDvrTkConFlg_p = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S402>/Logical Operator' incorporates:
     *  RelationalOperator: '<S402>/Relational Operator1'
     *  RelationalOperator: '<S402>/Relational Operator2'
     */
    rtb_LogicalOperator_ee = ((rtb_Gain1 <= rtb_R0_C2) || (rtb_Add5_n <=
      rtb_R0_C2));

    /* If: '<S399>/If' incorporates:
     *  Constant: '<S405>/Constant'
     *  Delay: '<S78>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_IMAPve_d_EPS_LKA_State) != 1)) {
      /* Outputs for IfAction SubSystem: '<S399>/If Action Subsystem' incorporates:
       *  ActionPort: '<S403>/Action Port'
       */
      LKAS_IfActionSubsystem_j(&rtb_Merge_j);

      /* End of Outputs for SubSystem: '<S399>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_IMAPve_d_EPS_LKA_State) != 3)) {
      /* Outputs for IfAction SubSystem: '<S399>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S404>/Action Port'
       */
      LKAS_IfActionSubsystem_j(&rtb_Merge_j);

      /* End of Outputs for SubSystem: '<S399>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S399>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S405>/Action Port'
       */
      rtb_Merge_j = false;

      /* End of Outputs for SubSystem: '<S399>/If Action Subsystem3' */
    }

    /* End of If: '<S399>/If' */

    /* Outputs for Enabled SubSystem: '<S399>/Sum Condition1' incorporates:
     *  EnablePort: '<S406>/state = reset'
     */
    if (rtb_Merge_j) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S406>/Memory' */
        LKAS_DW.Memory_PreviousInput_m = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S406>/Add1' incorporates:
       *  Memory: '<S406>/Memory'
       */
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_m;

      /* Saturate: '<S406>/Saturation' */
      if (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ > 60.0F) {
        rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 60.0F;
      } else {
        if (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ < 0.0F) {
          rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 0.0F;
        }
      }

      /* End of Saturate: '<S406>/Saturation' */

      /* Switch: '<S552>/Switch63' incorporates:
       *  Constant: '<S552>/LLSMConClb32'
       *
       * Block description for '<S552>/LLSMConClb32':
       *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion78;
      } else {
        x10 = LL_MAX_DELAY_EPSSTAR_TIME;
      }

      /* End of Switch: '<S552>/Switch63' */

      /* RelationalOperator: '<S406>/Relational Operator' */
      LKAS_DW.RelationalOperator_m = (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= x10);

      /* Update for Memory: '<S406>/Memory' */
      LKAS_DW.Memory_PreviousInput_m = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S406>/Out' */
        LKAS_DW.RelationalOperator_m = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S399>/Sum Condition1' */

    /* If: '<S361>/If2' incorporates:
     *  Constant: '<S370>/Constant'
     *  Constant: '<S407>/Constant'
     *  Constant: '<S408>/Constant'
     *  Constant: '<S409>/Constant'
     *  Constant: '<S410>/Constant'
     *  DataTypeConversion: '<S361>/Cast To Single'
     *  Logic: '<S361>/Logical Operator1'
     *  Logic: '<S400>/Logical Operator'
     *  Logic: '<S400>/Logical Operator1'
     *  RelationalOperator: '<S407>/Compare'
     *  RelationalOperator: '<S408>/Compare'
     *  RelationalOperator: '<S409>/Compare'
     *  RelationalOperator: '<S410>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_LogicalOperator3_a ||
         ((LKAS_DW.LKA_Mode == ((uint8)2U)) && (((rtb_stDvrTkConFlg_p == true) ||
            (rtb_LogicalOperator_ee == true)) || (LKAS_DW.RelationalOperator_m ==
            true))))) {
      /* Outputs for IfAction SubSystem: '<S361>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S370>/Action Port'
       */
      LKAS_DW.Merge2 = true;

      /* End of Outputs for SubSystem: '<S361>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S361>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S372>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2);

      /* End of Outputs for SubSystem: '<S361>/If Action Subsystem3' */
    }

    /* End of If: '<S361>/If2' */

    /* Product: '<S276>/Divide' */
    rtb_LKA_Veh2CamL_C = rtb_L0_C1_p * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S276>/Divide1' */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* If: '<S298>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S298>/Ph1SWA' incorporates:
       *  ActionPort: '<S302>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S298>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S298>/Ph2SWA' incorporates:
       *  ActionPort: '<S303>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S298>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S298>/Ph3SWA' incorporates:
       *  ActionPort: '<S304>/Action Port'
       */
      LKAS_Ph3SWA_g(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S298>/Ph3SWA' */
    }

    /* End of If: '<S298>/If' */

    /* Saturate: '<S276>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_IMAPve_g_ESC_LatAcc = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_IMAPve_g_ESC_LatAcc = (-2.0F);
    } else {
      rtb_IMAPve_g_ESC_LatAcc = rtb_Gain1;
    }

    /* End of Saturate: '<S276>/Saturation5' */

    /* MATLAB Function: '<S285>/MATLAB Function' incorporates:
     *  MATLAB Function: '<S321>/MATLAB Function'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S288>:1' */
    /* '<S288>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S288>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S288>:1:5' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S288>:1:6' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S288>:1:7' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    x20 = (2.0F * rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth;
    x20 = fminf(fmaxf(0.0F, (fminf(fmaxf(x20, rtb_LaneWidth), (6.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth) - x20) / (4.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW)), 1.0F);

    /* Product: '<S285>/Divide5' incorporates:
     *  MATLAB Function: '<S285>/MATLAB Function'
     */
    rtb_ThresDet_coefficient_n = x20 * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S285>/Divide6' incorporates:
     *  MATLAB Function: '<S285>/MATLAB Function'
     */
    rtb_TLft = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S300>/Abs' incorporates:
     *  Abs: '<S291>/Abs'
     */
    rtb_LogicalOperator3_ls_tmp = fabsf(rtb_LKA_Veh2CamL_C);

    /* Product: '<S300>/Divide' incorporates:
     *  Abs: '<S300>/Abs'
     */
    rtb_Divide_m = rtb_TLft * rtb_LogicalOperator3_ls_tmp;

    /* Product: '<S285>/Divide4' incorporates:
     *  MATLAB Function: '<S285>/MATLAB Function'
     */
    rtb_TTLC_m = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S305>/Switch' incorporates:
     *  RelationalOperator: '<S305>/UpperRelop'
     */
    if (rtb_Divide_m < rtb_TTLC_m) {
      rtb_Switch_o2 = rtb_TTLC_m;
    } else {
      rtb_Switch_o2 = rtb_Divide_m;
    }

    /* End of Switch: '<S305>/Switch' */

    /* Switch: '<S305>/Switch2' incorporates:
     *  RelationalOperator: '<S305>/LowerRelop1'
     */
    if (rtb_Divide_m > rtb_ThresDet_coefficient_n) {
      rtb_Switch2_f = rtb_ThresDet_coefficient_n;
    } else {
      rtb_Switch2_f = rtb_Switch_o2;
    }

    /* End of Switch: '<S305>/Switch2' */

    /* Saturate: '<S276>/Saturation1' */
    if (rtb_Add5_n > 2.0F) {
      rtb_LKA_Veh2CamW_C = 2.0F;
    } else if (rtb_Add5_n < (-2.0F)) {
      rtb_LKA_Veh2CamW_C = (-2.0F);
    } else {
      rtb_LKA_Veh2CamW_C = rtb_Add5_n;
    }

    /* End of Saturate: '<S276>/Saturation1' */

    /* Abs: '<S301>/Abs' incorporates:
     *  Abs: '<S292>/Abs'
     */
    rtb_LogicalOperator3_ls_tmp_0 = fabsf(rtb_LL_LKAS_OUT_OF_CONTROL_LAT_);

    /* Product: '<S301>/Divide' incorporates:
     *  Abs: '<S301>/Abs'
     */
    rtb_Divide_k = rtb_TLft * rtb_LogicalOperator3_ls_tmp_0;

    /* Switch: '<S306>/Switch' incorporates:
     *  RelationalOperator: '<S306>/UpperRelop'
     */
    if (rtb_Divide_k < rtb_TTLC_m) {
      rtb_Switch_h1 = rtb_TTLC_m;
    } else {
      rtb_Switch_h1 = rtb_Divide_k;
    }

    /* End of Switch: '<S306>/Switch' */

    /* Switch: '<S306>/Switch2' incorporates:
     *  RelationalOperator: '<S306>/LowerRelop1'
     */
    if (rtb_Divide_k > rtb_ThresDet_coefficient_n) {
      rtb_Switch2_l = rtb_ThresDet_coefficient_n;
    } else {
      rtb_Switch2_l = rtb_Switch_h1;
    }

    /* End of Switch: '<S306>/Switch2' */

    /* Switch: '<S299>/Switch3' incorporates:
     *  Constant: '<S301>/Constant'
     *  Gain: '<S299>/Gain1'
     *  Logic: '<S301>/Logical Operator'
     *  RelationalOperator: '<S301>/Relational Operator1'
     *  RelationalOperator: '<S301>/Relational Operator2'
     */
    if (rtb_Merge1_j >= 0.0F) {
      /* Switch: '<S299>/Switch2' incorporates:
       *  Constant: '<S299>/Constant2'
       *  Constant: '<S300>/Constant'
       *  DataTypeConversion: '<S299>/Cast To Single'
       *  Logic: '<S300>/Logical Operator'
       *  RelationalOperator: '<S300>/Relational Operator1'
       *  RelationalOperator: '<S300>/Relational Operator3'
       */
      if (rtb_Merge1_j > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_IMAPve_g_ESC_LatAcc) &&
          (rtb_IMAPve_g_ESC_LatAcc <= rtb_Switch2_f)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S299>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F < rtb_LKA_Veh2CamW_C) &&
        (rtb_LKA_Veh2CamW_C <= rtb_Switch2_l)) ? 1 : 0)) * ((uint32)((uint8)128U)))
        >> 6);
    }

    /* End of Switch: '<S299>/Switch3' */

    /* DataTypeConversion: '<S278>/Data Type Conversion' incorporates:
     *  Constant: '<S309>/Constant'
     *  Constant: '<S310>/Constant'
     *  Constant: '<S311>/Constant'
     *  Constant: '<S312>/Constant'
     *  Logic: '<S278>/Logical Operator'
     *  Logic: '<S278>/Logical Operator1'
     *  Logic: '<S278>/Logical Operator2'
     *  RelationalOperator: '<S309>/Compare'
     *  RelationalOperator: '<S310>/Compare'
     *  RelationalOperator: '<S311>/Compare'
     *  RelationalOperator: '<S312>/Compare'
     *  Switch: '<S53>/Switch'
     *  Switch: '<S53>/Switch1'
     */
    rtb_IMAPve_d_SAS_Trim_State = (uint8)((((rtb_R0_Q > ((uint8)2U)) &&
      (rtb_TCU_ActualGear == ((uint8)2U))) || ((rtb_TCU_ActualGear == ((uint8)1U))
      && (rtb_L0_Q > ((uint8)2U)))) ? 1 : 0);

    /* DataTypeConversion: '<S277>/Data Type Conversion' incorporates:
     *  Constant: '<S307>/Constant'
     *  Constant: '<S308>/Constant'
     *  Logic: '<S277>/Logical Operator'
     *  RelationalOperator: '<S307>/Compare'
     *  RelationalOperator: '<S308>/Compare'
     */
    rtb_CastToSingle3 = (uint8)(((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
      (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? 1 : 0);

    /* If: '<S275>/If1' incorporates:
     *  Constant: '<S280>/Constant'
     *  Constant: '<S283>/Constant'
     *  Constant: '<S284>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)rtb_TCU_ActualGear) ==
           1)) && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S275>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S283>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S275>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)
        rtb_TCU_ActualGear) == 2)) && (((sint32)rtb_CastToSingle3) == 1)) &&
               (((sint32)rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S275>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S284>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S275>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S275>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S280>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S275>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S275>/If1' */

    /* Product: '<S314>/Divide' */
    rtb_TTLC_m = rtb_L0_C1_p * rtb_LKA_Veh2CamL_C_tmp;

    /* Product: '<S314>/Divide1' */
    rtb_Gain2_0 = rtb_LKA_Veh2CamL_C_tmp * rtb_L0_C1;

    /* If: '<S335>/If' incorporates:
     *  Product: '<S314>/Divide1'
     */
    if ((rtb_TTLC_m >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Gain2_0 >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S335>/Ph1SWA' incorporates:
       *  ActionPort: '<S339>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S335>/Ph1SWA' */
    } else if ((rtb_TTLC_m <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_Gain2_0 <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S335>/Ph2SWA' incorporates:
       *  ActionPort: '<S340>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S335>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S335>/Ph3SWA' incorporates:
       *  ActionPort: '<S341>/Action Port'
       */
      LKAS_Ph3SWA_g(&rtb_Merge1_d);

      /* End of Outputs for SubSystem: '<S335>/Ph3SWA' */
    }

    /* End of If: '<S335>/If' */

    /* Saturate: '<S314>/Saturation5' */
    if (rtb_Gain1 > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_Gain1 < (-2.0F)) {
      rtb_LftTTLC = (-2.0F);
    } else {
      rtb_LftTTLC = rtb_Gain1;
    }

    /* End of Saturate: '<S314>/Saturation5' */

    /* Product: '<S321>/Divide5' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S324>:1' */
    /* '<S324>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S324>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S324>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S324>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S324>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_TLft = x20 * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S321>/Divide6' */
    rtb_ThresDet_coefficient_n = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S337>/Divide' incorporates:
     *  Abs: '<S337>/Abs'
     */
    rtb_Divide_j = rtb_ThresDet_coefficient_n * fabsf(rtb_TTLC_m);

    /* Product: '<S321>/Divide4' */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S342>/Switch' incorporates:
     *  RelationalOperator: '<S342>/UpperRelop'
     */
    if (rtb_Divide_j < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_d = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_d = rtb_Divide_j;
    }

    /* End of Switch: '<S342>/Switch' */

    /* Switch: '<S342>/Switch2' incorporates:
     *  RelationalOperator: '<S342>/LowerRelop1'
     */
    if (rtb_Divide_j > rtb_TLft) {
      rtb_Switch2_ol = rtb_TLft;
    } else {
      rtb_Switch2_ol = rtb_Switch_d;
    }

    /* End of Switch: '<S342>/Switch2' */

    /* Saturate: '<S314>/Saturation1' */
    if (rtb_Add5_n > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_n < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_n;
    }

    /* End of Saturate: '<S314>/Saturation1' */

    /* Product: '<S338>/Divide' incorporates:
     *  Abs: '<S338>/Abs'
     *  Product: '<S314>/Divide1'
     */
    rtb_Divide_gn = rtb_ThresDet_coefficient_n * fabsf(rtb_Gain2_0);

    /* Switch: '<S343>/Switch' incorporates:
     *  RelationalOperator: '<S343>/UpperRelop'
     */
    if (rtb_Divide_gn < rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch_b = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch_b = rtb_Divide_gn;
    }

    /* End of Switch: '<S343>/Switch' */

    /* Switch: '<S343>/Switch2' incorporates:
     *  RelationalOperator: '<S343>/LowerRelop1'
     */
    if (rtb_Divide_gn > rtb_TLft) {
      rtb_Switch2_b = rtb_TLft;
    } else {
      rtb_Switch2_b = rtb_Switch_b;
    }

    /* End of Switch: '<S343>/Switch2' */

    /* Switch: '<S336>/Switch3' incorporates:
     *  Constant: '<S338>/Constant'
     *  Gain: '<S336>/Gain1'
     *  Logic: '<S338>/Logical Operator'
     *  RelationalOperator: '<S338>/Relational Operator1'
     *  RelationalOperator: '<S338>/Relational Operator2'
     */
    if (rtb_Merge1_d >= 0.0F) {
      /* Switch: '<S336>/Switch2' incorporates:
       *  Constant: '<S336>/Constant2'
       *  Constant: '<S337>/Constant'
       *  DataTypeConversion: '<S336>/Cast To Single'
       *  Logic: '<S337>/Logical Operator'
       *  RelationalOperator: '<S337>/Relational Operator1'
       *  RelationalOperator: '<S337>/Relational Operator3'
       */
      if (rtb_Merge1_d > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_LftTTLC) && (rtb_LftTTLC <=
          rtb_Switch2_ol)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S336>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F <
        rtb_LL_ThresDet_lDvtThresLwrLKA) && (rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_b)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S336>/Switch3' */

    /* MATLAB Function: '<S315>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S347>:1' */
    /* '<S347>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S347>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S347>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S347>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_IMAPve_g_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge_a), 0.005F)) / 0.005F);

    /* '<S347>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_TCU_ActualGear) == 2) && (rtb_IMAPve_g_EPS_SW_Trq >
          rtb_LL_MAX_DRIVER_TORQUE_DISABL)) || ((((sint32)rtb_TCU_ActualGear) ==
          1) && (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL))))
    {
      /* Outputs for Enabled SubSystem: '<S315>/Count 0.2s' incorporates:
       *  EnablePort: '<S346>/Enable'
       */
      /* '<S347>:1:7' stDvrTkConFlg=1; */
      /* '<S347>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S347>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S346>/Memory' */
        LKAS_DW.Memory_PreviousInput_l = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S346>/Add' incorporates:
       *  Memory: '<S346>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_l;

      /* Saturate: '<S346>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S346>/Saturation' */
      /* End of Outputs for SubSystem: '<S315>/Count 0.2s' */

      /* Switch: '<S552>/Switch16' incorporates:
       *  Constant: '<S552>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S552>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S552>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S315>/Count 0.2s' incorporates:
       *  EnablePort: '<S346>/Enable'
       */
      /* RelationalOperator: '<S346>/Relational Operator' */
      LKAS_DW.RelationalOperator_hg = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S346>/Memory' */
      LKAS_DW.Memory_PreviousInput_l = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S315>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S315>/Count 0.2s' incorporates:
       *  EnablePort: '<S346>/Enable'
       */
      /* '<S347>:1:10' else */
      /* '<S347>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S346>/Out' */
        LKAS_DW.RelationalOperator_hg = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S315>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S315>/MATLAB Function' */

    /* RelationalOperator: '<S356>/Compare' incorporates:
     *  Constant: '<S356>/Constant'
     */
    rtb_Compare_ik = (((sint32)(LKAS_DW.RelationalOperator_hg ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S348>/Unit Delay' */
    rtb_UnitDelay_m = LKAS_DW.UnitDelay_DSTATE_pg;

    /* RelationalOperator: '<S355>/Compare' incorporates:
     *  Constant: '<S355>/Constant'
     */
    rtb_Compare_pr = (((sint32)(rtb_UnitDelay_m ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S348>/If' incorporates:
     *  Constant: '<S351>/Constant'
     *  Constant: '<S352>/Constant'
     *  RelationalOperator: '<S349>/FixPt Relational Operator'
     *  RelationalOperator: '<S350>/FixPt Relational Operator'
     *  UnitDelay: '<S349>/Delay Input1'
     *  UnitDelay: '<S350>/Delay Input1'
     *
     * Block description for '<S349>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S350>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_hg) && (((sint32)(rtb_Compare_ik ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_d ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S348>/If Action Subsystem' incorporates:
       *  ActionPort: '<S351>/Action Port'
       */
      rtb_Merge_iy = true;

      /* End of Outputs for SubSystem: '<S348>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_m) && (((sint32)(rtb_Compare_pr ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_p ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S348>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S352>/Action Port'
       */
      rtb_Merge_iy = false;

      /* End of Outputs for SubSystem: '<S348>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S348>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S353>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_m, &rtb_Merge_iy);

      /* End of Outputs for SubSystem: '<S348>/If Action Subsystem3' */
    }

    /* End of If: '<S348>/If' */

    /* Outputs for Enabled SubSystem: '<S315>/Count' incorporates:
     *  EnablePort: '<S345>/Enable'
     */
    /* Logic: '<S315>/Logical Operator' incorporates:
     *  Constant: '<S344>/Constant'
     *  Memory: '<S315>/Memory'
     *  RelationalOperator: '<S344>/Compare'
     */
    if ((rtb_TCU_ActualGear > ((uint8)0U)) && (LKAS_DW.Memory_PreviousInput_c0))
    {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S345>/Memory' */
        LKAS_DW.Memory_PreviousInput_jt = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S345>/Add' incorporates:
       *  Memory: '<S345>/Memory'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_jt;

      /* Saturate: '<S345>/Saturation' */
      if (rtb_TLft > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_TLft;
      }

      /* End of Saturate: '<S345>/Saturation' */

      /* Update for Memory: '<S345>/Memory' */
      LKAS_DW.Memory_PreviousInput_jt = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S345>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S315>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S315>/Count' */

    /* Outputs for Enabled SubSystem: '<S348>/Sum Condition1' incorporates:
     *  EnablePort: '<S354>/state = reset'
     */
    if (rtb_Merge_iy) {
      if (!LKAS_DW.SumCondition1_MODE_m) {
        /* InitializeConditions for Memory: '<S354>/Memory' */
        LKAS_DW.Memory_PreviousInput_p = 0.0F;
        LKAS_DW.SumCondition1_MODE_m = true;
      }

      /* Sum: '<S354>/Add1' incorporates:
       *  Memory: '<S354>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_p;

      /* Saturate: '<S354>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 5.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 5.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S354>/Saturation' */

      /* Switch: '<S552>/Switch40' incorporates:
       *  Constant: '<S552>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S552>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S552>/Switch40' */

      /* RelationalOperator: '<S354>/Relational Operator' incorporates:
       *  Sum: '<S315>/Add'
       */
      LKAS_DW.RelationalOperator_l = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S354>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S354>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }
    }

    /* End of Outputs for SubSystem: '<S348>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S316>/Sum Condition1' incorporates:
     *  EnablePort: '<S360>/state = reset'
     */
    /* Logic: '<S316>/Logical Operator' incorporates:
     *  Constant: '<S358>/Constant'
     *  Constant: '<S359>/Constant'
     *  Delay: '<S78>/Delay1'
     *  RelationalOperator: '<S358>/Compare'
     *  RelationalOperator: '<S359>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_d) {
        /* InitializeConditions for Memory: '<S360>/Memory' */
        LKAS_DW.Memory_PreviousInput_mg = 0.0F;
        LKAS_DW.SumCondition1_MODE_d = true;
      }

      /* Sum: '<S360>/Add1' incorporates:
       *  Memory: '<S360>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_mg;

      /* Saturate: '<S360>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S360>/Saturation' */

      /* RelationalOperator: '<S360>/Relational Operator' */
      LKAS_DW.RelationalOperator_o = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S360>/Memory' */
      LKAS_DW.Memory_PreviousInput_mg = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_d) {
        /* Disable for Outport: '<S360>/Out' */
        LKAS_DW.RelationalOperator_o = false;
        LKAS_DW.SumCondition1_MODE_d = false;
      }
    }

    /* End of Logic: '<S316>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S316>/Sum Condition1' */

    /* If: '<S313>/If1' incorporates:
     *  Constant: '<S318>/Constant'
     *  Constant: '<S320>/Constant'
     *  Constant: '<S357>/Constant'
     *  Delay: '<S78>/Delay'
     *  Logic: '<S313>/Logical Operator'
     *  Logic: '<S316>/Logical Operator1'
     *  RelationalOperator: '<S357>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((LKAS_DW.RelationalOperator_l) ||
          ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_o))) || (LKAS_DW.Delay_DSTATE_e))) {
      /* Outputs for IfAction SubSystem: '<S313>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S320>/Action Port'
       */
      LKAS_DW.Merge1_l = true;

      /* End of Outputs for SubSystem: '<S313>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S313>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S318>/Action Port'
       */
      LKAS_DW.Merge1_l = false;

      /* End of Outputs for SubSystem: '<S313>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S313>/If1' */

    /* MATLAB Function: '<S484>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_ThresDet_lDvtThresUprLDW, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient_n);

    /* Product: '<S484>/Multiply' */
    rtb_Multiply_m = rtb_LL_ThresDet_lDvtThresUprLDW *
      rtb_ThresDet_coefficient_n;

    /* Switch: '<S486>/Switch' incorporates:
     *  Constant: '<S484>/Constant'
     *  RelationalOperator: '<S486>/UpperRelop'
     */
    if (rtb_Multiply_m < 0.0F) {
      rtb_Switch_m = 0.0F;
    } else {
      rtb_Switch_m = rtb_Multiply_m;
    }

    /* End of Switch: '<S486>/Switch' */

    /* Switch: '<S486>/Switch2' incorporates:
     *  RelationalOperator: '<S486>/LowerRelop1'
     */
    if (rtb_Multiply_m > rtb_LL_ThresDet_lDvtThresUprLDW) {
      rtb_Switch2_cx = rtb_LL_ThresDet_lDvtThresUprLDW;
    } else {
      rtb_Switch2_cx = rtb_Switch_m;
    }

    /* End of Switch: '<S486>/Switch2' */

    /* Logic: '<S470>/Logical Operator3' incorporates:
     *  Constant: '<S482>/Constant'
     *  Constant: '<S483>/Constant'
     *  Logic: '<S480>/Logical Operator'
     *  Logic: '<S481>/Logical Operator'
     *  RelationalOperator: '<S481>/Relational Operator1'
     *  RelationalOperator: '<S481>/Relational Operator2'
     *  RelationalOperator: '<S482>/Compare'
     *  RelationalOperator: '<S483>/Compare'
     */
    rtb_LogicalOperator3_e = (((LKAS_DW.LKA_Mode >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1 >= rtb_Switch2_cx) && (rtb_Add5_n >= rtb_Switch2_cx)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_e);

    /* If: '<S470>/If' incorporates:
     *  Constant: '<S476>/Constant'
     *  DataTypeConversion: '<S470>/Cast To Single'
     *  DataTypeConversion: '<S470>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_LogicalOperator3_e) {
      /* Outputs for IfAction SubSystem: '<S470>/If Action Subsystem' incorporates:
       *  ActionPort: '<S476>/Action Port'
       */
      LKAS_DW.Merge_e = true;

      /* End of Outputs for SubSystem: '<S470>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S470>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S478>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_e);

      /* End of Outputs for SubSystem: '<S470>/If Action Subsystem3' */
    }

    /* End of If: '<S470>/If' */

    /* Delay: '<S78>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S363>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S363>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_hq != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S363>/If Action Subsystem' incorporates:
         *  ActionPort: '<S396>/Action Port'
         */
        /* InitializeConditions for If: '<S363>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S396>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_j = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S363>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S363>/If Action Subsystem' incorporates:
       *  ActionPort: '<S396>/Action Port'
       */
      /* Sum: '<S396>/Add1' incorporates:
       *  Memory: '<S396>/Memory'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_j;

      /* Saturate: '<S396>/Saturation' */
      if (rtb_LL_TkOvStChk_tiTDelTime > 10.0F) {
        rtb_LL_TkOvStChk_tiTDelTime = 10.0F;
      } else {
        if (rtb_LL_TkOvStChk_tiTDelTime < 0.0F) {
          rtb_LL_TkOvStChk_tiTDelTime = 0.0F;
        }
      }

      /* End of Saturate: '<S396>/Saturation' */
      /* End of Outputs for SubSystem: '<S363>/If Action Subsystem' */

      /* Switch: '<S552>/Switch64' incorporates:
       *  Constant: '<S552>/LLSMConClb33'
       *
       * Block description for '<S552>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S552>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S363>/If Action Subsystem' incorporates:
       *  ActionPort: '<S396>/Action Port'
       */
      /* RelationalOperator: '<S396>/Relational Operator' */
      rtb_Merge = (rtb_LL_TkOvStChk_tiTDelTime >= x10);

      /* Update for Memory: '<S396>/Memory' */
      LKAS_DW.Memory_PreviousInput_j = rtb_LL_TkOvStChk_tiTDelTime;

      /* End of Outputs for SubSystem: '<S363>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S363>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S397>/Action Port'
       */
      /* SignalConversion: '<S397>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S397>/Constant'
       */
      rtb_Merge = false;

      /* End of Outputs for SubSystem: '<S363>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S363>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S364>/Logical Operator1' incorporates:
     *  Constant: '<S398>/Constant'
     *  Logic: '<S364>/Logical Operator'
     *  RelationalOperator: '<S364>/Relational Operator1'
     *  RelationalOperator: '<S364>/Relational Operator2'
     *  RelationalOperator: '<S398>/Compare'
     */
    rtb_LogicalOperator3_e = ((LKAS_DW.LKA_Mode >= ((uint8)1U)) && ((rtb_Gain1 <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_n <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S361>/Logical Operator3' */
    rtb_LogicalOperator3_a = ((rtb_LogicalOperator3_e || rtb_Merge) ||
      rtb_LogicalOperator3_a);

    /* If: '<S361>/If1' incorporates:
     *  Constant: '<S371>/Constant'
     *  DataTypeConversion: '<S361>/Cast To Single'
     *  DataTypeConversion: '<S361>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_LogicalOperator3_a) {
      /* Outputs for IfAction SubSystem: '<S361>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S371>/Action Port'
       */
      LKAS_DW.Merge1_p = true;

      /* End of Outputs for SubSystem: '<S361>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S361>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S373>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_p);

      /* End of Outputs for SubSystem: '<S361>/If Action Subsystem4' */
    }

    /* End of If: '<S361>/If1' */

    /* Memory: '<S289>/Memory' */
    rtb_Memory_h = LKAS_DW.Memory_PreviousInput_g;

    /* If: '<S289>/If' */
    if ((rtb_LKA_Veh2CamL_C >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) &&
        (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ >= rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S289>/Ph1SWA' incorporates:
       *  ActionPort: '<S293>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_p);

      /* End of Outputs for SubSystem: '<S289>/Ph1SWA' */
    } else if ((rtb_LKA_Veh2CamL_C <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) &&
               (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S289>/Ph2SWA' incorporates:
       *  ActionPort: '<S294>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_p);

      /* End of Outputs for SubSystem: '<S289>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S289>/Ph3SWA' incorporates:
       *  ActionPort: '<S295>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_h, &rtb_Merge1_p);

      /* End of Outputs for SubSystem: '<S289>/Ph3SWA' */
    }

    /* End of If: '<S289>/If' */

    /* Product: '<S285>/Divide2' incorporates:
     *  MATLAB Function: '<S285>/MATLAB Function'
     */
    rtb_LL_LDW_LatestWarnLine_C = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S285>/Divide3' incorporates:
     *  MATLAB Function: '<S285>/MATLAB Function'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S291>/Divide' */
    rtb_Divide_p = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LogicalOperator3_ls_tmp;

    /* Product: '<S285>/Divide1' incorporates:
     *  MATLAB Function: '<S285>/MATLAB Function'
     */
    rtb_TLft = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S296>/Switch' incorporates:
     *  RelationalOperator: '<S296>/UpperRelop'
     */
    if (rtb_Divide_p < rtb_TLft) {
      rtb_Switch_i = rtb_TLft;
    } else {
      rtb_Switch_i = rtb_Divide_p;
    }

    /* End of Switch: '<S296>/Switch' */

    /* Switch: '<S296>/Switch2' incorporates:
     *  RelationalOperator: '<S296>/LowerRelop1'
     */
    if (rtb_Divide_p > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_e = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_e = rtb_Switch_i;
    }

    /* End of Switch: '<S296>/Switch2' */

    /* Product: '<S292>/Divide' */
    rtb_Divide_gx = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LogicalOperator3_ls_tmp_0;

    /* Switch: '<S297>/Switch' incorporates:
     *  RelationalOperator: '<S297>/UpperRelop'
     */
    if (rtb_Divide_gx < rtb_TLft) {
      rtb_Switch_k = rtb_TLft;
    } else {
      rtb_Switch_k = rtb_Divide_gx;
    }

    /* End of Switch: '<S297>/Switch' */

    /* Switch: '<S297>/Switch2' incorporates:
     *  RelationalOperator: '<S297>/LowerRelop1'
     */
    if (rtb_Divide_gx > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_j = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_j = rtb_Switch_k;
    }

    /* End of Switch: '<S297>/Switch2' */

    /* Switch: '<S290>/Switch3' incorporates:
     *  Gain: '<S290>/Gain1'
     *  RelationalOperator: '<S292>/Relational Operator2'
     */
    if (rtb_Merge1_p >= 0.0F) {
      /* Switch: '<S290>/Switch2' incorporates:
       *  Constant: '<S290>/Constant2'
       *  DataTypeConversion: '<S290>/Cast To Single'
       *  RelationalOperator: '<S291>/Relational Operator2'
       */
      if (rtb_Merge1_p > 0.0F) {
        rtb_CastToSingle3 = (uint8)((rtb_IMAPve_g_ESC_LatAcc <= rtb_Switch2_e) ?
          1 : 0);
      } else {
        rtb_CastToSingle3 = ((uint8)0U);
      }

      /* End of Switch: '<S290>/Switch2' */
    } else {
      rtb_CastToSingle3 = (uint8)((((uint32)((rtb_LKA_Veh2CamW_C <=
        rtb_Switch2_j) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S290>/Switch3' */

    /* If: '<S275>/If' incorporates:
     *  Constant: '<S279>/Constant'
     *  Constant: '<S281>/Constant'
     *  Constant: '<S282>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
         && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S275>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S281>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S275>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
      == 2)) && (((sint32)rtb_CastToSingle3) == 2)) && (((sint32)
                 rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S275>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S282>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S275>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S275>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S279>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S275>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S275>/If' */

    /* Memory: '<S325>/Memory' */
    rtb_Memory_ev = LKAS_DW.Memory_PreviousInput_d;

    /* If: '<S325>/If' incorporates:
     *  Product: '<S314>/Divide1'
     */
    if ((rtb_TTLC_m >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Gain2_0 >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S325>/Ph1SWA' incorporates:
       *  ActionPort: '<S329>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_c);

      /* End of Outputs for SubSystem: '<S325>/Ph1SWA' */
    } else if ((rtb_TTLC_m <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Gain2_0 <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S325>/Ph2SWA' incorporates:
       *  ActionPort: '<S330>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_c);

      /* End of Outputs for SubSystem: '<S325>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S325>/Ph3SWA' incorporates:
       *  ActionPort: '<S331>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_ev, &rtb_Merge1_c);

      /* End of Outputs for SubSystem: '<S325>/Ph3SWA' */
    }

    /* End of If: '<S325>/If' */

    /* Product: '<S321>/Divide2' */
    rtb_LL_LDW_LatestWarnLine_C = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S321>/Divide3' */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Abs: '<S327>/Abs' */
    rtb_TTLC_m = fabsf(rtb_TTLC_m);

    /* Product: '<S327>/Divide' */
    rtb_Divide_e = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_TTLC_m;

    /* Product: '<S321>/Divide1' */
    rtb_TTLC_m = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S333>/Switch' incorporates:
     *  RelationalOperator: '<S333>/UpperRelop'
     */
    if (rtb_Divide_e < rtb_TTLC_m) {
      rtb_Switch_a0 = rtb_TTLC_m;
    } else {
      rtb_Switch_a0 = rtb_Divide_e;
    }

    /* End of Switch: '<S333>/Switch' */

    /* Switch: '<S333>/Switch2' incorporates:
     *  RelationalOperator: '<S333>/LowerRelop1'
     */
    if (rtb_Divide_e > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_d = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_d = rtb_Switch_a0;
    }

    /* End of Switch: '<S333>/Switch2' */

    /* Product: '<S328>/Divide' incorporates:
     *  Abs: '<S328>/Abs'
     *  Product: '<S314>/Divide1'
     */
    rtb_Divide_l = rtb_LL_ThresDet_lDvtThresUprLKA * fabsf(rtb_Gain2_0);

    /* Switch: '<S334>/Switch' incorporates:
     *  RelationalOperator: '<S334>/UpperRelop'
     */
    if (rtb_Divide_l < rtb_TTLC_m) {
      rtb_Switch_c = rtb_TTLC_m;
    } else {
      rtb_Switch_c = rtb_Divide_l;
    }

    /* End of Switch: '<S334>/Switch' */

    /* Switch: '<S334>/Switch2' incorporates:
     *  RelationalOperator: '<S334>/LowerRelop1'
     */
    if (rtb_Divide_l > rtb_LL_LDW_LatestWarnLine_C) {
      rtb_Switch2_da = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      rtb_Switch2_da = rtb_Switch_c;
    }

    /* End of Switch: '<S334>/Switch2' */

    /* Switch: '<S326>/Switch3' incorporates:
     *  Gain: '<S326>/Gain1'
     *  RelationalOperator: '<S328>/Relational Operator2'
     */
    if (rtb_Merge1_c >= 0.0F) {
      /* Switch: '<S326>/Switch2' incorporates:
       *  Constant: '<S326>/Constant2'
       *  DataTypeConversion: '<S326>/Cast To Single'
       *  RelationalOperator: '<S327>/Relational Operator2'
       */
      if (rtb_Merge1_c > 0.0F) {
        rtb_IMAPve_d_SAS_Trim_State = (uint8)((rtb_LftTTLC <= rtb_Switch2_d) ? 1
          : 0);
      } else {
        rtb_IMAPve_d_SAS_Trim_State = ((uint8)0U);
      }

      /* End of Switch: '<S326>/Switch2' */
    } else {
      rtb_IMAPve_d_SAS_Trim_State = (uint8)((((uint32)
        ((rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_da) ? 1 : 0)) *
        ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S326>/Switch3' */

    /* Outputs for Enabled SubSystem: '<S326>/Sum Condition' incorporates:
     *  EnablePort: '<S332>/Enable'
     */
    if (((sint32)rtb_IMAPve_d_SAS_Trim_State) > 0) {
      if (!LKAS_DW.SumCondition_MODE) {
        /* InitializeConditions for Memory: '<S332>/Memory' */
        LKAS_DW.Memory_PreviousInput_em = 0.0F;
        LKAS_DW.SumCondition_MODE = true;
      }

      /* Sum: '<S332>/Add1' incorporates:
       *  Memory: '<S332>/Memory'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_em;

      /* Saturate: '<S332>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 5.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 5.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S332>/Saturation' */

      /* RelationalOperator: '<S332>/Relational Operator' incorporates:
       *  Constant: '<S326>/Constant'
       */
      LKAS_DW.RelationalOperator_kh = (rtb_LL_ThresDet_lDvtThresLwrLDW <= 2.0F);

      /* Update for Memory: '<S332>/Memory' */
      LKAS_DW.Memory_PreviousInput_em = rtb_LL_ThresDet_lDvtThresLwrLDW;
    } else {
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S332>/Out' */
        LKAS_DW.RelationalOperator_kh = false;
        LKAS_DW.SumCondition_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S326>/Sum Condition' */

    /* If: '<S313>/If' incorporates:
     *  Constant: '<S317>/Constant'
     *  Constant: '<S319>/Constant'
     *  DataTypeConversion: '<S326>/Cast To Single3'
     *  DataTypeConversion: '<S326>/Cast To Single4'
     *  Product: '<S326>/Divide'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && (((sint32)((uint32)(((uint32)rtb_IMAPve_d_SAS_Trim_State) *
            (LKAS_DW.RelationalOperator_kh ? 1U : 0U)))) == 0)) {
      /* Outputs for IfAction SubSystem: '<S313>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S319>/Action Port'
       */
      LKAS_DW.Merge_cf = true;

      /* End of Outputs for SubSystem: '<S313>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S313>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S317>/Action Port'
       */
      LKAS_DW.Merge_cf = false;

      /* End of Outputs for SubSystem: '<S313>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S313>/If' */

    /* Outputs for Enabled SubSystem: '<S274>/Count_5s3' incorporates:
     *  EnablePort: '<S541>/Enable'
     */
    /* RelationalOperator: '<S526>/Compare' incorporates:
     *  Constant: '<S526>/Constant'
     *  Constant: '<S559>/Constant'
     */
    if (((uint8)0U) == ((uint8)1U)) {
      if (!LKAS_DW.Count_5s3_MODE) {
        /* InitializeConditions for Memory: '<S541>/Memory' */
        LKAS_DW.Memory_PreviousInput_h = 0.0F;
        LKAS_DW.Count_5s3_MODE = true;
      }

      /* Sum: '<S541>/Add' incorporates:
       *  Memory: '<S541>/Memory'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_DW.Memory_PreviousInput_h +
        rtb_LKA_SampleTime;

      /* Saturate: '<S541>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 11.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 11.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S541>/Saturation' */

      /* RelationalOperator: '<S541>/Relational Operator' incorporates:
       *  Constant: '<S541>/Constant1'
       */
      LKAS_DW.RelationalOperator = (rtb_LL_ThresDet_lDvtThresLwrLDW >= ((float32)
        ((uint16)5U)));

      /* Update for Memory: '<S541>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = rtb_LL_ThresDet_lDvtThresLwrLDW;
    } else {
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S541>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S526>/Compare' */
    /* End of Outputs for SubSystem: '<S274>/Count_5s3' */

    /* RelationalOperator: '<S531>/Compare' incorporates:
     *  Constant: '<S531>/Constant'
     */
    rtb_Compare_ac = (rtb_IMAPve_d_Camera_Status == ((uint8)3U));

    /* Outputs for Enabled SubSystem: '<S274>/Count_5s2' */
    LKAS_Count_5s1(rtb_Compare_ac, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_k, &LKAS_DW.Count_5s2);

    /* End of Outputs for SubSystem: '<S274>/Count_5s2' */

    /* Logic: '<S274>/Logical Operator10' */
    LKAS_DW.LKA_Fault = ((LKAS_DW.RelationalOperator) ||
                         (LKAS_DW.RelationalOperator_k));

    /* Chart: '<S78>/LDW_State_Machine'
     *
     * Block description for '<S78>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* RelationalOperator: '<S530>/Compare' incorporates:
     *  Constant: '<S530>/Constant'
     */
    rtb_Compare_br = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

    /* Outputs for Enabled SubSystem: '<S274>/Count_5s1' */
    LKAS_Count_5s1(rtb_Compare_br, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_g, &LKAS_DW.Count_5s1);

    /* End of Outputs for SubSystem: '<S274>/Count_5s1' */

    /* Logic: '<S274>/Logical Operator8' */
    LKAS_DW.LKA_Fault = (((LKAS_DW.RelationalOperator) ||
                          (LKAS_DW.RelationalOperator_k)) ||
                         (LKAS_DW.RelationalOperator_g));

    /* Chart: '<S78>/LKA_State_Machine'
     *
     * Block description for '<S78>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S251>/Subsystem' incorporates:
     *  EnablePort: '<S255>/Enable'
     */
    /* Logic: '<S251>/Logical Operator3' incorporates:
     *  Abs: '<S251>/Abs4'
     *  Abs: '<S251>/Abs5'
     *  Abs: '<S251>/Abs6'
     *  Abs: '<S251>/Abs7'
     *  Constant: '<S251>/Constant'
     *  Constant: '<S251>/Constant1'
     *  Constant: '<S251>/Constant4'
     *  Constant: '<S251>/Constant5'
     *  Constant: '<S253>/Constant'
     *  Constant: '<S254>/Constant'
     *  Logic: '<S251>/Logical Operator'
     *  Logic: '<S251>/Logical Operator1'
     *  Logic: '<S251>/Logical Operator4'
     *  RelationalOperator: '<S251>/Relational Operator'
     *  RelationalOperator: '<S251>/Relational Operator1'
     *  RelationalOperator: '<S251>/Relational Operator2'
     *  RelationalOperator: '<S251>/Relational Operator3'
     *  RelationalOperator: '<S251>/Relational Operator6'
     *  RelationalOperator: '<S251>/Relational Operator7'
     *  RelationalOperator: '<S253>/Compare'
     *  RelationalOperator: '<S254>/Compare'
     *  Switch: '<S53>/Switch'
     *  Switch: '<S53>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_p) <= 0.005F) && (fabsf(rtb_L0_C1) <= 0.005F)) &&
           ((fabsf(rtb_L0_C2_j) <= 0.0001F) && (fabsf(rtb_L0_C2) <= 0.0001F))) &&
          ((rtb_L0_Q == ((uint8)3U)) && (rtb_R0_Q == ((uint8)3U)))) &&
         (rtb_IMAPve_g_ESC_VehSpd >= 50.0F)) && (x1 <= 1.0F)) {
      if (!LKAS_DW.Subsystem_MODE_h) {
        /* InitializeConditions for Memory: '<S255>/Memory' */
        LKAS_DW.Memory_PreviousInput_a4q = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_h = true;
      }

      /* Sum: '<S255>/Add1' incorporates:
       *  Memory: '<S255>/Memory'
       */
      rtb_Saturation_pd = (uint16)(1U + ((uint32)
        LKAS_DW.Memory_PreviousInput_a4q));

      /* Saturate: '<S255>/Saturation' */
      if (rtb_Saturation_pd >= ((uint16)3000U)) {
        rtb_Saturation_pd = ((uint16)3000U);
      }

      /* End of Saturate: '<S255>/Saturation' */

      /* RelationalOperator: '<S255>/Relational Operator' incorporates:
       *  Constant: '<S251>/Constant3'
       *  DataTypeConversion: '<S255>/Cast To Single1'
       *  Product: '<S251>/Divide'
       */
      LKAS_DW.RelationalOperator_l3 = (rtb_Saturation_pd >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S255>/Memory' */
      LKAS_DW.Memory_PreviousInput_a4q = rtb_Saturation_pd;
    } else {
      if (LKAS_DW.Subsystem_MODE_h) {
        /* Disable for Outport: '<S255>/Out' */
        LKAS_DW.RelationalOperator_l3 = false;
        LKAS_DW.Subsystem_MODE_h = false;
      }
    }

    /* End of Logic: '<S251>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S251>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S227>/Subsystem' incorporates:
     *  EnablePort: '<S250>/Enable'
     */
    if (LKAS_DW.RelationalOperator_l3) {
      /* Sum: '<S252>/Add2' incorporates:
       *  Constant: '<S252>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S252>/Memory3'
       */
      rtb_LL_ThresDet_lDvtThresLwrLDW = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S252>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 50.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = 50.0F;
      } else {
        if (rtb_LL_ThresDet_lDvtThresLwrLDW < 0.0F) {
          rtb_LL_ThresDet_lDvtThresLwrLDW = 0.0F;
        }
      }

      /* End of Saturate: '<S252>/Saturation' */

      /* Switch: '<S252>/Switch' incorporates:
       *  Constant: '<S250>/Constant'
       *  Product: '<S252>/Divide'
       *  Product: '<S252>/Divide1'
       *  Sum: '<S252>/Add'
       *  Sum: '<S252>/Add1'
       *  UnitDelay: '<S252>/Unit Delay'
       */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 1.0F) {
        rtb_LL_ThresDet_tiTTLCThresLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_IMAPve_g_SW_Angle - LKAS_DW.UnitDelay_DSTATE)) +
          LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_tiTTLCThresLDW = rtb_IMAPve_g_SW_Angle;
      }

      /* End of Switch: '<S252>/Switch' */

      /* Saturate: '<S250>/Saturation' */
      if (rtb_LL_ThresDet_tiTTLCThresLDW > 3.0F) {
        LKAS_DW.Saturation_m = 3.0F;
      } else if (rtb_LL_ThresDet_tiTTLCThresLDW < (-3.0F)) {
        LKAS_DW.Saturation_m = (-3.0F);
      } else {
        LKAS_DW.Saturation_m = rtb_LL_ThresDet_tiTTLCThresLDW;
      }

      /* End of Saturate: '<S250>/Saturation' */

      /* Update for UnitDelay: '<S252>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_tiTTLCThresLDW;

      /* Update for Memory: '<S252>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_ThresDet_lDvtThresLwrLDW;
    }

    /* End of Outputs for SubSystem: '<S227>/Subsystem' */

    /* Saturate: '<S229>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 0.001F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.001F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S229>/Saturation' */

    /* Gain: '<S263>/kph To mps' incorporates:
     *  Gain: '<S264>/kph To mps'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = 0.277777791F * rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S263>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S265>:1' */
    /* '<S265>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 150.0F;
    } else if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLDW = 60.0F;
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Saturate: '<S263>/Saturation3' */

    /* Product: '<S263>/Divide1' incorporates:
     *  Constant: '<S263>/Constant'
     */
    rtb_TLft = 0.09F / rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Saturate: '<S263>/Saturation1' */
    if (rtb_TLft > 0.0117F) {
      rtb_TLft = 0.0117F;
    } else {
      if (rtb_TLft < 0.00237F) {
        rtb_TLft = 0.00237F;
      }
    }

    /* End of Saturate: '<S263>/Saturation1' */

    /* Switch: '<S551>/Switch7' incorporates:
     *  Constant: '<S551>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_d != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_d;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S551>/Switch7' */

    /* MATLAB Function: '<S263>/MATLAB Function' incorporates:
     *  Gain: '<S263>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_TLft *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_m) * LKAS_DW.LKA_WhlBaseL_C_b) /
      (rtb_LL_ThresDet_tiTTLCThresLDW * rtb_LL_ThresDet_tiTTLCThresLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S264>/Saturation3' */
    if (rtb_LL_LDW_LatestWarnLine_C > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 60.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 60.0F;
      }
    }

    /* End of Saturate: '<S264>/Saturation3' */

    /* Product: '<S264>/Divide1' incorporates:
     *  Constant: '<S264>/Constant'
     */
    rtb_LL_LDW_LatestWarnLine_C = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S264>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S266>:1' */
    /* '<S266>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_LDW_LatestWarnLine_C > 0.0117F) {
      rtb_LL_LDW_LatestWarnLine_C = 0.0117F;
    } else {
      if (rtb_LL_LDW_LatestWarnLine_C < 0.00237F) {
        rtb_LL_LDW_LatestWarnLine_C = 0.00237F;
      }
    }

    /* End of Saturate: '<S264>/Saturation1' */

    /* Switch: '<S551>/Switch4' incorporates:
     *  Constant: '<S551>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_j != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_j;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S551>/Switch4' */

    /* MATLAB Function: '<S264>/MATLAB Function' */
    LKAS_DW.SWARmax = ((((((((rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_ThresDet_tiTTLCThresLDW) * rtb_LL_ThresDet_tiTTLCThresLDW) + 1.0F) *
      x10) * LKAS_DW.LKA_StrRatio_C_m) * LKAS_DW.LKA_WhlBaseL_C_b) /
                        (rtb_LL_ThresDet_tiTTLCThresLDW *
                         rtb_LL_ThresDet_tiTTLCThresLDW)) * 180.0F) / 3.14F;

    /* Gain: '<S222>/Gain' incorporates:
     *  Sum: '<S222>/Add'
     */
    rtb_phiHdAg = (rtb_L0_C1_p + rtb_L0_C1) * 0.5F;

    /* Gain: '<S224>/Gain1' incorporates:
     *  Sum: '<S224>/Add1'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = (rtb_Add_fk + rtb_Add_nk) * 0.5F;

    /* Switch: '<S226>/Switch' incorporates:
     *  Constant: '<S242>/Constant'
     *  RelationalOperator: '<S242>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_TLft = rtb_LFTTTLC;
    } else {
      rtb_TLft = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S226>/Switch' */

    /* Saturate: '<S226>/Saturation' */
    if (rtb_TLft > 2.0F) {
      rtb_TLft = 2.0F;
    } else {
      if (rtb_TLft < 0.5F) {
        rtb_TLft = 0.5F;
      }
    }

    /* End of Saturate: '<S226>/Saturation' */

    /* Product: '<S248>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * rtb_TLft;

    /* Gain: '<S246>/Gain1' incorporates:
     *  Gain: '<S247>/Gain1'
     */
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 3.0F * rtb_L0_C3_k;

    /* Sum: '<S246>/Add' incorporates:
     *  Gain: '<S246>/Gain1'
     *  Product: '<S246>/Product3'
     *  Product: '<S246>/Product4'
     *  Product: '<S246>/Z*Z'
     */
    rtb_Add_k = ((rtb_Add_fk_tmp * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C1_p) +
      (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * (rtb_LL_LDW_LatestWarnLine_C *
        rtb_LL_LDW_LatestWarnLine_C));

    /* Switch: '<S226>/Switch1' incorporates:
     *  Constant: '<S243>/Constant'
     *  RelationalOperator: '<S243>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S226>/Switch1' */

    /* Saturate: '<S226>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S226>/Saturation1' */

    /* Product: '<S249>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LKA_Veh2CamL_C_tmp *
      rtb_LL_HdAgPrvwT_C;

    /* Gain: '<S244>/Gain1' incorporates:
     *  Gain: '<S245>/Gain1'
     */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = 3.0F * rtb_L0_C3;

    /* Sum: '<S244>/Add' incorporates:
     *  Gain: '<S244>/Gain1'
     *  Product: '<S244>/Product3'
     *  Product: '<S244>/Product4'
     *  Product: '<S244>/Z*Z'
     */
    rtb_Add_py = ((rtb_Add_nk_tmp * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_L0_C1)
      + (rtb_LL_MAX_DRIVER_TORQUE_DISABL * (rtb_LL_ThresDet_lDvtThresUprLKA *
          rtb_LL_ThresDet_lDvtThresUprLKA));

    /* Gain: '<S226>/Gain1' incorporates:
     *  Sum: '<S226>/Add1'
     */
    rtb_LL_HdAgPrvwT_C = (rtb_LL_LDW_LatestWarnLine_C +
                          rtb_LL_ThresDet_lDvtThresUprLKA) * 0.5F;

    /* Switch: '<S551>/Switch8' incorporates:
     *  Constant: '<S551>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_o != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_o;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S551>/Switch8' */

    /* Product: '<S241>/Divide' */
    rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_Veh2CamL_C_tmp * x10;

    /* Product: '<S239>/Z*Z' incorporates:
     *  Product: '<S240>/Z*Z'
     */
    rtb_LL_TkOvStChk_tiTDelTime = rtb_LL_LDW_LatestWarnLine_C *
      rtb_LL_LDW_LatestWarnLine_C;

    /* Sum: '<S239>/Add' incorporates:
     *  Product: '<S239>/Product'
     *  Product: '<S239>/Product3'
     *  Product: '<S239>/Product4'
     *  Product: '<S239>/Z*Z'
     *  Product: '<S239>/Z*Z*Z'
     */
    rtb_Add_ij = (((rtb_L0_C1_p * rtb_LL_LDW_LatestWarnLine_C) + rtb_L0_C0_a) +
                  (rtb_L0_C2_j * rtb_LL_TkOvStChk_tiTDelTime)) +
      ((rtb_LL_LDW_LatestWarnLine_C * rtb_LL_TkOvStChk_tiTDelTime) * rtb_L0_C3_k);

    /* Sum: '<S240>/Add' incorporates:
     *  Product: '<S240>/Product'
     *  Product: '<S240>/Product3'
     *  Product: '<S240>/Product4'
     *  Product: '<S240>/Z*Z*Z'
     */
    rtb_Add_j = (((rtb_L0_C1 * rtb_LL_LDW_LatestWarnLine_C) + rtb_R0_C0_e) +
                 (rtb_L0_C2 * rtb_LL_TkOvStChk_tiTDelTime)) +
      ((rtb_LL_LDW_LatestWarnLine_C * rtb_LL_TkOvStChk_tiTDelTime) * rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S104>/Memory' */
        LKAS_DW.Memory_PreviousInput_ou = 0.0F;

        /* InitializeConditions for Memory: '<S141>/Memory' */
        LKAS_DW.Memory_PreviousInput_gz = ((uint16)0U);

        /* InitializeConditions for Memory: '<S87>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_k = ((uint8)0U);

        /* InitializeConditions for Memory: '<S140>/Memory' */
        LKAS_DW.Memory_PreviousInput_ox = ((uint16)0U);

        /* InitializeConditions for Memory: '<S142>/Memory' */
        LKAS_DW.Memory_PreviousInput_lk = ((uint16)0U);

        /* InitializeConditions for Memory: '<S136>/Memory' */
        LKAS_DW.Memory_PreviousInput_f = ((uint16)0U);

        /* InitializeConditions for Memory: '<S139>/Memory' */
        LKAS_DW.Memory_PreviousInput_g1 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S138>/Memory' */
        LKAS_DW.Memory_PreviousInput_ez = ((uint16)0U);

        /* InitializeConditions for Memory: '<S137>/Memory' */
        LKAS_DW.Memory_PreviousInput_l4 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S114>/Memory' */
        LKAS_DW.Memory_PreviousInput_at = 0.0F;

        /* InitializeConditions for Memory: '<S105>/Memory' */
        LKAS_DW.Memory_PreviousInput_c5 = 0.0F;

        /* InitializeConditions for Memory: '<S106>/Memory' */
        LKAS_DW.Memory_PreviousInput_a4 = 0.0F;

        /* InitializeConditions for Memory: '<S103>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_g = 0.0F;

        /* InitializeConditions for Memory: '<S197>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_h = 0.0F;

        /* InitializeConditions for Memory: '<S180>/Memory' */
        LKAS_DW.Memory_PreviousInput_cs = 0.0F;

        /* InitializeConditions for UnitDelay: '<S178>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_i = 0.0F;

        /* InitializeConditions for Memory: '<S186>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e = 0.0F;

        /* InitializeConditions for Memory: '<S192>/Memory' */
        LKAS_DW.Memory_PreviousInput_ke = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S196>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_k = 0.0F;

        /* InitializeConditions for Memory: '<S196>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_k = 0.0F;

        /* InitializeConditions for UnitDelay: '<S173>/Delay Input2'
         *
         * Block description for '<S173>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_e = 0.0F;

        /* InitializeConditions for Memory: '<S173>/Memory' */
        LKAS_DW.Memory_PreviousInput_n = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S94>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S94>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S106>/Moving Standard Deviation1' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S106>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S106>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2_d);

        /* End of SystemReset for SubSystem: '<S106>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Sum: '<S104>/Add2' incorporates:
       *  Memory: '<S104>/Memory'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_ou;

      /* Saturate: '<S104>/Saturation2' */
      if (rtb_TLft > 20.0F) {
        rtb_Saturation2 = 20.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation2 = 0.0F;
      } else {
        rtb_Saturation2 = rtb_TLft;
      }

      /* End of Saturate: '<S104>/Saturation2' */

      /* Saturate: '<S104>/Saturation' */
      if (rtb_TTLC > 0.004F) {
        rtb_TLft = 0.004F;
      } else if (rtb_TTLC < 0.0F) {
        rtb_TLft = 0.0F;
      } else {
        rtb_TLft = rtb_TTLC;
      }

      /* End of Saturate: '<S104>/Saturation' */

      /* RelationalOperator: '<S104>/Relational Operator4' incorporates:
       *  Constant: '<S104>/Constant'
       *  Constant: '<S104>/Constant1'
       *  Product: '<S104>/Divide'
       *  Sum: '<S104>/Add'
       */
      rtb_LogicalOperator3_a = (rtb_Saturation2 >=
        ((((rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F) * rtb_TLft) / 0.004F) +
         rtb_LL_LKAExPrcs_tiExitTime1));

      /* Sum: '<S141>/Add' incorporates:
       *  Constant: '<S141>/Constant'
       *  Memory: '<S141>/Memory'
       */
      rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_gz));

      /* Saturate: '<S141>/Saturation1' */
      if (rtb_Saturation_pd < ((uint16)10000U)) {
        rtb_Saturation1_m = rtb_Saturation_pd;
      } else {
        rtb_Saturation1_m = ((uint16)10000U);
      }

      /* End of Saturate: '<S141>/Saturation1' */

      /* If: '<S141>/If' incorporates:
       *  Constant: '<S141>/Constant2'
       */
      if (rtb_Saturation1_m == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S141>/if action ' incorporates:
         *  ActionPort: '<S158>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_SW_Angle, &LKAS_DW.In_h);

        /* End of Outputs for SubSystem: '<S141>/if action ' */
      }

      /* End of If: '<S141>/If' */

      /* Sum: '<S87>/Add' incorporates:
       *  Constant: '<S87>/Constant'
       *  Memory: '<S87>/Memory1'
       */
      rtb_IMAPve_d_SAS_Trim_State = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_k));

      /* Saturate: '<S87>/Saturation1' */
      if (rtb_IMAPve_d_SAS_Trim_State < ((uint8)5U)) {
        rtb_Saturation1_ln = rtb_IMAPve_d_SAS_Trim_State;
      } else {
        rtb_Saturation1_ln = ((uint8)5U);
      }

      /* End of Saturate: '<S87>/Saturation1' */

      /* Saturate: '<S113>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S113>/Saturation3' */

      /* Product: '<S113>/Divide1' incorporates:
       *  Constant: '<S113>/Constant'
       */
      rtb_TLft = 0.09F / x10;

      /* Saturate: '<S113>/Saturation1' */
      if (rtb_TLft > 0.0117F) {
        LKAS_DW.StbFacm_SY = 0.0117F;
      } else if (rtb_TLft < 0.00237F) {
        LKAS_DW.StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.StbFacm_SY = rtb_TLft;
      }

      /* End of Saturate: '<S113>/Saturation1' */

      /* Sum: '<S140>/Add' incorporates:
       *  Constant: '<S140>/Constant'
       *  Memory: '<S140>/Memory'
       */
      rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ox));

      /* Saturate: '<S140>/Saturation1' */
      if (rtb_Saturation_pd < ((uint16)10000U)) {
        rtb_Saturation1_h = rtb_Saturation_pd;
      } else {
        rtb_Saturation1_h = ((uint16)10000U);
      }

      /* End of Saturate: '<S140>/Saturation1' */

      /* If: '<S133>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S145>/Action Port'
         */
        LKAS_ifaction3(rtb_LFTTTLC, &rtb_Merge_b);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S144>/Action Port'
         */
        LKAS_ifaction3(rtb_RGTTTLC, &rtb_Merge_b);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_b);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem3' */
      }

      /* End of If: '<S133>/If' */

      /* If: '<S140>/If' incorporates:
       *  Constant: '<S140>/Constant2'
       */
      if (rtb_Saturation1_h == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S140>/if action ' incorporates:
         *  ActionPort: '<S157>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_b, &LKAS_DW.In_j);

        /* End of Outputs for SubSystem: '<S140>/if action ' */
      }

      /* End of If: '<S140>/If' */

      /* Saturate: '<S113>/Saturation2' */
      if (LKAS_DW.In_j > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_j < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_j;
      }

      /* End of Saturate: '<S113>/Saturation2' */

      /* Sum: '<S142>/Add' incorporates:
       *  Constant: '<S142>/Constant'
       *  Memory: '<S142>/Memory'
       */
      rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_lk));

      /* Saturate: '<S142>/Saturation1' */
      if (rtb_Saturation_pd < ((uint16)10000U)) {
        rtb_Saturation1_o = rtb_Saturation_pd;
      } else {
        rtb_Saturation1_o = ((uint16)10000U);
      }

      /* End of Saturate: '<S142>/Saturation1' */

      /* If: '<S142>/If' incorporates:
       *  Constant: '<S142>/Constant2'
       */
      if (rtb_Saturation1_o == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S142>/if action ' incorporates:
         *  ActionPort: '<S159>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_ESC_VehSpd, &LKAS_DW.In_an);

        /* End of Outputs for SubSystem: '<S142>/if action ' */
      }

      /* End of If: '<S142>/If' */

      /* Sum: '<S136>/Add' incorporates:
       *  Constant: '<S136>/Constant'
       *  Memory: '<S136>/Memory'
       */
      rtb_Add_js = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_f));

      /* DataTypeConversion: '<S168>/Data Type Conversion' incorporates:
       *  Constant: '<S169>/Constant'
       *  RelationalOperator: '<S169>/Compare'
       */
      rtb_IMAPve_d_SAS_Trim_State = (uint8)((rtb_Merge_a <= 0.0F) ? 1 : 0);

      /* Switch: '<S551>/Switch5' incorporates:
       *  Constant: '<S551>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_e != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_e;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S551>/Switch5' */

      /* Product: '<S168>/Divide' */
      rtb_Saturation4 = (rtb_Merge_a * rtb_LKA_Veh2CamL_C_tmp) * x10;

      /* Abs: '<S168>/Abs1' incorporates:
       *  Abs: '<S168>/Abs'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = fabsf(rtb_Saturation4);
      rtb_Abs1_k = rtb_LL_LKAExPrcs_tiExitTime1;

      /* Abs: '<S168>/Abs' */
      rtb_Abs_d = rtb_LL_LKAExPrcs_tiExitTime1;

      /* If: '<S168>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) && (((sint32)
            rtb_IMAPve_d_SAS_Trim_State) == 0)) {
        /* Outputs for IfAction SubSystem: '<S168>/If Action Subsystem' incorporates:
         *  ActionPort: '<S170>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_d, &rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S168>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) && (((sint32)
                   rtb_IMAPve_d_SAS_Trim_State) == 1)) {
        /* Outputs for IfAction SubSystem: '<S168>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S172>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_k, &rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S168>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S168>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S171>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Saturation4);

        /* End of Outputs for SubSystem: '<S168>/If Action Subsystem2' */
      }

      /* End of If: '<S168>/If' */

      /* Switch: '<S551>/Switch6' incorporates:
       *  Constant: '<S551>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_b != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_b;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S551>/Switch6' */

      /* Sum: '<S164>/Add' incorporates:
       *  Sum: '<S105>/Add3'
       *  Sum: '<S106>/Add'
       *  Sum: '<S185>/Add6'
       */
      rtb_L0_C3_k = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Sum: '<S164>/Add1' incorporates:
       *  Product: '<S164>/Divide'
       *  Product: '<S164>/Divide1'
       *  Sum: '<S164>/Add'
       */
      rtb_Add1_j4 = (((1.0F / x10) * rtb_L0_C3_k) / rtb_LKA_Veh2CamL_C_tmp) +
        rtb_Saturation4;

      /* If: '<S116>/If' incorporates:
       *  Constant: '<S167>/Constant2'
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S116>/If Action Subsystem' incorporates:
         *  ActionPort: '<S165>/Action Port'
         */
        /* Gain: '<S165>/Gain2' */
        rtb_Merge_c = (-1.0F) * rtb_Add1_j4;

        /* End of Outputs for SubSystem: '<S116>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S116>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S166>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_j4, &rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S116>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S116>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S167>/Action Port'
         */
        rtb_Merge_c = 0.0F;

        /* End of Outputs for SubSystem: '<S116>/If Action Subsystem2' */
      }

      /* End of If: '<S116>/If' */

      /* Saturate: '<S136>/Saturation1' */
      if (rtb_Add_js < ((uint16)10000U)) {
        rtb_Saturation_pd = rtb_Add_js;
      } else {
        rtb_Saturation_pd = ((uint16)10000U);
      }

      /* End of Saturate: '<S136>/Saturation1' */

      /* If: '<S136>/If' incorporates:
       *  Constant: '<S136>/Constant2'
       */
      if (rtb_Saturation_pd == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S136>/if action ' incorporates:
         *  ActionPort: '<S153>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_c, &LKAS_DW.In_jb);

        /* End of Outputs for SubSystem: '<S136>/if action ' */
      }

      /* End of If: '<S136>/If' */

      /* Sum: '<S139>/Add' incorporates:
       *  Constant: '<S139>/Constant'
       *  Memory: '<S139>/Memory'
       */
      rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_g1));

      /* Saturate: '<S139>/Saturation1' */
      if (rtb_Saturation_pd < ((uint16)10000U)) {
        rtb_Saturation1_hi = rtb_Saturation_pd;
      } else {
        rtb_Saturation1_hi = ((uint16)10000U);
      }

      /* End of Saturate: '<S139>/Saturation1' */

      /* If: '<S139>/If' incorporates:
       *  Constant: '<S139>/Constant2'
       */
      if (rtb_Saturation1_hi == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S139>/if action ' incorporates:
         *  ActionPort: '<S156>/Action Port'
         */
        LKAS_ifaction(rtb_phiHdAg, &LKAS_DW.In_g);

        /* End of Outputs for SubSystem: '<S139>/if action ' */
      }

      /* End of If: '<S139>/If' */

      /* Sum: '<S138>/Add' incorporates:
       *  Constant: '<S138>/Constant'
       *  Memory: '<S138>/Memory'
       */
      rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ez));

      /* Saturate: '<S138>/Saturation1' */
      if (rtb_Saturation_pd < ((uint16)10000U)) {
        rtb_Saturation1_ip = rtb_Saturation_pd;
      } else {
        rtb_Saturation1_ip = ((uint16)10000U);
      }

      /* End of Saturate: '<S138>/Saturation1' */

      /* If: '<S135>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S135>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S151>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_ij, &rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S135>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S135>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S150>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_j, &rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S135>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S135>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S152>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_n);

        /* End of Outputs for SubSystem: '<S135>/If Action Subsystem3' */
      }

      /* End of If: '<S135>/If' */

      /* If: '<S138>/If' incorporates:
       *  Constant: '<S138>/Constant2'
       */
      if (rtb_Saturation1_ip == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S138>/if action ' incorporates:
         *  ActionPort: '<S155>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_n, &LKAS_DW.In_i);

        /* End of Outputs for SubSystem: '<S138>/if action ' */
      }

      /* End of If: '<S138>/If' */

      /* Sum: '<S137>/Add' incorporates:
       *  Constant: '<S137>/Constant'
       *  Memory: '<S137>/Memory'
       */
      rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_l4));

      /* Saturate: '<S137>/Saturation1' */
      if (rtb_Saturation_pd < ((uint16)10000U)) {
        rtb_Saturation1_c = rtb_Saturation_pd;
      } else {
        rtb_Saturation1_c = ((uint16)10000U);
      }

      /* End of Saturate: '<S137>/Saturation1' */

      /* If: '<S134>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S134>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_k, &rtb_Merge_ag);

        /* End of Outputs for SubSystem: '<S134>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S134>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        LKAS_ifaction3(rtb_Add_py, &rtb_Merge_ag);

        /* End of Outputs for SubSystem: '<S134>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S134>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S149>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_ag);

        /* End of Outputs for SubSystem: '<S134>/If Action Subsystem3' */
      }

      /* End of If: '<S134>/If' */

      /* If: '<S137>/If' incorporates:
       *  Constant: '<S137>/Constant2'
       */
      if (rtb_Saturation1_c == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S137>/if action ' incorporates:
         *  ActionPort: '<S154>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_ag, &LKAS_DW.In_if);

        /* End of Outputs for SubSystem: '<S137>/if action ' */
      }

      /* End of If: '<S137>/If' */

      /* If: '<S143>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S143>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S161>/Action Port'
         */
        /* SignalConversion: '<S161>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S161>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S143>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S143>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S160>/Action Port'
         */
        /* SignalConversion: '<S160>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S160>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S143>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S143>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S162>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S143>/If Action Subsystem3' */
      }

      /* End of If: '<S143>/If' */

      /* If: '<S87>/If' incorporates:
       *  Constant: '<S87>/Constant19'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem;
      rtAction = -1;
      if (rtb_Saturation1_ln == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        if (0 != rtPrevAction) {
          /* SystemReset for IfAction SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
           *  ActionPort: '<S112>/Action Port'
           *
           * Block description for '<S87>/LKA Motion Planning Calculation (LKAMPCal)':
           *  Block Name: LKA Motion Planning Calculation
           *  Ab.: LKAMPCal
           *  No.: 1.2.3.2
           *  Rev: 0.0.1
           *  Update Date: 19-3-26
           */
          /* SystemReset for If: '<S87>/If' */
          LKAMotionPlanningCalculat_Reset();

          /* End of SystemReset for SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */
        }

        /* Outputs for IfAction SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S112>/Action Port'
         *
         * Block description for '<S87>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S87>/If' */

      /* Memory: '<S114>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_at;

      /* Sum: '<S114>/Add' incorporates:
       *  Gain: '<S114>/Gain1'
       *  Product: '<S114>/Divide'
       *  Product: '<S114>/Product'
       */
      rtb_Add_mb = ((rtb_LKA_Veh2CamL_C_tmp * rtb_LKA_SampleTime) /
                    (0.277777791F * LKAS_DW.In_an)) + rtb_Saturation4;

      /* MATLAB Function: '<S115>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S163>:1' */
      /* '<S163>:1:20' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S163>:1:21' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S163>:1:22' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S163>:1:23' Delte2PhSWGrad = SWACmd_dphi2PhSWAGrad; */
      /* '<S163>:1:24' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S163>:1:25' NomT = SWACmd_tiNomT; */
      /* '<S163>:1:26' T1 = (DelteSW1-DelteSW0)/Delte1PhSWGrad; */
      rtb_LL_LKAExPrcs_tiExitTime1 = (LKAS_DW.K1K2Det_phi2PhSWAIni -
        LKAS_DW.In_h) / LKAS_DW.K1K2Det_dphi1PhSWAGrad;

      /* '<S163>:1:27' T2 = (0-DelteSW1)/Delte2PhSWGrad+T1; */
      rtb_LL_DvtSpdDet_vDvtSpdMin_C = ((0.0F - LKAS_DW.K1K2Det_phi2PhSWAIni) /
        LKAS_DW.K1K2Det_dphi2PhSWAGrad1) + rtb_LL_LKAExPrcs_tiExitTime1;

      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S163>:1:35' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_mb < rtb_LL_LKAExPrcs_tiExitTime1) && (rtb_Add_mb >= 0.0F)) {
        /* '<S163>:1:36' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_mb) +
          LKAS_DW.In_h;
      } else if ((rtb_Add_mb <= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Add_mb >=
                  rtb_LL_LKAExPrcs_tiExitTime1)) {
        /* '<S163>:1:37' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S163>:1:39' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
          rtb_LL_LKAExPrcs_tiExitTime1) + LKAS_DW.In_h;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_mb >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) {
          /* '<S163>:1:41' elseif(NomT >= T2) */
          /* '<S163>:1:42' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
            rtb_LL_LKAExPrcs_tiExitTime1) + LKAS_DW.In_h;

          /*    DelteSWCmd = single(0); */
        }
      }

      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S163>:1:48' SWACmd_phiSWACmd = DelteSWCmd; */
      rtb_T2 = rtb_LL_DvtSpdDet_vDvtSpdMin_C;

      /* Saturate: '<S87>/Saturation6' incorporates:
       *  MATLAB Function: '<S115>/SWACmd'
       */
      if (rtb_LL_LKAExPrcs_tiExitTime1 > 2.0F) {
        rtb_Saturation6 = 2.0F;
      } else if (rtb_LL_LKAExPrcs_tiExitTime1 < 0.2F) {
        rtb_Saturation6 = 0.2F;
      } else {
        rtb_Saturation6 = rtb_LL_LKAExPrcs_tiExitTime1;
      }

      /* End of Saturate: '<S87>/Saturation6' */

      /* Memory: '<S105>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_c5;

      /* Sum: '<S105>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S105>/Saturation2' */
      if (rtb_Saturation4 > 12.0F) {
        rtb_Saturation2_b = 12.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation2_b = 0.0F;
      } else {
        rtb_Saturation2_b = rtb_Saturation4;
      }

      /* End of Saturate: '<S105>/Saturation2' */

      /* Abs: '<S105>/Abs2' */
      rtb_Saturation4 = fabsf(rtb_Gain1);

      /* Gain: '<S105>/Gain' */
      rtb_LL_LKAExPrcs_tiExitTime1 = rtb_L0_C3_k * 0.166666672F;

      /* RelationalOperator: '<S105>/Relational Operator2' */
      rtb_Compare_gz = (rtb_Saturation4 >= rtb_LL_LKAExPrcs_tiExitTime1);

      /* Abs: '<S105>/Abs3' */
      rtb_Saturation4 = fabsf(rtb_Add5_n);

      /* Outputs for Enabled SubSystem: '<S105>/Sum Condition1' incorporates:
       *  EnablePort: '<S107>/Enable'
       */
      /* Logic: '<S105>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S105>/Relational Operator3'
       *  RelationalOperator: '<S105>/Relational Operator4'
       */
      if (((rtb_Saturation2_b >= rtb_Saturation6) && rtb_Compare_gz) &&
          (rtb_Saturation4 >= rtb_LL_LKAExPrcs_tiExitTime1)) {
        if (!LKAS_DW.SumCondition1_MODE_h) {
          /* InitializeConditions for Memory: '<S107>/Memory' */
          LKAS_DW.Memory_PreviousInput_en = 0.0F;
          LKAS_DW.SumCondition1_MODE_h = true;
        }

        /* Sum: '<S107>/Add1' incorporates:
         *  Memory: '<S107>/Memory'
         */
        rtb_LL_LKAExPrcs_tiExitTime1 = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_en;

        /* Saturate: '<S107>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime1 > 10.0F) {
          rtb_LL_LKAExPrcs_tiExitTime1 = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime1 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime1 = 0.0F;
          }
        }

        /* End of Saturate: '<S107>/Saturation' */

        /* Saturate: '<S105>/Saturation' */
        if (rtb_TTLC > 0.004F) {
          rtb_TLft = 0.004F;
        } else if (rtb_TTLC < 0.0F) {
          rtb_TLft = 0.0F;
        } else {
          rtb_TLft = rtb_TTLC;
        }

        /* End of Saturate: '<S105>/Saturation' */

        /* RelationalOperator: '<S107>/Relational Operator' incorporates:
         *  Constant: '<S105>/Constant'
         *  Constant: '<S105>/Constant1'
         *  Product: '<S105>/Divide'
         *  Sum: '<S105>/Add1'
         */
        LKAS_DW.RelationalOperator_c5 = (rtb_LL_LKAExPrcs_tiExitTime1 >=
          ((((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) * rtb_TLft) / 0.004F) +
           rtb_LL_LKAExPrcs_tiExitTime2));

        /* Update for Memory: '<S107>/Memory' */
        LKAS_DW.Memory_PreviousInput_en = rtb_LL_LKAExPrcs_tiExitTime1;
      } else {
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S107>/Out' */
          LKAS_DW.RelationalOperator_c5 = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }
      }

      /* End of Logic: '<S105>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S105>/Sum Condition1' */

      /* Memory: '<S106>/Memory' */
      rtb_Saturation4 = LKAS_DW.Memory_PreviousInput_a4;

      /* Sum: '<S106>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S106>/Saturation2' */
      if (rtb_Saturation4 > 10.0F) {
        rtb_Saturation2_c = 10.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation2_c = 0.0F;
      } else {
        rtb_Saturation2_c = rtb_Saturation4;
      }

      /* End of Saturate: '<S106>/Saturation2' */

      /* Gain: '<S106>/Gain' */
      rtb_Saturation4 = rtb_L0_C3_k * 0.333333343F;

      /* RelationalOperator: '<S106>/Relational Operator2' */
      rtb_Compare_gz = (rtb_Gain1 >= rtb_Saturation4);

      /* RelationalOperator: '<S106>/Relational Operator3' */
      rtb_Compare_mc = (rtb_Add5_n >= rtb_Saturation4);

      /* Abs: '<S106>/Abs4' */
      rtb_Saturation4 = rtb_TTLC;

      /* Saturate: '<S106>/Saturation' */
      if (rtb_Saturation4 > 0.004F) {
        rtb_Saturation4 = 0.004F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S106>/Saturation' */

      /* Switch: '<S551>/Switch45' incorporates:
       *  Constant: '<S551>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S551>/Switch45' */

      /* Sum: '<S106>/Add6' incorporates:
       *  Constant: '<S106>/Constant'
       *  Constant: '<S106>/Constant7'
       *  Product: '<S106>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Saturation4) / 0.004F) + x10;

      /* Outputs for Enabled SubSystem: '<S85>/Subsystem' incorporates:
       *  EnablePort: '<S93>/Enable'
       */
      /* RelationalOperator: '<S92>/Compare' incorporates:
       *  Constant: '<S92>/Constant'
       */
      if (rtb_LL_LKASWASyn_TrqSwaAddSwt > 0.0F) {
        if (!LKAS_DW.Subsystem_MODE_j) {
          LKAS_DW.Subsystem_MODE_j = true;
        }

        /* MATLAB Function: '<S93>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S95>:1' */
        /* '<S95>:1:2' Swaadd=single(0); */
        /* '<S95>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S95>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S95>:1:5' l0c0=abs(l0c0); */
        /* '<S95>:1:6' r0c0=abs(r0c0); */
        /* '<S95>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_LL_LKAExPrcs_tiExitTime1 = fmaxf(fminf(rtb_Add5_n_tmp + rtb_TTLC_l,
          5.4F), 2.5F);

        /* '<S95>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_LL_LKAExPrcs_tiExitTime1 > 2.5F) &&
            (rtb_LL_LKAExPrcs_tiExitTime1 < 5.4F)) {
          /* '<S95>:1:9' leftlane=l0c0/lanewidth; */
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_Add5_n_tmp /
            rtb_LL_LKAExPrcs_tiExitTime1;

          /* '<S95>:1:10' rightlane=r0c0/lanewidth; */
          rtb_LL_LKAExPrcs_tiExitTime2 = rtb_TTLC_l /
            rtb_LL_LKAExPrcs_tiExitTime1;
        } else {
          /* '<S95>:1:11' else */
          /* '<S95>:1:12' leftlane=single(0.5); */
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = 0.5F;

          /* '<S95>:1:13' rightlane=single(0.5); */
          rtb_LL_LKAExPrcs_tiExitTime2 = 0.5F;
        }

        /* '<S95>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S95>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S95>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S551>/Switch42' incorporates:
           *  Constant: '<S551>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S95>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S551>/Switch43' incorporates:
           *  Constant: '<S551>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKAExPrcs_tiExitTime2 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_LL_DvtSpdDet_vDvtSpdMin_C) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S551>/Switch42' incorporates:
           *  Constant: '<S551>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S95>:1:19' else */
          /* '<S95>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S551>/Switch43' incorporates:
           *  Constant: '<S551>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKAExPrcs_tiExitTime2 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_LL_LKAExPrcs_tiExitTime2) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S96>/Add2' incorporates:
         *  Constant: '<S96>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S96>/Memory3'
         */
        rtb_LL_LKAExPrcs_tiExitTime1 = 1.0F + LKAS_DW.Memory3_PreviousInput_bx;

        /* Saturate: '<S96>/Saturation' */
        if (rtb_LL_LKAExPrcs_tiExitTime1 > 50.0F) {
          rtb_LL_LKAExPrcs_tiExitTime1 = 50.0F;
        } else {
          if (rtb_LL_LKAExPrcs_tiExitTime1 < 0.0F) {
            rtb_LL_LKAExPrcs_tiExitTime1 = 0.0F;
          }
        }

        /* End of Saturate: '<S96>/Saturation' */

        /* Switch: '<S96>/Switch' incorporates:
         *  Product: '<S96>/Divide'
         *  Product: '<S96>/Divide1'
         *  Sum: '<S96>/Add'
         *  Sum: '<S96>/Add1'
         *  UnitDelay: '<S96>/Unit Delay'
         */
        if (rtb_LL_LKAExPrcs_tiExitTime1 > 1.0F) {
          /* Switch: '<S551>/Switch50' incorporates:
           *  Constant: '<S551>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S551>/Switch50' */
          rtb_LL_LKAExPrcs_tiExitTime2 = ((rtb_LKA_SampleTime / x10) *
            (rtb_LL_LKAExPrcs_tiExitTime2 - LKAS_DW.UnitDelay_DSTATE_o)) +
            LKAS_DW.UnitDelay_DSTATE_o;
        }

        /* End of Switch: '<S96>/Switch' */

        /* SampleTimeMath: '<S99>/TSamp'
         *
         * About '<S99>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_LL_LKAExPrcs_tiExitTime2 * 100.0F;

        /* Sum: '<S97>/Add2' incorporates:
         *  Constant: '<S97>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S97>/Memory3'
         */
        rtb_LL_LDW_LatestWarnLine_C = 1.0F + LKAS_DW.Memory3_PreviousInput_c;

        /* Saturate: '<S97>/Saturation' */
        if (rtb_LL_LDW_LatestWarnLine_C > 50.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 50.0F;
        } else {
          if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
            rtb_LL_LDW_LatestWarnLine_C = 0.0F;
          }
        }

        /* End of Saturate: '<S97>/Saturation' */

        /* Switch: '<S97>/Switch' incorporates:
         *  Product: '<S97>/Divide'
         *  Product: '<S97>/Divide1'
         *  Sum: '<S97>/Add'
         *  Sum: '<S97>/Add1'
         *  Sum: '<S99>/Diff'
         *  UnitDelay: '<S97>/Unit Delay'
         *  UnitDelay: '<S99>/UD'
         *
         * Block description for '<S99>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S99>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_LL_LDW_LatestWarnLine_C > 2.0F) {
          /* Switch: '<S551>/Switch52' incorporates:
           *  Constant: '<S551>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S551>/Switch52' */
          rtb_LL_TkOvStChk_tiTDelTime = (((rtb_LL_DvtSpdDet_vDvtSpdMin_C -
            LKAS_DW.UD_DSTATE) - LKAS_DW.UnitDelay_DSTATE_p) *
            (rtb_LKA_SampleTime / x10)) + LKAS_DW.UnitDelay_DSTATE_p;
        } else {
          rtb_LL_TkOvStChk_tiTDelTime = rtb_LL_DvtSpdDet_vDvtSpdMin_C -
            LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S97>/Switch' */

        /* Saturate: '<S93>/Saturation' */
        if (rtb_LL_TkOvStChk_tiTDelTime > 30.0F) {
          rtb_L0_C3 = 30.0F;
        } else if (rtb_LL_TkOvStChk_tiTDelTime < (-30.0F)) {
          rtb_L0_C3 = (-30.0F);
        } else {
          rtb_L0_C3 = rtb_LL_TkOvStChk_tiTDelTime;
        }

        /* End of Saturate: '<S93>/Saturation' */

        /* Switch: '<S551>/Switch53' incorporates:
         *  Constant: '<S551>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S551>/Switch53' */

        /* Sum: '<S98>/Difference Inputs1' incorporates:
         *  Product: '<S93>/Divide1'
         *  Product: '<S93>/Divide3'
         *  Sum: '<S93>/Add'
         *  UnitDelay: '<S98>/Delay Input2'
         *
         * Block description for '<S98>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S98>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_LKASWASyn_TrqSwaAddSwt = (((rtb_LL_LKASWASyn_TrqSwaAddSwt *
          rtb_L0_C3) * x10) + (rtb_LL_LKASWASyn_TrqSwaAddSwt *
          rtb_LL_LKAExPrcs_tiExitTime2)) - LKAS_DW.DelayInput2_DSTATE_k;

        /* Product: '<S98>/delta rise limit' incorporates:
         *  Constant: '<S93>/Constant1'
         *  SampleTimeMath: '<S98>/sample time'
         *
         * About '<S98>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_L0_C3 = 5.0F * 0.01F;

        /* Product: '<S98>/delta fall limit' incorporates:
         *  Constant: '<S93>/Constant2'
         *  SampleTimeMath: '<S98>/sample time'
         *
         * About '<S98>/sample time':
         *  y = K where K = ( w * Ts )
         */
        x10 = (-5.0F) * 0.01F;

        /* Switch: '<S100>/Switch2' incorporates:
         *  Product: '<S98>/delta fall limit'
         *  Product: '<S98>/delta rise limit'
         *  RelationalOperator: '<S100>/LowerRelop1'
         *  RelationalOperator: '<S100>/UpperRelop'
         *  Switch: '<S100>/Switch'
         */
        if (rtb_LL_LKASWASyn_TrqSwaAddSwt > rtb_L0_C3) {
          rtb_LL_LKASWASyn_TrqSwaAddSwt = rtb_L0_C3;
        } else {
          if (rtb_LL_LKASWASyn_TrqSwaAddSwt < x10) {
            /* Switch: '<S100>/Switch' incorporates:
             *  Product: '<S98>/delta fall limit'
             */
            rtb_LL_LKASWASyn_TrqSwaAddSwt = x10;
          }
        }

        /* End of Switch: '<S100>/Switch2' */

        /* Sum: '<S98>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S98>/Delay Input2'
         *
         * Block description for '<S98>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S98>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_b = rtb_LL_LKASWASyn_TrqSwaAddSwt +
          LKAS_DW.DelayInput2_DSTATE_k;

        /* Update for UnitDelay: '<S96>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_o = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for Memory: '<S96>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_bx = rtb_LL_LKAExPrcs_tiExitTime1;

        /* Update for UnitDelay: '<S99>/UD'
         *
         * Block description for '<S99>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_LL_DvtSpdDet_vDvtSpdMin_C;

        /* Update for UnitDelay: '<S97>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_p = rtb_LL_TkOvStChk_tiTDelTime;

        /* Update for Memory: '<S97>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_c = rtb_LL_LDW_LatestWarnLine_C;

        /* Update for UnitDelay: '<S98>/Delay Input2'
         *
         * Block description for '<S98>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_k = LKAS_DW.DifferenceInputs2_b;
      } else {
        if (LKAS_DW.Subsystem_MODE_j) {
          /* Disable for Outport: '<S93>/Out1' */
          LKAS_DW.DifferenceInputs2_b = 0.0F;
          LKAS_DW.Subsystem_MODE_j = false;
        }
      }

      /* End of RelationalOperator: '<S92>/Compare' */
      /* End of Outputs for SubSystem: '<S85>/Subsystem' */

      /* Outputs for Atomic SubSystem: '<S94>/Moving Standard Deviation2' */
      rtb_Yk1_i = (float32) LKAS_MovingStandardDeviation2
        (rtb_IMAPve_g_EPS_SW_Trq, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S94>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S106>/Moving Standard Deviation1' */
      rtb_Gain_ji = (float32) LKAS_MovingStandardDeviation2(rtb_Add5_n,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S106>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S106>/Relational Operator6' */
      rtb_RelationalOperator6_b = (rtb_Gain_ji <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S106>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_b, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_lz, &LKAS_DW.SumCondition1_c);

      /* End of Outputs for SubSystem: '<S106>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S106>/Moving Standard Deviation2' */
      rtb_Gain_ji = (float32) LKAS_MovingStandardDeviation2(rtb_Gain1,
        &LKAS_DW.MovingStandardDeviation2_d);

      /* End of Outputs for SubSystem: '<S106>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S106>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain_ji <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S106>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_p, &LKAS_DW.SumCondition_j);

      /* End of Outputs for SubSystem: '<S106>/Sum Condition' */

      /* Switch: '<S551>/Switch46' incorporates:
       *  Constant: '<S551>/LL_LKAExPrcs_ExitC0Swt=1'
       */
      if (LKAS_ConstB.DataTypeConversion35) {
        i = LKAS_ConstB.DataTypeConversion35 ? 1 : 0;
      } else {
        i = LL_LKAExPrcs_ExitC0Swt ? 1 : 0;
      }

      /* End of Switch: '<S551>/Switch46' */

      /* Logic: '<S106>/Logical Operator2' incorporates:
       *  Logic: '<S106>/Logical Operator1'
       *  RelationalOperator: '<S106>/Relational Operator4'
       */
      rtb_Compare_gz = ((((((rtb_Saturation2_c >= rtb_Saturation6) &&
                            rtb_Compare_gz) && rtb_Compare_mc) &&
                          (LKAS_DW.RelationalOperator_lz)) &&
                         (LKAS_DW.RelationalOperator_p)) && (i != 0));

      /* Fcn: '<S86>/Fcn' incorporates:
       *  DataTypeConversion: '<S86>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((rtb_Compare_gz ? 1 : 0) *
        (rtb_Compare_gz ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!rtb_Compare_gz) ? 1 : 0)) * (LKAS_DW.RelationalOperator_c5 ? 1 : 0)) *
        ((sint32)2.0F))) + (((sint32)(((!LKAS_DW.RelationalOperator_c5) &&
        (!rtb_Compare_gz)) ? 1 : 0)) * (rtb_LogicalOperator3_a ? 1 : 0))));

      /* Logic: '<S86>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_LogicalOperator3_a ||
        (LKAS_DW.RelationalOperator_c5)) || rtb_Compare_gz);

      /* DataTypeConversion: '<S89>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon_a = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Switch: '<S551>/Switch18' incorporates:
       *  Constant: '<S551>/LL_LKASWASyn_M3K=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion25;
      } else {
        x10 = LL_LKASWASyn_M3K;
      }

      /* End of Switch: '<S551>/Switch18' */

      /* Product: '<S94>/Divide' */
      rtb_Saturation4 = rtb_Yk1_i * x10;

      /* Saturate: '<S94>/Saturation1' */
      if (rtb_Saturation4 > 0.2F) {
        rtb_Saturation4 = 0.2F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S94>/Saturation1' */

      /* Sum: '<S103>/Add2' incorporates:
       *  Memory: '<S103>/Memory3'
       */
      rtb_TLft = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_g;

      /* Saturate: '<S103>/Saturation' */
      if (rtb_TLft > 50.0F) {
        rtb_Saturation_go = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation_go = 0.0F;
      } else {
        rtb_Saturation_go = rtb_TLft;
      }

      /* End of Saturate: '<S103>/Saturation' */

      /* MATLAB Function: '<S94>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem1/MATLAB Function': '<S101>:1' */
      /* '<S101>:1:2' if T<T1 */
      if (rtb_Saturation_go < rtb_Saturation6) {
        /* '<S101>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_R0_C1 += ((rtb_LL_LKASWASyn_M1 - rtb_R0_C1) / rtb_Saturation6) *
          rtb_Saturation_go;
      } else if ((rtb_Saturation_go >= rtb_Saturation6) && (rtb_Saturation_go <=
                  (rtb_Saturation6 + rtb_LL_LKASWASyn_T2))) {
        /* Switch: '<S551>/Switch14' incorporates:
         *  Constant: '<S551>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S101>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S101>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_n != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_n;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_R0_C1 = (((x10 - rtb_LL_LKASWASyn_M1) / rtb_LL_LKASWASyn_T2) *
                     (rtb_Saturation_go - rtb_Saturation6)) +
          rtb_LL_LKASWASyn_M1;
      } else {
        /* Switch: '<S551>/Switch14' incorporates:
         *  Constant: '<S551>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S101>:1:6' else */
        /* '<S101>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_n != 0.0F) {
          rtb_R0_C1 = LKAS_ConstB.DataTypeConversion20_n;
        } else {
          rtb_R0_C1 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S94>/MATLAB Function' */

      /* Sum: '<S94>/Add1' */
      rtb_Saturation4 = rtb_R0_C1 - rtb_Saturation4;

      /* Saturate: '<S94>/Saturation2' */
      if (rtb_Saturation4 > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Saturation4 < 0.01F) {
        LKAS_DW.Saturation2 = 0.01F;
      } else {
        LKAS_DW.Saturation2 = rtb_Saturation4;
      }

      /* End of Saturate: '<S94>/Saturation2' */

      /* Memory: '<S197>/Memory3' */
      rtb_Saturation4 = LKAS_DW.Memory3_PreviousInput_h;

      /* Sum: '<S197>/Add2' */
      rtb_Saturation4 += rtb_LKA_SampleTime;

      /* Saturate: '<S197>/Saturation' */
      if (rtb_Saturation4 > 50.0F) {
        rtb_Saturation_j = 50.0F;
      } else if (rtb_Saturation4 < 0.0F) {
        rtb_Saturation_j = 0.0F;
      } else {
        rtb_Saturation_j = rtb_Saturation4;
      }

      /* End of Saturate: '<S197>/Saturation' */

      /* If: '<S195>/If' incorporates:
       *  DataTypeConversion: '<S76>/Cast To Single'
       *  Inport: '<S203>/Plan'
       *  Inport: '<S203>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_j;
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_j = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S195>/If Action Subsystem' incorporates:
           *  ActionPort: '<S201>/Action Port'
           */
          /* InitializeConditions for If: '<S195>/If' incorporates:
           *  Memory: '<S201>/Memory'
           *  UnitDelay: '<S205>/Delay Input1'
           *
           * Block description for '<S205>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_n = false;
          LKAS_DW.Memory_PreviousInput_og = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S195>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S195>/If Action Subsystem' incorporates:
         *  ActionPort: '<S201>/Action Port'
         */
        /* RelationalOperator: '<S204>/Compare' incorporates:
         *  Constant: '<S204>/Constant'
         */
        rtb_LogicalOperator3_a = (rtb_L0_C1_p >= 0.0F);

        /* Memory: '<S201>/Memory' */
        rtb_Plan_b = LKAS_DW.Memory_PreviousInput_og;

        /* Sum: '<S201>/Add' incorporates:
         *  Logic: '<S201>/Logical Operator'
         *  RelationalOperator: '<S201>/Relational Operator'
         *  RelationalOperator: '<S205>/FixPt Relational Operator'
         *  UnitDelay: '<S205>/Delay Input1'
         *
         * Block description for '<S205>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_g = ((float32)(((((sint32)(rtb_LogicalOperator3_a ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_n ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_j)) ? 1 : 0)) + rtb_Plan_b;

        /* Saturate: '<S201>/Saturation' */
        if (rtb_T1_g > 5.0F) {
          rtb_Saturation_m = 5.0F;
        } else if (rtb_T1_g < 0.0F) {
          rtb_Saturation_m = 0.0F;
        } else {
          rtb_Saturation_m = rtb_T1_g;
        }

        /* End of Saturate: '<S201>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S201>/If Action Subsystem' */
        LKAS_IfActionSubsystem_g(rtb_Saturation_m, rtb_Saturation_j,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_b, &LKAS_DW.In_a,
          &LKAS_DW.IfActionSubsystem_gs);

        /* End of Outputs for SubSystem: '<S201>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S201>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_c(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_g, &rtb_Plan_b);

        /* End of Outputs for SubSystem: '<S201>/If Action Subsystem2' */

        /* Switch: '<S201>/Switch' incorporates:
         *  Switch: '<S201>/Switch1'
         */
        if (rtb_Saturation_m > 0.0F) {
          LKAS_DW.Merge_a = LKAS_DW.In_b;
          LKAS_DW.Merge1 = LKAS_DW.In_a;
        } else {
          LKAS_DW.Merge_a = rtb_T1_g;
          LKAS_DW.Merge1 = rtb_Plan_b;
        }

        /* End of Switch: '<S201>/Switch' */

        /* Update for UnitDelay: '<S205>/Delay Input1'
         *
         * Block description for '<S205>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_n = rtb_LogicalOperator3_a;

        /* Update for Memory: '<S201>/Memory' */
        LKAS_DW.Memory_PreviousInput_og = rtb_Saturation_m;

        /* End of Outputs for SubSystem: '<S195>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S195>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S202>/Action Port'
           */
          /* InitializeConditions for If: '<S195>/If' incorporates:
           *  Memory: '<S202>/Memory'
           *  UnitDelay: '<S213>/Delay Input1'
           *
           * Block description for '<S213>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_j = false;
          LKAS_DW.Memory_PreviousInput_p2 = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S195>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S195>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S202>/Action Port'
         */
        /* RelationalOperator: '<S212>/Compare' incorporates:
         *  Constant: '<S212>/Constant'
         */
        rtb_LogicalOperator3_a = (rtb_L0_C1 <= 0.0F);

        /* Memory: '<S202>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_p2;

        /* Sum: '<S202>/Add' incorporates:
         *  Logic: '<S202>/Logical Operator'
         *  RelationalOperator: '<S202>/Relational Operator'
         *  RelationalOperator: '<S213>/FixPt Relational Operator'
         *  UnitDelay: '<S213>/Delay Input1'
         *
         * Block description for '<S213>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_i = ((float32)(((((sint32)(rtb_LogicalOperator3_a ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_j ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_j)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S202>/Saturation' */
        if (rtb_T1_i > 5.0F) {
          rtb_Saturation_h = 5.0F;
        } else if (rtb_T1_i < 0.0F) {
          rtb_Saturation_h = 0.0F;
        } else {
          rtb_Saturation_h = rtb_T1_i;
        }

        /* End of Saturate: '<S202>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S202>/If Action Subsystem' */
        LKAS_IfActionSubsystem_g(rtb_Saturation_h, rtb_Saturation_j,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_k, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_fc);

        /* End of Outputs for SubSystem: '<S202>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S202>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_c(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_i, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S202>/If Action Subsystem2' */

        /* Switch: '<S202>/Switch' incorporates:
         *  Switch: '<S202>/Switch1'
         */
        if (rtb_Saturation_h > 0.0F) {
          LKAS_DW.Merge_a = LKAS_DW.In_k;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_a = rtb_T1_i;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S202>/Switch' */

        /* Update for UnitDelay: '<S213>/Delay Input1'
         *
         * Block description for '<S213>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_j = rtb_LogicalOperator3_a;

        /* Update for Memory: '<S202>/Memory' */
        LKAS_DW.Memory_PreviousInput_p2 = rtb_Saturation_h;

        /* End of Outputs for SubSystem: '<S195>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S195>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S203>/Action Port'
         */
        LKAS_DW.Merge_a = rtb_Saturation6;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S195>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S195>/If' */

      /* Product: '<S91>/Divide3' */
      rtb_Saturation4 = rtb_Saturation_j / LKAS_DW.Merge_a;

      /* Saturate: '<S91>/Saturation' */
      if (rtb_Saturation4 > 1.0F) {
        rtb_Saturation4 = 1.0F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S91>/Saturation' */

      /* Product: '<S91>/Divide6' */
      rtb_R0_C1 = LKAS_DW.DifferenceInputs2_b * rtb_Saturation4;

      /* Saturate: '<S91>/Saturation6' */
      if (LKAS_DW.Merge_a > 0.5F) {
        rtb_Saturation4 = 0.5F;
      } else if (LKAS_DW.Merge_a < 0.2F) {
        rtb_Saturation4 = 0.2F;
      } else {
        rtb_Saturation4 = LKAS_DW.Merge_a;
      }

      /* End of Saturate: '<S91>/Saturation6' */

      /* Product: '<S91>/Divide' incorporates:
       *  Product: '<S198>/Divide'
       *  Product: '<S91>/Divide4'
       *  Sum: '<S91>/Add2'
       */
      rtb_Add5_n_tmp = (rtb_Saturation_j - LKAS_DW.Merge_a) / rtb_Saturation4;

      /* Saturate: '<S91>/Saturation2' incorporates:
       *  Product: '<S91>/Divide'
       */
      if (rtb_Add5_n_tmp > 1.0F) {
        rtb_LL_LKAExPrcs_tiExitTime1 = 1.0F;
      } else if (rtb_Add5_n_tmp < 0.0F) {
        rtb_LL_LKAExPrcs_tiExitTime1 = 0.0F;
      } else {
        rtb_LL_LKAExPrcs_tiExitTime1 = rtb_Add5_n_tmp;
      }

      /* End of Saturate: '<S91>/Saturation2' */

      /* Sum: '<S91>/Add5' incorporates:
       *  Constant: '<S91>/Constant2'
       */
      rtb_LL_LKASWASyn_M1 = 1.0F - rtb_LL_LKAExPrcs_tiExitTime1;

      /* Product: '<S247>/Z*Z' incorporates:
       *  Product: '<S245>/Z*Z'
       */
      rtb_LL_LKASWASyn_T2 = rtb_LL_HdAgPrvwT_C * rtb_LL_HdAgPrvwT_C;

      /* Sum: '<S180>/Add1' incorporates:
       *  Gain: '<S226>/Gain2'
       *  Memory: '<S180>/Memory'
       *  Product: '<S180>/Divide'
       *  Product: '<S180>/Divide1'
       *  Product: '<S245>/Product3'
       *  Product: '<S245>/Product4'
       *  Product: '<S247>/Product3'
       *  Product: '<S247>/Product4'
       *  Product: '<S247>/Z*Z'
       *  Sum: '<S226>/Add2'
       *  Sum: '<S245>/Add'
       *  Sum: '<S247>/Add'
       */
      rtb_Add1_o = ((((((rtb_Add_fk_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_p) +
                       (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ * rtb_LL_LKASWASyn_T2))
                      + (((rtb_Add_nk_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1) +
                         (rtb_LL_MAX_DRIVER_TORQUE_DISABL * rtb_LL_LKASWASyn_T2)))
                     * 0.5F) * LKAS_ConstB.Divide2_f) + (LKAS_ConstB.Add2_l *
        LKAS_DW.Memory_PreviousInput_cs);

      /* Gain: '<S178>/kph to mps' */
      rtb_kphtomps_k = rtb_LKA_Veh2CamL_C_tmp;

      /* MATLAB Function: '<S178>/Saturable Gain Lut (SatGainLut)' */
      LKAS_SaturableGainLutSatGainLut(rtb_IMAPve_g_ESC_VehSpd,
        rtb_LL_LFClb_TFC_KpVehSpdLwr_C, rtb_LL_LFClb_TFC_KpVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KpV1_C, rtb_LL_LFClb_TFC_KpV2_C, &rtb_Gain_ji);

      /* Switch: '<S551>/Switch32' incorporates:
       *  Constant: '<S551>/LL_LFClb_TFC_PrvwT_C=2'
       */
      if (LKAS_ConstB.DataTypeConversion15_p != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_p;
      } else {
        x10 = LL_LFClb_TFC_PrvwT_C;
      }

      /* End of Switch: '<S551>/Switch32' */

      /* Product: '<S178>/Divide1' */
      rtb_TLft = x10 * rtb_kphtomps_k;

      /* Switch: '<S551>/Switch30' incorporates:
       *  Constant: '<S551>/LL_LFClb_TFC_KpKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_j != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_j;
      } else {
        x10 = LL_LFClb_TFC_KpKlat_C;
      }

      /* End of Switch: '<S551>/Switch30' */

      /* Saturate: '<S178>/Saturation' */
      if (rtb_TLft > 40.0F) {
        rtb_TLft = 40.0F;
      } else {
        if (rtb_TLft < 5.0F) {
          rtb_TLft = 5.0F;
        }
      }

      /* End of Saturate: '<S178>/Saturation' */

      /* Sum: '<S178>/Subtract2' incorporates:
       *  Gain: '<S224>/Gain1'
       *  Product: '<S178>/Divide3'
       *  Sum: '<S178>/Add1'
       */
      rtb_LL_HdAgPrvwT_C = rtb_Add1_o - (rtb_LL_HdAgPrvwT_C *
        rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Product: '<S178>/Product4' incorporates:
       *  Gain: '<S225>/Gain1'
       *  Product: '<S178>/Divide'
       *  Product: '<S178>/Product1'
       *  Sum: '<S178>/Subtract1'
       *  Sum: '<S178>/Subtract2'
       *  Sum: '<S225>/Add1'
       */
      rtb_LL_LKASWASyn_T2 = (((((rtb_Add_ij + rtb_Add_j) * 0.5F) / rtb_TLft) *
        x10) - rtb_LL_HdAgPrvwT_C) * rtb_Gain_ji;

      /* Switch: '<S551>/Switch19' incorporates:
       *  Constant: '<S551>/LL_LFClb_TFC_Kp_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion26_e != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion26_e;
      } else {
        x10 = LL_LFClb_TFC_Kp_C;
      }

      /* End of Switch: '<S551>/Switch19' */

      /* Product: '<S178>/Product2' */
      rtb_TLft = rtb_LL_LKASWASyn_T2 * x10;

      /* Abs: '<S178>/Abs' incorporates:
       *  Gain: '<S224>/Gain1'
       */
      rtb_Yk1_i = fabsf(rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Saturate: '<S178>/Saturation1' */
      rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_Yk1_i;
      if (rtb_LL_LKAExPrcs_ExitC0Dvt > 0.004F) {
        rtb_Yk1_i = 0.004F;
      } else if (rtb_LL_LKAExPrcs_ExitC0Dvt < 1.0E-5F) {
        rtb_Yk1_i = 1.0E-5F;
      } else {
        rtb_Yk1_i = rtb_LL_LKAExPrcs_ExitC0Dvt;
      }

      /* End of Saturate: '<S178>/Saturation1' */

      /* Switch: '<S551>/Switch39' incorporates:
       *  Constant: '<S551>/LL_LFClb_TFC_KiMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_KiMaxSWA_C;
      }

      /* End of Switch: '<S551>/Switch39' */

      /* Sum: '<S178>/Add3' incorporates:
       *  Constant: '<S178>/Constant3'
       *  Constant: '<S178>/Constant4'
       *  Product: '<S178>/Divide4'
       *  Sum: '<S178>/Add5'
       */
      rtb_Yk1_i = (((x10 - 1.0F) * rtb_Yk1_i) / 0.004F) + 1.0F;

      /* Sum: '<S186>/Add2' incorporates:
       *  Memory: '<S186>/Memory3'
       */
      rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LKA_SampleTime +
        LKAS_DW.Memory3_PreviousInput_e;

      /* Saturate: '<S186>/Saturation' */
      if (rtb_LL_LKAExPrcs_ExitC0Dvt > 50.0F) {
        rtb_Saturation_gq = 50.0F;
      } else if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
        rtb_Saturation_gq = 0.0F;
      } else {
        rtb_Saturation_gq = rtb_LL_LKAExPrcs_ExitC0Dvt;
      }

      /* End of Saturate: '<S186>/Saturation' */

      /* Switch: '<S178>/Switch2' incorporates:
       *  Product: '<S178>/Divide2'
       *  Sum: '<S178>/Add'
       *  Sum: '<S178>/Add2'
       *  Switch: '<S551>/Switch40'
       *  UnitDelay: '<S178>/Unit Delay'
       */
      if ((rtb_Saturation_gq - rtb_Saturation6) >= 0.0F) {
        /* Switch: '<S551>/Switch40' incorporates:
         *  Constant: '<S551>/LL_LFClb_TFC_Ki_C=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_a = (rtb_LL_LKASWASyn_T2 * x10) + LKAS_DW.UnitDelay_DSTATE_i;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S551>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S551>/Switch40' incorporates:
           *  Constant: '<S551>/LL_LFClb_TFC_Ki_C=0.01'
           */
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_a = rtb_LL_LKASWASyn_T2 * x10;
      }

      /* End of Switch: '<S178>/Switch2' */

      /* Gain: '<S178>/Gain' */
      rtb_LL_LKASWASyn_T2 = (-1.0F) * rtb_Yk1_i;

      /* Switch: '<S183>/Switch' incorporates:
       *  RelationalOperator: '<S183>/UpperRelop'
       */
      if (rtb_Switch2_a < rtb_LL_LKASWASyn_T2) {
        rtb_Switch_jt = rtb_LL_LKASWASyn_T2;
      } else {
        rtb_Switch_jt = rtb_Switch2_a;
      }

      /* End of Switch: '<S183>/Switch' */

      /* Switch: '<S183>/Switch2' incorporates:
       *  RelationalOperator: '<S183>/LowerRelop1'
       */
      if (rtb_Switch2_a > rtb_Yk1_i) {
        rtb_Switch2_dt = rtb_Yk1_i;
      } else {
        rtb_Switch2_dt = rtb_Switch_jt;
      }

      /* End of Switch: '<S183>/Switch2' */

      /* Saturate: '<S178>/Saturation2' */
      if (rtb_TLft > 360.0F) {
        rtb_TLft = 360.0F;
      } else {
        if (rtb_TLft < (-360.0F)) {
          rtb_TLft = (-360.0F);
        }
      }

      /* End of Saturate: '<S178>/Saturation2' */

      /* Product: '<S91>/Divide1' incorporates:
       *  Sum: '<S91>/Add3'
       */
      rtb_L0_C3 = (rtb_TLft + rtb_Switch2_dt) * rtb_LL_LKAExPrcs_tiExitTime1;

      /* Switch: '<S551>/Switch49' incorporates:
       *  Constant: '<S551>/LL_LFClb_TFC_KdMaxSWA_C=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_KdMaxSWA_C;
      }

      /* End of Switch: '<S551>/Switch49' */

      /* Product: '<S178>/Divide8' incorporates:
       *  Constant: '<S178>/Constant7'
       *  Constant: '<S178>/Constant8'
       *  Sum: '<S178>/Add4'
       */
      rtb_Yk1_i = ((180.0F - rtb_kphtomps_k) * x10) / 120.0F;

      /* MATLAB Function: '<S178>/Saturable Gain Lut (SatGainLut)1' */
      LKAS_SaturableGainLutSatGainLut(rtb_kphtomps_k,
        rtb_LL_LFClb_TFC_KdVehSpdLwr_C, rtb_LL_LFClb_TFC_KdVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KdV1_C, rtb_LL_LFClb_TFC_KdV2_C, &rtb_Gain_ji);

      /* Product: '<S185>/Divide1' incorporates:
       *  Constant: '<S185>/Constant3'
       *  Sum: '<S185>/Add4'
       */
      rtb_LL_LKAExPrcs_ExitC0Dvt = (1.0F + rtb_Abs_c) * rtb_Gain_ji;

      /* Gain: '<S185>/Gain' incorporates:
       *  Abs: '<S185>/Abs'
       */
      rtb_LL_LKASWASyn_T2 = fabsf(rtb_L0_C3_k) * 0.5F;

      /* Gain: '<S185>/Gain1' incorporates:
       *  Sum: '<S185>/Add2'
       */
      rtb_Gain1_e = (rtb_L0_C0_a + rtb_R0_C0_e) * 0.5F;

      /* Gain: '<S185>/Gain2' */
      rtb_LL_LKAExPrcs_tiExitTime1 = (-1.0F) * rtb_LL_LKASWASyn_T2;

      /* Switch: '<S190>/Switch' incorporates:
       *  RelationalOperator: '<S190>/UpperRelop'
       */
      if (rtb_Gain1_e < rtb_LL_LKAExPrcs_tiExitTime1) {
        rtb_Switch_p = rtb_LL_LKAExPrcs_tiExitTime1;
      } else {
        rtb_Switch_p = rtb_Gain1_e;
      }

      /* End of Switch: '<S190>/Switch' */

      /* Switch: '<S190>/Switch2' incorporates:
       *  RelationalOperator: '<S190>/LowerRelop1'
       */
      if (rtb_Gain1_e > rtb_LL_LKASWASyn_T2) {
        rtb_Switch2_g = rtb_LL_LKASWASyn_T2;
      } else {
        rtb_Switch2_g = rtb_Switch_p;
      }

      /* End of Switch: '<S190>/Switch2' */

      /* Product: '<S185>/Divide4' */
      rtb_LL_LKASWASyn_T2 = (rtb_Switch2_g / rtb_LL_LKASWASyn_T2) * rtb_Abs_c;

      /* Product: '<S185>/Divide5' incorporates:
       *  Constant: '<S185>/Constant2'
       *  Sum: '<S185>/Add5'
       */
      rtb_Divide5 = (1.0F + rtb_LL_LKASWASyn_T2) * rtb_Gain_ji;

      /* Product: '<S185>/Divide2' incorporates:
       *  Constant: '<S185>/Constant2'
       *  Sum: '<S185>/Add1'
       */
      rtb_Divide2_h = (1.0F - rtb_LL_LKASWASyn_T2) * rtb_Gain_ji;

      /* Sum: '<S192>/Add' incorporates:
       *  Constant: '<S192>/Constant'
       *  Memory: '<S192>/Memory'
       */
      rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_ke));

      /* Saturate: '<S192>/Saturation1' */
      if (rtb_Saturation_pd < ((uint16)10000U)) {
        rtb_Saturation1_g = rtb_Saturation_pd;
      } else {
        rtb_Saturation1_g = ((uint16)10000U);
      }

      /* End of Saturate: '<S192>/Saturation1' */

      /* If: '<S192>/If' incorporates:
       *  Constant: '<S192>/Constant2'
       *  DataTypeConversion: '<S76>/Cast To Single'
       *  Inport: '<S193>/In'
       */
      if (rtb_Saturation1_g == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S192>/if action ' incorporates:
         *  ActionPort: '<S193>/Action Port'
         */
        LKAS_DW.In_hh = LKAS_DW.LKASM_stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S192>/if action ' */
      }

      /* End of If: '<S192>/If' */

      /* If: '<S185>/If' incorporates:
       *  Inport: '<S189>/In1'
       */
      if (((sint32)LKAS_DW.In_hh) == 1) {
        /* Outputs for IfAction SubSystem: '<S185>/If Action Subsystem' incorporates:
         *  ActionPort: '<S187>/Action Port'
         */
        LKAS_IfActionSubsystem_b(rtb_Divide2_h, &rtb_Merge_ah);

        /* End of Outputs for SubSystem: '<S185>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_hh) == 2) {
        /* Outputs for IfAction SubSystem: '<S185>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S188>/Action Port'
         */
        LKAS_IfActionSubsystem_b(rtb_Divide5, &rtb_Merge_ah);

        /* End of Outputs for SubSystem: '<S185>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S185>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S189>/Action Port'
         */
        rtb_Merge_ah = rtb_Gain_ji;

        /* End of Outputs for SubSystem: '<S185>/If Action Subsystem2' */
      }

      /* End of If: '<S185>/If' */

      /* Product: '<S185>/Divide3' incorporates:
       *  Constant: '<S185>/Constant1'
       *  Sum: '<S185>/Add3'
       */
      rtb_LL_LKASWASyn_T2 = (1.0F - rtb_Abs_c) * rtb_Gain_ji;

      /* Switch: '<S191>/Switch' incorporates:
       *  RelationalOperator: '<S191>/UpperRelop'
       */
      if (rtb_Merge_ah < rtb_LL_LKASWASyn_T2) {
        rtb_Switch_gl = rtb_LL_LKASWASyn_T2;
      } else {
        rtb_Switch_gl = rtb_Merge_ah;
      }

      /* End of Switch: '<S191>/Switch' */

      /* Switch: '<S191>/Switch2' incorporates:
       *  RelationalOperator: '<S191>/LowerRelop1'
       */
      if (rtb_Merge_ah > rtb_LL_LKAExPrcs_ExitC0Dvt) {
        rtb_Switch2_dd = rtb_LL_LKAExPrcs_ExitC0Dvt;
      } else {
        rtb_Switch2_dd = rtb_Switch_gl;
      }

      /* End of Switch: '<S191>/Switch2' */

      /* Product: '<S178>/Divide7' incorporates:
       *  Gain: '<S178>/Gain1'
       */
      rtb_Divide7 = (rtb_LL_HdAgPrvwT_C * (-1.0F)) * rtb_Switch2_dd;

      /* Gain: '<S178>/Gain3' */
      rtb_LL_LKAExPrcs_ExitC0Dvt = (-1.0F) * rtb_Yk1_i;

      /* Switch: '<S184>/Switch' incorporates:
       *  RelationalOperator: '<S184>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_LL_LKAExPrcs_ExitC0Dvt) {
        rtb_Switch_pg = rtb_LL_LKAExPrcs_ExitC0Dvt;
      } else {
        rtb_Switch_pg = rtb_Divide7;
      }

      /* End of Switch: '<S184>/Switch' */

      /* Switch: '<S184>/Switch2' incorporates:
       *  RelationalOperator: '<S184>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_Yk1_i) {
        rtb_Switch2_k = rtb_Yk1_i;
      } else {
        rtb_Switch2_k = rtb_Switch_pg;
      }

      /* End of Switch: '<S184>/Switch2' */

      /* Product: '<S91>/Divide4' */
      rtb_Yk1_i = rtb_Add5_n_tmp;

      /* Saturate: '<S91>/Saturation1' */
      rtb_TLft = rtb_Yk1_i;
      if (rtb_TLft > 1.0F) {
        rtb_Yk1_i = 1.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Yk1_i = 0.0F;
      } else {
        rtb_Yk1_i = rtb_TLft;
      }

      /* End of Saturate: '<S91>/Saturation1' */

      /* Product: '<S91>/Divide2' */
      rtb_L0_C0_a = rtb_Switch2_k * rtb_Yk1_i;

      /* Product: '<S198>/Divide' */
      rtb_Saturation4 = rtb_Add5_n_tmp;

      /* Saturate: '<S198>/Saturation4' */
      if (rtb_Saturation4 > 1.0F) {
        rtb_Saturation4 = 1.0F;
      } else {
        if (rtb_Saturation4 < 0.0F) {
          rtb_Saturation4 = 0.0F;
        }
      }

      /* End of Saturate: '<S198>/Saturation4' */

      /* Gain: '<S179>/kph to mps' */
      rtb_Yk1_i = rtb_LKA_Veh2CamL_C_tmp;

      /* Saturate: '<S179>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S179>/Saturation3' */

      /* Product: '<S179>/Divide2' incorporates:
       *  Constant: '<S179>/Constant'
       */
      rtb_TLft = 0.09F / x10;

      /* Switch: '<S551>/Switch36' incorporates:
       *  Constant: '<S551>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_a != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_a;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S551>/Switch36' */

      /* Saturate: '<S179>/Saturation1' */
      if (rtb_TLft > 0.01F) {
        rtb_TLft = 0.01F;
      } else {
        if (rtb_TLft < 0.0F) {
          rtb_TLft = 0.0F;
        }
      }

      /* End of Saturate: '<S179>/Saturation1' */

      /* Gain: '<S179>/Gain2' incorporates:
       *  Constant: '<S179>/Constant1'
       *  Gain: '<S179>/rad to deg'
       *  Gain: '<S224>/Gain1'
       *  Math: '<S179>/Math Function'
       *  Product: '<S179>/Divide'
       *  Product: '<S179>/Divide1'
       *  Product: '<S179>/Product'
       *  Product: '<S179>/Product1'
       *  Product: '<S179>/Product2'
       *  Product: '<S179>/Product3'
       *  Sum: '<S179>/Add'
       *
       * About '<S179>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_Yk1_i = (((((((rtb_Yk1_i * rtb_Yk1_i) * rtb_TLft) + 1.0F) / (rtb_Yk1_i
        / LKAS_DW.LKA_WhlBaseL_C_b)) * ((rtb_Yk1_i *
        rtb_LL_ThresDet_tiTTLCThresLDW) * 57.2957802F)) * x10) *
                   LKAS_DW.LKA_StrRatio_C_m) * (-1.0F);

      /* Sum: '<S196>/Add2' incorporates:
       *  Constant: '<S196>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S196>/Memory3'
       */
      rtb_TLft = 1.0F + LKAS_DW.Memory3_PreviousInput_k;

      /* Saturate: '<S196>/Saturation' */
      if (rtb_TLft > 50.0F) {
        rtb_Saturation_bs = 50.0F;
      } else if (rtb_TLft < 0.0F) {
        rtb_Saturation_bs = 0.0F;
      } else {
        rtb_Saturation_bs = rtb_TLft;
      }

      /* End of Saturate: '<S196>/Saturation' */

      /* Switch: '<S196>/Switch' incorporates:
       *  Constant: '<S198>/Constant1'
       *  Constant: '<S91>/Constant1'
       *  Product: '<S196>/Divide'
       *  Product: '<S196>/Divide1'
       *  Product: '<S198>/Divide8'
       *  Product: '<S91>/Divide5'
       *  Product: '<S91>/Divide7'
       *  Sum: '<S196>/Add'
       *  Sum: '<S196>/Add1'
       *  Sum: '<S198>/Add1'
       *  Sum: '<S91>/Add4'
       *  UnitDelay: '<S196>/Unit Delay'
       */
      if (rtb_Saturation_bs > 30.0F) {
        rtb_Switch_gc = (((((((LKAS_DW.Merge1 * rtb_LL_LKASWASyn_M1) + rtb_L0_C3)
                             + rtb_L0_C0_a) + (((LKAS_ConstB.Add3 *
          rtb_Saturation4) + 0.0F) * rtb_Yk1_i)) + rtb_R0_C1) -
                          LKAS_DW.UnitDelay_DSTATE_k) * (rtb_LKA_SampleTime /
          0.1F)) + LKAS_DW.UnitDelay_DSTATE_k;
      } else {
        rtb_Switch_gc = ((((LKAS_DW.Merge1 * rtb_LL_LKASWASyn_M1) + rtb_L0_C3) +
                          rtb_L0_C0_a) + (((LKAS_ConstB.Add3 * rtb_Saturation4)
          + 0.0F) * rtb_Yk1_i)) + rtb_R0_C1;
      }

      /* End of Switch: '<S196>/Switch' */

      /* Switch: '<S551>/Switch17' incorporates:
       *  Constant: '<S551>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S551>/Switch17' */

      /* Sum: '<S88>/Add' */
      rtb_Add_np = (rtb_Switch_gc - x10) + LKAS_DW.Saturation_m;

      /* Sum: '<S88>/Add1' */
      rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_Yk1_i + rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S88>/Add2' incorporates:
       *  Gain: '<S88>/Gain2'
       */
      rtb_Yk1_i += (-1.0F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S174>/Switch' incorporates:
       *  RelationalOperator: '<S174>/UpperRelop'
       */
      if (rtb_Add_np < rtb_Yk1_i) {
        rtb_Switch_bz = rtb_Yk1_i;
      } else {
        rtb_Switch_bz = rtb_Add_np;
      }

      /* End of Switch: '<S174>/Switch' */

      /* Switch: '<S174>/Switch2' incorporates:
       *  RelationalOperator: '<S174>/LowerRelop1'
       */
      if (rtb_Add_np > rtb_LL_LKAExPrcs_ExitC0Dvt) {
        rtb_Switch2_oj = rtb_LL_LKAExPrcs_ExitC0Dvt;
      } else {
        rtb_Switch2_oj = rtb_Switch_bz;
      }

      /* End of Switch: '<S174>/Switch2' */

      /* Sum: '<S173>/Add1' incorporates:
       *  Constant: '<S173>/Constant'
       *  Memory: '<S173>/Memory'
       */
      rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_n));

      /* Switch: '<S173>/Switch' incorporates:
       *  Constant: '<S173>/LatchTime_SY'
       *  RelationalOperator: '<S173>/Relational Operator'
       *  UnitDelay: '<S173>/Delay Input2'
       *
       * Block description for '<S173>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_pd <= ((uint16)1U)) {
        rtb_Yk1_i = rtb_Switch2_oj;
      } else {
        rtb_Yk1_i = LKAS_DW.DelayInput2_DSTATE_e;
      }

      /* End of Switch: '<S173>/Switch' */

      /* Sum: '<S173>/Difference Inputs1'
       *
       * Block description for '<S173>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_g = rtb_Switch2_oj - rtb_Yk1_i;

      /* Product: '<S173>/delta rise limit' incorporates:
       *  Gain: '<S88>/Gain3'
       *  SampleTimeMath: '<S173>/sample time'
       *
       * About '<S173>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_LL_LKASWASyn_T2 = (1.4F * LKAS_DW.SWARmax) * 0.01F;

      /* Product: '<S173>/delta fall limit' incorporates:
       *  Gain: '<S88>/Gain1'
       *  SampleTimeMath: '<S173>/sample time'
       *
       * About '<S173>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_LL_LKAExPrcs_ExitC0Dvt = ((-1.4F) * LKAS_DW.SWARmax) * 0.01F;

      /* Switch: '<S175>/Switch' incorporates:
       *  RelationalOperator: '<S175>/UpperRelop'
       */
      if (rtb_UkYk1_g < rtb_LL_LKAExPrcs_ExitC0Dvt) {
        rtb_Switch_ac = rtb_LL_LKAExPrcs_ExitC0Dvt;
      } else {
        rtb_Switch_ac = rtb_UkYk1_g;
      }

      /* End of Switch: '<S175>/Switch' */

      /* Switch: '<S175>/Switch2' incorporates:
       *  RelationalOperator: '<S175>/LowerRelop1'
       */
      if (rtb_UkYk1_g > rtb_LL_LKASWASyn_T2) {
        rtb_Switch2_om = rtb_LL_LKASWASyn_T2;
      } else {
        rtb_Switch2_om = rtb_Switch_ac;
      }

      /* End of Switch: '<S175>/Switch2' */

      /* Sum: '<S173>/Difference Inputs2'
       *
       * Block description for '<S173>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_om + rtb_Yk1_i;

      /* Saturate: '<S173>/Saturation2' */
      if (rtb_Saturation_pd < ((uint16)10000U)) {
        rtb_Saturation2_p = rtb_Saturation_pd;
      } else {
        rtb_Saturation2_p = ((uint16)10000U);
      }

      /* End of Saturate: '<S173>/Saturation2' */

      /* DataTypeConversion: '<S89>/CastLKA3' */
      LKAS_DW.T1_Mon_p = LKAS_DW.Merge_a;

      /* DataTypeConversion: '<S113>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_IMAPve_g_ESC_VehSpd;

      /* DataTypeConversion: '<S89>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon_o = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S87>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S105>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S107>/Out' */
          LKAS_DW.RelationalOperator_c5 = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S105>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S85>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_j) {
          /* Disable for Outport: '<S93>/Out1' */
          LKAS_DW.DifferenceInputs2_b = 0.0F;
          LKAS_DW.Subsystem_MODE_j = false;
        }

        /* End of Disable for SubSystem: '<S85>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S106>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_lz,
            &LKAS_DW.SumCondition1_c);
        }

        /* End of Disable for SubSystem: '<S106>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S106>/Sum Condition' */
        if (LKAS_DW.SumCondition_j.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_p,
            &LKAS_DW.SumCondition_j);
        }

        /* End of Disable for SubSystem: '<S106>/Sum Condition' */

        /* Disable for If: '<S195>/If' */
        LKAS_DW.If_ActiveSubsystem_j = -1;

        /* Disable for Outport: '<S76>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S76>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S76>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S76>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_a = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_o = 0.0F;
        LKAS_DW.T1_Mon_p = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon_a;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon_o;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.T1_Mon = LKAS_DW.T1_Mon_p;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_State_Mon = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LDW_State_Mon = LKAS_DW.LDWSM_stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.LDWSM_stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S75>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S80>/If' */
      if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S80>/If Action Subsystem' incorporates:
         *  ActionPort: '<S81>/Action Port'
         */
        /* Gain: '<S81>/rad to deg' incorporates:
         *  Gain: '<S81>/Gain'
         */
        LKAS_DW.Merge_c = ((-1.0F) * rtb_L0_C1_p) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S80>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S80>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S82>/Action Port'
         */
        /* Gain: '<S82>/rad to deg' */
        LKAS_DW.Merge_c = 57.2957802F * rtb_L0_C1;

        /* End of Outputs for SubSystem: '<S80>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S80>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S83>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_c);

        /* End of Outputs for SubSystem: '<S80>/If Action Subsystem2' */
      }

      /* End of If: '<S80>/If' */

      /* Switch: '<S550>/Switch2' incorporates:
       *  Constant: '<S550>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_l != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_l;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S550>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S80>/Sum Condition' incorporates:
       *  EnablePort: '<S84>/Enable'
       */
      /* RelationalOperator: '<S80>/Relational Operator' */
      if (LKAS_DW.Merge_c >= x10) {
        if (!LKAS_DW.SumCondition_MODE_i) {
          /* InitializeConditions for Memory: '<S84>/Memory' */
          LKAS_DW.Memory_PreviousInput_h3 = 0.0F;
          LKAS_DW.SumCondition_MODE_i = true;
        }

        /* Sum: '<S84>/Add1' incorporates:
         *  Memory: '<S84>/Memory'
         */
        rtb_L0_C1 = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_h3;

        /* Saturate: '<S84>/Saturation' */
        if (rtb_L0_C1 > 0.6F) {
          rtb_L0_C1 = 0.6F;
        } else {
          if (rtb_L0_C1 < 0.0F) {
            rtb_L0_C1 = 0.0F;
          }
        }

        /* End of Saturate: '<S84>/Saturation' */

        /* RelationalOperator: '<S84>/Relational Operator' incorporates:
         *  Constant: '<S80>/Constant'
         */
        LKAS_DW.RelationalOperator_oy = (rtb_L0_C1 >= 0.05F);

        /* Update for Memory: '<S84>/Memory' */
        LKAS_DW.Memory_PreviousInput_h3 = rtb_L0_C1;
      } else {
        if (LKAS_DW.SumCondition_MODE_i) {
          /* Disable for Outport: '<S84>/Out' */
          LKAS_DW.RelationalOperator_oy = false;
          LKAS_DW.SumCondition_MODE_i = false;
        }
      }

      /* End of RelationalOperator: '<S80>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S80>/Sum Condition' */

      /* Product: '<S75>/Product' incorporates:
       *  Logic: '<S75>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.LDWSM_stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_oy) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S80>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_i) {
          /* Disable for Outport: '<S84>/Out' */
          LKAS_DW.RelationalOperator_oy = false;
          LKAS_DW.SumCondition_MODE_i = false;
        }

        /* End of Disable for SubSystem: '<S80>/Sum Condition' */

        /* Disable for Outport: '<S75>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* SignalConversion: '<S458>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S368>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LKA_Main_Switch;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_BCM_Left_Light;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_BCM_Right_Light;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_i4;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_jl;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_no;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_dq;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_k0f;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_c;
    rtb_TmpSignalConversionAtSFunct[12] = LKAS_DW.RelationalOperator_h;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_stDvrTkConFlg_p;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_ee;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator_m;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_LogicalOperator3_e;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge;

    /* MATLAB Function: '<S368>/Disable Reason' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S458>:1' */
    /* '<S458>:1:2' y = single(0); */
    rtb_L0_C1 = 0.0F;

    /* '<S458>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S458>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S458>:1:5' y = single(i); */
        rtb_L0_C1 = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Disable_Reason = rtb_L0_C1;

    /* DataTypeConversion: '<S269>/Cast' */
    ob_LKA_Disable_Reason = rtb_L0_C1;

    /* DataTypeConversion: '<S269>/Cast1' */
    ob_LKA_LKADeactvCSyn = (float32)(LKAS_DW.Merge1_l ? 1.0F : 0.0F);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LFTTTLC_Mon = rtb_LFTTTLC;

    /* Logic: '<S491>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S491>/Relational Operator3'
     *  RelationalOperator: '<S491>/Relational Operator4'
     */
    rtb_LogicalOperator1_j = ((rtb_Gain1 <= rtb_R0_C2) || (rtb_Add5_n <=
      rtb_R0_C2));

    /* Gain: '<S221>/Gain' incorporates:
     *  Sum: '<S221>/Add'
     */
    rtb_lDvt = (rtb_Gain1 + rtb_Add5_n) * 0.5F;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.DACMode = LKAS_DW.LKA_Mode;

    /* Gain: '<S220>/Gain' incorporates:
     *  Sum: '<S220>/Add'
     */
    rtb_crCrvt = (rtb_L0_C2_j + rtb_L0_C2) * 0.5F;

    /* Delay: '<S78>/Delay1' */
    rtb_DACMode = LKAS_DW.Delay1_2_DSTATE;

    /* RelationalOperator: '<S527>/Compare' incorporates:
     *  Constant: '<S527>/Constant'
     *  Constant: '<S559>/Constant14'
     */
    rtb_Compare_oi = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S536>/Compare' incorporates:
     *  Constant: '<S536>/Constant'
     *  Constant: '<S559>/Constant11'
     */
    rtb_Compare_hm = (((uint8)0U) == ((uint8)1U));
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S376>/Count 20s' */
      if (LKAS_DW.Count20s_MODE) {
        /* Disable for Outport: '<S384>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.Count20s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S376>/Count 20s' */

      /* Disable for Enabled SubSystem: '<S377>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S386>/Out' */
        LKAS_DW.RelationalOperator_e = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Disable for SubSystem: '<S377>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S387>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_j) {
        /* Disable for Outport: '<S393>/Out' */
        LKAS_DW.RelationalOperator_h = false;
        LKAS_DW.SumCondition1_MODE_j = false;
      }

      /* End of Disable for SubSystem: '<S387>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S399>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S406>/Out' */
        LKAS_DW.RelationalOperator_m = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S399>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S315>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S346>/Out' */
        LKAS_DW.RelationalOperator_hg = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S315>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S315>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S345>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S315>/Count' */

      /* Disable for Enabled SubSystem: '<S348>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_m) {
        /* Disable for Outport: '<S354>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_m = false;
      }

      /* End of Disable for SubSystem: '<S348>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S316>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_d) {
        /* Disable for Outport: '<S360>/Out' */
        LKAS_DW.RelationalOperator_o = false;
        LKAS_DW.SumCondition1_MODE_d = false;
      }

      /* End of Disable for SubSystem: '<S316>/Sum Condition1' */

      /* Disable for If: '<S363>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S326>/Sum Condition' */
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S332>/Out' */
        LKAS_DW.RelationalOperator_kh = false;
        LKAS_DW.SumCondition_MODE = false;
      }

      /* End of Disable for SubSystem: '<S326>/Sum Condition' */

      /* Disable for Enabled SubSystem: '<S274>/Count_5s3' */
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S541>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }

      /* End of Disable for SubSystem: '<S274>/Count_5s3' */

      /* Disable for Enabled SubSystem: '<S274>/Count_5s2' */
      if (LKAS_DW.Count_5s2.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_k, &LKAS_DW.Count_5s2);
      }

      /* End of Disable for SubSystem: '<S274>/Count_5s2' */

      /* Disable for Enabled SubSystem: '<S274>/Count_5s1' */
      if (LKAS_DW.Count_5s1.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_g, &LKAS_DW.Count_5s1);
      }

      /* End of Disable for SubSystem: '<S274>/Count_5s1' */

      /* Disable for Enabled SubSystem: '<S251>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_h) {
        /* Disable for Outport: '<S255>/Out' */
        LKAS_DW.RelationalOperator_l3 = false;
        LKAS_DW.Subsystem_MODE_h = false;
      }

      /* End of Disable for SubSystem: '<S251>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S87>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S105>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S107>/Out' */
          LKAS_DW.RelationalOperator_c5 = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S105>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S85>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_j) {
          /* Disable for Outport: '<S93>/Out1' */
          LKAS_DW.DifferenceInputs2_b = 0.0F;
          LKAS_DW.Subsystem_MODE_j = false;
        }

        /* End of Disable for SubSystem: '<S85>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S106>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_lz,
            &LKAS_DW.SumCondition1_c);
        }

        /* End of Disable for SubSystem: '<S106>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S106>/Sum Condition' */
        if (LKAS_DW.SumCondition_j.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_p,
            &LKAS_DW.SumCondition_j);
        }

        /* End of Disable for SubSystem: '<S106>/Sum Condition' */

        /* Disable for If: '<S195>/If' */
        LKAS_DW.If_ActiveSubsystem_j = -1;

        /* Disable for Outport: '<S76>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S76>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S76>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S76>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_a = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_o = 0.0F;
        LKAS_DW.T1_Mon_p = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S80>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_i) {
          /* Disable for Outport: '<S84>/Out' */
          LKAS_DW.RelationalOperator_oy = false;
          LKAS_DW.SumCondition_MODE_i = false;
        }

        /* End of Disable for SubSystem: '<S80>/Sum Condition' */

        /* Disable for Outport: '<S75>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.DACMode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MATLAB Function: '<S8>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S53>/Switch'
   *  Switch: '<S53>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S29>:1' */
  /* '<S29>:1:2' if stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S29>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:6' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:8' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S29>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S29>:1:10' Vehicle_Lane_Display=uint8(10); */
        rtb_L0_Q = 10U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:12' Vehicle_Lane_Display=uint8(11); */
        rtb_L0_Q = 11U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:14' Vehicle_Lane_Display=uint8(12); */
        rtb_L0_Q = 12U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:16' Vehicle_Lane_Display=uint8(13); */
        rtb_L0_Q = 13U;
      } else {
        /* '<S29>:1:17' else */
        /* '<S29>:1:18' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S29>:1:4' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   case 2:
    /* '<S29>:1:20' elseif stDACmode==2 */
    /* '<S29>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:24' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:26' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S29>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S29>:1:28' Vehicle_Lane_Display=uint8(6); */
        rtb_L0_Q = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:30' Vehicle_Lane_Display=uint8(7); */
        rtb_L0_Q = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:32' Vehicle_Lane_Display=uint8(8); */
        rtb_L0_Q = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:34' Vehicle_Lane_Display=uint8(9); */
        rtb_L0_Q = 9U;
      } else {
        /* '<S29>:1:35' else */
        /* '<S29>:1:36' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S29>:1:22' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   default:
    /* '<S29>:1:38' else */
    /* '<S29>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_L0_Q = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/Vehicle_Lane_Display' */

  /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S11>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)1U);
    break;

   case 1:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)1U);
    break;

   case 2:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)2U);
    break;

   case 3:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)3U);
    break;

   case 4:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)4U);
    break;

   case 5:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)4U);
    break;

   default:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S11>/Multiport Switch' */

  /* RelationalOperator: '<S543>/Compare' incorporates:
   *  Constant: '<S543>/Constant'
   */
  rtb_Merge = (rtb_IMAPve_d_SAS_Trim_State == ((uint8)4U));

  /* Switch: '<S11>/Switch1' incorporates:
   *  Constant: '<S11>/1'
   *  Constant: '<S11>/x0'
   */
  if (rtb_Merge) {
    rtb_R0_Q = ((uint8)1U);
  } else {
    rtb_R0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S542>/Subsystem' incorporates:
   *  EnablePort: '<S547>/Enable'
   */
  if (((sint32)rtb_R0_Q) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S547>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S547>/Add' */
    rtb_L0_C2 = LKAS_DW.OutputSWACmd - rtb_IMAPve_g_SW_Angle;

    /* Sum: '<S547>/Add1' incorporates:
     *  Constant: '<S547>/Ki'
     *  Delay: '<S547>/Delay1'
     *  Product: '<S547>/Product2'
     */
    rtb_L0_C2_j = (rtb_L0_C2 * 0.0005F) + LKAS_DW.Delay1_DSTATE;

    /* Saturate: '<S547>/Saturation' */
    if (rtb_L0_C2_j > 0.5F) {
      rtb_L0_C2_j = 0.5F;
    } else {
      if (rtb_L0_C2_j < (-0.5F)) {
        rtb_L0_C2_j = (-0.5F);
      }
    }

    /* End of Saturate: '<S547>/Saturation' */

    /* Fcn: '<S547>/Fcn' */
    rtb_Abs_c = LKAS_DW.OutputSWACmd * LKAS_DW.OutputSWACmd;

    /* Sum: '<S547>/Add2' incorporates:
     *  Constant: '<S547>/Kp'
     *  Fcn: '<S547>/Fcn'
     *  Product: '<S547>/Product1'
     */
    LKAS_DW.in_trq = (((((rtb_Abs_c * LKAS_DW.OutputSWACmd) * 2.0e-6F) +
                        (rtb_Abs_c * -0.0005F)) + (LKAS_DW.OutputSWACmd *
      0.0505F)) + (rtb_L0_C2 * 0.02F)) + rtb_L0_C2_j;

    /* Update for Delay: '<S547>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_L0_C2_j;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S547>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S542>/Subsystem' */

  /* Sum: '<S545>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S545>/Delay Input2'
   *
   * Block description for '<S545>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S545>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S545>/delta rise limit' incorporates:
   *  Constant: '<S542>/Constant'
   *  SampleTimeMath: '<S545>/sample time'
   *
   * About '<S545>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C2_j = 5.0F * 0.01F;

  /* Product: '<S545>/delta fall limit' incorporates:
   *  Constant: '<S542>/Constant1'
   *  SampleTimeMath: '<S545>/sample time'
   *
   * About '<S545>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C1 = (-5.0F) * 0.01F;

  /* Switch: '<S548>/Switch2' incorporates:
   *  Product: '<S545>/delta fall limit'
   *  Product: '<S545>/delta rise limit'
   *  RelationalOperator: '<S548>/LowerRelop1'
   *  RelationalOperator: '<S548>/UpperRelop'
   *  Switch: '<S548>/Switch'
   */
  if (rtb_L0_C2 > rtb_L0_C2_j) {
    rtb_L0_C2 = rtb_L0_C2_j;
  } else {
    if (rtb_L0_C2 < rtb_L0_C1) {
      /* Switch: '<S548>/Switch' incorporates:
       *  Product: '<S545>/delta fall limit'
       */
      rtb_L0_C2 = rtb_L0_C1;
    }
  }

  /* End of Switch: '<S548>/Switch2' */

  /* Sum: '<S545>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S545>/Delay Input2'
   *
   * Block description for '<S545>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S545>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 += LKAS_DW.DelayInput2_DSTATE;

  /* MATLAB Function: '<S8>/LDW_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Status_Display': '<S25>:1' */
  /* '<S25>:1:2' if (stDACmode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S25>:1:3' LDW_Status_Display=uint8(1); */
    rtb_TCU_ActualGear = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S25>:1:4' elseif (stDACmode==1)&&LDW_STATE==6 */
    /* '<S25>:1:5' LDW_Status_Display=uint8(2); */
    rtb_TCU_ActualGear = 2U;
  } else {
    /* '<S25>:1:6' else */
    /* '<S25>:1:7' LDW_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;
  }

  /* End of MATLAB Function: '<S8>/LDW_Status_Display' */

  /* MATLAB Function: '<S8>/LKA_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_Status_Display': '<S26>:1' */
  /* '<S26>:1:3' if stDACmode==2&&LKA_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) != 6)) {
    /* '<S26>:1:4' LKA_Status_Display=single(1); */
    rtb_L0_C2_j = 1.0F;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S26>:1:5' elseif stDACmode==2&&LKA_STATE==6 */
    /* '<S26>:1:6' LKA_Status_Display=single(2); */
    rtb_L0_C2_j = 2.0F;
  } else {
    /* '<S26>:1:7' else */
    /* '<S26>:1:8' LKA_Status_Display=single(0); */
    rtb_L0_C2_j = 0.0F;
  }

  /* End of MATLAB Function: '<S8>/LKA_Status_Display' */

  /* MATLAB Function: '<S8>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S24>:1' */
  /* '<S24>:1:2' if HMI_stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S24>:1:3' if HMI_LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S24>:1:4' LDW_Flag=uint8(1); */
      rtb_CastToSingle3 = 1U;
      break;

     case 2:
      /* '<S24>:1:5' elseif HMI_LDWWarnInfo==2 */
      /* '<S24>:1:6' LDW_Flag=uint8(2); */
      rtb_CastToSingle3 = 2U;
      break;

     default:
      /* '<S24>:1:7' else */
      /* '<S24>:1:8' LDW_Flag=uint8(0); */
      rtb_CastToSingle3 = 0U;
      break;
    }
    break;

   case 2:
    /* '<S24>:1:10' elseif HMI_stDACmode==2 */
    /* '<S24>:1:11' if HMI_LDWWarnInfo==1 && HMI_LKA_STATE==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S24>:1:12' LDW_Flag=uint8(1); */
      rtb_CastToSingle3 = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S24>:1:13' elseif HMI_LDWWarnInfo==2 && HMI_LKA_STATE==5 */
      /* '<S24>:1:14' LDW_Flag=uint8(2); */
      rtb_CastToSingle3 = 2U;
    } else {
      /* '<S24>:1:15' else */
      /* '<S24>:1:16' LDW_Flag=uint8(0); */
      rtb_CastToSingle3 = 0U;
    }
    break;

   default:
    /* '<S24>:1:18' else */
    /* '<S24>:1:19' LDW_Flag=uint8(0); */
    rtb_CastToSingle3 = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/LDW_Flag' */

  /* Switch: '<S28>/Switch' incorporates:
   *  Constant: '<S28>/Constant'
   *  Constant: '<S28>/Constant1'
   *  Constant: '<S30>/Constant'
   *  RelationalOperator: '<S30>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_LKA_Veh2CamL_C = 0.5F;
  } else {
    rtb_LKA_Veh2CamL_C = 0.25F;
  }

  /* End of Switch: '<S28>/Switch' */

  /* Logic: '<S28>/Logical Operator2' incorporates:
   *  Abs: '<S28>/Abs'
   *  Constant: '<S31>/Constant'
   *  Constant: '<S32>/Constant'
   *  Constant: '<S33>/Constant'
   *  Constant: '<S34>/Constant'
   *  Constant: '<S35>/Constant'
   *  Constant: '<S36>/Constant'
   *  Constant: '<S37>/Constant'
   *  Constant: '<S38>/Constant'
   *  Logic: '<S28>/Logical Operator1'
   *  Logic: '<S28>/Logical Operator3'
   *  RelationalOperator: '<S28>/Relational Operator'
   *  RelationalOperator: '<S31>/Compare'
   *  RelationalOperator: '<S32>/Compare'
   *  RelationalOperator: '<S33>/Compare'
   *  RelationalOperator: '<S34>/Compare'
   *  RelationalOperator: '<S35>/Compare'
   *  RelationalOperator: '<S36>/Compare'
   *  RelationalOperator: '<S37>/Compare'
   *  RelationalOperator: '<S38>/Compare'
   */
  rtb_LKA_Main_Switch = ((((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (LKAS_DW.LKA_State == ((uint8)5U))) || (LKAS_DW.LKA_State == ((uint8)4U))) ||
    (LKAS_DW.LKA_State == ((uint8)3U))) && ((rtb_IMAPve_d_EPS_LKA_State ==
    ((uint8)3U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)))) && (fabsf
    (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_LKA_Veh2CamL_C));

  /* Outputs for Enabled SubSystem: '<S28>/Count 15s' incorporates:
   *  EnablePort: '<S40>/Enable'
   */
  if (rtb_LKA_Main_Switch) {
    if (!LKAS_DW.Count15s_MODE) {
      /* InitializeConditions for Memory: '<S40>/Memory' */
      LKAS_DW.Memory_PreviousInput_ew = ((uint16)0U);
      LKAS_DW.Count15s_MODE = true;
    }

    /* Sum: '<S40>/Add' incorporates:
     *  Constant: '<S40>/Constant'
     *  Memory: '<S40>/Memory'
     */
    rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      LKAS_DW.Memory_PreviousInput_ew));

    /* Saturate: '<S40>/Saturation' */
    if (rtb_Saturation_pd >= ((uint16)2100U)) {
      rtb_Saturation_pd = ((uint16)2100U);
    }

    /* End of Saturate: '<S40>/Saturation' */

    /* RelationalOperator: '<S42>/Compare' incorporates:
     *  Constant: '<S42>/Constant'
     */
    LKAS_DW.Compare = (rtb_Saturation_pd >= ((uint16)1500U));

    /* Update for Memory: '<S40>/Memory' */
    LKAS_DW.Memory_PreviousInput_ew = rtb_Saturation_pd;
  } else {
    if (LKAS_DW.Count15s_MODE) {
      /* Disable for Outport: '<S40>/Out' */
      LKAS_DW.Compare = false;
      LKAS_DW.Count15s_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S28>/Count 15s' */

  /* MATLAB Function: '<S8>/Hands_Off_Warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_Off_Warning': '<S23>:1' */
  /* '<S23>:1:2' if HandsOff==0 */
  if (!LKAS_DW.Compare) {
    /* '<S23>:1:3' Hands_Off_Warning= uint8(0); */
    rtb_Hands_Off_Warning_j = 0U;
  } else {
    /* '<S23>:1:4' elseif HandsOff==1 */
    /* '<S23>:1:5' Hands_Off_Warning= uint8(1); */
    rtb_Hands_Off_Warning_j = 1U;
  }

  /* End of MATLAB Function: '<S8>/Hands_Off_Warning' */

  /* Outputs for Enabled SubSystem: '<S28>/Count 10s' incorporates:
   *  EnablePort: '<S39>/Enable'
   */
  if (rtb_LKA_Main_Switch) {
    if (!LKAS_DW.Count10s_MODE) {
      /* InitializeConditions for Memory: '<S39>/Memory' */
      LKAS_DW.Memory_PreviousInput_m2 = ((uint16)0U);
      LKAS_DW.Count10s_MODE = true;
    }

    /* Sum: '<S39>/Add' incorporates:
     *  Constant: '<S39>/Constant'
     *  Memory: '<S39>/Memory'
     */
    rtb_Saturation_pd = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      LKAS_DW.Memory_PreviousInput_m2));

    /* Saturate: '<S39>/Saturation' */
    if (rtb_Saturation_pd >= ((uint16)2100U)) {
      rtb_Saturation_pd = ((uint16)2100U);
    }

    /* End of Saturate: '<S39>/Saturation' */

    /* RelationalOperator: '<S41>/Compare' incorporates:
     *  Constant: '<S41>/Constant'
     */
    LKAS_DW.Compare_c = (rtb_Saturation_pd >= ((uint16)1000U));

    /* Update for Memory: '<S39>/Memory' */
    LKAS_DW.Memory_PreviousInput_m2 = rtb_Saturation_pd;
  } else {
    if (LKAS_DW.Count10s_MODE) {
      /* Disable for Outport: '<S39>/Out' */
      LKAS_DW.Compare_c = false;
      LKAS_DW.Count10s_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S28>/Count 10s' */

  /* MATLAB Function: '<S8>/HMI_Popup_Status' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S22>:1' */
  /* '<S22>:1:2' if stDACmode==2&&LKA_STATE==6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 6)) {
    /* �������ָ������� */
    /* '<S22>:1:3' HMI_Popup_Status=uint8(6); */
    rtb_IMAPve_d_Camera_Status = 6U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (((sint32)rtb_IMAPve_d_Camera_Status) == 5)) {
    /* '<S22>:1:6' elseif (stDACmode==2||stDACmode==1)&&(Front_Camera_Blocked==5) */
    /* ����ͷ���ڵ� */
    /* '<S22>:1:7' HMI_Popup_Status=uint8(4); */
    rtb_IMAPve_d_Camera_Status = 4U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (LKAS_DW.Compare_c)) {
    /* '<S22>:1:8' elseif (stDACmode==2||stDACmode==1)&&HandsOff==1 */
    /* ���շ����� */
    /* '<S22>:1:9' HMI_Popup_Status=uint8(2); */
    rtb_IMAPve_d_Camera_Status = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              2)) {
    /* '<S22>:1:10' elseif stDACmode==2&&(LKA_STATE==2) */
    /* '<S22>:1:11' HMI_Popup_Status=uint8(1); */
    rtb_IMAPve_d_Camera_Status = 1U;
  } else if (((sint32)LKAS_DW.LKA_Mode) != 2) {
    /* '<S22>:1:12' elseif stDACmode~=2&&stFaultCSyn==0 */
    /* '<S22>:1:13' HMI_Popup_Status=uint8(8); */
    rtb_IMAPve_d_Camera_Status = 8U;
  } else {
    /* '<S22>:1:14' elseif stFaultCSyn==0 */
    /* '<S22>:1:15' HMI_Popup_Status=uint8(7); */
    rtb_IMAPve_d_Camera_Status = 7U;
  }

  /* End of MATLAB Function: '<S8>/HMI_Popup_Status' */

  /* MATLAB Function: '<S8>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S27>:1' */
  /* '<S27>:1:2' if stDACmode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S27>:1:3' LKA_Action_Indication=uint8(1); */
    rtb_LKA_Action_Indication_j = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S27>:1:4' elseif stDACmode==2&&LKA_STATE==3 */
    /* '<S27>:1:5' LKA_Action_Indication=uint8(2); */
    rtb_LKA_Action_Indication_j = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S27>:1:6' elseif stDACmode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S27>:1:7' LKA_Action_Indication=uint8(3); */
    rtb_LKA_Action_Indication_j = 3U;
  } else {
    /* '<S27>:1:8' else */
    /* '<S27>:1:9' LKA_Action_Indication=uint8(0); */
    rtb_LKA_Action_Indication_j = 0U;
  }

  /* End of MATLAB Function: '<S8>/LKA_action_indication' */

  /* DataTypeConversion: '<S11>/Cast To Single10' incorporates:
   *  Constant: '<S544>/Constant'
   *  RelationalOperator: '<S544>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.DACMode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S4>/Cast To Single1' */
  LKAS_DW.CastToSingle1 = LKAS_DW.LFTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single2' */
  LKAS_DW.CastToSingle2 = LKAS_DW.RGTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single3' */
  LKAS_DW.CastToSingle3 = (float32)LKAS_DW.LDW_State_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single4' */
  LKAS_DW.CastToSingle4 = (float32)LKAS_DW.LKA_State_Mon;

  /* S-Function (scanpack): '<S4>/CAN Pack' */
  /* S-Function (scanpack): '<S4>/CAN Pack' */
  LKAS_DW.CANPack.ID = 1U;
  LKAS_DW.CANPack.Length = 8U;
  LKAS_DW.CANPack.Extended = 0U;
  LKAS_DW.CANPack.Remote = 0;
  LKAS_DW.CANPack.Data[0] = 0;
  LKAS_DW.CANPack.Data[1] = 0;
  LKAS_DW.CANPack.Data[2] = 0;
  LKAS_DW.CANPack.Data[3] = 0;
  LKAS_DW.CANPack.Data[4] = 0;
  LKAS_DW.CANPack.Data[5] = 0;
  LKAS_DW.CANPack.Data[6] = 0;
  LKAS_DW.CANPack.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle1;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[1] = LKAS_DW.CANPack.Data[1] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[0] = LKAS_DW.CANPack.Data[0] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle2;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[3] = LKAS_DW.CANPack.Data[3] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[2] = LKAS_DW.CANPack.Data[2] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle3;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[5] = LKAS_DW.CANPack.Data[5] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[4] = LKAS_DW.CANPack.Data[4] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle4;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[7] = LKAS_DW.CANPack.Data[7] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[6] = LKAS_DW.CANPack.Data[6] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single5' */
  LKAS_DW.CastToSingle5 = LKAS_DW.LKA_ExitFlg_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single6' */
  LKAS_DW.CastToSingle6 = LKAS_DW.LKA_SampleTime_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single7' */
  LKAS_DW.CastToSingle7 = LKAS_DW.T1_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single8' */
  LKAS_DW.CastToSingle8 = LKAS_DW.Disable_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  LKAS_DW.CANPack1.ID = 2U;
  LKAS_DW.CANPack1.Length = 8U;
  LKAS_DW.CANPack1.Extended = 0U;
  LKAS_DW.CANPack1.Remote = 0;
  LKAS_DW.CANPack1.Data[0] = 0;
  LKAS_DW.CANPack1.Data[1] = 0;
  LKAS_DW.CANPack1.Data[2] = 0;
  LKAS_DW.CANPack1.Data[3] = 0;
  LKAS_DW.CANPack1.Data[4] = 0;
  LKAS_DW.CANPack1.Data[5] = 0;
  LKAS_DW.CANPack1.Data[6] = 0;
  LKAS_DW.CANPack1.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle5;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[1] = LKAS_DW.CANPack1.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[0] = LKAS_DW.CANPack1.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle6;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[3] = LKAS_DW.CANPack1.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[2] = LKAS_DW.CANPack1.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle7;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[5] = LKAS_DW.CANPack1.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[4] = LKAS_DW.CANPack1.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle8;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[7] = LKAS_DW.CANPack1.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[6] = LKAS_DW.CANPack1.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack' */
    if ((8 == LKAS_DW.CANPack.Length) && (LKAS_DW.CANPack.ID != INVALID_CAN_ID) )
    {
      if ((1 == LKAS_DW.CANPack.ID) && (0U == LKAS_DW.CANPack.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
    if ((8 == LKAS_DW.CANPack1.Length) && (LKAS_DW.CANPack1.ID != INVALID_CAN_ID)
        ) {
      if ((2 == LKAS_DW.CANPack1.ID) && (0U == LKAS_DW.CANPack1.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
    if ((8 == LKAS_ConstB.CANPack2.Length) && (LKAS_ConstB.CANPack2.ID !=
         INVALID_CAN_ID) ) {
      if ((3 == LKAS_ConstB.CANPack2.ID) && (0U == LKAS_ConstB.CANPack2.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack2.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack2.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07L_100 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
    if ((8 == LKAS_ConstB.CANPack3.Length) && (LKAS_ConstB.CANPack3.ID !=
         INVALID_CAN_ID) ) {
      if ((4 == LKAS_ConstB.CANPack3.ID) && (0U == LKAS_ConstB.CANPack3.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08L_100 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack4' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack4' */
    if ((8 == LKAS_ConstB.CANPack4.Length) && (LKAS_ConstB.CANPack4.ID !=
         INVALID_CAN_ID) ) {
      if ((4 == LKAS_ConstB.CANPack4.ID) && (0U == LKAS_ConstB.CANPack4.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack4.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob09H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack4.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack4.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob09L_100 = result;
            }
          }
        }
      }
    }
  }

  /* RelationalOperator: '<S16>/Compare' incorporates:
   *  Constant: '<S16>/Constant'
   */
  rtb_Compare_ap = (rtb_IMAPve_d_TCU_Actual_Gear > ((uint8)3U));

  /* RelationalOperator: '<S13>/Compare' incorporates:
   *  Constant: '<S13>/Constant'
   */
  rtb_Compare_cc = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

  /* Switch: '<S53>/Switch' incorporates:
   *  DataTypeConversion: '<S62>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_o = rtb_R0_Type;
  } else {
    rtb_R0_Type_o = rtb_L0_Type;
  }

  /* Switch: '<S53>/Switch1' incorporates:
   *  Constant: '<S59>/Constant'
   *  DataTypeConversion: '<S60>/Cast To Single5'
   *  Switch: '<S59>/Switch3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_h = rtb_L0_Type;

    /* DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     */
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q();

    /* Switch: '<S55>/Switch1' incorporates:
     *  Constant: '<S55>/Constant1'
     */
    if (rtb_L0_Type >= ((uint8)2U)) {
      rtb_L1_Q = (uint16)((uint8)3U);
    } else {
      rtb_L1_Q = (uint16)rtb_L0_Type;
    }

    /* End of Switch: '<S55>/Switch1' */
  } else {
    rtb_L0_Type_h = rtb_R0_Type;
    rtb_L1_Q = ((uint16)0U);
  }

  /* DataTypeConversion: '<S52>/Cast To Single57' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   */
  rtb_L0_C1_p = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   */
  rtb_L0_C1 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR();

  /* Switch: '<S61>/Switch3' incorporates:
   *  Constant: '<S61>/Constant'
   *  DataTypeConversion: '<S52>/Cast To Single66'
   *  Switch: '<S53>/Switch'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    /* DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q();

    /* Switch: '<S56>/Switch1' incorporates:
     *  Constant: '<S56>/Constant1'
     */
    if (rtb_L0_Type >= ((uint8)2U)) {
      rtb_R1_Q = (uint16)((uint8)3U);
    } else {
      rtb_R1_Q = (uint16)rtb_L0_Type;
    }

    /* End of Switch: '<S56>/Switch1' */
    rtb_R0_VR_a = rtb_L0_C1_p;
  } else {
    rtb_R1_Q = ((uint16)0U);
    rtb_R0_VR_a = rtb_L0_C1;
  }

  /* End of Switch: '<S61>/Switch3' */

  /* Switch: '<S53>/Switch1' incorporates:
   *  DataTypeConversion: '<S52>/Cast To Single66'
   *  DataTypeConversion: '<S60>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_g = rtb_L0_C1;
  } else {
    rtb_L0_VR_g = rtb_L0_C1_p;
  }

  /* DataTypeConversion: '<S52>/Cast To Single75' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  rtb_L0_C1_p = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_W_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_W'
   */
  rtb_L0_C1 = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W();

  /* Switch: '<S53>/Switch' incorporates:
   *  DataTypeConversion: '<S52>/Cast To Single71'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_f = rtb_L0_C1_p;
  } else {
    rtb_R0_W_f = rtb_L0_C1;
  }

  /* Switch: '<S53>/Switch1' incorporates:
   *  DataTypeConversion: '<S52>/Cast To Single71'
   *  DataTypeConversion: '<S60>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_e = rtb_L0_C1;
  } else {
    rtb_L0_W_e = rtb_L0_C1_p;
  }

  /* Math: '<S46>/Mod1' incorporates:
   *  Constant: '<S46>/Constant7'
   */
  if (((sint32)((uint8)3U)) != 0) {
    rtb_Mod1 %= ((uint8)3U);
  }

  /* End of Math: '<S46>/Mod1' */

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LDW_Warn_Mode'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode();

  /* MinMax: '<S46>/Max1' */
  if (rtb_Mod1 > rtb_L0_Type) {
    rtb_LDW_Warn_Mode = rtb_Mod1;
  } else {
    rtb_LDW_Warn_Mode = rtb_L0_Type;
  }

  /* End of MinMax: '<S46>/Max1' */

  /* DataTypeConversion: '<S1>/IMAPve_d_APA_AutoPark_WorkSt_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_APA_AutoPark_WorkSt'
   */
  rtb_IMAPve_d_APA_AutoPark_WorkS = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Override'
   */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_ESA_State'
   */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State'
   */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag'
   */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    ();

  /* RelationalOperator: '<S17>/Compare' incorporates:
   *  Constant: '<S17>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_TrqLim_State'
   */
  rtb_Compare_i4c = (((uint8)
                      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State
                      ()) == ((uint8)0U));

  /* RelationalOperator: '<S18>/Compare' incorporates:
   *  Constant: '<S18>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_Trq_State'
   */
  rtb_Compare_d = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State
                    ()) == ((uint8)1U));

  /* RelationalOperator: '<S19>/Compare' incorporates:
   *  Constant: '<S19>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid'
   */
  rtb_Compare_d2 = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S21>/Compare' incorporates:
   *  Constant: '<S21>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid'
   */
  rtb_Compare_b4 = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S12>/Compare' incorporates:
   *  Constant: '<S12>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid'
   */
  rtb_Compare_js = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid
                     ()) != ((uint8)1U));

  /* RelationalOperator: '<S20>/Compare' incorporates:
   *  Constant: '<S20>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid'
   */
  rtb_Compare_fa = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid
                     ()) == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Fusion_Status'
   */
  rtb_IMAPve_d_Fusion_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status();

  /* DataTypeConversion: '<S52>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   */
  rtb_L1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_Work_State'
   */
  rtb_IMAPve_d_MP5_Work_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State
    ();

  /* DataTypeConversion: '<S52>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   */
  rtb_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type();

  /* RelationalOperator: '<S14>/Compare' incorporates:
   *  Constant: '<S14>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Clb_State'
   */
  rtb_Compare_h = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State
                    ()) == ((uint8)0U));

  /* RelationalOperator: '<S15>/Compare' incorporates:
   *  Constant: '<S15>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Trim_State'
   */
  rtb_Compare_nl = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State
                     ()) == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SWS_Failure_Status'
   */
  rtb_IMAPve_d_SWS_Failure_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Sensor_Status'
   */
  rtb_IMAPve_d_Sensor_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_TCU_Available'
   */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  rtb_IMAPve_g_EMS_RealPedal = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  rtb_IMAPve_g_EPS_LKA_Current = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SteeringAngle'
   */
  rtb_IMAPve_g_EPS_SteeringAngle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  rtb_IMAPve_g_ESC_Brake_Press = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  rtb_IMAPve_g_ESC_UnYawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  rtb_IMAPve_g_ESC_YawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate();

  /* DataTypeConversion: '<S52>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   *  UnaryMinus: '<S52>/Unary Minus8'
   */
  rtb_L1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   *  UnaryMinus: '<S52>/Unary Minus9'
   */
  rtb_L1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   *  UnaryMinus: '<S52>/Unary Minus10'
   */
  rtb_L1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   *  UnaryMinus: '<S52>/Unary Minus11'
   */
  rtb_L1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single78' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  rtb_L1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR();

  /* DataTypeConversion: '<S52>/Cast To Single74' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  rtb_L1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W();

  /* DataTypeConversion: '<S52>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   *  UnaryMinus: '<S52>/Unary Minus14'
   */
  rtb_R1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   *  UnaryMinus: '<S52>/Unary Minus15'
   */
  rtb_R1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   *  UnaryMinus: '<S52>/Unary Minus12'
   */
  rtb_R1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   *  UnaryMinus: '<S52>/Unary Minus13'
   */
  rtb_R1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3
    ()));

  /* DataTypeConversion: '<S52>/Cast To Single50' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  rtb_R1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR();

  /* DataTypeConversion: '<S52>/Cast To Single52' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  rtb_R1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W();

  /* Switch: '<S551>/Switch1' incorporates:
   *  Constant: '<S551>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S551>/Switch1' */

  /* Switch: '<S551>/Switch12' incorporates:
   *  Constant: '<S551>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S551>/Switch12' */

  /* Switch: '<S552>/Switch56' incorporates:
   *  Constant: '<S552>/LLSMConClb14'
   *
   * Block description for '<S552>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_p != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_p;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S552>/Switch56' */

  /* Switch: '<S552>/Switch51' incorporates:
   *  Constant: '<S552>/LLSMConClb15'
   *
   * Block description for '<S552>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_h != 0.0F) {
    rtb_LL_DvtComp_C_p = LKAS_ConstB.DataTypeConversion25_h;
  } else {
    rtb_LL_DvtComp_C_p = LL_DvtComp_C;
  }

  /* End of Switch: '<S552>/Switch51' */

  /* Switch: '<S552>/Switch52' incorporates:
   *  Constant: '<S552>/LLSMConClb16'
   *
   * Block description for '<S552>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36_b != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36_b;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S552>/Switch52' */

  /* Switch: '<S552>/Switch46' incorporates:
   *  Constant: '<S552>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S552>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_c != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_c;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S552>/Switch46' */

  /* Update for Delay: '<S68>/Delay' */
  LKAS_DW.Delay_DSTATE = rtb_Saturation1_p1;

  /* Update for Memory: '<S72>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Add1;

  /* Update for Memory: '<S64>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = rtb_L0_C0;

  /* Update for Memory: '<S64>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = rtb_Saturation;

  /* Update for Memory: '<S65>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_b = rtb_R0_C0;

  /* Update for Memory: '<S65>/Memory' */
  LKAS_DW.Memory_PreviousInput_op = rtb_offset;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S77>/Delay' */
    LKAS_DW.Delay_DSTATE_l = LKAS_DW.LKASM_stLKAActvFlg;

    /* Update for Memory: '<S516>/Memory' */
    LKAS_DW.Memory_PreviousInput_a = rtb_Saturation_d;

    /* Update for Memory: '<S459>/Memory' */
    LKAS_DW.Memory_PreviousInput_e = rtb_Saturation_k;

    /* Update for UnitDelay: '<S389>/Delay Input1'
     *
     * Block description for '<S389>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_ds;

    /* Update for UnitDelay: '<S387>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_e = LKAS_DW.RelationalOperator_h;

    /* Update for UnitDelay: '<S388>/Delay Input1'
     *
     * Block description for '<S388>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_a = rtb_Compare_e3;

    /* Update for Delay: '<S78>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.LKASM_stLKAState;

    /* Update for UnitDelay: '<S350>/Delay Input1'
     *
     * Block description for '<S350>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_d = rtb_Compare_ik;

    /* Update for UnitDelay: '<S348>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_pg = LKAS_DW.RelationalOperator_l;

    /* Update for UnitDelay: '<S349>/Delay Input1'
     *
     * Block description for '<S349>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_p = rtb_Compare_pr;

    /* Update for Memory: '<S315>/Memory' */
    LKAS_DW.Memory_PreviousInput_c0 = LKAS_DW.RelationalOperator_l;

    /* Update for Delay: '<S78>/Delay' */
    LKAS_DW.Delay_DSTATE_e = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S78>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.LDWSM_stLDWState;

    /* Update for Memory: '<S363>/Memory' */
    LKAS_DW.Memory_PreviousInput_hq = rtb_LDW_State;

    /* Update for Memory: '<S289>/Memory' */
    LKAS_DW.Memory_PreviousInput_g = rtb_Merge1_p;

    /* Update for Memory: '<S325>/Memory' */
    LKAS_DW.Memory_PreviousInput_d = rtb_Merge1_c;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S76>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S104>/Memory' */
      LKAS_DW.Memory_PreviousInput_ou = rtb_Saturation2;

      /* Update for Memory: '<S141>/Memory' */
      LKAS_DW.Memory_PreviousInput_gz = rtb_Saturation1_m;

      /* Update for Memory: '<S87>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_k = rtb_Saturation1_ln;

      /* Update for Memory: '<S140>/Memory' */
      LKAS_DW.Memory_PreviousInput_ox = rtb_Saturation1_h;

      /* Update for Memory: '<S142>/Memory' */
      LKAS_DW.Memory_PreviousInput_lk = rtb_Saturation1_o;

      /* Update for Memory: '<S136>/Memory' */
      LKAS_DW.Memory_PreviousInput_f = rtb_Add_js;

      /* Update for Memory: '<S139>/Memory' */
      LKAS_DW.Memory_PreviousInput_g1 = rtb_Saturation1_hi;

      /* Update for Memory: '<S138>/Memory' */
      LKAS_DW.Memory_PreviousInput_ez = rtb_Saturation1_ip;

      /* Update for Memory: '<S137>/Memory' */
      LKAS_DW.Memory_PreviousInput_l4 = rtb_Saturation1_c;

      /* Update for Memory: '<S114>/Memory' */
      LKAS_DW.Memory_PreviousInput_at = rtb_Add_mb;

      /* Update for Memory: '<S105>/Memory' */
      LKAS_DW.Memory_PreviousInput_c5 = rtb_Saturation2_b;

      /* Update for Memory: '<S106>/Memory' */
      LKAS_DW.Memory_PreviousInput_a4 = rtb_Saturation2_c;

      /* Update for Memory: '<S103>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_g = rtb_Saturation_go;

      /* Update for Memory: '<S197>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_h = rtb_Saturation_j;

      /* Update for Memory: '<S180>/Memory' */
      LKAS_DW.Memory_PreviousInput_cs = rtb_Add1_o;

      /* Update for UnitDelay: '<S178>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_i = rtb_Switch2_dt;

      /* Update for Memory: '<S186>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_e = rtb_Saturation_gq;

      /* Update for Memory: '<S192>/Memory' */
      LKAS_DW.Memory_PreviousInput_ke = rtb_Saturation1_g;

      /* Update for UnitDelay: '<S196>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_k = rtb_Switch_gc;

      /* Update for Memory: '<S196>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_k = rtb_Saturation_bs;

      /* Update for UnitDelay: '<S173>/Delay Input2'
       *
       * Block description for '<S173>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_e = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S173>/Memory' */
      LKAS_DW.Memory_PreviousInput_n = rtb_Saturation2_p;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S78>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.LKA_Mode;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S545>/Delay Input2'
   *
   * Block description for '<S545>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_L0_C2;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_L0_Q);

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_TCU_ActualGear);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single2'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)((uint8)rtb_L0_C2_j));

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single3'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    rtb_CastToSingle3);

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single4'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning
    ((UInt8)rtb_Hands_Off_Warning_j);

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single5'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_LKA_Action_Indication_j);

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single6'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status
    ((UInt8)rtb_IMAPve_d_Camera_Status);

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq
    ((UInt8)rtb_R0_Q);

  /* Switch: '<S546>/Switch2' incorporates:
   *  Constant: '<S542>/Constant3'
   *  Constant: '<S542>/Constant4'
   *  RelationalOperator: '<S546>/LowerRelop1'
   *  RelationalOperator: '<S546>/UpperRelop'
   *  Switch: '<S546>/Switch'
   */
  if (rtb_L0_C2 > 5.0F) {
    rtb_L0_C2 = 5.0F;
  } else {
    if (rtb_L0_C2 < (-5.0F)) {
      /* Switch: '<S546>/Switch' incorporates:
       *  Constant: '<S542>/Constant4'
       */
      rtb_L0_C2 = (-5.0F);
    }
  }

  /* End of Switch: '<S546>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_L0_C2);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single8'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control
    ((UInt8)rtb_IMAPve_d_SAS_Trim_State);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/x1'
   */
  if (rtb_Merge) {
    rtb_L0_C0 = LKAS_DW.OutputM;
  } else {
    rtb_L0_C0 = (float32)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_L0_C0);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' incorporates:
   *  DataTypeConversion: '<S5>/Cast To Single9'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    ((UInt8)LKAS_ConstB.EPS_LKA_Control);

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_ob5H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5H_10_LKASve_g_ob5H_10
    (LKAS_DW.LKASve_g_ob5H_10);

  /* Outport: '<Root>/LKASve_g_ob5L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5L_10_LKASve_g_ob5L_10
    (LKAS_DW.LKASve_g_ob5L_10);

  /* Outport: '<Root>/LKASve_g_ob6H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6H_10_LKASve_g_ob6H_10
    (LKAS_DW.LKASve_g_ob6H_10);

  /* Outport: '<Root>/LKASve_g_ob6L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6L_10_LKASve_g_ob6L_10
    (LKAS_DW.LKASve_g_ob6L_10);

  /* Outport: '<Root>/LKASve_g_ob07H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07H_100_LKASve_g_ob07H_100
    (LKAS_DW.LKASve_g_ob07H_100);

  /* Outport: '<Root>/LKASve_g_ob07L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07L_100_LKASve_g_ob07L_100
    (LKAS_DW.LKASve_g_ob07L_100);

  /* Outport: '<Root>/LKASve_g_ob08H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08H_100_LKASve_g_ob08H_100
    (LKAS_DW.LKASve_g_ob08H_100);

  /* Outport: '<Root>/LKASve_g_ob08L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08L_100_LKASve_g_ob08L_100
    (LKAS_DW.LKASve_g_ob08L_100);

  /* Outport: '<Root>/LKASve_g_ob09H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob09H_100_LKASve_g_ob09H_100
    (LKAS_DW.LKASve_g_ob09H_100);

  /* Outport: '<Root>/LKASve_g_ob09L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob09L_100_LKASve_g_ob09L_100
    (LKAS_DW.LKASve_g_ob09L_100);
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S363>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S87>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S195>/If' */
  LKAS_DW.If_ActiveSubsystem_j = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack' */

  /*-----------S-Function Block: <S4>/CAN Unpack -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack1' */

  /*-----------S-Function Block: <S4>/CAN Unpack1 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack2' */

  /*-----------S-Function Block: <S4>/CAN Unpack2 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack3' */

  /*-----------S-Function Block: <S4>/CAN Unpack3 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack4' */

  /*-----------S-Function Block: <S4>/CAN Unpack4 -----------------*/

  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* ConstCode for Constant: '<S2>/Version' */
  ob_LKA_Version = 211116.0F;

  /* End of ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S72>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* InitializeConditions for Memory: '<S64>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = (-1.75F);

  /* InitializeConditions for Memory: '<S64>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = (-1.75F);

  /* InitializeConditions for Memory: '<S65>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_b = 1.75F;

  /* InitializeConditions for Memory: '<S65>/Memory' */
  LKAS_DW.Memory_PreviousInput_op = 1.75F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S77>/Delay' */
  LKAS_DW.Delay_DSTATE_l = ((uint8)0U);

  /* InitializeConditions for Memory: '<S516>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S459>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = 0.0F;

  /* InitializeConditions for UnitDelay: '<S389>/Delay Input1'
   *
   * Block description for '<S389>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S387>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_e = false;

  /* InitializeConditions for UnitDelay: '<S388>/Delay Input1'
   *
   * Block description for '<S388>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_a = false;

  /* InitializeConditions for Delay: '<S78>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for UnitDelay: '<S350>/Delay Input1'
   *
   * Block description for '<S350>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_d = false;

  /* InitializeConditions for UnitDelay: '<S348>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_pg = false;

  /* InitializeConditions for UnitDelay: '<S349>/Delay Input1'
   *
   * Block description for '<S349>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_p = false;

  /* InitializeConditions for Memory: '<S315>/Memory' */
  LKAS_DW.Memory_PreviousInput_c0 = false;

  /* InitializeConditions for Delay: '<S78>/Delay' */
  LKAS_DW.Delay_DSTATE_e = false;

  /* InitializeConditions for Delay: '<S78>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S363>/Memory' */
  LKAS_DW.Memory_PreviousInput_hq = ((uint8)0U);

  /* InitializeConditions for Memory: '<S289>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 0.0F;

  /* InitializeConditions for Memory: '<S325>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* InitializeConditions for Delay: '<S78>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S376>/Count 20s' */
  /* InitializeConditions for Memory: '<S384>/Memory' */
  LKAS_DW.Memory_PreviousInput_dy = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S376>/Count 20s' */

  /* SystemInitialize for Enabled SubSystem: '<S377>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S386>/Memory' */
  LKAS_DW.Memory_PreviousInput_k = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S377>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S387>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S393>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S387>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S399>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S406>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S399>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S315>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S346>/Memory' */
  LKAS_DW.Memory_PreviousInput_l = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S315>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S315>/Count' */
  /* InitializeConditions for Memory: '<S345>/Memory' */
  LKAS_DW.Memory_PreviousInput_jt = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S315>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S348>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S354>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S348>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S316>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S360>/Memory' */
  LKAS_DW.Memory_PreviousInput_mg = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S316>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S363>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S396>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S363>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S326>/Sum Condition' */
  /* InitializeConditions for Memory: '<S332>/Memory' */
  LKAS_DW.Memory_PreviousInput_em = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S326>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S274>/Count_5s3' */
  /* InitializeConditions for Memory: '<S541>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S274>/Count_5s3' */

  /* SystemInitialize for Enabled SubSystem: '<S274>/Count_5s2' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s2);

  /* End of SystemInitialize for SubSystem: '<S274>/Count_5s2' */

  /* SystemInitialize for Enabled SubSystem: '<S274>/Count_5s1' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s1);

  /* End of SystemInitialize for SubSystem: '<S274>/Count_5s1' */

  /* SystemInitialize for Enabled SubSystem: '<S251>/Subsystem' */
  /* InitializeConditions for Memory: '<S255>/Memory' */
  LKAS_DW.Memory_PreviousInput_a4q = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S251>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S104>/Memory' */
  LKAS_DW.Memory_PreviousInput_ou = 0.0F;

  /* InitializeConditions for Memory: '<S141>/Memory' */
  LKAS_DW.Memory_PreviousInput_gz = ((uint16)0U);

  /* InitializeConditions for Memory: '<S87>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_k = ((uint8)0U);

  /* InitializeConditions for Memory: '<S140>/Memory' */
  LKAS_DW.Memory_PreviousInput_ox = ((uint16)0U);

  /* InitializeConditions for Memory: '<S142>/Memory' */
  LKAS_DW.Memory_PreviousInput_lk = ((uint16)0U);

  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = ((uint16)0U);

  /* InitializeConditions for Memory: '<S139>/Memory' */
  LKAS_DW.Memory_PreviousInput_g1 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S138>/Memory' */
  LKAS_DW.Memory_PreviousInput_ez = ((uint16)0U);

  /* InitializeConditions for Memory: '<S137>/Memory' */
  LKAS_DW.Memory_PreviousInput_l4 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S114>/Memory' */
  LKAS_DW.Memory_PreviousInput_at = 0.0F;

  /* InitializeConditions for Memory: '<S105>/Memory' */
  LKAS_DW.Memory_PreviousInput_c5 = 0.0F;

  /* InitializeConditions for Memory: '<S106>/Memory' */
  LKAS_DW.Memory_PreviousInput_a4 = 0.0F;

  /* InitializeConditions for Memory: '<S103>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_g = 0.0F;

  /* InitializeConditions for Memory: '<S197>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_h = 0.0F;

  /* InitializeConditions for Memory: '<S180>/Memory' */
  LKAS_DW.Memory_PreviousInput_cs = 0.0F;

  /* InitializeConditions for UnitDelay: '<S178>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_i = 0.0F;

  /* InitializeConditions for Memory: '<S186>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_e = 0.0F;

  /* InitializeConditions for Memory: '<S192>/Memory' */
  LKAS_DW.Memory_PreviousInput_ke = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S196>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_k = 0.0F;

  /* InitializeConditions for Memory: '<S196>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_k = 0.0F;

  /* InitializeConditions for UnitDelay: '<S173>/Delay Input2'
   *
   * Block description for '<S173>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_e = 0.0F;

  /* InitializeConditions for Memory: '<S173>/Memory' */
  LKAS_DW.Memory_PreviousInput_n = ((uint16)0U);

  /* SystemInitialize for IfAction SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)'
   *
   * Block description for '<S87>/LKA Motion Planning Calculation (LKAMPCal)':
   *  Block Name: LKA Motion Planning Calculation
   *  Ab.: LKAMPCal
   *  No.: 1.2.3.2
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  LKAMotionPlanningCalculati_Init();

  /* End of SystemInitialize for SubSystem: '<S87>/LKA Motion Planning Calculation (LKAMPCal)' */

  /* SystemInitialize for Enabled SubSystem: '<S105>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S107>/Memory' */
  LKAS_DW.Memory_PreviousInput_en = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S105>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S94>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S94>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S106>/Moving Standard Deviation1' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S106>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S106>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_c);

  /* End of SystemInitialize for SubSystem: '<S106>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S106>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2_d);

  /* End of SystemInitialize for SubSystem: '<S106>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S106>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_j);

  /* End of SystemInitialize for SubSystem: '<S106>/Sum Condition' */

  /* SystemInitialize for IfAction SubSystem: '<S195>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S205>/Delay Input1'
   *
   * Block description for '<S205>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_n = false;

  /* InitializeConditions for Memory: '<S201>/Memory' */
  LKAS_DW.Memory_PreviousInput_og = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S195>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S195>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S213>/Delay Input1'
   *
   * Block description for '<S213>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_j = false;

  /* InitializeConditions for Memory: '<S202>/Memory' */
  LKAS_DW.Memory_PreviousInput_p2 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S195>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S195>/Merge' */
  LKAS_DW.Merge_a = 1.0F;

  /* SystemInitialize for Merge: '<S195>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S80>/Merge' */
  LKAS_DW.Merge_c = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S80>/Sum Condition' */
  /* InitializeConditions for Memory: '<S84>/Memory' */
  LKAS_DW.Memory_PreviousInput_h3 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S80>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S542>/Subsystem' */
  /* InitializeConditions for Delay: '<S547>/Delay1' */
  LKAS_DW.Delay1_DSTATE = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S542>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S28>/Count 15s' */
  /* InitializeConditions for Memory: '<S40>/Memory' */
  LKAS_DW.Memory_PreviousInput_ew = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S28>/Count 15s' */

  /* SystemInitialize for Enabled SubSystem: '<S28>/Count 10s' */
  /* InitializeConditions for Memory: '<S39>/Memory' */
  LKAS_DW.Memory_PreviousInput_m2 = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S28>/Count 10s' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
