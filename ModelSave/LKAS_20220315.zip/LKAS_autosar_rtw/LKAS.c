/*
 * File: LKAS.c
 *
 * Code generated for Simulink model 'LKAS'.
 *
 * Model version                  : 1.74
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Mar 15 09:47:20 2022
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. ROM efficiency
 *    3. RAM efficiency
 *    4. Traceability
 *    5. Safety precaution
 *    6. Debugging
 *    7. MISRA C:2012 guidelines
 *    8. Polyspace
 * Validation result: Not run
 */

#include "LKAS.h"
#include "LKAS_private.h"

/* Named constants for Chart: '<S82>/LDW_State_Machine' */
#define LKAS_IN_Fault                  ((uint8)1U)
#define LKAS_IN_LDWEnable              ((uint8)1U)
#define LKAS_IN_LDWLeftActive          ((uint8)2U)
#define LKAS_IN_LDWRightActive         ((uint8)3U)
#define LKAS_IN_LDWSelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD        ((uint8)0U)
#define LKAS_IN_Normal                 ((uint8)2U)
#define LKAS_IN_SysOff                 ((uint8)2U)
#define LKAS_IN_SysOn                  ((uint8)3U)
#define LKAS_IN_Unavailable            ((uint8)1U)
#define LKAS_IN_Unselected             ((uint8)2U)

/* Named constants for Chart: '<S82>/LKA_State_Machine' */
#define LKAS_IN_Fault_i                ((uint8)1U)
#define LKAS_IN_LKAEnable              ((uint8)1U)
#define LKAS_IN_LKALeftActive          ((uint8)2U)
#define LKAS_IN_LKARightActive         ((uint8)3U)
#define LKAS_IN_LKASelected            ((uint8)1U)
#define LKAS_IN_NO_ACTIVE_CHILD_j      ((uint8)0U)
#define LKAS_IN_Normal_p               ((uint8)2U)
#define LKAS_IN_SysOff_i               ((uint8)2U)
#define LKAS_IN_SysOn_h                ((uint8)3U)
#define LKAS_IN_Unavailable_h          ((uint8)1U)
#define LKAS_IN_Unselected_l           ((uint8)2U)

/* Named constants for Chart: '<S51>/LaneReconstructSM' */
#define LKAS_IN_DoubleLost             ((uint8)1U)
#define LKAS_IN_LeftLost               ((uint8)2U)
#define LKAS_IN_NoLaneLost             ((uint8)3U)
#define LKAS_IN_RightLost              ((uint8)4U)

/* Exported data definition */

/* Definition for custom storage class: Default */
float32 ob_LKA_Disable_Reason;
float32 ob_LKA_LKADeactvCSyn;
float32 ob_LKA_Version;

/* Block signals and states (default storage) */
DW_LKAS_T LKAS_DW;

/*
 * System initialize for enable system:
 *    '<S28>/Sum Condition1'
 *    '<S28>/Sum Condition2'
 *    '<S403>/Sum Condition1'
 */
void LKAS_SumCondition1_Init(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S39>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S28>/Sum Condition1'
 *    '<S28>/Sum Condition2'
 *    '<S403>/Sum Condition1'
 */
void LKAS_SumCondition1_Reset(DW_SumCondition1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S39>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S28>/Sum Condition1'
 *    '<S28>/Sum Condition2'
 *    '<S403>/Sum Condition1'
 */
void LKAS_SumCondition1_Disable(boolean *rty_Out, DW_SumCondition1_LKAS_T
  *localDW)
{
  /* Outputs for Enabled SubSystem: '<S28>/Sum Condition1' incorporates:
   *  EnablePort: '<S39>/state = reset'
   */
  /* Disable for Outport: '<S39>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S28>/Sum Condition1' */
  localDW->SumCondition1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S28>/Sum Condition1'
 *    '<S28>/Sum Condition2'
 *    '<S403>/Sum Condition1'
 */
void LKAS_SumCondition1(boolean rtu_statereset, float32 rtu_SampleTime, float32
  rtu_Sum, boolean *rty_Out, DW_SumCondition1_LKAS_T *localDW)
{
  float32 rtb_Saturation_ao;

  /* Outputs for Enabled SubSystem: '<S28>/Sum Condition1' incorporates:
   *  EnablePort: '<S39>/state = reset'
   */
  if (rtu_statereset) {
    if (!localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Reset(localDW);
      localDW->SumCondition1_MODE = true;
    }

    /* Sum: '<S39>/Add1' incorporates:
     *  Memory: '<S39>/Memory'
     */
    rtb_Saturation_ao = rtu_SampleTime + localDW->Memory_PreviousInput;

    /* Saturate: '<S39>/Saturation' */
    if (rtb_Saturation_ao > 60.0F) {
      rtb_Saturation_ao = 60.0F;
    } else {
      if (rtb_Saturation_ao < 0.0F) {
        rtb_Saturation_ao = 0.0F;
      }
    }

    /* End of Saturate: '<S39>/Saturation' */

    /* RelationalOperator: '<S39>/Relational Operator' */
    *rty_Out = (rtb_Saturation_ao >= rtu_Sum);

    /* Update for Memory: '<S39>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_ao;
  } else {
    if (localDW->SumCondition1_MODE) {
      LKAS_SumCondition1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S28>/Sum Condition1' */
}

/*
 * Output and update for action system:
 *    '<S84>/If Action Subsystem2'
 *    '<S129>/If Action Subsystem3'
 *    '<S130>/If Action Subsystem3'
 *    '<S131>/If Action Subsystem3'
 *    '<S132>/If Action Subsystem3'
 *    '<S133>/If Action Subsystem3'
 *    '<S141>/If Action Subsystem3'
 *    '<S173>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2(float32 *rty_Out1)
{
  /* SignalConversion: '<S87>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
   *  Constant: '<S87>/Constant'
   */
  *rty_Out1 = 0.0F;
}

/* System initialize for atomic system: '<S98>/Moving Standard Deviation2' */
void L_MovingStandardDeviation2_Init(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S106>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S106>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* System reset for atomic system: '<S98>/Moving Standard Deviation2' */
void MovingStandardDeviation2_Reset(DW_MovingStandardDeviation2_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S106>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S106>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;

  /* InitializeConditions for Memory: '<S106>/Memory3' */
  localDW->Memory3_PreviousInput = 0.0F;
}

/* Output and update for atomic system: '<S98>/Moving Standard Deviation2' */
void LKAS_MovingStandardDeviation2(float32 rtu_In1, float32 *rty_Out2, float32
  *rty_Out1, DW_MovingStandardDeviation2_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_ka;
  float32 rtb_Delay1_n;
  float32 rtb_Delay10;
  float32 rtb_Delay11;
  float32 rtb_Delay12;
  float32 rtb_Delay13;
  float32 rtb_Delay14;
  float32 rtb_Delay15;
  float32 rtb_Delay16;
  float32 rtb_Delay17;
  float32 rtb_Delay18;
  float32 rtb_Delay19;
  float32 rtb_Delay2;
  float32 rtb_Delay20;
  float32 rtb_Delay21;
  float32 rtb_Delay22;
  float32 rtb_Delay23;
  float32 rtb_Delay24;
  float32 rtb_Delay25;
  float32 rtb_Delay26;
  float32 rtb_Delay27;
  float32 rtb_Delay28;
  float32 rtb_Delay29;
  float32 rtb_Delay3;
  float32 rtb_Delay30;
  float32 rtb_Delay31;
  float32 rtb_Delay32;
  float32 rtb_Delay33;
  float32 rtb_Delay34;
  float32 rtb_Delay35;
  float32 rtb_Delay36;
  float32 rtb_Delay37;
  float32 rtb_Delay38;
  float32 rtb_Delay39;
  float32 rtb_Delay4;
  float32 rtb_Delay40;
  float32 rtb_Delay41;
  float32 rtb_Delay42;
  float32 rtb_Delay43;
  float32 rtb_Delay44;
  float32 rtb_Delay45;
  float32 rtb_Delay46;
  float32 rtb_Delay48;
  float32 rtb_Delay5;
  float32 rtb_Delay6;
  float32 rtb_Delay7;
  float32 rtb_Delay8;
  float32 rtb_Delay9;
  float32 rtb_SumofElements;
  float32 rtb_TmpSignalConversionAtStanda[50];
  sint32 tmp;
  sint32 i;
  float32 rtb_Saturation_ek;

  /* Delay: '<S106>/Delay' */
  rtb_Delay_ka = localDW->Delay_DSTATE;

  /* Delay: '<S106>/Delay1' */
  rtb_Delay1_n = localDW->Delay1_DSTATE;

  /* Delay: '<S106>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S106>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S106>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S106>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S106>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S106>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S106>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S106>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S106>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S106>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S106>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S106>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S106>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S106>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S106>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S106>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S106>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S106>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S106>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Delay: '<S106>/Delay28' */
  rtb_Delay28 = localDW->Delay28_DSTATE;

  /* Delay: '<S106>/Delay29' */
  rtb_Delay29 = localDW->Delay29_DSTATE;

  /* Delay: '<S106>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S106>/Delay30' */
  rtb_Delay30 = localDW->Delay30_DSTATE;

  /* Delay: '<S106>/Delay31' */
  rtb_Delay31 = localDW->Delay31_DSTATE;

  /* Delay: '<S106>/Delay32' */
  rtb_Delay32 = localDW->Delay32_DSTATE;

  /* Delay: '<S106>/Delay33' */
  rtb_Delay33 = localDW->Delay33_DSTATE;

  /* Delay: '<S106>/Delay34' */
  rtb_Delay34 = localDW->Delay34_DSTATE;

  /* Delay: '<S106>/Delay35' */
  rtb_Delay35 = localDW->Delay35_DSTATE;

  /* Delay: '<S106>/Delay36' */
  rtb_Delay36 = localDW->Delay36_DSTATE;

  /* Delay: '<S106>/Delay37' */
  rtb_Delay37 = localDW->Delay37_DSTATE;

  /* Delay: '<S106>/Delay38' */
  rtb_Delay38 = localDW->Delay38_DSTATE;

  /* Delay: '<S106>/Delay39' */
  rtb_Delay39 = localDW->Delay39_DSTATE;

  /* Delay: '<S106>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S106>/Delay40' */
  rtb_Delay40 = localDW->Delay40_DSTATE;

  /* Delay: '<S106>/Delay41' */
  rtb_Delay41 = localDW->Delay41_DSTATE;

  /* Delay: '<S106>/Delay42' */
  rtb_Delay42 = localDW->Delay42_DSTATE;

  /* Delay: '<S106>/Delay43' */
  rtb_Delay43 = localDW->Delay43_DSTATE;

  /* Delay: '<S106>/Delay44' */
  rtb_Delay44 = localDW->Delay44_DSTATE;

  /* Delay: '<S106>/Delay45' */
  rtb_Delay45 = localDW->Delay45_DSTATE;

  /* Delay: '<S106>/Delay46' */
  rtb_Delay46 = localDW->Delay46_DSTATE;

  /* Delay: '<S106>/Delay47' */
  rtb_SumofElements = localDW->Delay47_DSTATE;

  /* Delay: '<S106>/Delay48' */
  rtb_Delay48 = localDW->Delay48_DSTATE;

  /* Delay: '<S106>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S106>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S106>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S106>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S106>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S106>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_ka;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_n;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46;
  rtb_TmpSignalConversionAtStanda[49] = rtb_SumofElements;

  /* Sum: '<S106>/Sum of Elements' */
  tmp = 0;
  rtb_Saturation_ek = -0.0F;
  for (i = 0; i < 50; i++) {
    rtb_Saturation_ek += rtb_TmpSignalConversionAtStanda[i];
  }

  rtb_SumofElements = rtb_Saturation_ek;

  /* End of Sum: '<S106>/Sum of Elements' */

  /* Sum: '<S106>/Add2' incorporates:
   *  Constant: '<S106>/Constant'
   *  Memory: '<S106>/Memory3'
   */
  rtb_Saturation_ek = (float32)((uint8)(((uint32)((uint8)1U)) + ((uint32)((uint8)
    localDW->Memory3_PreviousInput))));

  /* Saturate: '<S106>/Saturation' */
  if (rtb_Saturation_ek > 50.0F) {
    rtb_Saturation_ek = 50.0F;
  } else {
    if (rtb_Saturation_ek < 1.0F) {
      rtb_Saturation_ek = 1.0F;
    }
  }

  /* End of Saturate: '<S106>/Saturation' */

  /* Product: '<S106>/Divide' */
  *rty_Out2 = rtb_SumofElements / rtb_Saturation_ek;

  /* S-Function (sdspstatfcns): '<S106>/Standard Deviation' incorporates:
   *  SignalConversion: '<S106>/TmpSignal ConversionAtStandard DeviationInport1'
   */
  while (tmp < 1) {
    localDW->StandardDeviation_AccVal = rtu_In1;
    localDW->StandardDeviation_SqData = rtu_In1 * rtu_In1;
    tmp = 1;
    for (i = 48; i >= 0; i--) {
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[tmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[tmp] *
        rtb_TmpSignalConversionAtStanda[tmp];
      tmp++;
    }

    *rty_Out1 = (localDW->StandardDeviation_SqData -
                 ((localDW->StandardDeviation_AccVal *
                   localDW->StandardDeviation_AccVal) / 50.0F)) / 49.0F;
    *rty_Out1 = sqrtf(fabsf(*rty_Out1));
    tmp = 1;
  }

  /* End of S-Function (sdspstatfcns): '<S106>/Standard Deviation' */

  /* Update for Delay: '<S106>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S106>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_ka;

  /* Update for Delay: '<S106>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S106>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S106>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S106>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S106>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S106>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S106>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S106>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S106>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S106>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28;

  /* Update for Delay: '<S106>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_n;

  /* Update for Delay: '<S106>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S106>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S106>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S106>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S106>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S106>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S106>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S106>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S106>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S106>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38;

  /* Update for Delay: '<S106>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S106>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29;

  /* Update for Delay: '<S106>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30;

  /* Update for Delay: '<S106>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31;

  /* Update for Delay: '<S106>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32;

  /* Update for Delay: '<S106>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33;

  /* Update for Delay: '<S106>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34;

  /* Update for Delay: '<S106>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35;

  /* Update for Delay: '<S106>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36;

  /* Update for Delay: '<S106>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S106>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48;

  /* Update for Delay: '<S106>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S106>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39;

  /* Update for Delay: '<S106>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40;

  /* Update for Delay: '<S106>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41;

  /* Update for Delay: '<S106>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42;

  /* Update for Delay: '<S106>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43;

  /* Update for Delay: '<S106>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44;

  /* Update for Delay: '<S106>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45;

  /* Update for Delay: '<S106>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46;

  /* Update for Delay: '<S106>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37;

  /* Update for Delay: '<S106>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S106>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S106>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S106>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S106>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;

  /* Update for Memory: '<S106>/Memory3' */
  localDW->Memory3_PreviousInput = rtb_Saturation_ek;
}

/*
 * Output and update for action system:
 *    '<S110>/If Action Subsystem3'
 *    '<S355>/If Action Subsystem3'
 *    '<S394>/If Action Subsystem3'
 */
void LKAS_IfActionSubsystem3(boolean rtu_In1, boolean *rty_Out)
{
  /* Inport: '<S114>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * System initialize for atomic system:
 *    '<S110>/Moving Standard Deviation1'
 *    '<S110>/Moving Standard Deviation2'
 */
void L_MovingStandardDeviation1_Init(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S115>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * System reset for atomic system:
 *    '<S110>/Moving Standard Deviation1'
 *    '<S110>/Moving Standard Deviation2'
 */
void MovingStandardDeviation1_Reset(DW_MovingStandardDeviation1_L_T *localDW)
{
  /* InitializeConditions for Delay: '<S115>/Delay' */
  localDW->Delay_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay1' */
  localDW->Delay1_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay10' */
  localDW->Delay10_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay11' */
  localDW->Delay11_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay12' */
  localDW->Delay12_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay13' */
  localDW->Delay13_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay14' */
  localDW->Delay14_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay15' */
  localDW->Delay15_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay16' */
  localDW->Delay16_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay17' */
  localDW->Delay17_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay18' */
  localDW->Delay18_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay19' */
  localDW->Delay19_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay2' */
  localDW->Delay2_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay20' */
  localDW->Delay20_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay21' */
  localDW->Delay21_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay22' */
  localDW->Delay22_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay23' */
  localDW->Delay23_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay24' */
  localDW->Delay24_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay25' */
  localDW->Delay25_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay26' */
  localDW->Delay26_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay27' */
  localDW->Delay27_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay28' */
  localDW->Delay28_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay29' */
  localDW->Delay29_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay3' */
  localDW->Delay3_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay30' */
  localDW->Delay30_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay31' */
  localDW->Delay31_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay32' */
  localDW->Delay32_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay33' */
  localDW->Delay33_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay34' */
  localDW->Delay34_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay35' */
  localDW->Delay35_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay36' */
  localDW->Delay36_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay37' */
  localDW->Delay37_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay38' */
  localDW->Delay38_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay39' */
  localDW->Delay39_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay4' */
  localDW->Delay4_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay40' */
  localDW->Delay40_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay41' */
  localDW->Delay41_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay42' */
  localDW->Delay42_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay43' */
  localDW->Delay43_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay44' */
  localDW->Delay44_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay45' */
  localDW->Delay45_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay46' */
  localDW->Delay46_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay47' */
  localDW->Delay47_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay48' */
  localDW->Delay48_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay5' */
  localDW->Delay5_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay6' */
  localDW->Delay6_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay7' */
  localDW->Delay7_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay8' */
  localDW->Delay8_DSTATE = 0.0F;

  /* InitializeConditions for Delay: '<S115>/Delay9' */
  localDW->Delay9_DSTATE = 0.0F;
}

/*
 * Output and update for atomic system:
 *    '<S110>/Moving Standard Deviation1'
 *    '<S110>/Moving Standard Deviation2'
 */
float32 LKAS_MovingStandardDeviation1(float32 rtu_In1,
  DW_MovingStandardDeviation1_L_T *localDW)
{
  /* local block i/o variables */
  float32 rtb_Delay_a;
  float32 rtb_Delay1_b;
  float32 rtb_Delay10_p;
  float32 rtb_Delay11_k;
  float32 rtb_Delay12_m;
  float32 rtb_Delay13_m;
  float32 rtb_Delay14_n;
  float32 rtb_Delay15_f;
  float32 rtb_Delay16_g;
  float32 rtb_Delay17_b;
  float32 rtb_Delay18_p;
  float32 rtb_Delay19_e;
  float32 rtb_Delay2_e;
  float32 rtb_Delay20_h;
  float32 rtb_Delay21_b;
  float32 rtb_Delay22_g;
  float32 rtb_Delay23_a;
  float32 rtb_Delay24_n;
  float32 rtb_Delay25_k;
  float32 rtb_Delay26_n;
  float32 rtb_Delay27_d;
  float32 rtb_Delay28_m;
  float32 rtb_Delay29_g;
  float32 rtb_Delay3_o;
  float32 rtb_Delay30_g;
  float32 rtb_Delay31_i;
  float32 rtb_Delay32_k;
  float32 rtb_Delay33_c;
  float32 rtb_Delay34_n;
  float32 rtb_Delay35_f;
  float32 rtb_Delay36_m;
  float32 rtb_Delay37_i;
  float32 rtb_Delay38_k;
  float32 rtb_Delay39_g;
  float32 rtb_Delay4_c;
  float32 rtb_Delay40_e;
  float32 rtb_Delay41_h;
  float32 rtb_Delay42_m;
  float32 rtb_Delay43_c;
  float32 rtb_Delay44_k;
  float32 rtb_Delay45_i;
  float32 rtb_Delay46_l;
  float32 rtb_Delay48_p;
  float32 rtb_Delay5_h;
  float32 rtb_Delay6_l;
  float32 rtb_Delay7_e;
  float32 rtb_Delay8_e;
  float32 rtb_Delay9_e;
  float32 rtb_Delay47;
  float32 rty_Out1_0;
  sint32 j;
  sint32 n;
  sint32 str;
  sint32 jtmp;
  float32 rtb_TmpSignalConversionAtStanda[50];

  /* Delay: '<S115>/Delay' */
  rtb_Delay_a = localDW->Delay_DSTATE;

  /* Delay: '<S115>/Delay1' */
  rtb_Delay1_b = localDW->Delay1_DSTATE;

  /* Delay: '<S115>/Delay10' */
  rtb_Delay10_p = localDW->Delay10_DSTATE;

  /* Delay: '<S115>/Delay11' */
  rtb_Delay11_k = localDW->Delay11_DSTATE;

  /* Delay: '<S115>/Delay12' */
  rtb_Delay12_m = localDW->Delay12_DSTATE;

  /* Delay: '<S115>/Delay13' */
  rtb_Delay13_m = localDW->Delay13_DSTATE;

  /* Delay: '<S115>/Delay14' */
  rtb_Delay14_n = localDW->Delay14_DSTATE;

  /* Delay: '<S115>/Delay15' */
  rtb_Delay15_f = localDW->Delay15_DSTATE;

  /* Delay: '<S115>/Delay16' */
  rtb_Delay16_g = localDW->Delay16_DSTATE;

  /* Delay: '<S115>/Delay17' */
  rtb_Delay17_b = localDW->Delay17_DSTATE;

  /* Delay: '<S115>/Delay18' */
  rtb_Delay18_p = localDW->Delay18_DSTATE;

  /* Delay: '<S115>/Delay19' */
  rtb_Delay19_e = localDW->Delay19_DSTATE;

  /* Delay: '<S115>/Delay2' */
  rtb_Delay2_e = localDW->Delay2_DSTATE;

  /* Delay: '<S115>/Delay20' */
  rtb_Delay20_h = localDW->Delay20_DSTATE;

  /* Delay: '<S115>/Delay21' */
  rtb_Delay21_b = localDW->Delay21_DSTATE;

  /* Delay: '<S115>/Delay22' */
  rtb_Delay22_g = localDW->Delay22_DSTATE;

  /* Delay: '<S115>/Delay23' */
  rtb_Delay23_a = localDW->Delay23_DSTATE;

  /* Delay: '<S115>/Delay24' */
  rtb_Delay24_n = localDW->Delay24_DSTATE;

  /* Delay: '<S115>/Delay25' */
  rtb_Delay25_k = localDW->Delay25_DSTATE;

  /* Delay: '<S115>/Delay26' */
  rtb_Delay26_n = localDW->Delay26_DSTATE;

  /* Delay: '<S115>/Delay27' */
  rtb_Delay27_d = localDW->Delay27_DSTATE;

  /* Delay: '<S115>/Delay28' */
  rtb_Delay28_m = localDW->Delay28_DSTATE;

  /* Delay: '<S115>/Delay29' */
  rtb_Delay29_g = localDW->Delay29_DSTATE;

  /* Delay: '<S115>/Delay3' */
  rtb_Delay3_o = localDW->Delay3_DSTATE;

  /* Delay: '<S115>/Delay30' */
  rtb_Delay30_g = localDW->Delay30_DSTATE;

  /* Delay: '<S115>/Delay31' */
  rtb_Delay31_i = localDW->Delay31_DSTATE;

  /* Delay: '<S115>/Delay32' */
  rtb_Delay32_k = localDW->Delay32_DSTATE;

  /* Delay: '<S115>/Delay33' */
  rtb_Delay33_c = localDW->Delay33_DSTATE;

  /* Delay: '<S115>/Delay34' */
  rtb_Delay34_n = localDW->Delay34_DSTATE;

  /* Delay: '<S115>/Delay35' */
  rtb_Delay35_f = localDW->Delay35_DSTATE;

  /* Delay: '<S115>/Delay36' */
  rtb_Delay36_m = localDW->Delay36_DSTATE;

  /* Delay: '<S115>/Delay37' */
  rtb_Delay37_i = localDW->Delay37_DSTATE;

  /* Delay: '<S115>/Delay38' */
  rtb_Delay38_k = localDW->Delay38_DSTATE;

  /* Delay: '<S115>/Delay39' */
  rtb_Delay39_g = localDW->Delay39_DSTATE;

  /* Delay: '<S115>/Delay4' */
  rtb_Delay4_c = localDW->Delay4_DSTATE;

  /* Delay: '<S115>/Delay40' */
  rtb_Delay40_e = localDW->Delay40_DSTATE;

  /* Delay: '<S115>/Delay41' */
  rtb_Delay41_h = localDW->Delay41_DSTATE;

  /* Delay: '<S115>/Delay42' */
  rtb_Delay42_m = localDW->Delay42_DSTATE;

  /* Delay: '<S115>/Delay43' */
  rtb_Delay43_c = localDW->Delay43_DSTATE;

  /* Delay: '<S115>/Delay44' */
  rtb_Delay44_k = localDW->Delay44_DSTATE;

  /* Delay: '<S115>/Delay45' */
  rtb_Delay45_i = localDW->Delay45_DSTATE;

  /* Delay: '<S115>/Delay46' */
  rtb_Delay46_l = localDW->Delay46_DSTATE;

  /* Delay: '<S115>/Delay47' */
  rtb_Delay47 = localDW->Delay47_DSTATE;

  /* Delay: '<S115>/Delay48' */
  rtb_Delay48_p = localDW->Delay48_DSTATE;

  /* Delay: '<S115>/Delay5' */
  rtb_Delay5_h = localDW->Delay5_DSTATE;

  /* Delay: '<S115>/Delay6' */
  rtb_Delay6_l = localDW->Delay6_DSTATE;

  /* Delay: '<S115>/Delay7' */
  rtb_Delay7_e = localDW->Delay7_DSTATE;

  /* Delay: '<S115>/Delay8' */
  rtb_Delay8_e = localDW->Delay8_DSTATE;

  /* Delay: '<S115>/Delay9' */
  rtb_Delay9_e = localDW->Delay9_DSTATE;

  /* SignalConversion: '<S115>/TmpSignal ConversionAtStandard DeviationInport1' */
  rtb_TmpSignalConversionAtStanda[0] = rtu_In1;
  rtb_TmpSignalConversionAtStanda[1] = rtb_Delay_a;
  rtb_TmpSignalConversionAtStanda[2] = rtb_Delay1_b;
  rtb_TmpSignalConversionAtStanda[3] = rtb_Delay2_e;
  rtb_TmpSignalConversionAtStanda[4] = rtb_Delay3_o;
  rtb_TmpSignalConversionAtStanda[5] = rtb_Delay4_c;
  rtb_TmpSignalConversionAtStanda[6] = rtb_Delay5_h;
  rtb_TmpSignalConversionAtStanda[7] = rtb_Delay6_l;
  rtb_TmpSignalConversionAtStanda[8] = rtb_Delay7_e;
  rtb_TmpSignalConversionAtStanda[9] = rtb_Delay8_e;
  rtb_TmpSignalConversionAtStanda[10] = rtb_Delay9_e;
  rtb_TmpSignalConversionAtStanda[11] = rtb_Delay10_p;
  rtb_TmpSignalConversionAtStanda[12] = rtb_Delay11_k;
  rtb_TmpSignalConversionAtStanda[13] = rtb_Delay12_m;
  rtb_TmpSignalConversionAtStanda[14] = rtb_Delay13_m;
  rtb_TmpSignalConversionAtStanda[15] = rtb_Delay14_n;
  rtb_TmpSignalConversionAtStanda[16] = rtb_Delay15_f;
  rtb_TmpSignalConversionAtStanda[17] = rtb_Delay16_g;
  rtb_TmpSignalConversionAtStanda[18] = rtb_Delay17_b;
  rtb_TmpSignalConversionAtStanda[19] = rtb_Delay18_p;
  rtb_TmpSignalConversionAtStanda[20] = rtb_Delay28_m;
  rtb_TmpSignalConversionAtStanda[21] = rtb_Delay19_e;
  rtb_TmpSignalConversionAtStanda[22] = rtb_Delay20_h;
  rtb_TmpSignalConversionAtStanda[23] = rtb_Delay21_b;
  rtb_TmpSignalConversionAtStanda[24] = rtb_Delay22_g;
  rtb_TmpSignalConversionAtStanda[25] = rtb_Delay23_a;
  rtb_TmpSignalConversionAtStanda[26] = rtb_Delay24_n;
  rtb_TmpSignalConversionAtStanda[27] = rtb_Delay25_k;
  rtb_TmpSignalConversionAtStanda[28] = rtb_Delay26_n;
  rtb_TmpSignalConversionAtStanda[29] = rtb_Delay27_d;
  rtb_TmpSignalConversionAtStanda[30] = rtb_Delay38_k;
  rtb_TmpSignalConversionAtStanda[31] = rtb_Delay29_g;
  rtb_TmpSignalConversionAtStanda[32] = rtb_Delay30_g;
  rtb_TmpSignalConversionAtStanda[33] = rtb_Delay31_i;
  rtb_TmpSignalConversionAtStanda[34] = rtb_Delay32_k;
  rtb_TmpSignalConversionAtStanda[35] = rtb_Delay33_c;
  rtb_TmpSignalConversionAtStanda[36] = rtb_Delay34_n;
  rtb_TmpSignalConversionAtStanda[37] = rtb_Delay35_f;
  rtb_TmpSignalConversionAtStanda[38] = rtb_Delay36_m;
  rtb_TmpSignalConversionAtStanda[39] = rtb_Delay37_i;
  rtb_TmpSignalConversionAtStanda[40] = rtb_Delay48_p;
  rtb_TmpSignalConversionAtStanda[41] = rtb_Delay39_g;
  rtb_TmpSignalConversionAtStanda[42] = rtb_Delay40_e;
  rtb_TmpSignalConversionAtStanda[43] = rtb_Delay41_h;
  rtb_TmpSignalConversionAtStanda[44] = rtb_Delay42_m;
  rtb_TmpSignalConversionAtStanda[45] = rtb_Delay43_c;
  rtb_TmpSignalConversionAtStanda[46] = rtb_Delay44_k;
  rtb_TmpSignalConversionAtStanda[47] = rtb_Delay45_i;
  rtb_TmpSignalConversionAtStanda[48] = rtb_Delay46_l;
  rtb_TmpSignalConversionAtStanda[49] = rtb_Delay47;

  /* S-Function (sdspstatfcns): '<S115>/Standard Deviation' */
  for (j = 0; j < 1; j++) {
    localDW->StandardDeviation_AccVal = rtb_TmpSignalConversionAtStanda[j];
    localDW->StandardDeviation_SqData = rtb_TmpSignalConversionAtStanda[j] *
      rtb_TmpSignalConversionAtStanda[j];
    str = 1;
    for (n = 48; n >= 0; n--) {
      jtmp = j + str;
      localDW->StandardDeviation_AccVal += rtb_TmpSignalConversionAtStanda[jtmp];
      localDW->StandardDeviation_SqData += rtb_TmpSignalConversionAtStanda[jtmp]
        * rtb_TmpSignalConversionAtStanda[jtmp];
      str++;
    }

    rty_Out1_0 = sqrtf(fabsf((localDW->StandardDeviation_SqData -
      ((localDW->StandardDeviation_AccVal * localDW->StandardDeviation_AccVal) /
       50.0F)) / 49.0F));
  }

  /* End of S-Function (sdspstatfcns): '<S115>/Standard Deviation' */

  /* Update for Delay: '<S115>/Delay' */
  localDW->Delay_DSTATE = rtu_In1;

  /* Update for Delay: '<S115>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay_a;

  /* Update for Delay: '<S115>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9_e;

  /* Update for Delay: '<S115>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10_p;

  /* Update for Delay: '<S115>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11_k;

  /* Update for Delay: '<S115>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12_m;

  /* Update for Delay: '<S115>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13_m;

  /* Update for Delay: '<S115>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14_n;

  /* Update for Delay: '<S115>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15_f;

  /* Update for Delay: '<S115>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16_g;

  /* Update for Delay: '<S115>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17_b;

  /* Update for Delay: '<S115>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay28_m;

  /* Update for Delay: '<S115>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1_b;

  /* Update for Delay: '<S115>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19_e;

  /* Update for Delay: '<S115>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20_h;

  /* Update for Delay: '<S115>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21_b;

  /* Update for Delay: '<S115>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22_g;

  /* Update for Delay: '<S115>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23_a;

  /* Update for Delay: '<S115>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24_n;

  /* Update for Delay: '<S115>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25_k;

  /* Update for Delay: '<S115>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26_n;

  /* Update for Delay: '<S115>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay18_p;

  /* Update for Delay: '<S115>/Delay29' */
  localDW->Delay29_DSTATE = rtb_Delay38_k;

  /* Update for Delay: '<S115>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2_e;

  /* Update for Delay: '<S115>/Delay30' */
  localDW->Delay30_DSTATE = rtb_Delay29_g;

  /* Update for Delay: '<S115>/Delay31' */
  localDW->Delay31_DSTATE = rtb_Delay30_g;

  /* Update for Delay: '<S115>/Delay32' */
  localDW->Delay32_DSTATE = rtb_Delay31_i;

  /* Update for Delay: '<S115>/Delay33' */
  localDW->Delay33_DSTATE = rtb_Delay32_k;

  /* Update for Delay: '<S115>/Delay34' */
  localDW->Delay34_DSTATE = rtb_Delay33_c;

  /* Update for Delay: '<S115>/Delay35' */
  localDW->Delay35_DSTATE = rtb_Delay34_n;

  /* Update for Delay: '<S115>/Delay36' */
  localDW->Delay36_DSTATE = rtb_Delay35_f;

  /* Update for Delay: '<S115>/Delay37' */
  localDW->Delay37_DSTATE = rtb_Delay36_m;

  /* Update for Delay: '<S115>/Delay38' */
  localDW->Delay38_DSTATE = rtb_Delay27_d;

  /* Update for Delay: '<S115>/Delay39' */
  localDW->Delay39_DSTATE = rtb_Delay48_p;

  /* Update for Delay: '<S115>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3_o;

  /* Update for Delay: '<S115>/Delay40' */
  localDW->Delay40_DSTATE = rtb_Delay39_g;

  /* Update for Delay: '<S115>/Delay41' */
  localDW->Delay41_DSTATE = rtb_Delay40_e;

  /* Update for Delay: '<S115>/Delay42' */
  localDW->Delay42_DSTATE = rtb_Delay41_h;

  /* Update for Delay: '<S115>/Delay43' */
  localDW->Delay43_DSTATE = rtb_Delay42_m;

  /* Update for Delay: '<S115>/Delay44' */
  localDW->Delay44_DSTATE = rtb_Delay43_c;

  /* Update for Delay: '<S115>/Delay45' */
  localDW->Delay45_DSTATE = rtb_Delay44_k;

  /* Update for Delay: '<S115>/Delay46' */
  localDW->Delay46_DSTATE = rtb_Delay45_i;

  /* Update for Delay: '<S115>/Delay47' */
  localDW->Delay47_DSTATE = rtb_Delay46_l;

  /* Update for Delay: '<S115>/Delay48' */
  localDW->Delay48_DSTATE = rtb_Delay37_i;

  /* Update for Delay: '<S115>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4_c;

  /* Update for Delay: '<S115>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5_h;

  /* Update for Delay: '<S115>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6_l;

  /* Update for Delay: '<S115>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7_e;

  /* Update for Delay: '<S115>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8_e;
  return rty_Out1_0;
}

/*
 * System initialize for enable system:
 *    '<S110>/Sum Condition'
 *    '<S110>/Sum Condition1'
 */
void LKAS_SumCondition_Init(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S117>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S110>/Sum Condition'
 *    '<S110>/Sum Condition1'
 */
void LKAS_SumCondition_Reset(DW_SumCondition_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S117>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S110>/Sum Condition'
 *    '<S110>/Sum Condition1'
 */
void LKAS_SumCondition_Disable(boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S110>/Sum Condition' incorporates:
   *  EnablePort: '<S117>/Enable'
   */
  /* Disable for Outport: '<S117>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S110>/Sum Condition' */
  localDW->SumCondition_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S110>/Sum Condition'
 *    '<S110>/Sum Condition1'
 */
void LKAS_SumCondition(boolean rtu_Enable, float32 rtu_In, float32 rtu_In1,
  boolean *rty_Out, DW_SumCondition_LKAS_T *localDW)
{
  float32 rtb_Saturation_ee;

  /* Outputs for Enabled SubSystem: '<S110>/Sum Condition' incorporates:
   *  EnablePort: '<S117>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->SumCondition_MODE) {
      LKAS_SumCondition_Reset(localDW);
      localDW->SumCondition_MODE = true;
    }

    /* Sum: '<S117>/Add1' incorporates:
     *  Memory: '<S117>/Memory'
     */
    rtb_Saturation_ee = rtu_In + localDW->Memory_PreviousInput;

    /* Saturate: '<S117>/Saturation' */
    if (rtb_Saturation_ee > 100.0F) {
      rtb_Saturation_ee = 100.0F;
    } else {
      if (rtb_Saturation_ee < 0.0F) {
        rtb_Saturation_ee = 0.0F;
      }
    }

    /* End of Saturate: '<S117>/Saturation' */

    /* RelationalOperator: '<S117>/Relational Operator' */
    *rty_Out = (rtb_Saturation_ee >= rtu_In1);

    /* Update for Memory: '<S117>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_ee;
  } else {
    if (localDW->SumCondition_MODE) {
      LKAS_SumCondition_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S110>/Sum Condition' */
}

/*
 * Output and update for action system:
 *    '<S129>/If Action Subsystem2'
 *    '<S129>/If Action Subsystem1'
 *    '<S130>/If Action Subsystem2'
 *    '<S130>/If Action Subsystem1'
 *    '<S131>/If Action Subsystem2'
 *    '<S131>/If Action Subsystem1'
 *    '<S132>/If Action Subsystem2'
 *    '<S132>/If Action Subsystem1'
 *    '<S133>/If Action Subsystem2'
 *    '<S133>/If Action Subsystem1'
 *    ...
 */
void LKAS_IfActionSubsystem2_k(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S143>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S134>/if action '
 *    '<S135>/if action '
 *    '<S136>/if action '
 *    '<S137>/if action '
 *    '<S138>/if action '
 *    '<S139>/if action '
 *    '<S140>/if action '
 */
void LKAS_ifaction(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S157>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for action system:
 *    '<S173>/If Action Subsystem'
 *    '<S173>/If Action Subsystem4'
 *    '<S125>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem(float32 rtu_In1, float32 *rty_Out1)
{
  /* DataTypeConversion: '<S175>/Cast To Single1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system: '<S91>/LKA Motion Planning Calculation (LKAMPCal)'
 * Block description for: '<S91>/LKA Motion Planning Calculation (LKAMPCal)'
 *   Block Name: LKA Motion Planning Calculation
 *   Ab.: LKAMPCal
 *   No.: 1.2.3.2
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAMotionPlanningCalculationLKA(void)
{
  float32 K1K2Det_T1;
  float32 DelteSW0;
  float32 u;
  float32 KMax;
  float32 DelteSW1;
  float32 tmp;

  /* MATLAB Function: '<S121>/MATLABFunction1' */
  /*  ************************************************************************* */
  /*  �������� */
  /*    K1K2Det_stLDDir : �����ĳ���ƫ��ķ���1�����������Ҳ೵����ƫ����-1�������� */
  /*                        ����೵����ƫ������λ��- */
  /*    K1K2Det_tiTTLC0 : ����һ��ʱ��TTLC����λ��s */
  /*    K1K2Det_vVehSpd : ���٣���λ��Km/h */
  /*    K1K2Det_phiIniSWA : ��ʼת����ת�ǣ���λ��deg */
  /*    K1K2Det_phi1PhDesHdAgChg : һ����������Ǳ仯��,��λ��radian */
  /*    K1K2Det_phi2PhDesHdAg : ��������ʱ����������ǣ���λ��radian */
  /*    K1K2Det_l1PhDvtIni : ����һ��ʱ��ƫ������ֵ����λ��m */
  /*    K1K2Det_lDesDvt : ��������ʱ������ƫ�����ľ���ֵ����λ��m */
  /*  �궨���� */
  /*    WhlBase_SY : ������࣬��λ��m */
  /*    StRatio_SY : ת�򴫶��ȣ���λ��- */
  /*    StbFacm_SY : �ȶ�����������λ��- */
  /*  ������� */
  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad1 : ����ת����ת�Ǳ仯��1����λ��deg/s */
  /*    K1K2Det_dphi2PhSWAGrad2 ������ת����ת�Ǳ仯��2����λ��deg/s */
  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /*    K1K2Det_stReplFlag : ���¹滮��־����λ��- */
  /* ************************************************************************** */
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /LKA Motion Planning Calculation (LKAMPCal)/MATLABFunction1': '<S128>:1' */
  /* '<S128>:1:34' LDDir = K1K2Det_stLDDir; */
  /*     D1_Ini = K1K2Det_l1PhDvtIni; */
  /* '<S128>:1:36' DelteSW0 = K1K2Det_phiIniSWA*(pi/180); */
  DelteSW0 = LKAS_DW.In_n * 0.0174532924F;

  /* '<S128>:1:37' PrvwHdAg = K1K2Det_phiPrvwHdAgIni; */
  /* '<S128>:1:38' TTLC = single(K1K2Det_tiTTLC0); */
  /* '<S128>:1:39' L = K1K2Det_bsSysCfg_SY_WhlBase_SY; */
  /* '<S128>:1:40' i = K1K2Det_bsSysCfg_SY_StRatio_SY; */
  /* '<S128>:1:41' K = K1K2Det_bsSysCfg_SY_StbFacm_SY; */
  /* '<S128>:1:42' u = K1K2Det_vVehSpd/3.6; */
  u = LKAS_DW.In_c / 3.6F;

  /* '<S128>:1:43' Kw= u/(L*(1+K*u*u)*i); */
  /* '<S128>:1:44' KMax = K1K2Det_dphiSWARMax/180*pi; */
  KMax = (LKAS_DW.MPInP_dphiSWARMax / 180.0F) * 3.14159274F;

  /* '<S128>:1:45' Delte_Psi1 = PrvwHdAg; */
  /* ���ݹ�ʽ��Delte_Psi1 = Kw*(DelteSW0*TTLC+0.5*K1*TTLC*TTLC)�����K1�� */
  /* '<S128>:1:47' K1 = -2*Delte_Psi1/(Kw*TTLC*TTLC)-2*DelteSW0/TTLC; */
  u = ((-2.0F * LKAS_DW.In_ir) / (((u / (((((LKAS_DW.MPInP_StbFacm_SY * u) * u)
             + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_m) * LKAS_DW.LKA_StrRatio_C_d)) *
         LKAS_DW.MPInP_tiTTLCIni) * LKAS_DW.MPInP_tiTTLCIni)) - ((2.0F *
    DelteSW0) / LKAS_DW.MPInP_tiTTLCIni);

  /* ����K1��TTLC�ͳ�ʼת����ת�ǣ����Լ���õ��������ʱ��ת����ת�ǳ�ʼֵDelteSW1�� */
  /* '<S128>:1:49' DelteSW1 = DelteSW0+K1*TTLC; */
  DelteSW1 = (u * LKAS_DW.MPInP_tiTTLCIni) + DelteSW0;

  /* '<S128>:1:50' K1K2Det_T1 = TTLC; */
  K1K2Det_T1 = LKAS_DW.MPInP_tiTTLCIni;

  /* '<S128>:1:51' if ~(K1<abs(KMax) && K1>-abs(KMax)) */
  tmp = fabsf(KMax);
  if ((u >= tmp) || (u <= (-tmp))) {
    /*  ������ת������ */
    /* '<S128>:1:52' K1 = LDDir*KMax; */
    u = LKAS_DW.Merge * KMax;

    /* '<S128>:1:53' K1K2Det_T1 = max((-DelteSW0+sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1,(-DelteSW0-sqrt(DelteSW0*DelteSW0-2*K1*Delte_Psi1))/K1); */
    KMax = sqrtf((DelteSW0 * DelteSW0) - ((2.0F * u) * LKAS_DW.In_ir));
    K1K2Det_T1 = fmaxf((KMax + (-DelteSW0)) / u, ((-DelteSW0) - KMax) / u);

    /* '<S128>:1:54' DelteSW1 = (K1*K1K2Det_T1+DelteSW0); */
    DelteSW1 = (u * K1K2Det_T1) + DelteSW0;
  }

  /* '<S128>:1:56' if LDDir>0 && K1<0 && DelteSW0>0 && Delte_Psi1<0 */
  if ((((LKAS_DW.Merge > 0.0F) && (u < 0.0F)) && (DelteSW0 > 0.0F)) &&
      (LKAS_DW.In_ir < 0.0F)) {
    /* '<S128>:1:57' K1 = single(0); */
    u = 0.0F;

    /* '<S128>:1:58' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S128>:1:59' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_ir) / DelteSW0;
  }

  /* '<S128>:1:61' if LDDir<0 && K1>0 && DelteSW0<0 && Delte_Psi1>0 */
  if ((((LKAS_DW.Merge < 0.0F) && (u > 0.0F)) && (DelteSW0 < 0.0F)) &&
      (LKAS_DW.In_ir > 0.0F)) {
    /* '<S128>:1:62' K1 = single(0); */
    u = 0.0F;

    /* '<S128>:1:63' DelteSW1 = DelteSW0; */
    DelteSW1 = DelteSW0;

    /* '<S128>:1:64' K1K2Det_T1 = -Delte_Psi1/DelteSW1; */
    K1K2Det_T1 = (-LKAS_DW.In_ir) / DelteSW0;
  }

  /*    K1K2Det_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
  /* '<S128>:1:67' K1K2Det_phi2PhSWAIni = DelteSW1*(180/pi); */
  LKAS_DW.K1K2Det_phi2PhSWAIni = DelteSW1 * 57.2957802F;

  /*    K1K2Det_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
  /* '<S128>:1:69' K1K2Det_dphi1PhSWAGrad = K1*(180/pi); */
  LKAS_DW.K1K2Det_dphi1PhSWAGrad = u * 57.2957802F;
  LKAS_DW.K1K2Det_T1 = K1K2Det_T1;

  /* End of MATLAB Function: '<S121>/MATLABFunction1' */
}

/*
 * Output and update for atomic system:
 *    '<S183>/Saturable Gain Lut (SatGainLut)'
 *    '<S183>/Saturable Gain Lut (SatGainLut)1'
 */
void LKAS_SaturableGainLutSatGainLut(float32 rtu_Input, float32 rtu_InputLimLwr,
  float32 rtu_InputLimUpr, float32 rtu_GainLimLwr, float32 rtu_GainLimUpr,
  float32 *rty_Gain)
{
  /* MATLAB Function 'LKAS/LL/LLOn/LKA/Lane Following (LF)/Trajectory Following Control (TFC)/Feedback Control (FbCtl)/Saturable Gain Lut (SatGainLut)': '<S186>:1' */
  /*  Function Name: Saturable Gain Lut */
  /*  */
  /*  Description:  */
  /*    Saturable Gain Lookup Table. */
  /*  */
  /*  Assumptions and Limitation: */
  /*    The data type of all inputs and output is single. */
  /*  */
  /*  Inputs: */
  /*    Input: */
  /*    InputLimLwr: */
  /*    InputLimUpr: */
  /*    GainLimLwr: */
  /*    GainLimUpr: */
  /*  */
  /*  Outputs: */
  /*    Gain: The result of Looking up table. */
  /*  $Revision: 1.0$ */
  /*  $Author: Zhang Jianwei$ */
  /*  $Date: January 27, 2019$ */
  /*  ________________________________________ */
  /* '<S186>:1:25' if Input <= InputLimLwr */
  if (rtu_Input <= rtu_InputLimLwr) {
    /* '<S186>:1:26' Gain = GainLimLwr; */
    *rty_Gain = rtu_GainLimLwr;
  } else if (rtu_Input >= rtu_InputLimUpr) {
    /* '<S186>:1:27' elseif Input >= InputLimUpr */
    /* '<S186>:1:28' Gain = GainLimUpr; */
    *rty_Gain = rtu_GainLimUpr;
  } else {
    /* '<S186>:1:29' else */
    /* '<S186>:1:29' Gain = (Input - InputLimLwr)/(InputLimUpr - InputLimLwr)... */
    /* '<S186>:1:30'         *(GainLimUpr - GainLimLwr) + GainLimLwr; */
    *rty_Gain = (((rtu_Input - rtu_InputLimLwr) / (rtu_InputLimUpr -
      rtu_InputLimLwr)) * (rtu_GainLimUpr - rtu_GainLimLwr)) + rtu_GainLimLwr;
  }
}

/*
 * Output and update for action system:
 *    '<S190>/If Action Subsystem'
 *    '<S190>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_a(float32 rtu_In1, float32 *rty_Out1)
{
  /* Inport: '<S192>/In1' */
  *rty_Out1 = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S213>/if action '
 *    '<S214>/if action '
 *    '<S221>/if action '
 *    '<S222>/if action '
 */
void LKAS_ifaction_f(float32 rtu_In, float32 *rty_Out)
{
  /* Inport: '<S215>/In' */
  *rty_Out = rtu_In;
}

/*
 * Output and update for enable system:
 *    '<S206>/If Action Subsystem'
 *    '<S207>/If Action Subsystem'
 */
void LKAS_IfActionSubsystem_n(float32 rtu_Enable, float32 rtu_T1, float32
  rtu_Plan, float32 *rty_T1_1, float32 *rty_Plan_1,
  DW_IfActionSubsystem_LKAS_h_T *localDW)
{
  uint16 rtb_Saturation1_mx;
  uint16 rtb_Saturation1_lo;

  /* Outputs for Enabled SubSystem: '<S206>/If Action Subsystem' incorporates:
   *  EnablePort: '<S211>/Enable'
   */
  if (rtu_Enable > 0.0F) {
    /* Sum: '<S213>/Add' incorporates:
     *  Constant: '<S213>/Constant'
     *  Memory: '<S213>/Memory'
     */
    rtb_Saturation1_mx = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput));

    /* Saturate: '<S213>/Saturation1' */
    if (rtb_Saturation1_mx >= ((uint16)10000U)) {
      rtb_Saturation1_mx = ((uint16)10000U);
    }

    /* End of Saturate: '<S213>/Saturation1' */

    /* If: '<S213>/If' incorporates:
     *  Constant: '<S213>/Constant2'
     */
    if (rtb_Saturation1_mx <= ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S213>/if action ' incorporates:
       *  ActionPort: '<S215>/Action Port'
       */
      LKAS_ifaction_f(rtu_T1, rty_T1_1);

      /* End of Outputs for SubSystem: '<S213>/if action ' */
    }

    /* End of If: '<S213>/If' */

    /* Sum: '<S214>/Add' incorporates:
     *  Constant: '<S214>/Constant'
     *  Memory: '<S214>/Memory'
     */
    rtb_Saturation1_lo = (uint16)(((uint32)((uint16)1U)) + ((uint32)
      localDW->Memory_PreviousInput_e));

    /* Saturate: '<S214>/Saturation1' */
    if (rtb_Saturation1_lo >= ((uint16)10000U)) {
      rtb_Saturation1_lo = ((uint16)10000U);
    }

    /* End of Saturate: '<S214>/Saturation1' */

    /* If: '<S214>/If' incorporates:
     *  Constant: '<S214>/Constant2'
     */
    if (rtb_Saturation1_lo == ((uint16)1U)) {
      /* Outputs for IfAction SubSystem: '<S214>/if action ' incorporates:
       *  ActionPort: '<S216>/Action Port'
       */
      LKAS_ifaction_f(rtu_Plan, rty_Plan_1);

      /* End of Outputs for SubSystem: '<S214>/if action ' */
    }

    /* End of If: '<S214>/If' */

    /* Update for Memory: '<S213>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation1_mx;

    /* Update for Memory: '<S214>/Memory' */
    localDW->Memory_PreviousInput_e = rtb_Saturation1_lo;
  }

  /* End of Outputs for SubSystem: '<S206>/If Action Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S206>/If Action Subsystem2'
 *    '<S207>/If Action Subsystem2'
 */
void LKAS_IfActionSubsystem2_a(float32 rtu_T1, float32 rtu_Plan, float32
  *rty_T1_1, float32 *rty_Plan_1)
{
  /* Inport: '<S212>/T1' */
  *rty_T1_1 = rtu_T1;

  /* Inport: '<S212>/Plan' */
  *rty_Plan_1 = rtu_Plan;
}

/* System reset for atomic system: '<S82>/LDW_State_Machine' */
void LKAS_LDW_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff_c = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.is_active_c69_LKAS = 0U;
  LKAS_DW.is_c69_LKAS = LKAS_IN_NO_ACTIVE_CHILD;
  LKAS_DW.LDWSM_stLDWActvFlg = 0U;
  LKAS_DW.LDWSM_stLDWState = 0U;
}

/*
 * Output and update for atomic system: '<S82>/LDW_State_Machine'
 * Block description for: '<S82>/LDW_State_Machine'
 *   Block Name: LDW State Machine
 *   Ab.: LDWSM
 *   No.: 1.1.2.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LDW_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S82>/LDW_State_Machine'
   *
   * Block description for '<S82>/LDW_State_Machine':
   *  Block Name: LDW State Machine
   *  Ab.: LDWSM
   *  No.: 1.1.2.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LDW_State_Machine */
  if (((uint32)LKAS_DW.is_active_c69_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    LKAS_DW.is_active_c69_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LDW_State_Machine */
    /* Transition: '<S274>:2' */
    LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;

    /* Entry Internal 'SysOff': '<S274>:1' */
    /* Transition: '<S274>:31' */
    LKAS_DW.is_SysOff_c = LKAS_IN_Unavailable;

    /* Entry 'Unavailable': '<S274>:30' */
    LKAS_DW.LDWSM_stLDWState = 0U;
  } else {
    switch (LKAS_DW.is_c69_LKAS) {
     case LKAS_IN_Fault:
      /* During 'Fault': '<S274>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)
             LKAS_DW.LKA_Mode) == 2))) {
        /* Transition: '<S274>:38' */
        /* Exit Internal 'Fault': '<S274>:36' */
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S274>:3' */
        /* Transition: '<S274>:77' */
        LKAS_DW.is_SysOn_a = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S274>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 0) && tmp) {
        /* Transition: '<S274>:40' */
        /* Exit Internal 'Fault': '<S274>:36' */
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_c = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S274>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else {
        LKAS_DW.LDWSM_stLDWState = 6U;

        /* During 'LDWFault': '<S274>:73' */
      }
      break;

     case LKAS_IN_SysOff:
      /* During 'SysOff': '<S274>:1' */
      if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
          && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S274>:39' */
        /* Exit Internal 'SysOff': '<S274>:1' */
        LKAS_DW.is_SysOff_c = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S274>:36' */
        /* Transition: '<S274>:75' */
        /* Entry 'LDWFault': '<S274>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
                  == 2)) {
        /* Transition: '<S274>:41' */
        /* Exit Internal 'SysOff': '<S274>:1' */
        LKAS_DW.is_SysOff_c = LKAS_IN_NO_ACTIVE_CHILD;
        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOn;

        /* Entry Internal 'SysOn': '<S274>:3' */
        /* Transition: '<S274>:77' */
        LKAS_DW.is_SysOn_a = LKAS_IN_LDWSelected;

        /* Entry 'LDWSelected': '<S274>:47' */
        LKAS_DW.LDWSM_stLDWState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff_c) == LKAS_IN_Unavailable) {
        LKAS_DW.LDWSM_stLDWState = 0U;

        /* During 'Unavailable': '<S274>:30' */
        if (((sint32)LKAS_DW.LKA_Mode) == 0) {
          /* Transition: '<S274>:35' */
          LKAS_DW.is_SysOff_c = LKAS_IN_Unselected;

          /* Entry 'Unselected': '<S274>:32' */
          LKAS_DW.LDWSM_stLDWState = 1U;
        }
      } else {
        LKAS_DW.LDWSM_stLDWState = 1U;

        /* During 'Unselected': '<S274>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S274>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S274>:37' */
        /* Exit Internal 'SysOn': '<S274>:3' */
        if (((uint32)LKAS_DW.is_SysOn_a) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S274>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S274>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S274>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_Fault;

        /* Entry Internal 'Fault': '<S274>:36' */
        /* Transition: '<S274>:75' */
        /* Entry 'LDWFault': '<S274>:73' */
        LKAS_DW.LDWSM_stLDWState = 6U;
      } else if ((((sint32)LKAS_DW.LKA_Mode) != 1) && (((sint32)LKAS_DW.LKA_Mode)
                  != 2)) {
        /* Transition: '<S274>:42' */
        /* Exit Internal 'SysOn': '<S274>:3' */
        if (((uint32)LKAS_DW.is_SysOn_a) == LKAS_IN_Normal) {
          /* Exit Internal 'Normal': '<S274>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S274>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S274>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        } else {
          LKAS_DW.is_SysOn_a = LKAS_IN_NO_ACTIVE_CHILD;
        }

        LKAS_DW.is_c69_LKAS = LKAS_IN_SysOff;
        LKAS_DW.is_SysOff_c = LKAS_IN_Unselected;

        /* Entry 'Unselected': '<S274>:32' */
        LKAS_DW.LDWSM_stLDWState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn_a) == LKAS_IN_LDWSelected) {
        LKAS_DW.LDWSM_stLDWState = 2U;

        /* During 'LDWSelected': '<S274>:47' */
        if ((LKAS_DW.Merge_ew) && (!LKAS_DW.Merge1_i)) {
          /* Transition: '<S274>:50' */
          LKAS_DW.is_SysOn_a = LKAS_IN_Normal;

          /* Entry Internal 'Normal': '<S274>:102' */
          /* Transition: '<S274>:113' */
          LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

          /* Entry 'LDWEnable': '<S274>:112' */
          LKAS_DW.LDWSM_stLDWState = 3U;
        }
      } else {
        /* During 'Normal': '<S274>:102' */
        if (LKAS_DW.Merge1_i) {
          /* Transition: '<S274>:44' */
          /* Exit Internal 'Normal': '<S274>:102' */
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWLeftActive:
            /* Exit 'LDWLeftActive': '<S274>:114' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           case LKAS_IN_LDWRightActive:
            /* Exit 'LDWRightActive': '<S274>:115' */
            LKAS_DW.LDWSM_stLDWActvFlg = 0U;
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;

           default:
            LKAS_DW.is_Normal_i = LKAS_IN_NO_ACTIVE_CHILD;
            break;
          }

          LKAS_DW.is_SysOn_a = LKAS_IN_LDWSelected;

          /* Entry 'LDWSelected': '<S274>:47' */
          LKAS_DW.LDWSM_stLDWState = 2U;
        } else {
          switch (LKAS_DW.is_Normal_i) {
           case LKAS_IN_LDWEnable:
            LKAS_DW.LDWSM_stLDWState = 3U;

            /* During 'LDWEnable': '<S274>:112' */
            if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_a)) {
              /* Transition: '<S274>:118' */
              LKAS_DW.is_Normal_i = LKAS_IN_LDWLeftActive;

              /* Entry 'LDWLeftActive': '<S274>:114' */
              LKAS_DW.LDWSM_stLDWState = 4U;
              LKAS_DW.LDWSM_stLDWActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_a))
              {
                /* Transition: '<S274>:119' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S274>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LDWLeftActive:
            LKAS_DW.LDWSM_stLDWState = 4U;

            /* During 'LDWLeftActive': '<S274>:114' */
            if (LKAS_DW.Merge_a) {
              /* Transition: '<S274>:116' */
              /* Exit 'LDWLeftActive': '<S274>:114' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S274>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 2) && (!LKAS_DW.Merge_a))
              {
                /* Transition: '<S274>:120' */
                /* Exit 'LDWLeftActive': '<S274>:114' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWRightActive;

                /* Entry 'LDWRightActive': '<S274>:115' */
                LKAS_DW.LDWSM_stLDWState = 5U;
                LKAS_DW.LDWSM_stLDWActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LDWSM_stLDWState = 5U;

            /* During 'LDWRightActive': '<S274>:115' */
            if (LKAS_DW.Merge_a) {
              /* Transition: '<S274>:117' */
              /* Exit 'LDWRightActive': '<S274>:115' */
              LKAS_DW.LDWSM_stLDWActvFlg = 0U;
              LKAS_DW.is_Normal_i = LKAS_IN_LDWEnable;

              /* Entry 'LDWEnable': '<S274>:112' */
              LKAS_DW.LDWSM_stLDWState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LKA_State_Mon) == 1) && (!LKAS_DW.Merge_a))
              {
                /* Transition: '<S274>:121' */
                /* Exit 'LDWRightActive': '<S274>:115' */
                LKAS_DW.is_Normal_i = LKAS_IN_LDWLeftActive;

                /* Entry 'LDWLeftActive': '<S274>:114' */
                LKAS_DW.LDWSM_stLDWState = 4U;
                LKAS_DW.LDWSM_stLDWActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S82>/LDW_State_Machine' */
}

/* System reset for atomic system: '<S82>/LKA_State_Machine' */
void LKAS_LKA_State_Machine_Reset(void)
{
  LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.is_active_c70_LKAS = 0U;
  LKAS_DW.is_c70_LKAS = LKAS_IN_NO_ACTIVE_CHILD_j;
  LKAS_DW.LKASM_stLKAActvFlg = 0U;
  LKAS_DW.LKASM_stLKAState = 0U;
}

/*
 * Output and update for atomic system: '<S82>/LKA_State_Machine'
 * Block description for: '<S82>/LKA_State_Machine'
 *   Block Name: LKA State Machine
 *   Ab.: LKASM
 *   No.: 1.1.3.0
 *   Rev: 0.0.1
 *   Update Date: 19-3-26
 */
void LKAS_LKA_State_Machine(void)
{
  boolean tmp;

  /* Chart: '<S82>/LKA_State_Machine'
   *
   * Block description for '<S82>/LKA_State_Machine':
   *  Block Name: LKA State Machine
   *  Ab.: LKASM
   *  No.: 1.1.3.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* Gateway: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  /* During: LKAS/LL/LLOn/LL State Determination
     (LLStateDet)/LKA_State_Machine */
  if (((uint32)LKAS_DW.is_active_c70_LKAS) == 0U) {
    /* Entry: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    LKAS_DW.is_active_c70_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LLOn/LL State Determination
       (LLStateDet)/LKA_State_Machine */
    /* Transition: '<S275>:2' */
    LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_i;

    /* Entry Internal 'SysOff': '<S275>:1' */
    /* Transition: '<S275>:31' */
    LKAS_DW.is_SysOff = LKAS_IN_Unavailable_h;

    /* Entry 'Unavailable': '<S275>:30' */
    LKAS_DW.LKASM_stLKAState = 0U;
  } else {
    switch (LKAS_DW.is_c70_LKAS) {
     case LKAS_IN_Fault_i:
      /* During 'Fault': '<S275>:36' */
      tmp = !LKAS_DW.LKA_Fault;
      if (tmp && (((sint32)LKAS_DW.LKA_Mode) == 2)) {
        /* Transition: '<S275>:38' */
        /* Exit Internal 'Fault': '<S275>:36' */
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOn_h;

        /* Entry Internal 'SysOn': '<S275>:3' */
        /* Transition: '<S275>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S275>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)
                    LKAS_DW.LKA_Mode) == 1)) && tmp) {
        /* Transition: '<S275>:40' */
        /* Exit Internal 'Fault': '<S275>:36' */
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_i;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_l;

        /* Entry 'Unselected': '<S275>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else {
        LKAS_DW.LKASM_stLKAState = 6U;

        /* During 'LKAFault': '<S275>:72' */
      }
      break;

     case LKAS_IN_SysOff_i:
      /* During 'SysOff': '<S275>:1' */
      if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (LKAS_DW.LKA_Fault)) {
        /* Transition: '<S275>:39' */
        /* Exit Internal 'SysOff': '<S275>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
        LKAS_DW.is_c70_LKAS = LKAS_IN_Fault_i;

        /* Entry Internal 'Fault': '<S275>:36' */
        /* Transition: '<S275>:74' */
        /* Entry 'LKAFault': '<S275>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode) == 2) {
        /* Transition: '<S275>:41' */
        /* Exit Internal 'SysOff': '<S275>:1' */
        LKAS_DW.is_SysOff = LKAS_IN_NO_ACTIVE_CHILD_j;
        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOn_h;

        /* Entry Internal 'SysOn': '<S275>:3' */
        /* Transition: '<S275>:76' */
        LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

        /* Entry 'LKASelected': '<S275>:19' */
        LKAS_DW.LKASM_stLKAState = 2U;
      } else if (((uint32)LKAS_DW.is_SysOff) == LKAS_IN_Unavailable_h) {
        LKAS_DW.LKASM_stLKAState = 0U;

        /* During 'Unavailable': '<S275>:30' */
        if ((((sint32)LKAS_DW.LKA_Mode) == 0) || (((sint32)LKAS_DW.LKA_Mode) ==
             1)) {
          /* Transition: '<S275>:35' */
          LKAS_DW.is_SysOff = LKAS_IN_Unselected_l;

          /* Entry 'Unselected': '<S275>:32' */
          LKAS_DW.LKASM_stLKAState = 1U;
        }
      } else {
        LKAS_DW.LKASM_stLKAState = 1U;

        /* During 'Unselected': '<S275>:32' */
      }
      break;

     default:
      /* During 'SysOn': '<S275>:3' */
      if (LKAS_DW.LKA_Fault) {
        /* Transition: '<S275>:37' */
        /* Exit Internal 'SysOn': '<S275>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_p) {
          /* Exit Internal 'Normal': '<S275>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S275>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S275>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        }

        LKAS_DW.is_c70_LKAS = LKAS_IN_Fault_i;

        /* Entry Internal 'Fault': '<S275>:36' */
        /* Transition: '<S275>:74' */
        /* Entry 'LKAFault': '<S275>:72' */
        LKAS_DW.LKASM_stLKAState = 6U;
      } else if (((sint32)LKAS_DW.LKA_Mode) != 2) {
        /* Transition: '<S275>:42' */
        /* Exit Internal 'SysOn': '<S275>:3' */
        if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_Normal_p) {
          /* Exit Internal 'Normal': '<S275>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S275>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S275>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        } else {
          LKAS_DW.is_SysOn = LKAS_IN_NO_ACTIVE_CHILD_j;
        }

        LKAS_DW.is_c70_LKAS = LKAS_IN_SysOff_i;
        LKAS_DW.is_SysOff = LKAS_IN_Unselected_l;

        /* Entry 'Unselected': '<S275>:32' */
        LKAS_DW.LKASM_stLKAState = 1U;
      } else if (((uint32)LKAS_DW.is_SysOn) == LKAS_IN_LKASelected) {
        LKAS_DW.LKASM_stLKAState = 2U;

        /* During 'LKASelected': '<S275>:19' */
        if ((LKAS_DW.Merge1_a) && (!LKAS_DW.Merge2)) {
          /* Transition: '<S275>:24' */
          LKAS_DW.is_SysOn = LKAS_IN_Normal_p;

          /* Entry Internal 'Normal': '<S275>:102' */
          /* Transition: '<S275>:103' */
          LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

          /* Entry 'LKAEnable': '<S275>:108' */
          LKAS_DW.LKASM_stLKAState = 3U;
        }
      } else {
        /* During 'Normal': '<S275>:102' */
        if (LKAS_DW.Merge2) {
          /* Transition: '<S275>:25' */
          /* Exit Internal 'Normal': '<S275>:102' */
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKALeftActive:
            /* Exit 'LKALeftActive': '<S275>:109' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           case LKAS_IN_LKARightActive:
            /* Exit 'LKARightActive': '<S275>:110' */
            LKAS_DW.LKASM_stLKAActvFlg = 0U;
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;

           default:
            LKAS_DW.is_Normal = LKAS_IN_NO_ACTIVE_CHILD_j;
            break;
          }

          LKAS_DW.is_SysOn = LKAS_IN_LKASelected;

          /* Entry 'LKASelected': '<S275>:19' */
          LKAS_DW.LKASM_stLKAState = 2U;
        } else {
          switch (LKAS_DW.is_Normal) {
           case LKAS_IN_LKAEnable:
            LKAS_DW.LKASM_stLKAState = 3U;

            /* During 'LKAEnable': '<S275>:108' */
            if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_c)) {
              /* Transition: '<S275>:105' */
              LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

              /* Entry 'LKALeftActive': '<S275>:109' */
              LKAS_DW.LKASM_stLKAState = 4U;
              LKAS_DW.LKASM_stLKAActvFlg = 1U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S275>:104' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S275>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           case LKAS_IN_LKALeftActive:
            LKAS_DW.LKASM_stLKAState = 4U;

            /* During 'LKALeftActive': '<S275>:109' */
            if (LKAS_DW.Merge1_c) {
              /* Transition: '<S275>:106' */
              /* Exit 'LKALeftActive': '<S275>:109' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S275>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 2) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S275>:111' */
                /* Exit 'LKALeftActive': '<S275>:109' */
                LKAS_DW.is_Normal = LKAS_IN_LKARightActive;

                /* Entry 'LKARightActive': '<S275>:110' */
                LKAS_DW.LKASM_stLKAState = 5U;
                LKAS_DW.LKASM_stLKAActvFlg = 2U;
              }
            }
            break;

           default:
            LKAS_DW.LKASM_stLKAState = 5U;

            /* During 'LKARightActive': '<S275>:110' */
            if (LKAS_DW.Merge1_c) {
              /* Transition: '<S275>:107' */
              /* Exit 'LKARightActive': '<S275>:110' */
              LKAS_DW.LKASM_stLKAActvFlg = 0U;
              LKAS_DW.is_Normal = LKAS_IN_LKAEnable;

              /* Entry 'LKAEnable': '<S275>:108' */
              LKAS_DW.LKASM_stLKAState = 3U;
            } else {
              if ((((sint32)LKAS_DW.LDW_State_Mon) == 1) && (!LKAS_DW.Merge1_c))
              {
                /* Transition: '<S275>:112' */
                /* Exit 'LKARightActive': '<S275>:110' */
                LKAS_DW.is_Normal = LKAS_IN_LKALeftActive;

                /* Entry 'LKALeftActive': '<S275>:109' */
                LKAS_DW.LKASM_stLKAState = 4U;
                LKAS_DW.LKASM_stLKAActvFlg = 1U;
              }
            }
            break;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S82>/LKA_State_Machine' */
}

/*
 * Output and update for action system:
 *    '<S296>/Ph1SWA'
 *    '<S305>/Ph1SWA'
 *    '<S332>/Ph1SWA'
 *    '<S342>/Ph1SWA'
 */
void LKAS_Ph1SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S300>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S300>/Constant'
   */
  *rty_Out = 1.0F;
}

/*
 * Output and update for action system:
 *    '<S296>/Ph2SWA'
 *    '<S305>/Ph2SWA'
 *    '<S332>/Ph2SWA'
 *    '<S342>/Ph2SWA'
 */
void LKAS_Ph2SWA(float32 *rty_Out)
{
  /* SignalConversion: '<S301>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S301>/Constant'
   */
  *rty_Out = (-1.0F);
}

/*
 * Output and update for action system:
 *    '<S296>/Ph3SWA'
 *    '<S332>/Ph3SWA'
 */
void LKAS_Ph3SWA(float32 rtu_In1, float32 *rty_Out)
{
  /* Inport: '<S302>/In1' */
  *rty_Out = rtu_In1;
}

/*
 * Output and update for action system:
 *    '<S305>/Ph3SWA'
 *    '<S342>/Ph3SWA'
 */
void LKAS_Ph3SWA_f(float32 *rty_Out)
{
  /* SignalConversion: '<S311>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S311>/Constant'
   */
  *rty_Out = 0.0F;
}

/*
 * Output and update for action system:
 *    '<S368>/If Action Subsystem4'
 *    '<S368>/If Action Subsystem3'
 *    '<S474>/If Action Subsystem3'
 *    '<S474>/If Action Subsystem4'
 */
void LKAS_IfActionSubsystem4(boolean *rty_Out)
{
  /* SignalConversion: '<S380>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S380>/Constant'
   */
  *rty_Out = false;
}

/*
 * Output and update for action system:
 *    '<S403>/If Action Subsystem'
 *    '<S403>/If Action Subsystem1'
 */
void LKAS_IfActionSubsystem_nh(boolean *rty_Out)
{
  /* SignalConversion: '<S407>/OutportBuffer_InsertedFor_Out_at_inport_0' incorporates:
   *  Constant: '<S407>/Constant'
   */
  *rty_Out = true;
}

/*
 * Output and update for atomic system:
 *    '<S488>/MATLAB Function'
 *    '<S507>/MATLAB Function'
 */
void LKAS_MATLABFunction(float32 rtu_DvtThresUprLDW, float32 rtu_LaneWidth,
  float32 rtu_LKA_CarWidth, float32 *rty_ThresDet_coefficient)
{
  float32 tmp;

  /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Enable Condition  (EnaC)/LDW Own Condition (LDWOwnC)/Vehicle Position Check (VehPosChk)/Subsystem/MATLAB Function': '<S489>:1' */
  /* '<S489>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
  /* '<S489>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
  /* '<S489>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
  /* '<S489>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
  /* '<S489>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
  tmp = (2.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth;
  *rty_ThresDet_coefficient = fminf(fmaxf(0.0F, (fminf(fmaxf(tmp, rtu_LaneWidth),
    (6.0F * rtu_DvtThresUprLDW) + rtu_LKA_CarWidth) - tmp) / (4.0F *
    rtu_DvtThresUprLDW)), 1.0F);
}

/*
 * System initialize for enable system:
 *    '<S281>/Count_5s1'
 *    '<S281>/Count_5s2'
 */
void LKAS_Count_5s1_Init(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S543>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * System reset for enable system:
 *    '<S281>/Count_5s1'
 *    '<S281>/Count_5s2'
 */
void LKAS_Count_5s1_Reset(DW_Count_5s1_LKAS_T *localDW)
{
  /* InitializeConditions for Memory: '<S543>/Memory' */
  localDW->Memory_PreviousInput = 0.0F;
}

/*
 * Disable for enable system:
 *    '<S281>/Count_5s1'
 *    '<S281>/Count_5s2'
 */
void LKAS_Count_5s1_Disable(boolean *rty_Out, DW_Count_5s1_LKAS_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S281>/Count_5s1' incorporates:
   *  EnablePort: '<S543>/Enable'
   */
  /* Disable for Outport: '<S543>/Out' */
  *rty_Out = false;

  /* End of Outputs for SubSystem: '<S281>/Count_5s1' */
  localDW->Count_5s1_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S281>/Count_5s1'
 *    '<S281>/Count_5s2'
 */
void LKAS_Count_5s1(boolean rtu_Enable, float32 rtu_SampleTime, boolean *rty_Out,
                    DW_Count_5s1_LKAS_T *localDW)
{
  float32 rtb_Saturation_ag;

  /* Outputs for Enabled SubSystem: '<S281>/Count_5s1' incorporates:
   *  EnablePort: '<S543>/Enable'
   */
  if (rtu_Enable) {
    if (!localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Reset(localDW);
      localDW->Count_5s1_MODE = true;
    }

    /* Sum: '<S543>/Add' incorporates:
     *  Memory: '<S543>/Memory'
     */
    rtb_Saturation_ag = localDW->Memory_PreviousInput + rtu_SampleTime;

    /* Saturate: '<S543>/Saturation' */
    if (rtb_Saturation_ag > 11.0F) {
      rtb_Saturation_ag = 11.0F;
    } else {
      if (rtb_Saturation_ag < 0.0F) {
        rtb_Saturation_ag = 0.0F;
      }
    }

    /* End of Saturate: '<S543>/Saturation' */

    /* RelationalOperator: '<S543>/Relational Operator' incorporates:
     *  Constant: '<S543>/Constant1'
     */
    *rty_Out = (rtb_Saturation_ag >= ((float32)((uint16)5U)));

    /* Update for Memory: '<S543>/Memory' */
    localDW->Memory_PreviousInput = rtb_Saturation_ag;
  } else {
    if (localDW->Count_5s1_MODE) {
      LKAS_Count_5s1_Disable(rty_Out, localDW);
    }
  }

  /* End of Outputs for SubSystem: '<S281>/Count_5s1' */
}

/* Model step function for TID1 */
void Runnable_LKAS_Step(void)          /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  uint32 rtb_Gain2;
  uint32 rtb_Gain;
  uint32 rtb_Gain1;
  float32 rtb_IMAPve_g_EPS_SW_Trq;
  float32 rtb_IMAPve_g_ESC_VehSpd;
  float32 rtb_IMAPve_g_ESC_LonAcc;
  float32 rtb_Gain_j;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_ENA;
  float32 rtb_LL_MIN_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_ENABLE;
  float32 rtb_LL_MAX_LONG_ACC_ENABLE;
  float32 rtb_LL_LKA_EarliestWarnLine_C;
  float32 rtb_Gain_g;
  float32 rtb_LL_MAX_SYSTEM_CURVATURE_DIS;
  float32 rtb_LL_MIN_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LANE_WIDTH_DISABLE;
  float32 rtb_LL_MAX_LONG_ACC_DISABLE;
  float32 rtb_LL_MAX_DELAY_EPSSTAR_TIME;
  float32 rtb_LL_ThresDet_lDvtThresUprLDW;
  float32 rtb_LL_LFClb_TFC_KpVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KpVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KpV1_C;
  float32 rtb_LL_LFClb_TFC_KpV2_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdLwr_C;
  float32 rtb_LL_LFClb_TFC_KdVehSpdUpr_C;
  float32 rtb_LL_LFClb_TFC_KdV1_C;
  float32 rtb_LL_LFClb_TFC_KdV2_C;
  float32 rtb_LKA_SampleTime;
  float32 rtb_LKA_CarWidth;
  float32 rtb_LL_HandsOff_WarnTime;
  float32 rtb_LL_HandsOff_TextTime;
  float32 rtb_R0_VR_e;
  float32 rtb_L0_VR_e;
  float32 rtb_R0_W_d;
  float32 rtb_L0_W_f;
  float32 rtb_IMAPve_g_EMS_RealPedal;
  float32 rtb_IMAPve_g_EPS_LKA_Current;
  float32 rtb_IMAPve_g_EPS_SteeringAngle;
  float32 rtb_IMAPve_g_ESC_Brake_Press;
  float32 rtb_IMAPve_g_ESC_UnYawRate;
  float32 rtb_IMAPve_g_ESC_YawRate;
  float32 rtb_L1_C0;
  float32 rtb_L1_C1;
  float32 rtb_L1_C2;
  float32 rtb_L1_C3;
  float32 rtb_L1_VR;
  float32 rtb_L1_W;
  float32 rtb_R1_C0;
  float32 rtb_R1_C1;
  float32 rtb_R1_C2;
  float32 rtb_R1_C3;
  float32 rtb_R1_VR;
  float32 rtb_R1_W;
  float32 rtb_LL_DvtComp_C;
  float32 rtb_LL_lStpLngth_C;
  float32 rtb_LL_DesDvt_C;
  float32 rtb_LL_NomTAhd_C;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_TTLC;
  float32 rtb_LL_DvtComp_C_i;
  float32 rtb_LL_LDW_EarliestWarnLine_C;
  float32 rtb_LL_RlsDet_tiTDelTime_DISABL;
  float32 rtb_Gain1_j;
  float32 rtb_phiHdAg_Lft;
  float32 rtb_Add5_n;
  float32 rtb_phiHdAg_Rgt;
  float32 rtb_Add_p;
  float32 rtb_Add_o;
  float32 rtb_LFTTTLC;
  float32 rtb_RGTTTLC;
  float32 rtb_LaneWidth;
  float32 rtb_Merge;
  float32 rtb_Switch_d;
  float32 rtb_Saturation_c;
  float32 rtb_Abs1;
  float32 rtb_Abs;
  float32 rtb_UnaryMinus;
  float32 rtb_Multiply;
  float32 rtb_Switch_i;
  float32 rtb_Switch2_f;
  float32 rtb_Switch_h;
  float32 rtb_Saturation_f;
  float32 rtb_Abs1_m;
  float32 rtb_Abs_i;
  float32 rtb_UnaryMinus_n;
  float32 rtb_Merge1;
  float32 rtb_Divide_b;
  float32 rtb_Switch_c;
  float32 rtb_Switch2_o;
  float32 rtb_Divide_ba;
  float32 rtb_Switch_n;
  float32 rtb_Switch2_n;
  float32 rtb_Merge1_f;
  float32 rtb_Divide_d;
  float32 rtb_Switch_gw;
  float32 rtb_Switch2_d;
  float32 rtb_Divide_f;
  float32 rtb_Switch_gi;
  float32 rtb_Switch2_fg;
  float32 rtb_Multiply_d;
  float32 rtb_Switch_p;
  float32 rtb_Switch2_c;
  float32 rtb_Memory_e;
  float32 rtb_Merge1_n;
  float32 rtb_Divide_k;
  float32 rtb_Switch_a;
  float32 rtb_Switch2_j;
  float32 rtb_Divide_kp;
  float32 rtb_Switch_o;
  float32 rtb_Switch2_jh;
  float32 rtb_Memory_p;
  float32 rtb_Merge1_j;
  float32 rtb_Divide_bk;
  float32 rtb_Switch_gl;
  float32 rtb_Switch2_nc;
  float32 rtb_Divide_h;
  float32 rtb_Switch_e;
  float32 rtb_Switch2_g;
  float32 rtb_Divide_ca;
  float32 rtb_Divide_dv;
  float32 rtb_Add_am;
  float32 rtb_Add_e1;
  float32 rtb_phiHdAg;
  float32 rtb_lDvt;
  float32 rtb_crCrvt;
  float32 rtb_ThresDet_coefficient;
  float32 rtb_ThresDet_coefficient_a;
  float32 rtb_Saturation2_g;
  float32 rtb_Add1_i;
  float32 rtb_Merge_c;
  float32 rtb_Gain_iu;
  float32 rtb_Gain1_p;
  float32 rtb_Add_id;
  float32 rtb_Add_l;
  float32 rtb_Saturation6;
  float32 rtb_Saturation2_l;
  float32 rtb_Saturation2_n;
  float32 rtb_Add6;
  float32 rtb_ExNum;
  float32 rtb_Saturation_gi;
  float32 rtb_Saturation_e;
  float32 rtb_Add1_h;
  float32 rtb_kphtomps_l;
  float32 rtb_Saturation_j;
  float32 rtb_Switch2_i;
  float32 rtb_Switch_k;
  float32 rtb_Switch2_at;
  float32 rtb_Gain1_i5;
  float32 rtb_Switch_fy;
  float32 rtb_Switch2_g1;
  float32 rtb_Divide5_l;
  float32 rtb_Divide2_be;
  float32 rtb_Merge_d;
  float32 rtb_Switch_fl;
  float32 rtb_Switch2_k;
  float32 rtb_Divide7;
  float32 rtb_Switch_pi;
  float32 rtb_Switch2_p;
  float32 rtb_Saturation_nf;
  float32 rtb_Switch_kb;
  float32 rtb_Add_of;
  float32 rtb_Switch_og;
  float32 rtb_Switch2_m;
  float32 rtb_UkYk1_o;
  float32 rtb_Switch_dr;
  float32 rtb_Switch2_co;
  float32 rtb_Abs1_g;
  float32 rtb_Abs_h;
  float32 rtb_Add1_kd;
  float32 rtb_Merge_f;
  float32 rtb_Merge_fs;
  float32 rtb_Merge_k;
  float32 rtb_MPInP_vVehSpd;
  float32 rtb_Saturation_gv;
  float32 rtb_Saturation_ae;
  float32 rtb_SWACmd_phiSWACmd;
  float32 rtb_In;
  float32 rtb_In_j;
  float32 rtb_In_a;
  float32 rtb_Plan;
  float32 rtb_T1_i;
  float32 rtb_Plan_g;
  float32 rtb_T1_g;
  float32 rtb_Gain_m;
  float32 rtb_Merge_e;
  float32 rtb_kphTomps_j;
  float32 rtb_Divide3_j;
  float32 rtb_Gain2_bi;
  uint16 rtb_L1_Q;
  uint16 rtb_R1_Q;
  uint16 rtb_Saturation1_f;
  uint16 rtb_Saturation1_a;
  uint16 rtb_Saturation1_b;
  uint16 rtb_Saturation1_k;
  uint16 rtb_Saturation1_m;
  uint16 rtb_Saturation2_b;
  uint16 rtb_Add_jk;
  uint16 rtb_Saturation1_or;
  uint16 rtb_Saturation1_p;
  uint8 rtb_LKA_Switch_State;
  uint8 rtb_R0_Type_g;
  uint8 rtb_L0_Type_e;
  uint8 rtb_LDW_Warn_Mode;
  uint8 rtb_IMAPve_d_APA_AutoPark_WorkS;
  uint8 rtb_IMAPve_d_BCM_HazardLamp_g;
  uint8 rtb_IMAPve_d_EPS_Driver_Overrid;
  uint8 rtb_IMAPve_d_EPS_ESA_State;
  uint8 rtb_IMAPve_d_EPS_Steer_Hold_Sta;
  uint8 rtb_IMAPve_d_EPS_SteeringAngle_;
  uint8 rtb_IMAPve_d_Fusion_Status;
  uint8 rtb_L1_Type;
  uint8 rtb_IMAPve_d_MP5_Work_State;
  uint8 rtb_R1_Type;
  uint8 rtb_IMAPve_d_SWS_Failure_Status;
  uint8 rtb_IMAPve_d_Sensor_Status;
  uint8 rtb_IMAPve_d_TCU_TCU_Available;
  uint8 rtb_LDW_State;
  uint8 rtb_DACMode;
  uint8 rtb_Saturation1_cv;
  boolean rtb_LogicalOperator2;
  boolean rtb_Compare_ku;
  boolean rtb_Compare_p;
  boolean rtb_Compare_pi;
  boolean rtb_Compare_ct;
  boolean rtb_Compare_ic;
  boolean rtb_Compare_nc;
  boolean rtb_Compare_pp;
  boolean rtb_Compare_a;
  boolean rtb_Compare_d2;
  boolean rtb_Compare_bw;
  boolean rtb_Compare_iz;
  boolean rtb_UnitDelay_m;
  boolean rtb_Merge_i;
  boolean rtb_Compare_km;
  boolean rtb_UnitDelay_h;
  boolean rtb_Compare_cj;
  boolean rtb_Merge_c0;
  boolean rtb_Compare_gt;
  boolean rtb_Compare_oz;
  boolean rtb_Merge_n;
  boolean rtb_Compare_bi;
  boolean rtb_LogicalOperator1_f;
  boolean rtb_Compare_mx;
  boolean rtb_Compare_hr;
  boolean rtb_RelationalOperator6_i;
  boolean rtb_RelationalOperator5;
  boolean rtb_Compare_az;
  boolean rtb_Memory1;
  boolean rtb_Merge_ba;
  float32 x10;
  float32 x20;
  float32 x1;
  sint32 i;
  uint8 rtb_Mod1;
  uint8 rtb_IMAPve_d_SAS_Trim_State;
  boolean rtb_LKA_Main_Switch;
  float32 rtb_Abs_k;
  float32 rtb_L0_C0;
  float32 rtb_L0_C2;
  float32 rtb_R0_C2;
  float32 rtb_Saturation;
  float32 rtb_R0_C0;
  uint8 rtb_L0_Q;
  uint8 rtb_R0_Q;
  float32 rtb_Add1;
  float32 rtb_Saturation1;
  uint8 rtb_L0_Type;
  uint8 rtb_R0_Type;
  float32 rtb_L0_C3;
  uint8 rtb_IMAPve_d_Camera_Status;
  uint8 rtb_IMAPve_d_EPS_LKA_State;
  boolean rtb_BCM_Left_Light;
  boolean rtb_BCM_Right_Light;
  uint8 rtb_IMAPve_d_TCU_Actual_Gear;
  uint8 rtb_TCU_ActualGear;
  uint8 rtb_Hands_Off_Warning_c;
  uint8 rtb_LKA_Action_Indication_d;
  float32 rtb_L0_C0_o;
  float32 rtb_LL_CompHdAg_C;
  float32 rtb_L0_C1_i;
  float32 rtb_R0_C1_e;
  float32 rtb_L0_C1_m;
  float32 rtb_L0_C3_dc;
  float32 rtb_R0_C0_n;
  float32 rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
  float32 rtb_LL_LDW_LatestWarnLine_C;
  float32 rtb_LL_MAX_DRIVER_TORQUE_DISABL;
  float32 rtb_LL_TkOvStChk_tiTDelTime;
  boolean rtb_LL_SingleLane_Disable_Swt;
  float32 rtb_LL_ThresDet_lDvtThresLwrLDW;
  float32 rtb_LL_ThresDet_tiTTLCThresLDW;
  float32 rtb_LL_ThresDet_lDvtThresLwrLKA;
  float32 rtb_LL_ThresDet_lDvtThresUprLKA;
  float32 rtb_LL_ThresDet_tiTTLCThresLKA;
  float32 rtb_LL_DvtSpdDet_vDvtSpdMin_C;
  float32 rtb_LL_HdAgPrvwT_C;
  float32 rtb_LL_LKASWASyn_M0;
  float32 rtb_LL_LKASWASyn_M1;
  float32 rtb_LL_LKASWASyn_T2;
  float32 rtb_LL_LKASWASyn_M3K;
  float32 rtb_LL_LKAExPrcs_tiExitTime1;
  float32 rtb_LL_LKAExPrcs_tiExitTime2;
  float32 rtb_LL_LKAExPrcs_ExitC0Dvt;
  float32 rtb_LKA_Veh2CamW_C;
  float32 rtb_LKA_Veh2CamL_C;
  float32 rtb_Abs_pw;
  float32 rtb_Abs_a;
  float32 rtb_TTLC_d;
  float32 rtb_LftTTLC;
  float32 rtb_TTLC_n;
  boolean rtb_LogicalOperator3_b5;
  boolean rtb_LogicalOperator3_pm;
  boolean rtb_Compare_mln;
  boolean rtb_LogicalOperator_iv;
  boolean rtb_Compare_pxf;
  boolean rtb_LogicalOperator_ix;
  boolean rtb_Compare_ab;
  boolean rtb_phiSWA_Thres;
  boolean rtb_dphiSWARate_Thres;
  boolean rtb_aLAcc_Thres;
  boolean rtb_Compare_cwd;
  boolean rtb_RelationalOperator_b;
  boolean rtb_LogicalOperator_ol;
  boolean rtb_LogicalOperator_m;
  uint8 rtb_CastToSingle3;
  sint8 rtPrevAction;
  sint8 rtAction;
  boolean rtb_Merge_a3;
  float32 rtb_offset;
  uint16 rtb_Saturation_h5;
  boolean rtb_TmpSignalConversionAtSFunct[18];
  float32 rtb_TTLC;
  float32 rtb_TLft;
  float32 tmp;
  float32 rtb_Abs_f_tmp;
  float32 rtb_Add5_n_tmp;
  float32 rtb_LogicalOperator3_c_tmp;
  float32 rtb_LogicalOperator3_c_tmp_0;
  float32 rtb_LogicalOperator3_c_tmp_1;
  boolean rtb_LogicalOperator3_p_tmp;
  float32 rtb_Add_p_tmp;
  float32 rtb_Add_o_tmp;
  boolean exitg1;

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* DataTypeConversion: '<S1>/FDMMve_d_LkaFcnConf_1' incorporates:
   *  Inport: '<Root>/FDMMve_d_LkaFcnConf'
   */
  rtb_Mod1 = (uint8)
    Rte_IRead_Runnable_LKAS_Step_FDMMve_d_LkaFcnConf_FDMMve_d_LkaFcnConf();

  /* Switch: '<S44>/Switch' incorporates:
   *  Constant: '<S44>/Constant3'
   *  Constant: '<S44>/Constant4'
   */
  if (rtb_Mod1 > ((uint8)0U)) {
    rtb_L0_Q = ((uint8)1U);
  } else {
    rtb_L0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S44>/Switch' */

  /* Saturate: '<S44>/Saturation1' */
  if (rtb_Mod1 > ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  } else {
    if (rtb_Mod1 < ((uint8)1U)) {
      rtb_Mod1 = ((uint8)1U);
    }
  }

  /* End of Saturate: '<S44>/Saturation1' */

  /* Sum: '<S44>/Add1' incorporates:
   *  Constant: '<S44>/Constant1'
   */
  rtb_Mod1 -= ((uint8)1U);

  /* Saturate: '<S44>/Saturation' */
  if (rtb_Mod1 >= ((uint8)12U)) {
    rtb_Mod1 = ((uint8)12U);
  }

  /* End of Saturate: '<S44>/Saturation' */

  /* Math: '<S44>/Mod' incorporates:
   *  Constant: '<S44>/Constant2'
   */
  if (((sint32)((uint8)6U)) == 0) {
    rtb_R0_Q = rtb_Mod1;
  } else {
    rtb_R0_Q = (uint8)(rtb_Mod1 % ((uint8)6U));
  }

  /* End of Math: '<S44>/Mod' */

  /* Product: '<S44>/Divide1' incorporates:
   *  Constant: '<S44>/Constant5'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)(((uint32)rtb_R0_Q) / ((uint32)((uint8)3U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_LKA_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LKA_Mode'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Mode_IMAPve_d_LKA_Mode();

  /* MinMax: '<S44>/Max' */
  if (rtb_IMAPve_d_SAS_Trim_State > rtb_L0_Type) {
    rtb_L0_Type = rtb_IMAPve_d_SAS_Trim_State;
  }

  /* End of MinMax: '<S44>/Max' */

  /* Product: '<S44>/Divide' incorporates:
   *  Constant: '<S44>/Constant6'
   *  DataTypeConversion: '<S1>/IMAPve_d_LKA_Main_Switch_1'
   *  Inport: '<Root>/IMAPve_d_LKA_Main_Switch'
   *  Logic: '<S44>/Logical Operator'
   *  Sum: '<S44>/Add'
   */
  LKAS_DW.LKA_Mode = (uint8)((sint32)(((((sint32)rtb_L0_Q) != 0) || (((sint32)
    ((uint8)
     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LKA_Main_Switch_IMAPve_d_LKA_Main_Switch
     ())) != 0)) ? ((sint32)((uint8)(((uint32)rtb_L0_Type) + ((uint32)((uint8)1U)))))
    : 0));

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Q'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Q_IMAPve_d_L0_Q();

  /* Switch: '<S55>/Switch' incorporates:
   *  Constant: '<S55>/Constant'
   */
  if (rtb_IMAPve_d_SAS_Trim_State >= ((uint8)2U)) {
    rtb_L0_Q = ((uint8)3U);
  } else {
    rtb_L0_Q = rtb_IMAPve_d_SAS_Trim_State;
  }

  /* End of Switch: '<S55>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Q_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Q'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Q_IMAPve_d_R0_Q();

  /* Switch: '<S52>/Switch1' incorporates:
   *  Constant: '<S52>/Constant1'
   */
  if (rtb_IMAPve_d_SAS_Trim_State >= ((uint8)2U)) {
    rtb_R0_Q = ((uint8)3U);
  } else {
    rtb_R0_Q = rtb_IMAPve_d_SAS_Trim_State;
  }

  /* End of Switch: '<S52>/Switch1' */

  /* Chart: '<S51>/LaneReconstructSM' */
  /* Gateway: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  /* During: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
   /LaneReconstructSM */
  if (((uint32)LKAS_DW.is_active_c26_LKAS) == 0U) {
    /* Entry: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    LKAS_DW.is_active_c26_LKAS = 1U;

    /* Entry Internal: LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct
     /LaneReconstructSM */
    /* Transition: '<S56>:4' */
    LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

    /* Entry 'NoLaneLost': '<S56>:3' */
    /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
    /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
    LKAS_DW.LaneRSM_stLftFlg = 1U;

    /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
    LKAS_DW.LaneRSM_stRgtFlg = 1U;
  } else {
    switch (LKAS_DW.is_c26_LKAS) {
     case LKAS_IN_DoubleLost:
      /* During 'DoubleLost': '<S56>:9' */
      /* '<S56>:13:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:13' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S56>:3' */
        /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:14:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S56>:14' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S56>:7' */
          /* '<S56>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S56>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S56>:23:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
            /* Transition: '<S56>:23' */
            LKAS_DW.is_c26_LKAS = LKAS_IN_LeftLost;

            /* Entry 'LeftLost': '<S56>:5' */
            /* '<S56>:5:1' LaneRSM_stRoadFlg=uint8(0); */
            /* '<S56>:5:1' LaneRSM_stLftFlg=uint8(0); */
            LKAS_DW.LaneRSM_stLftFlg = 0U;

            /* '<S56>:5:2' LaneRSM_stRgtFlg=uint8(1); */
            LKAS_DW.LaneRSM_stRgtFlg = 1U;
          }
        }
      }
      break;

     case LKAS_IN_LeftLost:
      LKAS_DW.LaneRSM_stLftFlg = 0U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'LeftLost': '<S56>:5' */
      /* '<S56>:16:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:16' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S56>:3' */
        /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:18:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S56>:18' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S56>:7' */
          /* '<S56>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S56>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S56>:11:1' sf_internal_predicateOutput = LaneRSM_stR0Ql<3; */
          if (((sint32)rtb_R0_Q) < 3) {
            /* Transition: '<S56>:11' */
            LKAS_DW.is_c26_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     case LKAS_IN_NoLaneLost:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 1U;

      /* During 'NoLaneLost': '<S56>:3' */
      /* '<S56>:6:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:6' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_LeftLost;

        /* Entry 'LeftLost': '<S56>:5' */
        /* '<S56>:5:1' LaneRSM_stRoadFlg=uint8(0); */
        /* '<S56>:5:1' LaneRSM_stLftFlg=uint8(0); */
        LKAS_DW.LaneRSM_stLftFlg = 0U;

        /* '<S56>:5:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:8:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql<3; */
        if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) < 3)) {
          /* Transition: '<S56>:8' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_RightLost;

          /* Entry 'RightLost': '<S56>:7' */
          /* '<S56>:7:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:7:1' LaneRSM_stLftFlg=uint8(1); */
          LKAS_DW.LaneRSM_stLftFlg = 1U;

          /* '<S56>:7:2' LaneRSM_stRgtFlg=uint8(0); */
          LKAS_DW.LaneRSM_stRgtFlg = 0U;
        } else {
          /* '<S56>:10:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql<3; */
          if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) < 3)) {
            /* Transition: '<S56>:10' */
            /* '<S56>:10:1' LaneRSM_stRoadFlg=uint8(0); */
            LKAS_DW.is_c26_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;

     default:
      LKAS_DW.LaneRSM_stLftFlg = 1U;
      LKAS_DW.LaneRSM_stRgtFlg = 0U;

      /* During 'RightLost': '<S56>:7' */
      /* '<S56>:17:1' sf_internal_predicateOutput = LaneRSM_stL0Ql==3&&LaneRSM_stR0Ql==3; */
      if ((((sint32)rtb_L0_Q) == 3) && (((sint32)rtb_R0_Q) == 3)) {
        /* Transition: '<S56>:17' */
        LKAS_DW.is_c26_LKAS = LKAS_IN_NoLaneLost;

        /* Entry 'NoLaneLost': '<S56>:3' */
        /* '<S56>:3:1' LaneRSM_stRoadFlg=uint8(1); */
        /* '<S56>:3:1' LaneRSM_stLftFlg=uint8(1); */
        LKAS_DW.LaneRSM_stLftFlg = 1U;

        /* '<S56>:3:2' LaneRSM_stRgtFlg=uint8(1); */
        LKAS_DW.LaneRSM_stRgtFlg = 1U;
      } else {
        /* '<S56>:19:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3&&LaneRSM_stR0Ql==3; */
        if ((((sint32)rtb_L0_Q) < 3) && (((sint32)rtb_R0_Q) == 3)) {
          /* Transition: '<S56>:19' */
          LKAS_DW.is_c26_LKAS = LKAS_IN_LeftLost;

          /* Entry 'LeftLost': '<S56>:5' */
          /* '<S56>:5:1' LaneRSM_stRoadFlg=uint8(0); */
          /* '<S56>:5:1' LaneRSM_stLftFlg=uint8(0); */
          LKAS_DW.LaneRSM_stLftFlg = 0U;

          /* '<S56>:5:2' LaneRSM_stRgtFlg=uint8(1); */
          LKAS_DW.LaneRSM_stRgtFlg = 1U;
        } else {
          /* '<S56>:12:1' sf_internal_predicateOutput = LaneRSM_stL0Ql<3; */
          if (((sint32)rtb_L0_Q) < 3) {
            /* Transition: '<S56>:12' */
            LKAS_DW.is_c26_LKAS = LKAS_IN_DoubleLost;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S51>/LaneReconstructSM' */

  /* DataTypeConversion: '<S50>/Cast To Single64' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C0_1'
   *  Inport: '<Root>/IMAPve_g_L0_C0'
   *  UnaryMinus: '<S50>/Unary Minus'
   */
  rtb_L0_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C0_IMAPve_g_L0_C0
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single65' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C2_1'
   *  Inport: '<Root>/IMAPve_g_L0_C2'
   *  UnaryMinus: '<S50>/Unary Minus2'
   */
  rtb_L0_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C2_IMAPve_g_L0_C2
    ()));

  /* UnaryMinus: '<S50>/Unary Minus6' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C2_1'
   *  Inport: '<Root>/IMAPve_g_R0_C2'
   */
  rtb_Abs_k = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C2_IMAPve_g_R0_C2
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single56' */
  rtb_R0_C2 = rtb_Abs_k;

  /* Sum: '<S61>/Add2' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single56'
   */
  rtb_Abs_k += rtb_L0_C2;

  /* Abs: '<S61>/Abs' */
  rtb_Abs_k = fabsf(rtb_Abs_k);

  /* Saturate: '<S61>/Saturation' */
  if (rtb_Abs_k > 0.004F) {
    rtb_Saturation = 0.004F;
  } else if (rtb_Abs_k < 0.0F) {
    rtb_Saturation = 0.0F;
  } else {
    rtb_Saturation = rtb_Abs_k;
  }

  /* End of Saturate: '<S61>/Saturation' */

  /* UnaryMinus: '<S50>/Unary Minus4' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C0_1'
   *  Inport: '<Root>/IMAPve_g_R0_C0'
   */
  rtb_Abs_k = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C0_IMAPve_g_R0_C0
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single55' */
  rtb_R0_C0 = rtb_Abs_k;

  /* Switch: '<S65>/Switch' incorporates:
   *  Constant: '<S74>/Constant'
   *  Constant: '<S75>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single55'
   *  Delay: '<S65>/Delay'
   *  Gain: '<S65>/Gain'
   *  Logic: '<S65>/Logical Operator'
   *  RelationalOperator: '<S74>/Compare'
   *  RelationalOperator: '<S75>/Compare'
   *  Sum: '<S65>/Add'
   */
  if ((rtb_L0_Q >= ((uint8)2U)) && (rtb_R0_Q >= ((uint8)2U))) {
    rtb_Abs_k += (-1.0F) * rtb_L0_C0;
  } else {
    rtb_Abs_k = LKAS_DW.Delay_DSTATE;
  }

  /* End of Switch: '<S65>/Switch' */

  /* Sum: '<S73>/Add1' incorporates:
   *  Memory: '<S73>/Memory'
   *  Product: '<S73>/Divide'
   *  Product: '<S73>/Divide1'
   */
  rtb_Add1 = (rtb_Abs_k * LKAS_ConstB.Divide2) + (LKAS_ConstB.Add2 *
    LKAS_DW.Memory_PreviousInput);

  /* Saturate: '<S65>/Saturation1' */
  if (rtb_Add1 > 5.5F) {
    rtb_Saturation1 = 5.5F;
  } else if (rtb_Add1 < 2.5F) {
    rtb_Saturation1 = 2.5F;
  } else {
    rtb_Saturation1 = rtb_Add1;
  }

  /* End of Saturate: '<S65>/Saturation1' */

  /* MATLAB Function: '<S61>/get_roadside_offset' */
  /* MATLAB Function 'LKAS/LL/LL Inputs Mapping/bsLaneInfo/LanesReconstruct /RoadSide Offset/get_roadside_offset': '<S67>:1' */
  /* '<S67>:1:2' lanewidth=min(single(4),lanewidth); */
  /* '<S67>:1:3' cur=min(single(0.004),cur); */
  /* '<S67>:1:4' offset=(cur/single(0.004)+single(1))*single(0.2)*(lanewidth-single(2)); */
  /*  �����߿�4�ף�·�ؿ���ƫ��0.4����3m��·�ؿ���ƫ�ã�0.2m */
  /* '<S67>:1:5' offset=min(single(0.5),offset); */
  rtb_offset = fminf(0.5F, (((fminf(0.004F, rtb_Saturation) / 0.004F) + 1.0F) *
    0.2F) * (fminf(4.0F, rtb_Saturation1) - 2.0F));

  /* DataTypeConversion: '<S1>/IMAPve_d_L0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_L0_Type'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L0_Type_IMAPve_d_L0_Type();

  /* DataTypeConversion: '<S50>/Cast To Single77' */
  rtb_L0_Type = rtb_IMAPve_d_SAS_Trim_State;

  /* Switch: '<S66>/Switch' incorporates:
   *  Constant: '<S77>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single77'
   *  RelationalOperator: '<S77>/Compare'
   *  Sum: '<S66>/Add'
   */
  if (rtb_IMAPve_d_SAS_Trim_State == ((uint8)10U)) {
    rtb_L0_C0 += rtb_offset;
  }

  /* End of Switch: '<S66>/Switch' */

  /* Switch: '<S76>/Switch' incorporates:
   *  Abs: '<S76>/Abs'
   *  Constant: '<S78>/Constant'
   *  Memory: '<S76>/Memory'
   *  Memory: '<S76>/Memory1'
   *  Product: '<S76>/Divide'
   *  Product: '<S76>/Divide1'
   *  RelationalOperator: '<S78>/Compare'
   *  Sum: '<S76>/Add1'
   *  Sum: '<S76>/Add3'
   */
  if (fabsf(rtb_L0_C0 - LKAS_DW.Memory1_PreviousInput) > 0.5F) {
    rtb_Saturation = rtb_L0_C0;
  } else {
    rtb_Saturation = (rtb_L0_C0 * LKAS_ConstB.Divide2_l) + (LKAS_ConstB.Add2_b *
      LKAS_DW.Memory_PreviousInput_m);
  }

  /* End of Switch: '<S76>/Switch' */

  /* DataTypeConversion: '<S1>/IMAPve_d_R0_Type_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_R0_Type'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R0_Type_IMAPve_d_R0_Type();

  /* DataTypeConversion: '<S50>/Cast To Single48' */
  rtb_R0_Type = rtb_IMAPve_d_SAS_Trim_State;

  /* Switch: '<S62>/Switch1' incorporates:
   *  Constant: '<S69>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single48'
   *  RelationalOperator: '<S69>/Compare'
   *  Sum: '<S62>/Add1'
   */
  if (rtb_IMAPve_d_SAS_Trim_State == ((uint8)10U)) {
    rtb_R0_C0 -= rtb_offset;
  }

  /* End of Switch: '<S62>/Switch1' */

  /* Switch: '<S68>/Switch' incorporates:
   *  Abs: '<S68>/Abs'
   *  Constant: '<S70>/Constant'
   *  Memory: '<S68>/Memory'
   *  Memory: '<S68>/Memory1'
   *  Product: '<S68>/Divide'
   *  Product: '<S68>/Divide1'
   *  RelationalOperator: '<S70>/Compare'
   *  Sum: '<S68>/Add1'
   *  Sum: '<S68>/Add3'
   */
  if (fabsf(rtb_R0_C0 - LKAS_DW.Memory1_PreviousInput_h) > 0.5F) {
    rtb_offset = rtb_R0_C0;
  } else {
    rtb_offset = (rtb_R0_C0 * LKAS_ConstB.Divide2_lw) + (LKAS_ConstB.Add2_j *
      LKAS_DW.Memory_PreviousInput_f);
  }

  /* End of Switch: '<S68>/Switch' */

  /* Switch: '<S51>/Switch1' incorporates:
   *  Gain: '<S58>/Gain'
   *  Sum: '<S58>/Add'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C0_o = rtb_Saturation;
  } else {
    rtb_L0_C0_o = (rtb_Saturation1 - rtb_offset) * (-1.0F);
  }

  /* Switch: '<S557>/Switch24' incorporates:
   *  Constant: '<S557>/LL_CompHdAg_C=0.005'
   */
  if (LKAS_ConstB.DataTypeConversion38 != 0.0F) {
    rtb_LL_CompHdAg_C = LKAS_ConstB.DataTypeConversion38;
  } else {
    rtb_LL_CompHdAg_C = LL_CompHdAg_C;
  }

  /* End of Switch: '<S557>/Switch24' */

  /* Switch: '<S63>/Switch1' incorporates:
   *  Constant: '<S71>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C1_1'
   *  Inport: '<Root>/IMAPve_g_L0_C1'
   *  RelationalOperator: '<S71>/Compare'
   *  Sum: '<S63>/Add'
   *  UnaryMinus: '<S50>/Unary Minus1'
   */
  if (rtb_L0_Q == ((uint8)3U)) {
    rtb_L0_C1_i = rtb_LL_CompHdAg_C + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1())));
  } else {
    rtb_L0_C1_i = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C1_IMAPve_g_L0_C1()));
  }

  /* End of Switch: '<S63>/Switch1' */

  /* Switch: '<S64>/Switch1' incorporates:
   *  Constant: '<S72>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C1_1'
   *  Inport: '<Root>/IMAPve_g_R0_C1'
   *  RelationalOperator: '<S72>/Compare'
   *  Sum: '<S64>/Add'
   *  UnaryMinus: '<S50>/Unary Minus5'
   */
  if (rtb_R0_Q == ((uint8)3U)) {
    rtb_R0_C1_e = rtb_LL_CompHdAg_C + ((float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1())));
  } else {
    rtb_R0_C1_e = (float32)((T_M_Nm_Float32)
      (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C1_IMAPve_g_R0_C1()));
  }

  /* End of Switch: '<S64>/Switch1' */

  /* DataTypeConversion: '<S50>/Cast To Single67' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L0_C3_1'
   *  Inport: '<Root>/IMAPve_g_L0_C3'
   *  UnaryMinus: '<S50>/Unary Minus3'
   */
  rtb_L0_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_C3_IMAPve_g_L0_C3
    ()));

  /* UnaryMinus: '<S50>/Unary Minus7' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_C3_1'
   *  Inport: '<Root>/IMAPve_g_R0_C3'
   */
  rtb_Abs_k = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_C3_IMAPve_g_R0_C3
    ()));

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single60'
   *  DataTypeConversion: '<S58>/Cast To Single1'
   *  DataTypeConversion: '<S58>/Cast To Single2'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_C1_m = rtb_L0_C1_i;
    rtb_LL_CompHdAg_C = rtb_L0_C2;
    rtb_L0_C3_dc = rtb_L0_C3;
  } else {
    rtb_L0_C1_m = rtb_R0_C1_e;
    rtb_LL_CompHdAg_C = rtb_R0_C2;
    rtb_L0_C3_dc = rtb_Abs_k;
  }

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single60'
   *  Sum: '<S60>/Add'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_C0_n = rtb_offset;
    rtb_L0_C1_i = rtb_R0_C1_e;
    rtb_L0_C2 = rtb_R0_C2;
    rtb_L0_C3 = rtb_Abs_k;
  } else {
    rtb_R0_C0_n = rtb_Saturation1 + rtb_Saturation;
  }

  /* DataTypeConversion: '<S1>/IMAPve_d_Camera_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Camera_Status'
   */
  rtb_IMAPve_d_Camera_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Camera_Status_IMAPve_d_Camera_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_LKA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_LKA_State'
   */
  rtb_IMAPve_d_EPS_LKA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_LKA_State_IMAPve_d_EPS_LKA_State();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SW_Trq_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SW_Trq'
   */
  rtb_IMAPve_g_EPS_SW_Trq = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SW_Trq_IMAPve_g_EPS_SW_Trq();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_VehSpd_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_VehSpd'
   */
  rtb_IMAPve_g_ESC_VehSpd = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_VehSpd_IMAPve_g_ESC_VehSpd();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_LonAcc_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_LonAcc'
   */
  rtb_IMAPve_g_ESC_LonAcc = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LonAcc_IMAPve_g_ESC_LonAcc();

  /* DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_SW_Angle'
   */
  rtb_R0_C2 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_IMAPve_g_SW_Angle();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp'
   */
  rtb_IMAPve_d_SAS_Trim_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_IMAPve_d_BCM_HazardLamp
    ();

  /* Logic: '<S41>/Logical Operator' incorporates:
   *  Constant: '<S48>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_LeftTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Left_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_LeftTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Left_Light'
   *  RelationalOperator: '<S48>/Compare'
   */
  rtb_BCM_Left_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Left_Light_IMAPve_d_BCM_Left_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_LeftTurn_Switch_IMAPve_d_BCM_LeftTurn_Switch
                    ()) == ((uint8)1U)));

  /* Logic: '<S41>/Logical Operator1' incorporates:
   *  Constant: '<S49>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_RightTurn_Switch_1'
   *  DataTypeConversion: '<S1>/IMAPve_d_BCM_Right_Light_1'
   *  Inport: '<Root>/IMAPve_d_BCM_RightTurn_Switch'
   *  Inport: '<Root>/IMAPve_d_BCM_Right_Light'
   *  RelationalOperator: '<S49>/Compare'
   */
  rtb_BCM_Right_Light = ((((sint32)((uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_Right_Light_IMAPve_d_BCM_Right_Light
    ())) != 0) || (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_RightTurn_Switch_IMAPve_d_BCM_RightTurn_Switch
                    ()) == ((uint8)1U)));

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_Actual_Gear_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_Actual_Gear'
   */
  rtb_IMAPve_d_TCU_Actual_Gear = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_Actual_Gear_IMAPve_d_TCU_Actual_Gear
    ();

  /* MultiPortSwitch: '<S45>/Multiport Switch' incorporates:
   *  Constant: '<S45>/Constant1'
   *  Constant: '<S45>/Constant3'
   */
  switch (rtb_IMAPve_d_TCU_Actual_Gear) {
   case 0:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 1:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 2:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 3:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 4:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 5:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 6:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;

   case 7:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 8:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   case 9:
    rtb_TCU_ActualGear = ((uint8)3U);
    break;

   default:
    rtb_TCU_ActualGear = ((uint8)0U);
    break;
  }

  /* End of MultiPortSwitch: '<S45>/Multiport Switch' */

  /* Switch: '<S558>/Switch58' incorporates:
   *  Constant: '<S558>/LLSMConClb4'
   *
   * Block description for '<S558>/LLSMConClb4':
   *  LKA���ܵĳ���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion89 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion89;
  } else {
    x10 = LL_MIN_LKAS_SPEED_ENABLE;
  }

  /* End of Switch: '<S558>/Switch58' */

  /* Gain: '<S563>/Gain' incorporates:
   *  Constant: '<S563>/Constant'
   *  Sum: '<S563>/Add'
   */
  rtb_Gain_j = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S558>/Switch84' incorporates:
   *  Constant: '<S558>/LLSMConClb5'
   *
   * Block description for '<S558>/LLSMConClb5':
   *  ����ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion10 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LKAS_ConstB.DataTypeConversion10;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_ENA = LL_MAX_SYSTEM_CURVATURE_ENABLE;
  }

  /* End of Switch: '<S558>/Switch84' */

  /* Switch: '<S558>/Switch85' incorporates:
   *  Constant: '<S558>/LLSMConClb6'
   *
   * Block description for '<S558>/LLSMConClb6':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion11 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion11;
  } else {
    rtb_LL_MIN_LANE_WIDTH_ENABLE = LL_MIN_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S558>/Switch85' */

  /* Switch: '<S558>/Switch86' incorporates:
   *  Constant: '<S558>/LLSMConClb7'
   *
   * Block description for '<S558>/LLSMConClb7':
   *  �����߿���ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion12 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LKAS_ConstB.DataTypeConversion12;
  } else {
    rtb_LL_MAX_LANE_WIDTH_ENABLE = LL_MAX_LANE_WIDTH_ENABLE;
  }

  /* End of Switch: '<S558>/Switch86' */

  /* Switch: '<S558>/Switch54' incorporates:
   *  Constant: '<S558>/LLSMConClb12'
   *
   * Block description for '<S558>/LLSMConClb12':
   *  ������ٶ�ʹ������
   */
  if (LKAS_ConstB.DataTypeConversion19 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_ENABLE = LKAS_ConstB.DataTypeConversion19;
  } else {
    rtb_LL_MAX_LONG_ACC_ENABLE = LL_MAX_LONG_ACC_ENABLE;
  }

  /* End of Switch: '<S558>/Switch54' */

  /* Switch: '<S558>/Switch55' incorporates:
   *  Constant: '<S558>/LLSMConClb13'
   *
   * Block description for '<S558>/LLSMConClb13':
   *  LKA���ܵĲ���ƫ���ٶ���ֵ
   */
  if (LKAS_ConstB.DataTypeConversion20 != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LKAS_ConstB.DataTypeConversion20;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = LL_LKAS_OUT_OF_CONTROL_LAT_VEL;
  }

  /* End of Switch: '<S558>/Switch55' */

  /* Switch: '<S558>/Switch60' incorporates:
   *  Constant: '<S558>/LLSMConClb17'
   *
   * Block description for '<S558>/LLSMConClb17':
   *  LDW���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion44 != 0.0F) {
    rtb_LL_LDW_LatestWarnLine_C = LKAS_ConstB.DataTypeConversion44;
  } else {
    rtb_LL_LDW_LatestWarnLine_C = LL_LDW_LatestWarnLine_C;
  }

  /* End of Switch: '<S558>/Switch60' */

  /* Switch: '<S558>/Switch57' incorporates:
   *  Constant: '<S558>/LLSMConClb18'
   *
   * Block description for '<S558>/LLSMConClb18':
   *  LKA���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion45 != 0.0F) {
    rtb_LL_LKA_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion45;
  } else {
    rtb_LL_LKA_EarliestWarnLine_C = LL_LKA_EarliestWarnLine_C;
  }

  /* End of Switch: '<S558>/Switch57' */

  /* Switch: '<S558>/Switch59' incorporates:
   *  Constant: '<S558>/LLSMConClb19'
   *
   * Block description for '<S558>/LLSMConClb19':
   *  LKA���ܵ����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion46 != 0.0F) {
    rtb_Abs_k = LKAS_ConstB.DataTypeConversion46;
  } else {
    rtb_Abs_k = LL_LKA_LatestWarnLine_C;
  }

  /* End of Switch: '<S558>/Switch59' */

  /* Switch: '<S558>/Switch69' incorporates:
   *  Constant: '<S558>/LLSMConClb22'
   *
   * Block description for '<S558>/LLSMConClb22':
   *  LKA���ܵĳ���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion67 != 0.0F) {
    x10 = LKAS_ConstB.DataTypeConversion67;
  } else {
    x10 = LL_MIN_LKAS_SPEED_DISABLE;
  }

  /* End of Switch: '<S558>/Switch69' */

  /* Gain: '<S560>/Gain' incorporates:
   *  Constant: '<S560>/Constant'
   *  Sum: '<S560>/Add'
   */
  rtb_Gain_g = (x10 - 2.5F) * 0.980392158F;

  /* Switch: '<S558>/Switch68' incorporates:
   *  Constant: '<S558>/LLSMConClb23'
   *
   * Block description for '<S558>/LLSMConClb23':
   *  ����ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion47 != 0.0F) {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LKAS_ConstB.DataTypeConversion47;
  } else {
    rtb_LL_MAX_SYSTEM_CURVATURE_DIS = LL_MAX_SYSTEM_CURVATURE_DISABLE;
  }

  /* End of Switch: '<S558>/Switch68' */

  /* Switch: '<S558>/Switch70' incorporates:
   *  Constant: '<S558>/LLSMConClb24'
   *
   * Block description for '<S558>/LLSMConClb24':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion64 != 0.0F) {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion64;
  } else {
    rtb_LL_MIN_LANE_WIDTH_DISABLE = LL_MIN_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S558>/Switch70' */

  /* Switch: '<S558>/Switch71' incorporates:
   *  Constant: '<S558>/LLSMConClb25'
   *
   * Block description for '<S558>/LLSMConClb25':
   *  �����߿���ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion66 != 0.0F) {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LKAS_ConstB.DataTypeConversion66;
  } else {
    rtb_LL_MAX_LANE_WIDTH_DISABLE = LL_MAX_LANE_WIDTH_DISABLE;
  }

  /* End of Switch: '<S558>/Switch71' */

  /* Switch: '<S558>/Switch73' incorporates:
   *  Constant: '<S558>/LLSMConClb27'
   *
   * Block description for '<S558>/LLSMConClb27':
   *  ��ʻԱת��ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion70 != 0.0F) {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LKAS_ConstB.DataTypeConversion70;
  } else {
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = LL_MAX_DRIVER_TORQUE_DISABLE;
  }

  /* End of Switch: '<S558>/Switch73' */

  /* Switch: '<S558>/Switch62' incorporates:
   *  Constant: '<S558>/LLSMConClb31'
   *
   * Block description for '<S558>/LLSMConClb31':
   *  ������ٶ�ʧЧ����
   */
  if (LKAS_ConstB.DataTypeConversion77 != 0.0F) {
    rtb_LL_MAX_LONG_ACC_DISABLE = LKAS_ConstB.DataTypeConversion77;
  } else {
    rtb_LL_MAX_LONG_ACC_DISABLE = LL_MAX_LONG_ACC_DISABLE;
  }

  /* End of Switch: '<S558>/Switch62' */

  /* Switch: '<S558>/Switch63' incorporates:
   *  Constant: '<S558>/LLSMConClb32'
   *
   * Block description for '<S558>/LLSMConClb32':
   *  LKA���ܵ�EPS�ӳٽ���ȴ���ʱ������
   */
  if (LKAS_ConstB.DataTypeConversion78 != 0.0F) {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LKAS_ConstB.DataTypeConversion78;
  } else {
    rtb_LL_MAX_DELAY_EPSSTAR_TIME = LL_MAX_DELAY_EPSSTAR_TIME;
  }

  /* End of Switch: '<S558>/Switch63' */

  /* Switch: '<S558>/Switch66' incorporates:
   *  Constant: '<S558>/LLSMConClb35'
   *
   * Block description for '<S558>/LLSMConClb35':
   *  �����ϴμ�ʻԱ�ӹ�ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion83 != 0.0F) {
    rtb_LL_TkOvStChk_tiTDelTime = LKAS_ConstB.DataTypeConversion83;
  } else {
    rtb_LL_TkOvStChk_tiTDelTime = LL_TkOvStChk_tiTDelTime;
  }

  /* End of Switch: '<S558>/Switch66' */

  /* Switch: '<S558>/Switch4' incorporates:
   *  Constant: '<S558>/LL_RlsDet_tiTDelTime_DISABLE=4'
   *
   * Block description for '<S558>/LL_RlsDet_tiTDelTime_DISABLE=4':
   *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion4 != 0.0F) {
    rtb_LL_SingleLane_Disable_Swt = (LKAS_ConstB.DataTypeConversion4 != 0.0F);
  } else {
    rtb_LL_SingleLane_Disable_Swt = LL_SingleLane_Disable_Swt;
  }

  /* End of Switch: '<S558>/Switch4' */

  /* Switch: '<S558>/Switch81' incorporates:
   *  Constant: '<S558>/LLSMConClb36'
   *
   * Block description for '<S558>/LLSMConClb36':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion13 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LKAS_ConstB.DataTypeConversion13;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLDW = LL_ThresDet_lDvtThresLwrLDW;
  }

  /* End of Switch: '<S558>/Switch81' */

  /* Switch: '<S558>/Switch82' incorporates:
   *  Constant: '<S558>/LLSMConClb37'
   *
   * Block description for '<S558>/LLSMConClb37':
   *  LDW���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion26 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLDW = LKAS_ConstB.DataTypeConversion26;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLDW = LL_ThresDet_lDvtThresUprLDW;
  }

  /* End of Switch: '<S558>/Switch82' */

  /* Switch: '<S558>/Switch83' incorporates:
   *  Constant: '<S558>/LLSMConClb38'
   *
   * Block description for '<S558>/LLSMConClb38':
   *  LDW���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion65 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLDW = LKAS_ConstB.DataTypeConversion65;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLDW = LL_ThresDet_tiTTLCThresLDW;
  }

  /* End of Switch: '<S558>/Switch83' */

  /* Switch: '<S558>/Switch75' incorporates:
   *  Constant: '<S558>/LLSMConClb39'
   *
   * Block description for '<S558>/LLSMConClb39':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion87 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LKAS_ConstB.DataTypeConversion87;
  } else {
    rtb_LL_ThresDet_lDvtThresLwrLKA = LL_ThresDet_lDvtThresLwrLKA;
  }

  /* End of Switch: '<S558>/Switch75' */

  /* Switch: '<S558>/Switch76' incorporates:
   *  Constant: '<S558>/LLSMConClb40'
   *
   * Block description for '<S558>/LLSMConClb40':
   *  LKA���ܵ�ƫ������������
   */
  if (LKAS_ConstB.DataTypeConversion88 != 0.0F) {
    rtb_LL_ThresDet_lDvtThresUprLKA = LKAS_ConstB.DataTypeConversion88;
  } else {
    rtb_LL_ThresDet_lDvtThresUprLKA = LL_ThresDet_lDvtThresUprLKA;
  }

  /* End of Switch: '<S558>/Switch76' */

  /* Switch: '<S558>/Switch77' incorporates:
   *  Constant: '<S558>/LLSMConClb41'
   *
   * Block description for '<S558>/LLSMConClb41':
   *  LKA���ܵĿ��ʱ�伤����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion85 != 0.0F) {
    rtb_LL_ThresDet_tiTTLCThresLKA = LKAS_ConstB.DataTypeConversion85;
  } else {
    rtb_LL_ThresDet_tiTTLCThresLKA = LL_ThresDet_tiTTLCThresLKA;
  }

  /* End of Switch: '<S558>/Switch77' */

  /* Switch: '<S558>/Switch78' incorporates:
   *  Constant: '<S558>/LLSMConClb42'
   *
   * Block description for '<S558>/LLSMConClb42':
   *  ƫ�������ٶ���Сֵ
   */
  if (LKAS_ConstB.DataTypeConversion86 != 0.0F) {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LKAS_ConstB.DataTypeConversion86;
  } else {
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = LL_DvtSpdDet_vDvtSpdMin_C;
  }

  /* End of Switch: '<S558>/Switch78' */

  /* Switch: '<S557>/Switch3' incorporates:
   *  Constant: '<S557>/LL_HdAgPrvwT_C=0.45'
   */
  if (LKAS_ConstB.DataTypeConversion3_b != 0.0F) {
    rtb_LL_HdAgPrvwT_C = LKAS_ConstB.DataTypeConversion3_b;
  } else {
    rtb_LL_HdAgPrvwT_C = LL_HdAgPrvwT_C;
  }

  /* End of Switch: '<S557>/Switch3' */

  /* Switch: '<S557>/Switch31' incorporates:
   *  Constant: '<S557>/LL_LFClb_TFC_KpVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion14_j != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LKAS_ConstB.DataTypeConversion14_j;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdLwr_C = LL_LFClb_TFC_KpVehSpdLwr_C;
  }

  /* End of Switch: '<S557>/Switch31' */

  /* Switch: '<S557>/Switch34' incorporates:
   *  Constant: '<S557>/LL_LFClb_TFC_KpVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion4_o != 0.0F) {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LKAS_ConstB.DataTypeConversion4_o;
  } else {
    rtb_LL_LFClb_TFC_KpVehSpdUpr_C = LL_LFClb_TFC_KpVehSpdUpr_C;
  }

  /* End of Switch: '<S557>/Switch34' */

  /* Switch: '<S557>/Switch33' incorporates:
   *  Constant: '<S557>/LL_LFClb_TFC_KpV1_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion7_l != 0.0F) {
    rtb_LL_LFClb_TFC_KpV1_C = LKAS_ConstB.DataTypeConversion7_l;
  } else {
    rtb_LL_LFClb_TFC_KpV1_C = LL_LFClb_TFC_KpV1_C;
  }

  /* End of Switch: '<S557>/Switch33' */

  /* Switch: '<S557>/Switch35' incorporates:
   *  Constant: '<S557>/LL_LFClb_TFC_KpV2_C=40'
   */
  if (LKAS_ConstB.DataTypeConversion17_i != 0.0F) {
    rtb_LL_LFClb_TFC_KpV2_C = LKAS_ConstB.DataTypeConversion17_i;
  } else {
    rtb_LL_LFClb_TFC_KpV2_C = LL_LFClb_TFC_KpV2_C;
  }

  /* End of Switch: '<S557>/Switch35' */

  /* Switch: '<S557>/Switch20' incorporates:
   *  Constant: '<S557>/LL_LFClb_TFC_KdVehSpdLwr_C=60'
   */
  if (LKAS_ConstB.DataTypeConversion27 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LKAS_ConstB.DataTypeConversion27;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdLwr_C = LL_LFClb_TFC_KdVehSpdLwr_C;
  }

  /* End of Switch: '<S557>/Switch20' */

  /* Switch: '<S557>/Switch22' incorporates:
   *  Constant: '<S557>/LL_LFClb_TFC_KdVehSpdUpr_C=120'
   */
  if (LKAS_ConstB.DataTypeConversion36 != 0.0F) {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LKAS_ConstB.DataTypeConversion36;
  } else {
    rtb_LL_LFClb_TFC_KdVehSpdUpr_C = LL_LFClb_TFC_KdVehSpdUpr_C;
  }

  /* End of Switch: '<S557>/Switch22' */

  /* Switch: '<S557>/Switch21' incorporates:
   *  Constant: '<S557>/LL_LFClb_TFC_KdV1_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion37 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV1_C = LKAS_ConstB.DataTypeConversion37;
  } else {
    rtb_LL_LFClb_TFC_KdV1_C = LL_LFClb_TFC_KdV1_C;
  }

  /* End of Switch: '<S557>/Switch21' */

  /* Switch: '<S557>/Switch23' incorporates:
   *  Constant: '<S557>/LL_LFClb_TFC_KdV2_C=250'
   */
  if (LKAS_ConstB.DataTypeConversion30 != 0.0F) {
    rtb_LL_LFClb_TFC_KdV2_C = LKAS_ConstB.DataTypeConversion30;
  } else {
    rtb_LL_LFClb_TFC_KdV2_C = LL_LFClb_TFC_KdV2_C;
  }

  /* End of Switch: '<S557>/Switch23' */

  /* Switch: '<S557>/Switch9' incorporates:
   *  Constant: '<S557>/LL_LFClb_TFC_KdBalance_C=1.2'
   */
  if (LKAS_ConstB.DataTypeConversion9 != 0.0F) {
    rtb_R0_C1_e = LKAS_ConstB.DataTypeConversion9;
  } else {
    rtb_R0_C1_e = LL_LFClb_TFC_KdBalance_C;
  }

  /* End of Switch: '<S557>/Switch9' */

  /* Switch: '<S557>/Switch11' incorporates:
   *  Constant: '<S557>/LL_LKASWASyn_M0=0.4'
   */
  if (LKAS_ConstB.DataTypeConversion12_b != 0.0F) {
    rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion12_b;
  } else {
    rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M0;
  }

  /* End of Switch: '<S557>/Switch11' */

  /* Switch: '<S557>/Switch13' incorporates:
   *  Constant: '<S557>/LL_LKASWASyn_M1=0.8'
   */
  if (LKAS_ConstB.DataTypeConversion19_m != 0.0F) {
    rtb_LL_LKASWASyn_M1 = LKAS_ConstB.DataTypeConversion19_m;
  } else {
    rtb_LL_LKASWASyn_M1 = LL_LKASWASyn_M1;
  }

  /* End of Switch: '<S557>/Switch13' */

  /* Switch: '<S557>/Switch16' incorporates:
   *  Constant: '<S557>/LL_LKASWASyn_T2=4'
   */
  if (LKAS_ConstB.DataTypeConversion24 != 0.0F) {
    rtb_LL_LKASWASyn_T2 = LKAS_ConstB.DataTypeConversion24;
  } else {
    rtb_LL_LKASWASyn_T2 = LL_LKASWASyn_T2;
  }

  /* End of Switch: '<S557>/Switch16' */

  /* Switch: '<S557>/Switch18' incorporates:
   *  Constant: '<S557>/LL_LKASWASyn_M3K=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion25 != 0.0F) {
    rtb_LL_LKASWASyn_M3K = LKAS_ConstB.DataTypeConversion25;
  } else {
    rtb_LL_LKASWASyn_M3K = LL_LKASWASyn_M3K;
  }

  /* End of Switch: '<S557>/Switch18' */

  /* Switch: '<S557>/Switch55' incorporates:
   *  Constant: '<S557>/LL_LKAExPrcs_tiExitTime3=8'
   */
  if (LKAS_ConstB.DataTypeConversion55 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime1 = LKAS_ConstB.DataTypeConversion55;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime1 = LL_LKAExPrcs_tiExitTime1;
  }

  /* End of Switch: '<S557>/Switch55' */

  /* Switch: '<S557>/Switch54' incorporates:
   *  Constant: '<S557>/LL_LKAExPrcs_tiExitTime3=4'
   */
  if (LKAS_ConstB.DataTypeConversion54 != 0.0F) {
    rtb_LL_LKAExPrcs_tiExitTime2 = LKAS_ConstB.DataTypeConversion54;
  } else {
    rtb_LL_LKAExPrcs_tiExitTime2 = LL_LKAExPrcs_tiExitTime2;
  }

  /* End of Switch: '<S557>/Switch54' */

  /* Switch: '<S557>/Switch44' incorporates:
   *  Constant: '<S557>/LL_LKAExPrcs_ExitC0Dvt=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion33 != 0.0F) {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LKAS_ConstB.DataTypeConversion33;
  } else {
    rtb_LL_LKAExPrcs_ExitC0Dvt = LL_LKAExPrcs_ExitC0Dvt;
  }

  /* End of Switch: '<S557>/Switch44' */

  /* Switch: '<S555>/Switch19' incorporates:
   *  Constant: '<S555>/LKA_SampleTime=0.01'
   */
  if (LKAS_ConstB.DataTypeConversion3_a != 0.0F) {
    rtb_LKA_SampleTime = LKAS_ConstB.DataTypeConversion3_a;
  } else {
    rtb_LKA_SampleTime = LKA_SampleTime;
  }

  /* End of Switch: '<S555>/Switch19' */

  /* Switch: '<S555>/Switch' incorporates:
   *  Constant: '<S555>/LKA_Veh2CamW_C=0.9'
   */
  if (LKAS_ConstB.DataTypeConversion13_f != 0.0F) {
    rtb_LKA_Veh2CamW_C = LKAS_ConstB.DataTypeConversion13_f;
  } else {
    rtb_LKA_Veh2CamW_C = LKA_Veh2CamW_C;
  }

  /* End of Switch: '<S555>/Switch' */

  /* Switch: '<S555>/Switch1' incorporates:
   *  Constant: '<S555>/LKA_Veh2CamL_C=1.56'
   */
  if (LKAS_ConstB.DataTypeConversion2_c != 0.0F) {
    rtb_LKA_Veh2CamL_C = LKAS_ConstB.DataTypeConversion2_c;
  } else {
    rtb_LKA_Veh2CamL_C = LKA_Veh2CamL_C;
  }

  /* End of Switch: '<S555>/Switch1' */

  /* Switch: '<S555>/Switch2' incorporates:
   *  Constant: '<S555>/LKA_WhlBaseL_C=2.65'
   */
  if (LKAS_ConstB.DataTypeConversion4_m != 0.0F) {
    LKAS_DW.LKA_WhlBaseL_C_m = LKAS_ConstB.DataTypeConversion4_m;
  } else {
    LKAS_DW.LKA_WhlBaseL_C_m = LKA_WhlBaseL_C;
  }

  /* End of Switch: '<S555>/Switch2' */

  /* Switch: '<S555>/Switch3' incorporates:
   *  Constant: '<S555>/LKA_StrRatio_C=15.3'
   */
  if (LKAS_ConstB.DataTypeConversion6_h != 0.0F) {
    LKAS_DW.LKA_StrRatio_C_d = LKAS_ConstB.DataTypeConversion6_h;
  } else {
    LKAS_DW.LKA_StrRatio_C_d = LKA_StrRatio_C;
  }

  /* End of Switch: '<S555>/Switch3' */

  /* Switch: '<S555>/Switch11' incorporates:
   *  Constant: '<S555>/LKA_CarWidth=1.8'
   */
  if (LKAS_ConstB.DataTypeConversion22 != 0.0F) {
    rtb_LKA_CarWidth = LKAS_ConstB.DataTypeConversion22;
  } else {
    rtb_LKA_CarWidth = LKA_CarWidth;
  }

  /* End of Switch: '<S555>/Switch11' */

  /* Outputs for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (((sint32)LKAS_DW.LKA_Mode) > 0) {
    if (!LKAS_DW.LLOn_MODE) {
      /* InitializeConditions for Delay: '<S81>/Delay' */
      LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

      /* InitializeConditions for Memory: '<S520>/Memory' */
      LKAS_DW.Memory_PreviousInput_j = 0.0F;

      /* InitializeConditions for Delay: '<S82>/Delay1' */
      LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S463>/Memory' */
      LKAS_DW.Memory_PreviousInput_c = 0.0F;

      /* InitializeConditions for UnitDelay: '<S395>/Delay Input1'
       *
       * Block description for '<S395>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE = false;

      /* InitializeConditions for UnitDelay: '<S394>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_i = false;

      /* InitializeConditions for UnitDelay: '<S357>/Delay Input1'
       *
       * Block description for '<S357>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_c = false;

      /* InitializeConditions for UnitDelay: '<S355>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_gu = false;

      /* InitializeConditions for UnitDelay: '<S356>/Delay Input1'
       *
       * Block description for '<S356>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_p = false;

      /* InitializeConditions for Memory: '<S322>/Memory' */
      LKAS_DW.Memory_PreviousInput_eq = false;

      /* InitializeConditions for Delay: '<S82>/Delay' */
      LKAS_DW.Delay_DSTATE_j = false;

      /* InitializeConditions for Delay: '<S82>/Delay1' */
      LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

      /* InitializeConditions for Memory: '<S370>/Memory' */
      LKAS_DW.Memory_PreviousInput_id = ((uint8)0U);

      /* InitializeConditions for Memory: '<S296>/Memory' */
      LKAS_DW.Memory_PreviousInput_i = 0.0F;

      /* InitializeConditions for Memory: '<S332>/Memory' */
      LKAS_DW.Memory_PreviousInput_a = 0.0F;

      /* InitializeConditions for Delay: '<S82>/Delay1' */
      LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

      /* SystemReset for Chart: '<S82>/LDW_State_Machine'
       *
       * Block description for '<S82>/LDW_State_Machine':
       *  Block Name: LDW State Machine
       *  Ab.: LDWSM
       *  No.: 1.1.2.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LDW_State_Machine_Reset();

      /* SystemReset for Chart: '<S82>/LKA_State_Machine'
       *
       * Block description for '<S82>/LKA_State_Machine':
       *  Block Name: LKA State Machine
       *  Ab.: LKASM
       *  No.: 1.1.3.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      LKAS_LKA_State_Machine_Reset();
      LKAS_DW.LLOn_MODE = true;
    }

    /* Sum: '<S235>/Add1' incorporates:
     *  MATLAB Function: '<S233>/MATLABFunction3'
     */
    x20 = rtb_L0_C0_o + rtb_LKA_Veh2CamW_C;

    /* Gain: '<S235>/Gain1' incorporates:
     *  Product: '<S235>/Divide'
     *  Product: '<S235>/Divide1'
     *  Sum: '<S235>/Add1'
     *  Sum: '<S235>/Add5'
     *  Trigonometry: '<S235>/Cos2'
     *  Trigonometry: '<S235>/Sin'
     */
    rtb_Gain1_j = ((x20 * cosf(rtb_L0_C1_m)) + (rtb_LKA_Veh2CamL_C * sinf
      (rtb_L0_C1_m))) * (-1.0F);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Gain: '<S227>/Gain1' incorporates:
     *  Gain: '<S123>/Gain'
     *  Gain: '<S169>/kph To mps'
     *  Gain: '<S183>/kph to mps'
     *  Gain: '<S184>/kph to mps'
     *  Gain: '<S233>/Gain2'
     *  Gain: '<S240>/kph to mps'
     *  Gain: '<S246>/kph to mps'
     *  Gain: '<S255>/kph to mps'
     *  Gain: '<S256>/kph to mps'
     */
    rtb_Abs_f_tmp = 0.277777791F * rtb_IMAPve_g_ESC_VehSpd;

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Product: '<S227>/Divide4' incorporates:
     *  Constant: '<S227>/Constant2'
     *  Constant: '<S227>/Constant3'
     *  Gain: '<S227>/Gain1'
     */
    rtb_Abs_a = (rtb_Abs_f_tmp * 2.0F) * 0.1F;

    /* Sum: '<S227>/Add3' incorporates:
     *  Product: '<S227>/Divide3'
     */
    rtb_phiHdAg_Lft = (rtb_LL_CompHdAg_C * rtb_Abs_a) + rtb_L0_C1_m;

    /* Sum: '<S236>/Add1' incorporates:
     *  MATLAB Function: '<S233>/MATLABFunction4'
     */
    rtb_Add5_n_tmp = rtb_R0_C0_n - rtb_LKA_Veh2CamW_C;

    /* Sum: '<S236>/Add5' incorporates:
     *  Product: '<S236>/Divide'
     *  Product: '<S236>/Divide1'
     *  Sum: '<S236>/Add1'
     *  Trigonometry: '<S236>/Cos2'
     *  Trigonometry: '<S236>/Sin'
     */
    rtb_Add5_n = (rtb_Add5_n_tmp * cosf(rtb_L0_C1_i)) + (rtb_LKA_Veh2CamL_C *
      sinf(rtb_L0_C1_i));

    /* Sum: '<S227>/Add1' incorporates:
     *  Product: '<S227>/Divide5'
     */
    rtb_phiHdAg_Rgt = (rtb_L0_C2 * rtb_Abs_a) + rtb_L0_C1_i;

    /* Switch: '<S557>/Switch2' incorporates:
     *  Constant: '<S557>/LL_CrvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion16_i != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion16_i;
    } else {
      x10 = LL_CrvtPrvwT_C;
    }

    /* End of Switch: '<S557>/Switch2' */

    /* Product: '<S240>/Divide' */
    rtb_Abs_a = rtb_Abs_f_tmp * x10;

    /* Gain: '<S237>/Gain' incorporates:
     *  Gain: '<S252>/Gain'
     *  Gain: '<S253>/Gain'
     *  Gain: '<S254>/Gain'
     */
    rtb_Add_p_tmp = 2.0F * rtb_LL_CompHdAg_C;

    /* Sum: '<S237>/Add' incorporates:
     *  Gain: '<S237>/Gain'
     *  Gain: '<S237>/Gain1'
     *  Product: '<S237>/Product'
     */
    rtb_Add_p = ((6.0F * rtb_L0_C3_dc) * rtb_Abs_a) + rtb_Add_p_tmp;

    /* Gain: '<S238>/Gain' incorporates:
     *  Gain: '<S249>/Gain'
     *  Gain: '<S250>/Gain'
     *  Gain: '<S251>/Gain'
     */
    rtb_Add_o_tmp = 2.0F * rtb_L0_C2;

    /* Sum: '<S238>/Add' incorporates:
     *  Gain: '<S238>/Gain'
     *  Gain: '<S238>/Gain1'
     *  Product: '<S238>/Product'
     */
    rtb_Add_o = ((6.0F * rtb_L0_C3) * rtb_Abs_a) + rtb_Add_o_tmp;

    /* Product: '<S227>/Divide1' incorporates:
     *  Gain: '<S227>/Gain1'
     */
    rtb_Abs_a = rtb_phiHdAg_Lft * rtb_Abs_f_tmp;

    /* Saturate: '<S233>/Saturation2' incorporates:
     *  UnaryMinus: '<S233>/Unary Minus1'
     */
    if ((-rtb_Abs_a) > 2.0F) {
      rtb_LKA_Veh2CamL_C = 2.0F;
    } else if ((-rtb_Abs_a) < (-2.0F)) {
      rtb_LKA_Veh2CamL_C = (-2.0F);
    } else {
      rtb_LKA_Veh2CamL_C = -rtb_Abs_a;
    }

    /* End of Saturate: '<S233>/Saturation2' */

    /* MATLAB Function: '<S233>/MATLABFunction' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction': '<S264>:1' */
    /* '<S264>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Gain1_j > 0.0F) && (rtb_Gain1_j < 2.0F)) && (rtb_LKA_Veh2CamL_C <
          0.0F)) && (rtb_LKA_Veh2CamL_C > -1.5F)) {
      /* '<S264>:1:3' TTLC = -dvt/vy; */
      rtb_TTLC_d = (-rtb_Gain1_j) / rtb_LKA_Veh2CamL_C;
    } else {
      /* '<S264>:1:4' else */
      /* '<S264>:1:5' TTLC = single(3); */
      rtb_TTLC_d = 3.0F;
    }

    /* End of MATLAB Function: '<S233>/MATLABFunction' */

    /* Saturate: '<S233>/Saturation' */
    if (rtb_TTLC_d > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else if (rtb_TTLC_d < 0.6F) {
      rtb_LftTTLC = 0.6F;
    } else {
      rtb_LftTTLC = rtb_TTLC_d;
    }

    /* End of Saturate: '<S233>/Saturation' */

    /* Product: '<S227>/Divide2' incorporates:
     *  Gain: '<S227>/Gain1'
     */
    rtb_Abs_pw = rtb_phiHdAg_Rgt * rtb_Abs_f_tmp;

    /* Saturate: '<S233>/Saturation3' */
    if (rtb_Abs_pw > 2.0F) {
      rtb_TTLC_d = 2.0F;
    } else if (rtb_Abs_pw < (-2.0F)) {
      rtb_TTLC_d = (-2.0F);
    } else {
      rtb_TTLC_d = rtb_Abs_pw;
    }

    /* End of Saturate: '<S233>/Saturation3' */

    /* MATLAB Function: '<S233>/MATLABFunction1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction1': '<S265>:1' */
    /* '<S265>:1:2' if dvt>single(0) && dvt<single(2) && vy<single(0) && vy>single(-1.5) */
    if ((((rtb_Add5_n > 0.0F) && (rtb_Add5_n < 2.0F)) && (rtb_TTLC_d < 0.0F)) &&
        (rtb_TTLC_d > -1.5F)) {
      /* '<S265>:1:3' TTLC = (-dvt)/vy; */
      rtb_TTLC_n = (-rtb_Add5_n) / rtb_TTLC_d;
    } else {
      /* '<S265>:1:4' else */
      /* '<S265>:1:5' TTLC = single(3); */
      rtb_TTLC_n = 3.0F;
    }

    /* End of MATLAB Function: '<S233>/MATLABFunction1' */

    /* Saturate: '<S233>/Saturation1' */
    if (rtb_TTLC_n > 2.0F) {
      rtb_TTLC_n = 2.0F;
    } else {
      if (rtb_TTLC_n < 0.6F) {
        rtb_TTLC_n = 0.6F;
      }
    }

    /* End of Saturate: '<S233>/Saturation1' */

    /* MATLAB Function: '<S233>/MATLABFunction5' incorporates:
     *  Gain: '<S263>/Gain1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction5': '<S269>:1' */
    /* '<S269>:1:2' K = 0.09/vx; */
    /* '<S269>:1:3' TTLC = sw_angle/((1+K*vx*vx)*WhlBaseL_C*StrRatio_C*2); */
    rtb_TTLC = (0.0174532924F * rtb_R0_C2) / (((((((0.09F / rtb_Abs_f_tmp) *
      rtb_Abs_f_tmp) * rtb_Abs_f_tmp) + 1.0F) * LKAS_DW.LKA_WhlBaseL_C_m) *
      LKAS_DW.LKA_StrRatio_C_d) * 2.0F);

    /* MATLAB Function: '<S233>/MATLABFunction3' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=-W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0+w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0+w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction3': '<S267>:1' */
    /* '<S267>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_LL_CompHdAg_C - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_m > 0.0F) || (rtb_L0_C1_m < 0.0F))) {
      /* '<S267>:1:7' if (-c0-w)/c1>0 */
      x10 = ((-rtb_L0_C0_o) - rtb_LKA_Veh2CamW_C) / rtb_L0_C1_m;
      if (x10 > 0.0F) {
        /* '<S267>:1:8' TLft = (-c0-w)/c1/vx; */
        rtb_TLft = x10 / rtb_Abs_f_tmp;
      } else {
        /* '<S267>:1:9' else */
        /* '<S267>:1:10' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_m * rtb_L0_C1_m) - ((x10 * 4.0F) * x20);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S267>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0+w) >= 0) */
        /* '<S267>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_m)) / x1;

        /* '<S267>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0+w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_m) - x20) / x1;

        /* '<S267>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S267>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S267>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S267>:1:18' TLft = x2/vx; */
          rtb_TLft = x10 / rtb_Abs_f_tmp;
        } else if (x1 > 0.0F) {
          /* '<S267>:1:19' elseif x1>0 */
          /* '<S267>:1:20' TLft = x1/vx; */
          rtb_TLft = x1 / rtb_Abs_f_tmp;
        } else {
          /* '<S267>:1:21' else */
          /* '<S267>:1:22' TLft = single(3); */
          rtb_TLft = 3.0F;
        }
      } else {
        /* '<S267>:1:24' else */
        /* '<S267>:1:25' TLft = single(3); */
        rtb_TLft = 3.0F;
      }
    }

    /* '<S267>:1:27' TLft =max(single(0.6),min(TLft,single(2))); */
    rtb_TLft = fmaxf(0.6F, fminf(rtb_TLft, 2.0F));

    /* MATLAB Function: '<S233>/MATLABFunction4' */
    /*    y1=c0+c1*x+c2*x^2+c3*x^3 */
    /*    y2=W + C20*x^2 */
    /*    y1-y2 =(c2-c20)*x^2+c1*x+(c0-w)=0 */
    /*    b2-4ac=c1^2-4*(c2-c20)*(c0-w) */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction4': '<S268>:1' */
    /* '<S268>:1:6' if (c2-c20)<=single(0.001) && ((c1 > 0) || (c1 < 0)) */
    x10 = rtb_L0_C2 - rtb_TTLC;
    if ((x10 <= 0.001F) && ((rtb_L0_C1_i > 0.0F) || (rtb_L0_C1_i < 0.0F))) {
      /* '<S268>:1:7' if (-c0+w)/c1>0 */
      x10 = ((-rtb_R0_C0_n) + rtb_LKA_Veh2CamW_C) / rtb_L0_C1_i;
      if (x10 > 0.0F) {
        /* '<S268>:1:8' TRgt = (-c0+w)/c1/vx; */
        rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_f_tmp;
      } else {
        /* '<S268>:1:9' else */
        /* '<S268>:1:10' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    } else {
      x20 = (rtb_L0_C1_i * rtb_L0_C1_i) - ((x10 * 4.0F) * rtb_Add5_n_tmp);
      if ((x10 > 0.001F) && (x20 >= 0.0F)) {
        /* '<S268>:1:12' elseif ((c2-c20)>single(0.001)) && (c1^2-4*(c2-c20)*(c0-w) >= 0) */
        /* '<S268>:1:13' x10= (-c1+sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = sqrtf(x20);
        x1 = x10 * 2.0F;
        x10 = (x20 + (-rtb_L0_C1_i)) / x1;

        /* '<S268>:1:14' x20= (-c1-sqrt(c1^2-4*(c2-c20)*(c0-w)))/(2*(c2-c20)); */
        x20 = ((-rtb_L0_C1_i) - x20) / x1;

        /* '<S268>:1:15' x1 = max(x10,x20); */
        x1 = fmaxf(x10, x20);

        /* '<S268>:1:16' x2 = min(x10,x20); */
        x10 = fminf(x10, x20);

        /* '<S268>:1:17' if x2>0 */
        if (x10 > 0.0F) {
          /* '<S268>:1:18' TRgt = x2/vx; */
          rtb_LKA_Veh2CamW_C = x10 / rtb_Abs_f_tmp;
        } else if (x1 > 0.0F) {
          /* '<S268>:1:19' elseif x1>0 */
          /* '<S268>:1:20' TRgt = x1/vx; */
          rtb_LKA_Veh2CamW_C = x1 / rtb_Abs_f_tmp;
        } else {
          /* '<S268>:1:21' else */
          /* '<S268>:1:22' TRgt = single(3); */
          rtb_LKA_Veh2CamW_C = 3.0F;
        }
      } else {
        /* '<S268>:1:24' else */
        /* '<S268>:1:25' TRgt = single(3); */
        rtb_LKA_Veh2CamW_C = 3.0F;
      }
    }

    /* '<S268>:1:27' TRgt =max(single(0.6),min(TRgt,single(2))); */
    rtb_LKA_Veh2CamW_C = fmaxf(0.6F, fminf(rtb_LKA_Veh2CamW_C, 2.0F));

    /* MATLAB Function: '<S233>/MATLABFunction2' incorporates:
     *  Constant: '<S233>/Constant'
     *  Constant: '<S233>/Constant1'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/TTLC Calculation (TTLCCalc)/MATLABFunction2': '<S266>:1' */
    /* '<S266>:1:2' if abs(LTTLC-LTLC)/LTTLC <= single(0.2) */
    if ((fabsf(rtb_LftTTLC - 2.0F) / rtb_LftTTLC) <= 0.2F) {
      /* '<S266>:1:3' LFTTTLC = min(LTTLC,LTLC); */
      rtb_LftTTLC = fminf(rtb_LftTTLC, 2.0F);
    } else {
      /* '<S266>:1:4' else */
      /* '<S266>:1:5' LFTTTLC = LTTLC; */
    }

    /* '<S266>:1:8' if abs(RTTLC-RTLC)/RTTLC <= single(0.2) */
    if ((fabsf(rtb_TTLC_n - 2.0F) / rtb_TTLC_n) <= 0.2F) {
      /* '<S266>:1:9' RGTTTLC = min(RTTLC,RTLC); */
      rtb_TTLC_n = fminf(rtb_TTLC_n, 2.0F);
    } else {
      /* '<S266>:1:10' else */
      /* '<S266>:1:11' RGTTTLC = RTTLC; */
    }

    /* '<S266>:1:14' if abs(crPrvwCrvtLft)>single(0.001) && abs(TLft-LFTTTLC)/LFTTTLC <= single(0.7) && TLft>single(0.5) && LFTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_p) > 0.001F) && ((fabsf(rtb_TLft - rtb_LftTTLC) /
           rtb_LftTTLC) <= 0.7F)) && (rtb_LftTTLC <= 1.95F)) {
      /* '<S266>:1:15' LFTTTLC = (LFTTTLC+TLft)/single(2); */
      rtb_LftTTLC = (rtb_LftTTLC + rtb_TLft) / 2.0F;
    }

    /* '<S266>:1:17' if abs(crPrvwCrvtRgt)>single(0.001) && abs(TRgt-RGTTTLC)/RGTTTLC <= single(0.7) && TRgt>single(0.5) && RGTTTLC <= single(1.95) */
    if (((fabsf(rtb_Add_o) > 0.001F) && ((fabsf(rtb_LKA_Veh2CamW_C - rtb_TTLC_n)
           / rtb_TTLC_n) <= 0.7F)) && (rtb_TTLC_n <= 1.95F)) {
      /* '<S266>:1:18' RGTTTLC = (RGTTTLC+TRgt)/single(2); */
      rtb_TTLC_n = (rtb_TTLC_n + rtb_LKA_Veh2CamW_C) / 2.0F;
    }

    /* Saturate: '<S233>/Saturation7' incorporates:
     *  MATLAB Function: '<S233>/MATLABFunction2'
     */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LFTTTLC = 2.0F;
    } else if (rtb_LftTTLC < 0.8F) {
      rtb_LFTTTLC = 0.8F;
    } else {
      rtb_LFTTTLC = rtb_LftTTLC;
    }

    /* End of Saturate: '<S233>/Saturation7' */

    /* Saturate: '<S233>/Saturation8' incorporates:
     *  MATLAB Function: '<S233>/MATLABFunction2'
     */
    if (rtb_TTLC_n > 2.0F) {
      rtb_RGTTTLC = 2.0F;
    } else if (rtb_TTLC_n < 0.8F) {
      rtb_RGTTTLC = 0.8F;
    } else {
      rtb_RGTTTLC = rtb_TTLC_n;
    }

    /* End of Saturate: '<S233>/Saturation8' */

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Outputs for Enabled SubSystem: '<S89>/Subsystem' incorporates:
     *  EnablePort: '<S97>/Enable'
     */
    /* Abs: '<S228>/Abs' incorporates:
     *  MATLAB Function: '<S97>/DriverSwaTrqAdd'
     */
    rtb_LKA_Veh2CamW_C = fabsf(rtb_L0_C0_o);

    /* Abs: '<S228>/Abs1' incorporates:
     *  MATLAB Function: '<S97>/DriverSwaTrqAdd'
     */
    rtb_Add5_n_tmp = fabsf(rtb_R0_C0_n);

    /* End of Outputs for SubSystem: '<S89>/Subsystem' */
    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* Sum: '<S228>/Add' incorporates:
     *  Abs: '<S228>/Abs'
     *  Abs: '<S228>/Abs1'
     */
    rtb_LftTTLC = rtb_LKA_Veh2CamW_C + rtb_Add5_n_tmp;

    /* Saturate: '<S228>/Saturation' */
    if (rtb_LftTTLC > 6.0F) {
      rtb_LaneWidth = 6.0F;
    } else if (rtb_LftTTLC < 2.0F) {
      rtb_LaneWidth = 2.0F;
    } else {
      rtb_LaneWidth = rtb_LftTTLC;
    }

    /* End of Saturate: '<S228>/Saturation' */

    /* If: '<S239>/If' incorporates:
     *  Delay: '<S81>/Delay'
     */
    if (((sint32)LKAS_DW.Delay_DSTATE_o) == 1) {
      /* Outputs for IfAction SubSystem: '<S239>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S242>/Action Port'
       */
      LKAS_IfActionSubsystem2_k(rtb_Add_p, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S239>/If Action Subsystem2' */
    } else if (((sint32)LKAS_DW.Delay_DSTATE_o) == 2) {
      /* Outputs for IfAction SubSystem: '<S239>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S241>/Action Port'
       */
      LKAS_IfActionSubsystem2_k(rtb_Add_o, &rtb_Merge);

      /* End of Outputs for SubSystem: '<S239>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S239>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S243>/Action Port'
       */
      /* Gain: '<S243>/Gain' incorporates:
       *  Sum: '<S243>/Add'
       */
      rtb_Merge = (rtb_Add_p + rtb_Add_o) * 0.5F;

      /* End of Outputs for SubSystem: '<S239>/If Action Subsystem3' */
    }

    /* End of If: '<S239>/If' */

    /* Switch: '<S522>/Switch' incorporates:
     *  Constant: '<S561>/Constant'
     *  Constant: '<S562>/Constant'
     *  Gain: '<S561>/Gain'
     *  Gain: '<S562>/Gain'
     *  Sum: '<S561>/Add'
     *  Sum: '<S562>/Add'
     *  Switch: '<S558>/Switch47'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S558>/Switch48' incorporates:
       *  Constant: '<S558>/LLSMConClb3'
       *
       * Block description for '<S558>/LLSMConClb3':
       *  LKA���ܵĳ���ʹ������
       */
      if (LKAS_ConstB.DataTypeConversion84 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion84;
      } else {
        x10 = LL_MAX_LKAS_SPEED_ENABLE;
      }

      /* End of Switch: '<S558>/Switch48' */
      rtb_Switch_d = (x10 - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion74 != 0.0F) {
        /* Switch: '<S558>/Switch47' */
        x10 = LKAS_ConstB.DataTypeConversion74;
      } else {
        /* Switch: '<S558>/Switch47' incorporates:
         *  Constant: '<S558>/LLSMConClb2'
         *
         * Block description for '<S558>/LLSMConClb2':
         *  LDW���ܵĳ���ʹ������
         */
        x10 = LL_MAX_LDWS_SPEED_ENABLE;
      }

      rtb_Switch_d = (x10 - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S522>/Switch' */

    /* Switch: '<S520>/Switch' incorporates:
     *  Constant: '<S520>/Constant'
     *  Constant: '<S520>/Constant1'
     *  Constant: '<S525>/Constant'
     *  Constant: '<S526>/Constant'
     *  Constant: '<S527>/Constant'
     *  Logic: '<S520>/Logical Operator'
     *  RelationalOperator: '<S525>/Compare'
     *  RelationalOperator: '<S526>/Compare'
     *  RelationalOperator: '<S527>/Compare'
     */
    if (((rtb_IMAPve_d_SAS_Trim_State >= ((uint8)3U)) || (((sint32)
           (rtb_BCM_Left_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) ||
        (((sint32)(rtb_BCM_Right_Light ? 1 : 0)) > ((sint32)(false ? 1 : 0)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S520>/Switch' */

    /* Sum: '<S520>/Add' incorporates:
     *  Memory: '<S520>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_j;

    /* Saturate: '<S520>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_c = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_c = (-1.0F);
    } else {
      rtb_Saturation_c = rtb_LftTTLC;
    }

    /* End of Saturate: '<S520>/Saturation' */

    /* Abs: '<S514>/Abs1' incorporates:
     *  Abs: '<S419>/Abs1'
     */
    x1 = fabsf(rtb_LaneWidth);
    rtb_Abs1 = x1;

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    /* Abs: '<S512>/Abs' incorporates:
     *  Abs: '<S108>/Abs'
     *  Abs: '<S109>/Abs'
     *  Abs: '<S110>/Abs4'
     *  Abs: '<S417>/Abs'
     *  MATLAB Function: '<S384>/MATLAB Function'
     */
    rtb_TTLC_n = fabsf(rtb_Merge);

    /* End of Outputs for SubSystem: '<S10>/LKA' */
    rtb_Abs = rtb_TTLC_n;

    /* Switch: '<S558>/Switch53' */
    if (LKAS_ConstB.DataTypeConversion18 != 0.0F) {
      /* UnaryMinus: '<S473>/Unary Minus' */
      rtb_UnaryMinus = -LKAS_ConstB.DataTypeConversion18;
    } else {
      /* UnaryMinus: '<S473>/Unary Minus' incorporates:
       *  Constant: '<S558>/LLSMConClb11'
       *
       * Block description for '<S558>/LLSMConClb11':
       *  ������ٶ�ʹ������
       */
      rtb_UnaryMinus = -LL_MAX_LONG_DECEL_ENABLE;
    }

    /* End of Switch: '<S558>/Switch53' */

    /* Switch: '<S558>/Switch87' incorporates:
     *  Constant: '<S558>/LLSMConClb8'
     *
     * Block description for '<S558>/LLSMConClb8':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion14 != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion14;
    } else {
      x10 = LL_MAX_STEER_ANGLE_ENABLE;
    }

    /* End of Switch: '<S558>/Switch87' */

    /* Switch: '<S558>/Switch49' incorporates:
     *  Constant: '<S558>/LLSMConClb43'
     *
     * Block description for '<S558>/LLSMConClb43':
     *  ������ת��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion16 != 0.0F) {
      x20 = LKAS_ConstB.DataTypeConversion16;
    } else {
      x20 = LL_MAX_STEER_SPEED_ENABLE;
    }

    /* End of Switch: '<S558>/Switch49' */

    /* Switch: '<S558>/Switch88' incorporates:
     *  Constant: '<S558>/LLSMConClb9'
     *
     * Block description for '<S558>/LLSMConClb9':
     *  ��ʻԱŤ��ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion15 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion15;
    } else {
      rtb_LftTTLC = LL_MAX_DRIVER_TORQUE_ENABLE;
    }

    /* End of Switch: '<S558>/Switch88' */

    /* Switch: '<S558>/Switch50' incorporates:
     *  Constant: '<S558>/LLSMConClb10'
     *
     * Block description for '<S558>/LLSMConClb10':
     *  ������ٶ�ʹ������
     */
    if (LKAS_ConstB.DataTypeConversion17 != 0.0F) {
      tmp = LKAS_ConstB.DataTypeConversion17;
    } else {
      tmp = LL_MAX_LAT_ACC_ENABLE;
    }

    /* End of Switch: '<S558>/Switch50' */

    /* Abs: '<S510>/Abs' incorporates:
     *  Abs: '<S415>/Abs'
     *  Sum: '<S510>/Add'
     */
    rtb_LogicalOperator3_c_tmp = fabsf(rtb_L0_C1_m - rtb_L0_C1_i);

    /* Abs: '<S473>/Abs2' incorporates:
     *  Abs: '<S258>/Abs2'
     *  Abs: '<S382>/Abs2'
     */
    rtb_TTLC = fabsf(rtb_R0_C2);

    /* Abs: '<S473>/Abs3' incorporates:
     *  Abs: '<S382>/Abs3'
     *  DataTypeConversion: '<S1>/IMAPve_g_SW_Angle_Speed_1'
     *  Inport: '<Root>/IMAPve_g_SW_Angle_Speed'
     */
    rtb_LogicalOperator3_c_tmp_0 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_SW_Angle_Speed_IMAPve_g_SW_Angle_Speed
      ());

    /* Abs: '<S473>/Abs4' incorporates:
     *  Abs: '<S382>/Abs4'
     *  DataTypeConversion: '<S1>/IMAPve_g_ESC_LatAcc_1'
     *  Inport: '<Root>/IMAPve_g_ESC_LatAcc'
     */
    rtb_LogicalOperator3_c_tmp_1 = fabsf((float32)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_LatAcc_IMAPve_g_ESC_LatAcc());

    /* Abs: '<S473>/Abs1' incorporates:
     *  Abs: '<S383>/Abs'
     *  Abs: '<S384>/Abs'
     */
    rtb_TLft = fabsf(rtb_IMAPve_g_EPS_SW_Trq);

    /* Logic: '<S474>/Logical Operator2' incorporates:
     *  Abs: '<S473>/Abs1'
     *  Abs: '<S473>/Abs2'
     *  Abs: '<S473>/Abs3'
     *  Abs: '<S473>/Abs4'
     *  Abs: '<S510>/Abs'
     *  Constant: '<S512>/Constant'
     *  Constant: '<S515>/Constant'
     *  Constant: '<S517>/Constant'
     *  Constant: '<S518>/Constant'
     *  Constant: '<S524>/Constant'
     *  Constant: '<S528>/Constant'
     *  Logic: '<S473>/Logical Operator3'
     *  Logic: '<S479>/FixPt Logical Operator'
     *  Logic: '<S511>/Logical Operator3'
     *  Logic: '<S513>/Logical Operator'
     *  Logic: '<S516>/FixPt Logical Operator'
     *  Logic: '<S519>/FixPt Logical Operator'
     *  Logic: '<S523>/Logical Operator'
     *  Logic: '<S529>/FixPt Logical Operator'
     *  RelationalOperator: '<S473>/Relational Operator'
     *  RelationalOperator: '<S473>/Relational Operator1'
     *  RelationalOperator: '<S473>/Relational Operator2'
     *  RelationalOperator: '<S473>/Relational Operator3'
     *  RelationalOperator: '<S479>/Lower Test'
     *  RelationalOperator: '<S479>/Upper Test'
     *  RelationalOperator: '<S515>/Compare'
     *  RelationalOperator: '<S516>/Lower Test'
     *  RelationalOperator: '<S516>/Upper Test'
     *  RelationalOperator: '<S517>/Compare'
     *  RelationalOperator: '<S518>/Compare'
     *  RelationalOperator: '<S519>/Lower Test'
     *  RelationalOperator: '<S519>/Upper Test'
     *  RelationalOperator: '<S524>/Compare'
     *  RelationalOperator: '<S528>/Compare'
     *  RelationalOperator: '<S529>/Lower Test'
     *  RelationalOperator: '<S529>/Upper Test'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_LogicalOperator3_b5 = ((((((rtb_Gain_j <= rtb_IMAPve_g_ESC_VehSpd) &&
      (rtb_IMAPve_g_ESC_VehSpd <= rtb_Switch_d)) && (rtb_Saturation_c <= 0.0F)) &&
      (rtb_TCU_ActualGear == ((uint8)3U))) && (((((rtb_L0_Q > ((uint8)2U)) &&
      (rtb_R0_Q > ((uint8)2U))) && ((rtb_LL_MIN_LANE_WIDTH_ENABLE <= rtb_Abs1) &&
      (rtb_Abs1 <= rtb_LL_MAX_LANE_WIDTH_ENABLE))) && ((0.0F <= rtb_Abs) &&
      (rtb_Abs <= rtb_LL_MAX_SYSTEM_CURVATURE_ENA))) &&
      (rtb_LogicalOperator3_c_tmp <= 0.025F))) && (((((rtb_TTLC < x10) &&
      (rtb_LogicalOperator3_c_tmp_0 < x20)) && (rtb_TLft < rtb_LftTTLC)) &&
      (rtb_LogicalOperator3_c_tmp_1 < tmp)) && ((rtb_UnaryMinus <
      rtb_IMAPve_g_ESC_LonAcc) && (rtb_IMAPve_g_ESC_LonAcc <
      rtb_LL_MAX_LONG_ACC_ENABLE))));

    /* MATLAB Function: '<S507>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_LKA_EarliestWarnLine_C, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient);

    /* Product: '<S507>/Multiply' */
    rtb_Multiply = rtb_LL_ThresDet_lDvtThresUprLKA * rtb_ThresDet_coefficient;

    /* Switch: '<S509>/Switch' incorporates:
     *  Constant: '<S507>/Constant'
     *  RelationalOperator: '<S509>/UpperRelop'
     */
    if (rtb_Multiply < 0.0F) {
      rtb_Switch_i = 0.0F;
    } else {
      rtb_Switch_i = rtb_Multiply;
    }

    /* End of Switch: '<S509>/Switch' */

    /* Switch: '<S509>/Switch2' incorporates:
     *  RelationalOperator: '<S509>/LowerRelop1'
     */
    if (rtb_Multiply > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_f = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_f = rtb_Switch_i;
    }

    /* End of Switch: '<S509>/Switch2' */

    /* Abs: '<S494>/Abs1' incorporates:
     *  Abs: '<S405>/Abs'
     */
    x10 = fabsf(rtb_LKA_Veh2CamL_C);

    /* Abs: '<S494>/Abs2' incorporates:
     *  Abs: '<S405>/Abs1'
     */
    x20 = fabsf(rtb_TTLC_d);

    /* If: '<S474>/If1' incorporates:
     *  Abs: '<S494>/Abs1'
     *  Abs: '<S494>/Abs2'
     *  Constant: '<S481>/Constant'
     *  Constant: '<S496>/Constant'
     *  Constant: '<S497>/Constant'
     *  Constant: '<S502>/Constant'
     *  Constant: '<S503>/Constant'
     *  Constant: '<S504>/Constant'
     *  Constant: '<S505>/Constant'
     *  DataTypeConversion: '<S474>/Cast To Single'
     *  Logic: '<S474>/Logical Operator1'
     *  Logic: '<S491>/Logical Operator'
     *  Logic: '<S493>/Logical Operator'
     *  Logic: '<S494>/Logical Operator'
     *  Logic: '<S495>/Logical Operator'
     *  RelationalOperator: '<S494>/Relational Operator2'
     *  RelationalOperator: '<S494>/Relational Operator3'
     *  RelationalOperator: '<S495>/Relational Operator1'
     *  RelationalOperator: '<S495>/Relational Operator2'
     *  RelationalOperator: '<S496>/Compare'
     *  RelationalOperator: '<S497>/Compare'
     *  RelationalOperator: '<S502>/Compare'
     *  RelationalOperator: '<S503>/Compare'
     *  RelationalOperator: '<S504>/Compare'
     *  RelationalOperator: '<S505>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_LogicalOperator3_b5 &&
         ((((LKAS_DW.LKA_Mode == ((uint8)2U)) && (((sint32)
              (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)2U)) ||
                (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U))) ? 1 : 0)) ==
             ((sint32)(true ? 1 : 0)))) && (((sint32)(((x10 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) && (x20 <=
                rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)) ? 1 : 0)) == ((sint32)(true ?
              1 : 0)))) && (((sint32)(((rtb_Gain1_j >= rtb_Switch2_f) &&
              (rtb_Add5_n >= rtb_Switch2_f)) ? 1 : 0)) == ((sint32)(true ? 1 : 0))))))
    {
      /* Outputs for IfAction SubSystem: '<S474>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S481>/Action Port'
       */
      LKAS_DW.Merge1_a = true;

      /* End of Outputs for SubSystem: '<S474>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S474>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S483>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_a);

      /* End of Outputs for SubSystem: '<S474>/If Action Subsystem4' */
    }

    /* End of If: '<S474>/If1' */

    /* Switch: '<S465>/Switch' incorporates:
     *  Constant: '<S559>/Constant'
     *  Constant: '<S564>/Constant'
     *  Gain: '<S559>/Gain'
     *  Gain: '<S564>/Gain'
     *  Sum: '<S559>/Add'
     *  Sum: '<S564>/Add'
     *  Switch: '<S558>/Switch67'
     */
    if (LKAS_DW.LKA_Mode >= ((uint8)2U)) {
      /* Switch: '<S558>/Switch80' incorporates:
       *  Constant: '<S558>/LLSMConClb21'
       *
       * Block description for '<S558>/LLSMConClb21':
       *  LKA���ܵĳ���ʧЧ����
       */
      if (LKAS_ConstB.DataTypeConversion58 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion58;
      } else {
        rtb_LftTTLC = LL_MAX_LKAS_SPEED_DISABLE;
      }

      /* End of Switch: '<S558>/Switch80' */
      rtb_Switch_h = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    } else {
      if (LKAS_ConstB.DataTypeConversion69 != 0.0F) {
        /* Switch: '<S558>/Switch67' */
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion69;
      } else {
        /* Switch: '<S558>/Switch67' incorporates:
         *  Constant: '<S558>/LLSMConClb20'
         *
         * Block description for '<S558>/LLSMConClb20':
         *  LDW���ܵĳ���ʧЧ����
         */
        rtb_LftTTLC = LL_MAX_LDWS_SPEED_DISABLE;
      }

      rtb_Switch_h = (rtb_LftTTLC - 2.5F) * 0.980392158F;
    }

    /* End of Switch: '<S465>/Switch' */

    /* Logic: '<S465>/Logical Operator' incorporates:
     *  Logic: '<S472>/FixPt Logical Operator'
     *  RelationalOperator: '<S472>/Lower Test'
     *  RelationalOperator: '<S472>/Upper Test'
     */
    rtb_LKA_Main_Switch = ((rtb_Gain_g >= rtb_IMAPve_g_ESC_VehSpd) ||
      (rtb_IMAPve_g_ESC_VehSpd >= rtb_Switch_h));

    /* Logic: '<S463>/Logical Operator' incorporates:
     *  Logic: '<S285>/Logical Operator6'
     */
    rtb_LogicalOperator3_p_tmp = !rtb_LL_SingleLane_Disable_Swt;

    /* Switch: '<S463>/Switch' incorporates:
     *  Constant: '<S463>/Constant'
     *  Constant: '<S463>/Constant1'
     *  Constant: '<S468>/Constant'
     *  Constant: '<S469>/Constant'
     *  Constant: '<S470>/Constant'
     *  Delay: '<S82>/Delay1'
     *  Logic: '<S463>/Logical Operator'
     *  Logic: '<S463>/Logical Operator1'
     *  Logic: '<S463>/Logical Operator2'
     *  Logic: '<S463>/Logical Operator3'
     *  Logic: '<S463>/Logical Operator4'
     *  Logic: '<S463>/Logical Operator5'
     *  RelationalOperator: '<S468>/Compare'
     *  RelationalOperator: '<S469>/Compare'
     *  RelationalOperator: '<S470>/Compare'
     */
    if (((((rtb_IMAPve_d_SAS_Trim_State >= ((uint8)3U)) || (rtb_BCM_Left_Light &&
            rtb_LogicalOperator3_p_tmp)) || (rtb_BCM_Right_Light &&
           rtb_LogicalOperator3_p_tmp)) || (rtb_BCM_Left_Light &&
          (LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)))) || (rtb_BCM_Right_Light &&
         (LKAS_DW.Delay1_3_DSTATE == ((uint8)5U)))) {
      rtb_LftTTLC = 3.0F;
    } else {
      rtb_LftTTLC = (-1.0F);
    }

    /* End of Switch: '<S463>/Switch' */

    /* Sum: '<S463>/Add' incorporates:
     *  Memory: '<S463>/Memory'
     */
    rtb_LftTTLC += LKAS_DW.Memory_PreviousInput_c;

    /* Saturate: '<S463>/Saturation' */
    if (rtb_LftTTLC > 200.0F) {
      rtb_Saturation_f = 200.0F;
    } else if (rtb_LftTTLC < (-1.0F)) {
      rtb_Saturation_f = (-1.0F);
    } else {
      rtb_Saturation_f = rtb_LftTTLC;
    }

    /* End of Saturate: '<S463>/Saturation' */

    /* RelationalOperator: '<S467>/Compare' incorporates:
     *  Constant: '<S467>/Constant'
     */
    rtb_LL_SingleLane_Disable_Swt = (rtb_Saturation_f > 1.0F);

    /* RelationalOperator: '<S471>/Compare' incorporates:
     *  Constant: '<S471>/Constant'
     */
    rtb_Compare_mln = (rtb_TCU_ActualGear != ((uint8)3U));

    /* Logic: '<S418>/Logical Operator' incorporates:
     *  Constant: '<S422>/Constant'
     *  Constant: '<S423>/Constant'
     *  RelationalOperator: '<S422>/Compare'
     *  RelationalOperator: '<S423>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_LogicalOperator_iv = ((rtb_L0_Q < ((uint8)3U)) && (rtb_R0_Q < ((uint8)3U)));

    /* Abs: '<S419>/Abs1' */
    rtb_Abs1_m = x1;

    /* RelationalOperator: '<S424>/Compare' incorporates:
     *  Constant: '<S424>/Constant'
     *  Logic: '<S425>/FixPt Logical Operator'
     *  RelationalOperator: '<S425>/Lower Test'
     *  RelationalOperator: '<S425>/Upper Test'
     */
    rtb_Compare_pxf = (((sint32)(((rtb_LL_MIN_LANE_WIDTH_DISABLE <= rtb_Abs1_m) &&
      (rtb_Abs1_m <= rtb_LL_MAX_LANE_WIDTH_DISABLE)) ? 1 : 0)) == ((sint32)
      (false ? 1 : 0)));

    /* Abs: '<S417>/Abs' */
    rtb_Abs_i = rtb_TTLC_n;

    /* Logic: '<S417>/Logical Operator' incorporates:
     *  Constant: '<S417>/Constant'
     *  Logic: '<S421>/FixPt Logical Operator'
     *  RelationalOperator: '<S421>/Lower Test'
     *  RelationalOperator: '<S421>/Upper Test'
     */
    rtb_LogicalOperator_ix = ((0.0F > rtb_Abs_i) || (rtb_Abs_i >
      rtb_LL_MAX_SYSTEM_CURVATURE_DIS));

    /* RelationalOperator: '<S420>/Compare' incorporates:
     *  Constant: '<S420>/Constant'
     */
    rtb_Compare_ab = (rtb_LogicalOperator3_c_tmp > 0.04F);

    /* Switch: '<S558>/Switch72' incorporates:
     *  Constant: '<S558>/LLSMConClb26'
     *
     * Block description for '<S558>/LLSMConClb26':
     *  ������ת���˳�����
     */
    if (LKAS_ConstB.DataTypeConversion68 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion68;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_ANGLE_DISABLE;
    }

    /* End of Switch: '<S558>/Switch72' */

    /* RelationalOperator: '<S382>/Relational Operator1' */
    rtb_phiSWA_Thres = (rtb_TTLC >= rtb_LftTTLC);

    /* Switch: '<S558>/Switch74' incorporates:
     *  Constant: '<S558>/LLSMConClb28'
     *
     * Block description for '<S558>/LLSMConClb28':
     *  ������ת��ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion72 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion72;
    } else {
      rtb_LftTTLC = LL_MAX_STEER_SPEED_DISABLE;
    }

    /* End of Switch: '<S558>/Switch74' */

    /* RelationalOperator: '<S382>/Relational Operator2' */
    rtb_dphiSWARate_Thres = (rtb_LogicalOperator3_c_tmp_0 >= rtb_LftTTLC);

    /* Switch: '<S558>/Switch79' incorporates:
     *  Constant: '<S558>/LLSMConClb29'
     *
     * Block description for '<S558>/LLSMConClb29':
     *  ������ٶ�ʧЧ����
     */
    if (LKAS_ConstB.DataTypeConversion75 != 0.0F) {
      rtb_LftTTLC = LKAS_ConstB.DataTypeConversion75;
    } else {
      rtb_LftTTLC = LL_MAX_LAT_ACC_DISABLE;
    }

    /* End of Switch: '<S558>/Switch79' */

    /* Logic: '<S382>/Logical Operator1' incorporates:
     *  Constant: '<S385>/Constant'
     *  RelationalOperator: '<S382>/Relational Operator3'
     *  RelationalOperator: '<S385>/Compare'
     */
    rtb_aLAcc_Thres = ((rtb_LogicalOperator3_c_tmp_1 >= rtb_LftTTLC) &&
                       (rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)));

    /* Switch: '<S558>/Switch61' */
    if (LKAS_ConstB.DataTypeConversion76 != 0.0F) {
      /* UnaryMinus: '<S382>/Unary Minus' */
      rtb_UnaryMinus_n = -LKAS_ConstB.DataTypeConversion76;
    } else {
      /* UnaryMinus: '<S382>/Unary Minus' incorporates:
       *  Constant: '<S558>/LLSMConClb30'
       *
       * Block description for '<S558>/LLSMConClb30':
       *  ������ٶ�ʧЧ����
       */
      rtb_UnaryMinus_n = -LL_MAX_LONG_DECEL_DISABLE;
    }

    /* End of Switch: '<S558>/Switch61' */

    /* RelationalOperator: '<S386>/Compare' incorporates:
     *  Constant: '<S386>/Constant'
     *  Logic: '<S387>/FixPt Logical Operator'
     *  RelationalOperator: '<S387>/Lower Test'
     *  RelationalOperator: '<S387>/Upper Test'
     */
    rtb_Compare_cwd = (((sint32)(((rtb_UnaryMinus_n < rtb_IMAPve_g_ESC_LonAcc) &&
      (rtb_IMAPve_g_ESC_LonAcc < rtb_LL_MAX_LONG_ACC_DISABLE)) ? 1 : 0)) ==
                       ((sint32)(false ? 1 : 0)));

    /* Switch: '<S383>/Switch' incorporates:
     *  Constant: '<S388>/Constant'
     *  Constant: '<S558>/LL_RlsDet_tiTrqChkT_DISABLE=0.25'
     *  RelationalOperator: '<S388>/Compare'
     *  Switch: '<S558>/Switch38'
     *
     * Block description for '<S558>/LL_RlsDet_tiTrqChkT_DISABLE=0.25':
     *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ
     */
    if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
      /* Switch: '<S558>/Switch44' incorporates:
       *  Constant: '<S558>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5'
       *
       * Block description for '<S558>/LL_RlsDet_tiTrqChkT_EPS_DISABLE=0.5':
       *  ��ʹ�ܼ�ʻԱ����ʱ����ֵ��EPS���
       */
      if (LKAS_ConstB.DataTypeConversion8 != 0.0F) {
        rtb_TTLC_d = LKAS_ConstB.DataTypeConversion8;
      } else {
        rtb_TTLC_d = LL_RlsDet_tiTrqChkT_EPS_DISABLE;
      }

      /* End of Switch: '<S558>/Switch44' */
    } else if (LKAS_ConstB.DataTypeConversion6 != 0.0F) {
      /* Switch: '<S558>/Switch38' */
      rtb_TTLC_d = LKAS_ConstB.DataTypeConversion6;
    } else {
      rtb_TTLC_d = LL_RlsDet_tiTrqChkT_DISABLE;
    }

    /* End of Switch: '<S383>/Switch' */

    /* Outputs for Enabled SubSystem: '<S383>/ExitCount' incorporates:
     *  EnablePort: '<S391>/Enable'
     */
    /* RelationalOperator: '<S383>/Relational Operator' */
    if (rtb_TLft <= rtb_TTLC_d) {
      if (!LKAS_DW.ExitCount_MODE) {
        /* InitializeConditions for Memory: '<S391>/Memory' */
        LKAS_DW.Memory_PreviousInput_no = 0.0F;
        LKAS_DW.ExitCount_MODE = true;
      }

      /* Sum: '<S391>/Add' incorporates:
       *  Constant: '<S389>/Constant'
       *  Constant: '<S390>/Constant'
       *  Logic: '<S383>/Logical Operator2'
       *  Memory: '<S391>/Memory'
       *  Product: '<S383>/Divide'
       *  RelationalOperator: '<S389>/Compare'
       *  RelationalOperator: '<S390>/Compare'
       */
      rtb_LKA_Veh2CamL_C = (((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
        (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? rtb_LKA_SampleTime : 0.0F)
        + LKAS_DW.Memory_PreviousInput_no;

      /* Saturate: '<S391>/Saturation' */
      if (rtb_LKA_Veh2CamL_C > 60.0F) {
        rtb_LKA_Veh2CamL_C = 60.0F;
      } else {
        if (rtb_LKA_Veh2CamL_C < 0.0F) {
          rtb_LKA_Veh2CamL_C = 0.0F;
        }
      }

      /* End of Saturate: '<S391>/Saturation' */

      /* Switch: '<S558>/Switch3' incorporates:
       *  Constant: '<S558>/LL_RlsDet_tiTDelTime_DISABLE=3'
       *
       * Block description for '<S558>/LL_RlsDet_tiTDelTime_DISABLE=3':
       *  ��ʻԱ���ֿ�ʼ�������˳���ʱ��
       */
      if (LKAS_ConstB.DataTypeConversion3 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion3;
      } else {
        rtb_LftTTLC = LL_HandsOff_ExitTime;
      }

      /* End of Switch: '<S558>/Switch3' */

      /* RelationalOperator: '<S391>/Relational Operator' */
      LKAS_DW.RelationalOperator_f = (rtb_LKA_Veh2CamL_C >= rtb_LftTTLC);

      /* Update for Memory: '<S391>/Memory' */
      LKAS_DW.Memory_PreviousInput_no = rtb_LKA_Veh2CamL_C;
    } else {
      if (LKAS_DW.ExitCount_MODE) {
        /* Disable for Outport: '<S391>/Out' */
        LKAS_DW.RelationalOperator_f = false;
        LKAS_DW.ExitCount_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S383>/Relational Operator' */
    /* End of Outputs for SubSystem: '<S383>/ExitCount' */

    /* Saturate: '<S384>/Saturation' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Driver Intent Condition (DrvInttC)/Take-Over Steering Check (TkOvStChk)/MATLAB Function': '<S392>:1' */
    /* '<S392>:1:2' CrvtTrq = single(abs(PrvwCrvt)/single(0.005)); */
    /* '<S392>:1:3' MidTqlmt = single(single(1.5)*DisableTrq-VehSpd/single(180)*DisableTrq + CrvtTrq); */
    /* '<S392>:1:4' Tqlmt = single(min(max(single(1.5),MidTqlmt),single(2.75))); */
    /* '<S392>:1:5' if EPSTrq >= Tqlmt */
    if (rtb_IMAPve_g_ESC_VehSpd > 80.0F) {
      rtb_LftTTLC = 80.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
      rtb_LftTTLC = 60.0F;
    } else {
      rtb_LftTTLC = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S384>/Saturation' */

    /* MATLAB Function: '<S384>/MATLAB Function' */
    if (rtb_TLft >= fminf(fmaxf(1.5F, ((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
           - ((rtb_LftTTLC / 180.0F) * rtb_LL_MAX_DRIVER_TORQUE_DISABL)) +
          (rtb_TTLC_n / 0.005F)), 2.75F)) {
      /* Outputs for Enabled SubSystem: '<S384>/Sum Condition1' incorporates:
       *  EnablePort: '<S393>/state = reset'
       */
      /* '<S392>:1:6' stDvrTkConFlg=true; */
      if (!LKAS_DW.SumCondition1_MODE_i) {
        /* InitializeConditions for Memory: '<S393>/Memory' */
        LKAS_DW.Memory_PreviousInput_k = 0.0F;
        LKAS_DW.SumCondition1_MODE_i = true;
      }

      /* Sum: '<S393>/Add1' incorporates:
       *  Memory: '<S393>/Memory'
       */
      rtb_LKA_Veh2CamL_C = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_k;

      /* Saturate: '<S393>/Saturation' */
      if (rtb_LKA_Veh2CamL_C > 5000.0F) {
        rtb_LKA_Veh2CamL_C = 5000.0F;
      } else {
        if (rtb_LKA_Veh2CamL_C < 0.0F) {
          rtb_LKA_Veh2CamL_C = 0.0F;
        }
      }

      /* End of Saturate: '<S393>/Saturation' */
      /* End of Outputs for SubSystem: '<S384>/Sum Condition1' */

      /* Switch: '<S558>/Switch65' incorporates:
       *  Constant: '<S558>/LLSMConClb34'
       *
       * Block description for '<S558>/LLSMConClb34':
       *  ��ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion82 != 0.0F) {
        rtb_LftTTLC = LKAS_ConstB.DataTypeConversion82;
      } else {
        rtb_LftTTLC = LL_TkOvStChk_tiTrqChkT;
      }

      /* End of Switch: '<S558>/Switch65' */

      /* Outputs for Enabled SubSystem: '<S384>/Sum Condition1' incorporates:
       *  EnablePort: '<S393>/state = reset'
       */
      /* RelationalOperator: '<S393>/Relational Operator' */
      LKAS_DW.RelationalOperator_n2 = (rtb_LKA_Veh2CamL_C >= rtb_LftTTLC);

      /* Update for Memory: '<S393>/Memory' */
      LKAS_DW.Memory_PreviousInput_k = rtb_LKA_Veh2CamL_C;

      /* End of Outputs for SubSystem: '<S384>/Sum Condition1' */
    } else {
      /* Outputs for Enabled SubSystem: '<S384>/Sum Condition1' incorporates:
       *  EnablePort: '<S393>/state = reset'
       */
      /* '<S392>:1:7' else */
      /* '<S392>:1:8' stDvrTkConFlg=false; */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S393>/Out' */
        LKAS_DW.RelationalOperator_n2 = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Outputs for SubSystem: '<S384>/Sum Condition1' */
    }

    /* RelationalOperator: '<S399>/Compare' incorporates:
     *  Constant: '<S399>/Constant'
     */
    rtb_Compare_iz = (((sint32)(LKAS_DW.RelationalOperator_n2 ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S394>/Unit Delay' */
    rtb_UnitDelay_m = LKAS_DW.UnitDelay_DSTATE_i;

    /* If: '<S394>/If' incorporates:
     *  Constant: '<S396>/Constant'
     *  RelationalOperator: '<S395>/FixPt Relational Operator'
     *  UnitDelay: '<S395>/Delay Input1'
     *
     * Block description for '<S395>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if (((sint32)(rtb_Compare_iz ? 1 : 0)) > ((sint32)
         (LKAS_DW.DelayInput1_DSTATE ? 1 : 0))) {
      /* Outputs for IfAction SubSystem: '<S394>/If Action Subsystem' incorporates:
       *  ActionPort: '<S396>/Action Port'
       */
      rtb_Merge_i = true;

      /* End of Outputs for SubSystem: '<S394>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S394>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S397>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_m, &rtb_Merge_i);

      /* End of Outputs for SubSystem: '<S394>/If Action Subsystem3' */
    }

    /* End of If: '<S394>/If' */

    /* Outputs for Enabled SubSystem: '<S394>/Sum Condition1' incorporates:
     *  EnablePort: '<S398>/state = reset'
     */
    if (rtb_Merge_i) {
      if (!LKAS_DW.SumCondition1_MODE) {
        /* InitializeConditions for Memory: '<S398>/Memory' */
        LKAS_DW.Memory_PreviousInput_p = 0.0F;
        LKAS_DW.SumCondition1_MODE = true;
      }

      /* Sum: '<S398>/Add1' incorporates:
       *  Memory: '<S398>/Memory'
       */
      rtb_LKA_Veh2CamL_C = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_p;

      /* Saturate: '<S398>/Saturation' */
      if (rtb_LKA_Veh2CamL_C > 10.0F) {
        rtb_LKA_Veh2CamL_C = 10.0F;
      } else {
        if (rtb_LKA_Veh2CamL_C < 0.0F) {
          rtb_LKA_Veh2CamL_C = 0.0F;
        }
      }

      /* End of Saturate: '<S398>/Saturation' */

      /* RelationalOperator: '<S398>/Relational Operator' */
      LKAS_DW.RelationalOperator_a = (rtb_LKA_Veh2CamL_C <=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S398>/Memory' */
      LKAS_DW.Memory_PreviousInput_p = rtb_LKA_Veh2CamL_C;
    } else {
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S398>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S394>/Sum Condition1' */

    /* Logic: '<S394>/Logical Operator' */
    rtb_RelationalOperator_b = ((LKAS_DW.RelationalOperator_n2) ||
      (LKAS_DW.RelationalOperator_a));

    /* Logic: '<S368>/Logical Operator2' incorporates:
     *  Logic: '<S381>/Logical Operator1'
     *  Logic: '<S382>/Logical Operator'
     *  Logic: '<S416>/Logical Operator3'
     *  Logic: '<S466>/Logical Operator3'
     */
    rtb_LogicalOperator3_pm = ((((rtb_LKA_Main_Switch ||
      rtb_LL_SingleLane_Disable_Swt) || rtb_Compare_mln) ||
      (((rtb_LogicalOperator_iv || rtb_Compare_pxf) || rtb_LogicalOperator_ix) ||
       rtb_Compare_ab)) || (((((rtb_phiSWA_Thres || rtb_dphiSWARate_Thres) ||
      rtb_aLAcc_Thres) || rtb_Compare_cwd) || (LKAS_DW.RelationalOperator_f)) ||
      rtb_RelationalOperator_b));

    /* Logic: '<S405>/Logical Operator' incorporates:
     *  RelationalOperator: '<S405>/Relational Operator1'
     *  RelationalOperator: '<S405>/Relational Operator2'
     */
    rtb_LogicalOperator_ol = ((x10 >= rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) || (x20 >=
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_));

    /* Logic: '<S406>/Logical Operator' incorporates:
     *  RelationalOperator: '<S406>/Relational Operator1'
     *  RelationalOperator: '<S406>/Relational Operator2'
     */
    rtb_LogicalOperator_m = ((rtb_Gain1_j <= rtb_Abs_k) || (rtb_Add5_n <=
      rtb_Abs_k));

    /* If: '<S368>/If2' incorporates:
     *  Constant: '<S377>/Constant'
     *  Constant: '<S411>/Constant'
     *  Constant: '<S412>/Constant'
     *  Constant: '<S414>/Constant'
     *  DataTypeConversion: '<S368>/Cast To Single'
     *  Logic: '<S368>/Logical Operator1'
     *  Logic: '<S404>/Logical Operator'
     *  Logic: '<S404>/Logical Operator1'
     *  RelationalOperator: '<S411>/Compare'
     *  RelationalOperator: '<S412>/Compare'
     *  RelationalOperator: '<S414>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (rtb_LogicalOperator3_pm ||
         ((LKAS_DW.LKA_Mode == ((uint8)2U)) && ((rtb_LogicalOperator_ol == true)
           || (rtb_LogicalOperator_m == true))))) {
      /* Outputs for IfAction SubSystem: '<S368>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S377>/Action Port'
       */
      LKAS_DW.Merge2 = true;

      /* End of Outputs for SubSystem: '<S368>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S368>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S379>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge2);

      /* End of Outputs for SubSystem: '<S368>/If Action Subsystem3' */
    }

    /* End of If: '<S368>/If2' */

    /* If: '<S305>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_pw >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S305>/Ph1SWA' incorporates:
       *  ActionPort: '<S309>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S305>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_pw <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S305>/Ph2SWA' incorporates:
       *  ActionPort: '<S310>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S305>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S305>/Ph3SWA' incorporates:
       *  ActionPort: '<S311>/Action Port'
       */
      LKAS_Ph3SWA_f(&rtb_Merge1);

      /* End of Outputs for SubSystem: '<S305>/Ph3SWA' */
    }

    /* End of If: '<S305>/If' */

    /* Saturate: '<S283>/Saturation5' */
    if (rtb_Gain1_j > 2.0F) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = 2.0F;
    } else if (rtb_Gain1_j < (-2.0F)) {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = (-2.0F);
    } else {
      rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = rtb_Gain1_j;
    }

    /* End of Saturate: '<S283>/Saturation5' */

    /* MATLAB Function: '<S292>/MATLAB Function' incorporates:
     *  MATLAB Function: '<S328>/MATLAB Function'
     */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Activation Condition (ActvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S295>:1' */
    /* '<S295>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S295>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S295>:1:5' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S295>:1:6' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S295>:1:7' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    x20 = (2.0F * rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth;
    x20 = fminf(fmaxf(0.0F, (fminf(fmaxf(x20, rtb_LaneWidth), (6.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW) + rtb_LKA_CarWidth) - x20) / (4.0F *
      rtb_LL_ThresDet_lDvtThresUprLDW)), 1.0F);

    /* Product: '<S292>/Divide5' incorporates:
     *  MATLAB Function: '<S292>/MATLAB Function'
     */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Product: '<S292>/Divide6' incorporates:
     *  MATLAB Function: '<S292>/MATLAB Function'
     */
    rtb_TLft = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Abs: '<S307>/Abs' incorporates:
     *  Abs: '<S298>/Abs'
     *  Abs: '<S334>/Abs'
     */
    x1 = fabsf(rtb_Abs_a);

    /* Product: '<S307>/Divide' incorporates:
     *  Abs: '<S307>/Abs'
     */
    rtb_Divide_b = rtb_TLft * x1;

    /* Product: '<S292>/Divide4' incorporates:
     *  MATLAB Function: '<S292>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S312>/Switch' incorporates:
     *  RelationalOperator: '<S312>/UpperRelop'
     */
    if (rtb_Divide_b < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_c = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_c = rtb_Divide_b;
    }

    /* End of Switch: '<S312>/Switch' */

    /* Switch: '<S312>/Switch2' incorporates:
     *  RelationalOperator: '<S312>/LowerRelop1'
     */
    if (rtb_Divide_b > rtb_LftTTLC) {
      rtb_Switch2_o = rtb_LftTTLC;
    } else {
      rtb_Switch2_o = rtb_Switch_c;
    }

    /* End of Switch: '<S312>/Switch2' */

    /* Saturate: '<S283>/Saturation1' */
    if (rtb_Add5_n > 2.0F) {
      rtb_TTLC_d = 2.0F;
    } else if (rtb_Add5_n < (-2.0F)) {
      rtb_TTLC_d = (-2.0F);
    } else {
      rtb_TTLC_d = rtb_Add5_n;
    }

    /* End of Saturate: '<S283>/Saturation1' */

    /* Abs: '<S308>/Abs' incorporates:
     *  Abs: '<S299>/Abs'
     *  Abs: '<S335>/Abs'
     */
    rtb_LogicalOperator3_c_tmp = fabsf(rtb_Abs_pw);

    /* Product: '<S308>/Divide' incorporates:
     *  Abs: '<S308>/Abs'
     */
    rtb_Divide_ba = rtb_TLft * rtb_LogicalOperator3_c_tmp;

    /* Switch: '<S313>/Switch' incorporates:
     *  RelationalOperator: '<S313>/UpperRelop'
     */
    if (rtb_Divide_ba < rtb_LKA_Veh2CamL_C) {
      rtb_Switch_n = rtb_LKA_Veh2CamL_C;
    } else {
      rtb_Switch_n = rtb_Divide_ba;
    }

    /* End of Switch: '<S313>/Switch' */

    /* Switch: '<S313>/Switch2' incorporates:
     *  RelationalOperator: '<S313>/LowerRelop1'
     */
    if (rtb_Divide_ba > rtb_LftTTLC) {
      rtb_Switch2_n = rtb_LftTTLC;
    } else {
      rtb_Switch2_n = rtb_Switch_n;
    }

    /* End of Switch: '<S313>/Switch2' */

    /* Switch: '<S306>/Switch3' incorporates:
     *  Constant: '<S308>/Constant'
     *  Gain: '<S306>/Gain1'
     *  Logic: '<S308>/Logical Operator'
     *  RelationalOperator: '<S308>/Relational Operator1'
     *  RelationalOperator: '<S308>/Relational Operator2'
     */
    if (rtb_Merge1 >= 0.0F) {
      /* Switch: '<S306>/Switch2' incorporates:
       *  Constant: '<S306>/Constant2'
       *  Constant: '<S307>/Constant'
       *  DataTypeConversion: '<S306>/Cast To Single'
       *  Logic: '<S307>/Logical Operator'
       *  RelationalOperator: '<S307>/Relational Operator1'
       *  RelationalOperator: '<S307>/Relational Operator3'
       */
      if (rtb_Merge1 > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_) &&
          (rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <= rtb_Switch2_o)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S306>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F < rtb_TTLC_d) &&
        (rtb_TTLC_d <= rtb_Switch2_n)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S306>/Switch3' */

    /* DataTypeConversion: '<S285>/Data Type Conversion' incorporates:
     *  Constant: '<S316>/Constant'
     *  Constant: '<S317>/Constant'
     *  Constant: '<S318>/Constant'
     *  Constant: '<S319>/Constant'
     *  Logic: '<S285>/Logical Operator'
     *  Logic: '<S285>/Logical Operator1'
     *  Logic: '<S285>/Logical Operator2'
     *  Logic: '<S285>/Logical Operator3'
     *  Logic: '<S285>/Logical Operator4'
     *  Logic: '<S285>/Logical Operator5'
     *  Logic: '<S285>/Logical Operator7'
     *  RelationalOperator: '<S316>/Compare'
     *  RelationalOperator: '<S317>/Compare'
     *  RelationalOperator: '<S318>/Compare'
     *  RelationalOperator: '<S319>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    rtb_IMAPve_d_SAS_Trim_State = (uint8)(((((rtb_LogicalOperator3_p_tmp ||
      (!rtb_BCM_Right_Light)) && (rtb_R0_Q > ((uint8)2U))) &&
      (rtb_TCU_ActualGear == ((uint8)2U))) || (((rtb_LogicalOperator3_p_tmp || (
      !rtb_BCM_Left_Light)) && (rtb_TCU_ActualGear == ((uint8)1U))) && (rtb_L0_Q
      > ((uint8)2U)))) ? 1 : 0);

    /* DataTypeConversion: '<S284>/Data Type Conversion' incorporates:
     *  Constant: '<S314>/Constant'
     *  Constant: '<S315>/Constant'
     *  Logic: '<S284>/Logical Operator'
     *  RelationalOperator: '<S314>/Compare'
     *  RelationalOperator: '<S315>/Compare'
     */
    rtb_CastToSingle3 = (uint8)(((rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)) ||
      (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U))) ? 1 : 0);

    /* If: '<S282>/If1' incorporates:
     *  Constant: '<S287>/Constant'
     *  Constant: '<S290>/Constant'
     *  Constant: '<S291>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)rtb_TCU_ActualGear) ==
           1)) && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S282>/LKA Left Active Flag (LKALftActvFlg)1' incorporates:
       *  ActionPort: '<S290>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S282>/LKA Left Active Flag (LKALftActvFlg)1' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)
        rtb_TCU_ActualGear) == 2)) && (((sint32)rtb_CastToSingle3) == 1)) &&
               (((sint32)rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S282>/LKA Right Active Flag (LKARgtActvFlg)1' incorporates:
       *  ActionPort: '<S291>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S282>/LKA Right Active Flag (LKARgtActvFlg)1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S282>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S287>/Action Port'
       */
      LKAS_DW.LDW_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S282>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S282>/If1' */

    /* If: '<S342>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) || (rtb_Abs_pw >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S342>/Ph1SWA' incorporates:
       *  ActionPort: '<S346>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_f);

      /* End of Outputs for SubSystem: '<S342>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) || (rtb_Abs_pw <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S342>/Ph2SWA' incorporates:
       *  ActionPort: '<S347>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_f);

      /* End of Outputs for SubSystem: '<S342>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S342>/Ph3SWA' incorporates:
       *  ActionPort: '<S348>/Action Port'
       */
      LKAS_Ph3SWA_f(&rtb_Merge1_f);

      /* End of Outputs for SubSystem: '<S342>/Ph3SWA' */
    }

    /* End of If: '<S342>/If' */

    /* Saturate: '<S321>/Saturation5' */
    if (rtb_Gain1_j > 2.0F) {
      rtb_TLft = 2.0F;
    } else if (rtb_Gain1_j < (-2.0F)) {
      rtb_TLft = (-2.0F);
    } else {
      rtb_TLft = rtb_Gain1_j;
    }

    /* End of Saturate: '<S321>/Saturation5' */

    /* Product: '<S328>/Divide5' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Deviation Threshold Condition (DvtThresCon)/Active Lane Calculation (ActLanCalc)/MATLAB Function': '<S331>:1' */
    /* '<S331>:1:2' LanWidmin = single(LKA_CarWidth+single(2)*DvtThresUprLDW); */
    /* '<S331>:1:3' LanWidmax = single(LKA_CarWidth+single(6)*DvtThresUprLDW); */
    /* '<S331>:1:4' LanWid = single(min(max(LanWidmin,LaneWidth), LanWidmax)); */
    /* '<S331>:1:5' k = single(LanWid-single(LKA_CarWidth+single(single(2)*DvtThresUprLDW)))/single(4*DvtThresUprLDW); */
    /* '<S331>:1:6' ThresDet_coefficient = single(min(max(single(0),k),single(1))); */
    rtb_LL_ThresDet_lDvtThresUprLKA *= x20;

    /* Product: '<S328>/Divide6' */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLKA;

    /* Product: '<S344>/Divide' incorporates:
     *  Abs: '<S344>/Abs'
     */
    rtb_Divide_d = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_a);

    /* Product: '<S328>/Divide4' */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLKA;

    /* Switch: '<S349>/Switch' incorporates:
     *  RelationalOperator: '<S349>/UpperRelop'
     */
    if (rtb_Divide_d < rtb_LftTTLC) {
      rtb_Switch_gw = rtb_LftTTLC;
    } else {
      rtb_Switch_gw = rtb_Divide_d;
    }

    /* End of Switch: '<S349>/Switch' */

    /* Switch: '<S349>/Switch2' incorporates:
     *  RelationalOperator: '<S349>/LowerRelop1'
     */
    if (rtb_Divide_d > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_d = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_d = rtb_Switch_gw;
    }

    /* End of Switch: '<S349>/Switch2' */

    /* Saturate: '<S321>/Saturation1' */
    if (rtb_Add5_n > 2.0F) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = 2.0F;
    } else if (rtb_Add5_n < (-2.0F)) {
      rtb_LL_ThresDet_lDvtThresLwrLKA = (-2.0F);
    } else {
      rtb_LL_ThresDet_lDvtThresLwrLKA = rtb_Add5_n;
    }

    /* End of Saturate: '<S321>/Saturation1' */

    /* Product: '<S345>/Divide' incorporates:
     *  Abs: '<S345>/Abs'
     */
    rtb_Divide_f = rtb_LKA_Veh2CamL_C * fabsf(rtb_Abs_pw);

    /* Switch: '<S350>/Switch' incorporates:
     *  RelationalOperator: '<S350>/UpperRelop'
     */
    if (rtb_Divide_f < rtb_LftTTLC) {
      rtb_Switch_gi = rtb_LftTTLC;
    } else {
      rtb_Switch_gi = rtb_Divide_f;
    }

    /* End of Switch: '<S350>/Switch' */

    /* Switch: '<S350>/Switch2' incorporates:
     *  RelationalOperator: '<S350>/LowerRelop1'
     */
    if (rtb_Divide_f > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_fg = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_fg = rtb_Switch_gi;
    }

    /* End of Switch: '<S350>/Switch2' */

    /* Switch: '<S343>/Switch3' incorporates:
     *  Constant: '<S345>/Constant'
     *  Gain: '<S343>/Gain1'
     *  Logic: '<S345>/Logical Operator'
     *  RelationalOperator: '<S345>/Relational Operator1'
     *  RelationalOperator: '<S345>/Relational Operator2'
     */
    if (rtb_Merge1_f >= 0.0F) {
      /* Switch: '<S343>/Switch2' incorporates:
       *  Constant: '<S343>/Constant2'
       *  Constant: '<S344>/Constant'
       *  DataTypeConversion: '<S343>/Cast To Single'
       *  Logic: '<S344>/Logical Operator'
       *  RelationalOperator: '<S344>/Relational Operator1'
       *  RelationalOperator: '<S344>/Relational Operator3'
       */
      if (rtb_Merge1_f > 0.0F) {
        rtb_TCU_ActualGear = (uint8)(((0.0F < rtb_TLft) && (rtb_TLft <=
          rtb_Switch2_d)) ? 1 : 0);
      } else {
        rtb_TCU_ActualGear = ((uint8)0U);
      }

      /* End of Switch: '<S343>/Switch2' */
    } else {
      rtb_TCU_ActualGear = (uint8)((((uint32)(((0.0F <
        rtb_LL_ThresDet_lDvtThresLwrLKA) && (rtb_LL_ThresDet_lDvtThresLwrLKA <=
        rtb_Switch2_fg)) ? 1 : 0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S343>/Switch3' */

    /* MATLAB Function: '<S322>/MATLAB Function' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Deactivation Condition (DeactvC)/Driver Take Condition (DvrTkCon)/MATLAB Function': '<S354>:1' */
    /* '<S354>:1:2' Spd = single(min(max(single(60),VehSpd),single(80))); */
    /* '<S354>:1:3' Crvt = single(min(max(single(-0.005),PrvwCrvt),single(0.005))); */
    /* '<S354>:1:4' CrvtTrq = (abs(Crvt))/single(0.005); */
    /* '<S354>:1:5' MidTqlmt = single((single(1.5)*DisableTrq-Spd/single(120)*DisableTrq)*single(0.8) + CrvtTrq); */
    rtb_LL_MAX_DRIVER_TORQUE_DISABL = (((1.5F * rtb_LL_MAX_DRIVER_TORQUE_DISABL)
      - ((fminf(fmaxf(60.0F, rtb_IMAPve_g_ESC_VehSpd), 80.0F) / 120.0F) *
         rtb_LL_MAX_DRIVER_TORQUE_DISABL)) * 0.8F) + (fabsf(fminf(fmaxf(-0.005F,
      rtb_Merge), 0.005F)) / 0.005F);

    /* '<S354>:1:6' if stActvFlg == 2 && EPSTrq > MidTqlmt */
    if (((((sint32)rtb_TCU_ActualGear) == 2) && (rtb_IMAPve_g_EPS_SW_Trq >
          rtb_LL_MAX_DRIVER_TORQUE_DISABL)) || ((((sint32)rtb_TCU_ActualGear) ==
          1) && (rtb_IMAPve_g_EPS_SW_Trq < (-rtb_LL_MAX_DRIVER_TORQUE_DISABL))))
    {
      /* Outputs for Enabled SubSystem: '<S322>/Count 0.2s' incorporates:
       *  EnablePort: '<S353>/Enable'
       */
      /* '<S354>:1:7' stDvrTkConFlg=1; */
      /* '<S354>:1:8' elseif stActvFlg == 1 && EPSTrq < single(-1)*MidTqlmt */
      /* '<S354>:1:9' stDvrTkConFlg=1; */
      if (!LKAS_DW.Count02s_MODE) {
        /* InitializeConditions for Memory: '<S353>/Memory' */
        LKAS_DW.Memory_PreviousInput_m5 = 0.0F;
        LKAS_DW.Count02s_MODE = true;
      }

      /* Sum: '<S353>/Add' incorporates:
       *  Memory: '<S353>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_m5;

      /* Saturate: '<S353>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 50.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 50.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S353>/Saturation' */
      /* End of Outputs for SubSystem: '<S322>/Count 0.2s' */

      /* Switch: '<S558>/Switch16' incorporates:
       *  Constant: '<S558>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2'
       *
       * Block description for '<S558>/LL_TkOvStChk_tiTrqChkT_DEACTV=0.2':
       *  ȡ�������ʻԱ�ӹ�ʱ����ֵ
       */
      if (LKAS_ConstB.DataTypeConversion5 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion5;
      } else {
        x10 = LL_TkOvStChk_tiTrqChkT_DEACTV;
      }

      /* End of Switch: '<S558>/Switch16' */

      /* Outputs for Enabled SubSystem: '<S322>/Count 0.2s' incorporates:
       *  EnablePort: '<S353>/Enable'
       */
      /* RelationalOperator: '<S353>/Relational Operator' */
      LKAS_DW.RelationalOperator_l1 = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >= x10);

      /* Update for Memory: '<S353>/Memory' */
      LKAS_DW.Memory_PreviousInput_m5 = rtb_LL_MAX_DRIVER_TORQUE_DISABL;

      /* End of Outputs for SubSystem: '<S322>/Count 0.2s' */
    } else {
      /* Outputs for Enabled SubSystem: '<S322>/Count 0.2s' incorporates:
       *  EnablePort: '<S353>/Enable'
       */
      /* '<S354>:1:10' else */
      /* '<S354>:1:11' stDvrTkConFlg=0; */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S353>/Out' */
        LKAS_DW.RelationalOperator_l1 = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Outputs for SubSystem: '<S322>/Count 0.2s' */
    }

    /* End of MATLAB Function: '<S322>/MATLAB Function' */

    /* RelationalOperator: '<S363>/Compare' incorporates:
     *  Constant: '<S363>/Constant'
     */
    rtb_Compare_km = (((sint32)(LKAS_DW.RelationalOperator_l1 ? 1 : 0)) >
                      ((sint32)(false ? 1 : 0)));

    /* UnitDelay: '<S355>/Unit Delay' */
    rtb_UnitDelay_h = LKAS_DW.UnitDelay_DSTATE_gu;

    /* RelationalOperator: '<S362>/Compare' incorporates:
     *  Constant: '<S362>/Constant'
     */
    rtb_Compare_cj = (((sint32)(rtb_UnitDelay_h ? 1 : 0)) <= ((sint32)(false ? 1
      : 0)));

    /* If: '<S355>/If' incorporates:
     *  Constant: '<S358>/Constant'
     *  Constant: '<S359>/Constant'
     *  RelationalOperator: '<S356>/FixPt Relational Operator'
     *  RelationalOperator: '<S357>/FixPt Relational Operator'
     *  UnitDelay: '<S356>/Delay Input1'
     *  UnitDelay: '<S357>/Delay Input1'
     *
     * Block description for '<S356>/Delay Input1':
     *
     *  Store in Global RAM
     *
     * Block description for '<S357>/Delay Input1':
     *
     *  Store in Global RAM
     */
    if ((LKAS_DW.RelationalOperator_l1) && (((sint32)(rtb_Compare_km ? 1 : 0)) >
         ((sint32)(LKAS_DW.DelayInput1_DSTATE_c ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S355>/If Action Subsystem' incorporates:
       *  ActionPort: '<S358>/Action Port'
       */
      rtb_Merge_c0 = true;

      /* End of Outputs for SubSystem: '<S355>/If Action Subsystem' */
    } else if ((!rtb_UnitDelay_h) && (((sint32)(rtb_Compare_cj ? 1 : 0)) >
                ((sint32)(LKAS_DW.DelayInput1_DSTATE_p ? 1 : 0)))) {
      /* Outputs for IfAction SubSystem: '<S355>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S359>/Action Port'
       */
      rtb_Merge_c0 = false;

      /* End of Outputs for SubSystem: '<S355>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S355>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S360>/Action Port'
       */
      LKAS_IfActionSubsystem3(rtb_UnitDelay_h, &rtb_Merge_c0);

      /* End of Outputs for SubSystem: '<S355>/If Action Subsystem3' */
    }

    /* End of If: '<S355>/If' */

    /* Outputs for Enabled SubSystem: '<S322>/Count' incorporates:
     *  EnablePort: '<S352>/Enable'
     */
    /* Logic: '<S322>/Logical Operator' incorporates:
     *  Constant: '<S351>/Constant'
     *  Memory: '<S322>/Memory'
     *  RelationalOperator: '<S351>/Compare'
     */
    if ((rtb_TCU_ActualGear > ((uint8)0U)) && (LKAS_DW.Memory_PreviousInput_eq))
    {
      if (!LKAS_DW.Count_MODE) {
        /* InitializeConditions for Memory: '<S352>/Memory' */
        LKAS_DW.Memory_PreviousInput_o = 0.0F;
        LKAS_DW.Count_MODE = true;
      }

      /* Sum: '<S352>/Add' incorporates:
       *  Memory: '<S352>/Memory'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_o;

      /* Saturate: '<S352>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        LKAS_DW.Saturation = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        LKAS_DW.Saturation = 0.0F;
      } else {
        LKAS_DW.Saturation = rtb_LftTTLC;
      }

      /* End of Saturate: '<S352>/Saturation' */

      /* Update for Memory: '<S352>/Memory' */
      LKAS_DW.Memory_PreviousInput_o = LKAS_DW.Saturation;
    } else {
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S352>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }
    }

    /* End of Logic: '<S322>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S322>/Count' */

    /* Outputs for Enabled SubSystem: '<S355>/Sum Condition1' incorporates:
     *  EnablePort: '<S361>/state = reset'
     */
    if (rtb_Merge_c0) {
      if (!LKAS_DW.SumCondition1_MODE_f) {
        /* InitializeConditions for Memory: '<S361>/Memory' */
        LKAS_DW.Memory_PreviousInput_n2 = 0.0F;
        LKAS_DW.SumCondition1_MODE_f = true;
      }

      /* Sum: '<S361>/Add1' incorporates:
       *  Memory: '<S361>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_n2;

      /* Saturate: '<S361>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 5.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 5.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S361>/Saturation' */

      /* Switch: '<S558>/Switch40' incorporates:
       *  Constant: '<S558>/LL_TkOvStChk_tiTDelTime_DEACTV=1'
       *
       * Block description for '<S558>/LL_TkOvStChk_tiTDelTime_DEACTV=1':
       *  ȡ����������ϴμ�ʻԱ�ӹ�ʱ����
       */
      if (LKAS_ConstB.DataTypeConversion7 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion7;
      } else {
        x10 = LL_TkOvStChk_tiTDelTime_DEACTV;
      }

      /* End of Switch: '<S558>/Switch40' */

      /* RelationalOperator: '<S361>/Relational Operator' incorporates:
       *  Sum: '<S322>/Add'
       */
      LKAS_DW.RelationalOperator_c = (rtb_LL_MAX_DRIVER_TORQUE_DISABL <= (x10 +
        LKAS_DW.Saturation));

      /* Update for Memory: '<S361>/Memory' */
      LKAS_DW.Memory_PreviousInput_n2 = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_f) {
        /* Disable for Outport: '<S361>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_f = false;
      }
    }

    /* End of Outputs for SubSystem: '<S355>/Sum Condition1' */

    /* Outputs for Enabled SubSystem: '<S323>/Sum Condition1' incorporates:
     *  EnablePort: '<S367>/state = reset'
     */
    /* Logic: '<S323>/Logical Operator' incorporates:
     *  Constant: '<S365>/Constant'
     *  Constant: '<S366>/Constant'
     *  Delay: '<S82>/Delay1'
     *  RelationalOperator: '<S365>/Compare'
     *  RelationalOperator: '<S366>/Compare'
     */
    if ((LKAS_DW.Delay1_3_DSTATE == ((uint8)4U)) || (LKAS_DW.Delay1_3_DSTATE ==
         ((uint8)5U))) {
      if (!LKAS_DW.SumCondition1_MODE_b) {
        /* InitializeConditions for Memory: '<S367>/Memory' */
        LKAS_DW.Memory_PreviousInput_cp = 0.0F;
        LKAS_DW.SumCondition1_MODE_b = true;
      }

      /* Sum: '<S367>/Add1' incorporates:
       *  Memory: '<S367>/Memory'
       */
      rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_cp;

      /* Saturate: '<S367>/Saturation' */
      if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > 1.0F) {
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = 1.0F;
      } else {
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < 0.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 0.0F;
        }
      }

      /* End of Saturate: '<S367>/Saturation' */

      /* RelationalOperator: '<S367>/Relational Operator' */
      LKAS_DW.RelationalOperator_l = (rtb_LL_MAX_DRIVER_TORQUE_DISABL >=
        rtb_LL_TkOvStChk_tiTDelTime);

      /* Update for Memory: '<S367>/Memory' */
      LKAS_DW.Memory_PreviousInput_cp = rtb_LL_MAX_DRIVER_TORQUE_DISABL;
    } else {
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S367>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }
    }

    /* End of Logic: '<S323>/Logical Operator' */
    /* End of Outputs for SubSystem: '<S323>/Sum Condition1' */

    /* If: '<S320>/If1' incorporates:
     *  Constant: '<S325>/Constant'
     *  Constant: '<S327>/Constant'
     *  Constant: '<S364>/Constant'
     *  Delay: '<S82>/Delay'
     *  Logic: '<S320>/Logical Operator'
     *  Logic: '<S323>/Logical Operator1'
     *  RelationalOperator: '<S364>/Compare'
     */
    if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((LKAS_DW.RelationalOperator_c) ||
          ((rtb_IMAPve_d_EPS_LKA_State != ((uint8)3U)) &&
           (LKAS_DW.RelationalOperator_l))) || (LKAS_DW.Delay_DSTATE_j))) {
      /* Outputs for IfAction SubSystem: '<S320>/LKA Deactivation Flag (LKADeactvFlg)' incorporates:
       *  ActionPort: '<S327>/Action Port'
       */
      LKAS_DW.Merge1_c = true;

      /* End of Outputs for SubSystem: '<S320>/LKA Deactivation Flag (LKADeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S320>/Default Flag (DflFlg)1' incorporates:
       *  ActionPort: '<S325>/Action Port'
       */
      LKAS_DW.Merge1_c = false;

      /* End of Outputs for SubSystem: '<S320>/Default Flag (DflFlg)1' */
    }

    /* End of If: '<S320>/If1' */

    /* MATLAB Function: '<S488>/MATLAB Function' */
    LKAS_MATLABFunction(rtb_LL_ThresDet_lDvtThresUprLDW, rtb_LaneWidth,
                        rtb_LKA_CarWidth, &rtb_ThresDet_coefficient_a);

    /* Product: '<S488>/Multiply' */
    rtb_Multiply_d = rtb_LL_ThresDet_lDvtThresUprLDW *
      rtb_ThresDet_coefficient_a;

    /* Switch: '<S490>/Switch' incorporates:
     *  Constant: '<S488>/Constant'
     *  RelationalOperator: '<S490>/UpperRelop'
     */
    if (rtb_Multiply_d < 0.0F) {
      rtb_Switch_p = 0.0F;
    } else {
      rtb_Switch_p = rtb_Multiply_d;
    }

    /* End of Switch: '<S490>/Switch' */

    /* Switch: '<S490>/Switch2' incorporates:
     *  RelationalOperator: '<S490>/LowerRelop1'
     */
    if (rtb_Multiply_d > rtb_LL_ThresDet_lDvtThresUprLDW) {
      rtb_Switch2_c = rtb_LL_ThresDet_lDvtThresUprLDW;
    } else {
      rtb_Switch2_c = rtb_Switch_p;
    }

    /* End of Switch: '<S490>/Switch2' */

    /* Logic: '<S474>/Logical Operator3' incorporates:
     *  Constant: '<S486>/Constant'
     *  Constant: '<S487>/Constant'
     *  Logic: '<S484>/Logical Operator'
     *  Logic: '<S485>/Logical Operator'
     *  RelationalOperator: '<S485>/Relational Operator1'
     *  RelationalOperator: '<S485>/Relational Operator2'
     *  RelationalOperator: '<S486>/Compare'
     *  RelationalOperator: '<S487>/Compare'
     */
    rtb_LogicalOperator3_b5 = (((LKAS_DW.LKA_Mode >= ((uint8)1U)) && (((sint32)
      (((rtb_Gain1_j >= rtb_Switch2_c) && (rtb_Add5_n >= rtb_Switch2_c)) ? 1 : 0))
      == ((sint32)(true ? 1 : 0)))) && rtb_LogicalOperator3_b5);

    /* If: '<S474>/If' incorporates:
     *  Constant: '<S480>/Constant'
     *  DataTypeConversion: '<S474>/Cast To Single'
     *  DataTypeConversion: '<S474>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_LogicalOperator3_b5) {
      /* Outputs for IfAction SubSystem: '<S474>/If Action Subsystem' incorporates:
       *  ActionPort: '<S480>/Action Port'
       */
      LKAS_DW.Merge_ew = true;

      /* End of Outputs for SubSystem: '<S474>/If Action Subsystem' */
    } else {
      /* Outputs for IfAction SubSystem: '<S474>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S482>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge_ew);

      /* End of Outputs for SubSystem: '<S474>/If Action Subsystem3' */
    }

    /* End of If: '<S474>/If' */

    /* Delay: '<S82>/Delay1' */
    rtb_LDW_State = LKAS_DW.Delay1_1_DSTATE;

    /* If: '<S370>/u1>=3|u1==1&u2==u3' incorporates:
     *  Memory: '<S370>/Memory'
     */
    rtPrevAction = LKAS_DW.u13u11u2u3_ActiveSubsystem;
    rtAction = (sint8)(((((sint32)rtb_LDW_State) != 4) && ((((sint32)
      rtb_LDW_State) != 5) || (LKAS_DW.Memory_PreviousInput_id != rtb_LDW_State)))
                       ? 1 : 0);
    LKAS_DW.u13u11u2u3_ActiveSubsystem = rtAction;
    switch (rtAction) {
     case 0:
      if (rtAction != rtPrevAction) {
        /* InitializeConditions for IfAction SubSystem: '<S370>/If Action Subsystem' incorporates:
         *  ActionPort: '<S400>/Action Port'
         */
        /* InitializeConditions for If: '<S370>/u1>=3|u1==1&u2==u3' incorporates:
         *  Memory: '<S400>/Memory'
         */
        LKAS_DW.Memory_PreviousInput_n = 0.0F;

        /* End of InitializeConditions for SubSystem: '<S370>/If Action Subsystem' */
      }

      /* Outputs for IfAction SubSystem: '<S370>/If Action Subsystem' incorporates:
       *  ActionPort: '<S400>/Action Port'
       */
      /* Sum: '<S400>/Add1' incorporates:
       *  Memory: '<S400>/Memory'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_n;

      /* Saturate: '<S400>/Saturation' */
      if (rtb_LL_TkOvStChk_tiTDelTime > 10.0F) {
        rtb_LL_TkOvStChk_tiTDelTime = 10.0F;
      } else {
        if (rtb_LL_TkOvStChk_tiTDelTime < 0.0F) {
          rtb_LL_TkOvStChk_tiTDelTime = 0.0F;
        }
      }

      /* End of Saturate: '<S400>/Saturation' */
      /* End of Outputs for SubSystem: '<S370>/If Action Subsystem' */

      /* Switch: '<S558>/Switch64' incorporates:
       *  Constant: '<S558>/LLSMConClb33'
       *
       * Block description for '<S558>/LLSMConClb33':
       *  LDW���ܵ���������ʱ������
       */
      if (LKAS_ConstB.DataTypeConversion80 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion80;
      } else {
        x10 = LL_Max_LDWS_Warning_Time;
      }

      /* End of Switch: '<S558>/Switch64' */

      /* Outputs for IfAction SubSystem: '<S370>/If Action Subsystem' incorporates:
       *  ActionPort: '<S400>/Action Port'
       */
      /* RelationalOperator: '<S400>/Relational Operator' */
      rtb_Merge_a3 = (rtb_LL_TkOvStChk_tiTDelTime >= x10);

      /* Update for Memory: '<S400>/Memory' */
      LKAS_DW.Memory_PreviousInput_n = rtb_LL_TkOvStChk_tiTDelTime;

      /* End of Outputs for SubSystem: '<S370>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S370>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S401>/Action Port'
       */
      /* SignalConversion: '<S401>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
       *  Constant: '<S401>/Constant'
       */
      rtb_Merge_a3 = false;

      /* End of Outputs for SubSystem: '<S370>/If Action Subsystem1' */
      break;

     default:
      /* no actions */
      break;
    }

    /* End of If: '<S370>/u1>=3|u1==1&u2==u3' */

    /* Logic: '<S371>/Logical Operator1' incorporates:
     *  Constant: '<S402>/Constant'
     *  Logic: '<S371>/Logical Operator'
     *  RelationalOperator: '<S371>/Relational Operator1'
     *  RelationalOperator: '<S371>/Relational Operator2'
     *  RelationalOperator: '<S402>/Compare'
     */
    rtb_BCM_Left_Light = ((LKAS_DW.LKA_Mode >= ((uint8)1U)) && ((rtb_Gain1_j <=
      rtb_LL_LDW_LatestWarnLine_C) || (rtb_Add5_n <= rtb_LL_LDW_LatestWarnLine_C)));

    /* Logic: '<S368>/Logical Operator3' */
    rtb_LogicalOperator3_pm = ((rtb_BCM_Left_Light || rtb_Merge_a3) ||
      rtb_LogicalOperator3_pm);

    /* If: '<S368>/If1' incorporates:
     *  Constant: '<S378>/Constant'
     *  DataTypeConversion: '<S368>/Cast To Single'
     *  DataTypeConversion: '<S368>/Cast To Single1'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && rtb_LogicalOperator3_pm) {
      /* Outputs for IfAction SubSystem: '<S368>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S378>/Action Port'
       */
      LKAS_DW.Merge1_i = true;

      /* End of Outputs for SubSystem: '<S368>/If Action Subsystem2' */
    } else {
      /* Outputs for IfAction SubSystem: '<S368>/If Action Subsystem4' incorporates:
       *  ActionPort: '<S380>/Action Port'
       */
      LKAS_IfActionSubsystem4(&LKAS_DW.Merge1_i);

      /* End of Outputs for SubSystem: '<S368>/If Action Subsystem4' */
    }

    /* End of If: '<S368>/If1' */

    /* Memory: '<S296>/Memory' */
    rtb_Memory_e = LKAS_DW.Memory_PreviousInput_i;

    /* If: '<S296>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_pw >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S296>/Ph1SWA' incorporates:
       *  ActionPort: '<S300>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S296>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_pw <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S296>/Ph2SWA' incorporates:
       *  ActionPort: '<S301>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S296>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S296>/Ph3SWA' incorporates:
       *  ActionPort: '<S302>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_e, &rtb_Merge1_n);

      /* End of Outputs for SubSystem: '<S296>/Ph3SWA' */
    }

    /* End of If: '<S296>/If' */

    /* Product: '<S292>/Divide2' incorporates:
     *  MATLAB Function: '<S292>/MATLAB Function'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S292>/Divide3' incorporates:
     *  MATLAB Function: '<S292>/MATLAB Function'
     */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S298>/Divide' */
    rtb_Divide_k = rtb_LKA_Veh2CamL_C * x1;

    /* Product: '<S292>/Divide1' incorporates:
     *  MATLAB Function: '<S292>/MATLAB Function'
     */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S303>/Switch' incorporates:
     *  RelationalOperator: '<S303>/UpperRelop'
     */
    if (rtb_Divide_k < rtb_LftTTLC) {
      rtb_Switch_a = rtb_LftTTLC;
    } else {
      rtb_Switch_a = rtb_Divide_k;
    }

    /* End of Switch: '<S303>/Switch' */

    /* Switch: '<S303>/Switch2' incorporates:
     *  RelationalOperator: '<S303>/LowerRelop1'
     */
    if (rtb_Divide_k > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_j = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_j = rtb_Switch_a;
    }

    /* End of Switch: '<S303>/Switch2' */

    /* Product: '<S299>/Divide' */
    rtb_Divide_kp = rtb_LKA_Veh2CamL_C * rtb_LogicalOperator3_c_tmp;

    /* Switch: '<S304>/Switch' incorporates:
     *  RelationalOperator: '<S304>/UpperRelop'
     */
    if (rtb_Divide_kp < rtb_LftTTLC) {
      rtb_Switch_o = rtb_LftTTLC;
    } else {
      rtb_Switch_o = rtb_Divide_kp;
    }

    /* End of Switch: '<S304>/Switch' */

    /* Switch: '<S304>/Switch2' incorporates:
     *  RelationalOperator: '<S304>/LowerRelop1'
     */
    if (rtb_Divide_kp > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_jh = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_jh = rtb_Switch_o;
    }

    /* End of Switch: '<S304>/Switch2' */

    /* Switch: '<S297>/Switch3' incorporates:
     *  Gain: '<S297>/Gain1'
     *  RelationalOperator: '<S299>/Relational Operator2'
     */
    if (rtb_Merge1_n >= 0.0F) {
      /* Switch: '<S297>/Switch2' incorporates:
       *  Constant: '<S297>/Constant2'
       *  DataTypeConversion: '<S297>/Cast To Single'
       *  RelationalOperator: '<S298>/Relational Operator2'
       */
      if (rtb_Merge1_n > 0.0F) {
        rtb_CastToSingle3 = (uint8)((rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ <=
          rtb_Switch2_j) ? 1 : 0);
      } else {
        rtb_CastToSingle3 = ((uint8)0U);
      }

      /* End of Switch: '<S297>/Switch2' */
    } else {
      rtb_CastToSingle3 = (uint8)((((uint32)((rtb_TTLC_d <= rtb_Switch2_jh) ? 1 :
        0)) * ((uint32)((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S297>/Switch3' */

    /* If: '<S282>/If' incorporates:
     *  Constant: '<S286>/Constant'
     *  Constant: '<S288>/Constant'
     *  Constant: '<S289>/Constant'
     */
    if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
         && (((sint32)rtb_CastToSingle3) == 1)) && (((sint32)
          rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S282>/LDW Left Active Flag (LDWLftActvFlg)' incorporates:
       *  ActionPort: '<S288>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)1U);

      /* End of Outputs for SubSystem: '<S282>/LDW Left Active Flag (LDWLftActvFlg)' */
    } else if ((((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode)
      == 2)) && (((sint32)rtb_CastToSingle3) == 2)) && (((sint32)
                 rtb_IMAPve_d_SAS_Trim_State) == 1)) {
      /* Outputs for IfAction SubSystem: '<S282>/LDW Right Active Flag (LDWRgtActvFlg)' incorporates:
       *  ActionPort: '<S289>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)2U);

      /* End of Outputs for SubSystem: '<S282>/LDW Right Active Flag (LDWRgtActvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S282>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S286>/Action Port'
       */
      LKAS_DW.LKA_State_Mon = ((uint8)0U);

      /* End of Outputs for SubSystem: '<S282>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S282>/If' */

    /* Memory: '<S332>/Memory' */
    rtb_Memory_p = LKAS_DW.Memory_PreviousInput_a;

    /* If: '<S332>/If' */
    if ((rtb_Abs_a >= rtb_LL_DvtSpdDet_vDvtSpdMin_C) && (rtb_Abs_pw >=
         rtb_LL_DvtSpdDet_vDvtSpdMin_C)) {
      /* Outputs for IfAction SubSystem: '<S332>/Ph1SWA' incorporates:
       *  ActionPort: '<S336>/Action Port'
       */
      LKAS_Ph1SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S332>/Ph1SWA' */
    } else if ((rtb_Abs_a <= (-rtb_LL_DvtSpdDet_vDvtSpdMin_C)) && (rtb_Abs_pw <=
                (-rtb_LL_DvtSpdDet_vDvtSpdMin_C))) {
      /* Outputs for IfAction SubSystem: '<S332>/Ph2SWA' incorporates:
       *  ActionPort: '<S337>/Action Port'
       */
      LKAS_Ph2SWA(&rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S332>/Ph2SWA' */
    } else {
      /* Outputs for IfAction SubSystem: '<S332>/Ph3SWA' incorporates:
       *  ActionPort: '<S338>/Action Port'
       */
      LKAS_Ph3SWA(rtb_Memory_p, &rtb_Merge1_j);

      /* End of Outputs for SubSystem: '<S332>/Ph3SWA' */
    }

    /* End of If: '<S332>/If' */

    /* Product: '<S328>/Divide2' */
    rtb_LL_ThresDet_lDvtThresUprLKA = x20 * rtb_LL_ThresDet_lDvtThresUprLDW;

    /* Product: '<S328>/Divide3' */
    rtb_LKA_Veh2CamL_C = x20 * rtb_LL_ThresDet_tiTTLCThresLDW;

    /* Product: '<S334>/Divide' */
    rtb_Divide_bk = rtb_LKA_Veh2CamL_C * x1;

    /* Product: '<S328>/Divide1' */
    rtb_LftTTLC = x20 * rtb_LL_ThresDet_lDvtThresLwrLDW;

    /* Switch: '<S340>/Switch' incorporates:
     *  RelationalOperator: '<S340>/UpperRelop'
     */
    if (rtb_Divide_bk < rtb_LftTTLC) {
      rtb_Switch_gl = rtb_LftTTLC;
    } else {
      rtb_Switch_gl = rtb_Divide_bk;
    }

    /* End of Switch: '<S340>/Switch' */

    /* Switch: '<S340>/Switch2' incorporates:
     *  RelationalOperator: '<S340>/LowerRelop1'
     */
    if (rtb_Divide_bk > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_nc = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_nc = rtb_Switch_gl;
    }

    /* End of Switch: '<S340>/Switch2' */

    /* Product: '<S335>/Divide' */
    rtb_Divide_h = rtb_LKA_Veh2CamL_C * rtb_LogicalOperator3_c_tmp;

    /* Switch: '<S341>/Switch' incorporates:
     *  RelationalOperator: '<S341>/UpperRelop'
     */
    if (rtb_Divide_h < rtb_LftTTLC) {
      rtb_Switch_e = rtb_LftTTLC;
    } else {
      rtb_Switch_e = rtb_Divide_h;
    }

    /* End of Switch: '<S341>/Switch' */

    /* Switch: '<S341>/Switch2' incorporates:
     *  RelationalOperator: '<S341>/LowerRelop1'
     */
    if (rtb_Divide_h > rtb_LL_ThresDet_lDvtThresUprLKA) {
      rtb_Switch2_g = rtb_LL_ThresDet_lDvtThresUprLKA;
    } else {
      rtb_Switch2_g = rtb_Switch_e;
    }

    /* End of Switch: '<S341>/Switch2' */

    /* Switch: '<S333>/Switch3' incorporates:
     *  Gain: '<S333>/Gain1'
     *  RelationalOperator: '<S335>/Relational Operator2'
     */
    if (rtb_Merge1_j >= 0.0F) {
      /* Switch: '<S333>/Switch2' incorporates:
       *  Constant: '<S333>/Constant2'
       *  DataTypeConversion: '<S333>/Cast To Single'
       *  RelationalOperator: '<S334>/Relational Operator2'
       */
      if (rtb_Merge1_j > 0.0F) {
        rtb_IMAPve_d_SAS_Trim_State = (uint8)((rtb_TLft <= rtb_Switch2_nc) ? 1 :
          0);
      } else {
        rtb_IMAPve_d_SAS_Trim_State = ((uint8)0U);
      }

      /* End of Switch: '<S333>/Switch2' */
    } else {
      rtb_IMAPve_d_SAS_Trim_State = (uint8)((((uint32)
        ((rtb_LL_ThresDet_lDvtThresLwrLKA <= rtb_Switch2_g) ? 1 : 0)) * ((uint32)
        ((uint8)128U))) >> 6);
    }

    /* End of Switch: '<S333>/Switch3' */

    /* Outputs for Enabled SubSystem: '<S333>/Sum Condition' incorporates:
     *  EnablePort: '<S339>/Enable'
     */
    if (((sint32)rtb_IMAPve_d_SAS_Trim_State) > 0) {
      if (!LKAS_DW.SumCondition_MODE) {
        /* InitializeConditions for Memory: '<S339>/Memory' */
        LKAS_DW.Memory_PreviousInput_d = 0.0F;
        LKAS_DW.SumCondition_MODE = true;
      }

      /* Sum: '<S339>/Add1' incorporates:
       *  Memory: '<S339>/Memory'
       */
      rtb_LL_LDW_LatestWarnLine_C = rtb_LKA_SampleTime +
        LKAS_DW.Memory_PreviousInput_d;

      /* Saturate: '<S339>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 5.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 5.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S339>/Saturation' */

      /* RelationalOperator: '<S339>/Relational Operator' incorporates:
       *  Constant: '<S333>/Constant'
       */
      LKAS_DW.RelationalOperator_na = (rtb_LL_LDW_LatestWarnLine_C <= 2.0F);

      /* Update for Memory: '<S339>/Memory' */
      LKAS_DW.Memory_PreviousInput_d = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S339>/Out' */
        LKAS_DW.RelationalOperator_na = false;
        LKAS_DW.SumCondition_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S333>/Sum Condition' */

    /* If: '<S320>/If' incorporates:
     *  Constant: '<S324>/Constant'
     *  Constant: '<S326>/Constant'
     *  DataTypeConversion: '<S333>/Cast To Single3'
     *  DataTypeConversion: '<S333>/Cast To Single4'
     *  Product: '<S333>/Divide'
     */
    if (((((sint32)LKAS_DW.LKA_Mode) == 1) || (((sint32)LKAS_DW.LKA_Mode) == 2))
        && (((sint32)((uint32)(((uint32)rtb_IMAPve_d_SAS_Trim_State) *
            (LKAS_DW.RelationalOperator_na ? 1U : 0U)))) == 0)) {
      /* Outputs for IfAction SubSystem: '<S320>/LDW Deactivation Flag (LDWDeactvFlg)' incorporates:
       *  ActionPort: '<S326>/Action Port'
       */
      LKAS_DW.Merge_a = true;

      /* End of Outputs for SubSystem: '<S320>/LDW Deactivation Flag (LDWDeactvFlg)' */
    } else {
      /* Outputs for IfAction SubSystem: '<S320>/Default Flag (DflFlg)' incorporates:
       *  ActionPort: '<S324>/Action Port'
       */
      LKAS_DW.Merge_a = false;

      /* End of Outputs for SubSystem: '<S320>/Default Flag (DflFlg)' */
    }

    /* End of If: '<S320>/If' */

    /* Outputs for Enabled SubSystem: '<S281>/Count_5s3' incorporates:
     *  EnablePort: '<S545>/Enable'
     */
    /* RelationalOperator: '<S530>/Compare' incorporates:
     *  Constant: '<S530>/Constant'
     *  Constant: '<S565>/Constant'
     */
    if (((uint8)0U) == ((uint8)1U)) {
      if (!LKAS_DW.Count_5s3_MODE) {
        /* InitializeConditions for Memory: '<S545>/Memory' */
        LKAS_DW.Memory_PreviousInput_i3 = 0.0F;
        LKAS_DW.Count_5s3_MODE = true;
      }

      /* Sum: '<S545>/Add' incorporates:
       *  Memory: '<S545>/Memory'
       */
      rtb_LL_LDW_LatestWarnLine_C = LKAS_DW.Memory_PreviousInput_i3 +
        rtb_LKA_SampleTime;

      /* Saturate: '<S545>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 11.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 11.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S545>/Saturation' */

      /* RelationalOperator: '<S545>/Relational Operator' incorporates:
       *  Constant: '<S545>/Constant1'
       */
      LKAS_DW.RelationalOperator = (rtb_LL_LDW_LatestWarnLine_C >= ((float32)
        ((uint16)5U)));

      /* Update for Memory: '<S545>/Memory' */
      LKAS_DW.Memory_PreviousInput_i3 = rtb_LL_LDW_LatestWarnLine_C;
    } else {
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S545>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }
    }

    /* End of RelationalOperator: '<S530>/Compare' */
    /* End of Outputs for SubSystem: '<S281>/Count_5s3' */

    /* RelationalOperator: '<S535>/Compare' incorporates:
     *  Constant: '<S535>/Constant'
     */
    rtb_Compare_gt = (rtb_IMAPve_d_Camera_Status == ((uint8)3U));

    /* Outputs for Enabled SubSystem: '<S281>/Count_5s2' */
    LKAS_Count_5s1(rtb_Compare_gt, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_o, &LKAS_DW.Count_5s2);

    /* End of Outputs for SubSystem: '<S281>/Count_5s2' */

    /* Logic: '<S281>/Logical Operator10' */
    LKAS_DW.LKA_Fault = ((LKAS_DW.RelationalOperator) ||
                         (LKAS_DW.RelationalOperator_o));

    /* Chart: '<S82>/LDW_State_Machine'
     *
     * Block description for '<S82>/LDW_State_Machine':
     *  Block Name: LDW State Machine
     *  Ab.: LDWSM
     *  No.: 1.1.2.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LDW_State_Machine();

    /* RelationalOperator: '<S534>/Compare' incorporates:
     *  Constant: '<S534>/Constant'
     */
    rtb_Compare_oz = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

    /* Outputs for Enabled SubSystem: '<S281>/Count_5s1' */
    LKAS_Count_5s1(rtb_Compare_oz, rtb_LKA_SampleTime,
                   &LKAS_DW.RelationalOperator_g, &LKAS_DW.Count_5s1);

    /* End of Outputs for SubSystem: '<S281>/Count_5s1' */

    /* Logic: '<S281>/Logical Operator8' */
    LKAS_DW.LKA_Fault = (((LKAS_DW.RelationalOperator) ||
                          (LKAS_DW.RelationalOperator_o)) ||
                         (LKAS_DW.RelationalOperator_g));

    /* Chart: '<S82>/LKA_State_Machine'
     *
     * Block description for '<S82>/LKA_State_Machine':
     *  Block Name: LKA State Machine
     *  Ab.: LKASM
     *  No.: 1.1.3.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    LKAS_LKA_State_Machine();

    /* Outputs for Enabled SubSystem: '<S258>/Subsystem' incorporates:
     *  EnablePort: '<S262>/Enable'
     */
    /* Logic: '<S258>/Logical Operator3' incorporates:
     *  Abs: '<S258>/Abs4'
     *  Abs: '<S258>/Abs5'
     *  Abs: '<S258>/Abs6'
     *  Abs: '<S258>/Abs7'
     *  Constant: '<S258>/Constant'
     *  Constant: '<S258>/Constant1'
     *  Constant: '<S258>/Constant4'
     *  Constant: '<S258>/Constant5'
     *  Constant: '<S260>/Constant'
     *  Constant: '<S261>/Constant'
     *  Logic: '<S258>/Logical Operator'
     *  Logic: '<S258>/Logical Operator1'
     *  Logic: '<S258>/Logical Operator4'
     *  RelationalOperator: '<S258>/Relational Operator'
     *  RelationalOperator: '<S258>/Relational Operator1'
     *  RelationalOperator: '<S258>/Relational Operator2'
     *  RelationalOperator: '<S258>/Relational Operator3'
     *  RelationalOperator: '<S258>/Relational Operator6'
     *  RelationalOperator: '<S258>/Relational Operator7'
     *  RelationalOperator: '<S260>/Compare'
     *  RelationalOperator: '<S261>/Compare'
     *  Switch: '<S51>/Switch'
     *  Switch: '<S51>/Switch1'
     */
    if ((((((fabsf(rtb_L0_C1_m) <= 0.005F) && (fabsf(rtb_L0_C1_i) <= 0.005F)) &&
           ((fabsf(rtb_LL_CompHdAg_C) <= 0.0001F) && (fabsf(rtb_L0_C2) <=
             0.0001F))) && ((rtb_L0_Q == ((uint8)3U)) && (rtb_R0_Q == ((uint8)3U))))
         && (rtb_IMAPve_g_ESC_VehSpd >= 50.0F)) && (rtb_TTLC <= 1.0F)) {
      if (!LKAS_DW.Subsystem_MODE_p) {
        /* InitializeConditions for Memory: '<S262>/Memory' */
        LKAS_DW.Memory_PreviousInput_h = ((uint16)0U);
        LKAS_DW.Subsystem_MODE_p = true;
      }

      /* Sum: '<S262>/Add1' incorporates:
       *  Memory: '<S262>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(1U + ((uint32)LKAS_DW.Memory_PreviousInput_h));

      /* Saturate: '<S262>/Saturation' */
      if (rtb_Saturation_h5 >= ((uint16)3000U)) {
        rtb_Saturation_h5 = ((uint16)3000U);
      }

      /* End of Saturate: '<S262>/Saturation' */

      /* RelationalOperator: '<S262>/Relational Operator' incorporates:
       *  Constant: '<S258>/Constant3'
       *  DataTypeConversion: '<S262>/Cast To Single1'
       *  Product: '<S258>/Divide'
       */
      LKAS_DW.RelationalOperator_k = (rtb_Saturation_h5 >= ((uint16)((float32)
        (2.0F / rtb_LKA_SampleTime))));

      /* Update for Memory: '<S262>/Memory' */
      LKAS_DW.Memory_PreviousInput_h = rtb_Saturation_h5;
    } else {
      if (LKAS_DW.Subsystem_MODE_p) {
        /* Disable for Outport: '<S262>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Subsystem_MODE_p = false;
      }
    }

    /* End of Logic: '<S258>/Logical Operator3' */
    /* End of Outputs for SubSystem: '<S258>/Subsystem' */

    /* Outputs for Enabled SubSystem: '<S232>/Subsystem' incorporates:
     *  EnablePort: '<S257>/Enable'
     */
    if (LKAS_DW.RelationalOperator_k) {
      /* Sum: '<S259>/Add2' incorporates:
       *  Constant: '<S259>/SWACmdSyn_tiSmplT_C4'
       *  Memory: '<S259>/Memory3'
       */
      rtb_LL_LDW_LatestWarnLine_C = 1.0F + LKAS_DW.Memory3_PreviousInput;

      /* Saturate: '<S259>/Saturation' */
      if (rtb_LL_LDW_LatestWarnLine_C > 50.0F) {
        rtb_LL_LDW_LatestWarnLine_C = 50.0F;
      } else {
        if (rtb_LL_LDW_LatestWarnLine_C < 0.0F) {
          rtb_LL_LDW_LatestWarnLine_C = 0.0F;
        }
      }

      /* End of Saturate: '<S259>/Saturation' */

      /* Switch: '<S259>/Switch' incorporates:
       *  Constant: '<S257>/Constant'
       *  Product: '<S259>/Divide'
       *  Product: '<S259>/Divide1'
       *  Sum: '<S259>/Add'
       *  Sum: '<S259>/Add1'
       *  UnitDelay: '<S259>/Unit Delay'
       */
      if (rtb_LL_LDW_LatestWarnLine_C > 1.0F) {
        rtb_LL_ThresDet_lDvtThresLwrLDW = ((rtb_LKA_SampleTime / 10.0F) *
          (rtb_R0_C2 - LKAS_DW.UnitDelay_DSTATE)) + LKAS_DW.UnitDelay_DSTATE;
      } else {
        rtb_LL_ThresDet_lDvtThresLwrLDW = rtb_R0_C2;
      }

      /* End of Switch: '<S259>/Switch' */

      /* Saturate: '<S257>/Saturation' */
      if (rtb_LL_ThresDet_lDvtThresLwrLDW > 3.0F) {
        LKAS_DW.Saturation_h = 3.0F;
      } else if (rtb_LL_ThresDet_lDvtThresLwrLDW < (-3.0F)) {
        LKAS_DW.Saturation_h = (-3.0F);
      } else {
        LKAS_DW.Saturation_h = rtb_LL_ThresDet_lDvtThresLwrLDW;
      }

      /* End of Saturate: '<S257>/Saturation' */

      /* Update for UnitDelay: '<S259>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE = rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Update for Memory: '<S259>/Memory3' */
      LKAS_DW.Memory3_PreviousInput = rtb_LL_LDW_LatestWarnLine_C;
    }

    /* End of Outputs for SubSystem: '<S232>/Subsystem' */

    /* Saturate: '<S234>/Saturation' */
    if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else if (rtb_IMAPve_g_ESC_VehSpd < 0.001F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.001F;
    } else {
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_IMAPve_g_ESC_VehSpd;
    }

    /* End of Saturate: '<S234>/Saturation' */

    /* Gain: '<S270>/kph To mps' incorporates:
     *  Gain: '<S271>/kph To mps'
     */
    rtb_LL_ThresDet_lDvtThresLwrLDW = 0.277777791F *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S270>/Saturation3' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Max (SWAMax)/MATLAB Function': '<S272>:1' */
    /* '<S272>:1:2' SWAmax = ((K*v*v+1)*ax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 150.0F;
    } else if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
      rtb_LL_LDW_LatestWarnLine_C = 60.0F;
    } else {
      rtb_LL_LDW_LatestWarnLine_C = rtb_LL_ThresDet_lDvtThresUprLKA;
    }

    /* End of Saturate: '<S270>/Saturation3' */

    /* Product: '<S270>/Divide1' incorporates:
     *  Constant: '<S270>/Constant'
     */
    rtb_LftTTLC = 0.09F / rtb_LL_LDW_LatestWarnLine_C;

    /* Saturate: '<S270>/Saturation1' */
    if (rtb_LftTTLC > 0.0117F) {
      rtb_LftTTLC = 0.0117F;
    } else {
      if (rtb_LftTTLC < 0.00237F) {
        rtb_LftTTLC = 0.00237F;
      }
    }

    /* End of Saturate: '<S270>/Saturation1' */

    /* Switch: '<S557>/Switch7' incorporates:
     *  Constant: '<S557>/LL_LAccMax_C=3'
     */
    if (LKAS_ConstB.DataTypeConversion5_k != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion5_k;
    } else {
      x10 = LL_LAccMax_C;
    }

    /* End of Switch: '<S557>/Switch7' */

    /* MATLAB Function: '<S270>/MATLAB Function' incorporates:
     *  Gain: '<S270>/kph To mps'
     */
    rtb_LL_LDW_LatestWarnLine_C = ((((((((rtb_LftTTLC *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_d) * LKAS_DW.LKA_WhlBaseL_C_m) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Saturate: '<S271>/Saturation3' */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 150.0F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 150.0F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 60.0F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 60.0F;
      }
    }

    /* End of Saturate: '<S271>/Saturation3' */

    /* Product: '<S271>/Divide1' incorporates:
     *  Constant: '<S271>/Constant'
     */
    rtb_LL_ThresDet_lDvtThresUprLKA = 0.09F / rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Saturate: '<S271>/Saturation1' */
    /* MATLAB Function 'LKAS/LL/LLOn/LKA Input Processing (LKAInP)/Under The Limit (UndrLim)/Steering Wheel Angel Rate Max (SWARMax)/MATLAB Function': '<S273>:1' */
    /* '<S273>:1:2' SWARmax = ((K*v*v+1)*dax*i*L)/(v*v)*180/3.14; */
    if (rtb_LL_ThresDet_lDvtThresUprLKA > 0.0117F) {
      rtb_LL_ThresDet_lDvtThresUprLKA = 0.0117F;
    } else {
      if (rtb_LL_ThresDet_lDvtThresUprLKA < 0.00237F) {
        rtb_LL_ThresDet_lDvtThresUprLKA = 0.00237F;
      }
    }

    /* End of Saturate: '<S271>/Saturation1' */

    /* Switch: '<S557>/Switch4' incorporates:
     *  Constant: '<S557>/LL_LAccRMax_C=5'
     */
    if (LKAS_ConstB.DataTypeConversion10_j != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion10_j;
    } else {
      x10 = LL_LAccRMax_C;
    }

    /* End of Switch: '<S557>/Switch4' */

    /* MATLAB Function: '<S271>/MATLAB Function' */
    rtb_LL_ThresDet_lDvtThresLwrLDW = ((((((((rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_LL_ThresDet_lDvtThresLwrLDW) + 1.0F)
      * x10) * LKAS_DW.LKA_StrRatio_C_d) * LKAS_DW.LKA_WhlBaseL_C_m) /
      (rtb_LL_ThresDet_lDvtThresLwrLDW * rtb_LL_ThresDet_lDvtThresLwrLDW)) *
      180.0F) / 3.14F;

    /* Gain: '<S229>/Gain1' incorporates:
     *  Sum: '<S229>/Add1'
     */
    rtb_LL_ThresDet_tiTTLCThresLDW = (rtb_Add_p + rtb_Add_o) * 0.5F;

    /* Switch: '<S231>/Switch' incorporates:
     *  Constant: '<S247>/Constant'
     *  RelationalOperator: '<S247>/Compare'
     */
    if (rtb_LFTTTLC <= 2.0F) {
      rtb_LftTTLC = rtb_LFTTTLC;
    } else {
      rtb_LftTTLC = rtb_LL_HdAgPrvwT_C;
    }

    /* End of Switch: '<S231>/Switch' */

    /* Saturate: '<S231>/Saturation' */
    if (rtb_LftTTLC > 2.0F) {
      rtb_LftTTLC = 2.0F;
    } else {
      if (rtb_LftTTLC < 0.5F) {
        rtb_LftTTLC = 0.5F;
      }
    }

    /* End of Saturate: '<S231>/Saturation' */

    /* Product: '<S255>/Divide' */
    rtb_Divide_ca = rtb_Abs_f_tmp * rtb_LftTTLC;

    /* Switch: '<S231>/Switch1' incorporates:
     *  Constant: '<S248>/Constant'
     *  RelationalOperator: '<S248>/Compare'
     */
    if (rtb_RGTTTLC <= 2.0F) {
      rtb_LL_HdAgPrvwT_C = rtb_RGTTTLC;
    }

    /* End of Switch: '<S231>/Switch1' */

    /* Saturate: '<S231>/Saturation1' */
    if (rtb_LL_HdAgPrvwT_C > 2.0F) {
      rtb_LL_HdAgPrvwT_C = 2.0F;
    } else {
      if (rtb_LL_HdAgPrvwT_C < 0.5F) {
        rtb_LL_HdAgPrvwT_C = 0.5F;
      }
    }

    /* End of Saturate: '<S231>/Saturation1' */

    /* Product: '<S256>/Divide' */
    rtb_Divide_dv = rtb_Abs_f_tmp * rtb_LL_HdAgPrvwT_C;

    /* Gain: '<S231>/Gain1' incorporates:
     *  Sum: '<S231>/Add1'
     */
    rtb_LL_HdAgPrvwT_C = (rtb_Divide_ca + rtb_Divide_dv) * 0.5F;

    /* Switch: '<S557>/Switch8' incorporates:
     *  Constant: '<S557>/LL_DvtPrvwT_C=0.45'
     */
    if (LKAS_ConstB.DataTypeConversion8_i != 0.0F) {
      x10 = LKAS_ConstB.DataTypeConversion8_i;
    } else {
      x10 = LL_DvtPrvwT_C;
    }

    /* End of Switch: '<S557>/Switch8' */

    /* Product: '<S246>/Divide' */
    rtb_LL_ThresDet_lDvtThresUprLKA = rtb_Abs_f_tmp * x10;

    /* Product: '<S244>/Z*Z' incorporates:
     *  Product: '<S245>/Z*Z'
     */
    rtb_LL_DvtSpdDet_vDvtSpdMin_C = rtb_LL_ThresDet_lDvtThresUprLKA *
      rtb_LL_ThresDet_lDvtThresUprLKA;

    /* Sum: '<S244>/Add' incorporates:
     *  Product: '<S244>/Product'
     *  Product: '<S244>/Product3'
     *  Product: '<S244>/Product4'
     *  Product: '<S244>/Z*Z'
     *  Product: '<S244>/Z*Z*Z'
     */
    rtb_Add_am = (((rtb_L0_C1_m * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_L0_C0_o)
                  + (rtb_LL_CompHdAg_C * rtb_LL_DvtSpdDet_vDvtSpdMin_C)) +
      ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_DvtSpdDet_vDvtSpdMin_C) *
       rtb_L0_C3_dc);

    /* Sum: '<S245>/Add' incorporates:
     *  Product: '<S245>/Product'
     *  Product: '<S245>/Product3'
     *  Product: '<S245>/Product4'
     *  Product: '<S245>/Z*Z*Z'
     */
    rtb_Add_e1 = (((rtb_L0_C1_i * rtb_LL_ThresDet_lDvtThresUprLKA) + rtb_R0_C0_n)
                  + (rtb_L0_C2 * rtb_LL_DvtSpdDet_vDvtSpdMin_C)) +
      ((rtb_LL_ThresDet_lDvtThresUprLKA * rtb_LL_DvtSpdDet_vDvtSpdMin_C) *
       rtb_L0_C3);

    /* Outputs for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) > 0) {
      if (!LKAS_DW.LKA_MODE) {
        /* InitializeConditions for Memory: '<S108>/Memory' */
        LKAS_DW.Memory_PreviousInput_ok = 0.0F;

        /* InitializeConditions for Memory: '<S139>/Memory' */
        LKAS_DW.Memory_PreviousInput_mx = ((uint16)0U);

        /* InitializeConditions for Memory: '<S126>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_l = ((uint8)0U);

        /* InitializeConditions for Memory: '<S138>/Memory' */
        LKAS_DW.Memory_PreviousInput_av = ((uint16)0U);

        /* InitializeConditions for Memory: '<S140>/Memory' */
        LKAS_DW.Memory_PreviousInput_nj = ((uint16)0U);

        /* InitializeConditions for Memory: '<S135>/Memory' */
        LKAS_DW.Memory_PreviousInput_p1 = ((uint16)0U);

        /* InitializeConditions for Memory: '<S123>/Memory' */
        LKAS_DW.Memory_PreviousInput_i3d = 0.0F;

        /* InitializeConditions for Memory: '<S109>/Memory' */
        LKAS_DW.Memory_PreviousInput_kz = 0.0F;

        /* InitializeConditions for Memory: '<S110>/Memory' */
        LKAS_DW.Memory_PreviousInput_mo = 0.0F;

        /* InitializeConditions for UnitDelay: '<S112>/Delay Input1'
         *
         * Block description for '<S112>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_px = false;

        /* InitializeConditions for Memory: '<S110>/Memory1' */
        LKAS_DW.Memory1_PreviousInput_k = false;

        /* InitializeConditions for Memory: '<S107>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e = 0.0F;

        /* InitializeConditions for Memory: '<S202>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_p = 0.0F;

        /* InitializeConditions for Memory: '<S185>/Memory' */
        LKAS_DW.Memory_PreviousInput_g = 0.0F;

        /* InitializeConditions for UnitDelay: '<S183>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_a = 0.0F;

        /* InitializeConditions for Memory: '<S191>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_m = 0.0F;

        /* InitializeConditions for Memory: '<S197>/Memory' */
        LKAS_DW.Memory_PreviousInput_f4 = ((uint16)0U);

        /* InitializeConditions for UnitDelay: '<S201>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

        /* InitializeConditions for Memory: '<S201>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_b = 0.0F;

        /* InitializeConditions for UnitDelay: '<S178>/Delay Input2'
         *
         * Block description for '<S178>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_b = 0.0F;

        /* InitializeConditions for Memory: '<S178>/Memory' */
        LKAS_DW.Memory_PreviousInput_e = ((uint16)0U);

        /* InitializeConditions for Memory: '<S134>/Memory' */
        LKAS_DW.Memory_PreviousInput_b = ((uint16)0U);

        /* InitializeConditions for Memory: '<S136>/Memory' */
        LKAS_DW.Memory_PreviousInput_l = ((uint16)0U);

        /* InitializeConditions for Memory: '<S137>/Memory' */
        LKAS_DW.Memory_PreviousInput_oj = ((uint16)0U);

        /* SystemReset for Atomic SubSystem: '<S98>/Moving Standard Deviation2' */
        MovingStandardDeviation2_Reset(&LKAS_DW.MovingStandardDeviation2);

        /* End of SystemReset for SubSystem: '<S98>/Moving Standard Deviation2' */

        /* SystemReset for Atomic SubSystem: '<S110>/Moving Standard Deviation1' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation1);

        /* End of SystemReset for SubSystem: '<S110>/Moving Standard Deviation1' */

        /* SystemReset for Atomic SubSystem: '<S110>/Moving Standard Deviation2' */
        MovingStandardDeviation1_Reset(&LKAS_DW.MovingStandardDeviation2_d);

        /* End of SystemReset for SubSystem: '<S110>/Moving Standard Deviation2' */
        LKAS_DW.LKA_MODE = true;
      }

      /* Memory: '<S108>/Memory' */
      rtb_Divide3_j = LKAS_DW.Memory_PreviousInput_ok;

      /* Sum: '<S108>/Add2' */
      rtb_Divide3_j += rtb_LKA_SampleTime;

      /* Saturate: '<S108>/Saturation2' */
      if (rtb_Divide3_j > 20.0F) {
        rtb_Saturation2_g = 20.0F;
      } else if (rtb_Divide3_j < 0.0F) {
        rtb_Saturation2_g = 0.0F;
      } else {
        rtb_Saturation2_g = rtb_Divide3_j;
      }

      /* End of Saturate: '<S108>/Saturation2' */

      /* Abs: '<S108>/Abs' */
      rtb_Divide3_j = rtb_TTLC_n;

      /* Saturate: '<S108>/Saturation' */
      if (rtb_Divide3_j > 0.004F) {
        rtb_Divide3_j = 0.004F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S108>/Saturation' */

      /* RelationalOperator: '<S108>/Relational Operator4' incorporates:
       *  Constant: '<S108>/Constant'
       *  Constant: '<S108>/Constant1'
       *  Product: '<S108>/Divide'
       *  Sum: '<S108>/Add'
       */
      rtb_BCM_Right_Light = (rtb_Saturation2_g >=
        ((((rtb_LL_LKAExPrcs_tiExitTime1 * 0.5F) * rtb_Divide3_j) / 0.004F) +
         rtb_LL_LKAExPrcs_tiExitTime1));

      /* Abs: '<S109>/Abs' */
      rtb_Divide3_j = rtb_TTLC_n;

      /* Saturate: '<S109>/Saturation' */
      if (rtb_Divide3_j > 0.004F) {
        rtb_Divide3_j = 0.004F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S109>/Saturation' */

      /* Product: '<S109>/Divide' incorporates:
       *  Constant: '<S109>/Constant'
       *  Constant: '<S109>/Constant1'
       */
      rtb_LL_DvtSpdDet_vDvtSpdMin_C = ((rtb_LL_LKAExPrcs_tiExitTime2 * 0.5F) *
        rtb_Divide3_j) / 0.004F;

      /* Sum: '<S139>/Add' incorporates:
       *  Constant: '<S139>/Constant'
       *  Memory: '<S139>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_mx));

      /* Saturate: '<S139>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_f = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_f = ((uint16)10000U);
      }

      /* End of Saturate: '<S139>/Saturation1' */

      /* Gain: '<S184>/kph to mps' */
      rtb_Divide3_j = rtb_Abs_f_tmp;

      /* Saturate: '<S184>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        x10 = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        x10 = 60.0F;
      } else {
        x10 = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S184>/Saturation3' */

      /* Product: '<S184>/Divide2' incorporates:
       *  Constant: '<S184>/Constant'
       */
      rtb_LftTTLC = 0.09F / x10;

      /* Switch: '<S557>/Switch36' incorporates:
       *  Constant: '<S557>/LL_LFClb_TFC_FfCtlRatio_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion18_p != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion18_p;
      } else {
        x10 = LL_LFClb_TFC_FfCtlRatio_C;
      }

      /* End of Switch: '<S557>/Switch36' */

      /* Saturate: '<S184>/Saturation1' */
      if (rtb_LftTTLC > 0.01F) {
        rtb_LftTTLC = 0.01F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S184>/Saturation1' */

      /* Gain: '<S184>/Gain2' incorporates:
       *  Constant: '<S184>/Constant1'
       *  Gain: '<S184>/rad to deg'
       *  Gain: '<S229>/Gain1'
       *  Math: '<S184>/Math Function'
       *  Product: '<S184>/Divide'
       *  Product: '<S184>/Divide1'
       *  Product: '<S184>/Product'
       *  Product: '<S184>/Product1'
       *  Product: '<S184>/Product2'
       *  Product: '<S184>/Product3'
       *  Sum: '<S184>/Add'
       *
       * About '<S184>/Math Function':
       *  Operator: magnitude^2
       */
      rtb_LL_LKAExPrcs_tiExitTime1 = (((((((rtb_Divide3_j * rtb_Divide3_j) *
        rtb_LftTTLC) + 1.0F) / (rtb_Divide3_j / LKAS_DW.LKA_WhlBaseL_C_m)) *
        ((rtb_Divide3_j * rtb_LL_ThresDet_tiTTLCThresLDW) * 57.2957802F)) * x10)
        * LKAS_DW.LKA_StrRatio_C_d) * (-1.0F);

      /* Sum: '<S122>/Add1' */
      rtb_Add1_i = (rtb_R0_C2 - rtb_LL_LKAExPrcs_tiExitTime1) -
        LKAS_DW.Saturation_h;

      /* If: '<S139>/If' incorporates:
       *  Constant: '<S139>/Constant2'
       */
      if (rtb_Saturation1_f == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S139>/if action ' incorporates:
         *  ActionPort: '<S162>/Action Port'
         */
        LKAS_ifaction(rtb_Add1_i, &LKAS_DW.In_n);

        /* End of Outputs for SubSystem: '<S139>/if action ' */
      }

      /* End of If: '<S139>/If' */

      /* Sum: '<S126>/Add' incorporates:
       *  Constant: '<S126>/Constant'
       *  Memory: '<S126>/Memory1'
       */
      rtb_IMAPve_d_SAS_Trim_State = (uint8)(((uint32)((uint8)1U)) + ((uint32)
        LKAS_DW.Memory1_PreviousInput_l));

      /* Saturate: '<S126>/Saturation1' */
      if (rtb_IMAPve_d_SAS_Trim_State < ((uint8)5U)) {
        rtb_Saturation1_cv = rtb_IMAPve_d_SAS_Trim_State;
      } else {
        rtb_Saturation1_cv = ((uint8)5U);
      }

      /* End of Saturate: '<S126>/Saturation1' */

      /* Saturate: '<S122>/Saturation3' */
      if (rtb_IMAPve_g_ESC_VehSpd > 150.0F) {
        rtb_Divide3_j = 150.0F;
      } else if (rtb_IMAPve_g_ESC_VehSpd < 60.0F) {
        rtb_Divide3_j = 60.0F;
      } else {
        rtb_Divide3_j = rtb_IMAPve_g_ESC_VehSpd;
      }

      /* End of Saturate: '<S122>/Saturation3' */

      /* Product: '<S122>/Divide1' incorporates:
       *  Constant: '<S122>/Constant'
       */
      rtb_Divide3_j = 0.09F / rtb_Divide3_j;

      /* Saturate: '<S122>/Saturation1' */
      if (rtb_Divide3_j > 0.0117F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.0117F;
      } else if (rtb_Divide3_j < 0.00237F) {
        LKAS_DW.MPInP_StbFacm_SY = 0.00237F;
      } else {
        LKAS_DW.MPInP_StbFacm_SY = rtb_Divide3_j;
      }

      /* End of Saturate: '<S122>/Saturation1' */

      /* Gain: '<S122>/Gain' */
      LKAS_DW.MPInP_dphiSWARMax = 1.0F * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Sum: '<S138>/Add' incorporates:
       *  Constant: '<S138>/Constant'
       *  Memory: '<S138>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_av));

      /* Saturate: '<S138>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_a = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_a = ((uint16)10000U);
      }

      /* End of Saturate: '<S138>/Saturation1' */

      /* If: '<S129>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S129>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S143>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_LFTTTLC, &rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S129>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S129>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S142>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_RGTTTLC, &rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S129>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S129>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S144>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_c);

        /* End of Outputs for SubSystem: '<S129>/If Action Subsystem3' */
      }

      /* End of If: '<S129>/If' */

      /* If: '<S138>/If' incorporates:
       *  Constant: '<S138>/Constant2'
       */
      if (rtb_Saturation1_a == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S138>/if action ' incorporates:
         *  ActionPort: '<S161>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_c, &LKAS_DW.In_l);

        /* End of Outputs for SubSystem: '<S138>/if action ' */
      }

      /* End of If: '<S138>/If' */

      /* Saturate: '<S122>/Saturation2' */
      if (LKAS_DW.In_l > 2.0F) {
        LKAS_DW.MPInP_tiTTLCIni = 2.0F;
      } else if (LKAS_DW.In_l < 0.6F) {
        LKAS_DW.MPInP_tiTTLCIni = 0.6F;
      } else {
        LKAS_DW.MPInP_tiTTLCIni = LKAS_DW.In_l;
      }

      /* End of Saturate: '<S122>/Saturation2' */

      /* Sum: '<S140>/Add' incorporates:
       *  Constant: '<S140>/Constant'
       *  Memory: '<S140>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_nj));

      /* Saturate: '<S140>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_b = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S140>/Saturation1' */

      /* If: '<S140>/If' incorporates:
       *  Constant: '<S140>/Constant2'
       */
      if (rtb_Saturation1_b == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S140>/if action ' incorporates:
         *  ActionPort: '<S163>/Action Port'
         */
        LKAS_ifaction(rtb_IMAPve_g_ESC_VehSpd, &LKAS_DW.In_c);

        /* End of Outputs for SubSystem: '<S140>/if action ' */
      }

      /* End of If: '<S140>/If' */

      /* Sum: '<S135>/Add' incorporates:
       *  Constant: '<S135>/Constant'
       *  Memory: '<S135>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_p1));

      /* Saturate: '<S135>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_k = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_k = ((uint16)10000U);
      }

      /* End of Saturate: '<S135>/Saturation1' */

      /* Product: '<S253>/Z*Z' incorporates:
       *  Product: '<S250>/Z*Z'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_Divide_ca * rtb_Divide_ca;

      /* Gain: '<S253>/Gain1' incorporates:
       *  Gain: '<S252>/Gain1'
       *  Gain: '<S254>/Gain1'
       */
      rtb_L0_C3_dc *= 3.0F;

      /* Gain: '<S250>/Gain1' incorporates:
       *  Gain: '<S249>/Gain1'
       *  Gain: '<S251>/Gain1'
       */
      rtb_L0_C3 *= 3.0F;

      /* Gain: '<S130>/Gain' incorporates:
       *  Gain: '<S250>/Gain1'
       *  Gain: '<S253>/Gain1'
       *  Product: '<S250>/Product3'
       *  Product: '<S250>/Product4'
       *  Product: '<S253>/Product3'
       *  Product: '<S253>/Product4'
       *  Product: '<S253>/Z*Z'
       *  Sum: '<S130>/Add'
       *  Sum: '<S250>/Add'
       *  Sum: '<S253>/Add'
       */
      rtb_Gain_iu = ((((rtb_Add_p_tmp * rtb_Divide_ca) + rtb_L0_C1_m) +
                      (rtb_L0_C3_dc * rtb_LL_TkOvStChk_tiTDelTime)) +
                     (((rtb_Add_o_tmp * rtb_Divide_ca) + rtb_L0_C1_i) +
                      (rtb_L0_C3 * rtb_LL_TkOvStChk_tiTDelTime))) * 0.5F;

      /* Product: '<S254>/Z*Z' incorporates:
       *  Product: '<S251>/Z*Z'
       */
      rtb_LL_TkOvStChk_tiTDelTime = rtb_Divide_dv * rtb_Divide_dv;

      /* Gain: '<S130>/Gain1' incorporates:
       *  Product: '<S251>/Product3'
       *  Product: '<S251>/Product4'
       *  Product: '<S254>/Product3'
       *  Product: '<S254>/Product4'
       *  Product: '<S254>/Z*Z'
       *  Sum: '<S130>/Add1'
       *  Sum: '<S251>/Add'
       *  Sum: '<S254>/Add'
       */
      rtb_Gain1_p = ((((rtb_Add_p_tmp * rtb_Divide_dv) + rtb_L0_C1_m) +
                      (rtb_L0_C3_dc * rtb_LL_TkOvStChk_tiTDelTime)) +
                     (((rtb_Add_o_tmp * rtb_Divide_dv) + rtb_L0_C1_i) +
                      (rtb_L0_C3 * rtb_LL_TkOvStChk_tiTDelTime))) * 0.5F;

      /* If: '<S130>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S130>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S146>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Gain_iu, &rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S130>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S130>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S145>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Gain1_p, &rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S130>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S130>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S147>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Divide3_j);

        /* End of Outputs for SubSystem: '<S130>/If Action Subsystem3' */
      }

      /* End of If: '<S130>/If' */

      /* If: '<S132>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S132>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S152>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Divide_ca, &rtb_Gain2_bi);

        /* End of Outputs for SubSystem: '<S132>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S132>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S151>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Divide_dv, &rtb_Gain2_bi);

        /* End of Outputs for SubSystem: '<S132>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S132>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S153>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Gain2_bi);

        /* End of Outputs for SubSystem: '<S132>/If Action Subsystem3' */
      }

      /* End of If: '<S132>/If' */

      /* Sum: '<S122>/Add' incorporates:
       *  Gain: '<S229>/Gain1'
       *  Product: '<S122>/Divide2'
       */
      rtb_Add_id = rtb_Divide3_j - (rtb_LL_ThresDet_tiTTLCThresLDW *
        rtb_Gain2_bi);

      /* If: '<S135>/If' incorporates:
       *  Constant: '<S135>/Constant2'
       */
      if (rtb_Saturation1_k == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S135>/if action ' incorporates:
         *  ActionPort: '<S158>/Action Port'
         */
        LKAS_ifaction(rtb_Add_id, &LKAS_DW.In_ir);

        /* End of Outputs for SubSystem: '<S135>/if action ' */
      }

      /* End of If: '<S135>/If' */

      /* If: '<S141>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S141>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S165>/Action Port'
         */
        /* SignalConversion: '<S165>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S165>/Constant'
         */
        LKAS_DW.Merge = (-1.0F);

        /* End of Outputs for SubSystem: '<S141>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S141>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S164>/Action Port'
         */
        /* SignalConversion: '<S164>/OutportBuffer_InsertedFor_Out1_at_inport_0' incorporates:
         *  Constant: '<S164>/Constant'
         */
        LKAS_DW.Merge = 1.0F;

        /* End of Outputs for SubSystem: '<S141>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S141>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S166>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge);

        /* End of Outputs for SubSystem: '<S141>/If Action Subsystem3' */
      }

      /* End of If: '<S141>/If' */

      /* If: '<S126>/If' incorporates:
       *  Constant: '<S126>/Constant19'
       */
      rtAction = -1;
      if (rtb_Saturation1_cv == ((uint8)1U)) {
        rtAction = 0;
      }

      LKAS_DW.If_ActiveSubsystem = rtAction;
      if (rtAction == 0) {
        /* Outputs for IfAction SubSystem: '<S91>/LKA Motion Planning Calculation (LKAMPCal)' incorporates:
         *  ActionPort: '<S121>/Action Port'
         *
         * Block description for '<S91>/LKA Motion Planning Calculation (LKAMPCal)':
         *  Block Name: LKA Motion Planning Calculation
         *  Ab.: LKAMPCal
         *  No.: 1.2.3.2
         *  Rev: 0.0.1
         *  Update Date: 19-3-26
         */
        LKAMotionPlanningCalculationLKA();

        /* End of Outputs for SubSystem: '<S91>/LKA Motion Planning Calculation (LKAMPCal)' */
      }

      /* End of If: '<S126>/If' */

      /* Memory: '<S123>/Memory' */
      rtb_Gain2_bi = LKAS_DW.Memory_PreviousInput_i3d;

      /* Sum: '<S123>/Add' incorporates:
       *  Gain: '<S123>/Gain1'
       *  Product: '<S123>/Divide'
       *  Product: '<S123>/Product'
       */
      rtb_Add_l = ((rtb_Abs_f_tmp * rtb_LKA_SampleTime) / (0.277777791F *
        LKAS_DW.In_c)) + rtb_Gain2_bi;

      /* MATLAB Function: '<S124>/SWACmd' */
      /*  ************************************************************************* */
      /*  �������� */
      /*    SWACmd_phi1PhSWAIni : һ��ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi1PhSWAGrad : һ��ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_phi2PhSWAIni : ����ת����ת�ǳ�ʼֵ����λ��deg */
      /*    SWACmd_dphi2PhSWAGrad : ����ת����ת�Ǳ仯�ʣ���λ��deg/s */
      /*    SWACmd_vVehSpdIni : ����һ���ĳ��ٳ�ʼֵ����λ��Km/h */
      /*    SWACmd_tiNomT : ����ʱ�䣬��λ��s */
      /*  */
      /*  ������� */
      /*    SWACmd_phiSWACmd : ת����ת��ָ��ֵ����λ��deg */
      /*    */
      /* ************************************************************************** */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/LKA Motion Planning (LKAMP) /Steering Wheel Angle Command Calculation  (SWACmdCal)/SWACmd': '<S167>:1' */
      /* '<S167>:1:19' DelteSW0 = SWACmd_phi1PhSWAIni; */
      /* '<S167>:1:20' DelteSW1 = SWACmd_phi2PhSWAIni; */
      /* '<S167>:1:21' Delte1PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S167>:1:22' Delte2PhSWGrad = SWACmd_dphi1PhSWAGrad; */
      /* '<S167>:1:23' DelteSWCmd = single(0); */
      rtb_SWACmd_phiSWACmd = 0.0F;

      /* '<S167>:1:24' NomT = SWACmd_tiNomT; */
      /* '<S167>:1:25' T1 = K1K2Det_T1; */
      /* '<S167>:1:26' T2 = T1; */
      /* ************************************************************************** */
      /* ��֪�� һ��ת����ת�ǳ�ʼֵ�� һ��ת����ת�Ǳ仯�ʣ� ����ת����ת�ǳ�ʼֵ,  */
      /*        ����ת����ת�Ǳ仯��, ����һ���ĳ��ٳ�ʼֵ, ��ʻ·�����ȡ� */
      /* ���ݳ��ٳ�ʼֵ����ʻ·�����ȣ����Լ��������ʱ�䣨NomT����Ȼ����������ʱ��� */
      /* �������˶����ߣ����ת����ת��ָ��ֵ�� */
      /*  */
      /* **************************************************************************                                 */
      /* '<S167>:1:34' if(NomT < T1 && NomT >= 0 ) */
      if ((rtb_Add_l < LKAS_DW.K1K2Det_T1) && (rtb_Add_l >= 0.0F)) {
        /* '<S167>:1:35' DelteSWCmd = DelteSW0+Delte1PhSWGrad*NomT; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad * rtb_Add_l) +
          LKAS_DW.In_n;
      } else if ((rtb_Add_l <= LKAS_DW.K1K2Det_T1) && (rtb_Add_l >=
                  LKAS_DW.K1K2Det_T1)) {
        /* '<S167>:1:36' elseif(NomT <= T2 && NomT >= T1 ) */
        /*     DelteSWCmd = DelteSW1+Delte2PhSWGrad*(NomT-T1); */
        /* '<S167>:1:38' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
        rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
          LKAS_DW.K1K2Det_T1) + LKAS_DW.In_n;

        /*     DelteSWCmd = single(0); */
      } else {
        if (rtb_Add_l >= LKAS_DW.K1K2Det_T1) {
          /* '<S167>:1:40' elseif(NomT >= T2) */
          /* '<S167>:1:41' DelteSWCmd = DelteSW0+Delte1PhSWGrad*T1; */
          rtb_SWACmd_phiSWACmd = (LKAS_DW.K1K2Det_dphi1PhSWAGrad *
            LKAS_DW.K1K2Det_T1) + LKAS_DW.In_n;

          /*    DelteSWCmd = single(0); */
        }
      }

      /* Saturate: '<S91>/Saturation6' incorporates:
       *  MATLAB Function: '<S124>/SWACmd'
       */
      /*  */
      /* ************************************************************************** */
      /*  ����� */
      /* '<S167>:1:47' SWACmd_phiSWACmd = DelteSWCmd; */
      if (LKAS_DW.K1K2Det_T1 > 2.0F) {
        rtb_Saturation6 = 2.0F;
      } else if (LKAS_DW.K1K2Det_T1 < 0.2F) {
        rtb_Saturation6 = 0.2F;
      } else {
        rtb_Saturation6 = LKAS_DW.K1K2Det_T1;
      }

      /* End of Saturate: '<S91>/Saturation6' */

      /* Memory: '<S109>/Memory' */
      rtb_Gain2_bi = LKAS_DW.Memory_PreviousInput_kz;

      /* Sum: '<S109>/Add2' */
      rtb_Gain2_bi += rtb_LKA_SampleTime;

      /* Saturate: '<S109>/Saturation2' */
      if (rtb_Gain2_bi > 12.0F) {
        rtb_Saturation2_l = 12.0F;
      } else if (rtb_Gain2_bi < 0.0F) {
        rtb_Saturation2_l = 0.0F;
      } else {
        rtb_Saturation2_l = rtb_Gain2_bi;
      }

      /* End of Saturate: '<S109>/Saturation2' */

      /* Abs: '<S109>/Abs2' */
      rtb_Gain2_bi = fabsf(rtb_Gain1_j);

      /* Sum: '<S109>/Add3' incorporates:
       *  Sum: '<S110>/Add'
       *  Sum: '<S169>/Add'
       *  Sum: '<S190>/Add6'
       */
      rtb_LL_ThresDet_lDvtThresUprLKA = rtb_LaneWidth - rtb_LKA_CarWidth;

      /* Gain: '<S109>/Gain' incorporates:
       *  Sum: '<S109>/Add3'
       */
      rtb_Divide3_j = rtb_LL_ThresDet_lDvtThresUprLKA * 0.166666672F;

      /* RelationalOperator: '<S109>/Relational Operator2' */
      rtb_LogicalOperator3_b5 = (rtb_Gain2_bi >= rtb_Divide3_j);

      /* Abs: '<S109>/Abs3' */
      rtb_Gain2_bi = fabsf(rtb_Add5_n);

      /* Outputs for Enabled SubSystem: '<S109>/Sum Condition1' incorporates:
       *  EnablePort: '<S111>/Enable'
       */
      /* Logic: '<S109>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S109>/Relational Operator3'
       *  RelationalOperator: '<S109>/Relational Operator4'
       */
      if (((rtb_Saturation2_l >= rtb_Saturation6) && rtb_LogicalOperator3_b5) &&
          (rtb_Gain2_bi >= rtb_Divide3_j)) {
        if (!LKAS_DW.SumCondition1_MODE_h) {
          /* InitializeConditions for Memory: '<S111>/Memory' */
          LKAS_DW.Memory_PreviousInput_n0 = 0.0F;
          LKAS_DW.SumCondition1_MODE_h = true;
        }

        /* Sum: '<S111>/Add1' incorporates:
         *  Memory: '<S111>/Memory'
         */
        rtb_Abs_pw = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_n0;

        /* Saturate: '<S111>/Saturation' */
        if (rtb_Abs_pw > 10.0F) {
          rtb_Abs_pw = 10.0F;
        } else {
          if (rtb_Abs_pw < 0.0F) {
            rtb_Abs_pw = 0.0F;
          }
        }

        /* End of Saturate: '<S111>/Saturation' */

        /* RelationalOperator: '<S111>/Relational Operator' incorporates:
         *  Sum: '<S109>/Add1'
         */
        LKAS_DW.RelationalOperator_ew = (rtb_Abs_pw >=
          (rtb_LL_LKAExPrcs_tiExitTime2 + rtb_LL_DvtSpdDet_vDvtSpdMin_C));

        /* Update for Memory: '<S111>/Memory' */
        LKAS_DW.Memory_PreviousInput_n0 = rtb_Abs_pw;
      } else {
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S111>/Out' */
          LKAS_DW.RelationalOperator_ew = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }
      }

      /* End of Logic: '<S109>/Logical Operator1' */
      /* End of Outputs for SubSystem: '<S109>/Sum Condition1' */

      /* Memory: '<S110>/Memory' */
      rtb_Gain2_bi = LKAS_DW.Memory_PreviousInput_mo;

      /* Sum: '<S110>/Add2' */
      rtb_Gain2_bi += rtb_LKA_SampleTime;

      /* Saturate: '<S110>/Saturation2' */
      if (rtb_Gain2_bi > 10.0F) {
        rtb_Saturation2_n = 10.0F;
      } else if (rtb_Gain2_bi < 0.0F) {
        rtb_Saturation2_n = 0.0F;
      } else {
        rtb_Saturation2_n = rtb_Gain2_bi;
      }

      /* End of Saturate: '<S110>/Saturation2' */

      /* Gain: '<S110>/Gain' */
      rtb_Gain2_bi = rtb_LL_ThresDet_lDvtThresUprLKA * 0.333333343F;

      /* Logic: '<S110>/Logical Operator1' incorporates:
       *  RelationalOperator: '<S110>/Relational Operator2'
       *  RelationalOperator: '<S110>/Relational Operator3'
       *  RelationalOperator: '<S110>/Relational Operator4'
       */
      rtb_LogicalOperator3_b5 = (((rtb_Saturation2_n >= rtb_Saturation6) &&
        (rtb_Gain1_j >= rtb_Gain2_bi)) && (rtb_Add5_n >= rtb_Gain2_bi));

      /* Abs: '<S110>/Abs4' */
      rtb_Gain2_bi = rtb_TTLC_n;

      /* Saturate: '<S110>/Saturation' */
      if (rtb_Gain2_bi > 0.004F) {
        rtb_Gain2_bi = 0.004F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S110>/Saturation' */

      /* Switch: '<S557>/Switch45' incorporates:
       *  Constant: '<S557>/LL_LKAExPrcs_tiExitTime3=0.2'
       */
      if (LKAS_ConstB.DataTypeConversion34 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion34;
      } else {
        x10 = LL_LKAExPrcs_tiExitTime3;
      }

      /* End of Switch: '<S557>/Switch45' */

      /* Sum: '<S110>/Add6' incorporates:
       *  Constant: '<S110>/Constant'
       *  Constant: '<S110>/Constant7'
       *  Product: '<S110>/Divide1'
       */
      rtb_Add6 = ((2.0F * rtb_Gain2_bi) / 0.004F) + x10;

      /* Outputs for Enabled SubSystem: '<S89>/Subsystem' incorporates:
       *  EnablePort: '<S97>/Enable'
       */
      /* RelationalOperator: '<S96>/Compare' incorporates:
       *  Constant: '<S557>/LL_LKASWASyn_TrqSwaAddSwt=1'
       *  Constant: '<S96>/Constant'
       *  Switch: '<S557>/Switch47'
       */
      if (((sint32)(((LKAS_ConstB.DataTypeConversion47_j) ||
                     (LL_LKASWASyn_TrqSwaAddSwt)) ? 1 : 0)) > ((sint32)(false ?
            1 : 0))) {
        if (!LKAS_DW.Subsystem_MODE_l) {
          LKAS_DW.Subsystem_MODE_l = true;
        }

        /* MATLAB Function: '<S97>/DriverSwaTrqAdd' */
        /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem/DriverSwaTrqAdd': '<S99>:1' */
        /* '<S99>:1:2' Swaadd=single(0); */
        /* '<S99>:1:3' spd=max(min(spd,single(120)),single(60)); */
        /* �����복�ٽ���������60~120km/h */
        /* '<S99>:1:4' swaaddmax=(single(180)-spd)/single(120)*swaaddmax; */
        /* ���ݵ�ǰ�������Ʒ����̵������ֵ=(1~0.5)*spdaddmax */
        /* '<S99>:1:5' l0c0=abs(l0c0); */
        /* '<S99>:1:6' r0c0=abs(r0c0); */
        /* '<S99>:1:7' lanewidth=max(min(l0c0+r0c0,single(5.4)),single(2.5)); */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = fmaxf(fminf(rtb_LKA_Veh2CamW_C +
          rtb_Add5_n_tmp, 5.4F), 2.5F);

        /* '<S99>:1:8' if lanewidth>single(2.5) && lanewidth<single(5.4) */
        if ((rtb_LL_DvtSpdDet_vDvtSpdMin_C > 2.5F) &&
            (rtb_LL_DvtSpdDet_vDvtSpdMin_C < 5.4F)) {
          /* '<S99>:1:9' leftlane=l0c0/lanewidth; */
          rtb_Abs_pw = rtb_LKA_Veh2CamW_C / rtb_LL_DvtSpdDet_vDvtSpdMin_C;

          /* '<S99>:1:10' rightlane=r0c0/lanewidth; */
          rtb_LL_LKAExPrcs_tiExitTime2 = rtb_Add5_n_tmp /
            rtb_LL_DvtSpdDet_vDvtSpdMin_C;
        } else {
          /* '<S99>:1:11' else */
          /* '<S99>:1:12' leftlane=single(0.5); */
          rtb_Abs_pw = 0.5F;

          /* '<S99>:1:13' rightlane=single(0.5); */
          rtb_LL_LKAExPrcs_tiExitTime2 = 0.5F;
        }

        /* '<S99>:1:15' leftswamax=single(2)*swaaddmax*leftlane; */
        /* '<S99>:1:16' rightswamax=single(2)*swaaddmax*rightlane; */
        /* '<S99>:1:17' if trq>=0 */
        if (rtb_IMAPve_g_EPS_SW_Trq >= 0.0F) {
          /* Switch: '<S557>/Switch42' incorporates:
           *  Constant: '<S557>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S99>:1:18' Swaadd=trq/trqmax*leftswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S557>/Switch43' incorporates:
           *  Constant: '<S557>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKAExPrcs_tiExitTime2 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_Abs_pw) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        } else {
          /* Switch: '<S557>/Switch42' incorporates:
           *  Constant: '<S557>/LL_LKASWASyn_TrqMax=1.5'
           */
          /* '<S99>:1:19' else */
          /* '<S99>:1:20' Swaadd=trq/trqmax*rightswamax; */
          if (LKAS_ConstB.DataTypeConversion31 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion31;
          } else {
            x10 = LL_LKASWASyn_TrqMax;
          }

          /* Switch: '<S557>/Switch43' incorporates:
           *  Constant: '<S557>/LL_LKASWASyn_SWAaddMax=8'
           */
          if (LKAS_ConstB.DataTypeConversion32 != 0.0F) {
            x20 = LKAS_ConstB.DataTypeConversion32;
          } else {
            x20 = LL_LKASWASyn_SWAaddMax;
          }

          rtb_LL_LKAExPrcs_tiExitTime2 = (((((180.0F - fmaxf(fminf
            (rtb_IMAPve_g_ESC_VehSpd, 120.0F), 60.0F)) / 120.0F) * x20) * 2.0F) *
            rtb_LL_LKAExPrcs_tiExitTime2) * (rtb_IMAPve_g_EPS_SW_Trq / x10);
        }

        /* Sum: '<S100>/Add2' incorporates:
         *  Constant: '<S100>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S100>/Memory3'
         */
        rtb_LL_DvtSpdDet_vDvtSpdMin_C = 1.0F + LKAS_DW.Memory3_PreviousInput_a;

        /* Saturate: '<S100>/Saturation' */
        if (rtb_LL_DvtSpdDet_vDvtSpdMin_C > 50.0F) {
          rtb_LL_DvtSpdDet_vDvtSpdMin_C = 50.0F;
        } else {
          if (rtb_LL_DvtSpdDet_vDvtSpdMin_C < 0.0F) {
            rtb_LL_DvtSpdDet_vDvtSpdMin_C = 0.0F;
          }
        }

        /* End of Saturate: '<S100>/Saturation' */

        /* Switch: '<S100>/Switch' incorporates:
         *  Product: '<S100>/Divide'
         *  Product: '<S100>/Divide1'
         *  Sum: '<S100>/Add'
         *  Sum: '<S100>/Add1'
         *  UnitDelay: '<S100>/Unit Delay'
         */
        if (rtb_LL_DvtSpdDet_vDvtSpdMin_C > 1.0F) {
          /* Switch: '<S557>/Switch50' incorporates:
           *  Constant: '<S557>/LL_LKASWASyn_tiTrqSwaTime=0.3'
           */
          if (LKAS_ConstB.DataTypeConversion50 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion50;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaTime;
          }

          /* End of Switch: '<S557>/Switch50' */
          rtb_LL_LKAExPrcs_tiExitTime2 = ((rtb_LKA_SampleTime / x10) *
            (rtb_LL_LKAExPrcs_tiExitTime2 - LKAS_DW.UnitDelay_DSTATE_n)) +
            LKAS_DW.UnitDelay_DSTATE_n;
        }

        /* End of Switch: '<S100>/Switch' */

        /* SampleTimeMath: '<S103>/TSamp'
         *
         * About '<S103>/TSamp':
         *  y = u * K where K = 1 / ( w * Ts )
         */
        rtb_Abs_pw = rtb_LL_LKAExPrcs_tiExitTime2 * 100.0F;

        /* Sum: '<S101>/Add2' incorporates:
         *  Constant: '<S101>/SWACmdSyn_tiSmplT_C4'
         *  Memory: '<S101>/Memory3'
         */
        rtb_Abs_a = 1.0F + LKAS_DW.Memory3_PreviousInput_e4;

        /* Saturate: '<S101>/Saturation' */
        if (rtb_Abs_a > 50.0F) {
          rtb_Abs_a = 50.0F;
        } else {
          if (rtb_Abs_a < 0.0F) {
            rtb_Abs_a = 0.0F;
          }
        }

        /* End of Saturate: '<S101>/Saturation' */

        /* Switch: '<S101>/Switch' incorporates:
         *  Product: '<S101>/Divide'
         *  Product: '<S101>/Divide1'
         *  Sum: '<S101>/Add'
         *  Sum: '<S101>/Add1'
         *  Sum: '<S103>/Diff'
         *  UnitDelay: '<S101>/Unit Delay'
         *  UnitDelay: '<S103>/UD'
         *
         * Block description for '<S103>/Diff':
         *
         *  Add in CPU
         *
         * Block description for '<S103>/UD':
         *
         *  Store in Global RAM
         */
        if (rtb_Abs_a > 2.0F) {
          /* Switch: '<S557>/Switch52' incorporates:
           *  Constant: '<S557>/LL_LKASWASyn_tiTrqSwaRtTime=0.2'
           */
          if (LKAS_ConstB.DataTypeConversion52 != 0.0F) {
            x10 = LKAS_ConstB.DataTypeConversion52;
          } else {
            x10 = LL_LKASWASyn_tiTrqSwaRtTime;
          }

          /* End of Switch: '<S557>/Switch52' */
          rtb_LL_TkOvStChk_tiTDelTime = (((rtb_Abs_pw - LKAS_DW.UD_DSTATE) -
            LKAS_DW.UnitDelay_DSTATE_nl) * (rtb_LKA_SampleTime / x10)) +
            LKAS_DW.UnitDelay_DSTATE_nl;
        } else {
          rtb_LL_TkOvStChk_tiTDelTime = rtb_Abs_pw - LKAS_DW.UD_DSTATE;
        }

        /* End of Switch: '<S101>/Switch' */

        /* Saturate: '<S97>/Saturation' */
        if (rtb_LL_TkOvStChk_tiTDelTime > 30.0F) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = 30.0F;
        } else if (rtb_LL_TkOvStChk_tiTDelTime < (-30.0F)) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = (-30.0F);
        } else {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LL_TkOvStChk_tiTDelTime;
        }

        /* End of Saturate: '<S97>/Saturation' */

        /* Switch: '<S557>/Switch53' incorporates:
         *  Constant: '<S557>/LL_LKASWASyn_TrqSwaRateDiff=-0.2'
         */
        if (LKAS_ConstB.DataTypeConversion53 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion53;
        } else {
          x10 = LL_LKASWASyn_TrqSwaRateDiff;
        }

        /* End of Switch: '<S557>/Switch53' */

        /* Sum: '<S102>/Difference Inputs1' incorporates:
         *  Product: '<S97>/Divide1'
         *  Product: '<S97>/Divide3'
         *  Sum: '<S97>/Add'
         *  UnitDelay: '<S102>/Delay Input2'
         *
         * Block description for '<S102>/Difference Inputs1':
         *
         *  Add in CPU
         *
         * Block description for '<S102>/Delay Input2':
         *
         *  Store in Global RAM
         */
        rtb_LL_MAX_DRIVER_TORQUE_DISABL = ((rtb_LL_MAX_DRIVER_TORQUE_DISABL *
          x10) + rtb_LL_LKAExPrcs_tiExitTime2) - LKAS_DW.DelayInput2_DSTATE_o;

        /* Product: '<S102>/delta rise limit' incorporates:
         *  Constant: '<S97>/Constant1'
         *  SampleTimeMath: '<S102>/sample time'
         *
         * About '<S102>/sample time':
         *  y = K where K = ( w * Ts )
         */
        x10 = 5.0F * 0.01F;

        /* Product: '<S102>/delta fall limit' incorporates:
         *  Constant: '<S97>/Constant2'
         *  SampleTimeMath: '<S102>/sample time'
         *
         * About '<S102>/sample time':
         *  y = K where K = ( w * Ts )
         */
        rtb_LL_LKAS_OUT_OF_CONTROL_LAT_ = (-5.0F) * 0.01F;

        /* Switch: '<S104>/Switch2' incorporates:
         *  Product: '<S102>/delta fall limit'
         *  Product: '<S102>/delta rise limit'
         *  RelationalOperator: '<S104>/LowerRelop1'
         *  RelationalOperator: '<S104>/UpperRelop'
         *  Switch: '<S104>/Switch'
         */
        if (rtb_LL_MAX_DRIVER_TORQUE_DISABL > x10) {
          rtb_LL_MAX_DRIVER_TORQUE_DISABL = x10;
        } else {
          if (rtb_LL_MAX_DRIVER_TORQUE_DISABL < rtb_LL_LKAS_OUT_OF_CONTROL_LAT_)
          {
            /* Switch: '<S104>/Switch' incorporates:
             *  Product: '<S102>/delta fall limit'
             */
            rtb_LL_MAX_DRIVER_TORQUE_DISABL = rtb_LL_LKAS_OUT_OF_CONTROL_LAT_;
          }
        }

        /* End of Switch: '<S104>/Switch2' */

        /* Sum: '<S102>/Difference Inputs2' incorporates:
         *  UnitDelay: '<S102>/Delay Input2'
         *
         * Block description for '<S102>/Difference Inputs2':
         *
         *  Add in CPU
         *
         * Block description for '<S102>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DifferenceInputs2_g = rtb_LL_MAX_DRIVER_TORQUE_DISABL +
          LKAS_DW.DelayInput2_DSTATE_o;

        /* Update for UnitDelay: '<S100>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_n = rtb_LL_LKAExPrcs_tiExitTime2;

        /* Update for Memory: '<S100>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_a = rtb_LL_DvtSpdDet_vDvtSpdMin_C;

        /* Update for UnitDelay: '<S103>/UD'
         *
         * Block description for '<S103>/UD':
         *
         *  Store in Global RAM
         */
        LKAS_DW.UD_DSTATE = rtb_Abs_pw;

        /* Update for UnitDelay: '<S101>/Unit Delay' */
        LKAS_DW.UnitDelay_DSTATE_nl = rtb_LL_TkOvStChk_tiTDelTime;

        /* Update for Memory: '<S101>/Memory3' */
        LKAS_DW.Memory3_PreviousInput_e4 = rtb_Abs_a;

        /* Update for UnitDelay: '<S102>/Delay Input2'
         *
         * Block description for '<S102>/Delay Input2':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput2_DSTATE_o = LKAS_DW.DifferenceInputs2_g;
      } else {
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S97>/Out1' */
          LKAS_DW.DifferenceInputs2_g = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }
      }

      /* End of RelationalOperator: '<S96>/Compare' */
      /* End of Outputs for SubSystem: '<S89>/Subsystem' */

      /* Outputs for Atomic SubSystem: '<S98>/Moving Standard Deviation2' */
      LKAS_MovingStandardDeviation2(rtb_IMAPve_g_EPS_SW_Trq, &rtb_kphTomps_j,
        &rtb_Merge_e, &LKAS_DW.MovingStandardDeviation2);

      /* End of Outputs for SubSystem: '<S98>/Moving Standard Deviation2' */

      /* Outputs for Atomic SubSystem: '<S110>/Moving Standard Deviation1' */
      rtb_Gain_m = (float32) LKAS_MovingStandardDeviation1(rtb_Add5_n,
        &LKAS_DW.MovingStandardDeviation1);

      /* End of Outputs for SubSystem: '<S110>/Moving Standard Deviation1' */

      /* RelationalOperator: '<S110>/Relational Operator6' */
      rtb_RelationalOperator6_i = (rtb_Gain_m <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S110>/Sum Condition1' */
      LKAS_SumCondition(rtb_RelationalOperator6_i, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_k3, &LKAS_DW.SumCondition1_j);

      /* End of Outputs for SubSystem: '<S110>/Sum Condition1' */

      /* Outputs for Atomic SubSystem: '<S110>/Moving Standard Deviation2' */
      rtb_Gain_m = (float32) LKAS_MovingStandardDeviation1(rtb_Gain1_j,
        &LKAS_DW.MovingStandardDeviation2_d);

      /* End of Outputs for SubSystem: '<S110>/Moving Standard Deviation2' */

      /* RelationalOperator: '<S110>/Relational Operator5' */
      rtb_RelationalOperator5 = (rtb_Gain_m <= rtb_LL_LKAExPrcs_ExitC0Dvt);

      /* Outputs for Enabled SubSystem: '<S110>/Sum Condition' */
      LKAS_SumCondition(rtb_RelationalOperator5, rtb_LKA_SampleTime, rtb_Add6,
                        &LKAS_DW.RelationalOperator_e, &LKAS_DW.SumCondition_c);

      /* End of Outputs for SubSystem: '<S110>/Sum Condition' */

      /* RelationalOperator: '<S120>/Compare' incorporates:
       *  Constant: '<S120>/Constant'
       *  Constant: '<S557>/LL_LKAExPrcs_ExitC0Swt=1'
       *  Logic: '<S110>/Logical Operator2'
       *  Switch: '<S557>/Switch46'
       */
      rtb_Compare_az = (((sint32)((((rtb_LogicalOperator3_b5 &&
        (LKAS_DW.RelationalOperator_k3)) && (LKAS_DW.RelationalOperator_e)) &&
        ((LKAS_ConstB.DataTypeConversion35) || (LL_LKAExPrcs_ExitC0Swt))) ? 1 :
        0)) > ((sint32)(false ? 1 : 0)));

      /* Memory: '<S110>/Memory1' */
      rtb_Memory1 = LKAS_DW.Memory1_PreviousInput_k;

      /* If: '<S110>/If' incorporates:
       *  Constant: '<S113>/Constant'
       *  RelationalOperator: '<S112>/FixPt Relational Operator'
       *  UnitDelay: '<S112>/Delay Input1'
       *
       * Block description for '<S112>/Delay Input1':
       *
       *  Store in Global RAM
       */
      if (((sint32)(rtb_Compare_az ? 1 : 0)) > ((sint32)
           (LKAS_DW.DelayInput1_DSTATE_px ? 1 : 0))) {
        /* Outputs for IfAction SubSystem: '<S110>/If Action Subsystem' incorporates:
         *  ActionPort: '<S113>/Action Port'
         */
        rtb_Merge_ba = true;

        /* End of Outputs for SubSystem: '<S110>/If Action Subsystem' */
      } else {
        /* Outputs for IfAction SubSystem: '<S110>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S114>/Action Port'
         */
        LKAS_IfActionSubsystem3(rtb_Memory1, &rtb_Merge_ba);

        /* End of Outputs for SubSystem: '<S110>/If Action Subsystem3' */
      }

      /* End of If: '<S110>/If' */

      /* Outputs for Enabled SubSystem: '<S110>/Sum Condition2' incorporates:
       *  EnablePort: '<S119>/state = reset'
       */
      if (rtb_Merge_ba) {
        if (!LKAS_DW.SumCondition2_MODE) {
          /* InitializeConditions for Memory: '<S119>/Memory' */
          LKAS_DW.Memory_PreviousInput_ik = 0.0F;
          LKAS_DW.SumCondition2_MODE = true;
        }

        /* Sum: '<S119>/Add1' incorporates:
         *  Memory: '<S119>/Memory'
         */
        rtb_LL_LKAExPrcs_ExitC0Dvt = rtb_LKA_SampleTime +
          LKAS_DW.Memory_PreviousInput_ik;

        /* Saturate: '<S119>/Saturation' */
        if (rtb_LL_LKAExPrcs_ExitC0Dvt > 10.0F) {
          rtb_LL_LKAExPrcs_ExitC0Dvt = 10.0F;
        } else {
          if (rtb_LL_LKAExPrcs_ExitC0Dvt < 0.0F) {
            rtb_LL_LKAExPrcs_ExitC0Dvt = 0.0F;
          }
        }

        /* End of Saturate: '<S119>/Saturation' */

        /* Switch: '<S557>/Switch25' incorporates:
         *  Constant: '<S557>/LL_LKAExPrcs_tiExitDelayTime3=0.5'
         */
        if (LKAS_ConstB.DataTypeConversion39 != 0.0F) {
          rtb_LogicalOperator3_b5 = (LKAS_ConstB.DataTypeConversion39 != 0.0F);
        } else {
          rtb_LogicalOperator3_b5 = (LL_LKAExPrcs_tiExitDelayTime3 != 0.0F);
        }

        /* End of Switch: '<S557>/Switch25' */

        /* RelationalOperator: '<S119>/Relational Operator' */
        LKAS_DW.RelationalOperator_h = (rtb_LL_LKAExPrcs_ExitC0Dvt >= ((float32)
          (rtb_LogicalOperator3_b5 ? 1.0F : 0.0F)));

        /* Update for Memory: '<S119>/Memory' */
        LKAS_DW.Memory_PreviousInput_ik = rtb_LL_LKAExPrcs_ExitC0Dvt;
      } else {
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S119>/Out' */
          LKAS_DW.RelationalOperator_h = false;
          LKAS_DW.SumCondition2_MODE = false;
        }
      }

      /* End of Outputs for SubSystem: '<S110>/Sum Condition2' */

      /* Fcn: '<S90>/Fcn' incorporates:
       *  DataTypeConversion: '<S90>/Cast To Single'
       */
      rtb_ExNum = (float32)((sint32)(((((LKAS_DW.RelationalOperator_h ? 1 : 0) *
        (LKAS_DW.RelationalOperator_h ? 1 : 0)) * ((sint32)3.0F)) + ((((sint32)
        ((!LKAS_DW.RelationalOperator_h) ? 1 : 0)) *
        (LKAS_DW.RelationalOperator_ew ? 1 : 0)) * ((sint32)2.0F))) + (((sint32)
        (((!LKAS_DW.RelationalOperator_ew) && (!LKAS_DW.RelationalOperator_h)) ?
         1 : 0)) * (rtb_BCM_Right_Light ? 1 : 0))));

      /* Logic: '<S90>/Logical Operator3' */
      LKAS_DW.LogicalOperator3 = ((rtb_BCM_Right_Light ||
        (LKAS_DW.RelationalOperator_ew)) || (LKAS_DW.RelationalOperator_h));

      /* DataTypeConversion: '<S93>/CastLKA1' */
      LKAS_DW.LKA_ExitFlg_Mon_l = LKAS_DW.LogicalOperator3 ? 1.0F : 0.0F;

      /* Sum: '<S98>/Add' */
      rtb_Gain2_bi = rtb_IMAPve_g_EPS_SW_Trq - rtb_kphTomps_j;

      /* Abs: '<S98>/Abs' */
      rtb_Gain2_bi = fabsf(rtb_Gain2_bi);

      /* Saturate: '<S98>/Saturation4' */
      if (rtb_Gain2_bi > 1.0F) {
        rtb_Gain2_bi = 1.0F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S98>/Saturation4' */

      /* Switch: '<S557>/Switch26' incorporates:
       *  Constant: '<S557>/LL_LKASWASyn_M3D=0.5'
       */
      if (LKAS_ConstB.DataTypeConversion40 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion40;
      } else {
        x10 = LL_LKASWASyn_M3D;
      }

      /* End of Switch: '<S557>/Switch26' */

      /* Product: '<S98>/Divide2' */
      rtb_Gain2_bi /= x10;

      /* Saturate: '<S98>/Saturation5' */
      if (rtb_Gain2_bi > 1.0F) {
        rtb_Gain2_bi = 1.0F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S98>/Saturation5' */

      /* Product: '<S98>/Divide1' */
      rtb_Gain2_bi *= rtb_LL_LKASWASyn_M3K;

      /* Saturate: '<S98>/Saturation3' */
      if (rtb_Gain2_bi > 0.2F) {
        rtb_Gain2_bi = 0.2F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S98>/Saturation3' */

      /* Product: '<S98>/Divide' */
      rtb_Divide3_j = rtb_Merge_e * rtb_LL_LKASWASyn_M3K;

      /* Saturate: '<S98>/Saturation1' */
      if (rtb_Divide3_j > 0.2F) {
        rtb_Divide3_j = 0.2F;
      } else {
        if (rtb_Divide3_j < 0.0F) {
          rtb_Divide3_j = 0.0F;
        }
      }

      /* End of Saturate: '<S98>/Saturation1' */

      /* Sum: '<S107>/Add2' incorporates:
       *  Memory: '<S107>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_e;

      /* Saturate: '<S107>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_gi = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_gi = 0.0F;
      } else {
        rtb_Saturation_gi = rtb_LftTTLC;
      }

      /* End of Saturate: '<S107>/Saturation' */

      /* MATLAB Function: '<S98>/MATLAB Function' */
      /* MATLAB Function 'LKAS/LL/LLOn/LKA/Driver Torque Addition (DTA)/Subsystem1/MATLAB Function': '<S105>:1' */
      /* '<S105>:1:2' if T<T1 */
      if (rtb_Saturation_gi < rtb_Saturation6) {
        /* '<S105>:1:3' M = M0+(M1-M0)/T1*T; */
        rtb_LL_LKASWASyn_M0 += ((rtb_LL_LKASWASyn_M1 - rtb_LL_LKASWASyn_M0) /
          rtb_Saturation6) * rtb_Saturation_gi;
      } else if ((rtb_Saturation_gi >= rtb_Saturation6) && (rtb_Saturation_gi <=
                  (rtb_Saturation6 + rtb_LL_LKASWASyn_T2))) {
        /* Switch: '<S557>/Switch14' incorporates:
         *  Constant: '<S557>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S105>:1:4' elseif T>=T1 && T<=(T1+T2) */
        /* '<S105>:1:5' M = (M2-M1)/(T2)*(T-T1)+M1; */
        if (LKAS_ConstB.DataTypeConversion20_i != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion20_i;
        } else {
          x10 = LL_LKASWASyn_M2;
        }

        rtb_LL_LKASWASyn_M0 = (((x10 - rtb_LL_LKASWASyn_M1) /
          rtb_LL_LKASWASyn_T2) * (rtb_Saturation_gi - rtb_Saturation6)) +
          rtb_LL_LKASWASyn_M1;
      } else {
        /* Switch: '<S557>/Switch14' incorporates:
         *  Constant: '<S557>/LL_LKASWASyn_M2=0.3'
         */
        /* '<S105>:1:6' else */
        /* '<S105>:1:7' M = M2; */
        if (LKAS_ConstB.DataTypeConversion20_i != 0.0F) {
          rtb_LL_LKASWASyn_M0 = LKAS_ConstB.DataTypeConversion20_i;
        } else {
          rtb_LL_LKASWASyn_M0 = LL_LKASWASyn_M2;
        }
      }

      /* End of MATLAB Function: '<S98>/MATLAB Function' */

      /* Sum: '<S98>/Add1' */
      rtb_Gain2_bi = (rtb_LL_LKASWASyn_M0 - rtb_Gain2_bi) - rtb_Divide3_j;

      /* Saturate: '<S98>/Saturation2' */
      if (rtb_Gain2_bi > 1.0F) {
        LKAS_DW.Saturation2 = 1.0F;
      } else if (rtb_Gain2_bi < 0.01F) {
        LKAS_DW.Saturation2 = 0.01F;
      } else {
        LKAS_DW.Saturation2 = rtb_Gain2_bi;
      }

      /* End of Saturate: '<S98>/Saturation2' */

      /* Sum: '<S202>/Add2' incorporates:
       *  Memory: '<S202>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_p;

      /* Saturate: '<S202>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_e = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_e = 0.0F;
      } else {
        rtb_Saturation_e = rtb_LftTTLC;
      }

      /* End of Saturate: '<S202>/Saturation' */

      /* If: '<S200>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       *  Inport: '<S208>/Plan'
       *  Inport: '<S208>/T1'
       */
      rtPrevAction = LKAS_DW.If_ActiveSubsystem_l;
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        rtAction = 0;
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      LKAS_DW.If_ActiveSubsystem_l = rtAction;
      switch (rtAction) {
       case 0:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S200>/If Action Subsystem' incorporates:
           *  ActionPort: '<S206>/Action Port'
           */
          /* InitializeConditions for If: '<S200>/If' incorporates:
           *  Memory: '<S206>/Memory'
           *  UnitDelay: '<S210>/Delay Input1'
           *
           * Block description for '<S210>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_b = false;
          LKAS_DW.Memory_PreviousInput_ge = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S200>/If Action Subsystem' */
        }

        /* Outputs for IfAction SubSystem: '<S200>/If Action Subsystem' incorporates:
         *  ActionPort: '<S206>/Action Port'
         */
        /* RelationalOperator: '<S209>/Compare' incorporates:
         *  Constant: '<S209>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Lft >= 0.0F);

        /* Memory: '<S206>/Memory' */
        rtb_Plan_g = LKAS_DW.Memory_PreviousInput_ge;

        /* Sum: '<S206>/Add' incorporates:
         *  Logic: '<S206>/Logical Operator'
         *  RelationalOperator: '<S206>/Relational Operator'
         *  RelationalOperator: '<S210>/FixPt Relational Operator'
         *  UnitDelay: '<S210>/Delay Input1'
         *
         * Block description for '<S210>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_g = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_b ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_e)) ? 1 : 0)) + rtb_Plan_g;

        /* Saturate: '<S206>/Saturation' */
        if (rtb_T1_g > 5.0F) {
          rtb_Saturation_ae = 5.0F;
        } else if (rtb_T1_g < 0.0F) {
          rtb_Saturation_ae = 0.0F;
        } else {
          rtb_Saturation_ae = rtb_T1_g;
        }

        /* End of Saturate: '<S206>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S206>/If Action Subsystem' */
        LKAS_IfActionSubsystem_n(rtb_Saturation_ae, rtb_Saturation_e,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_i, &LKAS_DW.In_g,
          &LKAS_DW.IfActionSubsystem_n4);

        /* End of Outputs for SubSystem: '<S206>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S206>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_a(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_g, &rtb_Plan_g);

        /* End of Outputs for SubSystem: '<S206>/If Action Subsystem2' */

        /* Switch: '<S206>/Switch' incorporates:
         *  Switch: '<S206>/Switch1'
         */
        if (rtb_Saturation_ae > 0.0F) {
          LKAS_DW.Merge_e = LKAS_DW.In_i;
          LKAS_DW.Merge1 = LKAS_DW.In_g;
        } else {
          LKAS_DW.Merge_e = rtb_T1_g;
          LKAS_DW.Merge1 = rtb_Plan_g;
        }

        /* End of Switch: '<S206>/Switch' */

        /* Update for UnitDelay: '<S210>/Delay Input1'
         *
         * Block description for '<S210>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_b = rtb_BCM_Right_Light;

        /* Update for Memory: '<S206>/Memory' */
        LKAS_DW.Memory_PreviousInput_ge = rtb_Saturation_ae;

        /* End of Outputs for SubSystem: '<S200>/If Action Subsystem' */
        break;

       case 1:
        if (rtAction != rtPrevAction) {
          /* InitializeConditions for IfAction SubSystem: '<S200>/If Action Subsystem1' incorporates:
           *  ActionPort: '<S207>/Action Port'
           */
          /* InitializeConditions for If: '<S200>/If' incorporates:
           *  Memory: '<S207>/Memory'
           *  UnitDelay: '<S218>/Delay Input1'
           *
           * Block description for '<S218>/Delay Input1':
           *
           *  Store in Global RAM
           */
          LKAS_DW.DelayInput1_DSTATE_m = false;
          LKAS_DW.Memory_PreviousInput_ph = 0.0F;

          /* End of InitializeConditions for SubSystem: '<S200>/If Action Subsystem1' */
        }

        /* Outputs for IfAction SubSystem: '<S200>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S207>/Action Port'
         */
        /* RelationalOperator: '<S217>/Compare' incorporates:
         *  Constant: '<S217>/Constant'
         */
        rtb_BCM_Right_Light = (rtb_phiHdAg_Rgt <= 0.0F);

        /* Memory: '<S207>/Memory' */
        rtb_Plan = LKAS_DW.Memory_PreviousInput_ph;

        /* Sum: '<S207>/Add' incorporates:
         *  Logic: '<S207>/Logical Operator'
         *  RelationalOperator: '<S207>/Relational Operator'
         *  RelationalOperator: '<S218>/FixPt Relational Operator'
         *  UnitDelay: '<S218>/Delay Input1'
         *
         * Block description for '<S218>/Delay Input1':
         *
         *  Store in Global RAM
         */
        rtb_T1_i = ((float32)(((((sint32)(rtb_BCM_Right_Light ? 1 : 0)) <
          ((sint32)(LKAS_DW.DelayInput1_DSTATE_m ? 1 : 0))) && (rtb_Saturation6 >=
          rtb_Saturation_e)) ? 1 : 0)) + rtb_Plan;

        /* Saturate: '<S207>/Saturation' */
        if (rtb_T1_i > 5.0F) {
          rtb_Saturation_gv = 5.0F;
        } else if (rtb_T1_i < 0.0F) {
          rtb_Saturation_gv = 0.0F;
        } else {
          rtb_Saturation_gv = rtb_T1_i;
        }

        /* End of Saturate: '<S207>/Saturation' */

        /* Outputs for Enabled SubSystem: '<S207>/If Action Subsystem' */
        LKAS_IfActionSubsystem_n(rtb_Saturation_gv, rtb_Saturation_e,
          rtb_SWACmd_phiSWACmd, &LKAS_DW.In_j, &LKAS_DW.In,
          &LKAS_DW.IfActionSubsystem_g);

        /* End of Outputs for SubSystem: '<S207>/If Action Subsystem' */

        /* Outputs for Atomic SubSystem: '<S207>/If Action Subsystem2' */
        LKAS_IfActionSubsystem2_a(rtb_Saturation6, rtb_SWACmd_phiSWACmd,
          &rtb_T1_i, &rtb_Plan);

        /* End of Outputs for SubSystem: '<S207>/If Action Subsystem2' */

        /* Switch: '<S207>/Switch' incorporates:
         *  Switch: '<S207>/Switch1'
         */
        if (rtb_Saturation_gv > 0.0F) {
          LKAS_DW.Merge_e = LKAS_DW.In_j;
          LKAS_DW.Merge1 = LKAS_DW.In;
        } else {
          LKAS_DW.Merge_e = rtb_T1_i;
          LKAS_DW.Merge1 = rtb_Plan;
        }

        /* End of Switch: '<S207>/Switch' */

        /* Update for UnitDelay: '<S218>/Delay Input1'
         *
         * Block description for '<S218>/Delay Input1':
         *
         *  Store in Global RAM
         */
        LKAS_DW.DelayInput1_DSTATE_m = rtb_BCM_Right_Light;

        /* Update for Memory: '<S207>/Memory' */
        LKAS_DW.Memory_PreviousInput_ph = rtb_Saturation_gv;

        /* End of Outputs for SubSystem: '<S200>/If Action Subsystem1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S200>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S208>/Action Port'
         */
        LKAS_DW.Merge_e = rtb_Saturation6;
        LKAS_DW.Merge1 = rtb_SWACmd_phiSWACmd;

        /* End of Outputs for SubSystem: '<S200>/If Action Subsystem2' */
        break;

       default:
        /* no actions */
        break;
      }

      /* End of If: '<S200>/If' */

      /* Saturate: '<S95>/Saturation6' */
      if (LKAS_DW.Merge_e > 0.5F) {
        rtb_LL_LKASWASyn_M0 = 0.5F;
      } else if (LKAS_DW.Merge_e < 0.2F) {
        rtb_LL_LKASWASyn_M0 = 0.2F;
      } else {
        rtb_LL_LKASWASyn_M0 = LKAS_DW.Merge_e;
      }

      /* End of Saturate: '<S95>/Saturation6' */

      /* Product: '<S95>/Divide' incorporates:
       *  Product: '<S203>/Divide'
       *  Product: '<S95>/Divide4'
       *  Sum: '<S95>/Add2'
       */
      rtb_LL_LKASWASyn_M0 = (rtb_Saturation_e - LKAS_DW.Merge_e) /
        rtb_LL_LKASWASyn_M0;
      rtb_Gain2_bi = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S95>/Saturation2' */
      if (rtb_Gain2_bi > 1.0F) {
        rtb_Gain2_bi = 1.0F;
      } else {
        if (rtb_Gain2_bi < 0.0F) {
          rtb_Gain2_bi = 0.0F;
        }
      }

      /* End of Saturate: '<S95>/Saturation2' */

      /* Sum: '<S95>/Add5' incorporates:
       *  Constant: '<S95>/Constant2'
       */
      rtb_LL_LKASWASyn_M1 = 1.0F - rtb_Gain2_bi;

      /* Memory: '<S185>/Memory' */
      rtb_Divide3_j = LKAS_DW.Memory_PreviousInput_g;

      /* Product: '<S252>/Z*Z' incorporates:
       *  Product: '<S249>/Z*Z'
       */
      rtb_LL_LKASWASyn_T2 = rtb_LL_HdAgPrvwT_C * rtb_LL_HdAgPrvwT_C;

      /* Sum: '<S185>/Add1' incorporates:
       *  Gain: '<S231>/Gain2'
       *  Product: '<S185>/Divide'
       *  Product: '<S185>/Divide1'
       *  Product: '<S249>/Product3'
       *  Product: '<S249>/Product4'
       *  Product: '<S252>/Product3'
       *  Product: '<S252>/Product4'
       *  Product: '<S252>/Z*Z'
       *  Sum: '<S231>/Add2'
       *  Sum: '<S249>/Add'
       *  Sum: '<S252>/Add'
       */
      rtb_Add1_h = ((((((rtb_Add_p_tmp * rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_m) +
                       (rtb_L0_C3_dc * rtb_LL_LKASWASyn_T2)) + (((rtb_Add_o_tmp *
        rtb_LL_HdAgPrvwT_C) + rtb_L0_C1_i) + (rtb_L0_C3 * rtb_LL_LKASWASyn_T2)))
                     * 0.5F) * LKAS_ConstB.Divide2_k) + (LKAS_ConstB.Add2_o *
        rtb_Divide3_j);

      /* Product: '<S183>/Divide3' incorporates:
       *  Gain: '<S229>/Gain1'
       */
      rtb_Divide3_j = rtb_LL_HdAgPrvwT_C * rtb_LL_ThresDet_tiTTLCThresLDW;

      /* Gain: '<S183>/kph to mps' */
      rtb_kphtomps_l = rtb_Abs_f_tmp;

      /* MATLAB Function: '<S183>/Saturable Gain Lut (SatGainLut)' */
      LKAS_SaturableGainLutSatGainLut(rtb_IMAPve_g_ESC_VehSpd,
        rtb_LL_LFClb_TFC_KpVehSpdLwr_C, rtb_LL_LFClb_TFC_KpVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KpV1_C, rtb_LL_LFClb_TFC_KpV2_C, &rtb_Gain_m);

      /* Switch: '<S557>/Switch32' incorporates:
       *  Constant: '<S557>/LL_LFClb_TFC_PrvwT_C=2'
       */
      if (LKAS_ConstB.DataTypeConversion15_f != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion15_f;
      } else {
        x10 = LL_LFClb_TFC_PrvwT_C;
      }

      /* End of Switch: '<S557>/Switch32' */

      /* Product: '<S183>/Divide1' */
      rtb_LftTTLC = x10 * rtb_kphtomps_l;

      /* Switch: '<S557>/Switch30' incorporates:
       *  Constant: '<S557>/LL_LFClb_TFC_KpKlat_C=-4.5'
       */
      if (LKAS_ConstB.DataTypeConversion11_g != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion11_g;
      } else {
        x10 = LL_LFClb_TFC_KpKlat_C;
      }

      /* End of Switch: '<S557>/Switch30' */

      /* Saturate: '<S183>/Saturation' */
      if (rtb_LftTTLC > 40.0F) {
        rtb_LftTTLC = 40.0F;
      } else {
        if (rtb_LftTTLC < 5.0F) {
          rtb_LftTTLC = 5.0F;
        }
      }

      /* End of Saturate: '<S183>/Saturation' */

      /* Sum: '<S183>/Subtract2' incorporates:
       *  Sum: '<S183>/Add1'
       */
      rtb_LL_HdAgPrvwT_C = rtb_Add1_h - rtb_Divide3_j;

      /* Product: '<S183>/Product4' incorporates:
       *  Gain: '<S230>/Gain1'
       *  Product: '<S183>/Divide'
       *  Product: '<S183>/Product1'
       *  Sum: '<S183>/Subtract1'
       *  Sum: '<S183>/Subtract2'
       *  Sum: '<S230>/Add1'
       */
      rtb_L0_C1_i = (((((rtb_Add_am + rtb_Add_e1) * 0.5F) / rtb_LftTTLC) * x10)
                     - rtb_LL_HdAgPrvwT_C) * rtb_Gain_m;

      /* Switch: '<S557>/Switch19' incorporates:
       *  Constant: '<S557>/LL_LFClb_TFC_Kp_C=1'
       */
      if (LKAS_ConstB.DataTypeConversion26_h != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion26_h;
      } else {
        x10 = LL_LFClb_TFC_Kp_C;
      }

      /* End of Switch: '<S557>/Switch19' */

      /* Product: '<S183>/Product2' */
      rtb_Merge_e = rtb_L0_C1_i * x10;

      /* Saturate: '<S183>/Saturation2' */
      if (rtb_Merge_e > 360.0F) {
        rtb_Merge_e = 360.0F;
      } else {
        if (rtb_Merge_e < (-360.0F)) {
          rtb_Merge_e = (-360.0F);
        }
      }

      /* End of Saturate: '<S183>/Saturation2' */

      /* Abs: '<S183>/Abs' incorporates:
       *  Gain: '<S229>/Gain1'
       */
      rtb_kphTomps_j = fabsf(rtb_LL_ThresDet_tiTTLCThresLDW);

      /* Saturate: '<S183>/Saturation1' */
      if (rtb_kphTomps_j > 0.004F) {
        rtb_kphTomps_j = 0.004F;
      } else {
        if (rtb_kphTomps_j < 1.0E-5F) {
          rtb_kphTomps_j = 1.0E-5F;
        }
      }

      /* End of Saturate: '<S183>/Saturation1' */

      /* Switch: '<S557>/Switch39' incorporates:
       *  Constant: '<S557>/LL_LFClb_TFC_KiMaxSWA_C=5'
       */
      if (LKAS_ConstB.DataTypeConversion28 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion28;
      } else {
        x10 = LL_LFClb_TFC_KiMaxSWA_C;
      }

      /* End of Switch: '<S557>/Switch39' */

      /* Sum: '<S183>/Add3' incorporates:
       *  Constant: '<S183>/Constant3'
       *  Constant: '<S183>/Constant4'
       *  Product: '<S183>/Divide4'
       *  Sum: '<S183>/Add5'
       */
      rtb_kphTomps_j = (((x10 - 1.0F) * rtb_kphTomps_j) / 0.004F) + 1.0F;

      /* Sum: '<S191>/Add2' incorporates:
       *  Memory: '<S191>/Memory3'
       */
      rtb_LftTTLC = rtb_LKA_SampleTime + LKAS_DW.Memory3_PreviousInput_m;

      /* Saturate: '<S191>/Saturation' */
      if (rtb_LftTTLC > 50.0F) {
        rtb_Saturation_j = 50.0F;
      } else if (rtb_LftTTLC < 0.0F) {
        rtb_Saturation_j = 0.0F;
      } else {
        rtb_Saturation_j = rtb_LftTTLC;
      }

      /* End of Saturate: '<S191>/Saturation' */

      /* Switch: '<S183>/Switch2' incorporates:
       *  Product: '<S183>/Divide2'
       *  Sum: '<S183>/Add'
       *  Sum: '<S183>/Add2'
       *  Switch: '<S557>/Switch40'
       *  UnitDelay: '<S183>/Unit Delay'
       */
      if ((rtb_Saturation_j - rtb_Saturation6) >= 0.0F) {
        /* Switch: '<S557>/Switch40' incorporates:
         *  Constant: '<S557>/LL_LFClb_TFC_Ki_C=0.01'
         */
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_i = (rtb_L0_C1_i * x10) + LKAS_DW.UnitDelay_DSTATE_a;
      } else {
        if (LKAS_ConstB.DataTypeConversion29 != 0.0F) {
          /* Switch: '<S557>/Switch40' */
          x10 = LKAS_ConstB.DataTypeConversion29;
        } else {
          /* Switch: '<S557>/Switch40' incorporates:
           *  Constant: '<S557>/LL_LFClb_TFC_Ki_C=0.01'
           */
          x10 = LL_LFClb_TFC_Ki_C;
        }

        rtb_Switch2_i = rtb_L0_C1_i * x10;
      }

      /* End of Switch: '<S183>/Switch2' */

      /* Gain: '<S183>/Gain' */
      rtb_L0_C1_i = (-1.0F) * rtb_kphTomps_j;

      /* Switch: '<S188>/Switch' incorporates:
       *  RelationalOperator: '<S188>/UpperRelop'
       */
      if (rtb_Switch2_i < rtb_L0_C1_i) {
        rtb_Switch_k = rtb_L0_C1_i;
      } else {
        rtb_Switch_k = rtb_Switch2_i;
      }

      /* End of Switch: '<S188>/Switch' */

      /* Switch: '<S188>/Switch2' incorporates:
       *  RelationalOperator: '<S188>/LowerRelop1'
       */
      if (rtb_Switch2_i > rtb_kphTomps_j) {
        rtb_Switch2_at = rtb_kphTomps_j;
      } else {
        rtb_Switch2_at = rtb_Switch_k;
      }

      /* End of Switch: '<S188>/Switch2' */

      /* Product: '<S95>/Divide1' incorporates:
       *  Sum: '<S95>/Add3'
       */
      rtb_L0_C1_m = (rtb_Merge_e + rtb_Switch2_at) * rtb_Gain2_bi;

      /* Switch: '<S557>/Switch49' incorporates:
       *  Constant: '<S557>/LL_LFClb_TFC_KdMaxSWA_C=20'
       */
      if (LKAS_ConstB.DataTypeConversion49 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion49;
      } else {
        x10 = LL_LFClb_TFC_KdMaxSWA_C;
      }

      /* End of Switch: '<S557>/Switch49' */

      /* Product: '<S183>/Divide8' incorporates:
       *  Constant: '<S183>/Constant7'
       *  Constant: '<S183>/Constant8'
       *  Sum: '<S183>/Add4'
       */
      rtb_kphTomps_j = ((180.0F - rtb_kphtomps_l) * x10) / 120.0F;

      /* MATLAB Function: '<S183>/Saturable Gain Lut (SatGainLut)1' */
      LKAS_SaturableGainLutSatGainLut(rtb_kphtomps_l,
        rtb_LL_LFClb_TFC_KdVehSpdLwr_C, rtb_LL_LFClb_TFC_KdVehSpdUpr_C,
        rtb_LL_LFClb_TFC_KdV1_C, rtb_LL_LFClb_TFC_KdV2_C, &rtb_Gain_m);

      /* Product: '<S190>/Divide1' incorporates:
       *  Constant: '<S190>/Constant3'
       *  Sum: '<S190>/Add4'
       */
      rtb_Merge_e = (1.0F + rtb_R0_C1_e) * rtb_Gain_m;

      /* Gain: '<S190>/Gain' incorporates:
       *  Abs: '<S190>/Abs'
       */
      rtb_L0_C1_i = fabsf(rtb_LL_ThresDet_lDvtThresUprLKA) * 0.5F;

      /* Gain: '<S190>/Gain1' incorporates:
       *  Sum: '<S190>/Add2'
       */
      rtb_Gain1_i5 = (rtb_L0_C0_o + rtb_R0_C0_n) * 0.5F;

      /* Gain: '<S190>/Gain2' */
      rtb_Gain2_bi = (-1.0F) * rtb_L0_C1_i;

      /* Switch: '<S195>/Switch' incorporates:
       *  RelationalOperator: '<S195>/UpperRelop'
       */
      if (rtb_Gain1_i5 < rtb_Gain2_bi) {
        rtb_Switch_fy = rtb_Gain2_bi;
      } else {
        rtb_Switch_fy = rtb_Gain1_i5;
      }

      /* End of Switch: '<S195>/Switch' */

      /* Switch: '<S195>/Switch2' incorporates:
       *  RelationalOperator: '<S195>/LowerRelop1'
       */
      if (rtb_Gain1_i5 > rtb_L0_C1_i) {
        rtb_Switch2_g1 = rtb_L0_C1_i;
      } else {
        rtb_Switch2_g1 = rtb_Switch_fy;
      }

      /* End of Switch: '<S195>/Switch2' */

      /* Product: '<S190>/Divide4' */
      rtb_L0_C1_i = (rtb_Switch2_g1 / rtb_L0_C1_i) * rtb_R0_C1_e;

      /* Product: '<S190>/Divide5' incorporates:
       *  Constant: '<S190>/Constant2'
       *  Sum: '<S190>/Add5'
       */
      rtb_Divide5_l = (1.0F + rtb_L0_C1_i) * rtb_Gain_m;

      /* Product: '<S190>/Divide2' incorporates:
       *  Constant: '<S190>/Constant2'
       *  Sum: '<S190>/Add1'
       */
      rtb_Divide2_be = (1.0F - rtb_L0_C1_i) * rtb_Gain_m;

      /* Sum: '<S197>/Add' incorporates:
       *  Constant: '<S197>/Constant'
       *  Memory: '<S197>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_f4));

      /* Saturate: '<S197>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_m = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_m = ((uint16)10000U);
      }

      /* End of Saturate: '<S197>/Saturation1' */

      /* If: '<S197>/If' incorporates:
       *  Constant: '<S197>/Constant2'
       *  DataTypeConversion: '<S80>/Cast To Single'
       *  Inport: '<S198>/In'
       */
      if (rtb_Saturation1_m == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S197>/if action ' incorporates:
         *  ActionPort: '<S198>/Action Port'
         */
        LKAS_DW.In_h = LKAS_DW.LKASM_stLKAActvFlg;

        /* End of Outputs for SubSystem: '<S197>/if action ' */
      }

      /* End of If: '<S197>/If' */

      /* If: '<S190>/If' incorporates:
       *  Inport: '<S194>/In1'
       */
      if (((sint32)LKAS_DW.In_h) == 1) {
        /* Outputs for IfAction SubSystem: '<S190>/If Action Subsystem' incorporates:
         *  ActionPort: '<S192>/Action Port'
         */
        LKAS_IfActionSubsystem_a(rtb_Divide2_be, &rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.In_h) == 2) {
        /* Outputs for IfAction SubSystem: '<S190>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S193>/Action Port'
         */
        LKAS_IfActionSubsystem_a(rtb_Divide5_l, &rtb_Merge_d);

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S190>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S194>/Action Port'
         */
        rtb_Merge_d = rtb_Gain_m;

        /* End of Outputs for SubSystem: '<S190>/If Action Subsystem2' */
      }

      /* End of If: '<S190>/If' */

      /* Product: '<S190>/Divide3' incorporates:
       *  Constant: '<S190>/Constant1'
       *  Sum: '<S190>/Add3'
       */
      rtb_L0_C1_i = (1.0F - rtb_R0_C1_e) * rtb_Gain_m;

      /* Switch: '<S196>/Switch' incorporates:
       *  RelationalOperator: '<S196>/UpperRelop'
       */
      if (rtb_Merge_d < rtb_L0_C1_i) {
        rtb_Switch_fl = rtb_L0_C1_i;
      } else {
        rtb_Switch_fl = rtb_Merge_d;
      }

      /* End of Switch: '<S196>/Switch' */

      /* Switch: '<S196>/Switch2' incorporates:
       *  RelationalOperator: '<S196>/LowerRelop1'
       */
      if (rtb_Merge_d > rtb_Merge_e) {
        rtb_Switch2_k = rtb_Merge_e;
      } else {
        rtb_Switch2_k = rtb_Switch_fl;
      }

      /* End of Switch: '<S196>/Switch2' */

      /* Product: '<S183>/Divide7' incorporates:
       *  Gain: '<S183>/Gain1'
       */
      rtb_Divide7 = (rtb_LL_HdAgPrvwT_C * (-1.0F)) * rtb_Switch2_k;

      /* Gain: '<S183>/Gain3' */
      rtb_Merge_e = (-1.0F) * rtb_kphTomps_j;

      /* Switch: '<S189>/Switch' incorporates:
       *  RelationalOperator: '<S189>/UpperRelop'
       */
      if (rtb_Divide7 < rtb_Merge_e) {
        rtb_Switch_pi = rtb_Merge_e;
      } else {
        rtb_Switch_pi = rtb_Divide7;
      }

      /* End of Switch: '<S189>/Switch' */

      /* Switch: '<S189>/Switch2' incorporates:
       *  RelationalOperator: '<S189>/LowerRelop1'
       */
      if (rtb_Divide7 > rtb_kphTomps_j) {
        rtb_Switch2_p = rtb_kphTomps_j;
      } else {
        rtb_Switch2_p = rtb_Switch_pi;
      }

      /* End of Switch: '<S189>/Switch2' */

      /* Product: '<S95>/Divide4' */
      rtb_kphTomps_j = rtb_LL_LKASWASyn_M0;

      /* Saturate: '<S95>/Saturation1' */
      if (rtb_kphTomps_j > 1.0F) {
        rtb_kphTomps_j = 1.0F;
      } else {
        if (rtb_kphTomps_j < 0.0F) {
          rtb_kphTomps_j = 0.0F;
        }
      }

      /* End of Saturate: '<S95>/Saturation1' */

      /* Product: '<S95>/Divide2' */
      rtb_L0_C0_o = rtb_Switch2_p * rtb_kphTomps_j;

      /* Saturate: '<S203>/Saturation4' */
      if (rtb_LL_LKASWASyn_M0 > 1.0F) {
        rtb_LL_LKASWASyn_M0 = 1.0F;
      } else {
        if (rtb_LL_LKASWASyn_M0 < 0.0F) {
          rtb_LL_LKASWASyn_M0 = 0.0F;
        }
      }

      /* End of Saturate: '<S203>/Saturation4' */

      /* Product: '<S95>/Divide5' incorporates:
       *  Constant: '<S203>/Constant1'
       *  Product: '<S203>/Divide8'
       *  Sum: '<S203>/Add1'
       */
      rtb_kphTomps_j = ((LKAS_ConstB.Add3 * rtb_LL_LKASWASyn_M0) + 0.0F) *
        rtb_LL_LKAExPrcs_tiExitTime1;

      /* Saturate: '<S95>/Saturation3' */
      if (rtb_Merge > 0.004F) {
        rtb_Merge_e = 0.004F;
      } else if (rtb_Merge < (-0.004F)) {
        rtb_Merge_e = (-0.004F);
      } else {
        rtb_Merge_e = rtb_Merge;
      }

      /* End of Saturate: '<S95>/Saturation3' */

      /* Product: '<S95>/Divide3' */
      rtb_LftTTLC = rtb_Saturation_e / LKAS_DW.Merge_e;

      /* Saturate: '<S95>/Saturation' */
      if (rtb_LftTTLC > 1.0F) {
        rtb_LftTTLC = 1.0F;
      } else {
        if (rtb_LftTTLC < 0.0F) {
          rtb_LftTTLC = 0.0F;
        }
      }

      /* End of Saturate: '<S95>/Saturation' */

      /* Sum: '<S95>/Add4' incorporates:
       *  Product: '<S95>/Divide6'
       *  Product: '<S95>/Divide7'
       *  Sum: '<S95>/Add6'
       */
      rtb_L0_C0_o = (((((LKAS_DW.Merge1 + rtb_LL_LKAExPrcs_tiExitTime1) *
                        rtb_LL_LKASWASyn_M1) + rtb_L0_C1_m) + rtb_L0_C0_o) +
                     rtb_kphTomps_j) + (LKAS_DW.DifferenceInputs2_g *
        rtb_LftTTLC);

      /* Memory: '<S201>/Memory3' */
      rtb_kphTomps_j = LKAS_DW.Memory3_PreviousInput_b;

      /* Sum: '<S201>/Add2' incorporates:
       *  Constant: '<S201>/SWACmdSyn_tiSmplT_C4'
       */
      rtb_kphTomps_j += 1.0F;

      /* Saturate: '<S201>/Saturation' */
      if (rtb_kphTomps_j > 50.0F) {
        rtb_Saturation_nf = 50.0F;
      } else if (rtb_kphTomps_j < 0.0F) {
        rtb_Saturation_nf = 0.0F;
      } else {
        rtb_Saturation_nf = rtb_kphTomps_j;
      }

      /* End of Saturate: '<S201>/Saturation' */

      /* Switch: '<S201>/Switch' incorporates:
       *  Constant: '<S95>/Constant1'
       *  Product: '<S201>/Divide'
       *  Product: '<S201>/Divide1'
       *  Sum: '<S201>/Add'
       *  Sum: '<S201>/Add1'
       *  UnitDelay: '<S201>/Unit Delay'
       */
      if (rtb_Saturation_nf > 30.0F) {
        rtb_Switch_kb = ((rtb_LKA_SampleTime / 0.1F) * (rtb_L0_C0_o -
          LKAS_DW.UnitDelay_DSTATE_g)) + LKAS_DW.UnitDelay_DSTATE_g;
      } else {
        rtb_Switch_kb = rtb_L0_C0_o;
      }

      /* End of Switch: '<S201>/Switch' */

      /* Switch: '<S557>/Switch17' incorporates:
       *  Constant: '<S557>/LL_CompSWA_C=0'
       */
      if (LKAS_ConstB.DataTypeConversion2 != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion2;
      } else {
        x10 = LL_CompSWA_C;
      }

      /* End of Switch: '<S557>/Switch17' */

      /* Sum: '<S92>/Add' */
      rtb_Add_of = (rtb_Switch_kb - x10) + LKAS_DW.Saturation_h;

      /* Sum: '<S92>/Add1' */
      rtb_kphTomps_j = rtb_LL_LKAExPrcs_tiExitTime1 +
        rtb_LL_LDW_LatestWarnLine_C;

      /* Sum: '<S92>/Add2' incorporates:
       *  Gain: '<S92>/Gain2'
       */
      rtb_LL_LKAExPrcs_tiExitTime1 += (-1.0F) * rtb_LL_LDW_LatestWarnLine_C;

      /* Switch: '<S179>/Switch' incorporates:
       *  RelationalOperator: '<S179>/UpperRelop'
       */
      if (rtb_Add_of < rtb_LL_LKAExPrcs_tiExitTime1) {
        rtb_Switch_og = rtb_LL_LKAExPrcs_tiExitTime1;
      } else {
        rtb_Switch_og = rtb_Add_of;
      }

      /* End of Switch: '<S179>/Switch' */

      /* Switch: '<S179>/Switch2' incorporates:
       *  RelationalOperator: '<S179>/LowerRelop1'
       */
      if (rtb_Add_of > rtb_kphTomps_j) {
        rtb_Switch2_m = rtb_kphTomps_j;
      } else {
        rtb_Switch2_m = rtb_Switch_og;
      }

      /* End of Switch: '<S179>/Switch2' */

      /* Sum: '<S178>/Add1' incorporates:
       *  Constant: '<S178>/Constant'
       *  Memory: '<S178>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_e));

      /* Switch: '<S178>/Switch' incorporates:
       *  Constant: '<S178>/LatchTime_SY'
       *  RelationalOperator: '<S178>/Relational Operator'
       *  UnitDelay: '<S178>/Delay Input2'
       *
       * Block description for '<S178>/Delay Input2':
       *
       *  Store in Global RAM
       */
      if (rtb_Saturation_h5 <= ((uint16)1U)) {
        rtb_kphTomps_j = rtb_Switch2_m;
      } else {
        rtb_kphTomps_j = LKAS_DW.DelayInput2_DSTATE_b;
      }

      /* End of Switch: '<S178>/Switch' */

      /* Sum: '<S178>/Difference Inputs1'
       *
       * Block description for '<S178>/Difference Inputs1':
       *
       *  Add in CPU
       */
      rtb_UkYk1_o = rtb_Switch2_m - rtb_kphTomps_j;

      /* SampleTimeMath: '<S178>/sample time'
       *
       * About '<S178>/sample time':
       *  y = K where K = ( w * Ts )
       */
      rtb_Merge_e = 0.01F;

      /* Product: '<S178>/delta rise limit' incorporates:
       *  Gain: '<S92>/Gain3'
       */
      rtb_L0_C1_i = (1.4F * rtb_LL_ThresDet_lDvtThresLwrLDW) * rtb_Merge_e;

      /* Product: '<S178>/delta fall limit' incorporates:
       *  Gain: '<S92>/Gain1'
       */
      rtb_Merge_e *= (-1.4F) * rtb_LL_ThresDet_lDvtThresLwrLDW;

      /* Switch: '<S180>/Switch' incorporates:
       *  RelationalOperator: '<S180>/UpperRelop'
       */
      if (rtb_UkYk1_o < rtb_Merge_e) {
        rtb_Switch_dr = rtb_Merge_e;
      } else {
        rtb_Switch_dr = rtb_UkYk1_o;
      }

      /* End of Switch: '<S180>/Switch' */

      /* Switch: '<S180>/Switch2' incorporates:
       *  RelationalOperator: '<S180>/LowerRelop1'
       */
      if (rtb_UkYk1_o > rtb_L0_C1_i) {
        rtb_Switch2_co = rtb_L0_C1_i;
      } else {
        rtb_Switch2_co = rtb_Switch_dr;
      }

      /* End of Switch: '<S180>/Switch2' */

      /* Sum: '<S178>/Difference Inputs2'
       *
       * Block description for '<S178>/Difference Inputs2':
       *
       *  Add in CPU
       */
      LKAS_DW.DifferenceInputs2 = rtb_Switch2_co + rtb_kphTomps_j;

      /* Saturate: '<S178>/Saturation2' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation2_b = rtb_Saturation_h5;
      } else {
        rtb_Saturation2_b = ((uint16)10000U);
      }

      /* End of Saturate: '<S178>/Saturation2' */

      /* DataTypeConversion: '<S93>/CastLKA3' */
      LKAS_DW.T1_Mon_g = LKAS_DW.Merge_e;

      /* If: '<S131>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S149>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Add_am, &rtb_Merge_fs);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S148>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_Add_e1, &rtb_Merge_fs);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S131>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S150>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_fs);

        /* End of Outputs for SubSystem: '<S131>/If Action Subsystem3' */
      }

      /* End of If: '<S131>/If' */

      /* If: '<S133>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S155>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_phiHdAg_Lft, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem2' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S154>/Action Port'
         */
        LKAS_IfActionSubsystem2_k(rtb_phiHdAg_Rgt, &rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S133>/If Action Subsystem3' incorporates:
         *  ActionPort: '<S156>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_k);

        /* End of Outputs for SubSystem: '<S133>/If Action Subsystem3' */
      }

      /* End of If: '<S133>/If' */

      /* DataTypeConversion: '<S173>/Data Type Conversion' incorporates:
       *  Constant: '<S174>/Constant'
       *  RelationalOperator: '<S174>/Compare'
       */
      rtb_IMAPve_d_SAS_Trim_State = (uint8)((rtb_Merge <= 0.0F) ? 1 : 0);

      /* Gain: '<S169>/kph To mps' */
      rtb_kphTomps_j = rtb_Abs_f_tmp;

      /* Switch: '<S557>/Switch5' incorporates:
       *  Constant: '<S557>/LL_LSpdCompT_C=0.4'
       */
      if (LKAS_ConstB.DataTypeConversion13_p != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion13_p;
      } else {
        x10 = LL_LSpdCompT_C;
      }

      /* End of Switch: '<S557>/Switch5' */

      /* Product: '<S173>/Divide' */
      rtb_Merge_e = (rtb_Merge * rtb_kphTomps_j) * x10;

      /* Abs: '<S173>/Abs1' incorporates:
       *  Abs: '<S173>/Abs'
       */
      rtb_L0_C0_o = fabsf(rtb_Merge_e);
      rtb_Abs1_g = rtb_L0_C0_o;

      /* Abs: '<S173>/Abs' */
      rtb_Abs_h = rtb_L0_C0_o;

      /* If: '<S173>/If' incorporates:
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) && (((sint32)
            rtb_IMAPve_d_SAS_Trim_State) == 0)) {
        /* Outputs for IfAction SubSystem: '<S173>/If Action Subsystem' incorporates:
         *  ActionPort: '<S175>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs_h, &rtb_Merge_e);

        /* End of Outputs for SubSystem: '<S173>/If Action Subsystem' */
      } else if ((((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) && (((sint32)
                   rtb_IMAPve_d_SAS_Trim_State) == 1)) {
        /* Outputs for IfAction SubSystem: '<S173>/If Action Subsystem4' incorporates:
         *  ActionPort: '<S177>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Abs1_g, &rtb_Merge_e);

        /* End of Outputs for SubSystem: '<S173>/If Action Subsystem4' */
      } else {
        /* Outputs for IfAction SubSystem: '<S173>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S176>/Action Port'
         */
        LKAS_IfActionSubsystem2(&rtb_Merge_e);

        /* End of Outputs for SubSystem: '<S173>/If Action Subsystem2' */
      }

      /* End of If: '<S173>/If' */

      /* Switch: '<S557>/Switch6' incorporates:
       *  Constant: '<S557>/LL_HdAgExT_C=15'
       */
      if (LKAS_ConstB.DataTypeConversion6_g != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_g;
      } else {
        x10 = LL_HdAgExT_C;
      }

      /* End of Switch: '<S557>/Switch6' */

      /* Sum: '<S169>/Add1' incorporates:
       *  Product: '<S169>/Divide'
       *  Product: '<S169>/Divide1'
       */
      rtb_Add1_kd = (((1.0F / x10) * rtb_LL_ThresDet_lDvtThresUprLKA) /
                     rtb_kphTomps_j) + rtb_Merge_e;

      /* If: '<S125>/If' incorporates:
       *  Constant: '<S172>/Constant2'
       *  DataTypeConversion: '<S80>/Cast To Single'
       */
      if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S125>/If Action Subsystem' incorporates:
         *  ActionPort: '<S170>/Action Port'
         */
        /* Gain: '<S170>/Gain2' */
        rtb_Merge_f = (-1.0F) * rtb_Add1_kd;

        /* End of Outputs for SubSystem: '<S125>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LKASM_stLKAActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S125>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S171>/Action Port'
         */
        LKAS_IfActionSubsystem(rtb_Add1_kd, &rtb_Merge_f);

        /* End of Outputs for SubSystem: '<S125>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S125>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S172>/Action Port'
         */
        rtb_Merge_f = 0.0F;

        /* End of Outputs for SubSystem: '<S125>/If Action Subsystem2' */
      }

      /* End of If: '<S125>/If' */

      /* Sum: '<S134>/Add' incorporates:
       *  Constant: '<S134>/Constant'
       *  Memory: '<S134>/Memory'
       */
      rtb_Add_jk = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_b));

      /* Saturate: '<S134>/Saturation1' */
      if (rtb_Add_jk < ((uint16)10000U)) {
        rtb_Saturation_h5 = rtb_Add_jk;
      } else {
        rtb_Saturation_h5 = ((uint16)10000U);
      }

      /* End of Saturate: '<S134>/Saturation1' */

      /* If: '<S134>/If' incorporates:
       *  Constant: '<S134>/Constant2'
       */
      if (rtb_Saturation_h5 == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S134>/if action ' incorporates:
         *  ActionPort: '<S157>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_f, &rtb_In_a);

        /* End of Outputs for SubSystem: '<S134>/if action ' */
      }

      /* End of If: '<S134>/If' */

      /* Sum: '<S136>/Add' incorporates:
       *  Constant: '<S136>/Constant'
       *  Memory: '<S136>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_l));

      /* Saturate: '<S136>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_or = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_or = ((uint16)10000U);
      }

      /* End of Saturate: '<S136>/Saturation1' */

      /* If: '<S136>/If' incorporates:
       *  Constant: '<S136>/Constant2'
       */
      if (rtb_Saturation1_or == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S136>/if action ' incorporates:
         *  ActionPort: '<S159>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_fs, &rtb_In_j);

        /* End of Outputs for SubSystem: '<S136>/if action ' */
      }

      /* End of If: '<S136>/If' */

      /* Sum: '<S137>/Add' incorporates:
       *  Constant: '<S137>/Constant'
       *  Memory: '<S137>/Memory'
       */
      rtb_Saturation_h5 = (uint16)(((uint32)((uint16)1U)) + ((uint32)
        LKAS_DW.Memory_PreviousInput_oj));

      /* Saturate: '<S137>/Saturation1' */
      if (rtb_Saturation_h5 < ((uint16)10000U)) {
        rtb_Saturation1_p = rtb_Saturation_h5;
      } else {
        rtb_Saturation1_p = ((uint16)10000U);
      }

      /* End of Saturate: '<S137>/Saturation1' */

      /* If: '<S137>/If' incorporates:
       *  Constant: '<S137>/Constant2'
       */
      if (rtb_Saturation1_p == ((uint16)1U)) {
        /* Outputs for IfAction SubSystem: '<S137>/if action ' incorporates:
         *  ActionPort: '<S160>/Action Port'
         */
        LKAS_ifaction(rtb_Merge_k, &rtb_In);

        /* End of Outputs for SubSystem: '<S137>/if action ' */
      }

      /* End of If: '<S137>/If' */

      /* DataTypeConversion: '<S122>/Cast To Single1' */
      rtb_MPInP_vVehSpd = rtb_IMAPve_g_ESC_VehSpd;

      /* DataTypeConversion: '<S93>/CastLKA2' */
      LKAS_DW.LKA_SampleTime_Mon_p = rtb_LKA_SampleTime;
    } else {
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S126>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S109>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S111>/Out' */
          LKAS_DW.RelationalOperator_ew = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S109>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S89>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S97>/Out1' */
          LKAS_DW.DifferenceInputs2_g = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S89>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_j.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_k3,
            &LKAS_DW.SumCondition1_j);
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition' */
        if (LKAS_DW.SumCondition_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_e,
            &LKAS_DW.SumCondition_c);
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S119>/Out' */
          LKAS_DW.RelationalOperator_h = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition2' */

        /* Disable for If: '<S200>/If' */
        LKAS_DW.If_ActiveSubsystem_l = -1;

        /* Disable for Outport: '<S80>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S80>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S80>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S80>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_l = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_p = 0.0F;
        LKAS_DW.T1_Mon_g = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LKA' */

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_ExitFlg_Mon = LKAS_DW.LKA_ExitFlg_Mon_l;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_SampleTime_Mon = LKAS_DW.LKA_SampleTime_Mon_p;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.T1_Mon = LKAS_DW.T1_Mon_g;

    /* SignalConversion: '<S10>/OutportBufferForM' */
    LKAS_DW.OutputM = LKAS_DW.Saturation2;

    /* SignalConversion: '<S10>/OutportBufferForphiSWACmd' */
    LKAS_DW.OutputSWACmd = LKAS_DW.DifferenceInputs2;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LKA_State_Mon = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LKA_State = LKAS_DW.LKASM_stLKAState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LDW_State_Mon = LKAS_DW.LDWSM_stLDWState;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.LDW_State = LKAS_DW.LDWSM_stLDWState;

    /* Outputs for Enabled SubSystem: '<S10>/LDW' incorporates:
     *  EnablePort: '<S79>/Enable'
     *
     * Block description for '<S10>/LDW':
     *  Block Name: Lane Departure Warning
     *  Ab.: LDW
     *  No.: 1.3.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-3-26
     */
    if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) > 0) {
      if (!LKAS_DW.LDW_MODE) {
        LKAS_DW.LDW_MODE = true;
      }

      /* If: '<S84>/If' */
      if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 1) {
        /* Outputs for IfAction SubSystem: '<S84>/If Action Subsystem' incorporates:
         *  ActionPort: '<S85>/Action Port'
         */
        /* Gain: '<S85>/rad to deg' incorporates:
         *  Gain: '<S85>/Gain'
         */
        LKAS_DW.Merge_l = ((-1.0F) * rtb_phiHdAg_Lft) * 57.2957802F;

        /* End of Outputs for SubSystem: '<S84>/If Action Subsystem' */
      } else if (((sint32)LKAS_DW.LDWSM_stLDWActvFlg) == 2) {
        /* Outputs for IfAction SubSystem: '<S84>/If Action Subsystem1' incorporates:
         *  ActionPort: '<S86>/Action Port'
         */
        /* Gain: '<S86>/rad to deg' */
        LKAS_DW.Merge_l = 57.2957802F * rtb_phiHdAg_Rgt;

        /* End of Outputs for SubSystem: '<S84>/If Action Subsystem1' */
      } else {
        /* Outputs for IfAction SubSystem: '<S84>/If Action Subsystem2' incorporates:
         *  ActionPort: '<S87>/Action Port'
         */
        LKAS_IfActionSubsystem2(&LKAS_DW.Merge_l);

        /* End of Outputs for SubSystem: '<S84>/If Action Subsystem2' */
      }

      /* End of If: '<S84>/If' */

      /* Switch: '<S556>/Switch2' incorporates:
       *  Constant: '<S556>/LL_LDWS_SUPPRESS_HEADING=2'
       */
      if (LKAS_ConstB.DataTypeConversion6_j != 0.0F) {
        x10 = LKAS_ConstB.DataTypeConversion6_j;
      } else {
        x10 = LL_LDWS_SUPPRESS_HEADING;
      }

      /* End of Switch: '<S556>/Switch2' */

      /* Outputs for Enabled SubSystem: '<S84>/Sum Condition' incorporates:
       *  EnablePort: '<S88>/Enable'
       */
      /* RelationalOperator: '<S84>/Relational Operator' */
      if (LKAS_DW.Merge_l >= x10) {
        if (!LKAS_DW.SumCondition_MODE_o) {
          /* InitializeConditions for Memory: '<S88>/Memory' */
          LKAS_DW.Memory_PreviousInput_o2 = 0.0F;
          LKAS_DW.SumCondition_MODE_o = true;
        }

        /* Sum: '<S88>/Add1' incorporates:
         *  Memory: '<S88>/Memory'
         */
        rtb_L0_C0_o = rtb_LKA_SampleTime + LKAS_DW.Memory_PreviousInput_o2;

        /* Saturate: '<S88>/Saturation' */
        if (rtb_L0_C0_o > 0.6F) {
          rtb_L0_C0_o = 0.6F;
        } else {
          if (rtb_L0_C0_o < 0.0F) {
            rtb_L0_C0_o = 0.0F;
          }
        }

        /* End of Saturate: '<S88>/Saturation' */

        /* RelationalOperator: '<S88>/Relational Operator' incorporates:
         *  Constant: '<S84>/Constant'
         */
        LKAS_DW.RelationalOperator_oh = (rtb_L0_C0_o >= 0.05F);

        /* Update for Memory: '<S88>/Memory' */
        LKAS_DW.Memory_PreviousInput_o2 = rtb_L0_C0_o;
      } else {
        if (LKAS_DW.SumCondition_MODE_o) {
          /* Disable for Outport: '<S88>/Out' */
          LKAS_DW.RelationalOperator_oh = false;
          LKAS_DW.SumCondition_MODE_o = false;
        }
      }

      /* End of RelationalOperator: '<S84>/Relational Operator' */
      /* End of Outputs for SubSystem: '<S84>/Sum Condition' */

      /* Product: '<S79>/Product' incorporates:
       *  Logic: '<S79>/Logical Operator'
       */
      LKAS_DW.Product = (uint8)(((uint32)LKAS_DW.LDWSM_stLDWActvFlg) * ((uint32)
        ((!LKAS_DW.RelationalOperator_oh) ? 1 : 0)));
    } else {
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S84>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_o) {
          /* Disable for Outport: '<S88>/Out' */
          LKAS_DW.RelationalOperator_oh = false;
          LKAS_DW.SumCondition_MODE_o = false;
        }

        /* End of Disable for SubSystem: '<S84>/Sum Condition' */

        /* Disable for Outport: '<S79>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S10>/LDW' */

    /* SignalConversion: '<S10>/OutportBufferForLDW_Flag' */
    LKAS_DW.LDW_Flag = LKAS_DW.Product;

    /* If: '<S403>/If' incorporates:
     *  Constant: '<S409>/Constant'
     *  Delay: '<S82>/Delay1'
     */
    if ((((sint32)LKAS_DW.Delay1_3_DSTATE) == 3) && (((sint32)
          rtb_IMAPve_d_EPS_LKA_State) != 1)) {
      /* Outputs for IfAction SubSystem: '<S403>/If Action Subsystem' incorporates:
       *  ActionPort: '<S407>/Action Port'
       */
      LKAS_IfActionSubsystem_nh(&rtb_Merge_n);

      /* End of Outputs for SubSystem: '<S403>/If Action Subsystem' */
    } else if (((((sint32)LKAS_DW.Delay1_3_DSTATE) == 4) || (((sint32)
                  LKAS_DW.Delay1_3_DSTATE) == 5)) && (((sint32)
                 rtb_IMAPve_d_EPS_LKA_State) != 3)) {
      /* Outputs for IfAction SubSystem: '<S403>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S408>/Action Port'
       */
      LKAS_IfActionSubsystem_nh(&rtb_Merge_n);

      /* End of Outputs for SubSystem: '<S403>/If Action Subsystem1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S403>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S409>/Action Port'
       */
      rtb_Merge_n = false;

      /* End of Outputs for SubSystem: '<S403>/If Action Subsystem3' */
    }

    /* End of If: '<S403>/If' */

    /* Outputs for Enabled SubSystem: '<S403>/Sum Condition1' */
    LKAS_SumCondition1(rtb_Merge_n, rtb_LKA_SampleTime,
                       rtb_LL_MAX_DELAY_EPSSTAR_TIME,
                       &LKAS_DW.RelationalOperator_n, &LKAS_DW.SumCondition1_l);

    /* End of Outputs for SubSystem: '<S403>/Sum Condition1' */

    /* SignalConversion: '<S462>/TmpSignal ConversionAt SFunction Inport1' incorporates:
     *  MATLAB Function: '<S375>/Disable Reason'
     */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_LKA_Main_Switch;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_LL_SingleLane_Disable_Swt;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_Compare_mln;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_LogicalOperator_iv;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_Compare_pxf;
    rtb_TmpSignalConversionAtSFunct[5] = rtb_LogicalOperator_ix;
    rtb_TmpSignalConversionAtSFunct[6] = rtb_Compare_ab;
    rtb_TmpSignalConversionAtSFunct[7] = rtb_phiSWA_Thres;
    rtb_TmpSignalConversionAtSFunct[8] = rtb_dphiSWARate_Thres;
    rtb_TmpSignalConversionAtSFunct[9] = rtb_aLAcc_Thres;
    rtb_TmpSignalConversionAtSFunct[10] = rtb_Compare_cwd;
    rtb_TmpSignalConversionAtSFunct[11] = LKAS_DW.RelationalOperator_f;
    rtb_TmpSignalConversionAtSFunct[12] = rtb_RelationalOperator_b;
    rtb_TmpSignalConversionAtSFunct[13] = rtb_LogicalOperator_ol;
    rtb_TmpSignalConversionAtSFunct[14] = rtb_LogicalOperator_m;
    rtb_TmpSignalConversionAtSFunct[15] = LKAS_DW.RelationalOperator_n;
    rtb_TmpSignalConversionAtSFunct[16] = rtb_BCM_Left_Light;
    rtb_TmpSignalConversionAtSFunct[17] = rtb_Merge_a3;

    /* MATLAB Function: '<S375>/Disable Reason' */
    /* MATLAB Function 'LKAS/LL/LLOn/LL State Determination  (LLStateDet)/LL State Machine Conditions (LLSMCon)/Disable Condition  (DisblC)/Subsystem1/Disable Reason': '<S462>:1' */
    /* '<S462>:1:2' y = single(0); */
    rtb_L0_C0_o = 0.0F;

    /* '<S462>:1:3' for i = 1:18 */
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 18)) {
      /* '<S462>:1:4' if u(i) == 1 */
      if (rtb_TmpSignalConversionAtSFunct[i]) {
        /* '<S462>:1:5' y = single(i); */
        rtb_L0_C0_o = 1.0F + ((float32)i);
        exitg1 = true;
      } else {
        i++;
      }
    }

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.Disable_Reason = rtb_L0_C0_o;

    /* DataTypeConversion: '<S276>/Cast' */
    ob_LKA_Disable_Reason = rtb_L0_C0_o;

    /* RelationalOperator: '<S413>/Compare' incorporates:
     *  Constant: '<S413>/Constant'
     */
    rtb_Compare_bi = (LKAS_DW.RelationalOperator_n == true);

    /* DataTypeConversion: '<S276>/Cast1' */
    ob_LKA_LKADeactvCSyn = (float32)(LKAS_DW.Merge1_c ? 1.0F : 0.0F);

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.RGTTTLC_Mon = rtb_RGTTTLC;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_LLMon_at_inport_0' */
    LKAS_DW.LFTTTLC_Mon = rtb_LFTTTLC;

    /* Gain: '<S227>/Gain' incorporates:
     *  Sum: '<S227>/Add4'
     */
    rtb_phiHdAg = (rtb_phiHdAg_Lft + rtb_phiHdAg_Rgt) * 0.5F;

    /* Logic: '<S495>/Logical Operator1' incorporates:
     *  RelationalOperator: '<S495>/Relational Operator3'
     *  RelationalOperator: '<S495>/Relational Operator4'
     */
    rtb_LogicalOperator1_f = ((rtb_Gain1_j <= rtb_Abs_k) || (rtb_Add5_n <=
      rtb_Abs_k));

    /* Gain: '<S226>/Gain' incorporates:
     *  Sum: '<S226>/Add'
     */
    rtb_lDvt = (rtb_Gain1_j + rtb_Add5_n) * 0.5F;

    /* SignalConversion: '<S10>/BusConversion_InsertedFor_bsLLState_at_inport_0' */
    LKAS_DW.DACMode = LKAS_DW.LKA_Mode;

    /* Gain: '<S225>/Gain' incorporates:
     *  Sum: '<S225>/Add'
     */
    rtb_crCrvt = (rtb_LL_CompHdAg_C + rtb_L0_C2) * 0.5F;

    /* Delay: '<S82>/Delay1' */
    rtb_DACMode = LKAS_DW.Delay1_2_DSTATE;

    /* RelationalOperator: '<S531>/Compare' incorporates:
     *  Constant: '<S531>/Constant'
     *  Constant: '<S565>/Constant14'
     */
    rtb_Compare_mx = (((uint8)0U) == ((uint8)1U));

    /* RelationalOperator: '<S540>/Compare' incorporates:
     *  Constant: '<S540>/Constant'
     *  Constant: '<S565>/Constant11'
     */
    rtb_Compare_hr = (((uint8)0U) == ((uint8)1U));
  } else {
    if (LKAS_DW.LLOn_MODE) {
      /* Disable for Enabled SubSystem: '<S383>/ExitCount' */
      if (LKAS_DW.ExitCount_MODE) {
        /* Disable for Outport: '<S391>/Out' */
        LKAS_DW.RelationalOperator_f = false;
        LKAS_DW.ExitCount_MODE = false;
      }

      /* End of Disable for SubSystem: '<S383>/ExitCount' */

      /* Disable for Enabled SubSystem: '<S384>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_i) {
        /* Disable for Outport: '<S393>/Out' */
        LKAS_DW.RelationalOperator_n2 = false;
        LKAS_DW.SumCondition1_MODE_i = false;
      }

      /* End of Disable for SubSystem: '<S384>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S394>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE) {
        /* Disable for Outport: '<S398>/Out' */
        LKAS_DW.RelationalOperator_a = false;
        LKAS_DW.SumCondition1_MODE = false;
      }

      /* End of Disable for SubSystem: '<S394>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S322>/Count 0.2s' */
      if (LKAS_DW.Count02s_MODE) {
        /* Disable for Outport: '<S353>/Out' */
        LKAS_DW.RelationalOperator_l1 = false;
        LKAS_DW.Count02s_MODE = false;
      }

      /* End of Disable for SubSystem: '<S322>/Count 0.2s' */

      /* Disable for Enabled SubSystem: '<S322>/Count' */
      if (LKAS_DW.Count_MODE) {
        /* Disable for Outport: '<S352>/Out' */
        LKAS_DW.Saturation = 0.0F;
        LKAS_DW.Count_MODE = false;
      }

      /* End of Disable for SubSystem: '<S322>/Count' */

      /* Disable for Enabled SubSystem: '<S355>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_f) {
        /* Disable for Outport: '<S361>/Out' */
        LKAS_DW.RelationalOperator_c = false;
        LKAS_DW.SumCondition1_MODE_f = false;
      }

      /* End of Disable for SubSystem: '<S355>/Sum Condition1' */

      /* Disable for Enabled SubSystem: '<S323>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_MODE_b) {
        /* Disable for Outport: '<S367>/Out' */
        LKAS_DW.RelationalOperator_l = false;
        LKAS_DW.SumCondition1_MODE_b = false;
      }

      /* End of Disable for SubSystem: '<S323>/Sum Condition1' */

      /* Disable for If: '<S370>/u1>=3|u1==1&u2==u3' */
      LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

      /* Disable for Enabled SubSystem: '<S333>/Sum Condition' */
      if (LKAS_DW.SumCondition_MODE) {
        /* Disable for Outport: '<S339>/Out' */
        LKAS_DW.RelationalOperator_na = false;
        LKAS_DW.SumCondition_MODE = false;
      }

      /* End of Disable for SubSystem: '<S333>/Sum Condition' */

      /* Disable for Enabled SubSystem: '<S281>/Count_5s3' */
      if (LKAS_DW.Count_5s3_MODE) {
        /* Disable for Outport: '<S545>/Out' */
        LKAS_DW.RelationalOperator = false;
        LKAS_DW.Count_5s3_MODE = false;
      }

      /* End of Disable for SubSystem: '<S281>/Count_5s3' */

      /* Disable for Enabled SubSystem: '<S281>/Count_5s2' */
      if (LKAS_DW.Count_5s2.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_o, &LKAS_DW.Count_5s2);
      }

      /* End of Disable for SubSystem: '<S281>/Count_5s2' */

      /* Disable for Enabled SubSystem: '<S281>/Count_5s1' */
      if (LKAS_DW.Count_5s1.Count_5s1_MODE) {
        LKAS_Count_5s1_Disable(&LKAS_DW.RelationalOperator_g, &LKAS_DW.Count_5s1);
      }

      /* End of Disable for SubSystem: '<S281>/Count_5s1' */

      /* Disable for Enabled SubSystem: '<S258>/Subsystem' */
      if (LKAS_DW.Subsystem_MODE_p) {
        /* Disable for Outport: '<S262>/Out' */
        LKAS_DW.RelationalOperator_k = false;
        LKAS_DW.Subsystem_MODE_p = false;
      }

      /* End of Disable for SubSystem: '<S258>/Subsystem' */

      /* Disable for Enabled SubSystem: '<S10>/LKA'
       *
       * Block description for '<S10>/LKA':
       *  Block Name: Lane Keeping Assistance
       *  Ab.: LKA
       *  No.: 1.2.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-5-13
       */
      if (LKAS_DW.LKA_MODE) {
        /* Disable for If: '<S126>/If' */
        LKAS_DW.If_ActiveSubsystem = -1;

        /* Disable for Enabled SubSystem: '<S109>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_MODE_h) {
          /* Disable for Outport: '<S111>/Out' */
          LKAS_DW.RelationalOperator_ew = false;
          LKAS_DW.SumCondition1_MODE_h = false;
        }

        /* End of Disable for SubSystem: '<S109>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S89>/Subsystem' */
        if (LKAS_DW.Subsystem_MODE_l) {
          /* Disable for Outport: '<S97>/Out1' */
          LKAS_DW.DifferenceInputs2_g = 0.0F;
          LKAS_DW.Subsystem_MODE_l = false;
        }

        /* End of Disable for SubSystem: '<S89>/Subsystem' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition1' */
        if (LKAS_DW.SumCondition1_j.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_k3,
            &LKAS_DW.SumCondition1_j);
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition1' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition' */
        if (LKAS_DW.SumCondition_c.SumCondition_MODE) {
          LKAS_SumCondition_Disable(&LKAS_DW.RelationalOperator_e,
            &LKAS_DW.SumCondition_c);
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition' */

        /* Disable for Enabled SubSystem: '<S110>/Sum Condition2' */
        if (LKAS_DW.SumCondition2_MODE) {
          /* Disable for Outport: '<S119>/Out' */
          LKAS_DW.RelationalOperator_h = false;
          LKAS_DW.SumCondition2_MODE = false;
        }

        /* End of Disable for SubSystem: '<S110>/Sum Condition2' */

        /* Disable for If: '<S200>/If' */
        LKAS_DW.If_ActiveSubsystem_l = -1;

        /* Disable for Outport: '<S80>/LKA_ExitFlg' */
        LKAS_DW.LogicalOperator3 = false;

        /* Disable for Outport: '<S80>/LKA_phiSWACmd' */
        LKAS_DW.DifferenceInputs2 = 0.0F;

        /* Disable for Outport: '<S80>/LKA_M' */
        LKAS_DW.Saturation2 = 0.0F;

        /* Disable for Outport: '<S80>/LKAMon' */
        LKAS_DW.LKA_ExitFlg_Mon_l = 0.0F;
        LKAS_DW.LKA_SampleTime_Mon_p = 0.0F;
        LKAS_DW.T1_Mon_g = 0.0F;
        LKAS_DW.LKA_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LKA' */

      /* Disable for Enabled SubSystem: '<S10>/LDW'
       *
       * Block description for '<S10>/LDW':
       *  Block Name: Lane Departure Warning
       *  Ab.: LDW
       *  No.: 1.3.0.0
       *  Rev: 0.0.1
       *  Update Date: 19-3-26
       */
      if (LKAS_DW.LDW_MODE) {
        /* Disable for Enabled SubSystem: '<S84>/Sum Condition' */
        if (LKAS_DW.SumCondition_MODE_o) {
          /* Disable for Outport: '<S88>/Out' */
          LKAS_DW.RelationalOperator_oh = false;
          LKAS_DW.SumCondition_MODE_o = false;
        }

        /* End of Disable for SubSystem: '<S84>/Sum Condition' */

        /* Disable for Outport: '<S79>/LDW_Flag' */
        LKAS_DW.Product = ((uint8)0U);
        LKAS_DW.LDW_MODE = false;
      }

      /* End of Disable for SubSystem: '<S10>/LDW' */

      /* Disable for Enabled SubSystem: '<S403>/Sum Condition1' */
      if (LKAS_DW.SumCondition1_l.SumCondition1_MODE) {
        LKAS_SumCondition1_Disable(&LKAS_DW.RelationalOperator_n,
          &LKAS_DW.SumCondition1_l);
      }

      /* End of Disable for SubSystem: '<S403>/Sum Condition1' */

      /* Disable for Outport: '<S10>/bsLLState' */
      LKAS_DW.LDW_State = ((uint8)0U);
      LKAS_DW.DACMode = ((uint8)0U);
      LKAS_DW.LKA_State = ((uint8)0U);

      /* Disable for Outport: '<S10>/LDW_Flag' */
      LKAS_DW.LDW_Flag = ((uint8)0U);

      /* Disable for Outport: '<S10>/phiSWACmd' */
      LKAS_DW.OutputSWACmd = 0.0F;

      /* Disable for Outport: '<S10>/M' */
      LKAS_DW.OutputM = 0.0F;
      LKAS_DW.LLOn_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S2>/LLOn' */

  /* MATLAB Function: '<S8>/Vehicle_Lane_Display' incorporates:
   *  Switch: '<S51>/Switch'
   *  Switch: '<S51>/Switch1'
   */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Vehicle_Lane_Display': '<S29>:1' */
  /* '<S29>:1:2' if stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S29>:1:3' if LDW_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LDW_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:5' elseif LDW_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:6' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:7' elseif LDW_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:8' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S29>:1:9' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S29>:1:10' Vehicle_Lane_Display=uint8(10); */
        rtb_L0_Q = 10U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:11' elseif LDW_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:12' Vehicle_Lane_Display=uint8(11); */
        rtb_L0_Q = 11U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:13' elseif LDW_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:14' Vehicle_Lane_Display=uint8(12); */
        rtb_L0_Q = 12U;
      } else if (((((sint32)LKAS_DW.LDW_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:15' elseif LDW_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:16' Vehicle_Lane_Display=uint8(13); */
        rtb_L0_Q = 13U;
      } else {
        /* '<S29>:1:17' else */
        /* '<S29>:1:18' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S29>:1:4' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   case 2:
    /* '<S29>:1:20' elseif stDACmode==2 */
    /* '<S29>:1:21' if LKA_STATE==3 && L0_Quality==3 && R0_Quality~=3 */
    if (((((sint32)LKAS_DW.LKA_State) != 3) || (((sint32)rtb_L0_Q) != 3)) ||
        (((sint32)rtb_R0_Q) == 3)) {
      if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) != 3)) &&
          (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:23' elseif LKA_STATE==3 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:24' Vehicle_Lane_Display=uint8(4); */
        rtb_L0_Q = 4U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 3) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:25' elseif LKA_STATE==3 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:26' Vehicle_Lane_Display=uint8(5); */
        rtb_L0_Q = 5U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) != 3)) {
        /* '<S29>:1:27' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality~=3 */
        /* '<S29>:1:28' Vehicle_Lane_Display=uint8(6); */
        rtb_L0_Q = 6U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) != 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:29' elseif LKA_STATE==5 && L0_Quality~=3 && R0_Quality==3 */
        /* '<S29>:1:30' Vehicle_Lane_Display=uint8(7); */
        rtb_L0_Q = 7U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 4) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:31' elseif LKA_STATE==4 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:32' Vehicle_Lane_Display=uint8(8); */
        rtb_L0_Q = 8U;
      } else if (((((sint32)LKAS_DW.LKA_State) == 5) && (((sint32)rtb_L0_Q) == 3))
                 && (((sint32)rtb_R0_Q) == 3)) {
        /* '<S29>:1:33' elseif LKA_STATE==5 && L0_Quality==3 && R0_Quality==3 */
        /* '<S29>:1:34' Vehicle_Lane_Display=uint8(9); */
        rtb_L0_Q = 9U;
      } else {
        /* '<S29>:1:35' else */
        /* '<S29>:1:36' Vehicle_Lane_Display=uint8(1); */
        rtb_L0_Q = 1U;
      }
    } else {
      /* '<S29>:1:22' Vehicle_Lane_Display=uint8(3); */
    }
    break;

   default:
    /* '<S29>:1:38' else */
    /* '<S29>:1:39' Vehicle_Lane_Display=uint8(0); */
    rtb_L0_Q = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/Vehicle_Lane_Display' */

  /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S11>/Constant6'
   */
  switch (LKAS_DW.LKA_State) {
   case 0:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)1U);
    break;

   case 1:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)1U);
    break;

   case 2:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)2U);
    break;

   case 3:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)3U);
    break;

   case 4:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)4U);
    break;

   case 5:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)4U);
    break;

   default:
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)5U);
    break;
  }

  /* End of MultiPortSwitch: '<S11>/Multiport Switch' */

  /* RelationalOperator: '<S547>/Compare' incorporates:
   *  Constant: '<S547>/Constant'
   */
  rtb_Merge_a3 = (rtb_IMAPve_d_SAS_Trim_State == ((uint8)4U));

  /* Switch: '<S11>/Switch1' incorporates:
   *  Constant: '<S11>/1'
   *  Constant: '<S11>/x0'
   */
  if (rtb_Merge_a3) {
    rtb_R0_Q = ((uint8)1U);
  } else {
    rtb_R0_Q = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S546>/Subsystem' incorporates:
   *  EnablePort: '<S553>/Enable'
   */
  if (((sint32)rtb_R0_Q) > 0) {
    if (!LKAS_DW.Subsystem_MODE) {
      /* InitializeConditions for Delay: '<S553>/Delay1' */
      LKAS_DW.Delay1_DSTATE = 0.0F;
      LKAS_DW.Subsystem_MODE = true;
    }

    /* Sum: '<S553>/Add' */
    rtb_L0_C2 = LKAS_DW.OutputSWACmd - rtb_R0_C2;

    /* Sum: '<S553>/Add1' incorporates:
     *  Constant: '<S553>/Ki'
     *  Delay: '<S553>/Delay1'
     *  Product: '<S553>/Product2'
     */
    rtb_LL_CompHdAg_C = (rtb_L0_C2 * 0.0005F) + LKAS_DW.Delay1_DSTATE;

    /* Saturate: '<S553>/Saturation' */
    if (rtb_LL_CompHdAg_C > 0.5F) {
      rtb_LL_CompHdAg_C = 0.5F;
    } else {
      if (rtb_LL_CompHdAg_C < (-0.5F)) {
        rtb_LL_CompHdAg_C = (-0.5F);
      }
    }

    /* End of Saturate: '<S553>/Saturation' */

    /* Fcn: '<S553>/Fcn' */
    rtb_Abs_k = LKAS_DW.OutputSWACmd * LKAS_DW.OutputSWACmd;

    /* Sum: '<S553>/Add2' incorporates:
     *  Constant: '<S553>/Kp'
     *  Fcn: '<S553>/Fcn'
     *  Product: '<S553>/Product1'
     */
    LKAS_DW.in_trq = (((((rtb_Abs_k * LKAS_DW.OutputSWACmd) * 2.0e-6F) +
                        (rtb_Abs_k * -0.0005F)) + (LKAS_DW.OutputSWACmd *
      0.0505F)) + (rtb_L0_C2 * 0.02F)) + rtb_LL_CompHdAg_C;

    /* Update for Delay: '<S553>/Delay1' */
    LKAS_DW.Delay1_DSTATE = rtb_LL_CompHdAg_C;
  } else {
    if (LKAS_DW.Subsystem_MODE) {
      /* Disable for Outport: '<S553>/in_trq' */
      LKAS_DW.in_trq = 0.0F;
      LKAS_DW.Subsystem_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<S546>/Subsystem' */

  /* Sum: '<S551>/Difference Inputs1' incorporates:
   *  UnitDelay: '<S551>/Delay Input2'
   *
   * Block description for '<S551>/Difference Inputs1':
   *
   *  Add in CPU
   *
   * Block description for '<S551>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 = LKAS_DW.in_trq - LKAS_DW.DelayInput2_DSTATE;

  /* Product: '<S551>/delta rise limit' incorporates:
   *  Constant: '<S546>/Constant'
   *  SampleTimeMath: '<S551>/sample time'
   *
   * About '<S551>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_LL_CompHdAg_C = 5.0F * 0.01F;

  /* Product: '<S551>/delta fall limit' incorporates:
   *  Constant: '<S546>/Constant1'
   *  SampleTimeMath: '<S551>/sample time'
   *
   * About '<S551>/sample time':
   *  y = K where K = ( w * Ts )
   */
  rtb_L0_C0_o = (-5.0F) * 0.01F;

  /* Switch: '<S554>/Switch2' incorporates:
   *  Product: '<S551>/delta fall limit'
   *  Product: '<S551>/delta rise limit'
   *  RelationalOperator: '<S554>/LowerRelop1'
   *  RelationalOperator: '<S554>/UpperRelop'
   *  Switch: '<S554>/Switch'
   */
  if (rtb_L0_C2 > rtb_LL_CompHdAg_C) {
    rtb_L0_C2 = rtb_LL_CompHdAg_C;
  } else {
    if (rtb_L0_C2 < rtb_L0_C0_o) {
      /* Switch: '<S554>/Switch' incorporates:
       *  Product: '<S551>/delta fall limit'
       */
      rtb_L0_C2 = rtb_L0_C0_o;
    }
  }

  /* End of Switch: '<S554>/Switch2' */

  /* Sum: '<S551>/Difference Inputs2' incorporates:
   *  UnitDelay: '<S551>/Delay Input2'
   *
   * Block description for '<S551>/Difference Inputs2':
   *
   *  Add in CPU
   *
   * Block description for '<S551>/Delay Input2':
   *
   *  Store in Global RAM
   */
  rtb_L0_C2 += LKAS_DW.DelayInput2_DSTATE;

  /* MATLAB Function: '<S8>/LDW_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Status_Display': '<S25>:1' */
  /* '<S25>:1:2' if (stDACmode==1)&&LDW_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) != 6)) {
    /* '<S25>:1:3' LDW_Status_Display=uint8(1); */
    rtb_TCU_ActualGear = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 1) && (((sint32)LKAS_DW.LDW_State) ==
              6)) {
    /* '<S25>:1:4' elseif (stDACmode==1)&&LDW_STATE==6 */
    /* '<S25>:1:5' LDW_Status_Display=uint8(2); */
    rtb_TCU_ActualGear = 2U;
  } else {
    /* '<S25>:1:6' else */
    /* '<S25>:1:7' LDW_Status_Display=uint8(0); */
    rtb_TCU_ActualGear = 0U;
  }

  /* End of MATLAB Function: '<S8>/LDW_Status_Display' */

  /* MATLAB Function: '<S8>/LKA_Status_Display' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_Status_Display': '<S26>:1' */
  /* '<S26>:1:3' if stDACmode==2&&LKA_STATE~=6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) != 6)) {
    /* '<S26>:1:4' LKA_Status_Display=single(1); */
    rtb_LL_CompHdAg_C = 1.0F;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              6)) {
    /* '<S26>:1:5' elseif stDACmode==2&&LKA_STATE==6 */
    /* '<S26>:1:6' LKA_Status_Display=single(2); */
    rtb_LL_CompHdAg_C = 2.0F;
  } else {
    /* '<S26>:1:7' else */
    /* '<S26>:1:8' LKA_Status_Display=single(0); */
    rtb_LL_CompHdAg_C = 0.0F;
  }

  /* End of MATLAB Function: '<S8>/LKA_Status_Display' */

  /* MATLAB Function: '<S8>/LDW_Flag' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LDW_Flag': '<S24>:1' */
  /* '<S24>:1:2' if HMI_stDACmode==1 */
  switch (LKAS_DW.LKA_Mode) {
   case 1:
    /* '<S24>:1:3' if HMI_LDWWarnInfo==1 */
    switch (LKAS_DW.LDW_Flag) {
     case 1:
      /* '<S24>:1:4' LDW_Flag=uint8(1); */
      rtb_CastToSingle3 = 1U;
      break;

     case 2:
      /* '<S24>:1:5' elseif HMI_LDWWarnInfo==2 */
      /* '<S24>:1:6' LDW_Flag=uint8(2); */
      rtb_CastToSingle3 = 2U;
      break;

     default:
      /* '<S24>:1:7' else */
      /* '<S24>:1:8' LDW_Flag=uint8(0); */
      rtb_CastToSingle3 = 0U;
      break;
    }
    break;

   case 2:
    /* '<S24>:1:10' elseif HMI_stDACmode==2 */
    /* '<S24>:1:11' if HMI_LDWWarnInfo==1 && HMI_LKA_STATE==4 */
    if ((((sint32)LKAS_DW.LDW_Flag) == 1) && (((sint32)LKAS_DW.LKA_State) == 4))
    {
      /* '<S24>:1:12' LDW_Flag=uint8(1); */
      rtb_CastToSingle3 = 1U;
    } else if ((((sint32)LKAS_DW.LDW_Flag) == 2) && (((sint32)LKAS_DW.LKA_State)
                == 5)) {
      /* '<S24>:1:13' elseif HMI_LDWWarnInfo==2 && HMI_LKA_STATE==5 */
      /* '<S24>:1:14' LDW_Flag=uint8(2); */
      rtb_CastToSingle3 = 2U;
    } else {
      /* '<S24>:1:15' else */
      /* '<S24>:1:16' LDW_Flag=uint8(0); */
      rtb_CastToSingle3 = 0U;
    }
    break;

   default:
    /* '<S24>:1:18' else */
    /* '<S24>:1:19' LDW_Flag=uint8(0); */
    rtb_CastToSingle3 = 0U;
    break;
  }

  /* End of MATLAB Function: '<S8>/LDW_Flag' */

  /* Switch: '<S28>/Switch' incorporates:
   *  Constant: '<S28>/Constant'
   *  Constant: '<S28>/Constant1'
   *  Constant: '<S30>/Constant'
   *  RelationalOperator: '<S30>/Compare'
   */
  if (rtb_IMAPve_d_EPS_LKA_State == ((uint8)3U)) {
    rtb_TTLC_d = 0.5F;
  } else {
    rtb_TTLC_d = 0.25F;
  }

  /* End of Switch: '<S28>/Switch' */

  /* Logic: '<S28>/Logical Operator2' incorporates:
   *  Abs: '<S28>/Abs'
   *  Constant: '<S31>/Constant'
   *  Constant: '<S32>/Constant'
   *  Constant: '<S33>/Constant'
   *  Constant: '<S34>/Constant'
   *  Constant: '<S35>/Constant'
   *  Constant: '<S36>/Constant'
   *  Constant: '<S37>/Constant'
   *  Constant: '<S38>/Constant'
   *  Logic: '<S28>/Logical Operator1'
   *  Logic: '<S28>/Logical Operator3'
   *  RelationalOperator: '<S28>/Relational Operator'
   *  RelationalOperator: '<S31>/Compare'
   *  RelationalOperator: '<S32>/Compare'
   *  RelationalOperator: '<S33>/Compare'
   *  RelationalOperator: '<S34>/Compare'
   *  RelationalOperator: '<S35>/Compare'
   *  RelationalOperator: '<S36>/Compare'
   *  RelationalOperator: '<S37>/Compare'
   *  RelationalOperator: '<S38>/Compare'
   */
  rtb_LogicalOperator2 = ((((((((LKAS_DW.LDW_State == ((uint8)5U)) ||
    (LKAS_DW.LDW_State == ((uint8)4U))) || (LKAS_DW.LDW_State == ((uint8)3U))) ||
    (LKAS_DW.LKA_State == ((uint8)5U))) || (LKAS_DW.LKA_State == ((uint8)4U))) ||
    (LKAS_DW.LKA_State == ((uint8)3U))) && ((rtb_IMAPve_d_EPS_LKA_State ==
    ((uint8)3U)) || (rtb_IMAPve_d_EPS_LKA_State == ((uint8)1U)))) && (fabsf
    (rtb_IMAPve_g_EPS_SW_Trq) <= rtb_TTLC_d));

  /* Switch: '<S558>/Switch2' incorporates:
   *  Constant: '<S558>/LL_RlsDet_tiTDelTime_DISABLE=2'
   *
   * Block description for '<S558>/LL_RlsDet_tiTDelTime_DISABLE=2':
   *  ��ʻԱ���ֿ�ʼ����������������ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion2_a != 0.0F) {
    rtb_LL_HandsOff_WarnTime = LKAS_ConstB.DataTypeConversion2_a;
  } else {
    rtb_LL_HandsOff_WarnTime = LL_HandsOff_WarnTime;
  }

  /* End of Switch: '<S558>/Switch2' */

  /* Outputs for Enabled SubSystem: '<S28>/Sum Condition2' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_WarnTime, &LKAS_DW.RelationalOperator_cf,
                     &LKAS_DW.SumCondition2);

  /* End of Outputs for SubSystem: '<S28>/Sum Condition2' */

  /* MATLAB Function: '<S8>/Hands_Off_Warning' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/Hands_Off_Warning': '<S23>:1' */
  /* '<S23>:1:2' if HandsOff==0 */
  if (!LKAS_DW.RelationalOperator_cf) {
    /* '<S23>:1:3' Hands_Off_Warning= uint8(0); */
    rtb_Hands_Off_Warning_c = 0U;
  } else {
    /* '<S23>:1:4' elseif HandsOff==1 */
    /* '<S23>:1:5' Hands_Off_Warning= uint8(1); */
    rtb_Hands_Off_Warning_c = 1U;
  }

  /* End of MATLAB Function: '<S8>/Hands_Off_Warning' */

  /* Switch: '<S558>/Switch1' incorporates:
   *  Constant: '<S558>/LL_RlsDet_tiTDelTime_DISABLE=1'
   *
   * Block description for '<S558>/LL_RlsDet_tiTDelTime_DISABLE=1':
   *  ��ʻԱ���ֿ�ʼ�����ܷ����������ѵ�ʱ��
   */
  if (LKAS_ConstB.DataTypeConversion1 != 0.0F) {
    rtb_LL_HandsOff_TextTime = LKAS_ConstB.DataTypeConversion1;
  } else {
    rtb_LL_HandsOff_TextTime = LL_HandsOff_TextTime;
  }

  /* End of Switch: '<S558>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S28>/Sum Condition1' */
  LKAS_SumCondition1(rtb_LogicalOperator2, rtb_LKA_SampleTime,
                     rtb_LL_HandsOff_TextTime, &LKAS_DW.RelationalOperator_e2,
                     &LKAS_DW.SumCondition1);

  /* End of Outputs for SubSystem: '<S28>/Sum Condition1' */

  /* MATLAB Function: '<S8>/HMI_Popup_Status' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/HMI_Popup_Status': '<S22>:1' */
  /* '<S22>:1:2' if stDACmode==2&&LKA_STATE==6 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 6)) {
    /* �������ָ������� */
    /* '<S22>:1:3' HMI_Popup_Status=uint8(6); */
    rtb_IMAPve_d_Camera_Status = 6U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (((sint32)rtb_IMAPve_d_Camera_Status) == 5)) {
    /* '<S22>:1:6' elseif (stDACmode==2||stDACmode==1)&&(Front_Camera_Blocked==5) */
    /* ����ͷ���ڵ� */
    /* '<S22>:1:7' HMI_Popup_Status=uint8(4); */
    rtb_IMAPve_d_Camera_Status = 4U;
  } else if (((((sint32)LKAS_DW.LKA_Mode) == 2) || (((sint32)LKAS_DW.LKA_Mode) ==
    1)) && (LKAS_DW.RelationalOperator_e2)) {
    /* '<S22>:1:8' elseif (stDACmode==2||stDACmode==1)&&HandsOff==1 */
    /* ���շ����� */
    /* '<S22>:1:9' HMI_Popup_Status=uint8(2); */
    rtb_IMAPve_d_Camera_Status = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              2)) {
    /* '<S22>:1:10' elseif stDACmode==2&&(LKA_STATE==2) */
    /* '<S22>:1:11' HMI_Popup_Status=uint8(1); */
    rtb_IMAPve_d_Camera_Status = 1U;
  } else if (((sint32)LKAS_DW.LKA_Mode) != 2) {
    /* '<S22>:1:12' elseif stDACmode~=2&&stFaultCSyn==0 */
    /* '<S22>:1:13' HMI_Popup_Status=uint8(8); */
    rtb_IMAPve_d_Camera_Status = 8U;
  } else {
    /* '<S22>:1:14' elseif stFaultCSyn==0 */
    /* '<S22>:1:15' HMI_Popup_Status=uint8(7); */
    rtb_IMAPve_d_Camera_Status = 7U;
  }

  /* End of MATLAB Function: '<S8>/HMI_Popup_Status' */

  /* MATLAB Function: '<S8>/LKA_action_indication' */
  /* MATLAB Function 'LKAS/LL/Human Machine Interface (HMI)/LKA_action_indication': '<S27>:1' */
  /* '<S27>:1:2' if stDACmode==2&&LKA_STATE==2 */
  if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) == 2)) {
    /* '<S27>:1:3' LKA_Action_Indication=uint8(1); */
    rtb_LKA_Action_Indication_d = 1U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && (((sint32)LKAS_DW.LKA_State) ==
              3)) {
    /* '<S27>:1:4' elseif stDACmode==2&&LKA_STATE==3 */
    /* '<S27>:1:5' LKA_Action_Indication=uint8(2); */
    rtb_LKA_Action_Indication_d = 2U;
  } else if ((((sint32)LKAS_DW.LKA_Mode) == 2) && ((((sint32)LKAS_DW.LKA_State) ==
    4) || (((sint32)LKAS_DW.LKA_State) == 5))) {
    /* '<S27>:1:6' elseif stDACmode==2&&(LKA_STATE==4||LKA_STATE==5) */
    /* '<S27>:1:7' LKA_Action_Indication=uint8(3); */
    rtb_LKA_Action_Indication_d = 3U;
  } else {
    /* '<S27>:1:8' else */
    /* '<S27>:1:9' LKA_Action_Indication=uint8(0); */
    rtb_LKA_Action_Indication_d = 0U;
  }

  /* End of MATLAB Function: '<S8>/LKA_action_indication' */

  /* DataTypeConversion: '<S11>/Cast To Single10' incorporates:
   *  Constant: '<S548>/Constant'
   *  RelationalOperator: '<S548>/Compare'
   */
  rtb_LKA_Switch_State = (uint8)((LKAS_DW.DACMode > ((uint8)0U)) ? 1 : 0);

  /* DataTypeConversion: '<S4>/Cast To Single1' */
  LKAS_DW.CastToSingle1 = LKAS_DW.LFTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single2' */
  LKAS_DW.CastToSingle2 = LKAS_DW.RGTTTLC_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single3' */
  LKAS_DW.CastToSingle3 = (float32)LKAS_DW.LDW_State_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single4' */
  LKAS_DW.CastToSingle4 = (float32)LKAS_DW.LKA_State_Mon;

  /* S-Function (scanpack): '<S4>/CAN Pack' */
  /* S-Function (scanpack): '<S4>/CAN Pack' */
  LKAS_DW.CANPack.ID = 1U;
  LKAS_DW.CANPack.Length = 8U;
  LKAS_DW.CANPack.Extended = 0U;
  LKAS_DW.CANPack.Remote = 0;
  LKAS_DW.CANPack.Data[0] = 0;
  LKAS_DW.CANPack.Data[1] = 0;
  LKAS_DW.CANPack.Data[2] = 0;
  LKAS_DW.CANPack.Data[3] = 0;
  LKAS_DW.CANPack.Data[4] = 0;
  LKAS_DW.CANPack.Data[5] = 0;
  LKAS_DW.CANPack.Data[6] = 0;
  LKAS_DW.CANPack.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle1;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[1] = LKAS_DW.CANPack.Data[1] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[0] = LKAS_DW.CANPack.Data[0] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle2;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[3] = LKAS_DW.CANPack.Data[3] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[2] = LKAS_DW.CANPack.Data[2] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle3;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[5] = LKAS_DW.CANPack.Data[5] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[4] = LKAS_DW.CANPack.Data[4] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle4;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack.Data[7] = LKAS_DW.CANPack.Data[7] | (uint8)((uint16)
              (packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack.Data[6] = LKAS_DW.CANPack.Data[6] | (uint8)((uint16)
              ((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* DataTypeConversion: '<S4>/Cast To Single5' */
  LKAS_DW.CastToSingle5 = LKAS_DW.LKA_ExitFlg_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single6' */
  LKAS_DW.CastToSingle6 = LKAS_DW.LKA_SampleTime_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single7' */
  LKAS_DW.CastToSingle7 = LKAS_DW.T1_Mon;

  /* DataTypeConversion: '<S4>/Cast To Single8' */
  LKAS_DW.CastToSingle8 = LKAS_DW.Disable_Reason;

  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  /* S-Function (scanpack): '<S4>/CAN Pack1' */
  LKAS_DW.CANPack1.ID = 2U;
  LKAS_DW.CANPack1.Length = 8U;
  LKAS_DW.CANPack1.Extended = 0U;
  LKAS_DW.CANPack1.Remote = 0;
  LKAS_DW.CANPack1.Data[0] = 0;
  LKAS_DW.CANPack1.Data[1] = 0;
  LKAS_DW.CANPack1.Data[2] = 0;
  LKAS_DW.CANPack1.Data[3] = 0;
  LKAS_DW.CANPack1.Data[4] = 0;
  LKAS_DW.CANPack1.Data[5] = 0;
  LKAS_DW.CANPack1.Data[6] = 0;
  LKAS_DW.CANPack1.Data[7] = 0;

  {
    /* --------------- START Packing signal 0 ------------------
     *  startBit                = 8
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle5;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[1] = LKAS_DW.CANPack1.Data[1] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[0] = LKAS_DW.CANPack1.Data[0] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 1 ------------------
     *  startBit                = 24
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle6;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[3] = LKAS_DW.CANPack1.Data[3] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[2] = LKAS_DW.CANPack1.Data[2] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 2 ------------------
     *  startBit                = 40
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle7;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[5] = LKAS_DW.CANPack1.Data[5] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[4] = LKAS_DW.CANPack1.Data[4] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }

    /* --------------- START Packing signal 3 ------------------
     *  startBit                = 56
     *  length                  = 16
     *  desiredSignalByteLayout = BIGENDIAN
     *  dataType                = UNSIGNED
     *  factor                  = 0.01
     *  offset                  = 0.0
     *  minimum                 = 0.0
     *  maximum                 = 0.0
     * -----------------------------------------------------------------------*/
    {
      float32 outValue = 0;

      {
        float32 result = LKAS_DW.CastToSingle8;

        /* no offset to apply */
        result = result * (1 / 0.01F);
        outValue = result;
      }

      {
        uint16 packedValue;
        if (outValue > (float32)(65535)) {
          packedValue = (uint16) 65535;
        } else if (outValue < (float32)(0)) {
          packedValue = (uint16) 0;
        } else {
          packedValue = (uint16) (outValue);
        }

        {
          {
            LKAS_DW.CANPack1.Data[7] = LKAS_DW.CANPack1.Data[7] | (uint8)
              ((uint16)(packedValue & (uint16)0xFFU));
            LKAS_DW.CANPack1.Data[6] = LKAS_DW.CANPack1.Data[6] | (uint8)
              ((uint16)((uint16)(packedValue & (uint16)0xFF00U) >> 8));
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack' */
    if ((8 == LKAS_DW.CANPack.Length) && (LKAS_DW.CANPack.ID != INVALID_CAN_ID) )
    {
      if ((1 == LKAS_DW.CANPack.ID) && (0U == LKAS_DW.CANPack.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob5L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack1' */
    if ((8 == LKAS_DW.CANPack1.Length) && (LKAS_DW.CANPack1.ID != INVALID_CAN_ID)
        ) {
      if ((2 == LKAS_DW.CANPack1.ID) && (0U == LKAS_DW.CANPack1.Extended) ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6H_10 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_DW.CANPack1.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_DW.CANPack1.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob6L_10 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack2' */
    if ((8 == LKAS_ConstB.CANPack2.Length) && (LKAS_ConstB.CANPack2.ID !=
         INVALID_CAN_ID) ) {
      if ((3 == LKAS_ConstB.CANPack2.ID) && (0U == LKAS_ConstB.CANPack2.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack2.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack2.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack2.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob07L_100 = result;
            }
          }
        }
      }
    }
  }

  /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
  {
    /* S-Function (scanunpack): '<S4>/CAN Unpack3' */
    if ((8 == LKAS_ConstB.CANPack3.Length) && (LKAS_ConstB.CANPack3.ID !=
         INVALID_CAN_ID) ) {
      if ((4 == LKAS_ConstB.CANPack3.ID) && (0U == LKAS_ConstB.CANPack3.Extended)
          ) {
        {
          /* --------------- START Unpacking signal 0 ------------------
           *  startBit                = 24
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[3]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[2]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[1]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[0]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08H_100 = result;
            }
          }

          /* --------------- START Unpacking signal 1 ------------------
           *  startBit                = 56
           *  length                  = 32
           *  desiredSignalByteLayout = BIGENDIAN
           *  dataType                = UNSIGNED
           *  factor                  = 1.0
           *  offset                  = 0.0
           * -----------------------------------------------------------------------*/
          {
            uint32 outValue = 0;

            {
              uint32 unpackedValue = 0;

              {
                uint32 tempValue = (uint32) (0);

                {
                  tempValue = tempValue | (uint32)(LKAS_ConstB.CANPack3.Data[7]);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[6]) << 8);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[5]) << 16);
                  tempValue = tempValue | (uint32)((uint32)
                    (LKAS_ConstB.CANPack3.Data[4]) << 24);
                }

                unpackedValue = tempValue;
              }

              outValue = (uint32) (unpackedValue);
            }

            {
              uint32 result = (uint32) outValue;
              LKAS_DW.LKASve_g_ob08L_100 = result;
            }
          }
        }
      }
    }
  }

  /* RelationalOperator: '<S16>/Compare' incorporates:
   *  Constant: '<S16>/Constant'
   */
  rtb_Compare_ku = (rtb_IMAPve_d_TCU_Actual_Gear > ((uint8)3U));

  /* RelationalOperator: '<S13>/Compare' incorporates:
   *  Constant: '<S13>/Constant'
   */
  rtb_Compare_p = (rtb_IMAPve_d_EPS_LKA_State == ((uint8)4U));

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S60>/Cast To Single5'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_Type_g = rtb_R0_Type;
  } else {
    rtb_R0_Type_g = rtb_L0_Type;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  Constant: '<S57>/Constant'
   *  DataTypeConversion: '<S58>/Cast To Single5'
   *  Switch: '<S57>/Switch3'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_Type_e = rtb_L0_Type;

    /* DataTypeConversion: '<S1>/IMAPve_d_L1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_L1_Q'
     */
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Q_IMAPve_d_L1_Q();

    /* Switch: '<S53>/Switch1' incorporates:
     *  Constant: '<S53>/Constant1'
     */
    if (rtb_L0_Type >= ((uint8)2U)) {
      rtb_L1_Q = (uint16)((uint8)3U);
    } else {
      rtb_L1_Q = (uint16)rtb_L0_Type;
    }

    /* End of Switch: '<S53>/Switch1' */
  } else {
    rtb_L0_Type_e = rtb_R0_Type;
    rtb_L1_Q = ((uint16)0U);
  }

  /* DataTypeConversion: '<S50>/Cast To Single57' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_VR_1'
   *  Inport: '<Root>/IMAPve_g_R0_VR'
   */
  rtb_R0_C2 = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_VR_IMAPve_g_R0_VR();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_VR_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_VR'
   */
  rtb_L0_C0_o = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_VR_IMAPve_g_L0_VR();

  /* Switch: '<S59>/Switch3' incorporates:
   *  Constant: '<S59>/Constant'
   *  DataTypeConversion: '<S50>/Cast To Single66'
   *  Switch: '<S51>/Switch'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    /* DataTypeConversion: '<S1>/IMAPve_d_R1_Q_1' incorporates:
     *  Inport: '<Root>/IMAPve_d_R1_Q'
     */
    rtb_L0_Type = (uint8)
      Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Q_IMAPve_d_R1_Q();

    /* Switch: '<S54>/Switch1' incorporates:
     *  Constant: '<S54>/Constant1'
     */
    if (rtb_L0_Type >= ((uint8)2U)) {
      rtb_R1_Q = (uint16)((uint8)3U);
    } else {
      rtb_R1_Q = (uint16)rtb_L0_Type;
    }

    /* End of Switch: '<S54>/Switch1' */
    rtb_R0_VR_e = rtb_R0_C2;
  } else {
    rtb_R1_Q = ((uint16)0U);
    rtb_R0_VR_e = rtb_L0_C0_o;
  }

  /* End of Switch: '<S59>/Switch3' */

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single66'
   *  DataTypeConversion: '<S58>/Cast To Single4'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_VR_e = rtb_L0_C0_o;
  } else {
    rtb_L0_VR_e = rtb_R0_C2;
  }

  /* DataTypeConversion: '<S50>/Cast To Single75' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R0_W_1'
   *  Inport: '<Root>/IMAPve_g_R0_W'
   */
  rtb_R0_C2 = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R0_W_IMAPve_g_R0_W();

  /* DataTypeConversion: '<S1>/IMAPve_g_L0_W_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_L0_W'
   */
  rtb_L0_C0_o = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L0_W_IMAPve_g_L0_W();

  /* Switch: '<S51>/Switch' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single71'
   */
  if (LKAS_DW.LaneRSM_stRgtFlg > ((uint8)0U)) {
    rtb_R0_W_d = rtb_R0_C2;
  } else {
    rtb_R0_W_d = rtb_L0_C0_o;
  }

  /* Switch: '<S51>/Switch1' incorporates:
   *  DataTypeConversion: '<S50>/Cast To Single71'
   *  DataTypeConversion: '<S58>/Cast To Single6'
   */
  if (LKAS_DW.LaneRSM_stLftFlg > ((uint8)0U)) {
    rtb_L0_W_f = rtb_L0_C0_o;
  } else {
    rtb_L0_W_f = rtb_R0_C2;
  }

  /* Math: '<S44>/Mod1' incorporates:
   *  Constant: '<S44>/Constant7'
   */
  if (((sint32)((uint8)3U)) != 0) {
    rtb_Mod1 %= ((uint8)3U);
  }

  /* End of Math: '<S44>/Mod1' */

  /* DataTypeConversion: '<S1>/IMAPve_d_LDW_Warn_Mode_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_LDW_Warn_Mode'
   */
  rtb_L0_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_LDW_Warn_Mode_IMAPve_d_LDW_Warn_Mode();

  /* MinMax: '<S44>/Max1' */
  if (rtb_Mod1 > rtb_L0_Type) {
    rtb_LDW_Warn_Mode = rtb_Mod1;
  } else {
    rtb_LDW_Warn_Mode = rtb_L0_Type;
  }

  /* End of MinMax: '<S44>/Max1' */

  /* Gain: '<S6>/Gain2' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_d_FuncFaultStatus_1'
   *  Inport: '<Root>/ADIAve_d_FuncFaultStatus'
   */
  rtb_Gain2 = ((((uint32)((uint16)32768U)) * ((uint32)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_d_FuncFaultStatus_ADIAve_d_FuncFaultStatus
    ())) >> 15);

  /* Gain: '<S6>/Gain' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_ASWFaultStatus_1'
   *  Inport: '<Root>/ADIAve_g_ASWFaultStatus'
   */
  rtb_Gain = (uint32)((uint64)((((uint64)2147483648U) * ((uint64)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_ASWFaultStatus_ADIAve_g_ASWFaultStatus
    ())) >> 31));

  /* Gain: '<S6>/Gain1' incorporates:
   *  DataTypeConversion: '<S1>/ADIAve_g_BSWFaultStatus_1'
   *  Inport: '<Root>/ADIAve_g_BSWFaultStatus'
   */
  rtb_Gain1 = (uint32)((uint64)((((uint64)2147483648U) * ((uint64)
    Rte_IRead_Runnable_LKAS_Step_ADIAve_g_BSWFaultStatus_ADIAve_g_BSWFaultStatus
    ())) >> 31));

  /* DataTypeConversion: '<S1>/IMAPve_d_APA_AutoPark_WorkSt_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_APA_AutoPark_WorkSt'
   */
  rtb_IMAPve_d_APA_AutoPark_WorkS = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_APA_AutoPark_WorkSt_IMAPve_d_APA_AutoPark_WorkSt
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_BCM_HazardLamp_Switch_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_BCM_HazardLamp_Switch'
   */
  rtb_IMAPve_d_BCM_HazardLamp_g = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_BCM_HazardLamp_Switch_IMAPve_d_BCM_HazardLamp_Switch
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Driver_Override_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Driver_Override'
   */
  rtb_IMAPve_d_EPS_Driver_Overrid = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Driver_Override_IMAPve_d_EPS_Driver_Override
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_ESA_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_ESA_State'
   */
  rtb_IMAPve_d_EPS_ESA_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_ESA_State_IMAPve_d_EPS_ESA_State();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_Steer_Hold_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_Steer_Hold_State'
   */
  rtb_IMAPve_d_EPS_Steer_Hold_Sta = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Steer_Hold_State_IMAPve_d_EPS_Steer_Hold_State
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_EPS_SteeringAngle_Flag_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_EPS_SteeringAngle_Flag'
   */
  rtb_IMAPve_d_EPS_SteeringAngle_ = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_SteeringAngle_Flag_IMAPve_d_EPS_SteeringAngle_Flag
    ();

  /* RelationalOperator: '<S17>/Compare' incorporates:
   *  Constant: '<S17>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_TrqLim_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_TrqLim_State'
   */
  rtb_Compare_pi = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_TrqLim_State_IMAPve_d_EPS_TrqLim_State
                     ()) == ((uint8)0U));

  /* RelationalOperator: '<S18>/Compare' incorporates:
   *  Constant: '<S18>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_EPS_Trq_State_1'
   *  Inport: '<Root>/IMAPve_d_EPS_Trq_State'
   */
  rtb_Compare_ct = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_EPS_Trq_State_IMAPve_d_EPS_Trq_State
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S19>/Compare' incorporates:
   *  Constant: '<S19>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LatAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LatAcc_Valid'
   */
  rtb_Compare_ic = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LatAcc_Valid_IMAPve_d_ESC_LatAcc_Valid
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S21>/Compare' incorporates:
   *  Constant: '<S21>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_LonAcc_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_LonAcc_Valid'
   */
  rtb_Compare_nc = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_LonAcc_Valid_IMAPve_d_ESC_LonAcc_Valid
                     ()) == ((uint8)1U));

  /* RelationalOperator: '<S12>/Compare' incorporates:
   *  Constant: '<S12>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_VehSpd_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_VehSpd_Valid'
   */
  rtb_Compare_pp = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_VehSpd_Valid_IMAPve_d_ESC_VehSpd_Valid
                     ()) != ((uint8)1U));

  /* RelationalOperator: '<S20>/Compare' incorporates:
   *  Constant: '<S20>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_ESC_YawRate_Valid_1'
   *  Inport: '<Root>/IMAPve_d_ESC_YawRate_Valid'
   */
  rtb_Compare_a = (((uint8)
                    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_ESC_YawRate_Valid_IMAPve_d_ESC_YawRate_Valid
                    ()) == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_Fusion_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Fusion_Status'
   */
  rtb_IMAPve_d_Fusion_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Fusion_Status_IMAPve_d_Fusion_Status();

  /* DataTypeConversion: '<S50>/Cast To Single59' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_L1_Type_1'
   *  Inport: '<Root>/IMAPve_d_L1_Type'
   */
  rtb_L1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_L1_Type_IMAPve_d_L1_Type();

  /* DataTypeConversion: '<S1>/IMAPve_d_MP5_Work_State_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_MP5_Work_State'
   */
  rtb_IMAPve_d_MP5_Work_State = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_MP5_Work_State_IMAPve_d_MP5_Work_State
    ();

  /* DataTypeConversion: '<S50>/Cast To Single70' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_d_R1_Type_1'
   *  Inport: '<Root>/IMAPve_d_R1_Type'
   */
  rtb_R1_Type = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_R1_Type_IMAPve_d_R1_Type();

  /* RelationalOperator: '<S14>/Compare' incorporates:
   *  Constant: '<S14>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Clb_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Clb_State'
   */
  rtb_Compare_d2 = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Clb_State_IMAPve_d_SAS_Clb_State
                     ()) == ((uint8)0U));

  /* RelationalOperator: '<S15>/Compare' incorporates:
   *  Constant: '<S15>/Constant'
   *  DataTypeConversion: '<S1>/IMAPve_d_SAS_Trim_State_1'
   *  Inport: '<Root>/IMAPve_d_SAS_Trim_State'
   */
  rtb_Compare_bw = (((uint8)
                     Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SAS_Trim_State_IMAPve_d_SAS_Trim_State
                     ()) == ((uint8)1U));

  /* DataTypeConversion: '<S1>/IMAPve_d_SWS_Failure_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_SWS_Failure_Status'
   */
  rtb_IMAPve_d_SWS_Failure_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_SWS_Failure_Status_IMAPve_d_SWS_Failure_Status
    ();

  /* DataTypeConversion: '<S1>/IMAPve_d_Sensor_Status_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_Sensor_Status'
   */
  rtb_IMAPve_d_Sensor_Status = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_Sensor_Status_IMAPve_d_Sensor_Status();

  /* DataTypeConversion: '<S1>/IMAPve_d_TCU_TCU_Available_1' incorporates:
   *  Inport: '<Root>/IMAPve_d_TCU_TCU_Available'
   */
  rtb_IMAPve_d_TCU_TCU_Available = (uint8)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_d_TCU_TCU_Available_IMAPve_d_TCU_TCU_Available
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EMS_RealPedal_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EMS_RealPedal'
   */
  rtb_IMAPve_g_EMS_RealPedal = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EMS_RealPedal_IMAPve_g_EMS_RealPedal();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_LKA_Current_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_LKA_Current'
   */
  rtb_IMAPve_g_EPS_LKA_Current = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_LKA_Current_IMAPve_g_EPS_LKA_Current
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_EPS_SteeringAngle_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_EPS_SteeringAngle'
   */
  rtb_IMAPve_g_EPS_SteeringAngle = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_EPS_SteeringAngle_IMAPve_g_EPS_SteeringAngle
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_Brake_Press_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_Brake_Press'
   */
  rtb_IMAPve_g_ESC_Brake_Press = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_Brake_Press_IMAPve_g_ESC_Brake_Press
    ();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_UnYawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_UnYawRate'
   */
  rtb_IMAPve_g_ESC_UnYawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_UnYawRate_IMAPve_g_ESC_UnYawRate();

  /* DataTypeConversion: '<S1>/IMAPve_g_ESC_YawRate_1' incorporates:
   *  Inport: '<Root>/IMAPve_g_ESC_YawRate'
   */
  rtb_IMAPve_g_ESC_YawRate = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_ESC_YawRate_IMAPve_g_ESC_YawRate();

  /* DataTypeConversion: '<S50>/Cast To Single43' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C0_1'
   *  Inport: '<Root>/IMAPve_g_L1_C0'
   *  UnaryMinus: '<S50>/Unary Minus8'
   */
  rtb_L1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C0_IMAPve_g_L1_C0
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single42' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C1_1'
   *  Inport: '<Root>/IMAPve_g_L1_C1'
   *  UnaryMinus: '<S50>/Unary Minus9'
   */
  rtb_L1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C1_IMAPve_g_L1_C1
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single44' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C2_1'
   *  Inport: '<Root>/IMAPve_g_L1_C2'
   *  UnaryMinus: '<S50>/Unary Minus10'
   */
  rtb_L1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C2_IMAPve_g_L1_C2
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single79' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_C3_1'
   *  Inport: '<Root>/IMAPve_g_L1_C3'
   *  UnaryMinus: '<S50>/Unary Minus11'
   */
  rtb_L1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_C3_IMAPve_g_L1_C3
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single78' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_VR_1'
   *  Inport: '<Root>/IMAPve_g_L1_VR'
   */
  rtb_L1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_VR_IMAPve_g_L1_VR();

  /* DataTypeConversion: '<S50>/Cast To Single74' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_L1_W_1'
   *  Inport: '<Root>/IMAPve_g_L1_W'
   */
  rtb_L1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_L1_W_IMAPve_g_L1_W();

  /* DataTypeConversion: '<S50>/Cast To Single46' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C0_1'
   *  Inport: '<Root>/IMAPve_g_R1_C0'
   *  UnaryMinus: '<S50>/Unary Minus14'
   */
  rtb_R1_C0 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C0_IMAPve_g_R1_C0
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single45' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C1_1'
   *  Inport: '<Root>/IMAPve_g_R1_C1'
   *  UnaryMinus: '<S50>/Unary Minus15'
   */
  rtb_R1_C1 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C1_IMAPve_g_R1_C1
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single49' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C2_1'
   *  Inport: '<Root>/IMAPve_g_R1_C2'
   *  UnaryMinus: '<S50>/Unary Minus12'
   */
  rtb_R1_C2 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C2_IMAPve_g_R1_C2
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single53' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_C3_1'
   *  Inport: '<Root>/IMAPve_g_R1_C3'
   *  UnaryMinus: '<S50>/Unary Minus13'
   */
  rtb_R1_C3 = (float32)((T_M_Nm_Float32)
                        (-Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_C3_IMAPve_g_R1_C3
    ()));

  /* DataTypeConversion: '<S50>/Cast To Single50' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_VR_1'
   *  Inport: '<Root>/IMAPve_g_R1_VR'
   */
  rtb_R1_VR = (float32)
    Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_VR_IMAPve_g_R1_VR();

  /* DataTypeConversion: '<S50>/Cast To Single52' incorporates:
   *  DataTypeConversion: '<S1>/IMAPve_g_R1_W_1'
   *  Inport: '<Root>/IMAPve_g_R1_W'
   */
  rtb_R1_W = (float32)Rte_IRead_Runnable_LKAS_Step_IMAPve_g_R1_W_IMAPve_g_R1_W();

  /* Switch: '<S557>/Switch1' incorporates:
   *  Constant: '<S557>/LL_DvtComp_C=0'
   */
  if (LKAS_ConstB.DataTypeConversion1_l != 0.0F) {
    rtb_LL_DvtComp_C = LKAS_ConstB.DataTypeConversion1_l;
  } else {
    rtb_LL_DvtComp_C = LL_DvtComp_C;
  }

  /* End of Switch: '<S557>/Switch1' */

  /* Switch: '<S557>/Switch15' incorporates:
   *  Constant: '<S557>/LL_lStpLngth_C=5'
   */
  if (LKAS_ConstB.DataTypeConversion21 != 0.0F) {
    rtb_LL_lStpLngth_C = LKAS_ConstB.DataTypeConversion21;
  } else {
    rtb_LL_lStpLngth_C = LL_lStpLngth_C;
  }

  /* End of Switch: '<S557>/Switch15' */

  /* Switch: '<S557>/Switch10' incorporates:
   *  Constant: '<S557>/LL_DesDvt_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion22_k != 0.0F) {
    rtb_LL_DesDvt_C = LKAS_ConstB.DataTypeConversion22_k;
  } else {
    rtb_LL_DesDvt_C = LL_DesDvt_C;
  }

  /* End of Switch: '<S557>/Switch10' */

  /* Switch: '<S557>/Switch12' incorporates:
   *  Constant: '<S557>/LL_NomTAhd_C=0.2'
   */
  if (LKAS_ConstB.DataTypeConversion23 != 0.0F) {
    rtb_LL_NomTAhd_C = LKAS_ConstB.DataTypeConversion23;
  } else {
    rtb_LL_NomTAhd_C = LL_NomTAhd_C;
  }

  /* End of Switch: '<S557>/Switch12' */

  /* Switch: '<S558>/Switch56' incorporates:
   *  Constant: '<S558>/LLSMConClb14'
   *
   * Block description for '<S558>/LLSMConClb14':
   *  LKA���ܵĳ�����ٸ�Ԥ�߳���ʱ����ֵ
   */
  if (LKAS_ConstB.DataTypeConversion21_k != 0.0F) {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LKAS_ConstB.DataTypeConversion21_k;
  } else {
    rtb_LL_LKAS_OUT_OF_CONTROL_TTLC = LL_LKAS_OUT_OF_CONTROL_TTLC;
  }

  /* End of Switch: '<S558>/Switch56' */

  /* Switch: '<S558>/Switch51' incorporates:
   *  Constant: '<S558>/LLSMConClb15'
   *
   * Block description for '<S558>/LLSMConClb15':
   *  ƫ��������
   */
  if (LKAS_ConstB.DataTypeConversion25_o != 0.0F) {
    rtb_LL_DvtComp_C_i = LKAS_ConstB.DataTypeConversion25_o;
  } else {
    rtb_LL_DvtComp_C_i = LL_DvtComp_C;
  }

  /* End of Switch: '<S558>/Switch51' */

  /* Switch: '<S558>/Switch52' incorporates:
   *  Constant: '<S558>/LLSMConClb16'
   *
   * Block description for '<S558>/LLSMConClb16':
   *  LDW���ܵ�����Ԥ����
   */
  if (LKAS_ConstB.DataTypeConversion36_b != 0.0F) {
    rtb_LL_LDW_EarliestWarnLine_C = LKAS_ConstB.DataTypeConversion36_b;
  } else {
    rtb_LL_LDW_EarliestWarnLine_C = LL_LDW_EarliestWarnLine_C;
  }

  /* End of Switch: '<S558>/Switch52' */

  /* Switch: '<S558>/Switch46' incorporates:
   *  Constant: '<S558>/LL_RlsDet_tiTDelTime_DISABLE=20'
   *
   * Block description for '<S558>/LL_RlsDet_tiTDelTime_DISABLE=20':
   *  ��ʹ�ܾ����ϴμ�ʻԱ����ʱ����
   */
  if (LKAS_ConstB.DataTypeConversion9_e != 0.0F) {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LKAS_ConstB.DataTypeConversion9_e;
  } else {
    rtb_LL_RlsDet_tiTDelTime_DISABL = LL_RlsDet_tiTDelTime_DISABLE;
  }

  /* End of Switch: '<S558>/Switch46' */

  /* Update for Delay: '<S65>/Delay' */
  LKAS_DW.Delay_DSTATE = rtb_Saturation1;

  /* Update for Memory: '<S73>/Memory' */
  LKAS_DW.Memory_PreviousInput = rtb_Add1;

  /* Update for Memory: '<S76>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = rtb_L0_C0;

  /* Update for Memory: '<S76>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = rtb_Saturation;

  /* Update for Memory: '<S68>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_h = rtb_R0_C0;

  /* Update for Memory: '<S68>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = rtb_offset;

  /* Update for Enabled SubSystem: '<S2>/LLOn' incorporates:
   *  EnablePort: '<S10>/Enable'
   */
  if (LKAS_DW.LLOn_MODE) {
    /* Update for Delay: '<S81>/Delay' */
    LKAS_DW.Delay_DSTATE_o = LKAS_DW.LKASM_stLKAActvFlg;

    /* Update for Memory: '<S520>/Memory' */
    LKAS_DW.Memory_PreviousInput_j = rtb_Saturation_c;

    /* Update for Delay: '<S82>/Delay1' */
    LKAS_DW.Delay1_3_DSTATE = LKAS_DW.LKASM_stLKAState;

    /* Update for Memory: '<S463>/Memory' */
    LKAS_DW.Memory_PreviousInput_c = rtb_Saturation_f;

    /* Update for UnitDelay: '<S395>/Delay Input1'
     *
     * Block description for '<S395>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE = rtb_Compare_iz;

    /* Update for UnitDelay: '<S394>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_i = LKAS_DW.RelationalOperator_a;

    /* Update for UnitDelay: '<S357>/Delay Input1'
     *
     * Block description for '<S357>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_c = rtb_Compare_km;

    /* Update for UnitDelay: '<S355>/Unit Delay' */
    LKAS_DW.UnitDelay_DSTATE_gu = LKAS_DW.RelationalOperator_c;

    /* Update for UnitDelay: '<S356>/Delay Input1'
     *
     * Block description for '<S356>/Delay Input1':
     *
     *  Store in Global RAM
     */
    LKAS_DW.DelayInput1_DSTATE_p = rtb_Compare_cj;

    /* Update for Memory: '<S322>/Memory' */
    LKAS_DW.Memory_PreviousInput_eq = LKAS_DW.RelationalOperator_c;

    /* Update for Delay: '<S82>/Delay' */
    LKAS_DW.Delay_DSTATE_j = LKAS_DW.LogicalOperator3;

    /* Update for Delay: '<S82>/Delay1' */
    LKAS_DW.Delay1_1_DSTATE = LKAS_DW.LDWSM_stLDWState;

    /* Update for Memory: '<S370>/Memory' */
    LKAS_DW.Memory_PreviousInput_id = rtb_LDW_State;

    /* Update for Memory: '<S296>/Memory' */
    LKAS_DW.Memory_PreviousInput_i = rtb_Merge1_n;

    /* Update for Memory: '<S332>/Memory' */
    LKAS_DW.Memory_PreviousInput_a = rtb_Merge1_j;

    /* Update for Enabled SubSystem: '<S10>/LKA' incorporates:
     *  EnablePort: '<S80>/Enable'
     *
     * Block description for '<S10>/LKA':
     *  Block Name: Lane Keeping Assistance
     *  Ab.: LKA
     *  No.: 1.2.0.0
     *  Rev: 0.0.1
     *  Update Date: 19-5-13
     */
    if (LKAS_DW.LKA_MODE) {
      /* Update for Memory: '<S108>/Memory' */
      LKAS_DW.Memory_PreviousInput_ok = rtb_Saturation2_g;

      /* Update for Memory: '<S139>/Memory' */
      LKAS_DW.Memory_PreviousInput_mx = rtb_Saturation1_f;

      /* Update for Memory: '<S126>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_l = rtb_Saturation1_cv;

      /* Update for Memory: '<S138>/Memory' */
      LKAS_DW.Memory_PreviousInput_av = rtb_Saturation1_a;

      /* Update for Memory: '<S140>/Memory' */
      LKAS_DW.Memory_PreviousInput_nj = rtb_Saturation1_b;

      /* Update for Memory: '<S135>/Memory' */
      LKAS_DW.Memory_PreviousInput_p1 = rtb_Saturation1_k;

      /* Update for Memory: '<S123>/Memory' */
      LKAS_DW.Memory_PreviousInput_i3d = rtb_Add_l;

      /* Update for Memory: '<S109>/Memory' */
      LKAS_DW.Memory_PreviousInput_kz = rtb_Saturation2_l;

      /* Update for Memory: '<S110>/Memory' */
      LKAS_DW.Memory_PreviousInput_mo = rtb_Saturation2_n;

      /* Update for UnitDelay: '<S112>/Delay Input1'
       *
       * Block description for '<S112>/Delay Input1':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput1_DSTATE_px = rtb_Compare_az;

      /* Update for Memory: '<S110>/Memory1' */
      LKAS_DW.Memory1_PreviousInput_k = rtb_Merge_ba;

      /* Update for Memory: '<S107>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_e = rtb_Saturation_gi;

      /* Update for Memory: '<S202>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_p = rtb_Saturation_e;

      /* Update for Memory: '<S185>/Memory' */
      LKAS_DW.Memory_PreviousInput_g = rtb_Add1_h;

      /* Update for UnitDelay: '<S183>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_a = rtb_Switch2_at;

      /* Update for Memory: '<S191>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_m = rtb_Saturation_j;

      /* Update for Memory: '<S197>/Memory' */
      LKAS_DW.Memory_PreviousInput_f4 = rtb_Saturation1_m;

      /* Update for UnitDelay: '<S201>/Unit Delay' */
      LKAS_DW.UnitDelay_DSTATE_g = rtb_Switch_kb;

      /* Update for Memory: '<S201>/Memory3' */
      LKAS_DW.Memory3_PreviousInput_b = rtb_Saturation_nf;

      /* Update for UnitDelay: '<S178>/Delay Input2'
       *
       * Block description for '<S178>/Delay Input2':
       *
       *  Store in Global RAM
       */
      LKAS_DW.DelayInput2_DSTATE_b = LKAS_DW.DifferenceInputs2;

      /* Update for Memory: '<S178>/Memory' */
      LKAS_DW.Memory_PreviousInput_e = rtb_Saturation2_b;

      /* Update for Memory: '<S134>/Memory' */
      LKAS_DW.Memory_PreviousInput_b = rtb_Add_jk;

      /* Update for Memory: '<S136>/Memory' */
      LKAS_DW.Memory_PreviousInput_l = rtb_Saturation1_or;

      /* Update for Memory: '<S137>/Memory' */
      LKAS_DW.Memory_PreviousInput_oj = rtb_Saturation1_p;
    }

    /* End of Update for SubSystem: '<S10>/LKA' */

    /* Update for Delay: '<S82>/Delay1' */
    LKAS_DW.Delay1_2_DSTATE = LKAS_DW.LKA_Mode;
  }

  /* End of Update for SubSystem: '<S2>/LLOn' */

  /* Update for UnitDelay: '<S551>/Delay Input2'
   *
   * Block description for '<S551>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE = rtb_L0_C2;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_Vehicle_Lane_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Vehicle_Lane_Display_LKASve_y_Vehicle_Lane_Display
    ((UInt8)rtb_L0_Q);

  /* Outport: '<Root>/LKASve_y_LDW_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Status_Display_LKASve_y_LDW_Status_Display
    ((UInt8)rtb_TCU_ActualGear);

  /* Outport: '<Root>/LKASve_y_LKA_Status_Display' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single2'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Status_Display_LKASve_y_LKA_Status_Display
    ((UInt8)((uint8)rtb_LL_CompHdAg_C));

  /* Outport: '<Root>/LKASve_y_LDW_Flag' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single3'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LDW_Flag_LKASve_y_LDW_Flag((UInt8)
    rtb_CastToSingle3);

  /* Outport: '<Root>/LKASve_y_Hands_Off_Warning' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single4'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_Hands_Off_Warning_LKASve_y_Hands_Off_Warning
    ((UInt8)rtb_Hands_Off_Warning_c);

  /* Outport: '<Root>/LKASve_y_LKA_Action_Indication' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single5'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKA_Action_Indication_LKASve_y_LKA_Action_Indication
    ((UInt8)rtb_LKA_Action_Indication_d);

  /* Outport: '<Root>/LKASve_y_HMI_Popup_Status' incorporates:
   *  DataTypeConversion: '<S8>/Cast To Single6'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_HMI_Popup_Status_LKASve_y_HMI_Popup_Status
    ((UInt8)rtb_IMAPve_d_Camera_Status);

  /* Outport: '<Root>/LKASve_y_LKATorqueReq' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single1'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_LKATorqueReq_LKASve_y_LKATorqueReq
    ((UInt8)rtb_R0_Q);

  /* Switch: '<S552>/Switch2' incorporates:
   *  Constant: '<S546>/Constant3'
   *  Constant: '<S546>/Constant4'
   *  RelationalOperator: '<S552>/LowerRelop1'
   *  RelationalOperator: '<S552>/UpperRelop'
   *  Switch: '<S552>/Switch'
   */
  if (rtb_L0_C2 > 5.0F) {
    rtb_L0_C2 = 5.0F;
  } else {
    if (rtb_L0_C2 < (-5.0F)) {
      /* Switch: '<S552>/Switch' incorporates:
       *  Constant: '<S546>/Constant4'
       */
      rtb_L0_C2 = (-5.0F);
    }
  }

  /* End of Switch: '<S552>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_LKATorqueReq_Value' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKATorqueReq_Value_LKASve_g_LKATorqueReq_Value
    ((T_M_Nm_Float32)rtb_L0_C2);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Outport: '<Root>/LKASve_y_EPS_State_Control' incorporates:
   *  DataTypeConversion: '<S1>/Cast To Single8'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_State_Control_LKASve_y_EPS_State_Control
    ((UInt8)rtb_IMAPve_d_SAS_Trim_State);

  /* Outport: '<Root>/LKASve_g_LKA_SWA_Control' incorporates:
   *  DataTypeConversion: '<S11>/Cast To Single'
   */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_LKA_SWA_Control_LKASve_g_LKA_SWA_Control
    ((T_M_Nm_Float32)LKAS_DW.OutputSWACmd);

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S11>/x1'
   */
  if (rtb_Merge_a3) {
    rtb_L0_C0 = LKAS_DW.OutputM;
  } else {
    rtb_L0_C0 = (float32)((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_g_EPS_Factor_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_EPS_Factor_Control_LKASve_g_EPS_Factor_Control
    ((T_M_Nm_Float32)rtb_L0_C0);

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Switch: '<S11>/Switch2' incorporates:
   *  Constant: '<S11>/2'
   *  Constant: '<S11>/x2'
   *  Constant: '<S549>/Constant'
   *  Constant: '<S550>/Constant'
   *  Logic: '<S11>/Logical Operator'
   *  RelationalOperator: '<S549>/Compare'
   *  RelationalOperator: '<S550>/Compare'
   */
  if ((rtb_IMAPve_d_SAS_Trim_State == ((uint8)4U)) ||
      (rtb_IMAPve_d_SAS_Trim_State == ((uint8)3U))) {
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)1U);
  } else {
    rtb_IMAPve_d_SAS_Trim_State = ((uint8)0U);
  }

  /* End of Switch: '<S11>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* Outport: '<Root>/LKASve_y_EPS_LKA_Control' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_y_EPS_LKA_Control_LKASve_y_EPS_LKA_Control
    ((UInt8)rtb_IMAPve_d_SAS_Trim_State);

  /* Outport: '<Root>/LKASve_g_ob5H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5H_10_LKASve_g_ob5H_10
    (LKAS_DW.LKASve_g_ob5H_10);

  /* Outport: '<Root>/LKASve_g_ob5L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob5L_10_LKASve_g_ob5L_10
    (LKAS_DW.LKASve_g_ob5L_10);

  /* Outport: '<Root>/LKASve_g_ob6H_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6H_10_LKASve_g_ob6H_10
    (LKAS_DW.LKASve_g_ob6H_10);

  /* Outport: '<Root>/LKASve_g_ob6L_10' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob6L_10_LKASve_g_ob6L_10
    (LKAS_DW.LKASve_g_ob6L_10);

  /* Outport: '<Root>/LKASve_g_ob07H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07H_100_LKASve_g_ob07H_100
    (LKAS_DW.LKASve_g_ob07H_100);

  /* Outport: '<Root>/LKASve_g_ob07L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob07L_100_LKASve_g_ob07L_100
    (LKAS_DW.LKASve_g_ob07L_100);

  /* Outport: '<Root>/LKASve_g_ob08H_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08H_100_LKASve_g_ob08H_100
    (LKAS_DW.LKASve_g_ob08H_100);

  /* Outport: '<Root>/LKASve_g_ob08L_100' */
  Rte_IWrite_Runnable_LKAS_Step_LKASve_g_ob08L_100_LKASve_g_ob08L_100
    (LKAS_DW.LKASve_g_ob08L_100);
}

/* Model initialize function */
void Runnable_LKAS_Init(void)
{
  /* Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* Start for Enabled SubSystem: '<S2>/LLOn' */
  /* Start for If: '<S370>/u1>=3|u1==1&u2==u3' */
  LKAS_DW.u13u11u2u3_ActiveSubsystem = -1;

  /* Start for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* Start for If: '<S126>/If' */
  LKAS_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S200>/If' */
  LKAS_DW.If_ActiveSubsystem_l = -1;

  /* End of Start for SubSystem: '<S10>/LKA' */
  /* End of Start for SubSystem: '<S2>/LLOn' */
  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack' */

  /*-----------S-Function Block: <S4>/CAN Unpack -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack1' */

  /*-----------S-Function Block: <S4>/CAN Unpack1 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack2' */

  /*-----------S-Function Block: <S4>/CAN Unpack2 -----------------*/

  /* Start for S-Function (scanunpack): '<S4>/CAN Unpack3' */

  /*-----------S-Function Block: <S4>/CAN Unpack3 -----------------*/

  /* End of Start for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* ConstCode for Constant: '<S2>/Version' */
  ob_LKA_Version = 220315.0F;

  /* End of ConstCode for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' incorporates:
   *  SubSystem: '<Root>/LKAS'
   */
  /* InitializeConditions for Memory: '<S73>/Memory' */
  LKAS_DW.Memory_PreviousInput = 3.2F;

  /* InitializeConditions for Memory: '<S76>/Memory1' */
  LKAS_DW.Memory1_PreviousInput = (-1.75F);

  /* InitializeConditions for Memory: '<S76>/Memory' */
  LKAS_DW.Memory_PreviousInput_m = (-1.75F);

  /* InitializeConditions for Memory: '<S68>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_h = 1.75F;

  /* InitializeConditions for Memory: '<S68>/Memory' */
  LKAS_DW.Memory_PreviousInput_f = 1.75F;

  /* SystemInitialize for Enabled SubSystem: '<S2>/LLOn' */
  /* InitializeConditions for Delay: '<S81>/Delay' */
  LKAS_DW.Delay_DSTATE_o = ((uint8)0U);

  /* InitializeConditions for Memory: '<S520>/Memory' */
  LKAS_DW.Memory_PreviousInput_j = 0.0F;

  /* InitializeConditions for Delay: '<S82>/Delay1' */
  LKAS_DW.Delay1_3_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S463>/Memory' */
  LKAS_DW.Memory_PreviousInput_c = 0.0F;

  /* InitializeConditions for UnitDelay: '<S395>/Delay Input1'
   *
   * Block description for '<S395>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE = false;

  /* InitializeConditions for UnitDelay: '<S394>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_i = false;

  /* InitializeConditions for UnitDelay: '<S357>/Delay Input1'
   *
   * Block description for '<S357>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_c = false;

  /* InitializeConditions for UnitDelay: '<S355>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_gu = false;

  /* InitializeConditions for UnitDelay: '<S356>/Delay Input1'
   *
   * Block description for '<S356>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_p = false;

  /* InitializeConditions for Memory: '<S322>/Memory' */
  LKAS_DW.Memory_PreviousInput_eq = false;

  /* InitializeConditions for Delay: '<S82>/Delay' */
  LKAS_DW.Delay_DSTATE_j = false;

  /* InitializeConditions for Delay: '<S82>/Delay1' */
  LKAS_DW.Delay1_1_DSTATE = ((uint8)0U);

  /* InitializeConditions for Memory: '<S370>/Memory' */
  LKAS_DW.Memory_PreviousInput_id = ((uint8)0U);

  /* InitializeConditions for Memory: '<S296>/Memory' */
  LKAS_DW.Memory_PreviousInput_i = 0.0F;

  /* InitializeConditions for Memory: '<S332>/Memory' */
  LKAS_DW.Memory_PreviousInput_a = 0.0F;

  /* InitializeConditions for Delay: '<S82>/Delay1' */
  LKAS_DW.Delay1_2_DSTATE = ((uint8)0U);

  /* SystemInitialize for Enabled SubSystem: '<S383>/ExitCount' */
  /* InitializeConditions for Memory: '<S391>/Memory' */
  LKAS_DW.Memory_PreviousInput_no = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S383>/ExitCount' */

  /* SystemInitialize for Enabled SubSystem: '<S384>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S393>/Memory' */
  LKAS_DW.Memory_PreviousInput_k = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S384>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S394>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S398>/Memory' */
  LKAS_DW.Memory_PreviousInput_p = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S394>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S322>/Count 0.2s' */
  /* InitializeConditions for Memory: '<S353>/Memory' */
  LKAS_DW.Memory_PreviousInput_m5 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S322>/Count 0.2s' */

  /* SystemInitialize for Enabled SubSystem: '<S322>/Count' */
  /* InitializeConditions for Memory: '<S352>/Memory' */
  LKAS_DW.Memory_PreviousInput_o = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S322>/Count' */

  /* SystemInitialize for Enabled SubSystem: '<S355>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S361>/Memory' */
  LKAS_DW.Memory_PreviousInput_n2 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S355>/Sum Condition1' */

  /* SystemInitialize for Enabled SubSystem: '<S323>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S367>/Memory' */
  LKAS_DW.Memory_PreviousInput_cp = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S323>/Sum Condition1' */

  /* SystemInitialize for IfAction SubSystem: '<S370>/If Action Subsystem' */
  /* InitializeConditions for Memory: '<S400>/Memory' */
  LKAS_DW.Memory_PreviousInput_n = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S370>/If Action Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S333>/Sum Condition' */
  /* InitializeConditions for Memory: '<S339>/Memory' */
  LKAS_DW.Memory_PreviousInput_d = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S333>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S281>/Count_5s3' */
  /* InitializeConditions for Memory: '<S545>/Memory' */
  LKAS_DW.Memory_PreviousInput_i3 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S281>/Count_5s3' */

  /* SystemInitialize for Enabled SubSystem: '<S281>/Count_5s2' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s2);

  /* End of SystemInitialize for SubSystem: '<S281>/Count_5s2' */

  /* SystemInitialize for Enabled SubSystem: '<S281>/Count_5s1' */
  LKAS_Count_5s1_Init(&LKAS_DW.Count_5s1);

  /* End of SystemInitialize for SubSystem: '<S281>/Count_5s1' */

  /* SystemInitialize for Enabled SubSystem: '<S258>/Subsystem' */
  /* InitializeConditions for Memory: '<S262>/Memory' */
  LKAS_DW.Memory_PreviousInput_h = ((uint16)0U);

  /* End of SystemInitialize for SubSystem: '<S258>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LKA'
   *
   * Block description for '<S10>/LKA':
   *  Block Name: Lane Keeping Assistance
   *  Ab.: LKA
   *  No.: 1.2.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-5-13
   */
  /* InitializeConditions for Memory: '<S108>/Memory' */
  LKAS_DW.Memory_PreviousInput_ok = 0.0F;

  /* InitializeConditions for Memory: '<S139>/Memory' */
  LKAS_DW.Memory_PreviousInput_mx = ((uint16)0U);

  /* InitializeConditions for Memory: '<S126>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_l = ((uint8)0U);

  /* InitializeConditions for Memory: '<S138>/Memory' */
  LKAS_DW.Memory_PreviousInput_av = ((uint16)0U);

  /* InitializeConditions for Memory: '<S140>/Memory' */
  LKAS_DW.Memory_PreviousInput_nj = ((uint16)0U);

  /* InitializeConditions for Memory: '<S135>/Memory' */
  LKAS_DW.Memory_PreviousInput_p1 = ((uint16)0U);

  /* InitializeConditions for Memory: '<S123>/Memory' */
  LKAS_DW.Memory_PreviousInput_i3d = 0.0F;

  /* InitializeConditions for Memory: '<S109>/Memory' */
  LKAS_DW.Memory_PreviousInput_kz = 0.0F;

  /* InitializeConditions for Memory: '<S110>/Memory' */
  LKAS_DW.Memory_PreviousInput_mo = 0.0F;

  /* InitializeConditions for UnitDelay: '<S112>/Delay Input1'
   *
   * Block description for '<S112>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_px = false;

  /* InitializeConditions for Memory: '<S110>/Memory1' */
  LKAS_DW.Memory1_PreviousInput_k = false;

  /* InitializeConditions for Memory: '<S107>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_e = 0.0F;

  /* InitializeConditions for Memory: '<S202>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_p = 0.0F;

  /* InitializeConditions for Memory: '<S185>/Memory' */
  LKAS_DW.Memory_PreviousInput_g = 0.0F;

  /* InitializeConditions for UnitDelay: '<S183>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_a = 0.0F;

  /* InitializeConditions for Memory: '<S191>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_m = 0.0F;

  /* InitializeConditions for Memory: '<S197>/Memory' */
  LKAS_DW.Memory_PreviousInput_f4 = ((uint16)0U);

  /* InitializeConditions for UnitDelay: '<S201>/Unit Delay' */
  LKAS_DW.UnitDelay_DSTATE_g = 0.0F;

  /* InitializeConditions for Memory: '<S201>/Memory3' */
  LKAS_DW.Memory3_PreviousInput_b = 0.0F;

  /* InitializeConditions for UnitDelay: '<S178>/Delay Input2'
   *
   * Block description for '<S178>/Delay Input2':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput2_DSTATE_b = 0.0F;

  /* InitializeConditions for Memory: '<S178>/Memory' */
  LKAS_DW.Memory_PreviousInput_e = ((uint16)0U);

  /* InitializeConditions for Memory: '<S134>/Memory' */
  LKAS_DW.Memory_PreviousInput_b = ((uint16)0U);

  /* InitializeConditions for Memory: '<S136>/Memory' */
  LKAS_DW.Memory_PreviousInput_l = ((uint16)0U);

  /* InitializeConditions for Memory: '<S137>/Memory' */
  LKAS_DW.Memory_PreviousInput_oj = ((uint16)0U);

  /* SystemInitialize for Enabled SubSystem: '<S109>/Sum Condition1' */
  /* InitializeConditions for Memory: '<S111>/Memory' */
  LKAS_DW.Memory_PreviousInput_n0 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S109>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S98>/Moving Standard Deviation2' */
  L_MovingStandardDeviation2_Init(&LKAS_DW.MovingStandardDeviation2);

  /* End of SystemInitialize for SubSystem: '<S98>/Moving Standard Deviation2' */

  /* SystemInitialize for Atomic SubSystem: '<S110>/Moving Standard Deviation1' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation1);

  /* End of SystemInitialize for SubSystem: '<S110>/Moving Standard Deviation1' */

  /* SystemInitialize for Enabled SubSystem: '<S110>/Sum Condition1' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition1_j);

  /* End of SystemInitialize for SubSystem: '<S110>/Sum Condition1' */

  /* SystemInitialize for Atomic SubSystem: '<S110>/Moving Standard Deviation2' */
  L_MovingStandardDeviation1_Init(&LKAS_DW.MovingStandardDeviation2_d);

  /* End of SystemInitialize for SubSystem: '<S110>/Moving Standard Deviation2' */

  /* SystemInitialize for Enabled SubSystem: '<S110>/Sum Condition' */
  LKAS_SumCondition_Init(&LKAS_DW.SumCondition_c);

  /* End of SystemInitialize for SubSystem: '<S110>/Sum Condition' */

  /* SystemInitialize for Enabled SubSystem: '<S110>/Sum Condition2' */
  /* InitializeConditions for Memory: '<S119>/Memory' */
  LKAS_DW.Memory_PreviousInput_ik = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S110>/Sum Condition2' */

  /* SystemInitialize for IfAction SubSystem: '<S200>/If Action Subsystem' */
  /* InitializeConditions for UnitDelay: '<S210>/Delay Input1'
   *
   * Block description for '<S210>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_b = false;

  /* InitializeConditions for Memory: '<S206>/Memory' */
  LKAS_DW.Memory_PreviousInput_ge = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S200>/If Action Subsystem' */

  /* SystemInitialize for IfAction SubSystem: '<S200>/If Action Subsystem1' */
  /* InitializeConditions for UnitDelay: '<S218>/Delay Input1'
   *
   * Block description for '<S218>/Delay Input1':
   *
   *  Store in Global RAM
   */
  LKAS_DW.DelayInput1_DSTATE_m = false;

  /* InitializeConditions for Memory: '<S207>/Memory' */
  LKAS_DW.Memory_PreviousInput_ph = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S200>/If Action Subsystem1' */

  /* SystemInitialize for Merge: '<S200>/Merge' */
  LKAS_DW.Merge_e = 1.0F;

  /* SystemInitialize for Merge: '<S200>/Merge1' */
  LKAS_DW.Merge1 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S10>/LKA' */

  /* SystemInitialize for Enabled SubSystem: '<S10>/LDW'
   *
   * Block description for '<S10>/LDW':
   *  Block Name: Lane Departure Warning
   *  Ab.: LDW
   *  No.: 1.3.0.0
   *  Rev: 0.0.1
   *  Update Date: 19-3-26
   */
  /* SystemInitialize for Merge: '<S84>/Merge' */
  LKAS_DW.Merge_l = 0.0F;

  /* SystemInitialize for Enabled SubSystem: '<S84>/Sum Condition' */
  /* InitializeConditions for Memory: '<S88>/Memory' */
  LKAS_DW.Memory_PreviousInput_o2 = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S84>/Sum Condition' */
  /* End of SystemInitialize for SubSystem: '<S10>/LDW' */

  /* SystemInitialize for Enabled SubSystem: '<S403>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1_l);

  /* End of SystemInitialize for SubSystem: '<S403>/Sum Condition1' */
  /* End of SystemInitialize for SubSystem: '<S2>/LLOn' */

  /* SystemInitialize for Enabled SubSystem: '<S546>/Subsystem' */
  /* InitializeConditions for Delay: '<S553>/Delay1' */
  LKAS_DW.Delay1_DSTATE = 0.0F;

  /* End of SystemInitialize for SubSystem: '<S546>/Subsystem' */

  /* SystemInitialize for Enabled SubSystem: '<S28>/Sum Condition2' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition2);

  /* End of SystemInitialize for SubSystem: '<S28>/Sum Condition2' */

  /* SystemInitialize for Enabled SubSystem: '<S28>/Sum Condition1' */
  LKAS_SumCondition1_Init(&LKAS_DW.SumCondition1);

  /* End of SystemInitialize for SubSystem: '<S28>/Sum Condition1' */
  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_Runnable_LKAS_Step_at_outport_1' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
